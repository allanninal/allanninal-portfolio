import { test, expect } from '@playwright/test';

test.describe('Designer Portfolio — page structure', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('page has correct title', async ({ page }) => {
    await expect(page).toHaveTitle(/Mara Voss.*Designer/i);
  });

  test('page has meta description', async ({ page }) => {
    const desc = await page.getAttribute('meta[name="description"]', 'content');
    expect(desc).toBeTruthy();
    expect(desc!.length).toBeGreaterThan(20);
  });

  test('page has canonical link', async ({ page }) => {
    const canonical = await page.getAttribute('link[rel="canonical"]', 'href');
    expect(canonical).toBeTruthy();
  });

  test('page has OG image meta', async ({ page }) => {
    const ogImage = await page.getAttribute('meta[property="og:image"]', 'content');
    expect(ogImage).toBeTruthy();
    expect(ogImage).toContain('og-image.png');
  });

  test('page has twitter card meta', async ({ page }) => {
    const card = await page.getAttribute('meta[name="twitter:card"]', 'content');
    expect(card).toBe('summary_large_image');
  });

  test('page has JSON-LD Person schema', async ({ page }) => {
    const ldJson = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
      return scripts.map((s) => JSON.parse(s.textContent || '{}'));
    });
    const person = ldJson.find((s) => s['@type'] === 'Person');
    expect(person).toBeTruthy();
    expect(person.name).toBe('Mara Voss');
    expect(person.jobTitle).toBeTruthy();
  });

  test('favicon is present', async ({ page }) => {
    const favicon = await page.getAttribute('link[rel="icon"]', 'href');
    expect(favicon).toContain('favicon.svg');
  });
});

test.describe('Designer Portfolio — sections', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('hero section is visible with designer name', async ({ page }) => {
    await expect(page.locator('h1')).toContainText('Mara Voss');
  });

  test('selected works section is visible', async ({ page }) => {
    await expect(page.locator('#work')).toBeVisible();
  });

  test('work section shows 4 projects', async ({ page }) => {
    const projectArticles = page.locator('#work article');
    await expect(projectArticles).toHaveCount(4);
  });

  test('approach section is visible', async ({ page }) => {
    await expect(page.locator('#approach')).toBeVisible();
  });

  test('services section is visible', async ({ page }) => {
    await expect(page.locator('#services')).toBeVisible();
  });

  test('availability band is visible', async ({ page }) => {
    await expect(page.locator('#availability')).toBeVisible();
    await expect(page.locator('#availability')).toContainText('Available');
  });

  test('contact teaser section is visible', async ({ page }) => {
    await expect(page.locator('#contact-teaser')).toBeVisible();
  });

  test('contact section has email link', async ({ page }) => {
    const emailLink = page.locator('a[href^="mailto:"]').first();
    await expect(emailLink).toBeVisible();
  });
});

test.describe('Designer Portfolio — work pages', () => {
  const workPages = [
    '/work/',
    '/work/forma-identity/',
    '/work/kuso-packaging/',
    '/work/reverie-editorial/',
    '/work/atelier-nord-identity/',
  ];

  // Third-party analytics / ad scripts (loaded by AnalyticsHead on the deployed
  // build) can fail to load in a real browser — blocked or 403'd by the ad
  // network — which is outside the template's control. Ignore those so the test
  // still catches the TEMPLATE's own JS errors, not the environment's.
  const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag/i;
  const isTemplateError = (msg: string) =>
    !THIRD_PARTY.test(msg) &&
    // generic cross-origin resource-load failures carry no URL in the text;
    // the template's own assets are same-origin and load fine.
    !/Failed to load resource: the server responded with a status of 403/i.test(msg);

  for (const route of workPages) {
    test(`${route} renders with h1 and no console errors`, async ({ page }) => {
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
      page.on('console', (m) => {
        if (m.type() === 'error') errors.push(`console.error: ${m.text()}`);
      });

      const res = await page.goto(route);
      expect(res?.status()).toBe(200);
      await expect(page.locator('h1').first()).toBeVisible();
      expect(errors.filter(isTemplateError)).toEqual([]);
    });
  }

  test('project case study has CreativeWork JSON-LD', async ({ page }) => {
    await page.goto('/work/forma-identity/');
    const ldJson = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
      return scripts.map((s) => JSON.parse(s.textContent || '{}'));
    });
    const creativeWork = ldJson.find((s) => s['@type'] === 'CreativeWork');
    expect(creativeWork).toBeTruthy();
    expect(creativeWork.name).toContain('Forma');
  });

  test('project page shows project navigation', async ({ page }) => {
    await page.goto('/work/kuso-packaging/');
    const nav = page.locator('nav[aria-label="Project navigation"]');
    await expect(nav).toBeVisible();
  });
});

test.describe('Designer Portfolio — about and contact pages', () => {
  test('about page renders', async ({ page }) => {
    const res = await page.goto('/about/');
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1')).toContainText('Mara Voss');
  });

  test('about page shows process section', async ({ page }) => {
    await page.goto('/about/');
    await expect(page.locator('#approach-about-heading')).toBeVisible();
  });

  test('contact page renders', async ({ page }) => {
    const res = await page.goto('/contact/');
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1')).toBeVisible();
  });

  test('contact page has inquiry form', async ({ page }) => {
    await page.goto('/contact/');
    const form = page.locator('form[aria-label="Project inquiry form"]');
    await expect(form).toBeVisible();
    await expect(form.locator('input#contact-name')).toBeVisible();
    await expect(form.locator('input[type="email"]')).toBeVisible();
    await expect(form.locator('textarea')).toBeVisible();
    await expect(form.locator('button[type="submit"]')).toBeVisible();
  });

  test('404 page renders', async ({ page }) => {
    const res = await page.goto('/404/');
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1')).toBeVisible();
  });
});
