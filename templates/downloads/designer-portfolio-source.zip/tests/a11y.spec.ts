import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Designer Portfolio — accessibility', () => {
  test('homepage passes axe a11y checks', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('about page passes axe a11y checks', async ({ page }) => {
    await page.goto('/about/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('contact page passes axe a11y checks', async ({ page }) => {
    await page.goto('/contact/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('work page passes axe a11y checks', async ({ page }) => {
    await page.goto('/work/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('project case study passes axe a11y checks', async ({ page }) => {
    await page.goto('/work/forma-identity/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('404 page passes axe a11y checks', async ({ page }) => {
    await page.goto('/404/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('Pro services page passes axe a11y checks', async ({ page }) => {
    test.skip(process.env.PUBLIC_EDITION !== 'pro', 'Services page is Pro-only');
    await page.goto('/services/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('homepage has skip to content link', async ({ page }) => {
    await page.goto('/');
    const skip = page.locator('a[href="#main-content"]');
    await expect(skip).toBeAttached();
  });

  test('homepage main landmark exists', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('main#main-content')).toBeVisible();
  });

  test('all images have alt text', async ({ page }) => {
    await page.goto('/');
    const images = await page.locator('img').all();
    for (const img of images) {
      const alt = await img.getAttribute('alt');
      expect(alt, 'Image missing alt text').not.toBeNull();
    }
  });

  test('project images have alt text', async ({ page }) => {
    await page.goto('/work/forma-identity/');
    const images = await page.locator('img').all();
    for (const img of images) {
      const alt = await img.getAttribute('alt');
      expect(alt, 'Project image missing alt text').not.toBeNull();
    }
  });

  test('interactive elements have accessible names', async ({ page }) => {
    await page.goto('/');
    const links = await page.locator('a').all();
    for (const link of links) {
      const text = await link.textContent();
      const ariaLabel = await link.getAttribute('aria-label');
      const ariaLabelledBy = await link.getAttribute('aria-labelledby');
      const hasAccessibleName = text?.trim() || ariaLabel || ariaLabelledBy;
      expect(hasAccessibleName, 'Link missing accessible name').toBeTruthy();
    }
  });

  test('form inputs have labels', async ({ page }) => {
    await page.goto('/contact/');
    // Check name input
    const nameInput = page.locator('input#contact-name');
    await expect(nameInput).toBeVisible();
    const nameLabel = page.locator('label[for="contact-name"]');
    await expect(nameLabel).toBeAttached();

    // Check email input
    const emailInput = page.locator('input#contact-email');
    await expect(emailInput).toBeVisible();
    const emailLabel = page.locator('label[for="contact-email"]');
    await expect(emailLabel).toBeAttached();

    // Check message textarea
    const textarea = page.locator('textarea#contact-message');
    await expect(textarea).toBeVisible();
    const msgLabel = page.locator('label[for="contact-message"]');
    await expect(msgLabel).toBeAttached();
  });
});
