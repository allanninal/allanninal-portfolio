// Designer Portfolio — Site Data
// All copy, projects, socials, and contact info in one place.

const ASSET_BASE = import.meta.env.BASE_URL.replace(/\/$/, '');

export const designer = {
  name: 'Mara Voss',
  title: 'Brand & Editorial Designer',
  location: 'Amsterdam, NL',
  availability: 'Available for select briefs from July 2025',
  tagline: 'Design that earns its space on the page.',
  about: [
    'I work at the intersection of brand identity and editorial design — building visual systems that feel considered, not assembled. Eight years of independent practice across print, packaging, and digital.',
    'My process starts with material research and ends with something that holds up under close reading. I\'ve worked with architecture studios, cultural institutions, independent publishers, and ceramicists who care how things look.',
    'When I\'m not in studio, I\'m teaching workshops on grid systems and reading about the history of paper.',
  ],
  email: 'hello@maravoss.com',
  socials: {
    linkedin: '#',
    github: '#',
    instagram: '#',
    dribbble: 'https://dribbble.com/allanninal',
    kofi: '#',
  },
  services: [
    { label: 'Brand Identity Systems', description: 'Wordmarks, logotypes, color systems, typography guidelines, identity manuals.' },
    { label: 'Art Direction', description: 'Visual strategy and creative direction for campaigns, editorials, and brand moments.' },
    { label: 'Editorial Design', description: 'Magazine layouts, annual reports, books, and publication design.' },
    { label: 'Packaging Design', description: 'Structural concepts, print finishes, material specification, production oversight.' },
    { label: 'Type Design Exploration', description: 'Custom letterforms, logotype refinements, bespoke display characters.' },
    { label: 'Creative Consultation', description: 'Brand audits, design system reviews, directional strategy for in-house teams.' },
  ],
  approach: [
    {
      number: '01',
      label: 'Research-Led',
      body: 'Every project begins with material and cultural research. I read the category before I draw a line. This is what separates work that resonates from work that merely looks good.',
    },
    {
      number: '02',
      label: 'Material-Sensitive',
      body: 'Design lives in the world — on paper, on screens, on walls. I consider the substrate before the concept, which means work that holds up in production, not just in Figma.',
    },
    {
      number: '03',
      label: 'Clarity-First',
      body: 'Good design is understandable at a glance and rewarding at close reading. I remove until there\'s nothing left to remove, then stop.',
    },
  ],
};

export type ProjectDiscipline = 'Identity' | 'Print' | 'Packaging' | 'Art Direction' | 'Editorial' | 'Wayfinding';

export type Project = {
  slug: string;
  number: string;
  title: string;
  client: string;
  location: string;
  year: number;
  role: string;
  disciplines: ProjectDiscipline[];
  tagline: string;
  description: string;
  heroImage: {
    src: string;
    alt: string;
    width: number;
    height: number;
  };
  detailImage: {
    src: string;
    alt: string;
    width: number;
    height: number;
  };
  accentColor: string;
};

export const projects: Project[] = [
  {
    slug: 'forma-identity',
    number: '01',
    title: 'Forma',
    client: 'Forma Architecture Studio',
    location: 'Oslo, NO',
    year: 2024,
    role: 'Brand Design, Identity System, Print Collateral',
    disciplines: ['Identity', 'Print'],
    tagline: 'A spatial identity for a studio that thinks in structure.',
    description: 'Complete visual identity for a Scandinavian architecture studio — wordmark, spatial application system, bespoke stationery, and a brand manual that doubles as a design reference.',
    heroImage: {
      src: `${ASSET_BASE}/images/work/forma-identity-hero.jpg`,
      alt: 'Forma Architecture Studio identity — clean geometric building facade in concrete and glass',
      width: 1200,
      height: 800,
    },
    detailImage: {
      src: `${ASSET_BASE}/images/work/forma-identity-detail.jpg`,
      alt: 'Forma brand identity stationery — white letterhead with minimal wordmark',
      width: 800,
      height: 600,
    },
    accentColor: '#2C2C2A',
  },
  {
    slug: 'kuso-packaging',
    number: '02',
    title: 'Kūso',
    client: 'Kūso Ceramics',
    location: 'Kyoto, JP',
    year: 2023,
    role: 'Art Direction, Packaging Design',
    disciplines: ['Packaging', 'Art Direction'],
    tagline: 'Let the object speak. The packaging only introduces.',
    description: 'Packaging system for a Japanese ceramics studio focused on utilitarian stoneware. Material-led — textured kraft paper, blind emboss, single-color letterpress printing. Zero decoration that doesn\'t earn its presence.',
    heroImage: {
      src: `${ASSET_BASE}/images/work/kuso-packaging-hero.jpg`,
      alt: 'Kūso ceramics packaging — kraft paper wrapping around stoneware bowl on concrete surface',
      width: 1200,
      height: 800,
    },
    detailImage: {
      src: `${ASSET_BASE}/images/work/kuso-packaging-detail.jpg`,
      alt: 'Kūso packaging detail — blind emboss Kūso mark on natural kraft paper texture',
      width: 800,
      height: 600,
    },
    accentColor: '#8B7355',
  },
  {
    slug: 'reverie-editorial',
    number: '03',
    title: 'Réverie',
    client: 'Réverie Quarterly',
    location: 'Paris, FR',
    year: 2024,
    role: 'Art Direction, Editorial Design',
    disciplines: ['Editorial', 'Art Direction'],
    tagline: 'Issue 04: Surface. 120 pages that reward slow reading.',
    description: 'Biannual print magazine for a contemporary art publication. Designed on a strict Swiss grid with Cormorant as the text face. Issue 04 theme — "Surface" — became an exercise in negative space, bleed photography, and caption typography as art direction.',
    heroImage: {
      src: `${ASSET_BASE}/images/work/reverie-editorial-hero.jpg`,
      alt: 'Réverie Quarterly magazine open spread showing editorial typography and full-bleed photography',
      width: 1200,
      height: 800,
    },
    detailImage: {
      src: `${ASSET_BASE}/images/work/reverie-editorial-detail.jpg`,
      alt: 'Réverie editorial detail — stack of print magazines showing spine and cover design',
      width: 800,
      height: 600,
    },
    accentColor: '#C45B3A',
  },
  {
    slug: 'atelier-nord-identity',
    number: '04',
    title: 'Atelier Nord',
    client: 'Atelier Nord Gallery',
    location: 'Copenhagen, DK',
    year: 2022,
    role: 'Brand Identity, Wayfinding',
    disciplines: ['Identity', 'Wayfinding'],
    tagline: 'A restrained identity that steps back from the art.',
    description: 'Visual identity and wayfinding system for a contemporary gallery in Copenhagen\'s Nørrebro district. Letterpress business cards, a custom monogram in the tradition of European cultural institutions, and an exhibition signage system that works across three floors.',
    heroImage: {
      src: `${ASSET_BASE}/images/work/atelier-nord-identity-hero.jpg`,
      alt: 'Atelier Nord Gallery interior — white walls with minimal signage and contemporary artwork',
      width: 1200,
      height: 800,
    },
    detailImage: {
      src: `${ASSET_BASE}/images/work/atelier-nord-identity-detail.jpg`,
      alt: 'Atelier Nord letterpress business cards — tactile print on 100% cotton paper',
      width: 800,
      height: 600,
    },
    accentColor: '#1A1410',
  },
];
