/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Light-only. Warm white #FAFAF8. Terracotta #C45B3A. Archivo Black + Cormorant.
  theme: {
    extend: {
      fontFamily: {
        display: ['"Archivo Black"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        sans: ['"Archivo Black"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        serif: ['"Cormorant Variable"', '"Cormorant"', 'ui-serif', 'Georgia', 'Cambria', 'serif'],
      },
      fontSize: {
        'xs':   ['0.75rem',  { lineHeight: '1.6' }],
        'sm':   ['0.875rem', { lineHeight: '1.65' }],
        'base': ['1.0625rem',{ lineHeight: '1.75' }],
        'lg':   ['1.25rem',  { lineHeight: '1.65' }],
        'xl':   ['1.5rem',   { lineHeight: '1.4' }],
        '2xl':  ['2rem',     { lineHeight: '1.2' }],
        '3xl':  ['2.5rem',   { lineHeight: '1.1' }],
        '4xl':  ['3.25rem',  { lineHeight: '1.05' }],
        '5xl':  ['4.5rem',   { lineHeight: '1.0' }],
        '6xl':  ['6rem',     { lineHeight: '0.95' }],
        '7xl':  ['8rem',     { lineHeight: '0.9' }],
      },
      colors: {
        // Warm white base
        cream: {
          DEFAULT: '#FAFAF8',
          50: '#FAFAF8',
          100: '#F5F2ED',
          200: '#F0ECE6',
          300: '#E8E0D6',
        },
        // Terracotta accent
        terracotta: {
          DEFAULT: '#A84A2D',
          50: '#F2E8E4',
          100: '#E8CFC5',
          200: '#D99C8A',
          300: '#CC7055',
          400: '#A84A2D',
          500: '#8B3A21',
          600: '#6E2C16',
        },
        // Warm near-black text
        ink: {
          DEFAULT: '#1A1410',
          muted: '#5C5248',
          light: '#6B6058',
        },
        // Parchment surface
        parchment: '#F0ECE6',
      },
      maxWidth: {
        content: '44rem',
        wide: '72rem',
        full: '100%',
      },
      letterSpacing: {
        widest2: '0.2em',
        widest3: '0.3em',
        tightest: '-0.04em',
        tight2: '-0.03em',
        tight3: '-0.02em',
      },
      aspectRatio: {
        '3/2': '3 / 2',
        '4/3': '4 / 3',
        '16/9': '16 / 9',
      },
    },
  },
};
