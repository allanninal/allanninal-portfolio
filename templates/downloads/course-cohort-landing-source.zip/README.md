# Course / Cohort Landing — Day 18 / 365

A live cohort course landing page template for educators, coaches, and online instructors. The enrollment deadline is the hero — not the company, not the features. Built with Astro + Tailwind.

**Live demo:** https://templates.allanninal.dev/course-cohort-landing/

## What's inside

- **Announcement band** — cohort start date, enrollment deadline, seats remaining
- **Hero** — course title in Spectral display serif, tagline, cohort meta pills (date/seats), countdown timer (JS, deadline from config), dual CTAs, 4-stat strip (cohorts / alumni / seats / rating)
- **Alumni company strip** — text-based logo band showing where graduates work
- **Who this is for / not for** — opinionated two-column qualifier, filters low-intent visitors
- **6-week syllabus** — numbered week cards with live-call badge, description, and key outcomes
- **Course format** — 6-item grid: live calls, recordings, Discord, office hours, capstone, certificate
- **Instructor bio** — credentials, CSS avatar, bio paragraphs, pull quote, social links
- **Testimonials** — 6 cards from prior cohorts with outcome headline, quote, attribution, cohort #
- **Pricing** — 3-tier (early bird / regular / team) with feature lists and refund policy
- **FAQ** — 8 cohort-specific questions using native `<details>`/`<summary>` (no JS needed)
- **Final CTA** — large Spectral heading + enroll button + refund reminder
- **Footer** — course name, instructor attribution, LinkedIn + Ko-fi links, email

## Design decisions

- **Palette:** Deep teal `#0D7377` on warm parchment `#F9F5EE` — editorial-academic register, untaken in prior 17 days
- **Typography:** Spectral (display, transitional serif) + Public Sans (body, USDS grotesque) — both untaken in prior 17 days
- **Countdown timer:** Vanilla JS, deadline from `config.ts`, SSR-safe (renders `--` until JS runs)
- **FAQ:** Native `<details>`/`<summary>` — no JS, fully keyboard-accessible, zero bundle cost
- **Schema.org:** `Course` + `CourseInstance` (with `startDate`, `endDate`, `maximumAttendeeCapacity`, `offers`) + `FAQPage`

## Customization

All editable content lives in `src/data/`:

### `src/data/config.ts`
- `course` — title, tagline, cohort number, dates, prices, seat count, enrollment URLs
- `instructor` — name, bio, role, companies, email, social links, Ko-fi

### `src/data/curriculum.ts`
- `curriculum[]` — 6-week entries: title, subtitle, description, outcomes, callType, isCapstone
- `format[]` — 6 format items: label, detail, icon

### `src/data/testimonials.ts`
- `testimonials[]` — name, role, company, cohort number, quote, outcome headline
- `alumniCompanies[]` — company names for the alumni strip

### `src/data/faq.ts`
- `faq[]` — 8 question/answer pairs

## Environment variables

Copy `.env.example` to `.env` and update:

```
PUBLIC_SITE_URL=https://your-site.com
PUBLIC_BASE_PATH=/
```

## Deploy to GitHub Pages

1. Push this directory to a new GitHub repo.
2. Repo Settings → Pages → Source: GitHub Actions.
3. The included workflow (`.github/workflows/pages.yml` in the root of the monorepo) builds + deploys on every push to `main`.

## Tech stack

- [Astro 4](https://astro.build/) — static site generator
- [Tailwind CSS 3](https://tailwindcss.com/) — utility-first CSS
- [@fontsource/spectral](https://fontsource.org/fonts/spectral) — self-hosted Spectral serif
- [@fontsource/public-sans](https://fontsource.org/fonts/public-sans) — self-hosted Public Sans grotesque
- [@astrojs/sitemap](https://docs.astro.build/en/guides/integrations-guide/sitemap/) — auto-generated sitemap

## Tests

```bash
npm install
npm test            # Playwright — pages + a11y + links + responsive + interactions
npm run test:a11y   # axe-core accessibility audit
npm run test:links  # linkinator
npm run test:lighthouse  # Lighthouse CI (≥ 95 on all four categories)
```

## License

MIT — free for personal and commercial use. Attribution not required but appreciated.
