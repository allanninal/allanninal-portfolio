import { test, expect } from '@playwright/test';

test.describe('Course Cohort Landing — interactions', () => {
  test('mobile nav toggles', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');

    const toggle = page.locator('#nav-toggle');
    const menu   = page.locator('#mobile-menu');

    // Initially hidden
    const isHiddenInitially = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenInitially).toBe(true);

    // Open
    await toggle.click();
    await page.waitForTimeout(100);
    const isHiddenAfterOpen = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterOpen).toBe(false);

    // Close by clicking a link
    await menu.locator('a').first().click();
    const isHiddenAfterClose = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterClose).toBe(true);
  });

  test('CTA buttons are keyboard-navigable', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    const focusedElement = await page.evaluate(() => document.activeElement?.tagName);
    expect(['A', 'BUTTON', 'INPUT']).toContain(focusedElement);
  });

  test('FAQ items expand on click', async ({ page }) => {
    await page.goto('/');
    const faqSection = page.locator('#faq');
    await faqSection.scrollIntoViewIfNeeded();

    const firstDetails = faqSection.locator('details').first();
    const firstSummary = firstDetails.locator('summary');

    // Initially closed
    const isOpen = await firstDetails.evaluate(el => (el as HTMLDetailsElement).open);
    expect(isOpen).toBe(false);

    // Click to open
    await firstSummary.click();
    await page.waitForTimeout(100);
    const isOpenAfterClick = await firstDetails.evaluate(el => (el as HTMLDetailsElement).open);
    expect(isOpenAfterClick).toBe(true);
  });

  test('all 6 week cards appear in syllabus', async ({ page }) => {
    await page.goto('/');
    const syllabus = page.locator('#syllabus');
    await syllabus.scrollIntoViewIfNeeded();
    // Each week has a week badge (numbered div)
    const weekBadges = syllabus.locator('[aria-label^="Week"]');
    await expect(weekBadges).toHaveCount(6);
  });

  test('pricing section shows three tiers', async ({ page }) => {
    await page.goto('/');
    const pricing = page.locator('#pricing');
    await pricing.scrollIntoViewIfNeeded();
    const articles = pricing.locator('article');
    await expect(articles).toHaveCount(3);
  });

  test('countdown timer renders', async ({ page }) => {
    await page.goto('/');
    const cdDays = page.locator('#cd-days');
    await expect(cdDays).toBeAttached();
  });

  test('no JS console errors on load', async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // inject google.com frames/scripts that 403 or emit report-only CSP
    // notices under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const errors: string[] = [];
    page.on('console', msg => {
      if (msg.type() !== 'error') return;
      const text = msg.text();
      const u = msg.location()?.url || '';
      if (THIRD_PARTY.test(text) || THIRD_PARTY.test(u)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(text);
    });
    await page.goto('/');
    // Allow countdown timer and other scripts to run
    await page.waitForTimeout(500);
    expect(errors).toHaveLength(0);
  });
});
