import { test, expect } from '@playwright/test';

test.describe('Course Cohort Landing — internal links', () => {
  test('all internal anchor links resolve', async ({ page }) => {
    await page.goto('/');

    const internalLinks = await page
      .locator('a[href^="#"]')
      .evaluateAll(links =>
        links.map(el => (el as HTMLAnchorElement).getAttribute('href'))
      );

    for (const href of internalLinks) {
      if (!href) continue;
      const id = href.slice(1);
      if (!id) continue;
      const target = page.locator(`#${id}`);
      await expect(target).toBeAttached({
        timeout: 2000,
      });
    }
  });

  test('nav links point to existing sections', async ({ page }) => {
    await page.goto('/');
    const sections = ['#syllabus', '#format', '#instructor', '#testimonials', '#pricing', '#faq'];
    for (const selector of sections) {
      const el = page.locator(selector);
      await expect(el).toBeAttached();
    }
  });
});
