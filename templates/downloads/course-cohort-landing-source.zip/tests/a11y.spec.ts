import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const isPro = process.env.PUBLIC_EDITION === 'pro';

test.describe('Course Cohort Landing — accessibility', () => {
  test('homepage passes axe accessibility audit', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('Pro /full-syllabus/ passes axe accessibility audit', async ({ page }) => {
    test.skip(!isPro, 'The /full-syllabus/ page only exists in the Pro edition');
    await page.goto('/full-syllabus/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('has skip-to-content link', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('a[href="#main"]');
    await expect(skipLink).toBeAttached();
  });

  test('all images have alt text', async ({ page }) => {
    await page.goto('/');
    const imagesWithoutAlt = await page.locator('img:not([alt])').count();
    expect(imagesWithoutAlt).toBe(0);
  });

  test('heading hierarchy is correct — h1 exists', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const count = await h1.count();
    expect(count).toBe(1);
  });

  test('nav has aria-label', async ({ page }) => {
    await page.goto('/');
    const nav = page.locator('nav[aria-label]');
    await expect(nav.first()).toBeVisible();
  });

  test('FAQ uses native disclosure elements', async ({ page }) => {
    await page.goto('/');
    const faqSection = page.locator('#faq');
    await faqSection.scrollIntoViewIfNeeded();
    const details = faqSection.locator('details');
    const count = await details.count();
    expect(count).toBeGreaterThan(0);
  });
});
