import { test, expect } from '@playwright/test';

test.describe('Course Cohort Landing — pages', () => {
  test('homepage loads with correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Systems Thinking/);
  });

  test('homepage has hero section with course title', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const text = await h1.textContent();
    expect(text).toMatch(/Systems Thinking/);
  });

  test('syllabus section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#syllabus');
    await expect(section).toBeVisible();
  });

  test('format section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#format');
    await expect(section).toBeVisible();
  });

  test('instructor section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#instructor');
    await expect(section).toBeVisible();
  });

  test('testimonials section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#testimonials');
    await expect(section).toBeVisible();
  });

  test('pricing section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#pricing');
    await expect(section).toBeVisible();
  });

  test('faq section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#faq');
    await expect(section).toBeVisible();
  });

  test('enroll CTA section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#enroll');
    await expect(section).toBeVisible();
  });

  test('sitemap exists', async ({ page }) => {
    const response = await page.request.get('/sitemap-index.xml');
    expect(response.status()).toBe(200);
  });

  test('footer is present', async ({ page }) => {
    await page.goto('/');
    const footer = page.locator('body > footer');
    await expect(footer).toBeAttached();
  });
});
