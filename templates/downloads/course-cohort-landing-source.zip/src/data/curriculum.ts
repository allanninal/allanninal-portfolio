// Curriculum / syllabus data — edit each week to match your course content.

export type WeekEntry = {
  week: number;
  title: string;
  subtitle: string;
  description: string;
  outcomes: string[];
  callType: 'Live call' | 'Async' | 'Live + async';
  isCapstone?: boolean;
};

export const curriculum: WeekEntry[] = [
  {
    week: 1,
    title: 'The Systems Mindset',
    subtitle: 'Why PMs stay stuck and how to get unstuck',
    description:
      'Most PM firefighting is structural, not personal. In week 1, we map the feedback loops that create reactive teams — and rewire your product instincts to see leverage points instead of symptoms.',
    outcomes: [
      'Build a mental model inventory for your product',
      'Draw a causal loop diagram for your top user problem',
      'Identify the highest-leverage intervention point in your current roadmap',
    ],
    callType: 'Live call',
  },
  {
    week: 2,
    title: 'User Behavior as a System',
    subtitle: 'Why users do what they do — and how to design for it',
    description:
      'Jobs-to-be-done is well-known. The feedback loops underneath it are not. We map user behavior as a dynamic system — so you can predict how product changes will ripple through your metrics, not just your current sprint.',
    outcomes: [
      'Map the behavior system for your core user flow',
      'Identify 3 reinforcing loops and 2 balancing loops in your product',
      'Write a behavior-led problem statement for your next initiative',
    ],
    callType: 'Live call',
  },
  {
    week: 3,
    title: 'Prioritization Without Politics',
    subtitle: 'A decision framework that doesn\'t require consensus',
    description:
      'The reason prioritization is political is that it\'s usually implicit. We make it explicit — building a personal decision rubric that encodes your strategy, surfaces tradeoffs, and lets you say no without a meeting.',
    outcomes: [
      'Build your personal prioritization rubric (impact × confidence × effort)',
      'Write a stakeholder alignment script for your next roadmap review',
      'Apply the rubric to your current backlog and rank the top 10 items',
    ],
    callType: 'Live call',
  },
  {
    week: 4,
    title: 'Metrics That Compound',
    subtitle: 'Design a metrics tree that rewards long-term thinking',
    description:
      'Quarterly OKRs optimize for quarterly outcomes. We build a metrics hierarchy that rewards compounding — so short-term decisions don\'t undermine long-term product health. Includes a live workshop on leading vs. lagging indicators.',
    outcomes: [
      'Build a metrics hierarchy for your product (north star → input → output)',
      'Identify 3 leading indicators that predict your north star metric',
      'Write a metrics brief your team can use in sprint reviews',
    ],
    callType: 'Live call',
  },
  {
    week: 5,
    title: 'Roadmapping as Communication',
    subtitle: 'Your roadmap is a narrative — make it one',
    description:
      'A roadmap that requires explanation has already failed. We rebuild the roadmap as a communication artifact — one that tells the right story to engineering, design, sales, and leadership without four separate decks.',
    outcomes: [
      'Rewrite your current roadmap as a 12-week narrative',
      'Create a one-page roadmap summary for non-PM stakeholders',
      'Develop a roadmap review cadence that surfaces blockers early',
    ],
    callType: 'Live call',
  },
  {
    week: 6,
    title: 'Capstone & Alumni Network',
    subtitle: 'Present your product strategy — then join the alumni cohort',
    description:
      'In the final week, each participant presents their product strategy document: a capstone built over the 6 weeks using every framework from the course. Peer reviews, instructor feedback, and a live graduation call.',
    outcomes: [
      'Complete and present your product strategy document',
      'Receive written instructor feedback on your capstone',
      'Join the alumni network with 6-month Discord access',
    ],
    callType: 'Live call',
    isCapstone: true,
  },
];

export const format = [
  {
    label: '2 live calls/week',
    detail: 'Tuesdays & Thursdays · 12pm PT · 90 min each',
    icon: 'video',
  },
  {
    label: 'All calls recorded',
    detail: 'Available within 24h · Unlimited replays',
    icon: 'play',
  },
  {
    label: 'Private Discord community',
    detail: '6-month access after cohort ends',
    icon: 'discord',
  },
  {
    label: 'Weekly office hours',
    detail: '30-min open slot every Friday · First come, first served',
    icon: 'calendar',
  },
  {
    label: 'Capstone project',
    detail: 'Real product strategy doc — instructor reviewed',
    icon: 'document',
  },
  {
    label: 'Completion certificate',
    detail: 'Issued on graduation · LinkedIn-shareable',
    icon: 'certificate',
  },
];
