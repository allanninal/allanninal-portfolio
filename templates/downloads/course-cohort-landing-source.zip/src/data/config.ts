// ── Course / Cohort Landing — single source of truth ──────────────────────
// Edit this file to personalize the template for your course.

export const course = {
  // Course identity
  title: 'Systems Thinking for\nProduct Managers',
  titleShort: 'Systems Thinking for PMs',
  tagline: 'Stop firefighting. Start building products that compound.',
  description:
    'A live 6-week cohort for senior PMs and product leads who want a repeatable system for prioritization, roadmapping, and metrics — built on first principles, not frameworks du jour.',

  // Cohort details
  cohortNumber: 5,
  cohortSize: 40,
  seatsRemaining: 11,
  cohortStart: '2026-03-10', // ISO 8601
  cohortEnd: '2026-04-21',   // ISO 8601
  enrollmentDeadline: '2026-02-28', // ISO 8601 — countdown target
  earlyBirdDeadline: '2026-02-14',  // ISO 8601

  // Display labels
  startDateDisplay: 'March 10, 2026',
  endDateDisplay: 'April 21, 2026',
  enrollDeadlineDisplay: 'February 28, 2026',
  earlyBirdDeadlineDisplay: 'February 14, 2026',
  duration: '6 weeks',
  format: 'Live + async',

  // Live call schedule
  callSchedule: 'Tuesdays & Thursdays · 12:00 PM PT · 90 min',
  callRecorded: true,
  recordingWindow: '24 hours',

  // Social proof stats (update each cohort)
  alumniCount: 160,
  completedCohorts: 4,
  avgRating: '4.9',
  ratingScale: '5',

  // Pricing (in USD)
  pricing: {
    earlyBird: {
      price: 997,
      label: 'Early Bird',
      note: 'Ends February 14, 2026',
      badge: 'Best value',
    },
    regular: {
      price: 1297,
      label: 'Regular',
      note: 'Closes February 28, 2026',
      badge: null,
    },
    team: {
      price: 2800,
      seats: 3,
      label: 'Team',
      note: '3 seats — save $391',
      badge: null,
    },
  },

  // Enrollment
  enrollUrl: '#enroll', // Replace with actual Stripe / Gumroad URL
  discoveryCallUrl: '#',  // Replace with cal.com or Calendly link

  // Community
  communityPlatform: 'Discord',
  communityAccess: '6 months post-cohort',

  // Capstone & certificate
  hasCapstone: true,
  hasCertificate: true,
  certificateLabel: 'Completion Certificate',

  // Alumni access
  alumniSlackAccess: true,
};

export const instructor = {
  name: 'Allan Ninal',
  pronouns: 'he/him',
  role: 'Senior PM → Product Educator',
  tagline: 'Product leader who has shipped with Notion, Linear, and three YC-backed startups.',
  bio: [
    'Allan spent 8 years as a PM at some of the most product-led companies in tech — Notion, Linear, and two YC-backed startups where he was the first PM hire. In that time, he built systems for prioritization and roadmapping that worked not just when everything was going well, but when the quarter was on fire.',
    'Systems Thinking for PMs grew out of a workshop he ran internally for his team in 2023. After sharing the framework with a few PM friends, he got enough emails to run it as a public cohort. Four cohorts later, 160 alumni work at companies ranging from Figma to pre-seed startups.',
    'He teaches because the conventional PM canon is heavy on frameworks and light on the underlying mental models. His goal is not to give you another 2×2 — it\'s to help you see your product as a system so you never need someone else\'s 2×2 again.',
  ],
  email: 'landix.ninal@gmail.com',
  socials: {
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    github:   'https://github.com/allanninal',
    x:        'https://x.com/allannin',
    bluesky:  'https://bsky.app/profile/allanninal.bsky.social',
  },
  kofi: 'https://ko-fi.com/allanninal',
  // Prior companies for credibility strip
  companies: ['Notion', 'Linear', 'YC W21', 'YC S19'],
};
