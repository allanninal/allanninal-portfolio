// FAQ — cohort-specific questions

export type FaqItem = {
  question: string;
  answer: string;
};

export const faq: FaqItem[] = [
  {
    question: 'How much time should I expect to commit each week?',
    answer:
      'Plan for 4–6 hours per week: two 90-minute live calls (3h), plus 1–2 hours for the weekly assignment and Discord participation. The capstone in Week 6 takes an additional 3–4 hours to prepare. You don\'t need to attend every call live — recordings are available within 24h — but the value is highest when you show up live.',
  },
  {
    question: 'What if I miss a live call?',
    answer:
      'All calls are recorded and posted to the course platform within 24 hours. You can watch at your own pace and submit your weekly assignment asynchronously. Most cohort participants miss 1–2 calls due to scheduling conflicts — that\'s normal and fine. The course is designed to work fully async for people in non-US time zones.',
  },
  {
    question: 'Are the recordings available after the cohort ends?',
    answer:
      'Yes. You\'ll have access to all call recordings for 12 months after the cohort ends. The Discord community stays open for 6 months post-cohort, after which you\'re invited to the ongoing alumni network.',
  },
  {
    question: 'What are the prerequisites?',
    answer:
      'You should have at least 2 years of PM experience and be actively shipping product at a company. This is not a beginner course — it assumes you know what a roadmap is and have felt the pain of the prioritization meeting. If you\'re a new PM, check back in a year. If you\'re an engineering or design leader who works closely with PMs, reach out before enrolling.',
  },
  {
    question: 'What is your refund policy?',
    answer:
      'Full refund within 7 days of the cohort start date if you\'ve attended fewer than 2 calls. After that, no refunds — but you can defer to the next cohort (Cohort 6) at no extra charge. If life genuinely intervenes (illness, layoff, family emergency), reach out directly and we\'ll work something out.',
  },
  {
    question: 'Do you offer scholarships or income-based pricing?',
    answer:
      'We reserve 2 scholarship seats per cohort for PMs at non-profits, government, or in lower-income markets. Email hello@priyaraman.com with a brief note on your situation before the early bird deadline. We don\'t have a formal application — just an honest conversation.',
  },
  {
    question: 'Can my whole team join? Is there a team discount?',
    answer:
      'Yes — the team rate is $2,800 for 3 seats (save $391 vs. three individual early bird seats). Larger teams (4+ seats) should reach out directly for a custom rate. Having 2–3 people from the same team is actually ideal — you can work on the capstone together around a shared product.',
  },
  {
    question: 'How much access do I have to you (Priya) directly?',
    answer:
      'Every live call includes 30 minutes of open Q&A. There\'s also a weekly 30-minute office hours slot every Friday (first come, first served) where you can bring a specific problem. In the Discord, Priya checks in daily Mon–Fri and responds to questions within 24h. The capstone gets written feedback from Priya personally — not a TA.',
  },
];
