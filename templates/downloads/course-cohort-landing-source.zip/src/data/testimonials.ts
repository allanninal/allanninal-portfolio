// Testimonials from prior cohorts

export type Testimonial = {
  name: string;
  role: string;
  company: string;
  cohort: number;
  quote: string;
  outcome?: string; // short outcome headline
  avatar?: string;   // Pro: filename (no ext) in public/images/pro/testimonials/
};

export const testimonials: Testimonial[] = [
  {
    name: 'Maya Patel',
    avatar: 'maya-patel',
    role: 'Senior PM',
    company: 'Figma',
    cohort: 2,
    quote:
      'The systems mindset completely changed how I run planning cycles. I shipped less, but the things I shipped compounded. Our activation metric went from flat to +22% over one quarter — and I can point to exactly which leverage point we moved.',
    outcome: 'Activation +22% in one quarter',
  },
  {
    name: 'Jordan Lee',
    avatar: 'jordan-lee',
    role: 'PM',
    company: 'Stripe',
    cohort: 1,
    quote:
      "Allan's prioritization framework alone was worth the price. I went from spending 40% of my time in stakeholder negotiations to having a shared rubric everyone could reason from. No more endless debate in sprint planning.",
    outcome: '40% less stakeholder negotiation time',
  },
  {
    name: 'Rania Ibrahim',
    avatar: 'rania-ibrahim',
    role: 'Group PM',
    company: 'Shopify',
    cohort: 3,
    quote:
      'I took this during a rough quarter at work. The capstone gave me a framework I used to restructure our entire Q3 strategy. I presented it directly to our VP of Product and got sign-off in the first meeting.',
    outcome: 'VP sign-off in first meeting',
  },
  {
    name: 'Chris Nakamura',
    avatar: 'chris-nakamura',
    role: 'Product Lead',
    company: 'Vercel',
    cohort: 2,
    quote:
      'Six weeks, twelve calls, one capstone. The ROI on this is absurd compared to any PM certification program I\'ve taken. The live format forces you to apply the concepts immediately — not just nod along in a recording.',
    outcome: 'Best PM training investment, period',
  },
  {
    name: 'Priya Sharma',
    avatar: 'priya-sharma',
    role: 'PM → Head of Product',
    company: 'a16z-backed startup',
    cohort: 4,
    quote:
      'I used the capstone document directly in my promotion case. My manager said it was the clearest articulation of product strategy she\'d seen from a PM at my level. Got promoted 3 months after cohort ended.',
    outcome: 'Promoted 3 months post-cohort',
  },
  {
    name: 'Thomas Wittmann',
    avatar: 'thomas-wittmann',
    role: 'Senior PM',
    company: 'Linear',
    cohort: 3,
    quote:
      "The live call format makes it real. Having 39 other PMs ask the hard questions in real time — and seeing Allan think through edge cases on the spot — is better than any podcast, book, or async course I've done.",
    outcome: 'Live format beats async, every time',
  },
];

// Company logos to show in the alumni strip
// (where alumni work — not where they came from)
export const alumniCompanies = [
  { name: 'Figma',    slug: 'figma'    },
  { name: 'Stripe',   slug: 'stripe'   },
  { name: 'Shopify',  slug: 'shopify'  },
  { name: 'Vercel',   slug: 'vercel'   },
  { name: 'Linear',   slug: 'linear'   },
  { name: 'Notion',   slug: 'notion'   },
];
