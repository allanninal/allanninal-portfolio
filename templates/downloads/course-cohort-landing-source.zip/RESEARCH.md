# Day 18 — Course / Cohort Landing: RESEARCH.md

## Differentiation mandate

Day 18 must be visually distinct from all prior 17 templates, with particular attention to the adjacent landing-page family:
- Day 2 saas-landing: light + violet/cyan, bento grid, generic SaaS structure
- Day 7 mobile-app-landing: light + magenta + Manrope, app-download framing
- Day 11 newsletter-landing: cream + oxblood + Lora + Work Sans, editorial
- Day 12 coming-soon: warm white + aubergine + Fraunces, boutique teaser
- Day 13 ai-startup-landing: dark + amber + Bricolage + JetBrains Mono, futurist
- Day 17 writer-author-site: ivory + Prussian blue + Playfair Display + Crimson Pro, literary

## Chosen visual register: Editorial-Academic / Premium Cohort

**Core concept:** Maven × Reforge meets academic warmth. Premium, teacher-led, intellectually serious. NOT a generic SaaS CTA page — every section communicates real learning value.

### Palette

- **Background:** `#F9F5EE` — warm parchment/cream (warmer than Day 9's white, distinct from Day 11's `#FAF7F2` cream and Day 17's `#F7F4EE` ivory)
- **Ink:** `#1C1917` — near-black with warm undertone (stone-950)
- **Accent:** `#0D7377` — deep teal/jade (`--color-accent`) — **untaken**: Day 10 used teal-on-dark (`#0F766E`); this is a slightly deeper/cooler teal `#0D7377` on warm cream background — completely different reading. Day 5 forest green is `#2D6A4F`, different hue family entirely.
- **Accent light:** `#CCF0EE` — pale jade for badges, week-pill backgrounds, highlighted labels
- **Accent dark:** `#094E51` — deep jade for hover states and strong emphasis
- **Secondary text:** `#57534E` — warm stone-600
- **Border/divider:** `#E7E0D5` — warm stone-200 analogue
- **Countdown band:** `#0D7377` background with `#F9F5EE` text — deep jade band across the hero

**Rationale for deep teal on warm cream:** Completely untaken on a light background. Prior teal (Day 10) was teal-on-near-black — opposite register. This color combination reads as "thoughtful teacher" — precise, credible, not cold. Academic journals, Oxford University Press, Harvard Business Review use this editorial teal-on-cream register. Nothing in the prior 17 days looks like it.

### Typography

- **Display headings:** **Spectral** (Google Fonts, `@fontsource/spectral`) — high-contrast transitional serif, excellent at large display sizes. Gives the course name and week headings genuine typographic authority. Untaken in prior 17 days (Day 11 used Lora, Day 17 used Playfair Display, Day 9 used Source Serif 4, Day 15 used Cormorant Garamond, Day 5 used Newsreader, Day 12 used Fraunces). Spectral reads as rigorous and intellectually serious — the voice of a professor who has thought deeply about their subject.
- **Body / UI:** **Public Sans** (Google Fonts, `@fontsource/public-sans`) — a USDS-designed humanist grotesque, crisp and trustworthy. Completely untaken across all 17 prior days. Excellent for form labels, navigation, feature callouts, and the fine print in pricing. Distinct from Inter (used throughout roadmap), Plus Jakarta (Day 14), Manrope (Day 7), Work Sans (Day 11), DM Sans (Day 16).
- **Mono accent (week labels, cohort #):** `font-mono` system stack — used sparingly for week numbers, cohort identifiers ("Cohort 4"), and timestamps. No extra font to load.

**Contrast check (WCAG AA):**
- Accent `#0D7377` on white `#FFFFFF`: 4.56:1 — AA for large text ✓ (meets AA but borderline for body)
- Accent `#0D7377` on cream `#F9F5EE`: ~4.3:1 — use for headings/large text only; for small text use `#094E51` (dark jade) which gives 7.2:1 on cream ✓
- Ink `#1C1917` on cream `#F9F5EE`: 16.8:1 — AAA ✓
- Cream `#F9F5EE` on accent `#0D7377` background: 4.56:1 — AA ✓
- White `#FFFFFF` on dark jade `#094E51`: 8.1:1 — AAA ✓

**Density profile:** Medium-structured. Not as sparse as newsletter-landing. Not as bento-dense as saas-landing. Organized like a course syllabus — clear sections, numbered weeks, badges for outcomes. A buyer reading this should feel they're looking at a proper curriculum, not a sales deck.

## Persona & Course

**Instructor:** Allan Ninal — Senior Product Manager turned product educator. 8 years in PM at Notion, Linear, and a YC-backed startup. Now teaching the system behind his decision-making process.

**Course:** **Systems Thinking for Product Managers**
A live cohort course for PMs who want to stop firefighting and start building products that compound in value. 6 weeks, live calls every Tuesday + Thursday, capped at 40 seats.

**Course facts:**
- Duration: 6 weeks
- Format: Live cohort — 2 live calls/week (Tuesdays 12pm PT + Thursdays 12pm PT), all calls recorded
- Cohort: Cohort 5 (four prior cohorts completed — proof of track record)
- Cohort start: March 10, 2026
- Enrollment deadline: February 28, 2026 (early bird ends February 14)
- Cohort size: 40 seats (scarcity signal)
- Price: $997 early bird / $1,297 regular / $2,800 team (3 seats)
- Community: Private Discord, 6-month access post-cohort
- Capstone: Build a real product strategy document, reviewed by instructor
- Certificate: Completion certificate

**Curriculum (6 weeks):**
1. **Week 1: The Systems Mindset** — Why PM firefighting happens and how systems thinking rewires your product instincts. Key outcomes: mental model audit, causal loop diagrams for your product.
2. **Week 2: User Behavior as a System** — Jobs-to-be-done meets feedback loops. Understanding why users do what they do at a systems level. Key outcomes: behavior map for your core user flow.
3. **Week 3: Prioritization Without Politics** — Build a decision framework that doesn't require you to fight for every feature. Key outcomes: personal prioritization rubric, stakeholder alignment script.
4. **Week 4: Metrics That Compound** — Design a metrics tree that rewards long-term thinking, not quarterly OKR gaming. Key outcomes: metrics hierarchy for your product, leading vs. lagging indicator map.
5. **Week 5: Roadmapping as a Communication Tool** — Your roadmap is a narrative, not a list. How to write one that gets buy-in and stays honest. Key outcomes: 12-week roadmap built during cohort.
6. **Week 6: Capstone & Alumni Network** — Present your product strategy document. Peer feedback, instructor review, graduation. Key outcomes: portfolio-ready capstone, cohort alumni Slack access.

**Testimonials (from Cohorts 1-4):**
1. Maya Patel, Senior PM @ Figma (Cohort 2) — "The systems mindset completely changed how I run planning cycles. I shipped less, but the things I shipped compounded."
2. Jordan Lee, PM @ Stripe (Cohort 1) — "Allan's prioritization framework alone was worth the price. No more endless debate in sprint planning."
3. Rania Ibrahim, Group PM @ Shopify (Cohort 3) — "I took this during a rough quarter at work. The capstone gave me a framework I used to restructure our entire Q3 strategy."
4. Chris Nakamura, Product Lead @ Vercel (Cohort 2) — "Six weeks, twelve calls, one capstone. The ROI on this is absurd compared to any PM certification program."
5. Priya Sharma, PM → Head of Product @ a16z-backed startup (Cohort 4) — "Cohort 4 cohort helped me get promoted. I presented the capstone directly to our board."
6. Thomas Wittmann, Senior PM @ Linear (Cohort 3) — "The live call format makes it real. Having 39 other PMs ask the hard questions is better than any podcast or book."

## Sections architecture

1. **Nav** — Course name (logotype Spectral), anchor links: Syllabus, Format, Instructor, Testimonials, Pricing. "Enroll Now" CTA button (jade/teal).
2. **Hero** — Course title large in Spectral. One-sentence positioning. Cohort 5 badge. Cohort dates + "Enrollment closes Feb 28." Countdown timer (JS, days/hours/min/sec to deadline). Two CTAs: "Enroll in Cohort 5" (primary, jade) + "View Syllabus ↓" (secondary, ghost). Stats strip: "4 cohorts · 160 alumni · 40 seats · Avg. 4.9/5".
3. **Social proof strip** — Company logos strip: Figma, Stripe, Shopify, Vercel, Linear, Notion (where alumni work — not where they came from).
4. **Who this is for / NOT for** — Two-column split. Left: 5 bullets who it's for. Right: 4 bullets who it's NOT for. Opinionated and direct.
5. **Curriculum / Syllabus** — 6 numbered week cards. Each: week number (mono, jade tint badge), week title (Spectral), 2-sentence description, 3 key outcomes (checkmarks). "Live call" or "Async" badge per week.
6. **Format** — What exactly you get: 2 live calls/week (schedule), recordings within 24h, private Discord, weekly office hours slot, capstone project, completion certificate, 6-month alumni access. Icon + label layout.
7. **Instructor bio** — Allan Ninal. Headshot (CSS avatar). Role credentials. Prior companies (Notion, Linear). Why he teaches this. Quote about his teaching philosophy.
8. **Testimonials** — 6 testimonials, 2-column grid on desktop. Name, role, company, cohort number. Short quote (2-3 sentences). 
9. **Pricing** — Early bird card (highlighted, jade border) + Regular card + Team card. Each: price, what's included, enroll CTA. Countdown to early-bird deadline. "Not sure? Book a 15-min call" secondary link.
10. **FAQ** — 8 questions specific to cohort format: time commitment, recording policy, missed sessions, prerequisites, refund policy, scholarship, team pricing, who gets access to instructor.
11. **Final CTA** — Large Spectral heading "Ready to build products that compound?" + "Enroll in Cohort 5 — 40 seats, closes Feb 28" + primary CTA button. Subtext: refund policy reminder.
12. **Footer** — Course name, instructor attribution, social links (LinkedIn, Ko-fi), contact email, copyright.

## Schema.org

- `Course` with:
  - `name`: "Systems Thinking for Product Managers"
  - `description`: course description
  - `provider`: `Person` (Allan Ninal, `url`, `sameAs` LinkedIn)
  - `hasCourseInstance`: `CourseInstance` with `courseMode: "online"`, `startDate`, `endDate`, `maximumAttendeeCapacity: 40`, `instructor` (ref to Person), `offers` (pricing)
  - `educationalLevel`: "Intermediate"
  - `teaches`: ["systems thinking", "product management", "prioritization", "roadmapping", "metrics"]
  - `url`: canonical URL
- `FAQPage` with `mainEntity` array of `Question` + `Answer`

## Technical decisions

- Astro 4 + Tailwind 3 (consistent with roadmap stack)
- `@fontsource/spectral` + `@fontsource/public-sans` (self-hosted for Lighthouse perf)
- Countdown timer: vanilla JS, ISO 8601 deadline string from `config.ts`, SSR-safe (renders "Loading..." in noscript)
- No CMS — all data in `src/data/` TypeScript files (curriculum.ts, testimonials.ts, faq.ts)
- config.ts: cohort number, dates, prices, seat count, enrollment URL — all in one place for easy customization
- OG image: og-image.svg + og-image.png committed to /public/
- Sitemap via @astrojs/sitemap
- Full WCAG AA throughout; all interactive elements keyboard-navigable; FAQ uses `<details>`/`<summary>` for native disclosure

## Differentiation table

| Feature | Day 18 (cohort) | Day 2 (SaaS) | Day 7 (app) | Day 13 (AI startup) |
|---------|----------------|--------------|-------------|---------------------|
| Hero anchor | Cohort dates + countdown | Product demo | App screenshots | Playground embed |
| Primary CTA | "Enroll in Cohort 5" (scarcity) | "Start free trial" | "Download" | "Get API key" |
| Curriculum | 6-week syllabus | None | None | None |
| Who-for / not-for | Yes (self-qualifying) | No | No | No |
| Pricing structure | Cohort + early bird + team | Tier toggle | Free download | API tiers |
| Testimonials | By cohort # + company | Generic | App Store | None |
| Format details | Live calls + async + Discord | Features | Features | How-it-works |
| Instructor | Bio + credentials + story | None | None | None |
| FAQ | Cohort-specific | Generic | Generic | API-specific |
| Schema.org | Course + CourseInstance + FAQPage | SoftwareApp | MobileApp | SoftwareApp |
| Palette | Deep teal on warm cream | Violet/cyan on white | Magenta on white | Amber on near-black |
| Display font | Spectral (transitional serif) | System sans | Manrope | Bricolage Grotesque |
| Body font | Public Sans | Inter | Manrope | Bricolage |

The live-cohort architecture (dates + scarcity + countdown + weekly curriculum + instructor bio + cohort-number testimonials) is a category distinct from every prior landing page in this roadmap.
