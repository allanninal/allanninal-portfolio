/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Core palette — deep teal on warm cream
        cream:      '#F9F5EE',
        ink:        '#1C1917',
        accent:     '#0D7377',
        'accent-light': '#CCF0EE',
        'accent-dark':  '#094E51',
        muted:      '#57534E',
        border:     '#E7E0D5',
        'border-strong': '#C9BFB0',
      },
      fontFamily: {
        display: ['"Spectral"', 'Georgia', '"Times New Roman"', 'serif'],
        body:    ['"Public Sans"', 'system-ui', '-apple-system', 'sans-serif'],
        mono:    ['"Fira Code"', '"Cascadia Code"', 'Consolas', 'monospace'],
      },
      fontSize: {
        'display-xl': ['clamp(2.5rem, 5vw, 4.5rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'display-lg': ['clamp(2rem, 4vw, 3.25rem)', { lineHeight: '1.15', letterSpacing: '-0.015em' }],
        'display-md': ['clamp(1.375rem, 2.5vw, 2rem)', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'body-lg':    ['1.0625rem', { lineHeight: '1.75', letterSpacing: '0' }],
        'body-base':  ['1rem', { lineHeight: '1.7' }],
        'label':      ['0.8125rem', { lineHeight: '1.4', letterSpacing: '0.04em' }],
      },
      maxWidth: {
        content: '1180px',
        prose:   '68ch',
      },
      spacing: {
        section: 'clamp(4rem, 8vw, 7rem)',
      },
    },
  },
  plugins: [],
};
