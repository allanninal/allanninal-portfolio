// Wingfield Build Co. — configuration data
// Day 75 of the 365-template roadmap
//
// Design note: this is the only trade template in the sprint that is not sold to
// a homeowner. The reader is a business owner about to sign a five- or ten-year
// lease, a property manager assembling a bid list, or an architect deciding who
// to hand a drawing set to. Those three convert on a website; homeowners phone
// whoever the neighbour used.
//
// A homeowner's fear is that the job will be bad. A commercial tenant's fear is
// arithmetic: the lease commences, rent starts, and every week the space is dark
// is a week of rent paid on a room that earns nothing. So there is no emergency
// bar and no red — the scaffold's emergency strip carries current crew capacity,
// which is what a bid list actually wants to know.
//
// The hook is `projects`. Every GC on earth says "on time, on budget" with
// nothing behind it. Each card here is a ledger, not a photograph: the permit
// dates, the schedule against the actual, the contract sum against the final,
// and every change order itemised with its dollar figure and its reason.
//
// The rule that makes it credible, and it is a hard rule: at least two of the six
// must be late or over, with the reason stated. A ledger where every job landed
// exactly on the number is an advert with a table in it, and a property manager
// reads it as one in about four seconds. This demo ships one job four days late,
// one twenty-six days late, one that came in UNDER because an alternate was
// declined, and one with no change orders at all — because that happens too, and
// showing it is what makes the other five believable.

export const contractor = {
  name:        'Wingfield Build Co.',
  tagline:     'Light commercial tenant improvement in Richmond, with the dates and the change orders published',
  description: 'Second-generation restaurant, medical, office, retail and studio fit-outs in Richmond, Virginia. 1,000 to 8,000 square feet inside an existing shell. Every project ledger on this site shows the permit dates, the schedule we hit or missed, and every change order we wrote.',
  phone:       '(804) 555-0142',
  phoneHref:   'tel:+18045550142',
  email:       'hello@wingfieldbuild.example',
  address:     '3110 W Moore St',
  city:        'Richmond',
  state:       'VA',
  zip:         '23230',
  license:     'Virginia DPOR Class A Contractor #2705-555-0142, Commercial Improvement (CIC) specialty',
  licenseShort:'Virginia Class A Contractor, CIC specialty',
  licensed:    true,
  insured:     true,
  founded:     2017,
  yearsExperience: 9,
  // Capacity replaces the emergency line. A tenant improvement contractor has no
  // emergency; a bid list has a question, and this is it.
  capacity:     'Taking on fit-outs starting after mid-November',
  capacityNote: 'Two crews. Superintendent on site daily — we do not run four jobs off one truck.',
  bonding:      '$4,000,000 single project, $8,000,000 aggregate',
  liability:    '$2,000,000 per occurrence, $4,000,000 aggregate',
  warrantyMonths: 12,
  crewCount:   2,
  bookUrl:     '#',
  owner: {
    name:     'Delia Wingfield',
    title:    'Owner & Estimator',
    initials: 'DW',
    bio:      "I spent eleven years as director of operations for a four-location restaurant group and ran three build-outs from the tenant's side of the table before I crossed over. All three opened late. On the second one I paid four months of rent on a dark room in Shockoe Bottom while a general contractor told me every Friday that we were two weeks out, and I could not get a straight answer about a single change order until the final invoice. That is the whole reason this website publishes its ledgers. I know exactly what the number and the date are worth to you, because I have been the one paying rent on the room.",
  },
  superintendent: {
    name:     'Marcus Oyelaran',
    title:    'Superintendent',
    initials: 'MO',
    bio:      "Marcus is on site every day a job is open, and he is the person whose phone number you get on day one. Twenty-two years in commercial interiors, the last nine of them in Richmond, which means he has walked most of the inspectors on your job through a project before. He runs the daily log, the inspection calendar and the subcontractor sequence, and he is the one who calls you the afternoon something is found behind a wall — not the following Friday.",
  },
  linkedin:  '#',
  instagram: '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Wingfield Build Co. — Commercial Tenant Improvement, Richmond VA',
  // Under 200 characters. Every page's meta description is asserted in
  // tests/links.spec.ts, on the Pro build as well as the free one — a Pro-only
  // page is invisible to a free-build audit (KNOWN_DEFECTS §5), which is exactly
  // where two over-long descriptions once sat unnoticed.
  description:   'Richmond tenant improvement contractor: restaurant, medical, office, retail and studio fit-outs, 1,000 to 8,000 sf. Six project ledgers with permit dates, schedule variance and every change order.',
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

// ── The ledgers ─────────────────────────────────────────────────────────────
// The hook. Five labelled lines per project, and the change orders itemised.
// The schema.org vocabulary has nothing that models a construction project's
// schedule and cost history, so these stay semantic HTML: an <article> with a
// <dl> per ledger, which is also the correct accessibility shape for a labelled
// spec block and gives screen readers the term/definition pairing for free.
export type ChangeOrder = { id: string; amount: string; reason: string };

export type Project = {
  slug: string;
  title: string;
  district: string;
  use: string;
  space: string;
  permit: string;
  schedule: string;
  /** 'late' | 'early' | 'ontime' — drives the schedule flag, not the styling of a claim. */
  scheduleFlag: 'late' | 'early' | 'ontime';
  scheduleFlagText: string;
  money: string;
  moneyFlag: 'over' | 'under' | 'even';
  moneyFlagText: string;
  changeOrders: ChangeOrder[];
  changeOrderNote?: string;
};

export const projects: Project[] = [
  {
    slug:     'scotts-addition-restaurant',
    title:    'Second-generation restaurant in a 1948 masonry shell',
    district: "Scott's Addition",
    use:      'Restaurant',
    space:    "2,400 sf second-generation restaurant, 1948 masonry shell, Scott's Addition. Previous tenant was a sandwich counter; the new operator wanted a full hot line and a 62-seat dining room.",
    permit:   'Submitted 3 Mar, issued 2 Apr — 30 days. One revision cycle: the grease interceptor was undersized on the first submission.',
    schedule: '11 Apr to 27 Jun. 77 calendar days against a 73-day schedule.',
    scheduleFlag: 'late',
    scheduleFlagText: 'Four days late',
    money:    '$412,000 contract, $431,600 final.',
    moneyFlag: 'over',
    moneyFlagText: '+4.8%',
    changeOrders: [
      { id: 'CO-1', amount: '+$4,200',  reason: 'Health district required a hand sink within 24 feet of the prep line that was not on the permit set. Jurisdictional, and we should have caught it at plan review.' },
      { id: 'CO-2', amount: '+$9,400',  reason: 'The 2" waste line under the slab was cast iron, not the PVC shown on the as-builts, and was scaled shut. Found on demolition day three; 38 feet of slab opened and re-poured.' },
      { id: 'CO-3', amount: '+$6,000',  reason: 'Owner added a second walk-in cooler after the equipment schedule was signed. Owner-directed, priced before it was ordered.' },
    ],
  },
  {
    slug:     'manchester-dental',
    title:    'Dental suite where the owner declined the second sterilisation room',
    district: 'Manchester',
    use:      'Medical / dental',
    space:    '3,100 sf dental suite, 1961 two-storey office building, Manchester. Six operatories, imaging room, lab and a sterilisation core.',
    permit:   'Submitted 14 Jan, issued 4 Feb — 21 days. No revision cycles; the drawing set was complete when it went in, which is the only reason a 21-day review is possible.',
    schedule: '12 Feb to 22 May. 100 calendar days against a 105-day schedule.',
    scheduleFlag: 'early',
    scheduleFlagText: 'Five days early',
    money:    '$598,000 contract, $574,300 final.',
    moneyFlag: 'under',
    moneyFlagText: '−4.0%',
    changeOrders: [
      { id: 'CO-1', amount: '−$31,000', reason: 'Credit. The owner declined the alternate for the second sterilisation room once the operatory count settled at six. The shell was left with capped rough-ins so it can be built later without opening walls.' },
      { id: 'CO-2', amount: '+$7,300',  reason: 'Vacuum and compressor lines needed a dedicated equipment closet after the manufacturer’s rough-in drawings arrived two weeks behind the equipment order.' },
    ],
    changeOrderNote: 'This is the one that comes in under, and it is here because it happens. An alternate is a price you carry and may not spend.',
  },
  {
    slug:     'church-hill-bakery',
    title:    'A café and bakery with no change orders at all',
    district: 'Church Hill',
    use:      'Café / bakery',
    space:    '1,150 sf café and retail bakery, 1912 storefront, Church Hill. Deck oven, retail case and 14 seats.',
    permit:   'Submitted 8 Aug, issued 25 Aug — 17 days. No revision cycles; the health-district plan review ran concurrently rather than after.',
    schedule: '2 Sep to 31 Oct. 59 calendar days against a 60-day schedule.',
    scheduleFlag: 'early',
    scheduleFlagText: 'One day early',
    money:    '$268,000 contract, $268,000 final.',
    moneyFlag: 'even',
    moneyFlagText: 'No change',
    changeOrders: [],
    changeOrderNote: 'None. That is uncommon enough to be worth explaining rather than boasting about: the shell had been a coffee shop nine months earlier, the as-builts were the previous contractor’s and they were accurate, and nothing under that slab was a surprise. Most jobs do not get this.',
  },
  {
    slug:     'west-broad-office',
    title:    'The one that ran twenty-six days late, and why',
    district: 'West Broad Street corridor',
    use:      'Professional office',
    space:    '6,800 sf professional office, 1974 concrete-frame building, West Broad Street corridor. Open plan, twelve private offices, a training room and a server room.',
    permit:   'Submitted 6 May, issued 30 Jun — 55 days. Two revision cycles: the occupancy classification moved from B to a mixed B / A-3 when the training-room seat count went over 49, which triggered a second egress review.',
    schedule: '14 Jul to 19 Dec. 158 calendar days against a 132-day schedule.',
    scheduleFlag: 'late',
    scheduleFlagText: 'Twenty-six days late — twenty-two of them waiting on a switchgear section',
    money:    '$1,240,000 contract, $1,297,400 final.',
    moneyFlag: 'over',
    moneyFlagText: '+4.6%',
    changeOrders: [
      { id: 'CO-1', amount: '+$18,900', reason: 'Rated corridor, second egress signage and emergency lighting package after the occupancy classification changed. Jurisdictional, and it followed directly from a decision the tenant made about seat count.' },
      { id: 'CO-2', amount: '+$26,500', reason: 'The existing 800A service had 90 spare amps, not the 240 the as-builts implied. New distribution panel and feeder. This is the single most common expensive surprise in a fit-out and it is the first item on our pre-lease walk for exactly this reason.' },
      { id: 'CO-3', amount: '+$12,000', reason: 'Landlord required all core drilling to be done after hours in an occupied building. Owner-directed by way of the lease, and it is the kind of thing a work letter should have said.' },
    ],
    changeOrderNote: 'The twenty-two days were a switchgear section quoted at 14 weeks when we ordered and delivered at 22. We do not hard-code lead times on this website for exactly that reason.',
  },
  {
    slug:     'carytown-showroom',
    title:    'Retail showroom with 2¼ inches of threshold in the way',
    district: 'Carytown',
    use:      'Retail / showroom',
    space:    '1,900 sf retail showroom, 1926 masonry storefront, Carytown. Sales floor, fitting rooms, stockroom and a small office.',
    permit:   'Submitted 19 Sep, issued 10 Oct — 21 days. One revision cycle: the accessible route at the recessed entry.',
    schedule: '20 Oct to 16 Dec. 57 calendar days against a 56-day schedule.',
    scheduleFlag: 'late',
    scheduleFlagText: 'One day late',
    money:    '$214,000 contract, $221,700 final.',
    moneyFlag: 'over',
    moneyFlagText: '+3.6%',
    changeOrders: [
      { id: 'CO-1', amount: '+$5,200', reason: 'The recessed entry threshold sat 2¼" above the sidewalk. Ramped landing and a new door sill to get an accessible route into the space. Existing condition, and visible from the street had anyone measured it.' },
      { id: 'CO-2', amount: '+$2,500', reason: 'Asbestos survey found mastic under the 9" floor tile in the back-of-house. 180 sf abated by a licensed contractor before demolition could continue. A survey is required before demolition in most commercial buildings; the abatement is what you cannot price until it comes back.' },
    ],
  },
  {
    slug:     'scotts-addition-studio',
    title:    'A fitness studio the roof would not carry',
    district: "Scott's Addition",
    use:      'Fitness / studio',
    space:    "4,600 sf fitness studio, 1951 warehouse shell, Scott's Addition. Open floor, two class studios, showers and a mezzanine office.",
    permit:   'Submitted 2 Feb, issued 16 Mar — 42 days. One revision cycle: structural calculations for the mezzanine and the roof-mounted unit.',
    schedule: '24 Mar to 29 Jun. 97 calendar days against a 95-day schedule.',
    scheduleFlag: 'late',
    scheduleFlagText: 'Two days late',
    money:    '$736,000 contract, $758,900 final.',
    moneyFlag: 'over',
    moneyFlagText: '+3.1%',
    changeOrders: [
      { id: 'CO-1', amount: '+$14,600', reason: 'The roof joists would not carry the 15-ton rooftop unit the design assumed. Supplemental steel over four bays, engineered and stamped. Existing condition; the original 1951 drawings were on file and were wrong.' },
      { id: 'CO-2', amount: '+$8,300',  reason: 'Gas meter was rated 400 MBH and the makeup-air unit plus the water heaters needed 620. Utility coordination and a new meter set. Existing condition, and one a tenant can check before signing.' },
    ],
  },
];

// ── What we build, and what it runs per square foot ─────────────────────────
// A $/sf range is normal, expected and non-committal in commercial work in a way
// it never is in residential, so there is no reason to withhold it. It also
// disqualifies the tenant with a $60/sf budget and a restaurant, which saves
// everyone a site visit.
export type SpaceType = {
  slug: string;
  name: string;
  range: string;
  basis: string;
  duration: string;
  desc: string;
  movers: string[];
};

export const spaceTypes: SpaceType[] = [
  {
    slug:  'restaurant',
    name:  'Restaurant and café',
    range: '$120 – $260 /sf',
    basis: 'construction cost, excluding kitchen equipment and FF&E',
    duration: '10 – 16 weeks on site',
    desc:  'Second-generation shells with a hood, a grease interceptor and a health-district plan review. The single most expensive square foot in light commercial, and the one where the existing shell decides most of the number.',
    movers: [
      'Whether the shell was previously a food establishment — a second-generation space with a usable hood and interceptor can be half the cost of a cold shell',
      'Hood length, makeup air and whether the gas meter carries the equipment schedule',
      'Grease interceptor sizing, which the locality sets against your seat count',
      'Any change of occupancy classification, which brings egress and sprinkler work with it',
    ],
  },
  {
    slug:  'medical',
    name:  'Medical and dental suites',
    range: '$150 – $300 /sf',
    basis: 'construction cost, excluding chairs, imaging and casework packages',
    duration: '12 – 20 weeks on site',
    desc:  'Operatories, imaging, lab and sterilisation cores. Heavy on mechanical, medical gas, plumbing and lead shielding, and heavy on manufacturer rough-in drawings that arrive when they arrive.',
    movers: [
      'Operatory count, and whether the plumbing and vacuum runs are in a slab or a ceiling',
      'Imaging: shielding, and the structural check for anything that weighs',
      'Separate HVAC zoning and air changes for the sterilisation core',
      'Equipment rough-in drawings, which are on the manufacturer’s schedule and not ours',
    ],
  },
  {
    slug:  'office',
    name:  'Professional office',
    range: '$65 – $140 /sf',
    basis: 'construction cost, excluding furniture and AV',
    duration: '8 – 16 weeks on site',
    desc:  'Open plan, private offices, conference and a server room. The most predictable fit-out type there is, right up until an assembly-occupancy training room or a data room with its own cooling shows up in the programme.',
    movers: [
      'Private office count — every wall is a wall, a door, a light and a sprinkler head',
      'Whether the existing ceiling grid, lighting and sprinklers can stay or come out',
      'Any room over 49 occupants, which changes the occupancy classification and the egress',
      'Server room cooling, power and the generator or UPS that usually follows it',
    ],
  },
  {
    slug:  'retail',
    name:  'Retail and showroom',
    range: '$60 – $130 /sf',
    basis: 'construction cost, excluding fixtures and millwork packages',
    duration: '6 – 10 weeks on site',
    desc:  'Sales floor, stockroom, fitting rooms and an accessible entry. The fastest fit-out type and the one where the storefront and the accessible route cause more trouble than everything behind them.',
    movers: [
      'Storefront glazing — custom sections are a long-lead item and quietly set the schedule',
      'The accessible route from the public way, especially at a recessed or stepped entry',
      'Whether the landlord’s work letter delivers a finished ceiling and lighting',
      'Restroom count and fixture count for the proposed occupant load',
    ],
  },
  {
    slug:  'fitness',
    name:  'Fitness, studio and gym',
    range: '$70 – $160 /sf',
    basis: 'construction cost, excluding equipment',
    duration: '8 – 14 weeks on site',
    desc:  'Open floor, class studios, showers and often a mezzanine. Structure, ventilation and sound isolation do the work here — the finishes are usually the cheapest part of the job.',
    movers: [
      'Roof structure, if the ventilation load wants another rooftop unit',
      'Shower and locker counts, which is drainage in or under a slab',
      'Sound isolation to neighbouring tenants, which the lease often makes your problem',
      'Any mezzanine, which is a structural permit and an egress question',
    ],
  },
  {
    slug:  'conversion',
    name:  'Warehouse-to-something conversion',
    range: '$90 – $220 /sf',
    basis: 'construction cost, excluding equipment and FF&E',
    duration: '12 – 24 weeks on site',
    desc:  'An industrial or warehouse shell becoming a restaurant, brewery, gym or office. This is the Scott’s Addition and Manchester story, and it is the most rewarding and least predictable work we do.',
    movers: [
      'Change of occupancy classification under the Virginia Uniform Statewide Building Code, which is the most expensive four words in a lease negotiation',
      'Electrical service, gas capacity and sanitary — an industrial shell rarely has the right ones',
      'Insulation, glazing and whether the envelope can meet the energy code for the new use',
      'Anything pre-1980: an asbestos survey before demolition, and lead in the paint on the steel',
    ],
  },
];

// ── Before you sign the lease ────────────────────────────────────────────────
// The moment a GC is most useful to a tenant is BEFORE the lease is signed, and
// it is the moment no GC's website addresses.
export const preLease = {
  eyebrow: 'Free, And Before You Are Committed',
  title:   'Before you sign the lease.',
  lede:    'We will walk a shell with you for an hour, for nothing, before there is a deal on the table. Not as a favour — a tenant who signs a lease on a space that cannot carry their equipment becomes a bad job, and a bad job is worse for us than no job.',
  items: [
    { label: 'Electrical service',   body: 'What size the service is, and how many spare amps the panel actually has. The difference between a spare breaker and a new service is the largest single surprise in a fit-out and it is knowable in ten minutes.' },
    { label: 'Gas capacity',         body: 'What the meter is rated in MBH against the BTU load of the equipment you intend to buy. A utility meter upgrade is weeks, not days.' },
    { label: 'Waste and grease',     body: 'Where the sanitary line runs, what size it is, and whether the run to the main is under a slab you would have to open. Whether there is an interceptor, and whether it is sized for your seat count.' },
    { label: 'Restrooms and route',  body: 'Fixture counts and the accessible path of travel for the occupant load you are proposing, not the one the previous tenant had.' },
    { label: 'Roof and structure',   body: 'Whether the roof will carry another unit, and what the landlord’s rules are about penetrating it. Both answers cost money when they are found late.' },
    { label: 'Occupancy class',      body: 'What the space is classified as now and what your use would make it. A change of use under the Virginia Uniform Statewide Building Code brings egress, sprinklers and accessibility with it.' },
  ],
  closer: 'You get the notes whether or not you hire us, and they are written so another contractor can price from them. If the answer is that this shell is wrong for you, that is the most valuable hour either of us will spend.',
};

// ── How the number is built ──────────────────────────────────────────────────
// The section must genuinely concede. Three legitimate causes for a change order
// and one illegitimate one. Naming the fourth is the whole point: a section that
// lists only the three reasons it is never the contractor's fault is an advert
// and the reader knows.
export type NumberPart = { term: string; lede: string; body: string };

export const numberParts: NumberPart[] = [
  {
    term: 'Allowance',
    lede: 'A number we carry for something not yet chosen.',
    body: 'Light fixtures, flooring, plumbing trim, signage. It is a placeholder with a real dollar figure attached, and when you pick the actual product the contract adjusts up or down by the difference. An allowance set too low to make a bid look competitive is the oldest trick in this trade; ours are set at what the thing actually costs and we will show you the three products the number was built from.',
  },
  {
    term: 'Contingency',
    lede: 'Money set aside for what is behind the plaster.',
    body: 'Three to eight per cent depending on the age of the shell and the quality of the as-builts, and it is yours, not ours. It is spent only against a written, priced item, and whatever is left at the end comes off the final application for payment. A contractor who will not tell you what the contingency was spent on has told you something.',
  },
  {
    term: 'Alternate',
    lede: 'A price you carry and may decide not to spend.',
    body: 'A second sterilisation room, an upgraded storefront, a mezzanine. It is priced with the base bid so the decision can be made on a number rather than a guess, and declining one is not a change order in the bad sense — it is the system working. One of the six ledgers above came in four per cent under budget for exactly this reason.',
  },
  {
    term: 'Change order',
    lede: 'A written, priced, signed change to the contract.',
    body: 'Never verbal, never retroactive, and never a line on the final invoice you are seeing for the first time. Every one of ours is issued before the work happens, with the scope, the dollar figure and the schedule impact in days on the same piece of paper. Every change order we have written on the six jobs above is published on this page.',
  },
];

export const changeOrderCauses = [
  {
    kind:  'legitimate' as const,
    title: 'Owner-directed change',
    body:  'You changed your mind, or your business changed. A second walk-in, a different equipment package, a wall moved after you stood in the space. This is the cleanest kind and it should be priced before it is built, not after.',
  },
  {
    kind:  'legitimate' as const,
    title: 'Unforeseen existing condition',
    body:  'The waste line under the slab is cast iron and scaled shut. The service has 90 spare amps and not 240. The roof will not carry the unit. Nobody could see it through a floor, and this is precisely what the contingency exists for.',
  },
  {
    kind:  'legitimate' as const,
    title: 'Jurisdictional requirement',
    body:  'A plan reviewer or an inspector requires something the permit set did not show — a hand sink, a rated corridor, an additional egress sign. Sometimes it is a genuine interpretation and sometimes it is something the drawings should have caught, and we will tell you which.',
  },
  {
    kind:  'illegitimate' as const,
    title: 'Scope that was always going to be needed and was left out to win the bid',
    body:  'This is the industry’s worst habit and it is why you assume the worst about change orders. A contractor bids low, leaves out work everybody knew was coming, and recovers it once the walls are open and you cannot go anywhere else. There is no honest version of it. If you get a change order from us for something that was obviously in the drawings you gave us, it is our error and we eat it — and that sentence is in our contract, not just on this page.',
  },
];

export const numberFixedNote =
  'The contract sum stops moving when the permit set is complete, the equipment schedule is signed and the subcontractor bids are in — not at the letter of intent, and not at the first budget. Before that point you have a budget with a stated accuracy band. After it, the only things that move the number are the four above, each in writing before the work happens.';

// ── What actually blows a schedule ───────────────────────────────────────────
// Long-lead items are FIELDS, not claims. The template ships the row and asks the
// operator to put today's number in it. A stale lead time on a live site is worse
// than none, so no week count is hard-coded here.
export type ScheduleRisk = {
  title: string;
  typical: string;
  weDo: string;
};

export const scheduleRisks: ScheduleRisk[] = [
  {
    title:   'Permit review cycles',
    typical: 'Two to seven weeks for a commercial interior in Richmond, and each revision cycle restarts the clock.',
    weDo:    'The set goes in complete. Most of the delay in a permit review is a second and third submission, and the second submission is almost always caused by something the first one left off. We also take the pre-application meeting, which is free and which almost nobody takes.',
  },
  {
    title:   'Long-lead equipment',
    typical: 'Switchgear, rooftop units, walk-in boxes and custom storefront glazing. Lead times move constantly and a stale number on a website is worse than no number.',
    weDo:    'We quote today’s lead time in writing at bid, re-confirm it at award, and place the order the day the contract is signed rather than when the trade is due on site. Twenty-two of the twenty-six late days on the West Broad job were a switchgear section that went from 14 weeks to 22 after we ordered.',
  },
  {
    title:   'Landlord approvals',
    typical: 'Plan approval, insurance certificates, roof penetration consent, after-hours rules and contractor access. Any of them can sit for two weeks with nobody chasing.',
    weDo:    'The landlord’s requirements go on the schedule as line items with owners and dates, the same as an inspection. We ask for the work letter before we bid, because half of these are already answered in it.',
  },
  {
    title:   'Health-district plan review',
    typical: 'For any food establishment, a separate review from the building permit, on its own timeline.',
    weDo:    'It goes in concurrently with the building permit rather than after it. On the Church Hill café that is the difference between a 17-day permit and a six-week one.',
  },
  {
    title:   'Change of occupancy classification',
    typical: 'The worst case on this list. A change of use under the Virginia Uniform Statewide Building Code can bring egress, sprinklers, accessibility upgrades and a structural review with it.',
    weDo:    'We check the existing and proposed classification on the pre-lease walk, before there is a lease to be stuck with. It is the single highest-value thing on that hour.',
  },
  {
    title:   'Utility coordination',
    typical: 'A new gas meter set, a service upgrade or a transformer is on the utility’s calendar, not on yours and not on ours.',
    weDo:    'Applications go in the week the permit is issued. We tell you the utility’s current turnaround at bid and we tell you again when it changes, which it does.',
  },
];

export const leadTimeNote =
  'Ask us for today’s lead times on switchgear, rooftop units, walk-in boxes and storefront glazing and we will send them the same day, dated. We deliberately do not publish week counts on this page: a lead time printed on a website in March and read in September is not information, it is a liability.';

// ── Who is on your job ───────────────────────────────────────────────────────
export const selfPerformed = [
  'Demolition and site protection',
  'Rough and finish carpentry',
  'Doors, frames and hardware',
  'Specialties, blocking and installation',
  'Daily clean and final clean coordination',
];

export const subcontracted = [
  'Mechanical, electrical and plumbing',
  'Fire protection and fire alarm',
  'Drywall, framing and acoustical ceilings',
  'Flooring, tile and painting',
  'Structural steel and welding',
  'Millwork and casework',
  'Abatement, by licensed contractors only',
];

export const teamNote =
  'Six to twelve subcontractors on a typical fit-out, and we carry the schedule, the permit and the payment applications for all of them. You have one contract and one phone number. On a Saturday that number is Marcus’s, and it is the same number you were given on day one — not an answering service and not a dispatcher.';

// ── Jurisdictions and service area ───────────────────────────────────────────
// In commercial work, "we know this building department" is worth real money and
// real weeks, and it is a concrete, checkable claim. Almost nobody lists them.
export const jurisdictions = [
  {
    zone:   'City of Richmond',
    detail: 'Department of Planning and Development Review',
    areas:  ["Scott's Addition", 'Manchester', 'Church Hill', 'Carytown', 'The Fan', 'Shockoe Bottom'],
    note:   'Where most of our work is. Commercial permits and the health-district review for food establishments.',
  },
  {
    zone:   'Henrico County',
    detail: 'Building Construction and Inspections',
    areas:  ['Innsbrook', 'Short Pump', 'Glen Allen', 'Lakeside', 'Sandston', 'Varina'],
    note:   'Office and medical, mostly. Different submission portal and a different inspection cadence to the city.',
  },
  {
    zone:   'Chesterfield County',
    detail: 'Building Inspection',
    areas:  ['Midlothian', 'Bon Air', 'Chester', 'Woodlake', 'Brandermill', 'Hull Street corridor'],
    note:   'Retail and restaurant in the western suburbs. Plan review turnaround here is usually the fastest of the four.',
  },
  {
    zone:   'Hanover County',
    detail: 'Building Inspections',
    areas:  ['Mechanicsville', 'Ashland', 'Atlee', 'Rockville', 'Beaverdam', 'Hanover Courthouse'],
    note:   'The edge of the map. We take work here; we do not pretend to know it as well as the city.',
  },
];

export const areaNote =
  'Richmond, Henrico, Chesterfield and Hanover, and that is the honest edge. Petersburg, Williamsburg and Charlottesville are all inside two hours and we still say no to them, because a superintendent who is on site daily cannot be on site daily ninety minutes away, and daily supervision is most of what you are buying. If you are outside the four, tell us anyway and we will give you a name.';

// ── What you can check ───────────────────────────────────────────────────────
// No awards, no "500+ projects", no certifications the business does not hold.
export const credentials = [
  {
    title:     'Class A licence, with the commercial specialty',
    stat:      'Class A',
    statLabel: 'DPOR, CIC specialty',
    desc:      'Virginia issues contractor licences by contract value — Class C, B and A — with specialty designations on top. Ours is a Class A with the Commercial Improvement (CIC) specialty, which is the one that actually covers this work. The number is on every proposal and it is checkable on the DPOR licence lookup in about thirty seconds.',
  },
  {
    title:     'Bonding capacity, stated as a number',
    stat:      '$4M / $8M',
    statLabel: 'single project / aggregate',
    desc:      'Payment and performance bonds available to four million on a single project and eight million aggregate. If your landlord or your lender requires a bond, ask for the number rather than the word "bondable", because the word means nothing.',
  },
  {
    title:     'Insurance limits, stated as numbers',
    stat:      '$2M / $4M',
    statLabel: 'per occurrence / aggregate',
    desc:      'General liability at two million per occurrence and four million aggregate, plus workers’ compensation, auto and an umbrella. Certificates naming your landlord and your lender as additional insureds are issued before we mobilise, not after somebody chases them.',
  },
  {
    title:     'Twelve months on the work, in writing',
    stat:      '12 months',
    statLabel: 'from certificate of occupancy',
    desc:      'One year on workmanship from the date of the certificate of occupancy, with manufacturer warranties on equipment assigned to you and registered in your name at closeout. The closeout package includes O&M manuals, as-builts marked with what we actually found, and every warranty document in one binder.',
  },
];

// ── References ───────────────────────────────────────────────────────────────
// Three roles, not one, because a bid list is assembled by all three. No star
// ratings and no aggregateRating: the reviews are fictional, and a star rating
// with nothing behind it is what search engines penalise.
export type Reference = { name: string; role: 'Tenant' | 'Architect' | 'Property manager'; detail: string; quote: string };

export const references: Reference[] = [
  {
    name:   'Anneke Ruzicka',
    role:   'Tenant',
    detail: "Owner, 62-seat restaurant · Scott's Addition",
    quote:  'We opened four days after the date on the contract. I know that because Delia told me on week nine that we were going to be four days late and why, and then we were four days late. Nobody in this industry had ever given me a number that turned out to be the number.',
  },
  {
    name:   'Gilbert Nwachukwu, AIA',
    role:   'Architect',
    detail: 'Principal, six-person practice · Richmond',
    quote:  'They ask questions during bid that most contractors ask during construction, which is when the answer is expensive. On the Manchester job they caught a conflict between my ceiling and the manufacturer’s vacuum routing before anyone had ordered anything.',
  },
  {
    name:   'Theresa Baldacci',
    role:   'Property manager',
    detail: 'Manages 340,000 sf across four buildings · Henrico',
    quote:  'Certificates of insurance correct the first time, a written after-hours plan, and I have never had a tenant complaint about their crew in an occupied building. That is the entire list of things I care about and they are three for three.',
  },
  {
    name:   'Sandeep Varrier, DDS',
    role:   'Tenant',
    detail: 'Six-operatory dental practice · Manchester',
    quote:  'They talked me out of the second sterilisation room and the job came in under budget. The rough-ins are capped in the wall so I can build it in three years without opening anything. I did not know a contractor was allowed to do that.',
  },
  {
    name:   'Marguerite Ollivander, AIA',
    role:   'Architect',
    detail: 'Interiors practice · The Fan',
    quote:  'The change orders come with the reason written in a sentence a client can read, which means I am not the one translating. On the West Broad job the switchgear delay was on the schedule I received the week it happened, not the week before turnover.',
  },
  {
    name:   'Curtis Ashby-Pell',
    role:   'Property manager',
    detail: 'Landlord representative, two Manchester buildings · Richmond',
    quote:  'They asked for the work letter before they bid, which sounds obvious and almost never happens. It meant the TI allowance and the delivery condition were settled before the tenant signed instead of argued about in month three.',
  },
];

// ── FAQ ──────────────────────────────────────────────────────────────────────
export const faqs = [
  {
    q: 'What are your bonding and insurance limits?',
    a: 'Payment and performance bonds to $4,000,000 on a single project and $8,000,000 aggregate. General liability at $2,000,000 per occurrence and $4,000,000 aggregate, plus workers’ compensation, commercial auto and an umbrella policy. Certificates naming your landlord and your lender as additional insureds are issued before we mobilise. We give you the numbers rather than the word "bondable", because the word costs nothing to say.',
  },
  {
    q: 'How does retainage work on your contracts?',
    a: 'Five per cent withheld from each application for payment, released at substantial completion less twice the value of the punch list, with the balance released when the punch list is signed off. We hold the same five per cent from our subcontractors and release it on the same terms, which is not universal and is worth asking any contractor about — a GC who holds ten from subs and bills you five is financing their business with your job.',
  },
  {
    q: 'Do you issue lien waivers?',
    a: 'Conditional waivers with each application for payment and unconditional waivers when that payment clears, from us and from every subcontractor and material supplier over a threshold you set. You should never make a final payment without unconditional waivers in hand from everyone who could file. If a contractor treats that request as an insult, that is the answer to a different question.',
  },
  {
    q: 'What do your pay applications look like?',
    a: 'AIA G702 and G703, monthly, against a schedule of values you approve before the first one is issued. The schedule of values is broken down finely enough to be meaningful — not five lines with "General Conditions" at forty per cent of the job. Your lender or your landlord will ask for exactly this format if a TI allowance is being drawn against, and it is the format the industry expects.',
  },
  {
    q: 'When does the contract sum stop moving?',
    a: 'When the permit set is complete, the equipment schedule is signed and the subcontractor bids are in. Before that you have a budget with an accuracy band we state on the page — typically plus or minus fifteen per cent at concept and plus or minus five at design development. After it, the only things that move the number are an owner-directed change, an unforeseen existing condition, or a jurisdictional requirement, each priced and signed before the work happens.',
  },
  {
    q: 'Can you work in an occupied building?',
    a: 'Yes, and most of our jobs are. That means negotiated work hours, dust and noise partitions, protected paths of travel for other tenants, elevator protection, and coordination with the property manager on deliveries and parking. It also means some work moves to nights and weekends at a premium, which we price at bid rather than discovering later. On one of the ledgers above, after-hours core drilling was a $12,000 change order because the lease required it and nobody read the lease.',
  },
  {
    q: 'What about after-hours and noise restrictions?',
    a: 'They come from three places and they conflict about half the time: the local noise ordinance, the landlord’s building rules, and your own lease. We ask for all three before bidding and put the resulting work window in the schedule. If your landlord’s rules say no core drilling during business hours and your schedule assumes daytime work, that is a real cost and you should know it before you sign, not in week four.',
  },
  {
    q: 'Do you do ground-up construction or residential work?',
    a: 'Neither. Light commercial tenant improvement inside an existing shell, 1,000 to 8,000 square feet. No ground-up, no houses, no whole-building renovation. Doing one thing is why we can tell you on the walk-through whether your shell is right, and it is why a superintendent is on your site every day instead of on four sites a week.',
  },
  {
    q: 'What happens if you find asbestos?',
    a: 'Work stops in that area, a licensed abatement contractor handles it, and it comes to you as a priced change order against the contingency. A survey before demolition is required for most commercial renovation under federal NESHAP rules, so it should be done and paid for before we mobilise, not discovered on demolition day. In any pre-1980 building the usual place it turns up is 9" floor tile and the mastic under it.',
  },
  {
    q: 'Will you look at a space before I sign the lease?',
    a: 'Yes, for free, and it is the most useful hour we spend with anyone. Service size and spare capacity, gas meter rating, waste line size and location, restroom and fixture counts, roof structure, and the existing versus proposed occupancy classification. You get written notes whether or not you hire us, and they are written so another contractor can price from them. If the answer is that the shell is wrong for your use, you have saved a great deal more than the hour cost.',
  },
];
