import { test, expect } from '@playwright/test';

test.describe('Wingfield Build Co. — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title names this business and this city', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Wingfield Build Co.');
    expect(title).toContain('Richmond');
  });

  // Scaffold contamination is the most common defect in this library: a template
  // is built by copying its neighbour, and everything not explicitly rewritten
  // survives. This asserts the day-74 nouns are gone from the rendered page.
  test('no trace of the source template survives in the rendered page', async ({ page }) => {
    await page.goto('/');
    const body = (await page.locator('body').innerText()).toLowerCase();
    for (const stale of [
      'foursquare', 'joinery', 'grand rapids', 'michigan', 'carpenter',
      'cabinet', 'built-in', 'alcove', 'walnut', 'moss', 'wood guide',
    ]) {
      expect(body).not.toContain(stale);
    }
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
    expect(description!.length).toBeLessThan(200);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
    expect(ogImage).toContain('og-image.png');
  });

  // Fonts imported from inside the CSS bundle are discovered only once the
  // stylesheet parses, which cost house-painter a CLS of 0.156 (KNOWN_DEFECTS
  // §14). The three above-the-fold faces are preloaded from Base.astro.
  test('above-the-fold font faces are preloaded', async ({ page }) => {
    await page.goto('/');
    const preloads = page.locator('link[rel="preload"][as="font"]');
    expect(await preloads.count()).toBe(3);
    const hrefs = await preloads.evaluateAll(els => els.map(e => e.getAttribute('href') ?? ''));
    expect(hrefs.some(h => h.includes('overpass-latin-700'))).toBe(true);
    expect(hrefs.some(h => h.includes('libre-franklin-latin-400'))).toBe(true);
    expect(hrefs.some(h => h.includes('overpass-mono-latin-500'))).toBe(true);
    for (const h of hrefs) {
      const res = await page.request.get(h);
      expect(res.status()).toBe(200);
    }
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of [
      'projects', 'spaces', 'pre-lease', 'number', 'schedule',
      'team', 'jurisdictions', 'references', 'faq', 'contact',
    ]) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('every in-page nav link resolves to a real section', async ({ page }) => {
    await page.goto('/');
    const hrefs = await page.locator('a[href^="#"]').evaluateAll(
      els => els.map(el => el.getAttribute('href')!).filter(h => h.length > 1),
    );
    expect(hrefs.length).toBeGreaterThan(5);
    for (const href of [...new Set(hrefs)]) {
      await expect(page.locator(href)).toBeAttached();
    }
  });

  test('tel links are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="tel:"]').count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('mailto link is present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="mailto:"]').count();
    expect(count).toBeGreaterThanOrEqual(1);
  });

  test('external links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const blanks = page.locator('a[target="_blank"]');
    const total = await blanks.count();
    expect(total).toBeGreaterThanOrEqual(2);
    const safe = await page.locator('a[target="_blank"][rel*="noopener"]').count();
    expect(safe).toBe(total);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  // schema.org DOES define `GeneralContractor`, under HomeAndConstructionBusiness,
  // and it already inherits LocalBusiness. Days 72-74 emitted the array form
  // because no exact type existed for those trades. Here it does, so pairing them
  // would be redundant — this template emits a single string type.
  test('business schema is a single GeneralContractor type, not an array', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const parsed = blocks.map(b => JSON.parse(b));
    const business = parsed.find(b => b['@type'] === 'GeneralContractor' && b.makesOffer);
    expect(business).toBeTruthy();
    expect(Array.isArray(business['@type'])).toBe(false);
    expect(business['@type']).toBe('GeneralContractor');
    expect(Array.isArray(business.makesOffer)).toBe(true);
    expect(business.makesOffer.length).toBe(6);
    expect(Array.isArray(business.knowsAbout)).toBe(true);
    expect(business.hasCredential[0].name).toContain('Class A');
    expect(business.founder['@type']).toBe('Person');
    expect(business.founder.name).toContain('Delia');
    // No aggregateRating anywhere: the references are fictional and a star
    // rating with nothing behind it is what search engines penalise.
    const allSchema = JSON.stringify(parsed);
    expect(allSchema).not.toContain('aggregateRating');
    expect(allSchema).not.toContain('HomeAndConstructionBusiness');
  });

  test('FAQPage schema covers every question on the page', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const faq = blocks.map(b => JSON.parse(b)).find(b => b['@type'] === 'FAQPage');
    expect(faq).toBeTruthy();
    const rendered = await page.locator('details summary').count();
    expect(faq.mainEntity.length).toBe(rendered);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('link[rel="icon"]')).toBeAttached();
  });

  test('six space types with published ranges', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.space-card').count()).toBe(6);
  });

  test('six project ledgers', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.ledger-card').count()).toBe(6);
  });

  test('six references', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.reference-card').count()).toBe(6);
  });

  test('four jurisdictions are all present', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.jurisdiction-zone').count()).toBe(4);
  });

  test('team section names both people', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#team')).toBeAttached();
    expect(await page.locator('.team-card').count()).toBe(2);
    await expect(page.locator('#team')).toContainText('Delia Wingfield');
    await expect(page.locator('#team')).toContainText('Marcus Oyelaran');
  });

  test('self-performed and subcontracted trades are both listed', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.trades-col').count()).toBe(2);
    expect(await page.locator('.trades-list li').count()).toBeGreaterThanOrEqual(10);
  });

  test('contact form is present with a labelled control for every input', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.contact-form')).toBeAttached();
    const controls = page.locator('.contact-form input, .contact-form select, .contact-form textarea');
    const total = await controls.count();
    expect(total).toBeGreaterThanOrEqual(5);
    for (let i = 0; i < total; i++) {
      const id = await controls.nth(i).getAttribute('id');
      expect(id).toBeTruthy();
      await expect(page.locator(`label[for="${id}"]`)).toHaveCount(1);
    }
  });

  test('FAQ section has ten items', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('details').count()).toBe(10);
  });

  // No decorative characters from Geometric Shapes, Miscellaneous Symbols or
  // Dingbats, and no variation selectors. Day 74 shipped U+25EB as
  // `<glyph>&#xFE0E;` and it rendered as a tofu box.
  test('no decorative glyphs from the tofu-prone blocks', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const banned = /[■-◿☀-⛿✀-➿︎️]/;
    expect(banned.test(html)).toBe(false);
  });

  test('the free edition does not ship the Pro lease-checklist page', async ({ page }) => {
    // The build under test is the free one, so /lease-checklist/ redirects home.
    const response = await page.goto('/lease-checklist/');
    expect(response?.status()).toBeLessThan(400);
    await expect(page.locator('h1')).toContainText('Your rent starts');
  });

  test('the design system page loads and is noindexed', async ({ page }) => {
    const response = await page.goto('/design/');
    expect(response?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
  });
});
