import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Wingfield Build Co. — accessibility', () => {
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();

    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  // The maker strip is the element that has failed most often across the library:
  // 61 footers were "fixed" with a var() fallback chain that resolved to
  // currentColor and changed nothing. Both the paragraph and the link get their
  // own assertion, because repairing only the link leaves "Made by" failing.
  test('maker strip and credit contrast pass on the dark footer', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .include('footer')
      .withRules(['color-contrast'])
      .analyze();
    expect(results.violations).toEqual([]);

    const creditColour = await page.locator('p.maker-credit').evaluate(el => getComputedStyle(el).color);
    const linkColour   = await page.locator('p.maker-credit a').evaluate(el => getComputedStyle(el).color);
    // Explicit values, not inherited: #C6CCD7 and #A9A4F2.
    expect(creditColour).toBe('rgb(198, 204, 215)');
    expect(linkColour).toBe('rgb(169, 164, 242)');
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  test('heading hierarchy is logical', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('h1')).toHaveCount(1);
    // Ten h2s: the ten sections below the hero, in the brief's order.
    await expect(page.locator('h2')).toHaveCount(10);
  });

  test('project ledgers each carry the five-line spec block', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('.ledger-card');
    await expect(cards).toHaveCount(6);
    const specTerms = page.locator('.ledger-spec dt');
    await expect(specTerms).toHaveCount(30);   // 6 projects × 5 lines
  });

  // The rule that makes the ledger credible. If every job landed on the number,
  // the section is an advert with a table in it.
  test('at least two ledgers are late and at least one came in under', async ({ page }) => {
    await page.goto('/');
    const late = await page.locator('.ledger-flag--late').count();
    expect(late).toBeGreaterThanOrEqual(2);
    const over = await page.locator('.ledger-flag--over').count();
    expect(over).toBeGreaterThanOrEqual(2);
    const under = await page.locator('.ledger-flag--under').count();
    expect(under).toBeGreaterThanOrEqual(1);
  });

  test('change orders are itemised with an id, an amount and a reason', async ({ page }) => {
    await page.goto('/');
    const ids = await page.locator('.ledger-co-id').count();
    expect(ids).toBeGreaterThanOrEqual(10);
    expect(await page.locator('.ledger-co-amount').count()).toBe(ids);
    expect(await page.locator('.ledger-co-reason').count()).toBe(ids);
    // At least one job with none at all, and it explains itself rather than boasting.
    expect(await page.locator('.ledger-co-none').count()).toBeGreaterThanOrEqual(1);
  });

  test('space types are present with published $/sf ranges', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.space-card')).toHaveCount(6);
    const ranges = await page.locator('.space-range').allTextContents();
    expect(ranges.length).toBe(6);
    ranges.forEach(r => {
      expect(r).toContain('$');
      expect(r).toContain('/sf');
    });
  });

  // The change-order section must concede. A list of three reasons it is never
  // the contractor's fault is an advert and the reader knows.
  test('the change-order section names the illegitimate cause', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.cause-card')).toHaveCount(4);
    await expect(page.locator('.cause-card--illegitimate')).toHaveCount(1);
    await expect(page.locator('.cause-card--illegitimate')).toContainText('left out');
  });

  test('references cover three roles, not one', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('.reference-card');
    expect(await cards.count()).toBeGreaterThanOrEqual(3);
    const roles = new Set(await page.locator('.reference-role').allTextContents());
    expect(roles.size).toBe(3);
  });

  test('jurisdiction zones are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('.jurisdiction-zone').count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('the capacity bar replaces the emergency bar', async ({ page }) => {
    await page.goto('/');
    const bar = page.locator('.capacity-bar');
    await expect(bar).toBeVisible();
    await expect(bar).toContainText('mid-November');
    // A tenant improvement contractor has no emergency. No emergency bar at all.
    await expect(page.locator('.emergency-bar')).toHaveCount(0);
  });

  test('design system page passes axe', async ({ page }) => {
    await page.goto('/design/');
    await page.waitForLoadState('networkidle');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();
    if (results.violations.length > 0) {
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }
    expect(results.violations).toEqual([]);
  });
});
