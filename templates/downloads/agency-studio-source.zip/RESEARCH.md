# Agency-Studio Template — Research Brief

> **Assumption:** A 3–5 person brand and digital design studio that sells identity, web, and creative direction services to early-stage tech startups. Not a full-service marketing agency. Not a freelancer portfolio. The studio IS the product; every page is a sales artefact.
>
> **Fictional studio:** **Fieldwork Studio** — a brand identity and digital design studio based in a mid-size city, known for creating clear, distinctive identities for software and SaaS companies at Series A–B stage. Three principals, one junior designer, one producer. Think: Pentagram-at-1/10th-scale, opinionated about craft, selective about clients.

---

## Audience & primary CTA

- **Who visits:** Startup founders (Seed–Series B), heads of product, or marketing leads who are searching for a brand or site redesign. They have budget. They are evaluating 3–5 studios. Dwell time and work quality are the two qualifying signals.
- **Primary CTA:** Submit a project brief via the contact form — scoped, not generic. Fields: name, company, project type (identity / web / both), rough budget range, target launch date, message.
- **Secondary CTAs:** Read a case study in full; view a specific service; follow on Instagram (where real client work lives).

---

## Reference sites (real businesses)

- https://www.pentagram.com — Restrained black/white/gray; multi-column project grid; filterable by discipline and sector; minimal text per project card; detail pages are long-form narrative. Sets the gold standard for "work speaks first."
- https://locomotive.ca/en — Strong editorial headline, project cards with image-first layout, bilingual, personality injected via tone and cultural content (studio trips, merch). Proves that warmth and craft can coexist.
- https://www.basicagency.com — Neutral high-contrast palette, drag-carousel work section, bold tagline ("Easy to understand, impossible to ignore"), internal initiatives section. Good model for service clarity alongside portfolio depth.
- https://www.instrument.com — Visual-first carousel on homepage; services broken into Brand / Marketing / Product; separate ED&I section signals values. Good example of cross-disciplinary positioning with clear nav.
- https://www.anagrama.com — Pure minimal grid; project categorization by discipline (Branding, Interactive, Architecture); 25+ project pages with consistent card treatment; global locations signal credibility. Model for case-study breadth.
- https://dia.tv — Typographic systems specialist; minimal nav (Input / Output / Information); emphasis on philosophy and process over visual flash; select client roster as trust signal. Proves that restraint + strong POV builds premium positioning.

---

## Existing templates surveyed

- https://github.com/getastrothemes/folex-lite-astro — Single known Astro agency template in the topic. Built with Astro + Tailwind. No confirmed case-studies content collection, no team page, no real contact form. Generic marketing copy. Weakness: single-page mentality bolted onto multi-page nav.
- AstroWind (github.com/arthelokyo/astrowind) — General-purpose Astro + Tailwind. Covers landing-page use case well. Not shaped for a studio: no case study collection, no team page, no project-brief form, no services detail. Good bones, wrong form factor.
- Webflow Agency Cloneables (webflow.com/made-in-webflow/agency) — Strong visual range but locked to Webflow CMS and hosting. Canvas (dark, scrolljack-heavy), Bittersweet (CMS-dependent), Kayo (clean but shallow). None are static-deployable to GH Pages. Not MIT-licensed.
- Astro themes directory paid entries (Hyperbit, CIPRES, Larch, Olmo) — All paid; all use vague "cinematic impact" marketing copy; none confirmed to have Astro content collections for case studies.
- **Saturated pattern:** Dark background + animated cursor + scroll-jacking hero + neon accent + video background. Fills Framer agency gallery. Looks impressive in demos; performs badly on mobile; inaccessible; impossible to maintain. Explicitly what we are not building.
- **Missing in free tier:** A multi-page MIT-licensed Astro studio template with: typed content collections for case studies, a separate Services page with per-service detail, a Team page, a project-brief contact form (Formspree), GH Pages-ready deploy. Nothing in this space exists free.

---

## Must-have sections (in order)

### Pages

1. **Home (`/`)** — Studio name + one-line positioning statement (not a paragraph). Then: selected work (4 project cards, image-first, 2-col on desktop). Then: a compressed services list (3 lines, links to `/services`). Then: a "who we work with" client type description (no logo grid — we have none). Then: a brief studio intro (2 sentences + link to `/team`). Footer with contact CTA.
2. **Work index (`/work`)** — Full project grid: 5 cards, filterable by discipline tag (Identity / Web / Direction). Each card: project image placeholder (SVG composition), client name (anonymized or fictional), discipline tags, year.
3. **Case study (`/work/[slug]`)** — Long-form: hero image, metadata strip (client, year, role, deliverables), problem statement, approach (2–3 sections), outcome, and a link back to Work index. Astro content collection, MDX body.
4. **Services (`/services`)** — Three services, each with a name, 2-sentence description, what's included list (5–7 items), and a "Starting enquiries" note (no price, just "Projects typically begin at $X range" — calibration, not a price sheet).
5. **Team (`/team`)** — 3 team member cards: name, role, 2-line bio, one link (LinkedIn or personal site). No photos required — uses abstract geometric SVG avatars (unique per person, CSS-generated, no external images).
6. **Contact (`/contact`)** — Project-brief form via Formspree: name, email, company, project type (select), budget range (select), target date (select), message. Mailing address stub. Studio email. Social links.

### Not building

- **/about** (separate from team): the studio intro on the homepage + Team page is sufficient for a 3–5 person studio. An /about page duplicates content and adds navigation debt.
- **/journal or /blog**: content marketing is out of scope. The operator can add it themselves using the personal-blog template as a sub-collection.
- **/careers**: a studio of this size hires opportunistically. A one-line footer note ("We hire occasionally — email us") is sufficient.
- **/pricing**: no page. Service ranges appear only inside the contact form's budget-range select.

---

## Design conventions

- **Typography:** **General Sans** (ITF Free Font License, variable, 12 styles) for all UI, navigation, labels, and body copy. **Fraunces** (Google Fonts, free, variable) as the display/heading typeface — used only for large hero statements, case study titles, and the studio name logotype. This is a deliberately unusual pairing: Fraunces is an "old style soft-serif" with warmth and quirk; General Sans is a clean rationalist grotesque. The combination reads as "crafted but contemporary." No other Day 1–7 typeface is used.
- **Color palette tendency:** **Deep charcoal with a single burnt-orange accent.** Base: `#1A1917` (warm near-black, not pure black — avoids harshness). Surface: `#F5F3EF` (warm off-white for light sections). Accent: `#C2410C` (burnt orange — distinct from Day 1's amber `#FFB020`, Day 4's coral `#C13B1F`, Day 7's magenta, Day 3's lime). Secondary text: `#6B6460` (warm mid-gray). This palette reads as "premium craft studio" — the same register as letterpress, small-run print, and premium packaging. Not tech-startup blue, not agency neon.
- **Imagery style:** Abstract typographic SVG compositions — large display letterforms, geometric color blocks, and grid overlays rendered entirely in SVG/CSS. Zero photography, zero Unsplash. Each case study card gets a unique composition built from the project's color story and letterforms. This is defensible (no licensing), design-forward (reinforces the studio's identity work), and avoids the "stock photo of laptop on a desk" cliché.
- **Density:** Premium-minimal. Wide margins (container max ~1160px with generous padding). Large type scale. Lots of vertical space between sections. The work grid is the most visually dense area (2-col cards, tight). Services and Team pages are sparse single-column or 3-col. No sidebars anywhere.
- **Light/dark:** Light-default only. No dark mode toggle. Rationale: premium studio sites (Pentagram, Anagrama, BASIC) are almost universally light-default. A dark-mode toggle introduces UI complexity and a second palette to maintain. The warm off-white base at `#F5F3EF` is already easy on the eye. Save dark-default for developer-register niches (Days 1, 3).

---

## Trust signals to include

- Case study outcome metrics in the metadata strip ("12% conversion lift", "launched in 8 weeks") — fictional but specific, not vague
- "Selected clients" — 4–6 fictional but plausible company names (e.g., "Meridian Health", "Arca Protocol") — no logos needed, names alone calibrate studio level
- Award badge or press mention in the footer (e.g., "Featured in Brand New, 2024") — one tasteful line, not a ribbon wall
- Team page with real names and LinkedIn-style bios — signals the humans behind the work
- Formspree form with project-brief fields (budget select, timeline select) — signals that the studio is selective; a generic "name + message" form undercuts premium positioning
- Footer: studio founding year ("Est. 2019") and location — longevity + place

---

## SEO / schema.org

- **Home / global:** `Organization` — `name`, `url`, `logo`, `description`, `foundingDate`, `address`, `sameAs[]` (Instagram, LinkedIn), `contactPoint`
- **Services page:** `ProfessionalService` (subtype of `LocalBusiness`) — `serviceType`, `areaServed`, `provider` (ref to `Organization`)
- **Case study pages:** `CreativeWork` — `name`, `description`, `datePublished`, `creator` (ref to `Organization`), `genre` (e.g., "Brand Identity"), `url`
- **Team page:** one `Person` per team member — `name`, `jobTitle`, `url` (LinkedIn), `worksFor` (ref to `Organization`)
- **Contact page:** no separate schema; `Organization.contactPoint` covers it
- **Suggested OG image direction:** Studio name in Fraunces display on `#1A1917` background with the burnt-orange accent stripe and a single abstract SVG mark. Static committed image (`og-default.png`). Per-case-study OG: project title + discipline tag on the project's color story background.

---

## Static-only fit

No concerns. All features are static-compatible:

- **Case studies:** Astro content collections (`src/content/work/`) with MDX. `getStaticPaths` at build. Zero runtime.
- **Contact form:** Formspree free tier (50 submissions/month). `action` attribute on a plain HTML `<form>`, no JS SDK required. Same pattern as Day 3 waitlist — proven.
- **SVG image placeholders:** Generated at build from frontmatter (project color + initials). Pure CSS/SVG, no canvas, no image processing.
- **Filterable work grid:** Client-side JS only (class toggling on `data-tag` attributes). No server query. Gracefully degrades: all projects visible with no JS.
- **Team avatars:** Inline SVG per team member, parameterized from MDX frontmatter or a JSON data file. No external images, no CDN dependency.
- **Schema JSON-LD:** Emitted as `<script type="application/ld+json">` in `<head>` via Astro layout. Static string at build time.

---

## Differentiation — what we'll do better

1. **Typed case-study content collection:** `zod` schema enforces `client`, `year`, `role`, `deliverables[]`, `tags[]`, `outcome` fields. No other free agency template ships this. Builder gets compile-time errors if a case study is malformed.
2. **Specific fictional content:** "Fieldwork Studio" has named projects, plausible client types, and real-sounding outcome metrics. Competitors ship "Project Title" and "Lorem ipsum." Viewers can evaluate the template immediately without imagination.
3. **SVG-only imagery:** Zero photo licensing risk. Every project card looks designed, not stocked. The template differentiates itself visually from every Webflow or Framer agency template that relies on Unsplash hero imagery.
4. **Project-brief contact form:** Budget range, project type select, and timeline select fields signal a selective studio. No other free template ships this field set. Formspree free tier, no backend, works on GH Pages.
5. **Fraunces + General Sans pairing:** Not used in any Day 1–7 template or in any surveyed free Astro agency template. The pairing is immediately recognizable as non-generic.
6. **GH Pages one-click deploy:** Webflow cloneables require Webflow hosting. Framer starters require Framer. Our template ships with the pre-wired `pages.yml` workflow. MIT licensed. True zero-cost hosting.
7. **No animated cursor, no scroll-jacking, no video background:** These are the three features that make agency template demos impressive and real agency sites inaccessible, slow, and unmaintainable. We make restraint a feature, not a compromise.

---

## Explicitly NOT building

- **Animated custom cursor:** Requires persistent JS listener on `mousemove`. Accessibility failure (breaks keyboard-only and pointer-constrained users). Distracts from the work. Every Framer agency template ships one; we don't.
- **Scroll-jacking transitions (GSAP ScrollTrigger, Locomotive Scroll):** Breaks browser native scroll; catastrophic on iOS Safari; adds 40–80KB of JS. Real studios use it to win Awwwards; real clients can't update it without a developer.
- **Video background on hero:** Large file, autoplay policy inconsistencies across browsers, kills LCP score, impossible to maintain.
- **Third-party CMS (Contentful, Sanity, Prismic):** Requires API tokens, SSR or ISR, paid tiers above a content threshold. Our case studies are MDX files in the repo. Edit locally, push, deploy.
- **Client portal / password-protected case studies:** Requires server auth. Out of scope for a static template. Studios that need this use Notion or a private GH Pages branch.
- **Testimonials carousel / slider:** JS-heavy, accessibility minefield. Static testimonials rendered as blockquotes in the contact or home page are sufficient.
- **Chat widget (Intercom, Drift, Crisp):** Injects third-party scripts, tanks Lighthouse score, and is inappropriate for a selective studio register. Email is the correct contact channel here.
