import { defineCollection, z } from 'astro:content';

const work = defineCollection({
  type: 'content',
  schema: z.object({
    title:        z.string(),
    client:       z.string(),
    summary:      z.string(),
    year:         z.number().int(),
    role:         z.string(),
    deliverables: z.array(z.string()),
    tags:         z.array(z.enum(['Identity', 'Web', 'Direction'])),
    outcome:      z.string(),
    /** SVG color story — used for the auto-generated abstract project card. */
    colorBg:      z.string(),
    colorFg:      z.string(),
    /** 2-letter mark used in the SVG card; usually the client's initials. */
    mark:         z.string().min(1).max(3),
    /** Pro edition only: real cover photo at /images/pro/work/<slug>.jpg.
     *  Free edition ignores this and renders the ProjectMark SVG. */
    coverImage:   z.string().optional(),
    coverAlt:     z.string().optional(),
    featured:     z.boolean().default(false),
    order:        z.number().int().default(0),
  }),
});

export const collections = { work };
