// Edition flag — the single switch that turns a free template into its Pro build.
//
// Free build (default):  PUBLIC_EDITION unset  → isPro === false
// Pro build:             PUBLIC_EDITION=pro     → isPro === true
//
// The Pro build is produced by scripts/zip-pro-templates.mjs, which sets
// PUBLIC_EDITION=pro at build time. Components read `isPro` to swap in the
// commercial license, real photography, and Pro-only sections. Keeping this a
// build flag (not a forked copy) means "make template X Pro" is a wiring pass,
// not a rewrite — see docs/PRO_PLATFORM_PLAN.md.
export const EDITION = import.meta.env.PUBLIC_EDITION === 'pro' ? 'pro' : 'free';
export const isPro = EDITION === 'pro';
