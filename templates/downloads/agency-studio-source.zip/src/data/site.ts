// Single source of truth for Fieldwork Studio.
// Cloning users edit this file (and src/content/work/*.mdx for case studies)
// to make the site theirs.

export const studio = {
  name: 'Fieldwork Studio',
  short: 'Fieldwork',
  positioning: 'A brand and digital design studio for software companies that take craft seriously.',
  oneLiner: 'We make brands clear, distinctive, and durable.',
  description:
    'Fieldwork is a 4-person studio working on identity, web, and creative direction. We partner with founders at Series A through B who have something specific to say and the patience to say it well.',
  foundingYear: 2019,
  city: 'Toronto',
  region: 'ON',
  country: 'Canada',
  pressNote: 'Selected work featured in Brand New (2024).',
  selectedClients: [
    'Meridian Health',
    'Arca Protocol',
    'Inflect.so',
    'Field Notes Press',
    'Gloss Cosmetics',
    'Lattice Labs',
  ],
  socials: {
    instagram: '#',
    linkedin: '#',
    x: '#',
  },
};

export const contact = {
  email: 'hello@fieldworkstudio.com',
  phoneDisplay: '+1 (416) 555-0119',  // display-only; not a link
  postalAddress: {
    street: '120 Adelaide St W, Suite 304',
    city: 'Toronto',
    region: 'ON',
    postalCode: 'M5H 1T1',
    country: 'CA',
  },
};

export const services = [
  {
    id: 'identity',
    name: 'Brand Identity',
    description:
      'Naming, mark, type system, color, voice. The fundamentals, treated as fundamentals — not as a deliverable to ship in 2 weeks.',
    includes: [
      'Strategic positioning + naming review',
      'Mark + wordmark exploration',
      'Type system: display + body pairing, hierarchy',
      'Color system with WCAG-validated combinations',
      'Photography or illustration direction',
      'Brand guidelines document',
      'Hand-off + 60 days of refinement',
    ],
    rangeNote: 'Identity engagements typically begin around $40K and run 8–14 weeks.',
  },
  {
    id: 'web',
    name: 'Marketing Site & Product Surfaces',
    description:
      'Marketing sites, app marketing pages, design systems for product teams. Built to ship, not to demo.',
    includes: [
      'IA + content strategy',
      'Visual design across all primary surfaces',
      'Front-end build (Astro / Next / static)',
      'Design tokens + component library hand-off',
      'CMS or MDX content model',
      'Performance + a11y validation',
      'Pre-launch + post-launch passes',
    ],
    rangeNote: 'Site engagements typically begin around $50K and run 10–16 weeks.',
  },
  {
    id: 'direction',
    name: 'Creative Direction',
    description:
      'Embedded creative direction for in-house teams. Six-week sprints; we plug in, raise the bar, and hand back a clearer system.',
    includes: [
      'Audit of current visual + verbal output',
      'Direction principles document',
      'Templated systems your team can run',
      'Critique cadence with internal designers',
      'Hand-off to an in-house lead',
      'Optional ongoing retainer',
    ],
    rangeNote: 'Six-week direction sprints begin at $30K. Retainers from $12K/mo.',
  },
];

export const team = [
  {
    id: 'allan-ninal',
    name: 'Fieldwork Studio',
    role: 'Principal, Identity & Strategy',
    bio: 'Allan started Fieldwork in 2019 after eight years at a larger studio in Brooklyn. He leads identity engagements and writes most of the strategic positioning documents. Likes wood type, hates filler. Originally from Toronto.',
    linkedin: '#',
  },
  {
    id: 'mira-soto',
    name: 'Mira Soto',
    role: 'Principal, Digital',
    bio: 'Mira leads marketing-site and product-surface engagements. Previously a senior designer at Linear and a self-published Riso printmaker on the side. Believes the design system is the deliverable; the page is just an instance of it.',
    linkedin: '#',
  },
  {
    id: 'theo-park',
    name: 'Theo Park',
    role: 'Designer',
    bio: 'Theo joined Fieldwork in 2023. Prior to that: designer at a healthcare startup, then a year as a freelance illustrator. Brings range — equally happy in Figma, Glyphs, or InDesign. Cares about how letters fit together more than most.',
    linkedin: '#',
  },
  {
    id: 'nadia-okafor',
    name: 'Nadia Okafor',
    role: 'Designer, Web & Systems',
    bio: 'Nadia builds the front-end side of our marketing-site work and keeps our design systems honest. Came up through a product team before going independent, then joined Fieldwork in 2024. Will argue about spacing scales for longer than is reasonable, and is usually right.',
    linkedin: '#',
  },
];

export const homeCopy = {
  heroTagline: 'Clear, distinctive, durable.',
  heroBody:
    'Fieldwork is a 4-person studio in Toronto. We do brand identity, marketing sites, and creative direction for software companies — most of them small enough to still feel surprised by their own growth.',
  workIntro:
    'A few projects we\'ve liked working on. Each studied carefully, none rushed.',
  studioIntro:
    'We work in a specific register: confident, restrained, technically rigorous. We tend to say no when the brief asks for something we don\'t do, which is most things outside identity, web, and direction.',
};
