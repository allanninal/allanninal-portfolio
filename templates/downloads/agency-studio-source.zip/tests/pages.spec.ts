import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() === 'error') errors.push(`console.error: ${m.text()}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home meta description is set', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home emits Organization JSON-LD with name + foundingDate + sameAs', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const org = docs.find((d) => d && d['@type'] === 'Organization');
  expect(org, 'Organization JSON-LD missing').toBeTruthy();
  expect(org.name).toBe('Fieldwork Studio');
  expect(org.foundingDate).toBe('2019');
  expect(Array.isArray(org.sameAs)).toBe(true);
  expect(org.sameAs.length).toBeGreaterThanOrEqual(2);
  expect(org.address).toBeTruthy();
});

test('case study page emits CreativeWork JSON-LD', async ({ page }) => {
  await page.goto('/work/meridian-health/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const work = docs.find((d) => d && d['@type'] === 'CreativeWork');
  expect(work, 'CreativeWork JSON-LD missing on case study').toBeTruthy();
  expect(work.name).toContain('identity');
  expect(work.creator['@type']).toBe('Organization');
  expect(work.datePublished).toMatch(/^\d{4}-\d{2}-\d{2}$/);
});

test('services page emits ProfessionalService JSON-LD per service', async ({ page }) => {
  await page.goto('/services/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const services = docs.filter((d) => d && d['@type'] === 'ProfessionalService');
  expect(services.length).toBe(3);
  for (const svc of services) {
    expect(svc.provider['@type']).toBe('Organization');
    expect(svc.serviceType).toBeTruthy();
  }
});

test('team page emits Person JSON-LD per member', async ({ page }) => {
  await page.goto('/team/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const persons = docs.filter((d) => d && d['@type'] === 'Person');
  expect(persons.length).toBe(4);
  for (const p of persons) {
    expect(p.jobTitle).toBeTruthy();
    expect(p.worksFor['@type']).toBe('Organization');
  }
});

test('OG image absolute and 1200×630', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toMatch(/^https?:\/\//);
  expect(og).toContain('og-image.png');
  expect(await page.locator('meta[property="og:image:width"]').getAttribute('content')).toBe('1200');
  expect(await page.locator('meta[property="og:image:height"]').getAttribute('content')).toBe('630');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  expect(await page.locator('meta[name="twitter:card"]').getAttribute('content')).toBe('summary_large_image');
});

test('canonical URLs are absolute on every route', async ({ page }) => {
  for (const route of ROUTES.slice(0, 5)) {
    await page.goto(route);
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical, `canonical missing on ${route}`).toBeTruthy();
    expect(canonical, `canonical not absolute on ${route}`).toMatch(/^https?:\/\//);
  }
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});
