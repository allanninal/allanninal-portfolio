import type { Page } from '@playwright/test';

export const ROUTES = [
  '/',
  '/work/',
  '/services/',
  '/team/',
  '/contact/',
  '/work/meridian-health/',
  '/work/arca-protocol/',
  '/work/inflect/',
  '/work/field-notes-press/',
  '/work/gloss-cosmetics/',
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];
