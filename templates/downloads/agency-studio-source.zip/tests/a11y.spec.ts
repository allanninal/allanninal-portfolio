import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

// Sample 5 representative routes — chrome is identical across pages.
const SAMPLE = ['/', '/work/', '/services/', '/team/', '/contact/'];

for (const route of SAMPLE) {
  test(`a11y: ${route} — zero violations`, async ({ page }) => {
    await page.goto(route);

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();

    const violations = results.violations.map((v) => ({
      id: v.id,
      impact: v.impact,
      description: v.description,
      nodes: v.nodes.length,
      help: v.helpUrl,
    }));

    expect(
      violations,
      `Axe violations on ${route}:\n${JSON.stringify(violations, null, 2)}`,
    ).toEqual([]);
  });
}

test('a11y: case study page — zero violations', async ({ page }) => {
  await page.goto('/work/meridian-health/');
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  const violations = results.violations.map((v) => ({
    id: v.id,
    nodes: v.nodes.length,
  }));
  expect(violations).toEqual([]);
});
