import { test, expect } from '@playwright/test';

// ── Header navigation ─────────────────────────────────────────────────────

test('header has the four primary nav links', async ({ page }) => {
  await page.goto('/');
  // exact: true — "Work" must not match "Fieldwork Studio" (the logo).
  for (const label of ['Work', 'Services', 'Team', 'Contact']) {
    await expect(page.locator('header').getByRole('link', { name: label, exact: true })).toBeVisible();
  }
});

test('header logo links back to home', async ({ page }) => {
  await page.goto('/work/');
  await page.locator('header').getByRole('link', { name: /fieldwork studio/i }).click();
  await expect(page).toHaveURL(/\/$/);
});

// ── Home: featured work ───────────────────────────────────────────────────

test('home shows featured work cards (≥3)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('[data-work-card]');
  expect(await cards.count()).toBeGreaterThanOrEqual(3);
});

test('home shows the selected-clients band', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('Meridian Health').first()).toBeVisible();
});

// ── Work index + filter (progressive enhancement) ─────────────────────────

test('work index lists all 5 case studies', async ({ page }) => {
  await page.goto('/work/');
  const cards = page.locator('[data-work-card]');
  expect(await cards.count()).toBe(5);
});

test('filter bar is visible with JS enabled and filters cards', async ({ page }) => {
  await page.goto('/work/');
  const bar = page.locator('[data-work-filter-bar]');
  await expect(bar).toBeVisible();

  // Click "Identity" — only Identity-tagged cards should remain
  await bar.getByRole('button', { name: 'Identity' }).click();
  const visibleCards = page.locator('[data-work-card]:visible');
  const visibleCount = await visibleCards.count();
  // Must have at least one (Meridian + Inflect + Field Notes are Identity)
  expect(visibleCount).toBeGreaterThan(0);
  for (let i = 0; i < visibleCount; i++) {
    const tags = await visibleCards.nth(i).getAttribute('data-tags');
    expect(tags).toContain('identity');
  }
});

test('filter bar is hidden when JS is disabled (progressive enhancement)', async ({ browser }) => {
  const ctx = await browser.newContext({ javaScriptEnabled: false });
  const page = await ctx.newPage();
  await page.goto('/work/');
  const bar = page.locator('[data-work-filter-bar]');
  // Without JS the bar keeps its `hidden` class — only revealed by the script.
  await expect(bar).toHaveClass(/hidden/);
  // All cards still visible
  const cards = page.locator('[data-work-card]');
  expect(await cards.count()).toBe(5);
  await ctx.close();
});

// ── Case study page ──────────────────────────────────────────────────────

test('case study page shows metadata strip with all 5 fields', async ({ page }) => {
  await page.goto('/work/meridian-health/');
  for (const label of ['Client', 'Role', 'Year', 'Discipline', 'Deliverables', 'Outcome']) {
    await expect(page.getByText(label, { exact: true }).first()).toBeVisible();
  }
});

test('case study page renders MDX prose body and an "All work" link', async ({ page }) => {
  await page.goto('/work/meridian-health/');
  // Body uses .prose-case
  await expect(page.locator('.prose-case h2').first()).toBeVisible();
  // Back link in header AND the bottom CTA both link to /work/
  const backLinks = page.locator('a[href$="/work/"]');
  expect(await backLinks.count()).toBeGreaterThanOrEqual(2);
});

// ── Services page ────────────────────────────────────────────────────────

test('services page shows three services with rangeNote', async ({ page }) => {
  await page.goto('/services/');
  for (const svc of ['Brand Identity', 'Marketing Site & Product Surfaces', 'Creative Direction']) {
    await expect(page.getByRole('heading', { name: svc })).toBeVisible();
  }
  // Each service has a "Starting at" / "begin at" calibration line
  const ranges = page.getByText(/begin at|begin around/i);
  expect(await ranges.count()).toBeGreaterThanOrEqual(3);
});

// ── Team page ────────────────────────────────────────────────────────────

test('team page shows three team members with role + LinkedIn', async ({ page }) => {
  await page.goto('/team/');
  for (const name of ['Allan Ninal', 'Mira Soto', 'Theo Park']) {
    await expect(page.getByText(name).first()).toBeVisible();
  }
  // LinkedIn link per member (3 in main + 1 in footer = 4)
  const liLinks = page.getByRole('link', { name: /linkedin/i });
  expect(await liLinks.count()).toBeGreaterThanOrEqual(4);
});

// ── Contact form ─────────────────────────────────────────────────────────

test('contact form has all required fields', async ({ page }) => {
  await page.goto('/contact/');
  for (const id of ['name', 'email', 'project-type', 'budget', 'timeline', 'message']) {
    await expect(page.locator(`#${id}`)).toBeVisible();
  }
});

test('contact form posts to formspree.io', async ({ page }) => {
  await page.goto('/contact/');
  const action = await page.locator('#brief-form').getAttribute('action');
  expect(action).toContain('formspree.io');
});

test('contact form shows error on missing fields', async ({ page }) => {
  await page.goto('/contact/');
  // Submit without filling anything — the JS handler shows the error state.
  await page.getByRole('button', { name: /send brief/i }).click();
  await expect(page.locator('#form-error')).toBeVisible();
});

test('contact form shows success on valid demo submit', async ({ page }) => {
  // Block formspree.io to be safe — the demo build short-circuits anyway.
  await page.route('**/formspree.io/**', (route) =>
    route.fulfill({ status: 200, body: '{}', headers: { 'Content-Type': 'application/json' } })
  );

  await page.goto('/contact/');
  await page.locator('#name').fill('Allan Ninal');
  await page.locator('#email').fill('hello@example.com');
  await page.locator('#company').fill('Test Co');
  await page.locator('#project-type').selectOption('identity');
  await page.locator('#budget').selectOption('30-50k');
  await page.locator('#timeline').selectOption('2-4mo');
  await page.locator('#message').fill('A test project brief that is long enough to pass minlength=20.');

  await page.getByRole('button', { name: /send brief/i }).click();
  await expect(page.locator('#form-success')).toBeVisible({ timeout: 5000 });
});

// ── Footer ───────────────────────────────────────────────────────────────

test('footer "have a project" CTA links to /contact/', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('footer').getByRole('link', { name: /send a brief/i });
  await expect(cta).toBeVisible();
  expect(await cta.getAttribute('href')).toContain('/contact/');
});

test('LinkedIn appears before Email in the footer', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer').first();
  const hrefs = await footer.locator('a[href]').evaluateAll((els) =>
    els.map((e) => (e as HTMLAnchorElement).getAttribute('href') || ''),
  );
  const idxLI = hrefs.findIndex((h) => h.includes('linkedin.com'));
  const idxEmail = hrefs.findIndex((h) => h.startsWith('mailto:'));
  expect(idxLI).toBeGreaterThan(-1);
  expect(idxEmail).toBeGreaterThan(-1);
  expect(idxLI).toBeLessThan(idxEmail);
});

test('footer donate link points to ko-fi when env var is set', async ({ page }) => {
  await page.goto('/');
  const donate = page.locator('[data-donate-url]').first();
  if ((await donate.count()) > 0) {
    expect(await donate.getAttribute('href')).toContain('ko-fi.com');
  }
});
