/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Light-only by intentional design — premium studio sites stay light.
  theme: {
    extend: {
      fontFamily: {
        // Bricolage Grotesque — body, UI, navigation, labels.
        sans: ['"Bricolage Grotesque Variable"', '"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        // Fraunces — display, hero statements, case study titles, the studio logotype.
        display: ['"Fraunces Variable"', 'Fraunces', 'Georgia', 'Cambria', 'serif'],
        serif: ['"Fraunces Variable"', 'Fraunces', 'Georgia', 'serif'],
      },
      fontSize: {
        'xs':  ['0.75rem',   { lineHeight: '1.5' }],
        'sm':  ['0.875rem',  { lineHeight: '1.55' }],
        'base':['1rem',      { lineHeight: '1.65' }],
        'lg':  ['1.125rem',  { lineHeight: '1.55' }],
        'xl':  ['1.25rem',   { lineHeight: '1.4' }],
        '2xl': ['1.5rem',    { lineHeight: '1.25' }],
        '3xl': ['1.875rem',  { lineHeight: '1.15' }],
        '4xl': ['2.5rem',    { lineHeight: '1.05' }],
        '5xl': ['3.5rem',    { lineHeight: '1.0' }],
        '6xl': ['4.5rem',    { lineHeight: '0.98' }],
        '7xl': ['5.5rem',    { lineHeight: '0.95' }],
      },
      maxWidth: {
        '7xl': '72.5rem', // 1160px container max
        prose: '64ch',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
    },
  },
};
