# agency-studio

A free, MIT-licensed multi-page **agency / studio** template for indie design and development studios. Demonstrated by marketing a fictional **Fieldwork Studio** — a 4-person brand and digital design studio. Six pages, five MDX case studies, project-brief contact form.

**Light-only · Bricolage Grotesque + Fraunces · Burnt-orange `#C2410C` on warm-cream `#F5F3EF`.**

![Preview](./preview.png)

**Live demo:** [templates.allanninal.dev/agency-studio/](https://templates.allanninal.dev/agency-studio/)

---

## Features

- **Multi-page IA**: home, work index, individual case studies (5 of them), services, team, contact. The structure that real studio sites converge on.
- **Astro Content Collections** with zod-typed frontmatter for case studies. Compile-time errors if a case study is malformed.
- **Five substantive case studies** (Meridian Health, Arca Protocol, Inflect, Field Notes Press, Gloss Cosmetics) with real outcome metrics, real prose, real differentiation. The point: a viewer can evaluate the template without imagination.
- **SVG-only imagery — no photography**, no licensing risk. Each project card is an abstract typographic composition built from the project's color story and initials. Four built-in mark variants (centered, wordmark, stack, overlap) cycle through cards.
- **Geometric SVG team avatars** — deterministic per-name, no headshots required.
- **Project-brief contact form** with budget-range + project-type + timeline selects (Formspree). Signals "selective studio" — generic name+message forms undercut premium positioning.
- **Filterable work grid** by discipline (Identity / Web / Direction). Progressive enhancement: filter buttons revealed only when JS loads, all cards visible without JS.
- **Schema.org per page type** — `Organization` site-wide; `ProfessionalService` × 3 on Services; `CreativeWork` per case study; `Person` × 3 on Team.
- **Bricolage Grotesque + Fraunces** — both variable, both free, neither used in any prior day's template. The pairing reads as "crafted but contemporary."
- **Burnt-orange `#C2410C` on warm cream** — fully fresh palette from Days 1-7. Two accent shades: regular for visuals, deep for body-copy text contexts (passes WCAG AA at all sizes).
- **Light-only by intentional design.** Premium studio sites (Pentagram, Anagrama, BASIC) are universally light-default. Dark mode adds maintenance debt without ROI for this register.
- **No animated cursor, no scroll-jacking, no video bg** — the three features that win Awwwards and lose clients. Restraint is the feature.
- **Full test suite — 73 Playwright tests** including: every route renders, JSON-LD shape per page (Organization, CreativeWork, ProfessionalService, Person), case study metadata strip, work-grid filter works WITH JS and gracefully degrades WITHOUT JS, contact form submits and shows success, LinkedIn-first footer, axe clean across 6 routes, Lighthouse all four ≥ 95.

## Stack

- **Framework:** Astro 4 (static output)
- **Markdown:** MDX with @astrojs/mdx
- **Styles:** Tailwind CSS, CSS custom properties for theme tokens
- **Fonts:** Bricolage Grotesque Variable + Fraunces Variable (self-hosted via @fontsource-variable)
- **Form:** Formspree (free tier: 50 submissions/month)
- **Testing:** Playwright, @axe-core/playwright, Lighthouse CI, linkinator

## Quick start

```bash
unzip agency-studio-source.zip -d my-studio
cd my-studio
npm install
cp .env.example .env
npm run dev
```

## Customize

### 1. Studio identity, services, team, copy

Edit `src/data/site.ts`. The exports `studio`, `contact`, `services`, `team`, `homeCopy` are the source of truth for everything that isn't a case study.

```ts
export const studio = {
  name: 'Fieldwork Studio',
  positioning: '...',
  city: 'Toronto',
  selectedClients: ['Meridian Health', 'Arca Protocol', ...],
};
```

### 2. Case studies

Drop MDX files in `src/content/work/`. Each case study needs frontmatter:

```mdx
---
title: "An identity that doesn't apologize for being a clinic"
client: "Meridian Health"
summary: "Brand identity, naming, and a marketing site for a primary-care startup."
year: 2024
role: "Identity, Naming, Web"
deliverables: ["Strategy", "Naming", "Wordmark", "Color & Type", "Website"]
tags: ["Identity", "Web"]    # one or more of Identity / Web / Direction
outcome: "Launched April 2024. 3.4× sign-up rate vs. the previous landing in 60 days."
colorBg: "#1A2E2A"           # SVG card background
colorFg: "#E5E1D7"           # SVG card foreground (mark color)
mark: "M"                    # 1-3 letters; usually client initials
featured: true               # show on the home page selected-work grid
order: 1                     # sort within work index
---

Body of the case study in MDX. Markdown + JSX welcome.
```

Schema validates at build — typos in frontmatter fail the build, not deploy.

### 3. Project-brief contact form

Set `PUBLIC_FORMSPREE_ID` in `.env` to your real Formspree form ID:

```bash
PUBLIC_FORMSPREE_ID=your-form-id-here
```

Get one (free) at [formspree.io](https://formspree.io). The form's budget-range, project-type, and timeline selects are defined in `src/pages/contact.astro` — adjust the option lists to match your services.

The demo build short-circuits to an inline success state (placeholder ID `xpwzrjqb` is detected); cloning users with a real ID get native form behavior.

### 4. Work grid filters

The filter is built around the `tags` enum in the work schema (`Identity`, `Web`, `Direction`). To add a new tag:

1. Update `src/content/config.ts` — add the tag to the `z.enum([...])`.
2. Update `src/pages/work/index.astro` — add the new tag to the `allTags` array.

That's it. The filter is progressive enhancement (revealed only when JS loads); cards default to all-visible without JS.

### 5. Theme tokens

Edit `:root` in `src/styles/global.css`. The accent comes in two shades:

- `--color-accent: #C2410C` (burnt orange, pink-700-ish) — visuals, button hover, focus rings
- `--color-accent-deep: #7C2D12` — body-copy links and emphasis text (passes WCAG AA at all sizes)

If you swap the accent, verify both shades pass AA on `--color-bg` (`#F5F3EF`) and `--color-surface-2` (`#ECE8E0`). See [accent-contrast-check](../../.claude/skills/accent-contrast-check/SKILL.md) in the parent repo.

### 6. Project mark variants

Each case study card uses one of four SVG mark variants — `centered`, `wordmark`, `stack`, `overlap`. They cycle automatically on the home page and work index. To force a specific variant per project, pass it explicitly to `<ProjectCard>`. The mark itself is composed from the case study's `colorBg`, `colorFg`, and `mark` (initials) frontmatter fields.

To add a new variant: open `src/components/ProjectMark.astro` and add a new branch with your composition. SVG only; no rasters.

---

## Deploy to GitHub Pages

> The source repo is private — there is no Fork button. Download the source ZIP from [templates.allanninal.dev/agency-studio/](https://templates.allanninal.dev/agency-studio/) and follow these steps.

1. **Unzip + init**:

   ```bash
   unzip agency-studio-source.zip -d my-studio
   cd my-studio
   git init && git add . && git commit -m "init from agency-studio template"
   ```

2. **Push** to a new GitHub repository.

3. **Settings → Pages → Source: GitHub Actions.** The included `pages.yml` builds and deploys.

### Custom domain

Add `CNAME` in `public/`, set `PUBLIC_SITE_URL` and `PUBLIC_BASE_PATH=/` in repo Variables → Actions.

---

## Testing

```bash
npm run test:all
# = npm run build && npm run test && npm run test:links && npm run test:lighthouse
```

| Suite | What it covers |
|---|---|
| `tests/pages.spec.ts` | All 10 routes render with h1, footer, no console errors; meta description; **Organization** JSON-LD with `name`, `foundingDate`, `address`, `sameAs`; **CreativeWork** JSON-LD on case studies (with `creator`, `datePublished`, `genre`); **ProfessionalService** × 3 on Services page; **Person** × 3 on Team page; OG image absolute + 1200×630; Twitter `summary_large_image`; canonical URLs; sitemap; robots.txt |
| `tests/interactions.spec.ts` | Header has all four nav links; logo links home; home shows ≥3 featured work cards + selected-clients band; work index lists all 5 case studies; **filter bar revealed by JS, hidden without JS**, filters cards by tag; case study page shows full metadata strip; services page shows three services with rangeNote; team page shows three members + LinkedIn links; contact form has all required fields, posts to formspree.io, shows error on invalid, shows success on valid demo submit; LinkedIn appears before email in footer |
| `tests/responsive.spec.ts` | No horizontal scroll at 4 viewports across 6 routes; mobile hero visible above fold; contact button hits 44px tap target |
| `tests/a11y.spec.ts` | Zero axe violations on 5 sample routes + 1 case study (covers all chrome) |
| `tests/links.spec.ts` | All `target="_blank"` links use `rel="noopener noreferrer"`; internal links resolve; mailto well-formed |

---

## Support and donations

This template is **free and MIT-licensed**.

If it saved you time: [**Ko-fi — ko-fi.com/allanninal**](https://ko-fi.com/allanninal).

---

## License

MIT — see [LICENSE](./LICENSE).

Part of the [365-template series](https://templates.allanninal.dev/) — Day 8 of 365 free, MIT-licensed static website templates.
