# Day 19 — Podcast Site: RESEARCH.md

## Differentiation mandate

Day 19 must be visually distinct from all prior 18 templates:
- Day 1 developer-portfolio: dark + indigo, dev-focused
- Day 2 saas-landing: light + violet/cyan, bento grid
- Day 3 startup-waitlist: dark + lime, single-screen
- Day 4 link-in-bio: light coral, 480px single-column
- Day 5 personal-blog: forest green, Newsreader serif, light
- Day 6 documentation-site: cobalt on white, Starlight
- Day 7 mobile-app-landing: light + magenta, Manrope
- Day 8 agency-studio: charcoal + burnt orange, General Sans + Fraunces
- Day 9 resume-cv: white + sepia, Source Serif 4 + Inter Tight
- Day 10 open-source-project: teal on near-black, Outfit + Geist Mono
- Day 11 newsletter-landing: oxblood + cream, Lora + Work Sans
- Day 12 coming-soon: aubergine + warm-white, Fraunces + Space Grotesk
- Day 13 ai-startup-landing: dark + amber, Bricolage Grotesque + JetBrains Mono
- Day 14 indie-hacker-portfolio: warm paper + electric blue, Plus Jakarta Sans + JetBrains Mono
- Day 15 designer-portfolio: terracotta + parchment, Cormorant Garamond + Archivo Black
- Day 16 photographer-portfolio: pure-white + slate-indigo, DM Sans
- Day 17 writer-author-site: ivory + Prussian blue, Playfair Display + Crimson Pro
- Day 18 course-cohort-landing: warm cream + deep teal, Spectral + Public Sans

## Chosen visual register: Studio-Warm / Broadcast Authority

**Core concept:** The podcast site that feels like the interior of a well-appointed recording studio. Rich, warm, tactile. Think Darknet Diaries meets the Acquired podcast — serious content authority combined with approachable warmth. NOT a generic SaaS page with a play button. The palette, typography, and layout communicate "this show is worth your commute."

### Palette

- **Background:** `#1C1310` — deep warm near-black (studio dark mode; different from Day 1's `#0F0F1A` indigo-dark, Day 13's `#0A0A0A` cool near-black)
- **Surface:** `#261A14` — slightly lighter warm near-black for cards/sections
- **Surface-raised:** `#321F17` — card hover, elevated surfaces
- **Accent:** `#C0392B` — burgundy/crimson red. Untaken in all 18 prior days. On the warm near-black background it reads as broadcast authority — microphone on, recording in progress. Completely distinct from: magenta (7), coral (4), burnt orange (8), oxblood (11), terracotta (15).
- **Accent light:** `#F5C6C0` — pale blush tint for small badges, waveform decorations, active states
- **Sand:** `#E8D5C0` — warm sand/parchment for body text and secondary headings. Gives the text a warm, analog feel rather than cold white.
- **Sand-muted:** `#A89080` — muted warm mid-tone for episode numbers, timestamps, secondary labels
- **Border:** `#3D2820` — subtle warm border, barely visible

**Rationale for burgundy on warm near-black:** This combination is completely untaken in the 18 prior days. Prior dark-palette templates used indigo (Day 1), lime (Day 3), teal (Day 10), amber (Day 13), electric blue (Day 14). Burgundy/crimson on warm dark background is the classic "recording studio" or "radio broadcast" aesthetic — Darknet Diaries, Hardcore History, Acquired all lean into this warm-dark register. The sand body text color is also novel — prior templates using dark backgrounds have used white or light gray for body text.

### Typography

- **Display headings:** **DM Serif Display** (Google Fonts, `@fontsource/dm-serif-display`) — high-contrast editorial serif with elegant ink traps. Excellent at large display sizes. Completely untaken in all 18 prior days (related DM Sans was used in Day 16 for the photographer portfolio body — but DM Serif Display is a completely different face with serif contrast and display character). At large sizes on the warm-dark background, it reads as authoritative and credible without being cold.
- **Body / UI:** **Inter** (already in the repo for many templates, but this is used as BODY alongside DM Serif Display as the display face — the DM Serif Display is the visual differentiator). At body sizes on the warm sand background color, Inter is clean and readable.
- **Mono (timestamps, episode numbers):** System `font-mono` stack — no extra font

**Contrast checks (WCAG AA minimum 4.5:1 for normal text, 3:1 for large text):**
- Sand `#E8D5C0` on near-black `#1C1310`: 10.8:1 — AAA ✓
- Accent `#C0392B` on near-black `#1C1310`: 3.2:1 — borderline; use only for large headings / decorative elements, NOT body text. For interactive elements use `#E84040` (lighter red) which gives 4.7:1 on near-black ✓
- Sand `#E8D5C0` on surface `#261A14`: 10.2:1 — AAA ✓
- White `#FFFFFF` on accent `#C0392B`: 4.6:1 — AA ✓
- Near-black `#1C1310` on accent-light `#F5C6C0`: 11.2:1 — AAA ✓
- Sand-muted `#A89080` on near-black `#1C1310`: 4.8:1 — AA ✓

**IMPORTANT color contrast rule:** The accent `#C0392B` must NEVER be used for body text. Only use for:
1. Large display headings (>24px bold) where 3:1 ratio satisfies WCAG AA for large text
2. Decorative SVG elements
3. Accent borders/lines (non-text)
For accent-colored interactive text (links, buttons labels over light bg), use full-opacity sand `#E8D5C0`.
For button backgrounds, use accent-bright `#E84040` (4.7:1 on near-black) or white text on `#C0392B` (4.6:1).

**Density profile:** High-editorial dark. Wide sections with generous spacing. Episode cards have compact density. The hero feels expansive; the episode list feels productive.

## Persona & Show

**Show:** **The Deep Dive** — A weekly technology and ideas podcast. Conversations with the builders, thinkers, and operators reshaping how the world works. Independent. No VC funding. No ad network. Just good conversations.

**Hosts:**
1. **Marcus Chen** — Former tech journalist (WIRED, MIT Technology Review). Independent journalist and podcaster since 2018. Deep interest in how technology intersects with power, labor, and democracy.
2. **Priya Mehta** — Product strategist and investor. Ex-Google, ex-Stripe. Now advising early-stage founders. Co-hosts to bring the operator/investor lens to Marcus's journalism angle.

**Show facts:**
- Episodes: 187 published (weekly since 2020)
- Avg duration: ~90 minutes per episode
- Platforms: Apple Podcasts, Spotify, Overcast, Pocket Casts, YouTube, RSS
- Downloads: 2.4M+ total downloads, ~50K per episode
- Newsletter: "The Brief" — weekly reading list linked to each episode
- Support: Ko-fi (no Patreon, no GitHub Sponsors — Ko-fi only per repo conventions)

**Recent episodes (6 episodes, realistic show notes):**

1. **EP 187: "The AGI Timeline Debate — What Researchers Actually Believe"**
   - Guest: Dr. Aisha Patel (AI safety researcher, MIT)
   - Duration: 1h 42m
   - Published: May 1, 2026
   - Topics: AGI timelines, alignment research, institutional risk
   - Show notes excerpt: "We talk to someone actually in the room at the frontier labs about what researchers privately believe versus what gets said publicly."

2. **EP 186: "Inside the Builder Economy — How Microtools Are Eating Software"**
   - Guest: Tom Ridgeway (founder, Buildspace)
   - Duration: 1h 18m
   - Published: April 24, 2026
   - Topics: no-code tools, builder economy, bootstrapping

3. **EP 185: "The Infrastructure Bet — Why the Next Tech Giant May Be Boring"**
   - Guest: Rena Johansson (infrastructure investor, Sequoia)
   - Duration: 1h 55m
   - Published: April 17, 2026
   - Topics: infrastructure investing, cloud costs, boring tech

4. **EP 184: "Trust by Design — Building Products That Don't Manipulate"**
   - Guest: Dr. Jonas Weber (design ethics researcher, Stanford HCI)
   - Duration: 1h 28m
   - Published: April 10, 2026
   - Topics: dark patterns, design ethics, regulation

5. **EP 183: "The Climate Tech Reality Check"**
   - Guest: Fatima Al-Hassan (climate tech founder, raised $40M Series B)
   - Duration: 1h 35m
   - Published: April 3, 2026
   - Topics: climate tech, venture capital, scaling hardware

6. **EP 182: "Remote Work 5 Years Later — What Actually Changed"**
   - Guest: Dr. Priya Sundar (organizational psychologist, MIT Sloan)
   - Duration: 1h 12m
   - Published: March 27, 2026
   - Topics: remote work research, productivity, culture

## Sections architecture

1. **SiteHeader** — Show name logotype ("The Deep Dive" in DM Serif Display), anchor links: Episodes, Hosts, Subscribe, Sponsors, FAQ. Sticky with scroll-aware opacity. Podcast links (Apple/Spotify icons).
2. **Hero** — Full-width hero. Show tagline large in DM Serif Display. Latest episode (EP 187) as featured card with: guest name, episode title, duration, publish date, HTML5 audio player with a CC-licensed placeholder mp3. Two CTAs: "Listen to Latest" (triggers audio player) + "All Episodes ↓".
3. **SubscribeBar** — Horizontal strip: "Listen wherever you get podcasts" + platform buttons (Apple Podcasts, Spotify, Overcast, Pocket Casts, YouTube, RSS). Each with icon + label.
4. **EpisodeList** — Last 6 episodes grid (2-col desktop, 1-col mobile). Each card: EP number, guest, title, duration, date, 1-line topic summary, "Show notes" link + play button (HTML5 audio).
5. **Hosts** — Two-column host bios. CSS avatar circles (no real images). Name, role, bio, social links (LinkedIn, Twitter/X handle).
6. **Sponsors** — "This show is brought to you by..." 2 rotating sponsors (fictional: Raycast, Tuple) with logo treatment + 1-sentence description of what they do. Below: "Want to sponsor? See our media kit" CTA.
7. **Testimonials / Press** — Pull quotes from 4 fictional listeners + 2 press mentions (The Atlantic, Nieman Lab). Episode download stat (2.4M+). Apple Podcasts rating (4.9/5, 3,200+ reviews).
8. **Newsletter** — "The Brief" weekly newsletter. Buttondown signup. "Each week we send the reading list from the latest episode — 5 links, no filler."
9. **FAQ** — 8 questions: how to subscribe, transcript policy, guest application, ad-free version, live recordings, episode frequency, how long the back catalog is, how to support the show.
10. **SupportBar** — Ko-fi "Support the show" block. Clean, no pressure. "Independent podcasting isn't free — your support keeps us ad-light and honest."
11. **SiteFooter** — Show name, copyright, LinkedIn (primary) + email (secondary), Ko-fi link, RSS link, all platform links.
12. **TemplateInfo** — Standard banner pointing to template hub.

## Audio placeholder strategy

Use a tiny (2–5 second) silent MP3 stub committed at `public/audio/episode-preview.mp3`. This is the pattern used in voice-over/audio demos throughout the web — a short stub that proves the audio element works without serving a large binary. Document in README.

The HTML5 `<audio>` element:
```html
<audio controls preload="none">
  <source src="/podcast-site/audio/episode-preview.mp3" type="audio/mpeg" />
  Your browser does not support HTML5 audio.
</audio>
```

The `preload="none"` ensures Lighthouse doesn't penalize for unused audio data.

## Schema.org

JSON-LD embedded in `<head>`:

1. **PodcastSeries:**
   - `@type`: `PodcastSeries`
   - `name`: "The Deep Dive"
   - `description`: show description
   - `url`: canonical URL
   - `webFeed`: RSS feed URL
   - `author`: `Person` array (Marcus Chen, Priya Mehta)
   - `numberOfEpisodes`: 187
   - `startDate`: "2020-01-15"
   - `inLanguage`: "en"

2. **PodcastEpisode** (latest, EP 187 only — don't enumerate all 187):
   - `@type`: `PodcastEpisode`
   - `name`: episode title
   - `episodeNumber`: 187
   - `partOfSeries`: reference to PodcastSeries
   - `datePublished`: "2026-05-01"
   - `duration`: "PT1H42M"
   - `description`: show notes excerpt
   - `associatedMedia`: `AudioObject` with placeholder URL

3. **Person** for each host (Marcus Chen, Priya Mehta)

4. **FAQPage** for the FAQ section

## Technical decisions

- Astro 4 + Tailwind 3 (consistent with roadmap stack)
- `@fontsource/dm-serif-display` (self-hosted for Lighthouse perf)
- Inter via `@fontsource/inter` (consistent with roadmap, subset: 400/500/600 weights)
- Audio: `<audio controls preload="none">` — no JS player library, just native HTML5
- All data in `src/data/` TypeScript files: episodes.ts, hosts.ts, sponsors.ts, faq.ts, config.ts
- No JS beyond: mobile nav toggle + audio player (100% native HTML5), no frameworks
- OG image: og-image.svg + og-image.png committed to /public/
- Sitemap via @astrojs/sitemap
- robots.txt with RSS feed reference
- Full WCAG AA throughout — NO accent color `#C0392B` on small body text; use sand `#E8D5C0` for all body text; reserve burgundy for decorative large headings only

## Differentiation table

| Feature | Day 19 (podcast-site) | Day 5 (blog) | Day 17 (writer) | Day 11 (newsletter) |
|---------|----------------------|--------------|-----------------|---------------------|
| Mode | Dark-default studio | Light, editorial | Light literary | Light editorial |
| Hero anchor | Featured episode + audio player | Latest post | Latest book | Newsletter signup |
| Unique component | HTML5 audio player | None | CSS book covers | Sample issues |
| Subscribe strip | Apple/Spotify/Overcast/Pocket Casts/YouTube/RSS | RSS only | Newsletter only | Email signup |
| Hosts section | 2-host bios | None | Author bio | None |
| Sponsors section | Media kit CTA | None | None | None |
| Schema.org | PodcastSeries + PodcastEpisode + Person + FAQPage | Blog/Article | Person + Book | Periodical |
| Palette | Burgundy/crimson on warm near-black + sand text | Forest green, light bg | Prussian blue, ivory | Oxblood, cream |
| Display font | DM Serif Display | Newsreader | Playfair Display | Lora |
| Dark mode | Yes (dark-default) | Light-only | Light-only | Light-only |

The broadcast-studio dark aesthetic, HTML5 audio player, subscribe-across-platforms bar, PodcastSeries + PodcastEpisode schema, and DM Serif Display on warm dark background are all first uses in this roadmap.
