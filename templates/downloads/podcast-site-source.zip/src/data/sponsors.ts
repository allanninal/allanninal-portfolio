// Podcast Site — sponsor data
// Replace with real sponsor copy and links

export interface Sponsor {
  name: string;
  description: string;
  url: string;
  logoInitials: string; // Text placeholder for CSS logo
}

export const sponsors: Sponsor[] = [
  {
    name: 'Raycast',
    description:
      'The productivity tool that replaces your Mac\'s Spotlight. Used by 200,000+ developers and knowledge workers. Raycast sponsors this episode because they believe in tools that respect your time.',
    url: 'https://raycast.com',
    logoInitials: 'RC',
  },
  {
    name: 'Tuple',
    description:
      'Remote pair programming built for real engineers. Ultra-low latency, high resolution, built-in annotation. If your team pair programs remotely, Tuple is the tool that doesn\'t make you feel like you\'re fighting the software.',
    url: 'https://tuple.app',
    logoInitials: 'TP',
  },
];

export const sponsorshipCta = {
  heading: 'Want to sponsor The Deep Dive?',
  body: 'We reach 50,000+ technology professionals per episode. Our sponsors are tools and services that our audience actually uses. No spray-and-pray ad networks.',
  mediaKitUrl: '#',
  ctaLabel: 'View our media kit',
};
