// Podcast Site — FAQ data

export interface FaqItem {
  question: string;
  answer: string;
}

export const faq: FaqItem[] = [
  {
    question: 'How often do you publish?',
    answer:
      'New episodes drop every Thursday. We\'ve published weekly since January 2020 — 187 episodes without missing a week. Subscribe on your preferred platform so you never miss one.',
  },
  {
    question: 'How long are the episodes?',
    answer:
      'Typically 75 to 110 minutes. We don\'t believe in cutting conversations short to hit an arbitrary runtime. If the conversation has more to say, we let it breathe. Episode length is always listed on each show note page so you can plan accordingly.',
  },
  {
    question: 'Where can I listen?',
    answer:
      'You can listen on Apple Podcasts, Spotify, Overcast, Pocket Casts, YouTube, or directly via our RSS feed. All platforms are listed in the "Listen Everywhere" section above. RSS listeners get the cleanest experience — no algorithmic feed, just the episodes in order.',
  },
  {
    question: 'Do you offer transcripts?',
    answer:
      'Yes. Full AI-assisted transcripts are available for every episode from EP 100 onwards. You\'ll find the transcript link on each episode\'s show notes page. We\'re working backwards through the back catalog — EP 1–99 will be available by mid-2026.',
  },
  {
    question: 'How do I suggest a guest?',
    answer:
      'We get a lot of guest suggestions and genuinely read every one. Send suggestions to our contact email with "Guest Idea" in the subject line. We look for guests with a specific story to tell or a counterintuitive perspective on a topic we haven\'t covered. Industry status is less important than intellectual honesty.',
  },
  {
    question: 'Is there an ad-free version?',
    answer:
      'The show is nearly ad-free already — we have a maximum of two sponsors per episode, always products we\'ve personally used or vetted. Supporting us on Ko-fi helps us stay ad-light and gives us the independence to cover topics without worrying about sponsor relationships.',
  },
  {
    question: 'Do you do live recordings?',
    answer:
      'Occasionally. We do live episodes at tech conferences roughly twice a year. These are always announced on our newsletter (The Brief) first. Join the mailing list to get early access to live event tickets.',
  },
  {
    question: 'How can I support the show?',
    answer:
      'Three ways: (1) Subscribe and leave a review on Apple Podcasts — it helps discoverability more than you\'d think. (2) Share an episode with one person who you think would genuinely benefit from it. (3) Support on Ko-fi if you want to contribute financially — every contribution directly funds production costs.',
  },
];
