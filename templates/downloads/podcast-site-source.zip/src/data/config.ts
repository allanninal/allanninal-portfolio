// Podcast Site — global config
// Edit this file to customize for your show

export const podcast = {
  name: 'The Deep Dive',
  tagline: 'Conversations with the builders, thinkers, and operators reshaping how the world works.',
  description:
    'The Deep Dive is a weekly technology and ideas podcast. We go long-form with researchers, founders, investors, and writers to understand the forces shaping our world. Independent. No VC funding. No ad network. Just good conversations.',
  shortDescription:
    'Weekly long-form conversations at the intersection of technology, ideas, and the future. 187 episodes and counting.',
  episodeCount: 187,
  frequency: 'Weekly',
  avgDuration: '~90 minutes',
  startDate: '2020-01-15',
  language: 'en',
  // Platform links — replace with real URLs
  platforms: {
    apple:      'https://podcasts.apple.com/podcast/the-deep-dive',
    spotify:    'https://open.spotify.com/show/the-deep-dive',
    overcast:   'https://overcast.fm/itunes/the-deep-dive',
    pocketcasts:'https://pocketcasts.com/podcast/the-deep-dive',
    youtube:    'https://www.youtube.com/@thedeepDivePodcast',
    rss:        '/podcast-site/feed.xml',
  },
  stats: {
    totalDownloads: '2.4M+',
    perEpisodeDownloads: '~50K',
    applePodcastsRating: '4.9',
    applePodcastsReviews: '3,200+',
  },
};

export const host = {
  name: 'Allan Ninal',
  email: 'landix.ninal@gmail.com',
  socials: {
    linkedin: 'https://www.linkedin.com/in/allanninal',
    kofi: 'https://ko-fi.com/allanninal',
  },
};

export const newsletter = {
  name: 'The Brief',
  description:
    'Each week we send the reading list from the latest episode — 5 links, no filler. Join 18,000+ listeners who read it every Sunday.',
  buttondownUrl: 'https://buttondown.email/thedeepDive',
};

export const kofi = {
  url: 'https://ko-fi.com/allanninal',
  label: 'Support on Ko-fi',
};
