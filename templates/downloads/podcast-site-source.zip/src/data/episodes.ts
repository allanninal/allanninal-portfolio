// Podcast Site — episode data
// Each episode maps to a card in the episode list

export interface Episode {
  number: number;
  title: string;
  guest: string;
  guestRole: string;
  duration: string; // human-readable e.g. "1h 42m"
  durationISO: string; // ISO 8601 duration e.g. "PT1H42M"
  publishedDate: string; // YYYY-MM-DD
  publishedDisplay: string; // human-readable
  topics: string[];
  summary: string;
  showNotesUrl: string; // placeholder
  audioUrl: string; // placeholder — all point to the same stub mp3
  featured?: boolean;
}

export const episodes: Episode[] = [
  {
    number: 187,
    title: 'The AGI Timeline Debate — What Researchers Actually Believe',
    guest: 'Dr. Aisha Patel',
    guestRole: 'AI Safety Researcher, MIT',
    duration: '1h 42m',
    durationISO: 'PT1H42M',
    publishedDate: '2026-05-01',
    publishedDisplay: 'May 1, 2026',
    topics: ['AI Safety', 'AGI Timelines', 'Alignment Research'],
    summary:
      'We talk to someone actually in the room at the frontier labs about what researchers privately believe versus what gets said publicly. An honest conversation about timelines, risk models, and what "alignment" even means.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
    featured: true,
  },
  {
    number: 186,
    title: 'Inside the Builder Economy — How Microtools Are Eating Software',
    guest: 'Tom Ridgeway',
    guestRole: 'Founder, Buildspace',
    duration: '1h 18m',
    durationISO: 'PT1H18M',
    publishedDate: '2026-04-24',
    publishedDisplay: 'Apr 24, 2026',
    topics: ['Builder Economy', 'No-Code Tools', 'Bootstrapping'],
    summary:
      'The tools used to build software are themselves becoming products. Tom Ridgeway explains why the microtools wave isn\'t just a productivity story — it\'s a structural shift in who can build companies.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
  },
  {
    number: 185,
    title: 'The Infrastructure Bet — Why the Next Tech Giant May Be Boring',
    guest: 'Rena Johansson',
    guestRole: 'Infrastructure Investor, Sequoia',
    duration: '1h 55m',
    durationISO: 'PT1H55M',
    publishedDate: '2026-04-17',
    publishedDisplay: 'Apr 17, 2026',
    topics: ['Infrastructure', 'Venture Capital', 'Cloud Costs'],
    summary:
      'The most durable tech businesses of the next decade won\'t have flashy consumer brands. Rena Johansson makes the case for infrastructure as the highest-conviction investment thesis in tech right now.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
  },
  {
    number: 184,
    title: 'Trust by Design — Building Products That Don\'t Manipulate',
    guest: 'Dr. Jonas Weber',
    guestRole: 'Design Ethics Researcher, Stanford HCI',
    duration: '1h 28m',
    durationISO: 'PT1H28M',
    publishedDate: '2026-04-10',
    publishedDisplay: 'Apr 10, 2026',
    topics: ['Design Ethics', 'Dark Patterns', 'Regulation'],
    summary:
      'A researcher who has spent a decade studying how interface design manipulates behavior explains what the industry gets wrong — and what "ethical design" actually requires in practice.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
  },
  {
    number: 183,
    title: 'The Climate Tech Reality Check',
    guest: 'Fatima Al-Hassan',
    guestRole: 'Climate Tech Founder, Series B',
    duration: '1h 35m',
    durationISO: 'PT1H35M',
    publishedDate: '2026-04-03',
    publishedDisplay: 'Apr 3, 2026',
    topics: ['Climate Tech', 'Hardware Startups', 'Venture Capital'],
    summary:
      'After raising $40M to build a carbon capture hardware company, Fatima Al-Hassan gives an unvarnished view of what climate tech actually looks like from inside a scaling hardware startup.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
  },
  {
    number: 182,
    title: 'Remote Work 5 Years Later — What Actually Changed',
    guest: 'Dr. Priya Sundar',
    guestRole: 'Organizational Psychologist, MIT Sloan',
    duration: '1h 12m',
    durationISO: 'PT1H12M',
    publishedDate: '2026-03-27',
    publishedDisplay: 'Mar 27, 2026',
    topics: ['Remote Work', 'Productivity Research', 'Organizational Culture'],
    summary:
      'Five years after the forced experiment, what does the research actually show? Dr. Sundar separates the science from the narrative on hybrid work, productivity, and what we\'re still getting wrong.',
    showNotesUrl: '#episodes',
    audioUrl: 'audio/episode-preview.mp3',
  },
];

export const featuredEpisode = episodes.find(ep => ep.featured) ?? episodes[0];
