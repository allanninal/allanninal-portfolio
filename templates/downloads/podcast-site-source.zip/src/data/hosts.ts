// Podcast Site — host bios

export interface Host {
  name: string;
  role: string;
  bio: string;
  socials: {
    linkedin?: string;
    twitter?: string;
    website?: string;
  };
  initials: string; // for CSS avatar
  accentColor: string; // CSS class suffix for avatar background
  avatar?: string; // Pro: filename (no ext) in public/images/pro/hosts/
}

export const hosts: Host[] = [
  {
    name: 'Marcus Chen',
    role: 'Co-host & Executive Producer',
    bio: 'Former technology journalist with bylines in WIRED, MIT Technology Review, and The Atlantic. Marcus has been reporting on the intersection of technology and society for over a decade. He started The Deep Dive in 2020 to have the longer, more honest conversations that print journalism wouldn\'t allow. His beat: power, labor, and the political economy of the internet.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/marcuschen',
      twitter:  'https://x.com/marcuschen',
    },
    initials: 'MC',
    accentColor: 'accent',
    avatar: 'marcus-chen',
  },
  {
    name: 'Priya Mehta',
    role: 'Co-host & Operator Perspective',
    bio: 'Product strategist and early-stage investor. Priya spent seven years inside Google and Stripe building products used by millions of people before leaving to advise founders. She brings the operator and investor lens to every conversation on The Deep Dive — asking the questions that only someone who has shipped at scale thinks to ask. She joined the show in Season 2 and hasn\'t left.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/priyamehta',
      twitter:  'https://x.com/priyamehta',
    },
    initials: 'PM',
    accentColor: 'sand',
    avatar: 'priya-mehta',
  },
];
