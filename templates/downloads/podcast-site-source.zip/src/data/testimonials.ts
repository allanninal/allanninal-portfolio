// Podcast Site — listener quotes and press mentions

export interface ListenerQuote {
  name: string;
  role: string;
  quote: string;
}

export interface PressMention {
  outlet: string;
  quote: string;
  url: string;
  initials: string;
}

export const listenerQuotes: ListenerQuote[] = [
  {
    name: 'Sarah Kim',
    role: 'Staff Engineer, Vercel',
    quote:
      'The only podcast where I consistently learn something I didn\'t know I needed to know. The AGI episode with Dr. Patel genuinely changed how I think about where this is all going.',
  },
  {
    name: 'James Okafor',
    role: 'Founder, Series A',
    quote:
      'I\'ve listened to every episode since 2021. The infrastructure episode with Rena Johansson reframed how I pitch our company to investors. Real ROI from a podcast.',
  },
  {
    name: 'Leila Ahmadi',
    role: 'Senior PM, Stripe',
    quote:
      'Marcus and Priya ask the questions that journalists miss and investors won\'t. The design ethics episode should be required listening for every PM.',
  },
  {
    name: 'Daniel Park',
    role: 'Engineering Manager, Linear',
    quote:
      'I queue up an episode every Sunday morning. 90 minutes of actual depth, not sound bites. It\'s the one thing I do for myself each week that makes me a better thinker.',
  },
];

export const pressMentions: PressMention[] = [
  {
    outlet: 'The Atlantic',
    quote:
      '"One of the most consistently rigorous technology podcasts in production. The Deep Dive treats its audience like adults."',
    url: '#',
    initials: 'TA',
  },
  {
    outlet: 'Nieman Lab',
    quote:
      '"A model for what independent long-form audio journalism can look like when freed from the constraints of broadcast time and ad network mandates."',
    url: '#',
    initials: 'NL',
  },
];
