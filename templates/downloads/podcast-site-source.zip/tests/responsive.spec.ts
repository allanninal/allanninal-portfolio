import { test, expect } from '@playwright/test';

const viewports = [
  { name: 'mobile-sm',  width: 375,  height: 812  },
  { name: 'mobile-lg',  width: 430,  height: 932  },
  { name: 'tablet',     width: 768,  height: 1024 },
  { name: 'desktop',    width: 1280, height: 800  },
  { name: 'wide',       width: 1440, height: 900  },
];

for (const vp of viewports) {
  test(`homepage renders without overflow at ${vp.name} (${vp.width}px)`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.goto('/');

    // Check for horizontal overflow
    const hasHorizontalOverflow = await page.evaluate(() => {
      return document.documentElement.scrollWidth > document.documentElement.clientWidth;
    });
    expect(hasHorizontalOverflow).toBe(false);

    // Core sections are visible
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('#episodes')).toBeVisible();
  });

  test(`navigation is accessible at ${vp.name}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.goto('/');

    // Site header is always present
    const header = page.locator('body > header');
    await expect(header).toBeVisible();

    if (vp.width < 768) {
      // Mobile toggle should exist and be visible
      const toggle = page.locator('#nav-toggle');
      await expect(toggle).toBeVisible();
    }
  });

  test(`audio player renders at ${vp.name}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.goto('/');
    // Featured audio player
    const audio = page.locator('#featured-audio');
    await expect(audio).toBeAttached();
  });
}
