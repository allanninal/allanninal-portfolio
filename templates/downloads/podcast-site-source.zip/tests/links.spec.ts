import { test, expect } from '@playwright/test';

test.describe('Podcast Site — links', () => {
  test('all internal links resolve without 404', async ({ page }) => {
    await page.goto('/');
    // Collect all internal href anchors
    const anchors = await page.locator('a[href^="#"]').all();
    const hrefs = await Promise.all(anchors.map(a => a.getAttribute('href')));

    const sectionIds = hrefs
      .filter(Boolean)
      .filter(h => h && h.length > 1)  // Skip bare "#"
      .map(h => h!.replace('#', ''));

    for (const id of sectionIds) {
      const el = page.locator(`#${id}`);
      const count = await el.count();
      expect(count, `Section #${id} not found`).toBeGreaterThan(0);
    }
  });

  test('external links have rel="noopener noreferrer"', async ({ page }) => {
    await page.goto('/');
    const externalLinks = await page.locator('a[target="_blank"]').all();
    for (const link of externalLinks) {
      const rel = await link.getAttribute('rel');
      expect(rel, `External link missing rel="noopener noreferrer"`).toContain('noopener');
    }
  });

  test('sitemap link in head resolves', async ({ page }) => {
    await page.goto('/');
    const sitemapHref = await page.locator('link[rel="sitemap"]').getAttribute('href');
    expect(sitemapHref).toBeTruthy();
    const response = await page.request.get(sitemapHref!);
    expect(response.status()).toBe(200);
  });

  test('favicon loads', async ({ page }) => {
    await page.goto('/');
    const faviconHref = await page.locator('link[rel="icon"][type="image/svg+xml"]').getAttribute('href');
    expect(faviconHref).toBeTruthy();
    const response = await page.request.get(faviconHref!);
    expect(response.status()).toBe(200);
  });

  test('audio stub file is accessible', async ({ page }) => {
    await page.goto('/');
    const firstSource = await page.locator('#featured-audio source').getAttribute('src');
    expect(firstSource).toBeTruthy();
    const response = await page.request.get(firstSource!);
    expect(response.status()).toBe(200);
  });
});
