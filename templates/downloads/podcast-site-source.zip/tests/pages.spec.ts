import { test, expect } from '@playwright/test';

test.describe('Podcast Site — pages', () => {
  test('homepage loads with correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/The Deep Dive/);
  });

  test('homepage has hero section with show title', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const text = await h1.textContent();
    expect(text).toMatch(/Deep Dive/);
  });

  test('subscribe section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#subscribe');
    await expect(section).toBeVisible();
  });

  test('episodes section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#episodes');
    await expect(section).toBeVisible();
  });

  test('hosts section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#hosts');
    await expect(section).toBeVisible();
  });

  test('sponsors section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#sponsors');
    await expect(section).toBeVisible();
  });

  test('testimonials section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#testimonials');
    await expect(section).toBeVisible();
  });

  test('newsletter section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#newsletter');
    await expect(section).toBeVisible();
  });

  test('faq section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#faq');
    await expect(section).toBeVisible();
  });

  test('support section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#support');
    await expect(section).toBeVisible();
  });

  test('sitemap exists', async ({ page }) => {
    const response = await page.request.get('/sitemap-index.xml');
    expect(response.status()).toBe(200);
  });

  test('robots.txt exists', async ({ page }) => {
    const response = await page.request.get('/robots.txt');
    expect(response.status()).toBe(200);
  });

  test('og-image exists', async ({ page }) => {
    const response = await page.request.get('/og-image.png');
    expect(response.status()).toBe(200);
  });

  test('footer is present', async ({ page }) => {
    await page.goto('/');
    const footer = page.locator('body > footer');
    await expect(footer).toBeAttached();
  });

  test('page has canonical URL in head', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('page has OG meta tags', async ({ page }) => {
    await page.goto('/');
    const ogTitle = await page.locator('meta[property="og:title"]').getAttribute('content');
    expect(ogTitle).toMatch(/The Deep Dive/);
  });

  test('JSON-LD PodcastSeries schema is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasPodcastSeries = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('PodcastSeries')) {
        hasPodcastSeries = true;
        break;
      }
    }
    expect(hasPodcastSeries).toBe(true);
  });

  test('JSON-LD PodcastEpisode schema is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasPodcastEpisode = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('PodcastEpisode')) {
        hasPodcastEpisode = true;
        break;
      }
    }
    expect(hasPodcastEpisode).toBe(true);
  });
});
