import { test, expect } from '@playwright/test';

test.describe('Podcast Site — interactions', () => {
  test('mobile nav toggles open and closed', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');

    const toggle = page.locator('#nav-toggle');
    const menu   = page.locator('#mobile-menu');

    // Initially hidden
    const isHiddenInitially = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenInitially).toBe(true);

    // Open
    await toggle.click();
    await page.waitForTimeout(100);
    const isHiddenAfterOpen = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterOpen).toBe(false);

    // Close by clicking a link
    await menu.locator('a').first().click();
    const isHiddenAfterClose = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterClose).toBe(true);
  });

  test('CTA buttons are keyboard-navigable', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    const focusedElement = await page.evaluate(() => document.activeElement?.tagName);
    expect(['A', 'BUTTON', 'INPUT']).toContain(focusedElement);
  });

  test('FAQ items expand on click', async ({ page }) => {
    await page.goto('/');
    const faqSection = page.locator('#faq');
    await faqSection.scrollIntoViewIfNeeded();

    const firstDetails = faqSection.locator('details').first();
    const firstSummary = firstDetails.locator('summary');

    // Initially closed
    const isOpen = await firstDetails.evaluate(el => (el as HTMLDetailsElement).open);
    expect(isOpen).toBe(false);

    // Click to open
    await firstSummary.click();
    await page.waitForTimeout(100);
    const isOpenAfterClick = await firstDetails.evaluate(el => (el as HTMLDetailsElement).open);
    expect(isOpenAfterClick).toBe(true);
  });

  test('featured audio player element exists with valid src', async ({ page }) => {
    await page.goto('/');
    const audioPlayer = page.locator('#featured-audio');
    await expect(audioPlayer).toBeAttached();

    // Check audio element has a source
    const audioSrc = await page.locator('#featured-audio source').getAttribute('src');
    expect(audioSrc).toBeTruthy();
    expect(audioSrc).toMatch(/\.mp3$/);
  });

  test('audio player in episode list exists', async ({ page }) => {
    await page.goto('/');
    const episodesSection = page.locator('#episodes');
    await episodesSection.scrollIntoViewIfNeeded();

    // At least one audio element in the episode list
    const audioPlayers = episodesSection.locator('audio');
    const count = await audioPlayers.count();
    expect(count).toBeGreaterThan(0);
  });

  test('audio player source points to mp3 file', async ({ page }) => {
    await page.goto('/');
    const episodesSection = page.locator('#episodes');
    await episodesSection.scrollIntoViewIfNeeded();

    const firstAudio = episodesSection.locator('audio').first();
    const src = await firstAudio.locator('source').getAttribute('src');
    expect(src).toMatch(/episode-preview\.mp3$/);
  });

  test('episode list shows 6 episode cards', async ({ page }) => {
    await page.goto('/');
    const episodesSection = page.locator('#episodes');
    await episodesSection.scrollIntoViewIfNeeded();
    const articles = episodesSection.locator('article');
    await expect(articles).toHaveCount(6);
  });

  test('subscribe bar has platform links', async ({ page }) => {
    await page.goto('/');
    const subscribeSection = page.locator('#subscribe');
    await subscribeSection.scrollIntoViewIfNeeded();
    const platformLinks = subscribeSection.locator('a');
    const count = await platformLinks.count();
    expect(count).toBeGreaterThanOrEqual(5); // Apple, Spotify, Overcast, Pocket Casts, YouTube, RSS
  });

  test('newsletter form has email input and submit button', async ({ page }) => {
    await page.goto('/');
    const newsletterSection = page.locator('#newsletter');
    await newsletterSection.scrollIntoViewIfNeeded();
    const emailInput = newsletterSection.locator('input[type="email"]');
    await expect(emailInput).toBeVisible();
    const submitBtn = newsletterSection.locator('button[type="submit"]');
    await expect(submitBtn).toBeVisible();
  });

  test('no JS console errors on load', async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // inject google.com frames/scripts that 403 or emit report-only CSP
    // notices under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const errors: string[] = [];
    page.on('console', msg => {
      if (msg.type() !== 'error') return;
      const text = msg.text();
      const u = msg.location()?.url || '';
      if (THIRD_PARTY.test(text) || THIRD_PARTY.test(u)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(text);
    });
    await page.goto('/');
    await page.waitForTimeout(500);
    expect(errors).toHaveLength(0);
  });
});
