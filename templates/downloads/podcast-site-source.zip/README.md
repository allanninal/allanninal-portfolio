# Podcast Site Template

**Day 19 / 365** — Part of the [365 Free Templates](https://templates.allanninal.dev) project.

A dark-mode podcast site template for independent shows. Built with Astro + Tailwind. Shows "The Deep Dive" — a weekly technology and ideas podcast — as a ready-to-customize persona.

**[Live Demo](https://templates.allanninal.dev/podcast-site/)** · **[Browse all 365 templates](https://templates.allanninal.dev)**

---

## What's in the box

| Section | Details |
|---|---|
| **Hero** | Show tagline, latest episode card, HTML5 audio player, platform quick-links |
| **Subscribe Bar** | Apple Podcasts · Spotify · Overcast · Pocket Casts · YouTube · RSS |
| **Episode List** | 6 recent episodes with guest, topics, duration, audio player, show notes link |
| **Hosts** | Two host bios with CSS avatar circles, LinkedIn + X links |
| **Sponsors** | 2 sponsor cards with media kit CTA |
| **Testimonials** | 4 listener quotes + 2 press mentions + download stats |
| **Newsletter** | "The Brief" — Buttondown signup form |
| **FAQ** | 8 questions with native `<details>`/`<summary>` disclosure |
| **Support** | Ko-fi support bar |

## Stack

- **Astro 4** (static output, no SSR)
- **Tailwind CSS 3**
- **DM Serif Display** (display headings) + **Inter** (body) via `@fontsource` (self-hosted)
- **Native HTML5 `<audio>`** — no JS audio library
- `@astrojs/sitemap` — auto-generated sitemap

## Palette

Dark studio aesthetic: warm near-black (`#1C1310`) + burgundy accent (`#9B1C1C`) + warm sand body text (`#E8D5C0`). Every color passes WCAG AA contrast at all text sizes.

## Schema.org

Includes four JSON-LD blocks in `<head>`:
- `PodcastSeries` — show metadata, host refs, episode count, RSS feed
- `PodcastEpisode` — latest episode with `AudioObject` media reference
- `Person` × 2 — each host
- `FAQPage` — FAQ section

## Audio placeholder

The template includes `public/audio/episode-preview.mp3` — a minimal silent stub (1.2 KB) that gives the HTML5 audio player a valid `src` without serving a large binary. Replace it with real episode clips when deploying your own show.

`preload="none"` on all `<audio>` elements prevents Lighthouse from penalizing unused audio data.

## Customize

### 1. Show identity

Edit `src/data/config.ts`:
```ts
export const podcast = {
  name: 'Your Show Name',
  tagline: 'Your tagline here.',
  platforms: {
    apple: 'https://podcasts.apple.com/...',
    spotify: 'https://open.spotify.com/...',
    // ...
  },
  // ...
};
```

### 2. Episodes

Edit `src/data/episodes.ts` — add/remove episode objects. Each episode has:
- `number`, `title`, `guest`, `guestRole`, `duration`, `durationISO`, `publishedDate`
- `topics[]`, `summary`, `audioUrl` (relative path to your mp3)
- `featured: true` on one episode to highlight it in the hero

### 3. Hosts

Edit `src/data/hosts.ts`. The CSS avatar initials are generated from the `initials` field.

### 4. Sponsors

Edit `src/data/sponsors.ts`. Replace with your actual sponsors (or remove the Sponsors component from `src/pages/index.astro`).

### 5. Newsletter

The form posts to Buttondown. Change `newsletter.buttondownUrl` in `config.ts` to your Mailchimp/ConvertKit/Buttondown/any endpoint.

### 6. Support link

Replace `kofi.url` in `config.ts` with your Ko-fi URL (or remove the SupportBar component).

## Quick start

```bash
git clone https://github.com/allanninal/templates
cd templates/podcast-site
npm install
npm run dev
```

## Deploy to GitHub Pages

```bash
# Fork or copy this template to your own repo
# Enable GitHub Pages: Repo Settings → Pages → Source: GitHub Actions
# The included .github/workflows/pages.yml handles build + deploy
```

Set environment variables in your repo secrets if using a custom domain:
- `PUBLIC_SITE_URL` — your full site URL, e.g. `https://mypodcast.com`
- `PUBLIC_BASE_PATH` — `/` for apex domain, or `/slug/` for a subdirectory

## License

MIT — free to use for any project, commercial or personal. Attribution appreciated but not required.

Built by [Allan Ninal](https://templates.allanninal.dev) as part of the 365-template challenge.
If this saves you time, consider [supporting on Ko-fi](https://ko-fi.com/allanninal).
