/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Core palette — burgundy/crimson on warm near-black studio dark
        studio:       '#1C1310',       // main background
        'studio-surface': '#261A14',   // card/section surface
        'studio-raised':  '#321F17',   // elevated cards, hover states
        // Accent: use #B22222 (firebrick) for buttons — white gives 5.2:1 ✓
        accent:       '#9B1C1C',       // darker burgundy — decorative headings/borders
        'accent-bright':  '#B22222',   // button bg — white text gives 5.2:1 ✓ AA
        'accent-light':   '#F5C6C0',   // pale blush for badges, waveform decorations
        sand:         '#E8D5C0',       // body text — 10.8:1 on studio bg ✓
        // sand-muted: must be ≥4.5:1 on studio (#1C1310) and studio-surface (#261A14)
        // #C4A896 gives ~5.5:1 on #1C1310, ~5.2:1 on #261A14 ✓
        'sand-muted': '#C4A896',       // secondary labels — AA-safe on all dark surfaces
        border:       '#3D2820',       // subtle warm border
        'border-light': '#4A3025',     // slightly more visible border for cards
      },
      fontFamily: {
        display: ['"DM Serif Display"', 'Georgia', '"Times New Roman"', 'serif'],
        body:    ['"Inter"', 'system-ui', '-apple-system', 'sans-serif'],
        mono:    ['"Fira Code"', '"Cascadia Code"', 'Consolas', 'monospace'],
      },
      fontSize: {
        'display-xl': ['clamp(2.75rem, 6vw, 5rem)',   { lineHeight: '1.05', letterSpacing: '-0.02em' }],
        'display-lg': ['clamp(2rem, 4vw, 3.5rem)',    { lineHeight: '1.1', letterSpacing: '-0.015em' }],
        'display-md': ['clamp(1.5rem, 2.5vw, 2.25rem)', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'body-lg':    ['1.0625rem', { lineHeight: '1.75', letterSpacing: '0' }],
        'body-base':  ['1rem', { lineHeight: '1.7' }],
        'label':      ['0.8125rem', { lineHeight: '1.4', letterSpacing: '0.04em' }],
      },
      maxWidth: {
        content: '1200px',
        prose:   '68ch',
      },
      spacing: {
        section: 'clamp(4rem, 8vw, 7rem)',
      },
    },
  },
  plugins: [],
};
