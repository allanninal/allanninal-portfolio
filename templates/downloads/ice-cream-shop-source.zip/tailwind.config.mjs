/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Pacifico', 'cursive'],
        body: ['Source Sans 3', 'system-ui', 'sans-serif'],
      },
      colors: {
        'scoop-pistachio':  '#2E7D52',
        'scoop-strawberry': '#C0304A',
        'scoop-vanilla':    '#FEF9F0',
        'scoop-mint':       '#EBF7F0',
        'scoop-raspberry':  '#8B1A2F',
      },
    },
  },
  plugins: [],
};
