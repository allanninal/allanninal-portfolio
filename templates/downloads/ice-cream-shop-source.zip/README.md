# Scooped — Ice Cream Shop Template (Day 40 of 365)

**Live demo:** https://templates.allanninal.dev/ice-cream-shop/

Artisan gelato and ice cream shop built with Astro + Tailwind CSS. Pistachio / strawberry / vanilla cream palette. Pacifico display + Source Sans 3 body — a cheerful, high-contrast combination not used in any prior day.

## What's inside

- Hero with SVG scoop illustration and real-time stat band
- Flavour of the Day feature section with rotating weekly scoops (6 cards)
- Full tabbed menu (Gelato / Ice Cream / Sorbet & Dairy-Free / Sundaes & Specials) — 22 items with price + dietary tags
- Multi-location section — 3 Austin shops with individual hours, address, phone, and Google Maps CTA
- Online order section (Square placeholder) per location
- Our Story section with founder bio, stats, and sourcing values
- Photo gallery — 6 SVG placeholder tiles (no external images needed)
- Private event & catering section with email CTA
- schema.org IceCreamShop + Menu + Person JSON-LD
- Google Analytics + AdSense (hub-gated via `PUBLIC_TEMPLATE_HUB_URL`)
- Download bar (TemplateInfo) — gated on hub URL, 3-button canonical pattern
- axe-core WCAG 2.1 AA clean · Lighthouse ≥ 95 on all four categories

## Design

| Attribute | Value |
|---|---|
| Palette | Pistachio #2E7D52 · Strawberry #C0304A · Vanilla #FEF9F0 · Mint Mist #EBF7F0 |
| Display font | Pacifico 400 |
| Body font | Source Sans 3 400/600/700 |
| Mode | Light only |
| Schema | IceCreamShop · Menu · Person |

## Quickstart

```bash
npm install
npm run dev
```

Open http://localhost:4321/

## Environment variables

Copy `.env.example` to `.env` and fill in your values:

```
PUBLIC_SITE_URL=https://your-site.com
PUBLIC_BASE_PATH=/ice-cream-shop/
PUBLIC_TEMPLATE_HUB_URL=   # leave blank — enables TemplateInfo + analytics only on author's deploy
```

## Deploy to GitHub Pages

```bash
npm run build
# dist/ → push to gh-pages branch, or use the included workflow
```

Set `PUBLIC_BASE_PATH=/ice-cream-shop/` (or `/` if deploying to root) in your CI environment.

## License

MIT — free to use, customize, and deploy. Attribution appreciated but not required.

Built by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · [landix.ninal@gmail.com](mailto:landix.ninal@gmail.com)
