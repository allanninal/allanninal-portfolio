import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Scooped/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero heading contains ice cream reference', async ({ page }) => {
  await page.goto('/');
  const heading = await page.locator('#hero-heading').textContent();
  expect(heading?.toLowerCase()).toMatch(/fresh|scoop|morning/i);
});

test('flavour of the day section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#flavour-of-the-day')).toBeVisible();
});

test('flavour of the day heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#fotd-heading')).toBeVisible();
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu-heading')).toBeVisible();
});

test('menu tabs exist and are interactive', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  const iceCreamTab = page.locator('[role="tab"]', { hasText: /ice cream/i });
  await iceCreamTab.click();
  expect(await iceCreamTab.getAttribute('aria-selected')).toBe('true');

  const iceCreamPanel = page.locator('[data-panel="ice-cream"]');
  await expect(iceCreamPanel).toBeVisible();
});

test('locations section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#locations')).toBeVisible();
});

test('locations heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#locations-heading')).toBeVisible();
});

test('order section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order')).toBeVisible();
});

test('order heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order-heading')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('story heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story-heading')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('gallery heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery-heading')).toBeVisible();
});

test('catering section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#catering')).toBeVisible();
});

test('catering heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#catering-heading')).toBeVisible();
});

test('shop name appears in page', async ({ page }) => {
  await page.goto('/');
  const content = await page.content();
  expect(content).toContain('Scooped');
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('a[href="#main-content"]');
  await expect(skipLink).toBeAttached();
});

test('navigation has accessible label', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('footer nav has accessible label', async ({ page }) => {
  await page.goto('/');
  const footerNav = page.locator('nav[aria-label="Footer navigation"]');
  await expect(footerNav).toBeVisible();
});

test('catering CTA link is present', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('#catering a[href*="catering"]');
  await expect(cta).toBeAttached();
});
