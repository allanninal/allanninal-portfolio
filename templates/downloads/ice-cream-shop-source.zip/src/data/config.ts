export const shop = {
  name: "Scooped",
  tagline: "Small-batch gelato & ice cream, made fresh daily.",
  shortTagline: "Pistachio, strawberry, salted caramel — and whatever today's flavour of the day turns out to be.",
  description:
    "Scooped is an artisan gelato and ice cream shop in Austin, Texas. We churn every flavour in small batches every morning using locally sourced dairy, seasonal fruit, and zero artificial colours. Three scoops, two cones, one obsession.",
  address: "811 S Congress Ave, Austin, TX 78704",
  phone: "+1 (512) 555-0137",
  email: "hello@scooped.co",
  orderUrl: "#order",
  cateringUrl: "#catering",
  instagram: "https://instagram.com/scoopedatx",
  facebook: "https://facebook.com/scoopedatx",
  tiktok: "https://tiktok.com/@scoopedatx",
  estYear: "2018",
  mapsUrl: "https://maps.google.com/?q=811+S+Congress+Ave+Austin+TX",
};

export type LocationHours = {
  day: string;
  open: string;
  note: string;
};

export type Location = {
  id: string;
  name: string;
  address: string;
  neighborhood: string;
  phone: string;
  hours: LocationHours[];
  mapsUrl: string;
};

export const locations: Location[] = [
  {
    id: "south-congress",
    name: "South Congress",
    address: "811 S Congress Ave, Austin, TX 78704",
    neighborhood: "SoCo",
    phone: "+1 (512) 555-0137",
    hours: [
      { day: "Mon–Thu", open: "12:00 PM – 9:00 PM",  note: "" },
      { day: "Friday",  open: "12:00 PM – 10:30 PM", note: "Late-night scoops on the patio" },
      { day: "Saturday", open: "11:00 AM – 10:30 PM", note: "Weekend line forms by noon" },
      { day: "Sunday",  open: "11:00 AM – 9:00 PM",  note: "" },
    ],
    mapsUrl: "https://maps.google.com/?q=811+S+Congress+Ave+Austin+TX",
  },
  {
    id: "east-sixth",
    name: "East Sixth",
    address: "2204 E 6th St, Austin, TX 78702",
    neighborhood: "East Austin",
    phone: "+1 (512) 555-0192",
    hours: [
      { day: "Mon–Thu", open: "1:00 PM – 9:30 PM",  note: "" },
      { day: "Friday",  open: "1:00 PM – 11:00 PM", note: "Bar district hours" },
      { day: "Saturday", open: "12:00 PM – 11:00 PM", note: "" },
      { day: "Sunday",  open: "12:00 PM – 9:30 PM",  note: "Brunch walk-ins welcome" },
    ],
    mapsUrl: "https://maps.google.com/?q=2204+E+6th+St+Austin+TX",
  },
  {
    id: "domain",
    name: "The Domain",
    address: "3401 Esperanza Crossing, Austin, TX 78758",
    neighborhood: "Domain Northside",
    phone: "+1 (512) 555-0218",
    hours: [
      { day: "Mon–Thu", open: "11:00 AM – 9:00 PM",  note: "" },
      { day: "Friday",  open: "11:00 AM – 10:00 PM", note: "" },
      { day: "Saturday", open: "10:00 AM – 10:00 PM", note: "First scoop of the day at 10 AM" },
      { day: "Sunday",  open: "10:00 AM – 8:00 PM",  note: "" },
    ],
    mapsUrl: "https://maps.google.com/?q=3401+Esperanza+Crossing+Austin+TX",
  },
];

export type FlavorTag = "classic" | "seasonal" | "vegan" | "dairy-free" | "new" | "fan-fave" | "sold-out" | "gluten-free";

export type FlavorItem = {
  id: string;
  name: string;
  description: string;
  price: string;
  tags?: FlavorTag[];
  note?: string;
  soldOut?: boolean;
};

export type FlavorCategory = {
  id: string;
  label: string;
  description: string;
  items: FlavorItem[];
};

export const flavorOfTheDay: FlavorItem = {
  id: "honey-lavender",
  name: "Honey Lavender",
  description:
    "Central Texas wildflower honey swirled into lavender-steeped custard. Floral, golden, impossible to stop eating. Today only — we made one batch.",
  price: "$5.50 / scoop",
  tags: ["seasonal", "fan-fave"],
};

export const rotatingFlavors: FlavorItem[] = [
  {
    id: "pistachio-rosewater",
    name: "Sicilian Pistachio",
    description: "Bronte-style pistachio paste, hint of rosewater, no colouring. Earthy, sweet, deeply nutty.",
    price: "$5.00",
    tags: ["classic", "fan-fave", "gluten-free"],
  },
  {
    id: "strawberry-balsamic",
    name: "Strawberry Balsamic",
    description: "Local Fredericksburg strawberries macerated in aged balsamic. Jammy, bright, slightly tart.",
    price: "$4.75",
    tags: ["seasonal", "vegan", "dairy-free"],
  },
  {
    id: "salted-caramel",
    name: "Burnt Salted Caramel",
    description: "Deep copper caramel, Maldon sea salt, housemade waffle cone crumble. Our #1 all-time seller.",
    price: "$4.75",
    tags: ["classic", "fan-fave", "gluten-free"],
  },
  {
    id: "dark-chocolate-sea-salt",
    name: "Dark Chocolate Sea Salt",
    description: "72% Valrhona ganache base, espresso undertone, finishing salt. For serious chocolate people.",
    price: "$5.00",
    tags: ["classic", "vegan", "dairy-free"],
  },
  {
    id: "mint-chip",
    name: "Fresh Mint Chip",
    description: "Steeped with fresh mint leaves (not extract), folded with dark chocolate shards. Bright, clean, herbaceous.",
    price: "$4.75",
    tags: ["classic"],
  },
  {
    id: "mango-tajin",
    name: "Mango Tajín Sorbet",
    description: "Ataulfo mango purée with a Tajín rim finish. Sweet-heat perfection — and completely dairy-free.",
    price: "$4.50",
    tags: ["seasonal", "vegan", "dairy-free", "gluten-free"],
  },
];

export const menu: FlavorCategory[] = [
  {
    id: "gelato",
    label: "Gelato",
    description: "Slow-churned at lower air — denser, creamier, more intense flavour. The Italian way.",
    items: [
      {
        id: "pistachio-gelato",
        name: "Sicilian Pistachio",
        description: "Bronte pistachio paste, hint of rosewater. No artificial colour.",
        price: "$5.00",
        tags: ["classic", "fan-fave", "gluten-free"],
      },
      {
        id: "stracciatella",
        name: "Stracciatella",
        description: "Pure cream gelato, fine chocolate shards drizzled in during churning. Simple and perfect.",
        price: "$4.75",
        tags: ["classic"],
      },
      {
        id: "tiramisu",
        name: "Tiramisù",
        description: "Mascarpone base, espresso ribbon, lady finger crumble. The real deal.",
        price: "$5.50",
        tags: ["classic", "fan-fave"],
      },
      {
        id: "hazelnut-praline",
        name: "Hazelnut Praline",
        description: "Roasted Piedmont hazelnuts, dark caramel swirl. Nutella's sophisticated older sibling.",
        price: "$5.25",
        tags: ["classic", "fan-fave", "gluten-free"],
      },
      {
        id: "lemon-ricotta",
        name: "Lemon Ricotta",
        description: "Fresh ricotta whipped with Meyer lemon zest. Soft, delicate, dairy-forward.",
        price: "$5.00",
        tags: ["seasonal"],
      },
      {
        id: "burnt-caramel-gelato",
        name: "Burnt Caramel",
        description: "Deep amber caramel, fleur de sel finish, served on brioche if you ask nicely.",
        price: "$5.00",
        tags: ["classic", "gluten-free"],
      },
    ],
  },
  {
    id: "ice-cream",
    label: "Ice Cream",
    description: "Churned with extra cream for that classic American scoop — nostalgic, generous, unapologetic.",
    items: [
      {
        id: "salted-caramel-ic",
        name: "Burnt Salted Caramel",
        description: "Copper caramel, Maldon flake salt, waffle cone crumble. Our #1 all-time.",
        price: "$4.75",
        tags: ["classic", "fan-fave", "gluten-free"],
      },
      {
        id: "dark-choc-ic",
        name: "Dark Chocolate Sea Salt",
        description: "72% Valrhona, espresso undertone, finishing Maldon. Richly bittersweet.",
        price: "$5.00",
        tags: ["classic"],
      },
      {
        id: "mint-chip-ic",
        name: "Fresh Mint Chip",
        description: "Steeped mint leaf base, dark chocolate shards. Herbaceous and bright.",
        price: "$4.75",
        tags: ["classic"],
      },
      {
        id: "strawberry-balsamic-ic",
        name: "Strawberry Balsamic",
        description: "Fredericksburg strawberries, aged balsamic, vanilla. Best-in-season.",
        price: "$4.75",
        tags: ["seasonal"],
      },
      {
        id: "cookies-cream",
        name: "Cookies & Cream",
        description: "House-baked chocolate cookie crumble folded into pure vanilla cream. No shortcuts.",
        price: "$4.75",
        tags: ["fan-fave"],
      },
      {
        id: "birthday-cake-ic",
        name: "Birthday Cake",
        description: "White cake batter base, rainbow sprinkles swirled in. Every day is someone's birthday.",
        price: "$4.75",
        tags: ["fan-fave"],
      },
    ],
  },
  {
    id: "sorbet",
    label: "Sorbet & Dairy-Free",
    description: "Completely plant-based, and just as satisfying. All made with real fruit, no fillers.",
    items: [
      {
        id: "mango-tajin-s",
        name: "Mango Tajín",
        description: "Ataulfo mango purée, Tajín rim finish. Sweet-heat that lingers.",
        price: "$4.50",
        tags: ["seasonal", "vegan", "dairy-free", "gluten-free"],
      },
      {
        id: "raspberry-lemon-s",
        name: "Raspberry Lemon",
        description: "Pressed raspberry, Meyer lemon, cane sugar. Sharp and electric.",
        price: "$4.50",
        tags: ["classic", "vegan", "dairy-free", "gluten-free"],
      },
      {
        id: "dark-choc-vegan",
        name: "Dark Chocolate (Vegan)",
        description: "Oat milk base, 72% cacao. Same richness as the dairy version.",
        price: "$5.00",
        tags: ["vegan", "dairy-free"],
      },
      {
        id: "passion-fruit-s",
        name: "Passion Fruit",
        description: "Pure Maracuyá purée, just a touch of lime. Intensely tropical.",
        price: "$4.75",
        tags: ["seasonal", "vegan", "dairy-free", "gluten-free"],
      },
    ],
  },
  {
    id: "sundaes",
    label: "Sundaes & Specials",
    description: "Go big or go home. Our loaded sundaes use housemade sauces and fresh-baked toppings.",
    items: [
      {
        id: "classic-sundae",
        name: "Classic Sundae",
        description: "2 scoops of your choice, hot fudge, whipped cream, cherry. The OG.",
        price: "$8.50",
        tags: ["fan-fave"],
      },
      {
        id: "banana-split",
        name: "Banana Split",
        description: "House-split banana, 3 scoops, strawberry / caramel / hot fudge, toasted walnuts.",
        price: "$12.00",
        tags: ["fan-fave"],
      },
      {
        id: "affogato",
        name: "Affogato",
        description: "A double shot of La Marzocca espresso poured over housemade vanilla gelato. Italian simplicity.",
        price: "$7.50",
        tags: ["classic", "gluten-free"],
      },
      {
        id: "float",
        name: "Ice Cream Float",
        description: "Your scoop + Q Mixer or local Topo Chico. Choose root beer, grapefruit, or orange.",
        price: "$7.00",
        tags: ["fan-fave"],
      },
    ],
  },
];

export const story = {
  headline: "Churned from Scratch, Every Morning",
  founderName: "Maya Solano",
  founderTitle: "Founder & Head Gelato Maker",
  bio: [
    "Maya spent two years in Bologna learning the craft of artigianale gelato before opening Scooped's first window in South Congress in 2018 — a 90-square-foot walk-up with a hand-painted sign and a three-flavour menu.",
    "The philosophy has never changed: local dairy, seasonal fruit, zero shortcuts. Every batch is churned fresh in the morning, and when it's gone, it's gone.",
    "Austin embraced it. Within six months there were queues around the block. Today there are three locations — but the recipes, the portions, and the obsession are identical to that first summer.",
  ],
  stats: [
    { label: "Opened",              value: "2018" },
    { label: "Flavours per week",   value: "28–36" },
    { label: "Farms we source from", value: "7" },
    { label: "Locations",           value: "3" },
  ],
};

export const gallery = [
  { alt: "A cone of honey lavender gelato with a golden honeycomb garnish, held against a bright Austin sky", label: "Honey Lavender", src: "honey-lavender" },
  { alt: "Three stacked scoops of pistachio, strawberry, and vanilla gelato in a homemade waffle cone", label: "Triple scoop", src: "triple-scoop" },
  { alt: "A row of gelato pans in pistachio green, strawberry red, and vanilla cream inside the gelateria case", label: "The gelato case", src: "case" },
  { alt: "A banana split sundae with three scoops, hot fudge, and toasted walnuts served in a long white dish", label: "Banana split", src: "banana-split" },
  { alt: "Two friends sharing gelato cones together outside the South Congress location on a sunny afternoon", label: "SoCo summers", src: "friends" },
  { alt: "The exterior of Scooped on South Congress at dusk, warm lights glowing with a line of customers outside", label: "SoCo at dusk", src: "exterior" },
];

export const catering = {
  headline: "Private Events & Catering",
  description:
    "Bring Scooped to your wedding, corporate event, or birthday party. We set up a staffed gelato station with 8–12 flavours, cones, cups, and all the toppings. Austin-wide delivery and setup included.",
  details: [
    "Minimum 50 guests · 3-hour service",
    "Custom flavour selection 2 weeks before event",
    "Staffed by our team — you relax",
    "Served weddings, SXSW, ACL Festival, corporate retreats",
  ],
  cta: "Get a catering quote",
  ctaUrl: "mailto:catering@scooped.co?subject=Catering%20Enquiry",
};

export const maker = {
  name: 'Scooped',
  linkedin: "#",
  twitter: "#",
  github: "#",
  email: "hello@scooped.com",
  kofi: "#",
};

export const site = {
  title: "Scooped — Artisan Gelato & Ice Cream, Austin TX",
  description:
    "Small-batch gelato and ice cream made fresh daily in Austin, Texas. Seasonal flavours, three locations (SoCo, East Sixth, Domain), and catering for private events. Come in for today's flavour of the day.",
  url: "https://example.com/",
  ogImage: "/og-image.png",
  language: "en",
};
