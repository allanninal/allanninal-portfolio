// Single source of truth for the indie hacker portfolio.
// Cloning users edit this file to personalise the template.

export const maker = {
  name: 'Allan Ninal',
  handle: 'allanninal',
  email: 'landix.ninal@gmail.com',
  tagline: 'I build small software products that solve real problems.',
  bio: [
    'I quit my job in 2021 to build things on the internet. I had no plan, one half-finished side project, and a vague feeling that I was better at solving problems than following roadmaps.',
    'Three years and five products later, two are growing, one was sunset (I learned more from that one than the others), and one sold — which paid for about eight months of runway to keep going. I share everything publicly: the numbers, the mistakes, and the occasional win.',
    'I work from Southeast Asia, stay in the same timezone as my morning coffee, and try to ship something every quarter. If you\'re building something too, I\'d love to hear about it.',
  ],
  location: 'Southeast Asia · UTC+8',
  availableFor: 'Micro-SaaS consulting, technical writing, advisory.',
  socials: {
    github: 'https://github.com/allanninal',
    x: 'https://x.com/allanninal',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    email: 'mailto:landix.ninal@gmail.com',
    kofi: 'https://ko-fi.com/allanninal',
  },
};

export type ProductStatus = 'live' | 'sunset' | 'sold';

export interface Product {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  status: ProductStatus;
  /** Monthly Recurring Revenue in USD — 0 for sunset/sold */
  mrr: number;
  mrrLabel: string;
  /** For sold products: the sale price */
  salePrice?: number;
  salePriceLabel?: string;
  /** Peak MRR for sunset products */
  peakMrr?: number;
  peakMrrLabel?: string;
  users: number;
  usersLabel: string;
  launchDate: string;
  launchDateLabel: string;
  url: string;
  stack: string[];
  lesson?: string;
}

export const products: Product[] = [
  {
    id: 'formcraft',
    name: 'FormCraft',
    description: 'Drag-and-drop form builder for small businesses.',
    longDescription:
      'FormCraft lets non-technical teams build embeddable forms, collect responses, and route leads to email or Slack — without writing a line of code. Built for the operators who are tired of paying $99/mo for Typeform when they only need 5 forms.',
    status: 'live',
    mrr: 3200,
    mrrLabel: '$3,200',
    users: 1847,
    usersLabel: '1,847',
    launchDate: '2022-03',
    launchDateLabel: 'Mar 2022',
    url: 'https://formcraft.app',
    stack: ['Astro', 'Supabase', 'Stripe', 'Tailwind'],
  },
  {
    id: 'pingalert',
    name: 'PingAlert',
    description: 'Uptime monitoring with SMS and Slack alerts.',
    longDescription:
      'PingAlert checks your URLs every 60 seconds and fires an SMS or Slack message the moment something goes down. No dashboard to babysit — just quiet until it\'s not. Intentionally simple: one screen, one plan, $9/mo.',
    status: 'live',
    mrr: 1450,
    mrrLabel: '$1,450',
    users: 612,
    usersLabel: '612',
    launchDate: '2022-09',
    launchDateLabel: 'Sep 2022',
    url: 'https://pingalert.io',
    stack: ['Node.js', 'Twilio', 'Planetscale', 'Railway'],
  },
  {
    id: 'docuflow',
    name: 'DocuFlow',
    description: 'PDF generation API for web apps.',
    longDescription:
      'DocuFlow is a REST API that accepts HTML or a template ID and returns a rendered PDF in under 2 seconds. Built for developers who are tired of wrestling with headless Chromium in production. Pay-per-use, no monthly minimums.',
    status: 'live',
    mrr: 890,
    mrrLabel: '$890',
    users: 341,
    usersLabel: '341',
    launchDate: '2023-02',
    launchDateLabel: 'Feb 2023',
    url: 'https://docuflow.dev',
    stack: ['Bun', 'Puppeteer', 'AWS Lambda', 'Stripe'],
  },
  {
    id: 'listpilot',
    name: 'ListPilot',
    description: 'Email list cleaning and validation SaaS.',
    longDescription:
      'ListPilot cleaned and validated email lists to reduce bounce rates before sending campaigns. Launched into a market that already had three well-funded competitors. Couldn\'t differentiate on price or features — turned off the servers in December 2022.',
    status: 'sunset',
    mrr: 0,
    mrrLabel: '$0',
    peakMrr: 420,
    peakMrrLabel: '$420 peak',
    users: 0,
    usersLabel: '—',
    launchDate: '2021-06',
    launchDateLabel: 'Jun 2021',
    url: '#',
    stack: ['Next.js', 'Vercel', 'SendGrid API', 'Postgres'],
    lesson:
      'I solved a real problem in a market I didn\'t understand. Validate the competitive landscape before you write a single line of code.',
  },
  {
    id: 'shipkit',
    name: 'ShipKit',
    description: 'Astro + Tailwind SaaS boilerplate.',
    longDescription:
      'ShipKit was an opinionated Astro + Tailwind starter with auth, billing, and a dashboard shell pre-built. Sold to a developer tools studio in October 2023 who wanted to build on the foundation rather than maintain their own.',
    status: 'sold',
    mrr: 0,
    mrrLabel: '$0',
    salePrice: 8500,
    salePriceLabel: 'Sold for $8,500',
    users: 0,
    usersLabel: '—',
    launchDate: '2023-01',
    launchDateLabel: 'Jan 2023',
    url: '#',
    stack: ['Astro', 'Tailwind', 'Lucia Auth', 'Stripe'],
  },
];

// Computed totals — update when product MRRs change.
export const stats = {
  currentMrr: 5540,
  currentMrrLabel: '$5,540',
  lifetimeRevenue: 142000,
  lifetimeRevenueLabel: '$142,000',
  activeUsers: 2800,
  activeUsersLabel: '2,800',
};

export const currentProject = {
  name: 'VaultNote',
  description:
    'Encrypted personal knowledge base with an offline-first Markdown editor. Your notes never touch a server unencrypted — zero-knowledge, end-to-end. Public beta open now.',
  status: 'Public beta',
  url: 'https://vaultnote.app',
  stack: ['Electron', 'SQLite', 'libsodium', 'Astro'],
  startedDate: '2024-01',
};

export const newsletter = {
  name: 'Ship It Weekly',
  description:
    'Honest updates from a one-person software business — MRR numbers, what\'s working, what broke, and the tools I\'m using. No fluff, no hustle-porn. Sent every Sunday.',
  cadence: 'Every Sunday',
  subscriberCount: 2847,
  subscriberCountLabel: '2,847 subscribers',
  averageReadMinutes: 5,
  buttondown: {
    slug: 'allanninal',
    actionUrl: 'https://buttondown.email/api/emails/embed-subscribe/allanninal',
  },
};
