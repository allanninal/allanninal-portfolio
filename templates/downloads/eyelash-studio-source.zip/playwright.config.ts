import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 30_000,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 2,
  reporter: 'list',
  use: {
    baseURL:     'http://localhost:4321/eyelash-studio',
    trace:       'on-first-retry',
    screenshot:  'only-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: {
    command:  'npm run preview -- --port 4321',
    port:     4321,
    timeout:  60_000,
    reuseExistingServer: !process.env.CI,
  },
});
