import { test, expect } from '@playwright/test';

const THIRD_PARTY_NOISE =
  /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
const RESOURCE_FAIL = /failed to load resource/i;

test.describe('Eyelash Studio — pages', () => {
  test.beforeEach(async ({ page }) => {
    // Suppress known third-party console noise
    page.on('console', msg => {
      const text = msg.text();
      if (THIRD_PARTY_NOISE.test(text) || RESOURCE_FAIL.test(text)) return;
      if (msg.type() === 'error') {
        console.error(`[CONSOLE ERROR] ${text}`);
      }
    });
  });

  test('homepage loads with correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Lumière Lash Studio/i);
  });

  test('hero section visible', async ({ page }) => {
    await page.goto('/');
    const hero = page.locator('[aria-label*="hero"]').first();
    await expect(hero).toBeVisible();
  });

  test('h1 present and mentions lashes', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1').first();
    await expect(h1).toBeVisible();
    const text = await h1.textContent();
    expect(text?.toLowerCase()).toMatch(/lash|morning|effortless/);
  });

  test('navigation links are present', async ({ page }) => {
    await page.goto('/');
    const navLinks = page.locator('.header-nav a');
    const count = await navLinks.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('services section has multiple service cards', async ({ page }) => {
    await page.goto('/');
    await page.locator('#services').waitFor({ state: 'attached' });
    const cards = page.locator('.service-card');
    await expect(cards.first()).toBeVisible();
    const count = await cards.count();
    expect(count).toBeGreaterThanOrEqual(6);
  });

  test('services show prices', async ({ page }) => {
    await page.goto('/');
    const prices = page.locator('.service-price');
    await expect(prices.first()).toBeVisible();
    const firstPrice = await prices.first().textContent();
    expect(firstPrice).toMatch(/\$/);
  });

  test('gallery section renders images', async ({ page }) => {
    await page.goto('/');
    const galleryImages = page.locator('.gallery-card img');
    await expect(galleryImages.first()).toBeVisible();
    const count = await galleryImages.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('gallery filter buttons work', async ({ page }) => {
    await page.goto('/');
    await page.locator('.filter-btn').filter({ hasText: 'Classic' }).click();
    // After filtering, only classic cards should show
    const visibleCards = page.locator('.gallery-card:not([style*="display: none"])');
    await expect(visibleCards.first()).toBeVisible();
  });

  test('aftercare section is present', async ({ page }) => {
    await page.goto('/');
    const aftercare = page.locator('.aftercare-band');
    await expect(aftercare).toBeVisible();
    const cards = page.locator('.aftercare-card');
    const count = await cards.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('about section shows artist bio', async ({ page }) => {
    await page.goto('/');
    const about = page.locator('#about');
    await expect(about).toBeVisible();
    const aboutText = await about.textContent();
    expect(aboutText?.toLowerCase()).toMatch(/noelle|lumière|austin/i);
  });

  test('testimonials are present', async ({ page }) => {
    await page.goto('/');
    const testimonials = page.locator('.testimonial-card');
    const count = await testimonials.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('FAQ section renders and accordion works', async ({ page }) => {
    await page.goto('/');
    const faqTrigger = page.locator('.faq-trigger').first();
    await expect(faqTrigger).toBeVisible();
    // Click to open
    await faqTrigger.click();
    await expect(faqTrigger).toHaveAttribute('aria-expanded', 'true');
    const panel = page.locator('.faq-panel.is-open').first();
    await expect(panel).toBeVisible();
  });

  test('contact section shows hours', async ({ page }) => {
    await page.goto('/');
    const contact = page.locator('#contact');
    await expect(contact).toBeVisible();
    const hoursTable = page.locator('.hours-table');
    await expect(hoursTable).toBeVisible();
  });

  test('skip link is in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('booking CTA buttons link to booking URL', async ({ page }) => {
    await page.goto('/');
    const bookBtn = page.locator('a[href*="calendly"]').first();
    await expect(bookBtn).toBeVisible();
  });

  test('footer has social links and Ko-fi', async ({ page }) => {
    await page.goto('/');
    const footer = page.locator('.site-footer');
    await expect(footer).toBeVisible();
    const kofi = page.locator('a[href*="ko-fi"]').first();
    await expect(kofi).toBeVisible();
  });

  test('all images have alt text', async ({ page }) => {
    await page.goto('/');
    const images = page.locator('img');
    const count = await images.count();
    for (let i = 0; i < count; i++) {
      const img = images.nth(i);
      const alt = await img.getAttribute('alt');
      const ariaHidden = await img.getAttribute('aria-hidden');
      // Images that aren't aria-hidden must have non-empty alt
      if (ariaHidden !== 'true') {
        expect(alt, `Image ${i} missing alt text`).toBeTruthy();
        expect(alt!.trim().length, `Image ${i} has empty alt text`).toBeGreaterThan(0);
      }
    }
  });

  test('page has canonical and OG meta tags', async ({ page }) => {
    await page.goto('/');
    const canonical = page.locator('link[rel="canonical"]');
    await expect(canonical).toBeAttached();
    const ogTitle = page.locator('meta[property="og:title"]');
    await expect(ogTitle).toBeAttached();
    const ogImage = page.locator('meta[property="og:image"]');
    await expect(ogImage).toBeAttached();
  });

  test('JSON-LD schema is present', async ({ page }) => {
    await page.goto('/');
    const schemas = page.locator('script[type="application/ld+json"]');
    const count = await schemas.count();
    expect(count).toBeGreaterThanOrEqual(2);
    const firstSchema = await schemas.first().textContent();
    expect(firstSchema).toContain('schema.org');
  });
});
