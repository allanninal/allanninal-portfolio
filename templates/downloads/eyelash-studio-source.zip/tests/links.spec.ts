import { test, expect } from '@playwright/test';

test.describe('Eyelash Studio — link integrity', () => {
  test('internal anchor links resolve to sections', async ({ page }) => {
    await page.goto('/');

    const anchors = ['#services', '#gallery', '#about', '#faq', '#contact'];
    for (const anchor of anchors) {
      const el = page.locator(anchor);
      await expect(el).toBeAttached();
    }
  });

  test('booking URL is present and has correct href', async ({ page }) => {
    await page.goto('/');
    const bookingLinks = page.locator('a[href*="calendly"]');
    const count = await bookingLinks.count();
    expect(count).toBeGreaterThanOrEqual(1);
  });

  test('social links open external URLs', async ({ page }) => {
    await page.goto('/');
    const socialLinks = page.locator('a[target="_blank"][rel*="noopener"]');
    const count = await socialLinks.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('ko-fi link is present', async ({ page }) => {
    await page.goto('/');
    const kofiLink = page.locator('a[href*="ko-fi"]');
    await expect(kofiLink.first()).toBeVisible();
  });

  test('LinkedIn link is present', async ({ page }) => {
    await page.goto('/');
    const linkedinLinks = page.locator('a[href*="linkedin"]');
    await expect(linkedinLinks.first()).toBeVisible();
  });

  test('no broken tel or mailto hrefs', async ({ page }) => {
    await page.goto('/');
    const telLinks = page.locator('a[href^="tel:"]');
    const mailLinks = page.locator('a[href^="mailto:"]');
    const telCount = await telLinks.count();
    const mailCount = await mailLinks.count();
    expect(telCount + mailCount).toBeGreaterThanOrEqual(2);

    // Verify tel href is not empty
    if (telCount > 0) {
      const telHref = await telLinks.first().getAttribute('href');
      expect(telHref?.length).toBeGreaterThan(5);
    }
  });
});
