import { test, expect } from '@playwright/test';

// Edition-aware: the Pro edition swaps the free download bar for a
// "Pro edition — live preview" strip with locked Get-Pro links.
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';

test('TemplateInfo renders the canonical bar when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const info = page.locator(`[aria-label="${barLabel}"]`);
  await expect(info).toBeVisible();

  // All 365 link present in both editions
  const allLink = info.locator('a', { hasText: /all 365/i });
  await expect(allLink).toBeVisible();

  if (isPro) {
    // Two locked Get-Pro buttons (static + Astro), both → LinkedIn
    const getProStatic = info.locator('a', { hasText: /get pro static/i });
    const getProAstro = info.locator('a', { hasText: /get pro astro/i });
    await expect(getProStatic).toHaveAttribute('href', /linkedin\.com/);
    await expect(getProAstro).toHaveAttribute('href', /linkedin\.com/);
    // Two free downloads — static + Astro source
    await expect(info.locator('a[download][href*="-static.zip"]')).toBeVisible();
    await expect(info.locator('a[download][href*="-source.zip"]')).toBeVisible();
    return;
  }

  // Free edition: static + source downloads
  await expect(info.locator('a[download][href*="-static.zip"]')).toBeVisible();
  await expect(info.locator('a[download][href*="-source.zip"]')).toBeVisible();

  // Build with me → LinkedIn
  const hireLink = info.locator('a', { hasText: /build with me/i });
  await expect(hireLink).toBeVisible();
  expect(await hireLink.getAttribute('href')).toContain('linkedin.com');
});

test('TemplateInfo has no github.com/allanninal/templates links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`[aria-label="${barLabel}"] a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});

test('Day 58 label is present in the free TemplateInfo', async ({ page }) => {
  test.skip(isPro, 'Free-edition-only assertion');
  await page.goto('/');
  const info = page.locator(`[aria-label="${barLabel}"]`);
  await expect(info).toContainText('Day 58 of 365');
});
