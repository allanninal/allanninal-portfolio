# Day 58 — Eyelash Studio: Niche Research Brief

## Slug
`eyelash-studio`

## Persona
**Noelle Beaumont** — boutique lash artist, owner of *Lumière Lash Studio*, Austin TX.
Certified lash technician with 7 years experience, trained in classic, hybrid, volume, and mega-volume sets.
Operates a private studio suite focused on luxury single-client appointments.

## Visual Register — Distinct from Days 1–57

| Prior template | Palette | Type |
|---|---|---|
| Day 50 hair-salon | mauve #C8A7C9 / ivory | Bellefair + Questrial |
| Day 53 day-spa | sage-green #3A6047 | Raleway + Crimson Pro |
| Day 54 massage-therapist | teal #1A4A5A deep | Libre Baskerville |
| Day 55 tattoo-studio | amber #E8A020 / near-black | Bebas Neue + Barlow |
| Day 56 esthetician-skincare | forest-green #2D5016 / blush ivory | DM Serif Display |
| Day 57 makeup-artist | deep plum #4A1860 / champagne gold | Cormorant Garamond + Nunito Sans |

**Day 58 chosen palette:** Warm rose-mauve accent on DARK espresso base, cream sections for readability.

- **Primary accent:** `#C9857A` — dusty rose (warm, editorial, 4.6:1+ on dark; on cream sections: text is dark espresso)
- **Accent dark (CTA text):** `#8B3B30` — deep terracotta-rose — 5.2:1 on cream/white backgrounds ✓ AA
- **Background dark sections:** `#1C1410` — near-black espresso
- **Background cream sections:** `#FBF7F4` — warm off-white
- **Surface:** `#FFFFFF`
- **Type:** `Playfair Display` (serif headings — editorial) + `DM Sans` (clean sans body) — NOT used together in any prior day
- **Density:** Split-dark-and-light, photo-heavy, close-up lash macro photography

**Differentiation story:** All prior beauty days (56, 57) use light-primary backgrounds. This is the FIRST in the sprint to open with a **dark hero** (espresso/near-black) that transitions to warm cream for service cards — like a luxury lash studio's Instagram: dark, cinematic, close-up. The rose accent has never been used (plum was Day 57, sage was 53, teal was 54).

## Target User
Freelance lash artists, lash studio owners (1–3 chairs), looking to book clients online. Converts via "Book Now" CTAs and a clear service+price menu.

## Sections (ordered)
1. **Header** — sticky, logo + nav + "Book Now" CTA
2. **Hero** — dark espresso; headline + tagline + dual CTA; large close-up lash photo right-side
3. **Stats band** — lash-specific: 7+ Years · 1,200+ Sets Applied · 5★ Rating · Austin TX
4. **Services** — lash type cards: Classic · Hybrid · Volume · Mega-Volume · Lash Lift & Tint · Fill · Removal — each with duration + price
5. **Gallery** — photo grid: lash styles (Classic set close-up, Volume set, Hybrid set, before/after, studio space, lash artist at work)
6. **Aftercare & Fill Cycle** — educational band (retention tips, fill window: 2–3 weeks)
7. **About / Artist Bio** — Noelle's story, certifications, photo
8. **Testimonials** — 5-star reviews focused on lash retention, comfort, results
9. **FAQ** — fill timing, patch test, allergies, aftercare, booking policy, contraindications
10. **Booking CTA** — dark espresso band, Calendly placeholder
11. **Contact** — hours, address (Austin TX), phone, email
12. **Footer** — links, social, donate (Ko-fi), Allan's handles

## Schema.org
- `BeautyBusiness` + `LocalBusiness`
- `Service` with `hasOfferCatalog` (lash services)
- `FAQPage`
- `Review` (testimonials)

## Image Plan (Unsplash)
All terms must be fresh — avoid eye, face, beauty terms already used in days 50–57.
Use: "eyelash extensions close-up", "lash artist applying", "studio interior minimal", "woman eye lashes macro", "beauty salon chair"
No duplicates from registry (all 39 beauty images listed above are excluded).
