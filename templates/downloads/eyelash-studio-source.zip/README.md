# Eyelash Studio — Day 58 of 365

> **Lumière Lash Studio** — boutique eyelash extension studio template for lash artists and studio owners.

**Live demo:** [example.com](https://example.com/)

Part of the [365 Free Astro Templates](https://example.com/templates) project by [Allan Niñal](#).

---

## What's inside

A complete, production-ready website for a boutique lash studio. Built with Astro + Tailwind CSS. Zero framework JS in the client bundle (except the gallery filter and FAQ accordion).

**Sections:**
- Sticky dark header with Book Now CTA
- Dark espresso hero — headline + lash close-up photo split layout
- Stats band — years, sets applied, rating, retention rate
- Services menu — Classic, Hybrid, Volume, Mega-Volume sets + Fills + Lash Lift & Tint + Removal, each with duration and price
- Photo gallery with filter (All / Classic / Hybrid / Volume / Lift & Tint / Before & After / Studio)
- Aftercare & fill-cycle info band
- Artist bio — story, certifications, credentials
- Testimonials — 5 real-content reviews focused on retention and safety
- FAQ — 8 questions covering fill timing, patch test, allergies, aftercare, cancellation
- Full-width booking CTA band
- Hours + contact section (address, phone, email, LinkedIn)

## Tech stack

- [Astro](https://astro.build) — static site generator
- [Tailwind CSS](https://tailwindcss.com) — utility CSS
- [Playfair Display](https://fonts.google.com/specimen/Playfair+Display) — serif headings (via @fontsource)
- [DM Sans](https://fonts.google.com/specimen/DM+Sans) — clean sans body (via @fontsource)

## Getting started

```bash
npm install
npm run dev     # http://localhost:4321
npm run build   # output → dist/
```

## Environment variables

| Variable | Description |
|---|---|
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — enables analytics & download bar. Leave blank for your own deploy. |
| `PUBLIC_BASE_PATH` | URL path prefix. Default: `/eyelash-studio/` |
| `PUBLIC_SITE_URL` | Canonical site URL. |

Copy `.env.example` → `.env` and customize.

## Customization

All content lives in `src/data/config.ts`:
- Studio persona (name, address, phone, email, social links)
- Services (name, price, duration, includes)
- Gallery items
- Aftercare tips
- Testimonials
- FAQ

Replace `public/images/` with your own photos. The image registry (`assets/image-registry.json`) tracks sources for uniqueness checking.

## License

MIT — free to use, modify, and deploy commercially. No attribution required.

---

