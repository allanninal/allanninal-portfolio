// ─── Studio persona ────────────────────────────────────────────────────────────
export const studio = {
  name:         'Noelle Beaumont',
  studioName:   'Lumière Lash Studio',
  title:        'Certified Lash Technician & Studio Owner',
  location:     'Austin, TX · Private Studio Suite',
  tagline:      'Lashes that open your eyes to the world — classic to mega-volume, flawlessly applied.',
  description:
    'Boutique lash studio in Austin, TX. Noelle Beaumont is a certified lash technician with 7 years of experience specializing in classic, hybrid, volume, and mega-volume extensions. Every set is hand-crafted for your eye shape and lifestyle in a serene, single-client private suite.',
  address:     '1408 South Congress Ave, Suite 204, Austin, TX 78704',
  phone:       '+1 (512) 555-0193',
  email:       'hello@noellebeaumont.com',
  instagram:   'https://www.instagram.com/',
  pinterest:   'https://www.pinterest.com/',
  linkedin:    '#',
  kofi:        '#',
  bookingUrl:  'https://calendly.com/',
  coverageArea: 'Central Austin · South Congress · East Austin · Walk-ins by appointment only.',
  credentials: [
    'Certified Lash Technician — NALA (National Association of Lash Artists)',
    'Volume & Mega-Volume Specialist — Borboleta Beauty Academy',
    'Lash Lift & Tint Certified — LashBase Pro',
    'Patch Test & Allergy Safety Certified — Gladlash Academy',
    'Texas Cosmetology License #TX-1284573',
  ],
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '10:00 AM – 6:00 PM' },
    { day: 'Wednesday', open: '10:00 AM – 6:00 PM' },
    { day: 'Thursday',  open: '10:00 AM – 7:00 PM' },
    { day: 'Friday',    open: '10:00 AM – 7:00 PM' },
    { day: 'Saturday',  open: '9:00 AM – 5:00 PM' },
    { day: 'Sunday',    open: 'Closed' },
  ],
};

export const site = {
  title:         'Lumière Lash Studio — Eyelash Extensions Austin TX',
  description:
    'Boutique eyelash extension studio in Austin, TX. Classic, hybrid, volume and mega-volume sets in a private suite. Online booking.',
  language:      'en',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
};

// ─── Stats ────────────────────────────────────────────────────────────────────
export const stats = [
  { value: '7+',    label: 'Years Experience' },
  { value: '1,200+', label: 'Sets Applied' },
  { value: '5★',    label: 'Average Rating' },
  { value: '98%',   label: 'Retention Rate' },
];

// ─── Gallery ─────────────────────────────────────────────────────────────────
export type GalleryItem = {
  id:       string;
  category: 'classic' | 'hybrid' | 'volume' | 'mega-volume' | 'lift-tint' | 'studio' | 'before-after';
  title:    string;
  caption:  string;
  image:    string;
  imageAlt: string;
  width:    number;
  height:   number;
};

export const gallery: GalleryItem[] = [
  {
    id:       'classic-01',
    category: 'classic',
    title:    'Classic Lash Set',
    caption:  'One extension per natural lash. Soft, defined, and effortlessly natural — perfect for first-timers.',
    image:    '/images/gallery-classic.jpg',
    imageAlt: 'Close-up of a classic eyelash extension set — one extension per lash, soft natural look, dark mascara-like effect',
    width:    800,
    height:   1000,
  },
  {
    id:       'hybrid-01',
    category: 'hybrid',
    title:    'Hybrid Lash Set',
    caption:  'A mix of classic and volume fans for texture, dimension, and a fuller-than-natural finish.',
    image:    '/images/gallery-hybrid.jpg',
    imageAlt: 'Hybrid eyelash extension set close-up showing mix of classic single extensions and volume fans for dimensional look',
    width:    800,
    height:   1000,
  },
  {
    id:       'volume-01',
    category: 'volume',
    title:    'Volume Lash Set',
    caption:  '3D–6D fans handcrafted from ultra-fine lashes. Bold, fluffy, dramatic — without the damage.',
    image:    '/images/gallery-volume.jpg',
    imageAlt: 'Volume eyelash extension set showing 3D to 6D fans, bold fluffy dramatic lashes on eye close-up',
    width:    800,
    height:   1000,
  },
  {
    id:       'lift-01',
    category: 'lift-tint',
    title:    'Lash Lift & Tint',
    caption:  'Your natural lashes, curled and darkened. No extensions needed — just stunning, low-maintenance curl.',
    image:    '/images/gallery-lift.jpg',
    imageAlt: 'Lash lift and tint result showing naturally curled and darkened lashes without extensions',
    width:    800,
    height:   1000,
  },
  {
    id:       'before-after-01',
    category: 'before-after',
    title:    'Before & After',
    caption:  'The transformation speaks for itself. From bare to beautifully enhanced in 90 minutes.',
    image:    '/images/gallery-before-after.jpg',
    imageAlt: 'Before and after eyelash extension transformation showing bare lashes versus lash extension results',
    width:    800,
    height:   1000,
  },
  {
    id:       'studio-01',
    category: 'studio',
    title:    'The Studio',
    caption:  'A serene, private suite designed for you to relax while I work. Clean, calm, intentional.',
    image:    '/images/gallery-studio.jpg',
    imageAlt: 'Lumière Lash Studio interior — clean minimal private suite with lash bed, soft lighting, and organized tools',
    width:    800,
    height:   600,
  },
];

// ─── Services ─────────────────────────────────────────────────────────────────
export type Service = {
  id:          string;
  name:        string;
  tagline:     string;
  duration:    string;
  price:       string;
  description: string;
  includes:    string[];
  highlight?:  boolean;
  category:    'extensions' | 'fills' | 'other';
};

export const services: Service[] = [
  {
    id:       'classic-set',
    category: 'extensions',
    name:     'Classic Full Set',
    tagline:  'Naturally defined, one extension per lash.',
    duration: '90–120 min',
    price:    'From $145',
    description:
      'One premium silk or mink extension is placed on each isolated natural lash. The result is a polished, mascara-effect look that enhances without overdoing it. Ideal for lash extension beginners or those who prefer a natural, everyday look.',
    includes: [
      'Consultation & lash health assessment',
      'Primer & pre-treatment cleanse',
      'Hand-crafted silk or mink extensions',
      'Aftercare kit & fill-cycle guidance',
    ],
    highlight: false,
  },
  {
    id:       'hybrid-set',
    category: 'extensions',
    name:     'Hybrid Full Set',
    tagline:  'Texture, depth, and dimension — the best of both worlds.',
    duration: '120–150 min',
    price:    'From $175',
    description:
      'A 50/50 blend of classic singles and handmade volume fans gives your lash line texture and fullness that looks intentional, not overdone. Perfect for clients who want more than classic but something softer than full volume.',
    includes: [
      'Personalized lash mapping for your eye shape',
      'Classic singles + hand-rolled volume fans',
      'Curl & thickness selection consultation',
      'Aftercare kit & fill-cycle guidance',
    ],
    highlight: true,
  },
  {
    id:       'volume-set',
    category: 'extensions',
    name:     'Volume Full Set',
    tagline:  'Fluffy, full, and absolutely dramatic.',
    duration: '150–180 min',
    price:    'From $210',
    description:
      '3D to 6D handcrafted fans applied to each natural lash. Volume lashes create a bold, fluffy look that photographs beautifully without requiring mascara. Created with ultra-fine 0.05–0.07mm lashes to keep your natural lashes safe.',
    includes: [
      'Custom lash mapping',
      'Handcrafted 3D–6D volume fans',
      'Ultra-fine lightweight extensions',
      'Aftercare kit & fill-cycle guidance',
    ],
    highlight: false,
  },
  {
    id:       'mega-volume-set',
    category: 'extensions',
    name:     'Mega Volume Full Set',
    tagline:  'Maximum drama, maximum impact.',
    duration: '180–210 min',
    price:    'From $255',
    description:
      '7D–16D mega fans built from the finest 0.03–0.05mm lashes. The ultimate in lash drama — ultra-fluffy, incredibly full, and stunning from across the room. Requires healthy natural lashes and a thorough consultation.',
    includes: [
      'In-depth lash health & retention consultation',
      'Mega fans 7D–16D (0.03–0.05mm)',
      'Custom curl & length mapping',
      'Aftercare kit + fill booking priority',
    ],
    highlight: false,
  },
  {
    id:       'lash-fill',
    category: 'fills',
    name:     'Lash Fill',
    tagline:  'Keep your set looking full — every 2 to 3 weeks.',
    duration: '60–90 min',
    price:    'From $75',
    description:
      'Fills replace shed extensions and maintain the fullness of your set. Most clients fill every 2–3 weeks. Arrives with at least 40% retention for a fill (otherwise a new set is recommended). Classic, hybrid, or volume fill pricing varies.',
    includes: [
      'Removal of grown-out or twisted extensions',
      'Infill to full-set density',
      'Same curl, length, and mapping maintained',
      'Retention assessment & aftercare refresher',
    ],
    highlight: false,
  },
  {
    id:       'lift-tint',
    category: 'other',
    name:     'Lash Lift & Tint',
    tagline:  'All curl, no extensions. Your natural lashes, elevated.',
    duration: '60–75 min',
    price:    'From $95',
    description:
      'A lash lift sets your natural lashes in a lifted, curled position using a gentle perming solution. Paired with a lash tint for darkened, mascara-free results that last 6–8 weeks. No extensions, no upkeep — just beautiful natural lashes.',
    includes: [
      'Silicone shield lifting rod selection',
      'Lift treatment (6–8 week lasting curl)',
      'Keratin nourishing treatment',
      'Lash tint (black or brown)',
    ],
    highlight: false,
  },
  {
    id:       'removal',
    category: 'other',
    name:     'Lash Removal',
    tagline:  'Safe, gentle removal — no damage to natural lashes.',
    duration: '20–30 min',
    price:    'From $35',
    description:
      'Professional removal of eyelash extensions using a safe, solvent-based remover that breaks down the adhesive without pulling or stressing your natural lashes. Included free with any new full set booking at Lumière.',
    includes: [
      'Professional gel or cream remover',
      'Gentle brushing & rinse',
      'Natural lash health check',
      'Free when booked with a new full set',
    ],
    highlight: false,
  },
];

// ─── Aftercare tips ────────────────────────────────────────────────────────────
export type AftercareTip = { icon: string; title: string; body: string; };

export const aftercareTips: AftercareTip[] = [
  {
    icon:  '💧',
    title: 'Keep Dry for 24 Hours',
    body:  'Avoid water, steam, and sweat for the first 24 hours after your appointment to allow the adhesive to fully cure.',
  },
  {
    icon:  '🪥',
    title: 'Brush Daily',
    body:  'Gently brush your lashes with a clean spoolie wand each morning to keep extensions aligned and separated.',
  },
  {
    icon:  '🧴',
    title: 'Oil-Free Skincare',
    body:  'Oil-based products — including micellar water, sunscreen, and eye cream — break down lash adhesive. Switch to oil-free alternatives.',
  },
  {
    icon:  '😴',
    title: 'Sleep on Your Back',
    body:  'Side or stomach sleeping crushes extensions against the pillow. A silk pillowcase helps if you can\'t avoid it.',
  },
];

// ─── Testimonials ─────────────────────────────────────────────────────────────
export type Testimonial = {
  quote:   string;
  author:  string;
  service: string;
  rating:  number;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      'Noelle is hands-down the best lash artist in Austin. I\'ve been getting lashes for 4 years at different places and nothing compares. My retention is incredible — I still have 80% of my lashes at 3 weeks.',
    author:  'Kayla M.',
    service: 'Hybrid Lash Set — Regular Client',
    rating:  5,
  },
  {
    quote:
      'I was terrified to get extensions because of damage horror stories, but Noelle took so much time explaining the process and checking my natural lashes first. Six months later, my naturals are completely healthy.',
    author:  'Sofia R.',
    service: 'Classic Full Set',
    rating:  5,
  },
  {
    quote:
      'The studio is so clean and relaxing — I literally fall asleep every appointment. My mega volume set turns heads everywhere I go. People ask if they\'re real every single time.',
    author:  'Amber T.',
    service: 'Mega Volume Set',
    rating:  5,
  },
  {
    quote:
      'Switched to lash lift after years of extensions and I\'m obsessed. Noelle is so knowledgeable about what works for different eye shapes. My natural lashes have never looked better.',
    author:  'Jordan C.',
    service: 'Lash Lift & Tint',
    rating:  5,
  },
  {
    quote:
      'Lumière is a hidden gem in South Congress. Private suite means it\'s just you and Noelle — no distractions, total focus. I won\'t go anywhere else now.',
    author:  'Priya N.',
    service: 'Volume Full Set — Regular Client',
    rating:  5,
  },
];

// ─── FAQ ─────────────────────────────────────────────────────────────────────
export type FAQ = { q: string; a: string; };

export const faqs: FAQ[] = [
  {
    q: 'How long do eyelash extensions last?',
    a: 'A full set typically lasts 6–8 weeks before a fresh set is recommended. However, natural lash shedding means you\'ll notice gaps starting around 2–3 weeks. Most clients schedule fills every 2–3 weeks to maintain fullness. With great aftercare, many clients stretch fills to 3 weeks comfortably.',
  },
  {
    q: 'Do I need a patch test before my appointment?',
    a: 'Yes, if you\'re new to lash extensions or have a history of skin sensitivities or allergies, a patch test is strongly recommended. A small amount of adhesive is applied to the skin behind the ear or on the inner arm 24–48 hours before your appointment. This is available at no charge and can be done at a brief drop-in visit.',
  },
  {
    q: 'Can I wear mascara with eyelash extensions?',
    a: 'You don\'t need to — that\'s the whole point! If you do want extra definition at the tips, a water-based, oil-free mascara applied only to the tips (never the base) is acceptable. Avoid waterproof mascara entirely as it requires an oil-based remover which will dissolve the adhesive.',
  },
  {
    q: 'Will extensions damage my natural lashes?',
    a: 'When applied correctly by a trained technician using appropriate weight extensions, lash extensions do not damage natural lashes. Damage occurs from improper isolation, extensions that are too heavy, or poor aftercare. At Lumière, every set is customized to the health and strength of your natural lashes.',
  },
  {
    q: 'How soon can I get a fill after a full set?',
    a: 'Most clients are ready for their first fill 2–3 weeks after their full set. Arriving with at least 40% of your extensions still intact is ideal for a fill appointment. If you have less than 40% retention (for example, due to an illness, oily lids, or an extended gap), a new full set may be recommended at a discounted rate.',
  },
  {
    q: 'What is your cancellation policy?',
    a: 'Appointments can be rescheduled or cancelled up to 24 hours in advance with no charge. Cancellations within 24 hours of the appointment time are charged 50% of the service price. No-shows are charged 100%. A credit card is required to hold all bookings. The card is not charged unless a late cancellation or no-show occurs.',
  },
  {
    q: 'Are lash extensions safe during pregnancy?',
    a: 'Many pregnant clients continue getting lash extensions, but we always recommend consulting your OB/GYN first. Hormonal changes during pregnancy can affect natural lash shedding cycles and skin sensitivity to adhesives. We can discuss lower-fume adhesive options and ensure you\'re fully comfortable during the appointment.',
  },
  {
    q: 'What is the difference between Classic, Hybrid, and Volume?',
    a: 'Classic is one extension per natural lash — the most natural look. Volume uses handcrafted fans (3D–6D) for a fuller, fluffier result. Hybrid blends both techniques for texture and dimension. Mega-volume takes fans to 7D–16D for maximum drama. During your consultation, we\'ll review your eye shape, lifestyle, and goals to find the perfect style for you.',
  },
];
