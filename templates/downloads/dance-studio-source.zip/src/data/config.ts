export const studio = {
  name:        'Éclat Dance Academy',
  tagline:     'Where every dancer finds their light.',
  description: 'A premier multi-discipline dance academy in Lincoln Park, Chicago IL — Ballet, Jazz, Contemporary, Hip-Hop, and Ballroom for ages 3 to adult. Known for our annual Spring Showcase at the Athenaeum Theatre.',
  phone:       '(312) 555-0192',
  email:       'hello@eclatdance.com',
  address:     '2345 N Lincoln Ave',
  city:        'Chicago',
  state:       'IL',
  zip:         '60614',
  instagram:   'https://instagram.com/eclatdancechicago',
  facebook:    'https://facebook.com/eclatdancechicago',
  youtube:     'https://youtube.com/@eclatdancechicago',
  bookUrl:     'https://app.eclatdance.com/book',
  enrollUrl:   'https://app.eclatdance.com/enroll',
  headInstructor: {
    name:  'Sofia Laurent',
    title: 'Founder & Artistic Director',
    certs: ['Royal Academy of Dance ARAD', 'Vaganova Method Certified', '18 Years Teaching'],
  },
  makerBio: {
    name:     'Éclat Dance Academy',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Éclat Dance Academy | Ballet, Jazz & Contemporary Dance in Lincoln Park, Chicago',
  description:   'Éclat Dance Academy offers Ballet, Jazz, Contemporary, Hip-Hop, and Ballroom classes for ages 3 to adult in Lincoln Park, Chicago. Annual Spring Showcase. Enroll today — first class free for adults.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
