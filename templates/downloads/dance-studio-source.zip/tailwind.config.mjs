/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Josefin Sans"', 'system-ui', 'sans-serif'],
        body:    ['"Nunito Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: {
          50:  '#EEEEF5',
          100: '#D4D4E8',
          200: '#A8A8CC',
          300: '#7878A8',
          400: '#505080',
          500: '#353565',
          600: '#26264E',
          700: '#1A1B36',
          800: '#111426',
          900: '#0C0E18',
        },
        rose: {
          50:  '#FDF0F3',
          100: '#F8C8D5',
          200: '#F097AB',
          300: '#E46685',
          400: '#D4415F',
          500: '#C4315A',
          600: '#A82A4D',
          700: '#8C2240',
          800: '#6E1A32',
          900: '#4F1023',
        },
        gold: {
          50:  '#FDF8EF',
          100: '#F7E9C8',
          200: '#EDCF8C',
          300: '#E3B560',
          400: '#D4A054',
          500: '#BE8840',
          600: '#9A6C2E',
          700: '#775220',
          800: '#523714',
          900: '#2E1D08',
        },
      },
    },
  },
  plugins: [],
};
