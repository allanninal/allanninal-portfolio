import { test, expect } from '@playwright/test';

test.describe('Dance Studio — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title is set correctly', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Éclat Dance Academy');
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of ['classes', 'schedule', 'instructors', 'recital', 'enroll', 'pricing', 'testimonials', 'faq', 'contact']) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('booking links are present', async ({ page }) => {
    await page.goto('/');
    const bookLinks = page.locator('a[href*="eclatdance.com"]');
    const count = await bookLinks.count();
    expect(count).toBeGreaterThan(0);
  });

  test('tel and mailto links are present', async ({ page }) => {
    await page.goto('/');
    const telLinks  = page.locator('a[href^="tel:"]');
    const mailLinks = page.locator('a[href^="mailto:"]');
    const telCount  = await telLinks.count();
    const mailCount = await mailLinks.count();
    expect(telCount + mailCount).toBeGreaterThanOrEqual(2);
  });

  test('social links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const socialLinks = page.locator('a[target="_blank"][rel*="noopener"]');
    const count = await socialLinks.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    const favicon = page.locator('link[rel="icon"]');
    await expect(favicon).toBeAttached();
  });

  test('class schedule filter works', async ({ page }) => {
    await page.goto('/');
    const balletBtn = page.locator('.filter-btn[data-filter="Ballet"]');
    await balletBtn.click();
    await expect(balletBtn).toHaveClass(/active/);
    const visibleRows = page.locator('#schedule-table tbody tr:not([hidden])');
    const count = await visibleRows.count();
    expect(count).toBeGreaterThan(0);
  });

  test('pricing section has three tiers', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBe(3);
  });

  test('discipline cards are present and show all 5 disciplines', async ({ page }) => {
    await page.goto('/');
    const classCards = page.locator('.class-card');
    const count = await classCards.count();
    expect(count).toBe(5);
  });

  test('instructor cards are present', async ({ page }) => {
    await page.goto('/');
    const instructorCards = page.locator('.instructor-card');
    const count = await instructorCards.count();
    expect(count).toBe(4);
  });

  test('recital section is present with programme highlights', async ({ page }) => {
    await page.goto('/');
    const recital = page.locator('#recital');
    await expect(recital).toBeAttached();
    const numberCards = page.locator('.number-card');
    const numberCount = await numberCards.count();
    expect(numberCount).toBeGreaterThanOrEqual(4);
  });

  test('enroll section is present', async ({ page }) => {
    await page.goto('/');
    const enroll = page.locator('#enroll');
    await expect(enroll).toBeAttached();
  });
});
