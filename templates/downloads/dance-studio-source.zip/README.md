# Day 65 — Dance Studio

**Éclat Dance Academy** — a premier multi-discipline performing arts dance school template.

Live demo: [templates.allanninal.dev/dance-studio/](https://templates.allanninal.dev/dance-studio/)

Part of the [365 Astro Templates](https://allanninal.dev) project by [Allan Ninal](https://linkedin.com/in/allanninal).

## Features

- Five disciplines: Ballet, Jazz, Contemporary, Hip-Hop, Ballroom & Latin
- JS-filterable weekly class schedule table
- Four instructor profiles with credentials
- Annual Spring Recital / Showcase section (unique to dance — with venue, dates, programme highlights)
- New-student enrollment CTA (first adult class free)
- 3-tier pricing (Drop-In / Monthly Pack / Unlimited)
- 5 student testimonials
- 8-item FAQ accordion
- Contact form (Formspree) + studio hours table
- Fully accessible (axe WCAG AA, skip link, aria-pressed filter buttons)
- Schema.org: PerformingArtsTheater + LocalBusiness + SportsActivityLocation + Person + FAQPage + Service JSON-LD

## Visual identity

- **Palette**: Deep Stage Ink `#0C0E18` (dark default) + Rose Crimson `#C4315A` (CTAs, 5.33:1 AA on white) + Champagne Gold `#D4A054` (eyebrows, 8.7:1 AAA on dark bg)
- **Fonts**: Josefin Sans (display, first use) + Nunito Sans (body, first use)
- **Mood**: Theatrical, stage-lit, performing arts — distinct from all prior fitness templates in Sprint 3

## Getting started

```bash
npm install
npm run dev
```

Build for production:

```bash
npm run build
```

## Environment variables

See `.env.example`. All variables are optional for local development.

## Tests

```bash
npm run test:a11y       # axe WCAG AA
npm run test:links      # link integrity + DOM checks
npm run test:lighthouse # Performance/A11y/SEO/Best Practices ≥ 95
```

## License

MIT — free for personal and commercial use. See [LICENSE](LICENSE).
