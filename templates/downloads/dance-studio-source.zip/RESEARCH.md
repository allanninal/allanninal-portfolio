# Day 65 — Dance Studio: Niche Research

## Slug
`dance-studio`

## Visual differentiation from Days 60–64 (Sprint 3 fitness siblings)

### Taken palettes & fonts — Sprint 3 days 60–64
| Day | Template | Palette | Fonts | Default |
|-----|----------|---------|-------|---------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 | Dark |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira | Dark |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Red #EF4444 + Gold #C09030 | Black Ops One + Rubik | Dark |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 + Clay #A05540 | EB Garamond + Quicksand | Light |
| 64 | pilates-studio | Cool Stone #F5F4F1 + Deep Ocean Slate #2B5E7B | Prata + Fira Sans | Light |

### Day 65 distinct visual register

**DARK-DEFAULT template** — theatrical stage aesthetic, completely distinct from all 64 prior days:
- NOT the athletic/industrial darks of days 60–62 (carbon, steel, ring-mat)
- NOT yoga's warm-earthy linen or pilates' cool-stone precision
- Instead: **deep stage velvet + rose crimson + champagne gold** — the world of performance, spotlights, curtain calls

**Palette: Deep Stage Ink + Rose Crimson + Champagne Gold**
- Background: `#0C0E18` (Deep Stage Ink — very dark navy-indigo, not warm-brown or neutral-black)
- Background alt: `#111426` (slightly lighter for section alternation)
- Surface: `#181B2C` (card surfaces)
- Accent/CTA: `#C4315A` (Rose Crimson — white on it = 5.33:1 AA ✓; distinct from all prior reds/oranges)
- Accent hover: `#A82A4D`
- Gold/Eyebrow: `#D4A054` (Champagne Gold — 8.7:1 AAA on dark bg ✓; warm performance highlight)
- Text: `#F2EEF5` (warm near-white, soft lavender tint to avoid harshness)
- Text muted: `#9898AE` (soft blue-lavender gray, 7.5:1 AAA on dark bg ✓)
- Border: `#2A2E48`
- Border strong: `#3A4060`

**Fonts: Josefin Sans (display) + Nunito Sans (body)** — FIRST USE of both in the 365 library
- Josefin Sans: tall, thin geometric elegant font with strong vertical rhythm — feels like a marquee, a program booklet, a dancer's elongated silhouette
- Nunito Sans: clean, rounded body text with warmth and legibility — approachable for parents booking kids' classes
- Combined feel: elegant + welcoming, exactly what a multi-discipline dance academy communicates
- Distinct from all prior fitness typography (sporty condensed, classical serif, precision humanist)

## Persona & Business Model

**Studio**: Éclat Dance Academy
**Tagline**: Where every dancer finds their light.
**Location**: 2345 N Lincoln Ave, Lincoln Park, Chicago, IL 60614
**Founded**: 2015

**Audience**: Children (ages 3–17), teens, and adult beginners to advanced. Multi-genre dance academy emphasizing artistic development + performance.

**Unique differentiator from Sprint 3 siblings**:
- Pilates/yoga: adult-focused wellness/fitness modalities
- Gym/CrossFit/Boxing: athletic performance
- Dance studio: performing arts education — class types, recital program, age-grouped curriculum, artistic identity

**Disciplines** (5 class types):
1. Ballet — classical technique, all ages/levels
2. Jazz — theatrical, all levels
3. Contemporary — modern movement, intermediate+
4. Hip-Hop — street styles, all levels
5. Ballroom & Latin — adult social dance

**Key sections** (unique to dance: recital info!):
1. Hero — stage curtain / spotlight aesthetic
2. Stats band — disciplines, instructors, years, Spring Recital
3. Classes (5 disciplines with levels, descriptions)
4. Weekly schedule (JS-filterable)
5. Instructors (4 profiles with credentials)
6. Spring Recital / Annual Showcase — unique to dance
7. New student enrollment offer
8. Pricing (3 tiers)
9. Testimonials
10. FAQ
11. Contact

**Schema.org**: PerformingArtsTheater + LocalBusiness + SportsActivityLocation + Person + FAQPage

## Instructors

1. **Sofia Laurent** — Artistic Director & Ballet Principal
   - Royal Academy of Dance ARAD certified, Vaganova method trained
   - Former principal dancer with Chicago City Ballet
   - 18 years teaching
   
2. **Marcus Okafor** — Jazz & Hip-Hop Director
   - BFA Dance, Illinois State University
   - Former Broadway ensemble (Hamilton national tour)
   - Specializes in commercial jazz and street styles

3. **Priya Raghavan** — Contemporary & Modern
   - MFA Dance, University of Illinois
   - Laban Movement Analysis certified
   - Collaborates with Chicago contemporary companies

4. **Elena Novak** — Ballroom & Latin
   - ISTD Fellow (Imperial Society of Teachers of Dancing)
   - Former UK Latin champion
   - DanceSport certified coach

## Spring Recital (Unique Section)

**Event**: Spring Showcase 2026 "Illuminate"
**Venue**: The Athenaeum Theatre, Chicago
**Date**: Saturday, May 16 & Sunday, May 17, 2026
**Content**: 22 numbers across all disciplines, professional lighting & sound, printed programs
**Tickets**: $28 general / $18 students+seniors (handled at box office)
**Costume**: Included in recital fee ($85 one-time for enrolled students)
