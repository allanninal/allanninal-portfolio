import { test, expect } from '@playwright/test';

test.describe('Wren Halloway — smoke tests', () => {
  test('homepage renders with the artist name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Wren Halloway/);
    await expect(page.locator('h1')).toContainText('what the night is');
  });

  // Sixth schema shape in five days. MusicGroup is the first with first-class
  // album and event properties.
  test('is a MusicGroup with albums and events', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"MusicGroup"');
    expect(json).toContain('"MusicAlbum"');
    expect(json).toContain('"MusicEvent"');
    expect(json).not.toContain('makesOffer');
    expect(json).not.toContain('Disc jockey');
  });

  // Publishing a sold-out show as an available event is markup that makes a
  // rich result actively wrong.
  test('only on-sale dates are emitted as events', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('MusicGroup')) || '');
    const schema = JSON.parse(raw);
    const onSale = (await page.locator('#tour .status').allTextContents())
      .map((s) => s.trim()).filter((s) => s === 'On sale').length;
    expect(schema.event.length).toBe(onSale);
    const gone = (await page.locator('#tour .status').allTextContents())
      .map((s) => s.trim()).filter((s) => s === 'Sold out').length;
    expect(gone).toBeGreaterThan(0);
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#tour .tour');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(400);
  });

  // ── Tour ────────────────────────────────────────────────────────────────
  test('every date answers the four questions a listing normally omits', async ({ page }) => {
    await page.goto('/');
    const dates = page.locator('#tour details');
    const n = await dates.count();
    expect(n).toBe(12);
    for (const d of await dates.all()) {
      const summary = ((await d.locator('summary').textContent()) || '');
      expect(summary).toMatch(/Seated|Standing/);
      expect(summary).toMatch(/Solo|Duo|Full band/);
      const labels = (await d.locator('.body dt').allTextContents()).map((s) => s.trim());
      expect(labels).toEqual(['Room', 'Format', 'Support', 'Curfew']);
      expect(((await d.locator('.body .date').textContent()) || '')).toMatch(/On stage \d\d:\d\d/);
    }
  });

  test('dates are closed by default and open on click', async ({ page }) => {
    await page.goto('/');
    const dates = page.locator('#tour details');
    for (const d of await dates.all()) expect(await d.getAttribute('open')).toBeNull();
    const first = dates.first();
    await first.locator('summary').click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the seated / standing counts are derived from the dates', async ({ page }) => {
    await page.goto('/');
    const rooms = await page.locator('#tour summary .shape').allTextContents();
    const seated = rooms.filter((r) => r.includes('Seated')).length;
    const standing = rooms.filter((r) => r.includes('Standing')).length;
    const n = await page.locator('#tour details').count();
    await expect(page.locator('#tour h2'))
      .toHaveText(`${n} dates. ${seated} seated, ${n - seated} standing.`);
    expect(seated + standing).toBe(n);
  });

  test('sold-out dates stay on the list and say why that is deliberate', async ({ page }) => {
    await page.goto('/');
    const statuses = (await page.locator('#tour .status').allTextContents()).map((s) => s.trim());
    for (const s of statuses) expect(['On sale', 'Sold out']).toContain(s);
    const gone = statuses.filter((s) => s === 'Sold out').length;
    await expect(page.locator('#tour')).toContainText(`${gone} of ${statuses.length} gone.`);
    await expect(page.locator('#tour')).toContainText(/quietly deletes the sold-out dates/i);
    for (const el of await page.locator('#tour .status').all()) {
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
  });

  // ── Store ───────────────────────────────────────────────────────────────
  test('the store publishes what reaches the artist, including a stream', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#store tbody tr');
    expect(await rows.count()).toBeGreaterThan(4);
    const text = (await page.locator('#store').textContent()) || '';
    expect(text).toContain('One stream');
    expect(text).toMatch(/\$0\.00\d/);
    // The headline is read from the first row rather than typed.
    const price = ((await rows.first().locator('.num').first().textContent()) || '').trim();
    const keep = ((await rows.first().locator('.keep').textContent()) || '').trim();
    await expect(page.locator('#store h2')).toHaveText(`${price} direct is ${keep} to me.`);
  });

  test('the streaming row is a number, not an argument', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#store')).toContainText(/this is a number, not an argument/i);
  });

  // ── Photographs ─────────────────────────────────────────────────────────
  test('both photographs load and neither is a portrait', async ({ page }) => {
    await page.goto('/');
    const imgs = page.locator('figure.plates img');
    expect(await imgs.count()).toBe(2);
    for (const i of await imgs.all()) {
      expect(((await i.getAttribute('alt')) || '').length).toBeGreaterThan(30);
    }
    await expect(page.locator('#faq')).toContainText(/Wren Halloway is fictional/i);
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((all) =>
      all.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
         .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  // The CTA on an artist page is a list, not a quote request.
  test('the mailing form asks only for an email', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#email')).toHaveAttribute('required', '');
    expect(await page.locator('#list input[required], #list textarea[required]').count()).toBe(1);
    await expect(page.locator('#list')).toContainText(/Six emails a year/i);
  });

  test('no trace of the day-112 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['sula brant', 'detroit', 'rider', 'click track', 'bpm', 'promoter']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro tour sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/tour-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
