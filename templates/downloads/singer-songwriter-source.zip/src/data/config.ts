// Wren Halloway — Portland, ME. Fictional.
//
// An artist's own page. Days 111 and 112 sold work to a client; this sells a
// ticket and a record to a listener, which is a different job.
//
// The claim: a tour date is four facts and every listing on the internet gives
// you one. Seated or standing, solo or band, when the headline actually starts,
// and whether it is gone.

export const site = {
  name:        'Wren Halloway',
  shortName:   'Wren Halloway',
  title:       'Wren Halloway — songs, shows, records',
  tagline:     'Every date says what the night is.',
  owner:       'Wren Halloway',
  ownerRole:   'Songwriter',
  credential:  'Three records · Portland, Maine',
  city:        'Portland',
  state:       'ME',
  language:    'en',
  phoneDisplay: '(207) 555-0119',
  phoneHref:   '+12075550119',
  email:       'hello@wrenhalloway.example',
  streetAddress: '54 Danforth St',
  postalCode:  '04101',
  hours:       'Answered by me, not by a team',
  bookingWindow: 'Autumn dates on sale · a mailing list, not a feed',
  description:
    '“Fri 14 Nov · Bramble Hall · Tickets” tells you nothing about whether to come. Seated or ' +
    'standing? Solo or with a band? Does the headline start at nine or half eleven? Every date ' +
    'below answers all four before you buy, which is the least a listing can do.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Dates',   href: '#tour' },
  { label: 'Records', href: '#records' },
  { label: 'Store',   href: '#store' },
  { label: 'The list', href: '#list' },
];

// ── Tour ──────────────────────────────────────────────────────────────────
// Four facts per date, plus a sentence about what the night is actually like.
// `status` is 'on' or 'gone'; sold-out dates stay on the list with the reason.

export const tour = [
  { date: 'Wed 8 Oct',  city: 'Portland, ME',   venue: 'The Danforth Room',
    room: 'Seated, 90', format: 'Solo', support: 'None', stage: '20:30', curfew: '22:30', status: 'on',
    note: 'The quiet one. No support, no interval, and the bar closes during the set. If you have only been to the loud shows, this is the other kind.' },
  { date: 'Fri 10 Oct', city: 'Portsmouth, NH', venue: 'Bramble Hall',
    room: 'Standing, 300', format: 'Full band', support: 'Ondine Ruiz', stage: '21:45', curfew: '23:30', status: 'on',
    note: 'Loud, late, and the last forty minutes are the reason to come. Support is on at 20:30 and worth arriving for.' },
  { date: 'Sat 11 Oct', city: 'Boston, MA',     venue: 'Harborlight',
    room: 'Standing, 450', format: 'Full band', support: 'Ondine Ruiz', stage: '21:30', curfew: '23:00', status: 'gone',
    note: 'Sold out in nine days. There is no waiting list and I would rather say that than run one that never moves.' },
  { date: 'Sun 12 Oct', city: 'Northampton, MA', venue: 'The Pearl Street Annexe',
    room: 'Seated, 180', format: 'Duo', support: 'None', stage: '20:00', curfew: '22:00', status: 'on',
    note: 'Early finish on a Sunday, deliberately. Cello and guitar, and about half the set is from the first record.' },
  { date: 'Tue 14 Oct', city: 'Albany, NY',     venue: 'Quarry Light',
    room: 'Standing, 250', format: 'Full band', support: 'Local, TBC', stage: '21:15', curfew: '23:00', status: 'on',
    note: 'A Tuesday, so it will be a smaller room than the weekend and better for it.' },
  { date: 'Thu 16 Oct', city: 'Philadelphia, PA', venue: 'Ninth & Vance',
    room: 'Standing, 400', format: 'Full band', support: 'Emory Bell', stage: '21:30', curfew: '00:00', status: 'on',
    note: 'The longest set of the run, and the only midnight curfew. Bring shoes you can stand in.' },
  { date: 'Fri 17 Oct', city: 'Baltimore, MD',  venue: 'The Wharf Rooms',
    room: 'Standing, 300', format: 'Full band', support: 'Emory Bell', stage: '21:45', curfew: '23:30', status: 'gone',
    note: 'Gone. A second night was offered and I said no — two nights in a room this size on a routing this tight is how a voice ends a tour early.' },
  { date: 'Sun 19 Oct', city: 'Pittsburgh, PA', venue: 'Union Vault',
    room: 'Seated, 220', format: 'Solo', support: 'None', stage: '20:00', curfew: '22:00', status: 'on',
    note: 'Seated and solo in a room that usually is not either. Requests taken between songs, within reason.' },
  { date: 'Wed 22 Oct', city: 'Columbus, OH',   venue: 'Pallet & Pine',
    room: 'Standing, 200', format: 'Duo', support: 'None', stage: '20:45', curfew: '22:30', status: 'on',
    note: 'Standing but small. Somewhere between the quiet show and the loud one, which is where most of these songs actually live.' },
  { date: 'Fri 24 Oct', city: 'Chicago, IL',    venue: 'Corktown Social',
    room: 'Standing, 500', format: 'Full band', support: 'Two openers', stage: '22:00', curfew: '00:00', status: 'on',
    note: 'The biggest room of the run and the latest start. Two openers means doors at seven and me at ten — plan accordingly.' },
  { date: 'Sat 25 Oct', city: 'Milwaukee, WI',  venue: 'Northline Hall',
    room: 'Seated, 400', format: 'Full band', support: 'Local, TBC', stage: '21:00', curfew: '23:00', status: 'on',
    note: 'A seated theatre with a full band, which is unusual and my favourite kind of night.' },
  { date: 'Sun 26 Oct', city: 'Minneapolis, MN', venue: 'Beulah Street Chapel',
    room: 'Seated, 140', format: 'Solo', support: 'None', stage: '19:30', curfew: '21:30', status: 'on',
    note: 'Last night of the run, earliest start, and by then my voice will be honest about the twelve dates behind it.' },
];

export const TICKET = {
  on:   { label: 'On sale',  glyph: '·' },
  gone: { label: 'Sold out', glyph: '×' },
} as const;

export const tourNote =
  'Two of these are gone and they stay on the list, because a tour page that quietly deletes the ' +
  'sold-out dates makes the run look smaller than it is and tells the person who missed one ' +
  'nothing. Where a room sold out fast, the next routing goes somewhere bigger in that city — ' +
  'that is the only thing this list is actually for.';

// ── Records ───────────────────────────────────────────────────────────────

export const records = [
  { title: 'Low Water Mark', year: '2025', len: '38 min', tracks: 10,
    how: 'Recorded live to two-inch tape in four days with the band in one room. Three songs are first takes and one of them has a mistake in it that we kept.',
    what: 'The loudest of the three and the one the standing shows are built from.' },
  { title: 'Every Third Sunday', year: '2022', len: '44 min', tracks: 12,
    how: 'Made at home over eighteen months, mostly at night, mostly alone. Two songs have a cello on them and nothing else does.',
    what: 'The quiet record. If you liked one of these and not the others, it is usually this one.' },
  { title: 'Cane Break', year: '2019', len: '31 min', tracks: 9,
    how: 'First record, made for very little in a rented church hall with a borrowed pair of microphones.',
    what: 'Rougher than the other two and I have stopped apologising for it. Half the seated set still comes from here.' },
];

// ── Store ─────────────────────────────────────────────────────────────────
// What it costs, and what actually reaches the artist. One row of streaming
// equivalence, not a lecture.

export const store = {
  intro:
    'What things cost, and what actually reaches me. Not a guilt trip about streaming — the ' +
    'numbers, so you can decide with them instead of around them.',
  rows: [
    { item: 'Digital album, direct',  price: '$10.00', keep: '$8.20',  note: 'Card fees and the platform cut. This is by a distance the most efficient way to support a record.' },
    { item: 'Vinyl, 12"',             price: '$32.00', keep: '$9.40',  note: 'Pressing, sleeve, shipping and breakage. It is the least profitable thing I sell and I keep making it anyway.' },
    { item: 'CD',                     price: '$14.00', keep: '$7.10',  note: 'Cheap to make, and still the best-selling item at a seated show by a wide margin.' },
    { item: 'T-shirt',                price: '$28.00', keep: '$11.50', note: 'Before the venue merch cut, which is 10–25% at most rooms on this run.' },
    { item: 'Ticket, seated show',    price: '$24.00', keep: '$8.75',  note: 'After the venue, the agent, the support and the crew. On a good night the band and I are paid; on a Tuesday in a 250-room we are not.' },
    { item: 'One stream',             price: '—',      keep: '$0.0035', note: 'Which is why the first row exists. Buying the album once is worth about 2,300 plays, and both are fine — this is a number, not an argument.' },
  ],
};

export const said = {
  text: 'I drove two hours for what I assumed was the solo show and it was the full band. My fault for not asking, except there was nowhere to ask. This page would have told me in one line.',
  who: 'From a message after a show in 2024 — the reason the dates changed',
};

export const faqs = [
  {
    q: 'Why is there no photo of you?',
    a: 'Because this is a website template and Wren Halloway is fictional. A stock portrait presented as a named performer would be inventing a person, which is a different thing from inventing a song. The two photographs are a seated room and a guitar case: real kinds of place and real objects, standing in for whatever the person using this template actually has.',
  },
  {
    q: 'What does "solo" versus "full band" change?',
    a: 'Volume, length, and about half the setlist. The solo shows are quieter and lean on the older records; the band shows are louder, later, and built from the newest one. Neither is the real version — they are two different nights and the point of this page is that you get to choose.',
  },
  {
    q: 'Why keep sold-out dates on the list?',
    a: 'Because deleting them makes the run look smaller than it is and tells the person who missed one nothing. Where a room sold out fast, the next tour goes somewhere bigger in that city, and that is genuinely the main thing this list is for.',
  },
  {
    q: 'Will you add a second night?',
    a: 'Almost never on a tight routing. Two nights in the same room means either a day off I do not have or a voice that will not last to the end of the run. I would rather come back in six months.',
  },
  {
    q: 'Do you take requests?',
    a: 'At the seated shows, between songs, within reason — some of them I genuinely cannot play any more without a week of practice. At the band shows the set is fixed because five people have to know what is next.',
  },
  {
    q: 'Is there a mailing list, or should I follow you somewhere?',
    a: 'A mailing list. Roughly six emails a year, all of them either a tour or a record, and no algorithm decides whether you see them. That is the only reason to prefer it and it is a good one.',
  },
];
