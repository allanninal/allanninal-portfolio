export const chef = {
  name: 'Marcus Elliot',
  title: 'Private Chef',
  tagline: 'Intimate Dining, Crafted for You',
  bio: `Chef Marcus Elliot has spent fifteen years in Michelin-starred kitchens from Paris to New York before taking his craft into private homes. With each dinner, he brings the precision of a professional kitchen and the warmth of personal service — arriving with ingredients sourced that morning, cooking in your kitchen, and leaving nothing behind but a memory you'll revisit for years.`,
  bioShort: 'Michelin-trained private chef bringing restaurant-quality dining to intimate gatherings.',
  credentials: [
    'Culinary Institute of America, 2009',
    'Former Sous Chef — Le Bernardin, New York',
    'Former Chef de Partie — Le Meurice, Paris',
    '12+ years private chef experience',
    'ServSafe Certified',
    'Specialises in New American & French cuisine',
  ],
  instagram: 'https://www.instagram.com/',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  email: 'hello@marcuselliot.com',
  phone: '+1 (212) 555-0147',
  location: 'New York City & Tri-State Area',
  kofi: 'https://ko-fi.com/allanninal',
};

export const site = {
  title: 'Chef Marcus Elliot — Private Chef, New York City',
  description: 'Private chef Marcus Elliot brings Michelin-trained cuisine to your home. Bespoke private dinners, weekly meal prep, special occasions, and cooking lessons in NYC.',
  language: 'en',
  ogImage: '/og-image.png',
  twitterHandle: '@allanninal',
};

export const services = [
  {
    id: 'private-dinners',
    icon: '&#x1F37D;',
    title: 'Private Dinners',
    description: 'A bespoke tasting experience for 2–14 guests. Marcus arrives 2 hours early, cooks in your kitchen, plates every course, and tidies up after — you simply enjoy.',
    details: ['2–14 guests', 'Custom menu created with you', 'Sourced ingredients', 'Full kitchen clean-up', 'Service included'],
    from: 'From $350 per guest',
  },
  {
    id: 'meal-prep',
    icon: '&#x1F96C;',
    title: 'Weekly Meal Prep',
    description: 'Nutritious, chef-crafted meals prepared weekly in your home. Portioned, labelled, and ready to heat — so every dinner feels effortless even on the busiest nights.',
    details: ['Weekly or bi-weekly', 'Tailored to dietary needs', '5–7 meals per session', 'Pantry stocking guidance', 'Nutritional planning available'],
    from: 'From $600 per session',
  },
  {
    id: 'special-occasions',
    icon: '&#x2728;',
    title: 'Special Occasions',
    description: 'Anniversaries, proposals, milestone birthdays, and holiday gatherings — Marcus designs a menu and experience that reflects your moment and the people sharing it.',
    details: ['Fully tailored experience', 'Themed menus available', 'Pairing with sommelier', 'Floral & décor coordination', 'Up to 20 guests'],
    from: 'From $450 per guest',
  },
  {
    id: 'cooking-lessons',
    icon: '&#x1F468;&#x200D;&#x1F373;',
    title: 'Cooking Lessons',
    description: 'One-on-one or small-group sessions (up to 6) where Marcus teaches fundamental techniques, knife skills, and signature recipes in the comfort of your own kitchen.',
    details: ['1–6 students', '90–120 minute sessions', 'Hands-on technique focus', 'Recipe booklet included', 'Ingredients provided'],
    from: 'From $280 per session',
  },
];

export const menus = [
  {
    id: 'autumn-harvest',
    src: 'autumn',
    season: 'Autumn',
    name: 'Harvest Table',
    description: 'A celebration of peak-season produce from New York state farms, anchored by technique learned in French kitchens.',
    courses: [
      { course: 'Amuse-bouche', dish: 'Butternut squash velouté, toasted pepitas, crème fraîche' },
      { course: 'First', dish: 'Seared scallop, celery root purée, calvados-apple butter, micro-herbs' },
      { course: 'Second', dish: 'Wild mushroom consommé, chestnut gnudi, truffle oil' },
      { course: 'Third', dish: 'Duck magret, roasted parsnip, port-cherry reduction, crispy kale' },
      { course: 'Pre-dessert', dish: 'Poached pear sorbet, elderflower, pink peppercorn' },
      { course: 'Dessert', dish: 'Tarte tatin, salted caramel, Tahitian vanilla ice cream' },
      { course: 'Mignardises', dish: 'Dark chocolate truffles, candied orange peel' },
    ],
    dietary: 'Gluten-free adaptable · Nut-free on request',
    pairing: 'Pairs beautifully with Burgundy Pinot Noir or dry Alsatian Riesling',
  },
  {
    id: 'summer-coast',
    src: 'summer',
    season: 'Summer',
    name: 'Coastal Summer',
    description: 'Light, vibrant, and seafood-forward — a menu built around the bounty of the East Coast at its peak.',
    courses: [
      { course: 'Amuse-bouche', dish: 'Cucumber gazpacho shot, dill oil, caviar pearl' },
      { course: 'First', dish: 'Yellowfin tuna crudo, avocado, yuzu kosho, shiso, sesame crisp' },
      { course: 'Second', dish: 'Lobster bisque, tarragon cream, brioche mouillette' },
      { course: 'Third', dish: 'Halibut en papillote, summer vegetables, saffron beurre blanc' },
      { course: 'Pre-dessert', dish: 'Passion fruit granita, coconut foam' },
      { course: 'Dessert', dish: 'Strawberry mille-feuille, Chantilly cream, basil oil' },
      { course: 'Mignardises', dish: 'Raspberry pâte de fruit, lemon sablé' },
    ],
    dietary: 'Dairy-free adaptable · Shellfish allergy alternative available',
    pairing: 'Perfect with Chablis Premier Cru or Pouilly-Fumé',
  },
  {
    id: 'winter-warmth',
    src: 'winter',
    season: 'Winter',
    name: 'Winter Warmth',
    description: 'Deeply comforting yet refined — slow-cooked richness elevated with classical technique and warming spice.',
    courses: [
      { course: 'Amuse-bouche', dish: 'Roasted beet tartare, horseradish cream, rye crisp' },
      { course: 'First', dish: 'Seared foie gras, brioche toast, Sauternes jelly, micro-greens' },
      { course: 'Second', dish: 'Black truffle risotto, aged Parmesan, Madeira foam' },
      { course: 'Third', dish: 'Wagyu beef short rib (72hr), potato rösti, miso-glazed carrots, jus' },
      { course: 'Pre-dessert', dish: 'Earl Grey panna cotta, blood orange' },
      { course: 'Dessert', dish: 'Valrhona chocolate fondant, smoked salt, vanilla bean ice cream' },
      { course: 'Mignardises', dish: 'Salted caramel bonbons, hazelnut praline' },
    ],
    dietary: 'Vegetarian alternative available for all courses',
    pairing: 'Exceptional with aged Bordeaux or a rich Napa Cabernet',
  },
];

export const testimonials = [
  {
    quote: 'Marcus transformed our anniversary into something we still talk about two years later. The food was extraordinary — but it was the care in every detail that made it unforgettable.',
    author: 'Sarah & David K.',
    occasion: 'Anniversary Dinner, Upper East Side',
  },
  {
    quote: 'I\'ve had Marcus come weekly for eight months now. My relationship with food has completely changed — I eat better, feel better, and genuinely look forward to opening the fridge.',
    author: 'James T.',
    occasion: 'Weekly Meal Prep Client',
  },
  {
    quote: 'We hired Marcus for my mother\'s 70th birthday — twenty family members, all with different dietary needs. He handled everything with grace and turned out food that rivalled the best restaurants in the city.',
    author: 'The Okonkwo Family',
    occasion: 'Birthday Celebration, Brooklyn',
  },
  {
    quote: 'The cooking lesson was the best gift I\'ve ever received. Marcus is patient, funny, and impossibly talented. I learned more in two hours than I had in a lifetime of cooking.',
    author: 'Priya M.',
    occasion: 'Cooking Lesson, Manhattan',
  },
];

export const process = [
  {
    step: '01',
    title: 'First Conversation',
    description: 'A 20-minute call to understand your preferences, dietary needs, the occasion, and what you\'re hoping to feel — not just eat.',
  },
  {
    step: '02',
    title: 'Bespoke Menu',
    description: 'Marcus designs a menu specifically for you, sourced to the season and refined until it feels exactly right. No templates, no repeats.',
  },
  {
    step: '03',
    title: 'The Experience',
    description: 'Marcus arrives, sets up, cooks, plates each course, and ensures the evening flows seamlessly. You are a guest at your own table.',
  },
  {
    step: '04',
    title: 'Spotless Departure',
    description: 'Every surface wiped, every dish washed, every trace of the kitchen work gone. All that remains is the conversation and the memory.',
  },
];
