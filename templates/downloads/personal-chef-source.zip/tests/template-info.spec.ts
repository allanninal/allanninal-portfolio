import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo shows the right buttons when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const info = page.locator(BAR);
  await expect(info).toBeVisible();

  // Static download present in both editions.
  await expect(info.locator('a[download]').first()).toBeVisible();

  // Free has a second download (Source); Pro swaps it for a locked "Get Pro static".
  if (isPro) {
    await expect(info.locator('a', { hasText: 'Get Pro static' })).toBeVisible();
  } else {
    await expect(info.locator('a[download]').nth(1)).toBeVisible();
  }

  // All 365 link
  await expect(info.locator('a', { hasText: 'All 365' })).toBeVisible();

  // LinkedIn link — "Build with me" (free) / "Get Pro static" (pro)
  const linkedin = info.locator('a', { hasText: isPro ? 'Get Pro static' : 'Build with me' });
  await expect(linkedin).toBeVisible();
  expect(await linkedin.getAttribute('href')).toContain('linkedin.com');
});

test('TemplateInfo has no github.com/allanninal/templates links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`${BAR} a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});

test('TemplateInfo shows the edition tagline', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR)).toContainText(isPro ? 'Pro edition' : 'Day 49 of 365');
});
