import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Chef Marcus Elliot/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('services section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#services')).toBeVisible();
});

test('services grid has 4 cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#services article');
  const count = await cards.count();
  expect(count).toBe(4);
});

test('menus section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menus')).toBeVisible();
});

test('menu tabs are present', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = await page.locator('[role="tab"]').all();
  if (tabs.length > 1) {
    await tabs[1].click();
    const selected = await tabs[1].getAttribute('aria-selected');
    expect(selected).toBe('true');
  }
});

test('process section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#process')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('testimonials has reviews', async ({ page }) => {
  await page.goto('/');
  const quotes = page.locator('.testimonial-card');
  const count = await quotes.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('contact section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#contact')).toBeVisible();
});

test('LinkedIn contact link is present', async ({ page }) => {
  await page.goto('/');
  const contactSection = page.locator('#contact');
  const linkedinLink = contactSection.locator('a[href*="linkedin.com"]');
  await expect(linkedinLink.first()).toBeVisible();
});

test('contact form is present', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('.contact-form');
  await expect(form).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link is present', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('.skip-link');
  await expect(skipLink).toBeAttached();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('mobile menu button exists', async ({ page }) => {
  await page.goto('/');
  const mobileBtn = page.locator('#mobile-menu-btn');
  await expect(mobileBtn).toBeAttached();
});
