// Quarry Line Records — Lawrence, KS. Fictional, and the calendar is the point:
// every elapsed figure below is consistent with the others, and the lane chart
// on the page is generated from `stages`, so the drawing cannot disagree with
// the arithmetic.
//
// The organising idea: a record is finished in January and out in September,
// and seven of those nine months are queueing rather than working. Nobody in
// the chain controls the queue and no label site says so.

export const site = {
  name:        'Quarry Line Records',
  shortName:   'Quarry Line',
  title:       'Quarry Line Records — a small label in Lawrence, Kansas',
  tagline:     'Finished in January. Out in September.',
  owner:       'Odell Vandermeer',
  ownerRole:   'Label manager',
  credential:  'Since 2014 · 31 releases · four artists',
  city:        'Lawrence',
  state:       'KS',
  language:    'en',
  phoneDisplay: '(785) 555-0139',
  phoneHref:   '+17855550139',
  email:       'odell@quarrylinerecords.example',
  streetAddress: '714 Massachusetts St',
  postalCode:  '66044',
  hours:       'Demos read Mondays · everything else within a week',
  bookingWindow: 'Plant slots booked six months ahead · release dates confirmed at the cutoff, not before',
  description:
    'A record is finished in January and comes out in September, and seven of those nine months ' +
    'are a queue nobody in the chain controls. This page publishes the calendar — what is work, ' +
    'what is waiting, what can be moved and what it costs — because an artist who knows that in ' +
    'month one is a different artist from one who finds out in month five.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The nine months', href: '#lane' },
  { label: 'What can move',   href: '#move' },
  { label: 'Roster',          href: '#roster' },
  { label: 'Demos',           href: '#demos' },
];

// ── The lane chart ────────────────────────────────────────────────────────
// One release, day 0 = masters delivered. `kind` is 'work' or 'queue', and the
// distinction is the entire argument. Bars are drawn from `start` and `days`;
// both numbers are printed as text beside every row.

export const release = {
  title: 'Belle Plaine — “Kanopolis”',
  album: 'Kanopolis',
  artist: 'Belle Plaine',
  delivered: 'Masters delivered 14 January 2026',
  out: 'Released 25 September 2026',
  // The two dates the whole page is the distance between.
  createdISO: '2026-01-14',
  publishedISO: '2026-09-25',
};

export const stages = [
  { k: 'Mastering',                 start: 0,   days: 11,  kind: 'work',  who: 'Us',
    n: 'Two attended passes and a week between them, which is a week of listening rather than a week of waiting. The only stage on this list where more money buys more quality instead of a better place in a line.' },
  { k: 'Plant slot booked',         start: 4,   days: 1,   kind: 'work',  who: 'Us',
    n: 'Booked on day four, eleven days before mastering is even signed off. A slot booked in March is a September record and a slot booked in June is next year, so the booking has to come first. It feels reckless and it is the opposite.' },
  { k: 'Lacquer cut and plating',   start: 11,  days: 17,  kind: 'work',  who: 'Plant',
    n: 'Real work by real people, and the last point at which the audio can still change. After this the record is a physical object being manufactured.' },
  { k: 'Test pressing in the post', start: 28,  days: 12,  kind: 'queue', who: 'Nobody',
    n: 'Two discs travelling from the plant to a kitchen table in Kansas. Twelve days of the release calendar spent in a padded envelope, and there is no version of this that is faster.' },
  { k: 'Test pressing approval',    start: 40,  days: 6,   kind: 'work',  who: 'Artist',
    n: 'The artist listens on two systems and says yes or no. Six days because people have jobs. A no here costs eleven weeks and it is still the right answer if the answer is no.' },
  { k: 'Pressing queue',            start: 46,  days: 118, kind: 'queue', who: 'Plant',
    n: 'A hundred and eighteen days in which nothing whatsoever happens to your record. This single bar is longer than every piece of work on this page added together, and it is the reason the whole calendar looks the way it does.' },
  { k: 'Sleeves printed',           start: 118, days: 21,  kind: 'work',  who: 'Printer',
    n: 'Runs inside the pressing window, which is the one piece of good news on this list. Artwork is due here, not at the end, and a late sleeve is the most avoidable delay in the business.' },
  { k: 'Long-lead press embargo',   start: 198, days: 56,  kind: 'work',  who: 'Us',
    n: 'Monthlies and long-lead press need the record eight weeks before it exists in shops. The version they get is a stream, not a record, which is its own small indignity.' },
  { k: 'Distribution cutoff',       start: 208, days: 1,   kind: 'work',  who: 'Distributor',
    n: 'The hardest date on the page. Miss it by one day and the release moves by a month, because the calendar is a grid and there is no space between the lines.' },
  { k: 'Radio servicing',           start: 212, days: 42,  kind: 'work',  who: 'Us',
    n: 'Six weeks out. Overlaps the press window on purpose — a station that hears about a record only from a press release has already decided.' },
  { k: 'Records arrive with us',    start: 164, days: 14,  kind: 'queue', who: 'Freight',
    n: 'Palletised, from the plant to a storage unit off 23rd. Two weeks and one phone call about a loading dock.' },
  { k: 'Release day',               start: 254, days: 1,   kind: 'work',  who: 'Everyone',
    n: 'A Friday, always, because the charts week starts on one. Two hundred and fifty-four days after the masters were finished.' },
];

export const laneNote =
  'Solid bars are work. Outlined bars are waiting. None of the waiting is anybody in this chain ' +
  'being slow — the plant is not slow, the plant is full, which is a different problem and not ' +
  'one an artist can fix by asking twice. The useful thing about seeing it laid out is that it ' +
  'is knowable in month one. Every argument a label has with an artist about a release date is ' +
  'an argument about a chart nobody drew.';

// ── What can be moved ─────────────────────────────────────────────────────
// `move` is 'yes' | 'money' | 'no'. Never colour alone: every row prints the word.

export const moves = [
  { k: 'Mastering',        move: 'yes',   cost: 'Nothing',        lose: 'A week of listening. The second pass exists because the first one is never right, and skipping it is the cheapest bad decision available.' },
  { k: 'Lacquer cut',      move: 'money', cost: '+$180 rush fee', lose: 'Nothing, occasionally. Cutting rooms do sometimes have a gap, and this is the one rush fee on the page I would actually pay.' },
  { k: 'Test pressing post', move: 'money', cost: '+$95 courier',  lose: 'Nine days of the twelve. Worth it only if the whole calendar is already against a wall.' },
  { k: 'Test approval',    move: 'yes',   cost: 'Nothing',        lose: 'Nothing, if the artist is free. This is the only stage where asking nicely genuinely works.' },
  { k: 'Pressing queue',   move: 'no',    cost: '—',              lose: 'It cannot be moved. Plants do sell expedited slots and they are re-selling somebody else’s date, which is a thing I will not do to another label.' },
  { k: 'Sleeve print',     move: 'money', cost: '+$240',          lose: 'Nothing, and it is almost never the constraint. It becomes the constraint only when artwork is late.' },
  { k: 'Press embargo',    move: 'yes',   cost: 'Nothing',        lose: 'The long-lead reviews. You can release in six weeks instead of eight and simply not be in the monthlies, and for some records that is the right trade.' },
  { k: 'Distribution cutoff', move: 'no', cost: '—',              lose: 'It cannot be moved. It is not our calendar and there is no phone call.' },
];

// ── The two dates ─────────────────────────────────────────────────────────

export const dates = [
  { t: 'The plant booking, day 4',
    d: 'Made before mastering is signed off and long before anyone has heard a test pressing. A slot booked in March presses in July and ships in September; the same booking made in June is a record that comes out next year. Every label that looks disorganised about release dates is a label that booked its slot late once.' },
  { t: 'The distributor’s cutoff, day 208',
    d: 'Metadata, artwork, audio and barcodes, all delivered six to eight weeks before the release date, on a date the distributor sets and does not move. Missing it does not delay the record by a week. It delays it by a month, because the release calendar is a grid.' },
];

// ── What one record costs ─────────────────────────────────────────────────

export const spend = {
  rows: [
    { k: 'Mastering, two passes',   v: 620 },
    { k: 'Lacquer cut and plating', v: 940 },
    { k: 'Pressing, 500 units',     v: 2380 },
    { k: 'Sleeves and inners',      v: 1150 },
    { k: 'Freight and storage',     v: 410 },
    { k: 'Press, three months',     v: 1800 },
    { k: 'Radio servicing',         v: 600 },
    { k: 'Digital distribution',    v: 90 },
  ],
  note:
    'Eight thousand dollars on five hundred records, which is sixteen dollars a copy before anybody ' +
    'is paid for making the music. This is why a label exists and it is also why a label says no ' +
    'a great deal. Recording costs are not on this list because the artists on this roster record ' +
    'themselves; when we pay for recording, it is recoupable and it is in the contract in one sentence.',
};

// ── The three deal shapes ─────────────────────────────────────────────────

export const deals = [
  { t: 'Licence, three years',
    d: 'We pay for the pressing and the campaign, we license the recording for three years, and it reverts to the artist automatically with no letter to write. Splits are 60/40 to the artist after costs. This is what most records here are.' },
  { t: 'Pressing and distribution only',
    d: 'The artist keeps everything, we take 20% of trade sales and put the record through our distributor. No press, no radio, no advance. For an artist who has an audience and needs a pressing line rather than a label.' },
  { t: 'One record, no option',
    d: 'A single release, no right to the next one, no option clause. Every artist here started on this and two of them are still on it. An option clause on a first record is a label asking for a favour it has not earned.' },
];

// ── Roster ────────────────────────────────────────────────────────────────
// Described by calendar rather than by stream count, because the calendar is
// the thing this page is about and the stream count is the thing every other
// label page leads with.

export const roster = [
  { name: 'Belle Plaine',    from: 'Salina, KS',
    record: '“Kanopolis”, LP',   delivered: '14 Jan 2026', out: '25 Sep 2026', queued: 20,
    n: 'The record this whole page is drawn from. Delivered in a week when the plant was quoting sixteen weeks and pressing in twenty-two, which is what a queue estimate is worth.' },
  { name: 'The Wichita Line', from: 'Lawrence, KS',
    record: '“Second Shift”, 12"', delivered: '3 Mar 2025', out: '19 Sep 2025', queued: 18,
    n: 'Sleeve artwork arrived nine days late and cost nothing, because it landed inside the pressing window. The one time being late was free.' },
  { name: 'Orla Beckhorn',   from: 'Kansas City, MO',
    record: '“Elm and Vine”, LP',  delivered: '22 Aug 2024', out: '11 Jul 2025', queued: 31,
    n: 'Rejected a test pressing over a warp on side B and lost eleven weeks. It was the right call, the second pressing is the record people know, and I would tell any artist to do the same thing again.' },
  { name: 'Nightjar Union',  from: 'Topeka, KS',
    record: '“Grain Belt”, EP',    delivered: '5 May 2025', out: '6 Feb 2026', queued: 24,
    n: 'Missed a distribution cutoff by two days in October and moved to February. Nothing was wrong with the record. The calendar is a grid and we were on the wrong side of a line.' },
];

// ── Demos ─────────────────────────────────────────────────────────────────
// A funnel is a sequence, so it is an ordered list. The counts are real
// arithmetic: each stage is a subset of the one above it.

export const funnel = [
  { k: 'Arrived in 2025',            n: 1240, d: 'Every link, attachment, DM and envelope. Read on Mondays, all of them, which takes most of a Monday.' },
  { k: 'Played past 60 seconds',     n: 214,  d: 'Not a judgement of the song — a judgement of whether the recording lets me hear the song. See the table below.' },
  { k: 'Played all the way through', n: 61,   d: 'The point at which I am listening as a person rather than as a filter.' },
  { k: 'Replied to properly',        n: 61,   d: 'Every one of these gets a real answer with a reason. It is the least a label owes somebody who spent a year on something.' },
  { k: 'Met',                        n: 9,    d: 'Coffee, no promises made by anybody. Four of the nine did not want a label and said so, which is a good outcome.' },
  { k: 'Signed',                     n: 2,    d: 'Two records out of twelve hundred and forty. That ratio is not a filter working well; it is what a four-artist label can physically release.' },
];

export const stops = [
  { at: '0:04', k: 'It starts with a fade-in',        n: 'A quarter of everything sent to a label opens with eight seconds of nothing. Cut it. The first four seconds are the only ones you are guaranteed.' },
  { at: '0:12', k: 'The vocal is buried',             n: 'Almost always a rough mix sent as a final. Say it is a rough and I will listen differently — an unlabelled rough mix gets judged as a mix.' },
  { at: '0:22', k: 'Nothing has happened yet',        n: 'Not a demand for a chorus by twenty seconds. A demand that something changes by twenty seconds, which is a different and much easier thing.' },
  { at: '0:48', k: 'The drums are a preset',          n: 'Fine on a demo and it stops me hearing the arrangement. A phone recording of the band in a room is more useful to me than a grid.' },
  { at: '1:10', k: 'It is the fourth one that sounds like this today', n: 'The least fair reason on this list, and I am telling you it exists rather than pretending it does not.' },
];

export const said = {
  text: 'They sent me a calendar before they sent me a contract. I knew in the first week that the record was coming out in September, and I spent those nine months writing the next one instead of emailing about the last one.',
  who: 'Artist, second album — 2025',
};

export const faqs = [
  {
    q: 'Why does it take nine months?',
    a: 'About seven weeks of it is work. The rest is a pressing plant queue of roughly four months, twelve days of test pressings in the post, and eight weeks of press embargo that has to sit in front of the release date rather than behind it. Nobody in the chain is being slow. The plant is full, which is a different problem and not one an artist can fix by asking twice.',
  },
  {
    q: 'Can we just release it digitally while we wait?',
    a: 'You can and it usually costs you the vinyl campaign. Press treats a record as new once, radio the same, and a digital release six months early spends that once. The exception is a single, which is what singles are for.',
  },
  {
    q: 'Do you take the masters?',
    a: 'No. The standard deal here is a three-year licence and the recording reverts automatically at the end of it with nothing to sign and no letter to write. Two of the four artists on this roster are on a one-record deal with no option clause, which is the shape I would want if I were the artist.',
  },
  {
    q: 'What happens if we reject the test pressing?',
    a: 'You lose about eleven weeks and you should still do it if it needs doing. One record on this roster went back over a warp on side B, came out four months late, and is the one people actually know. A bad pressing is permanent; a delay is not.',
  },
  {
    q: 'Will you listen to our demo?',
    a: 'Yes, on a Monday, all of it if the recording lets me hear the song. Twelve hundred and forty arrived in 2025 and sixty-one got a real reply with a reason. Two were signed, which is not a filter working well — it is how many records a four-artist label can physically put out.',
  },
  {
    q: 'Do we need a manager or a lawyer to talk to you?',
    a: 'No. The contract is four pages, the splits are on this page, and I will happily wait while somebody reads it. Any label that needs you to have representation before it will explain its own deal is telling you about the deal.',
  },
];
