import { test, expect } from '@playwright/test';

const int = (s: string) => Number((s.match(/[\d,]+/) || ['0'])[0].replace(/,/g, ''));

test.describe('Quarry Line Records — smoke tests', () => {
  test('homepage renders with the label in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Quarry Line Records/);
    await expect(page.locator('h1')).toContainText('Finished in January');
  });

  // An Organization plus one album — not day 119's LocalBusiness-as-a-place,
  // not day 118's Service.
  test('is an Organization, with the record as a separate MusicAlbum', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const org = JSON.parse(blocks.find((b) => b.includes('"Organization"'))!);
    const album = JSON.parse(blocks.find((b) => b.includes('MusicAlbum'))!);
    expect(org['@type']).toBe('Organization');
    expect(album['@type']).toBe('MusicAlbum');
    expect(album.recordLabel.name).toBe(org.name);
    expect(blocks.join('')).not.toContain('LocalBusiness');
    expect(blocks.join('')).not.toContain('floorSize');
  });

  // Six days running the markup here has said less than the page. This one
  // says more, using the one property that carries the argument.
  test('the album emits BOTH of its dates, and the gap is the page', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('MusicAlbum'))!);
    const a = JSON.parse(raw);
    const created = Date.parse(a.dateCreated);
    const published = Date.parse(a.datePublished);
    expect(created).toBeLessThan(published);
    const days = Math.round((published - created) / 86400000);
    // The gap in the markup must equal the number in the headline.
    const h2 = (await page.locator('#lane h2').textContent()) || '';
    expect(int(h2)).toBe(days);
    // Still declined.
    expect(raw).not.toContain('aggregateRating');
    expect(raw).not.toContain('"offers"');
  });

  // ── The lane chart ──────────────────────────────────────────────────────
  test('the chart is visible and every row prints both of its numbers', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#lane ol.lane li');
    const n = await rows.count();
    expect(n).toBeGreaterThan(9);
    expect((await page.locator('#lane ol.lane').boundingBox())!.height).toBeGreaterThan(400);
    for (const r of await rows.all()) {
      const d = (await r.locator('.d').textContent()) || '';
      expect(d).toMatch(/\d+ days?/);
      expect(d).toMatch(/from day \d+/);
      await expect(r.locator('.track')).toHaveAttribute('aria-hidden', 'true');
      expect(((await r.locator('.n').textContent()) || '').length).toBeGreaterThan(60);
    }
  });

  test('bar geometry matches the printed days, row for row', async ({ page }) => {
    await page.goto('/');
    const data = await page.locator('#lane ol.lane li').evaluateAll((lis) =>
      lis.map((li) => ({
        text: (li.querySelector('.d') as HTMLElement).innerText,
        left: parseFloat((li.querySelector('.bar') as HTMLElement).style.left),
        width: parseFloat((li.querySelector('.bar') as HTMLElement).style.width),
      })));
    const span = Math.max(...data.map((d) => {
      const [days, start] = (d.text.match(/\d+/g) || []).map(Number);
      return start + days;
    }));
    for (const d of data) {
      const [days, start] = (d.text.match(/\d+/g) || []).map(Number);
      expect(d.left).toBeCloseTo((start / span) * 100, 1);
      expect(d.width).toBeCloseTo((days / span) * 100, 1);
    }
  });

  test('queue and work are two visually distinct bars, named in words first', async ({ page }) => {
    await page.goto('/');
    const kinds = await page.locator('#lane .bar').evaluateAll((bs) =>
      bs.map((b) => b.className.replace('bar bar--', '')));
    expect(new Set(kinds)).toEqual(new Set(['work', 'queue']));
    const legend = (await page.locator('#lane .legend').textContent()) || '';
    expect(legend).toMatch(/Work/);
    expect(legend).toMatch(/Waiting/);
    const colours = await page.locator('#lane .legend i').evaluateAll((els) =>
      els.map((e) => getComputedStyle(e).backgroundColor + getComputedStyle(e).borderColor));
    expect(new Set(colours).size).toBe(2);
  });

  test('the queue total in the headline is the sum of the queue bars', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#lane ol.lane li').evaluateAll((lis) =>
      lis.map((li) => ({
        kind: (li.querySelector('.bar') as HTMLElement).className,
        days: Number(((li.querySelector('.d') as HTMLElement).innerText.match(/\d+/) || [0])[0]),
      })));
    const q = rows.filter((r) => r.kind.includes('queue')).reduce((a, r) => a + r.days, 0);
    const h2 = (await page.locator('#lane h2').textContent()) || '';
    expect(h2).toContain(`${q} of them are a queue`);
    // The longest single stage really is longer than all the work put together.
    const work = rows.filter((r) => !r.kind.includes('queue')).reduce((a, r) => a + r.days, 0);
    expect(Math.max(...rows.map((r) => r.days))).toBeLessThan(work + q);
    expect(q).toBeGreaterThan(rows.length * 5);
  });

  // ── What can be moved ───────────────────────────────────────────────────
  test('every stage says in words whether it can move', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#move table .move');
    expect(await v.count()).toBe(8);
    for (const el of await v.all()) {
      expect(((await el.textContent()) || '').trim().length).toBeGreaterThan(2);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    const walls = (await v.allTextContents()).filter((t) => /cannot be moved/i.test(t));
    expect(walls.length).toBe(2);
    await expect(page.locator('#move .eyebrow')).toContainText('two of them are walls');
  });

  test('the two immovable dates each get a definition', async ({ page }) => {
    await page.goto('/');
    const dl = page.locator('#move dl.defs');
    expect(await dl.locator('dt').count()).toBe(2);
    for (const d of await dl.locator('dd').allTextContents()) expect(d.length).toBeGreaterThan(120);
    await expect(dl).toContainText('plant booking');
    await expect(dl).toContainText('cutoff');
  });

  // ── Spend ───────────────────────────────────────────────────────────────
  test('the spend total and per-copy figure are arithmetic on the rows', async ({ page }) => {
    await page.goto('/');
    const rows = (await page.locator('#spend tbody td.v').allTextContents()).map(int);
    const sum = rows.reduce((a, b) => a + b, 0);
    expect(int((await page.locator('#spend h2').first().textContent()) || '')).toBe(sum);
    const per = (await page.locator('#spend tfoot td').textContent()) || '';
    expect(Number(per.replace(/[^\d.]/g, ''))).toBeCloseTo(sum / 500, 2);
  });

  test('three deal shapes, and none of them takes the masters', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#spend dl.defs dt').count()).toBe(3);
    await expect(page.locator('#spend')).toContainText(/reverts to the artist automatically/);
    await expect(page.locator('#faq')).toContainText(/No\./);
  });

  // ── Roster ──────────────────────────────────────────────────────────────
  test('the roster is described by calendar, never by streams', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#roster article');
    expect(await cards.count()).toBe(4);
    for (const c of await cards.all()) {
      const dts = await c.locator('.cal dt').allTextContents();
      expect(dts.join(' ').toLowerCase()).toContain('weeks in queue');
      expect(await c.locator('.cal dd').count()).toBe(3);
    }
    // Only the cards themselves — the intro deliberately says "No stream counts",
    // and an over-broad leak token that matches the sentence disclaiming the
    // thing is a mistake this project has made more than once.
    const cardHtml = (await page.locator('#roster article').evaluateAll((els) =>
      els.map((e) => e.innerHTML).join(' '))).toLowerCase();
    for (const w of ['stream', 'monthly listener', 'plays']) expect(cardHtml).not.toContain(w);
  });

  // ── Demos ───────────────────────────────────────────────────────────────
  test('the funnel narrows monotonically and the headline uses its ends', async ({ page }) => {
    await page.goto('/');
    const n = (await page.locator('#demos ol.funnel .n').allTextContents()).map(int);
    expect(n.length).toBeGreaterThan(4);
    for (let i = 1; i < n.length; i++) expect(n[i]).toBeLessThanOrEqual(n[i - 1]);
    const h2 = (await page.locator('#demos h2').textContent()) || '';
    expect(h2).toContain(n[0].toLocaleString('en-US'));
    expect(h2).toContain(String(n[n.length - 1]));
  });

  test('every stop has a timestamp, including the one admitted to be unfair', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#demos tbody th.v').allTextContents()) {
      expect(t.trim()).toMatch(/^\d:\d\d$/);
    }
    await expect(page.locator('#demos')).toContainText(/least fair reason on this list/);
  });

  test('the submission form asks which deal shape', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#link']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    await expect(page.locator('#link')).toHaveAttribute('type', 'url');
    expect(await page.locator('#shape option').count()).toBe(4);
  });

  test('the FAQ is an accordion', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('no trace of the day-119 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['rowan street', 'asheville', 'live room', 'load-in', 'clearance']) {
      expect(html).not.toContain(noun);
    }
    expect(await page.locator('svg.dwg, figure.dwg').count()).toBe(0);
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro release plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/release-plan/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
