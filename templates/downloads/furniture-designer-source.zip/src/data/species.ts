// Shrinkage coefficients, Janka hardness and target moisture content per
// species — the published, cited numbers this page's wood-movement formula
// and species/hardness table are computed against (Wood Database dimensional
// shrinkage tables; ForestSource / Butcher Block Co. Janka figures — see
// RESEARCH.md "Sources"). FSP is a single assumed constant applied to every
// species, per the Purdue Extension FNR-163 convention this page's formula
// follows — stated once here, not re-typed at each call site.
export type SpeciesId = 'black-walnut' | 'white-oak' | 'ash';

export type SpeciesInfo = {
  id: SpeciesId;
  label: string;
  latin: string;
  janka: number; // lbf, Janka hardness
  tangentialShrinkagePct: number; // green → oven-dry, %
  radialShrinkagePct: number; // green → oven-dry, %
  trRatio: number; // tangential ÷ radial — the "0-1-2 rule" stability figure
  targetMC: string; // interior-furniture target moisture content
  sawingNote: string;
};

/** Fiber saturation point, the moisture-content threshold below which wood
 *  actually shrinks — a typical assumed value (Purdue Extension FNR-163),
 *  not a per-species measurement, so it is a single shared constant. */
export const FSP_PERCENT = 28;

export const SPECIES: Record<SpeciesId, SpeciesInfo> = {
  'black-walnut': {
    id: 'black-walnut',
    label: 'Black walnut',
    latin: 'Juglans nigra',
    janka: 1010,
    tangentialShrinkagePct: 7.8,
    radialShrinkagePct: 5.5,
    trRatio: 1.4,
    targetMC: '6–8%',
    sawingNote: 'Flatsawn for open face grain on casegood panels; quartersawn for legs and stretchers, where stiffness matters more than figure.',
  },
  'white-oak': {
    id: 'white-oak',
    label: 'White oak',
    latin: 'Quercus alba',
    janka: 1360,
    tangentialShrinkagePct: 10.5,
    radialShrinkagePct: 5.6,
    trRatio: 1.9,
    targetMC: '6–8%',
    sawingNote: 'Quartersawn for tabletops, breadboard ends and legs — the widest movement of the three species, so stability is worth more than figure here.',
  },
  ash: {
    id: 'ash',
    label: 'Ash',
    latin: 'Fraxinus americana',
    janka: 1320,
    tangentialShrinkagePct: 7.8,
    radialShrinkagePct: 4.9,
    trRatio: 1.6,
    targetMC: '6–8%',
    sawingNote: 'Flatsawn for the open, straight grain a console top wants to show; quartersawn where a slimmer leg profile needs the extra stiffness.',
  },
};

export const SPECIES_ORDER: SpeciesId[] = ['black-walnut', 'white-oak', 'ash'];
