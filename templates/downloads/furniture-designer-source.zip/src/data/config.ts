// Adaeze Okafor — Okafor Furniture Co. Fictional maker, Asheville NC. Demo
// address below is a placeholder; replace it with your own before deploying
// (see README). Dining tables and casegoods only, solid wood, made-to-order
// plus a small run of current-stock pieces.
export const site = {
  name: 'Okafor Furniture Co.',
  title: 'Okafor Furniture Co. — Adaeze Okafor, furniture maker, Asheville NC',
  tagline: 'A cut list is arithmetic that hasn’t happened to the wood yet.',
  owner: 'Adaeze Okafor',
  ownerRole: 'Furniture designer-maker',
  studioName: 'Okafor Furniture Co.',
  addressLine: '118 Depot St, Unit 6',
  city: 'Asheville',
  state: 'NC',
  zip: '28801',
  country: 'US',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'An Asheville, NC furniture maker publishing the shop drawing, cut list and wood-movement math behind ' +
    'every commission — solid walnut, white oak and ash dining tables and casegoods, priced honestly: not ' +
    'until the cut list exists.',
  ogImage: '/og-image.png',
};

export const primaryNav = [
  { label: 'The drawing', href: '#drawing' },
  { label: 'Dimensions', href: '#dimensions' },
  { label: 'Cut list', href: '#cut-list' },
  { label: 'Wood movement', href: '#wood-movement' },
  { label: 'Species', href: '#species' },
  { label: 'Joinery', href: '#joinery' },
  { label: 'Finish', href: '#finish' },
  { label: 'Process', href: '#process' },
  { label: 'Current stock', href: '#stock' },
  { label: 'Studio', href: '#studio' },
  { label: 'FAQ', href: '#faq' },
];

// ── Joinery glossary ─────────────────────────────────────────────────────
export const joineryGlossary = [
  {
    term: 'Mortise & tenon',
    definition: 'A tongue (tenon) cut on one part fits a matching slot (mortise) cut into another — the basic structural joint of almost every piece on this page. Fails without it: the joint relies on glue alone, and glue alone doesn’t survive a chair or table’s racking stress.',
  },
  {
    term: 'Breadboard end',
    definition: 'A narrow strip capping the end grain of a wide panel, pinned (not glued) so the panel can move under it — the joint that lets a tabletop widen and narrow with the seasons without splitting. Fails without it: end grain left exposed checks and cups within a year or two.',
  },
  {
    term: 'Drawbore',
    definition: 'A mortise-and-tenon pin hole bored slightly offset between the two parts, so driving the peg pulls the joint tight without clamps or glue. Fails without it: a glued-only tenon can creep loose over decades of seasonal movement; a drawbored one mechanically can’t.',
  },
  {
    term: 'Through-tenon',
    definition: 'A tenon cut long enough to pass completely through the receiving part and show on the far face, often wedged there. Fails without it (i.e., a blind tenon in its place): less glue surface and less mechanical lock on a stretcher or leg that takes real load.',
  },
  {
    term: 'Dovetail',
    definition: 'Interlocking trapezoidal pins and tails cut into two case corners, mechanically resisting the pulling-apart force a loaded drawer or case side puts on a joint. Fails without it: a butt-jointed or nailed case corner works loose exactly where the load is highest.',
  },
];

// ── Finish schedule ──────────────────────────────────────────────────────
export type FinishScheduleRow = {
  system: 'Hardwax oil' | 'Conversion varnish';
  coat: string;
  product: string;
  dryTime: string;
  cureTime: string;
  recoatWindow: string;
};

export const finishSchedule: FinishScheduleRow[] = [
  { system: 'Hardwax oil', coat: 'Base coat', product: 'Pure hardwax oil, natural', dryTime: '4–6 hrs', cureTime: '7 days', recoatWindow: 'After 24 hrs' },
  { system: 'Hardwax oil', coat: 'Finish coat, buffed', product: 'Pure hardwax oil, natural', dryTime: '4–6 hrs', cureTime: '7 days', recoatWindow: '—' },
  { system: 'Conversion varnish', coat: 'Sealer coat', product: 'Pre-catalyzed sealer', dryTime: '30–45 min', cureTime: '5–7 days', recoatWindow: '2–4 hrs' },
  { system: 'Conversion varnish', coat: 'Top coat ×2', product: 'Conversion varnish topcoat', dryTime: '30–45 min', cureTime: '5–7 days', recoatWindow: '2–4 hrs' },
];

export const finishApplicationSteps = [
  { step: 'Sand through the grits', detail: 'Through 120, then 150, then 180 grit, raising the grain between the last two passes.' },
  { step: 'Tack off the dust', detail: 'Wipe down with a tack cloth — no sanding dust caught in the grain lines before the first coat.' },
  { step: 'Apply the first coat', detail: 'Work hardwax oil into the grain with a lint-free applicator, end grain last.' },
  { step: 'Buff off the excess', detail: 'After 15–20 minutes, buff off every trace of standing oil — what’s left on the surface is what streaks.' },
  { step: 'Let it dry', detail: '24 hours before recoating — see the finish schedule above.' },
  { step: 'Apply the second coat', detail: 'Same method, then buff again.' },
  { step: 'Full cure', detail: '7 days before the piece sees normal use — water and cleaning wait until then.' },
];

export const careInstructions = [
  { step: 'Wipe spills immediately', detail: 'A soft, dry cloth — standing liquid is what actually damages a finish, not the spill itself.' },
  { step: 'Use coasters and trivets', detail: 'Under anything hot, wet or cold, every time.' },
  { step: 'Hold indoor humidity steady', detail: '35–55% relative humidity year-round where you can — this is what the wood-movement math above is computed against.' },
  { step: 'Dust dry or barely damp', detail: 'Skip silicone- or wax-based sprays; they build up and complicate a future re-coat.' },
  { step: 'Expect the breadboard ends to move', detail: 'A little seasonal give at the ends is the joint doing its job, not a defect — don’t clamp or glue it shut.' },
  { step: 'Re-oil worn areas yearly', detail: 'Hardwax oil only; conversion varnish doesn’t need this step. See the finish schedule above for which this piece has.' },
];

// ── Commission process & lead time ───────────────────────────────────────
export const commissionProcess = [
  { step: 'Inquiry', detail: 'Piece type, rough dimensions and timeline, shared through the form below.' },
  { step: 'Design & shop drawing', detail: 'Adaeze drafts the to-scale elevation you see above this page’s cut list, sized to your piece.' },
  { step: '50% deposit', detail: 'Due on approval of the drawing — this is what starts the clock on lead time, not the inquiry.' },
  { step: 'Material selection & cut list', detail: 'Species and sawing method confirmed per part; the cut list — and its board footage — comes from the approved drawing, not before.' },
  { step: 'Build', detail: 'Joinery cut, dry-fit, glued up, inside the lead-time band for your piece’s size.' },
  { step: 'Finish & cure', detail: 'Hardwax oil or conversion varnish applied per the finish schedule, then cured before delivery.' },
  { step: 'Delivery & install', detail: 'Balance due on delivery, within about a day’s drive of Asheville.' },
];

export type LeadTimeRow = {
  band: 'Small' | 'Medium' | 'Large';
  examples: string;
  leadTime: string;
  deposit: string;
  balance: string;
};

export const leadTimeSchedule: LeadTimeRow[] = [
  { band: 'Small', examples: 'Console tables, benches', leadTime: '3–6 weeks', deposit: '50% on drawing approval', balance: 'Due on delivery' },
  { band: 'Medium', examples: 'Sideboards, credenzas', leadTime: '6–10 weeks', deposit: '50% on drawing approval', balance: 'Due on delivery' },
  { band: 'Large', examples: 'Dining tables, extension tables', leadTime: '8–14 weeks', deposit: '50% on drawing approval', balance: 'Due on delivery' },
];

// ── FAQ ───────────────────────────────────────────────────────────────────
export const faq = [
  {
    q: 'Why can’t you quote a price today?',
    a: 'Because lumber is priced and sold by the board foot, and board footage doesn’t exist until the cut list does — which doesn’t exist until the shop drawing is approved. See the cut list above for exactly how that arithmetic runs once it can.',
  },
  {
    q: 'Will my table really move with the seasons?',
    a: 'Yes, by a small, computable amount — see the wood-movement worked example above. That’s exactly why solid tops ship with breadboard ends, floating panels or elongated screw slots instead of being glued rigid across the grain.',
  },
  {
    q: 'Can I bring my own wood?',
    a: 'Sometimes — if it’s kiln-dried to 6–8% moisture content and there’s enough of it, net of the cut list plus 15–20% waste. Raise it at the inquiry stage so it can be checked before the drawing is drafted.',
  },
  {
    q: 'Do you deliver and install outside Asheville?',
    a: 'Yes, within about a day’s drive. Delivery and install are quoted separately once the piece is built, based on distance — the same “not until it’s real” approach as the piece itself.',
  },
];

// ── Quotes ────────────────────────────────────────────────────────────────
export const quotes = {
  client: {
    text: '“The drawing Adaeze sent us before we’d paid a dollar for materials told us more about the table than any showroom floor model ever could — species, joinery, even how much the top would move in our house. My husband and I signed off on the drawing, not a guess.”',
    cite: 'Marcus & Rebecca Coyle, commission clients, Asheville, NC',
  },
  maker: {
    text: '“The drawing is the receipt for the price, not the other way around. I’m not going to hand a client a board-foot number I haven’t earned by drawing the piece first.”',
    cite: 'Adaeze Okafor',
  },
};
