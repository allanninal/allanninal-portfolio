// The single source of every piece this page shows — the dimensions
// section's per-piece <dl>s, the current-stock grid and the Product/Offer
// schema all read from here. The flagship (the Blue Ridge Dining Table) is
// a commission demonstration, not a for-sale piece: it carries no price,
// consistent with "The axis" — a commission's material cost isn't knowable
// until its cut list exists. The other four are already built, already
// photographed, already costed — the day 129/131 case. See RESEARCH.md,
// "Must-have sections", #10.
import type { SpeciesId } from '~/data/species';

export type PieceStatus = 'commission-demo' | 'in-stock';

export type PieceDim = { label: string; value: string };

export type Piece = {
  id: string;
  name: string;
  category: string;
  speciesId: SpeciesId;
  dims: PieceDim[];
  joinery: string[];
  image?: { src: string; alt: string };
  status: PieceStatus;
  priceUSD?: number;
};

export const PIECES: Piece[] = [
  {
    id: 'blue-ridge-dining-table',
    name: 'The Blue Ridge Dining Table',
    category: 'Dining table',
    speciesId: 'white-oak',
    dims: [
      { label: 'Overall, closed', value: '84"W × 42"D × 30"H' },
      { label: 'Overall, with two 12" leaves', value: '108"W × 42"D × 30"H' },
      { label: 'Apron clearance (floor to underside of apron)', value: '26.5"' },
      { label: 'Top thickness', value: '7⁄8"' },
      { label: 'Leaf capacity', value: '2 leaves, 12" each' },
    ],
    joinery: ['Breadboard ends, draw-bored', 'Mortise & tenon, apron to leg', 'Through-tenon stretcher'],
    status: 'commission-demo',
  },
  {
    id: 'currituck-sideboard',
    name: 'The Currituck Sideboard',
    category: 'Sideboard',
    speciesId: 'black-walnut',
    dims: [
      { label: 'Overall', value: '64"W × 19"D × 32"H' },
      { label: 'Case depth, interior', value: '17"' },
    ],
    joinery: ['Dovetailed case corners', 'Mortise & tenon face frame'],
    image: { src: 'currituck-sideboard-walnut.jpg', alt: 'Close detail of the Currituck Sideboard’s book-matched black walnut door face' },
    status: 'in-stock',
    priceUSD: 4200,
  },
  {
    id: 'pisgah-credenza',
    name: 'The Pisgah Credenza',
    category: 'Credenza',
    speciesId: 'white-oak',
    dims: [
      { label: 'Overall', value: '58"W × 18"D × 28"H' },
      { label: 'Case depth, interior', value: '16"' },
    ],
    joinery: ['Dovetailed case corners', 'Sliding-dovetail shelf'],
    image: { src: 'pisgah-credenza-oak.jpg', alt: 'The Pisgah Credenza in white oak, sliding doors open on a low case' },
    status: 'in-stock',
    priceUSD: 3850,
  },
  {
    id: 'watauga-console-table',
    name: 'The Watauga Console Table',
    category: 'Console table',
    speciesId: 'ash',
    dims: [
      { label: 'Overall', value: '48"W × 14"D × 30"H' },
      { label: 'Apron clearance', value: '26"' },
    ],
    joinery: ['Mortise & tenon, apron to leg', 'Drawbore pin'],
    image: { src: 'watauga-console-table.jpg', alt: 'The Watauga Console Table, a slender wood console on turned legs' },
    status: 'in-stock',
    priceUSD: 1650,
  },
  {
    id: 'catawba-bench',
    name: 'The Catawba Bench',
    category: 'Bench',
    speciesId: 'black-walnut',
    dims: [
      { label: 'Overall', value: '58"W × 14"D × 18"H' },
      { label: 'Seat height', value: '18"' },
    ],
    joinery: ['Through-tenon legs', 'Wedged tenon'],
    image: { src: 'catawba-bench-walnut.jpg', alt: 'The Catawba Bench, a curved waterfall-profile bench in black walnut' },
    status: 'in-stock',
    priceUSD: 980,
  },
];

export const flagship = PIECES[0];
export const currentStock = PIECES.filter((p) => p.status === 'in-stock');

// ── The Blue Ridge Dining Table's cut list ──────────────────────────────
// Real board-foot arithmetic (see src/lib/board-feet.ts), not typed totals —
// this is the document that doesn't exist until the drawing is approved.
export type CutListRow = {
  part: string;
  speciesId: SpeciesId;
  sawing: 'Flatsawn' | 'Quartersawn';
  thicknessIn: number;
  widthIn: number;
  lengthIn: number;
  qty: number;
  joinery: string;
};

export const BLUE_RIDGE_CUT_LIST: CutListRow[] = [
  { part: 'Top boards', speciesId: 'white-oak', sawing: 'Flatsawn', thicknessIn: 0.875, widthIn: 10.5, lengthIn: 84, qty: 4, joinery: 'Glued panel, biscuit-aligned' },
  { part: 'Breadboard ends', speciesId: 'white-oak', sawing: 'Quartersawn', thicknessIn: 0.875, widthIn: 3, lengthIn: 42, qty: 2, joinery: 'Draw-bored mortise & tenon' },
  { part: 'Apron, long rails', speciesId: 'white-oak', sawing: 'Quartersawn', thicknessIn: 0.875, widthIn: 5, lengthIn: 76, qty: 2, joinery: 'Mortise & tenon to leg' },
  { part: 'Apron, short rails', speciesId: 'white-oak', sawing: 'Quartersawn', thicknessIn: 0.875, widthIn: 5, lengthIn: 34, qty: 2, joinery: 'Mortise & tenon to leg' },
  { part: 'Legs', speciesId: 'white-oak', sawing: 'Quartersawn', thicknessIn: 2.25, widthIn: 2.25, lengthIn: 29, qty: 4, joinery: 'Mortised for apron & stretcher' },
  { part: 'Extension leaves', speciesId: 'white-oak', sawing: 'Flatsawn', thicknessIn: 0.875, widthIn: 12, lengthIn: 42, qty: 2, joinery: 'Alignment pins & pull-out slides' },
];

// ── Kiln-dried moisture-content intake record ───────────────────────────
// A real shop QC log: every board checked against the 6–8% target the
// moment it comes off the truck, before a single joint is cut. See
// RESEARCH.md, "The axis", point 4.
export type MoistureRow = {
  boardId: string;
  speciesId: SpeciesId;
  part: string;
  mcAtIntake: string;
  targetMC: string;
  status: 'Within target' | 'Redried';
};

export const BLUE_RIDGE_MOISTURE_RECORD: MoistureRow[] = [
  { boardId: 'BR-101', speciesId: 'white-oak', part: 'Top board 1', mcAtIntake: '7.1%', targetMC: '6–8%', status: 'Within target' },
  { boardId: 'BR-102', speciesId: 'white-oak', part: 'Top board 2', mcAtIntake: '7.4%', targetMC: '6–8%', status: 'Within target' },
  { boardId: 'BR-103', speciesId: 'white-oak', part: 'Top board 3', mcAtIntake: '6.8%', targetMC: '6–8%', status: 'Within target' },
  { boardId: 'BR-104', speciesId: 'white-oak', part: 'Top board 4', mcAtIntake: '7.2%', targetMC: '6–8%', status: 'Within target' },
  { boardId: 'BR-105', speciesId: 'white-oak', part: 'Breadboard ends', mcAtIntake: '6.9%', targetMC: '6–8%', status: 'Within target' },
  { boardId: 'BR-106', speciesId: 'white-oak', part: 'Legs & apron', mcAtIntake: '7.5%', targetMC: '6–8%', status: 'Within target' },
];
