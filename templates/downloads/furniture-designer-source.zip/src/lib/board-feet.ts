// The single place a board-foot figure is computed from a part's finished
// dimensions — (thickness in × width in × length ft) ÷ 12, the standard
// hardwood-dealer formula (Craftsmen Hardwoods / Inch Calculator — see
// RESEARCH.md "Sources"). The cut-list table and its purchase total both
// read from this, so the page's "board feet isn't knowable until the cut
// list exists" claim rests on arithmetic that actually ran, not a typed
// figure. See RESEARCH.md, "The axis", point 1.
export function boardFeet(thicknessIn: number, widthIn: number, lengthIn: number, qty = 1): number {
  const lengthFt = lengthIn / 12;
  return round1((thicknessIn * widthIn * lengthFt) / 12 * qty);
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/** Furniture-grade projects add ~15% waste on top of the net cut list for
 *  sawing around checks, sapwood and grain runout — 20% on rough/lower-grade
 *  stock. Default here is the furniture-grade figure. */
export function applyWaste(netBf: number, wastePct = 15): number {
  return round1(netBf * (1 + wastePct / 100));
}
