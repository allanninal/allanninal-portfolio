// The single place a seasonal wood-movement figure is derived from a
// species' published shrinkage coefficient. Every number the wood-movement
// section shows — the worked example, the movement diagram — reads from
// here, so the page's central claim can never quietly disagree with itself.
// See RESEARCH.md, "The axis", point 2.
//
// width × (species shrinkage % ÷ fiber-saturation point) × Δ moisture content
//
// `shrinkagePct` and `fspPct` are both expressed as plain percentage numbers
// (10.5 meaning 10.5%, 28 meaning 28% MC) — shrinkagePct ÷ fspPct is
// therefore the fraction of the panel's width that moves per 1 percentage
// point of moisture-content change; multiplying by deltaMC and the panel
// width gives the movement in inches.
export function computeMovementIn(
  widthIn: number,
  shrinkagePct: number,
  fspPct: number,
  deltaMC: number,
): number {
  return widthIn * (shrinkagePct / fspPct / 100) * deltaMC;
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function formatIn(n: number): string {
  return `${round2(n)}"`;
}
