import { test, expect } from '@playwright/test';

test.describe('Okafor Furniture Co. — smoke tests', () => {
  test('the hero leads with the axis, not a finished-product photo caption', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Okafor Furniture/);
    await expect(page.locator('h1')).toContainText(/cut list is arithmetic/i);
  });

  test('primary nav is the page spine, not Home/About/Services', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Primary' });
    const links = await nav.getByRole('link').allTextContents();
    expect(links).toEqual([
      'The drawing', 'Dimensions', 'Cut list', 'Wood movement', 'Species', 'Joinery',
      'Finish', 'Process', 'Current stock', 'Studio', 'FAQ',
    ]);
  });

  // ── The drawing ───────────────────────────────────────────────────────────
  test('the elevation drawing iframe is same-origin, lazy-loaded and sized to avoid CLS', async ({ page }) => {
    await page.goto('/');
    const iframe = page.locator('#drawing iframe');
    await expect(iframe).toHaveAttribute('src', /blue-ridge-elevation\.svg$/);
    await expect(iframe).toHaveAttribute('loading', 'lazy');
    await expect(iframe).toHaveAttribute('width');
    await expect(iframe).toHaveAttribute('height');
    await expect(iframe).toHaveAttribute('title', /scale 1:12/i);
  });

  test('the elevation SVG document itself renders with a real accessible title', async ({ page }) => {
    const res = await page.goto('/drawings/blue-ridge-elevation.svg');
    expect(res?.status()).toBe(200);
    const text = await page.content();
    expect(text).toMatch(/Blue Ridge Dining Table/);
    expect(text).toMatch(/scale 1:12/i);
  });

  // ── Dimensions ────────────────────────────────────────────────────────────
  test('dimensions publishes one dl per piece — five pieces', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#dimensions .dims-card');
    await expect(cards).toHaveCount(5);
    for (let i = 0; i < 5; i++) {
      expect(await cards.nth(i).locator('dl').count()).toBe(1);
    }
  });

  // ── Cut list ──────────────────────────────────────────────────────────────
  test('the cut list table computes board feet, not typed totals', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#cut-list-table').innerText();
    expect(text).toMatch(/Top boards/);
    expect(text).toMatch(/21\.4/);
    expect(text).toMatch(/Net cut-list total/i);
    expect(text).toMatch(/39\.8/);
    expect(text).toMatch(/Purchase total/i);
    expect(text).toMatch(/45\.8/);
  });

  test('the kiln-dried moisture record lists six checked boards', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#cut-list table.spec').nth(1).locator('tbody tr');
    await expect(rows).toHaveCount(6);
  });

  // ── Wood movement ─────────────────────────────────────────────────────────
  test('the wood-movement worked example computes the movement, not a rounded shrug', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#wood-movement').innerText();
    expect(text).toMatch(/10\.5%/);
    expect(text).toMatch(/28% MC/);
    expect(text).toMatch(/0\.63/);
  });

  test('the movement diagram is a drawn svg figure, not a stock photo', async ({ page }) => {
    await page.goto('/');
    const svg = page.locator('#wood-movement svg[role="img"]').first();
    await expect(svg).toHaveAttribute('aria-label', /white oak/i);
  });

  // ── Species & hardness ────────────────────────────────────────────────────
  test('species & hardness compares all three species with Janka lbf figures', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#species').innerText();
    expect(text).toMatch(/Black walnut/);
    expect(text).toMatch(/White oak/);
    expect(text).toMatch(/Ash/);
    expect(text).toMatch(/1010 lbf|1,010 lbf/);
    expect(text).toMatch(/1360 lbf|1,360 lbf/);
  });

  // ── Joinery ───────────────────────────────────────────────────────────────
  test('the joinery glossary defines all five terms', async ({ page }) => {
    await page.goto('/');
    const terms = await page.locator('#joinery dl.glossary dt').allTextContents();
    expect(terms).toEqual(['Mortise & tenon', 'Breadboard end', 'Drawbore', 'Through-tenon', 'Dovetail']);
  });

  // ── Finish schedule ───────────────────────────────────────────────────────
  test('finish schedule states both systems with dry and cure times', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#finish table.spec').first().locator('tbody tr');
    await expect(rows).toHaveCount(4);
    const text = await page.locator('#finish').innerText();
    expect(text).toMatch(/Hardwax oil/);
    expect(text).toMatch(/Conversion varnish/);
    expect(text).toMatch(/7 days/);
  });

  test('finish section carries two ordered lists — application order and care', async ({ page }) => {
    await page.goto('/');
    const lists = page.locator('#finish ol.seq');
    await expect(lists).toHaveCount(2);
    await expect(lists.nth(0).locator('li')).toHaveCount(7);
    await expect(lists.nth(1).locator('li')).toHaveCount(6);
  });

  // ── Commission process & lead time ────────────────────────────────────────
  test('the commission process ol lists all seven steps in order', async ({ page }) => {
    await page.goto('/');
    const items = await page.locator('#process ol.seq li .k').allTextContents();
    expect(items).toEqual([
      'Inquiry', 'Design & shop drawing', '50% deposit', 'Material selection & cut list',
      'Build', 'Finish & cure', 'Delivery & install',
    ]);
  });

  test('lead time by size lists three bands with deposit terms', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#process table.spec tbody tr');
    await expect(rows).toHaveCount(3);
    const text = await page.locator('#process').innerText();
    expect(text).toMatch(/50% on drawing approval/);
  });

  // ── Current stock ─────────────────────────────────────────────────────────
  test('current stock lists four already-built pieces, each with a fixed price', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#stock .stock-card');
    await expect(cards).toHaveCount(4);
    for (let i = 0; i < 4; i++) {
      await expect(cards.nth(i).locator('.price')).toContainText('$');
    }
  });

  test('the flagship commission demonstration is not in current stock', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#stock-blue-ridge-dining-table').count()).toBe(0);
  });

  // ── About the workshop ────────────────────────────────────────────────────
  test('about the workshop shows at least four documentary figures', async ({ page }) => {
    await page.goto('/');
    const figures = page.locator('#studio figure.doc-figure');
    expect(await figures.count()).toBeGreaterThanOrEqual(4);
  });

  // ── FAQ ───────────────────────────────────────────────────────────────────
  test('FAQ has four questions', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#faq details.faq-item')).toHaveCount(4);
  });

  // ── Contact ───────────────────────────────────────────────────────────────
  test('the commission inquiry form requires name, email and piece type — and has no select', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#contact-name', '#contact-email', '#piece-type']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#contact select').count()).toBe(0);
    expect(await page.locator('select').count()).toBe(0);
  });

  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('#contact .contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Schema ────────────────────────────────────────────────────────────────
  test('the commission Service schema carries no price', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const serviceBlock = blocks.find((b) => b.includes('"Service"'))!;
    const service = JSON.parse(serviceBlock);
    expect(service.price).toBeUndefined();
    expect(service.priceRange).toBeUndefined();
  });

  test('every current-stock Product carries a settled Offer with a real price', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const productBlock = blocks.find((b) => b.includes('"Product"'))!;
    const products = JSON.parse(productBlock)['@graph'];
    expect(products.length).toBe(4);
    for (const p of products) {
      expect(typeof p.offers.price).toBe('number');
      expect(p.offers.availability).toBe('https://schema.org/InStock');
      expect(p.gtin).toBeUndefined();
      expect(p.mpn).toBeUndefined();
      expect(p.aggregateRating).toBeUndefined();
    }
  });

  test('no priceValidUntil is emitted anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    expect(html).not.toContain('priceValidUntil');
  });

  test('the Organization schema carries no LocalBusiness opening-hours claim', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const orgBlock = blocks.find((b) => b.includes('"Organization"'))!;
    const org = JSON.parse(orgBlock);
    expect(org.openingHoursSpecification).toBeUndefined();
    expect(org['@type']).toBe('Organization');
    expect(org.brand.name).toBe('Okafor Furniture Co.');
  });

  // ── Hygiene ───────────────────────────────────────────────────────────────
  test('no trace of earlier-day source templates survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['amara adeyemi', 'adeyemi studio', 'line sheet', 'noor aslani', 'stylist', 'look rail']) {
      expect(html, `earlier-day copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('no same-sex couple or off-brief framing appears anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['his husband', 'her wife', 'polyamor']) {
      expect(html, `off-brief copy present: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1920, 1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/redline vermilion/i);
  });

  // The Full Shop Drawing Set is Pro-only. In the free build it must not be
  // reachable as real content — Astro.redirect() renders it as a meta-refresh
  // stub — and it must not be linked from the homepage.
  test('the Pro Full Shop Drawing Set is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="shop-drawings"]').count()).toBe(0);

    const res = await page.goto('/shop-drawings/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
