// Single source of truth for the coming-soon page.
// Cloning users edit this file to customize for their brand.

export const brand = {
  name: 'Maison Nouvelle',
  // One-sentence tagline shown in the hero.
  tagline: 'Something beautiful is on its way.',
  // Extended description for meta + JSON-LD.
  description:
    'Maison Nouvelle is a new boutique brand launching soon. Join the list to be the first to know when we open — no spam, just the moment.',
  // Copy shown below the tagline when no countdown is rendered.
  launchCopy: 'Launching Summer 2026',
  // Static notify count — update manually before each deploy.
  notifyCount: 1240,
  notifyCountLabel: '1,200+',
  language: 'en',
  // Social links — LinkedIn primary, email secondary per project convention.
  socials: {
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    instagram: 'https://www.instagram.com/allanninal/',
    email: 'landix.ninal@gmail.com',
  },
};

// Three teaser cards — what's coming, abstracted.
// Keep these short and brand-agnostic enough that cloning users can swap them in.
export const teasers = [
  {
    eyebrow: 'Carefully made',
    headline: 'Every detail considered.',
    body: 'We have been working quietly for a while. When the doors open, nothing will feel rushed.',
  },
  {
    eyebrow: 'A new space',
    headline: 'Somewhere you will want to return to.',
    body: 'Whether it is a shop, a studio, or a service — we are building it for people who care about quality.',
  },
  {
    eyebrow: 'Your kind of thing',
    headline: 'You found us for a reason.',
    body: 'The fact that you are here means you are already the kind of person we are making this for.',
  },
];

// Formspree endpoint. Set PUBLIC_FORMSPREE_ID in your env.
// If empty, the form renders in demo mode (no actual submission).
export const formspreeId = import.meta.env.PUBLIC_FORMSPREE_ID || '';

// Launch date from env. If empty, no countdown renders.
export const launchDate = import.meta.env.PUBLIC_LAUNCH_DATE || '';
