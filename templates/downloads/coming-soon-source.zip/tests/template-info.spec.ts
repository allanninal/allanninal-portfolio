import { test, expect } from '@playwright/test';

// Asserts the canonical TemplateInfo download bar is present on the live demo
// build. This is a regression test — Days 14-19 each shipped a broken bespoke
// "meta strip" with no download buttons because no test enforced the shape.
//
// Requires playwright.config.ts to set PUBLIC_TEMPLATE_HUB_URL on the
// webServer.env block, otherwise the bar correctly returns null and this test
// will fail.
//
// The Pro edition (PUBLIC_EDITION=pro) swaps the free bar for a live-preview
// bar, so the assertions branch on the edition.

const isPro = process.env.PUBLIC_EDITION === 'pro';
const slug = 'coming-soon';

test.describe('TemplateInfo download bar', () => {
  if (isPro) {
    test('renders the Pro live-preview bar with correct links', async ({ page }) => {
      await page.goto('/');
      const bar = page.getByRole('complementary', {
        name: /Pro edition — live preview/i,
      });
      await expect(bar).toBeVisible();

      const getPro      = bar.getByRole('link', { name: /Get Pro static/i });
      const downloadFree = bar.getByRole('link', { name: /Download free/i });
      const gallery      = bar.getByRole('link', { name: /All 365/i });

      await expect(getPro).toHaveAttribute(
        'href',
        '#'
      );
      await expect(downloadFree).toHaveAttribute(
        'href',
        new RegExp(`/downloads/${slug}-static\\.zip$`)
      );
      await expect(gallery).toHaveAttribute('href', /templates\.allanninal\.dev/);
    });

    test('Pro bar contains zero github.com links', async ({ page }) => {
      await page.goto('/');
      const bar = page.getByRole('complementary', {
        name: /Pro edition — live preview/i,
      });
      const hrefs = await bar
        .locator('a')
        .evaluateAll((els) => els.map((e) => e.getAttribute('href') || ''));
      const githubLinks = hrefs.filter((h) => h.includes('github.com'));
      expect(githubLinks).toEqual([]);
    });
  } else {
    test('renders 4 canonical links with correct hrefs', async ({ page }) => {
      await page.goto('/');
      const bar = page.getByRole('complementary', {
        name: /Free template — download or fork/i,
      });
      await expect(bar).toBeVisible();

      const staticZip = bar.getByRole('link', { name: /Download static/i });
      const sourceZip = bar.getByRole('link', { name: /Source \(Astro\)/i });
      const gallery   = bar.getByRole('link', { name: /All 365/i });
      const hire      = bar.getByRole('link', { name: /Build with me/i });

      await expect(staticZip).toHaveAttribute(
        'href',
        new RegExp(`/downloads/${slug}-static\\.zip$`)
      );
      await expect(sourceZip).toHaveAttribute(
        'href',
        new RegExp(`/downloads/${slug}-source\\.zip$`)
      );
      await expect(gallery).toHaveAttribute('href', /templates\.allanninal\.dev/);
      await expect(hire).toHaveAttribute(
        'href',
        '#'
      );
    });

    test('contains zero github.com links', async ({ page }) => {
      await page.goto('/');
      const bar = page.getByRole('complementary', {
        name: /Free template — download or fork/i,
      });
      const hrefs = await bar
        .locator('a')
        .evaluateAll((els) => els.map((e) => e.getAttribute('href') || ''));
      const githubLinks = hrefs.filter((h) => h.includes('github.com'));
      expect(githubLinks).toEqual([]);
    });
  }
});
