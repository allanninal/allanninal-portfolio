import type { Page } from '@playwright/test';

// The Pro edition adds a standalone /story/ page; the free edition does not.
export const ROUTES = ['/', ...(process.env.PUBLIC_EDITION === 'pro' ? ['/story/'] : [])];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];
