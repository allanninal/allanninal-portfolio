// Link-checking is handled by `npm run test:links` (linkinator CLI).
// This file is a placeholder that lets Playwright collect the test file
// without running any tests from it — the actual link check runs separately.

// If you want to add in-page link assertions, add them here.
import { test, expect } from '@playwright/test';

test('all internal links return 200 status', async ({ page }) => {
  await page.goto('/');
  // Check the sitemap link is reachable
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});
