import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    // Third-party analytics/ads (GA, AdSense, etc.) emit console noise and
    // blocked-resource (403/CSP) errors that are out of the template's control,
    // especially on system Chrome. Filter those so the test asserts only on the
    // template's own errors.
    const THIRD_PARTY =
      /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() !== 'error') return;
      const text = m.text();
      if (THIRD_PARTY.test(text)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(`console.error: ${text}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home meta description is set', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home emits WebSite JSON-LD with required fields', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const website = docs.find((d) => d && d['@type'] === 'WebSite');
  expect(website, 'WebSite JSON-LD missing').toBeTruthy();
  expect(website.name).toBe('Maison Nouvelle');
  expect(website.url).toMatch(/^https?:\/\//);
  expect(website.description).toBeTruthy();
});

test('home emits Organization JSON-LD with required fields', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const org = docs.find((d) => d && d['@type'] === 'Organization');
  expect(org, 'Organization JSON-LD missing').toBeTruthy();
  expect(org.name).toBe('Maison Nouvelle');
  expect(org.url).toMatch(/^https?:\/\//);
  expect(org.description).toBeTruthy();
  expect(Array.isArray(org.sameAs)).toBe(true);
  expect(org.sameAs.length).toBeGreaterThanOrEqual(1);
});

test('OG image absolute and 1200×630', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toMatch(/^https?:\/\//);
  expect(og).toContain('og-image.png');
  expect(await page.locator('meta[property="og:image:width"]').getAttribute('content')).toBe('1200');
  expect(await page.locator('meta[property="og:image:height"]').getAttribute('content')).toBe('630');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  expect(await page.locator('meta[name="twitter:card"]').getAttribute('content')).toBe('summary_large_image');
});

test('canonical link is absolute', async ({ page }) => {
  await page.goto('/');
  const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
  expect(canonical).toMatch(/^https?:\/\//);
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});

test('color-scheme meta declares light only', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="color-scheme"]').getAttribute('content');
  expect(meta).toBe('light');
});
