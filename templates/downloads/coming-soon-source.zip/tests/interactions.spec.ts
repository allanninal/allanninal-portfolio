import { test, expect } from '@playwright/test';

// ── Hero ──────────────────────────────────────────────────────────────

test('hero shows brand tagline in h1', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toContainText(/something beautiful/i);
});

test('hero shows launch copy', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('text=/launching/i').first()).toBeVisible();
});

test('hero notify count trust line is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText(/1,200\+/i).first()).toBeVisible();
});

// ── Notify forms ──────────────────────────────────────────────────────

test('hero notify form renders and has email input', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('form#notify-hero');
  await expect(form).toBeVisible();
  expect(await form.getAttribute('method')).toBe('post');
  const emailInput = form.locator('input[type="email"]');
  await expect(emailInput).toBeVisible();
});

test('hero notify form email input has autocomplete + required', async ({ page }) => {
  await page.goto('/');
  const email = page.locator('form#notify-hero input[type="email"]');
  expect(await email.getAttribute('autocomplete')).toBe('email');
  expect(await email.getAttribute('name')).toBe('email');
  expect(await email.getAttribute('required')).not.toBeNull();
});

test('email input is keyboard-fillable and has accessible label', async ({ page }) => {
  await page.goto('/');
  const email = page.locator('form#notify-hero input[type="email"]');
  await email.fill('hello@example.com');
  expect(await email.inputValue()).toBe('hello@example.com');
  const ariaLabel = await email.getAttribute('aria-label');
  expect(ariaLabel).toBeTruthy();
  expect(ariaLabel!.length).toBeGreaterThan(3);
});

test('two notify forms render (hero + final)', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('form#notify-hero')).toBeVisible();
  await expect(page.locator('form#notify-final')).toBeVisible();
});

test('demo-mode form shows success message on submit', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('form#notify-hero');
  // Only test demo mode (no real Formspree ID in test env)
  const formspreeAttr = await form.getAttribute('data-formspree');
  if (formspreeAttr === 'demo') {
    await form.locator('input[type="email"]').fill('test@example.com');
    await form.locator('button[type="submit"]').click();
    await expect(page.locator('[role="status"]').first()).toBeVisible();
    await expect(page.locator('[role="status"]').first()).toContainText(/test@example.com/i);
  }
});

// ── Trust band ────────────────────────────────────────────────────────

test('trust band shows notify count', async ({ page }) => {
  await page.goto('/');
  const band = page.locator('section[aria-labelledby="trust-heading"]');
  await expect(band).toBeVisible();
  await expect(band.getByText(/1,200\+/).first()).toBeVisible();
});

test('trust band shows launch copy', async ({ page }) => {
  await page.goto('/');
  const band = page.locator('section[aria-labelledby="trust-heading"]');
  await expect(band.getByText(/summer 2026/i).first()).toBeVisible();
});

// ── Teasers section ───────────────────────────────────────────────────

test('teasers section renders three cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('section[aria-labelledby="teasers-heading"] ul[role="list"] > li');
  expect(await cards.count()).toBe(3);
});

test('each teaser card has an eyebrow label', async ({ page }) => {
  await page.goto('/');
  for (const eyebrow of ['Carefully made', 'A new space', 'Your kind of thing']) {
    await expect(
      page.locator('section[aria-labelledby="teasers-heading"]').getByText(eyebrow, { exact: true })
    ).toBeVisible();
  }
});

// ── Header ────────────────────────────────────────────────────────────

test('header has Get notified CTA pointing to #notify', async ({ page }) => {
  await page.goto('/');
  const btn = page.locator('header').getByRole('link', { name: /get notified/i });
  await expect(btn).toBeVisible();
  expect(await btn.getAttribute('href')).toBe('#notify');
});

// ── Final CTA ─────────────────────────────────────────────────────────

test('final CTA section has notify form', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('section[aria-labelledby="final-cta-heading"]');
  await expect(cta).toBeVisible();
  await expect(cta.locator('form#notify-final')).toBeVisible();
});

// ── External-link safety ──────────────────────────────────────────────

test('all target=_blank links use rel="noopener noreferrer"', async ({ page }) => {
  await page.goto('/');
  const ext = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];
  for (const a of ext) {
    const rel = await a.getAttribute('rel');
    const href = await a.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — rel="${rel}"`);
    }
  }
  expect(unsafe).toEqual([]);
});

// ── LinkedIn-primary in footer ────────────────────────────────────────

test('footer LinkedIn link is visually prominent (accent color)', async ({ page }) => {
  await page.goto('/');
  const li = page.locator('footer a[href*="linkedin.com"]').first();
  const color = await li.evaluate((el) => getComputedStyle(el).color);
  // accent #4A1942 → rgb(74, 25, 66)
  expect(color).toBe('rgb(74, 25, 66)');
});
