/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Light-default — boutique brand teaser register. No dark toggle.
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Space Grotesk Variable"', '"Space Grotesk"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Fraunces Variable"', 'Fraunces', 'ui-serif', 'Georgia', 'Cambria', 'Times', 'serif'],
        serif: ['"Fraunces Variable"', 'Fraunces', 'ui-serif', 'Georgia', 'serif'],
      },
      fontSize: {
        'xs':  ['0.75rem',  { lineHeight: '1.6' }],
        'sm':  ['0.875rem', { lineHeight: '1.65' }],
        'base':['1rem',     { lineHeight: '1.75' }],
        'lg':  ['1.125rem', { lineHeight: '1.65' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.5rem',   { lineHeight: '1.1' }],
        '5xl': ['3.5rem',   { lineHeight: '1.05' }],
        '6xl': ['4.5rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '70rem',
        prose: '64ch',
        column: '42rem',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.015em',
        wide2: '0.18em',
      },
      colors: {
        aubergine: {
          50:  '#F9F1F8',
          100: '#F0E0EE',
          200: '#DDB9D9',
          300: '#C08EC0',
          400: '#9A619A',
          500: '#7A3D7A',
          600: '#5E2660',
          700: '#4A1942',
          800: '#3A1233',
          900: '#2A0D25',
        },
      },
    },
  },
};
