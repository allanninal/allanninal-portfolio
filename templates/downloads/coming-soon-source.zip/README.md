# Coming Soon — Free Astro Template

**Day 12 of 365 Free Static Website Templates**

A generic, reusable launch placeholder for any brand — a boutique shop, a creative studio, a product launch, a restaurant opening, or a personal project. Not another techy startup waitlist. The aesthetic is "elegant placeholder": warm white, deep aubergine, Fraunces display serif, Space Grotesk body. Calm, confident, conversion-ready.

![Preview](./preview.png)

**[Live demo](https://templates.allanninal.dev/coming-soon/)**

---

## Features

- **Boutique-brand aesthetic** — Fraunces variable serif (display) + Space Grotesk (body/UI), warm white `#FDFAF6` + deep aubergine `#4A1942` palette. Fully distinct from Day 3's dark/lime waitlist.
- **Optional countdown** — Set `PUBLIC_LAUNCH_DATE` env var and a live JS countdown renders. Leave it blank and an elegant "Launching Summer 2026" copy line shows instead — no empty clock.
- **Notify form** — Formspree POST by default. Swap the action URL to any provider (Buttondown, Mailchimp, ConvertKit, Web3Forms). In demo mode (no ID set), a success message shows client-side.
- **Trust band** — Static notify count badge + press quote placeholder + launch season copy.
- **Three teaser cards** — Abstracted "what's coming" section any brand can swap into their own language.
- **WebSite + Organization JSON-LD** — Built-in schema.org for SEO coverage.
- **Full OG / Twitter card** — 1200×630 committed og-image.png, all meta tags.
- **Accessible** — axe-core WCAG 2.1 AA clean, all forms labeled, all external links `rel="noopener noreferrer"`.
- **Lighthouse ≥ 95** — Performance, Accessibility, Best Practices, SEO.
- **Mobile-first** — Verified at 375 / 768 / 1280 / 1920 px. All tap targets ≥ 44px.
- **GitHub Pages ready** — `pages.yml` workflow included. Push → enable Pages → done.

---

## Stack & dependencies

- [Astro 4](https://astro.build) — static site generator
- [Tailwind CSS 3](https://tailwindcss.com) — utility CSS
- [@fontsource-variable/fraunces](https://fontsource.org/fonts/fraunces) — self-hosted variable display serif
- [@fontsource-variable/space-grotesk](https://fontsource.org/fonts/space-grotesk) — self-hosted variable sans
- [Formspree](https://formspree.io) — email capture (free tier: 50 submissions/mo)
- Playwright + axe-core + LHCI — test suite

---

## Quick start

```bash
# 1. Download the source ZIP from the live demo page or directly:
#    https://templates.allanninal.dev/downloads/coming-soon-source.zip
unzip coming-soon-source.zip -d my-launch && cd my-launch

# 2. Install + develop
npm install
npm run dev

# 3. Customize (see Customize section below)

# 4. Build
npm run build

# 5. Preview locally
npm run preview
```

---

## Deploy to GitHub Pages

1. Download the source ZIP from `https://templates.allanninal.dev/downloads/coming-soon-source.zip`
2. Unzip into a new folder on your machine.
3. Initialize a new Git repo and push to a new GitHub repo of your own:
   ```bash
   git init && git add . && git commit -m "init from coming-soon template"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
4. In your repo Settings → Pages → Source: **GitHub Actions**.
5. The included `.github/workflows/pages.yml` builds and deploys on every push to `main`. No config edits needed — it auto-detects the repo name for the base path.

---

## Customize

All content lives in **`src/data/config.ts`** — one file to rule them all.

| What | Where |
|---|---|
| Brand name, tagline, description | `brand.name`, `brand.tagline`, `brand.description` |
| Launch copy | `brand.launchCopy` (shown when no countdown is set) |
| Notify count | `brand.notifyCount`, `brand.notifyCountLabel` |
| Social links | `brand.socials.linkedin`, `.instagram`, `.email` |
| Three teaser cards | `teasers[]` array |
| Form endpoint | `PUBLIC_FORMSPREE_ID` env var |
| Launch countdown | `PUBLIC_LAUNCH_DATE` env var (ISO 8601, e.g. `2026-09-01T09:00:00Z`) |

### Colors & fonts

Override CSS variables in `src/styles/global.css`:

```css
:root {
  --color-bg:      #FDFAF6;  /* warm white */
  --color-accent:  #4A1942;  /* aubergine */
  /* ... */
}
```

Font families are set in `tailwind.config.mjs`.

### Custom domain

Set two repo variables (Settings → Secrets and variables → Actions → Variables):
```
PUBLIC_BASE_PATH=/
PUBLIC_SITE_URL=https://your-domain.com
```
The workflow reads these at build time. No code edits required.

---

## Testing

```bash
npm run test:all         # build + Playwright + links + Lighthouse
npm run test             # Playwright only
npm run test:a11y        # axe accessibility only
npm run test:links       # linkinator dead-link check on dist/
npm run test:lighthouse  # Lighthouse CI (all 4 scores ≥ 95)
```

Playwright covers:
- Page renders, h1 visible, no console errors
- Both notify forms (hero + final) rendered and functional
- Demo-mode form success message
- Three teaser cards render with correct eyebrow labels
- Responsive at 4 viewports (no horizontal overflow)
- Mobile tap targets ≥ 40px
- axe WCAG 2.1 AA zero violations
- JSON-LD WebSite + Organization schemas
- OG / Twitter card tags
- Canonical, robots.txt, sitemap.xml

---

## Alternate deploys

| Provider | Notes |
|---|---|
| **Netlify** | Drop the `dist/` folder or connect your repo. Set `PUBLIC_BASE_PATH=/` |
| **Vercel** | Connect repo. Set `PUBLIC_BASE_PATH=/` as env var. Framework: Astro. |
| **Cloudflare Pages** | Connect repo. Build command: `npm run build`. Output: `dist`. Set `PUBLIC_BASE_PATH=/` |

---

## Support / donations

This template is free and MIT-licensed. If it saves you time:

- [Tip on Ko-fi](https://ko-fi.com/allanninal) — keeps this 365-template project going.
- [All 365 templates](https://templates.allanninal.dev) — browse the rest of the library.

**For cloning users:**
- The repo's GitHub "Sponsor" button is driven by `.github/FUNDING.yml` — edit `ko_fi: allanninal` to your own handle, or delete the file to hide the button.
- The footer Ko-fi attribution is controlled by `PUBLIC_AUTHOR_DONATE_URL` in your env. Set it blank to hide it. Set your own Ko-fi URL to repoint it.
- To add your own prominent donate button on the site, set `PUBLIC_USER_DONATE_URL` in your env.

---

## License

MIT — free to use, modify, and distribute. Attribution appreciated but not required.

Built by [Allan Ninal](https://allanninal.dev) as part of the [365 Free Static Templates](https://templates.allanninal.dev) project.
