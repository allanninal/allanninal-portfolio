# Coming Soon / Launch Page Template — Research Brief

> **Assumption:** A *generic*, reusable launch placeholder that works for any business — a boutique brand, a creative studio, a product, a restaurant, a personal project. **Not** a tech-startup waitlist (Day 3 owns that space). The vibe is "elegant placeholder" — tasteful, calm, confident. Think construction notice for a high-end shop, not a hype page for a Y Combinator startup.

## Audience & primary CTA

- **Who visits:** People who arrive at a brand's URL before it has launched — directed by word of mouth, a social post, a press mention, or the brand's own marketing. Decision time is short; they need to feel "this is worth waiting for" in 5 seconds.
- **Primary CTA:** Join the notify list — one email field, one submit button. That's the entire conversion goal.
- **Secondary CTAs:** Social follow links (Instagram, LinkedIn) in the footer. No referral, no countdown gimmick as the sole anchor.

## Reference sites (real examples)

- https://www.aesop.com — Restrained brand teasers when launching a new space: a single photograph, a date, a city name. Zero copy, all atmosphere.
- https://sezane.com/en — French fashion brand; "soon" pages are just the logo, a date, and an email field on a cream background. Converts on brand energy alone.
- https://www.glossier.com (early pop-up store announcements) — Millennial-pink and cream, gentle serif headline, "join the list," city + date. Minimal, effective.
- https://uncommongoods.com (pre-launch collection pages) — countdown + product teaser image + email. Functional but visually pleasant.
- https://www.apartmenttherapy.com/shop (soft-launch placeholder) — No countdown, just editorial photography, one-liner, email.

## Must-have sections (in order)

1. **Hero (above the fold, full attention)** — Brand/project name (large display), a single evocative tagline ("Something beautiful is coming."), launch date or progress signal (optional countdown OR a simple "Launching Spring 2026" copy line), email capture field + CTA button.
2. **Teaser / "What's coming" band** — Three short teaser cards: the nature of what's arriving. Keeps visitors curious without over-promising. Abstracted enough that any brand can swap the copy.
3. **Social proof / trust** — Newsletter subscriber count badge OR a quote from a press mention (placeholder). Answers "should I trust this?"
4. **Final subscribe CTA** — Repeat of the email field for visitors who scrolled past the hero. Short headline + form.
5. **Footer** — Brand name, social links (LinkedIn primary, email secondary), brief privacy note.

## Design conventions

- **Typography:** **Fraunces** (Google Fonts — optical-size variable serif with "wonky" optical feature, used by high-end brands; deeply unused across Days 1–11 and rare in free templates) as the display/heading font. **Space Grotesk** (Google Fonts — geometric sans-serif, clean but with humanist warmth; unused in Days 1–11) for body, labels, form elements, eyebrows.
- **Color palette:** **Warm white** (`#FDFAF6`) base with **deep aubergine / plum** (`#4A1942`) as the primary accent. Secondary: dusty mauve for muted text (`#7A5C75`). Surface tint: `#F3EEF2`. Accent-on-surface for buttons: `#4A1942` with warm-white text. This palette is entirely untaken in Days 1–11 and signals "premium, creative, editorial" rather than "tech startup."
- **Imagery:** No stock photography. The hero is pure typography + optional abstract SVG mark (circle + thin rule) — brand-identity-coded. No countdown clock as the visual anchor (that's Day 3). Optional: a single geometric brand mark / monogram in the hero.
- **Density:** Airy and generous. Large whitespace margins. The template should feel like the brand has already decided its aesthetic and is simply waiting to open the door.
- **Mode:** Light-only. Dark mode would contradict the boutique brand register.

## Trust signals to include

- Launch date copy line ("Launching Summer 2026") — concrete, not vague
- Subscriber count badge ("Join 1,200+ people on the list") — static, editable
- Social links (Instagram-first for boutique brands, LinkedIn for B2B)
- Optional: one press / media mention in the "what's coming" band
- Privacy note: "No spam. Unsubscribe anytime." below the form

## SEO / schema.org

- **Type:** `WebSite` + `Organization` — pre-launch, no shippable product yet; same rationale as Day 3's waitlist, different category.
- **Required:** `Organization.name`, `Organization.url`, `Organization.description`, `WebSite.name`, `WebSite.url`, `WebSite.potentialAction` (SearchAction)
- **OG image:** Brand name in Fraunces display weight on warm white, tagline below in Space Grotesk, aubergine rule / monogram mark. 1200×630 committed static PNG.

## Static-only fit

No concerns:
- **Email form:** Formspree POST endpoint (`PUBLIC_FORMSPREE_ID`). No JS SDK. Fallback documented: swap action URL for any provider (Buttondown, Mailchimp, ConvertKit, Web3Forms).
- **Countdown (optional):** If `PUBLIC_LAUNCH_DATE` env var is set, a client-side JS countdown renders; if empty, a copy-only "Launching [SEASON YEAR]" renders. No SSR required.
- **Subscriber count:** Static `NOTIFY_COUNT` field in `config.ts`. Update manually.
- **Schema:** Build-time `<script type="application/ld+json">`.

## Differentiation — what we'll do differently

1. **Day 3 contrast:** Day 3 (startup-waitlist) is dark-default (#09090B) + electric lime (#BFFF00) + Geist + techy persona + large countdown clock as hero anchor. Day 12 is light-default + aubergine/plum + Fraunces + boutique persona + countdown optional/secondary. Same conversion goal, completely different register.
2. **Generic, non-technical persona:** Works equally well for a fashion brand, a new restaurant, a creative agency, a personal project, or a boutique product. Day 3 reads "tech startup." Day 12 reads "any beautiful thing about to exist."
3. **Fraunces + Space Grotesk — unused in Days 1–11:** Fraunces's optical-size variable features ("wonky" alternates at display sizes) create an instantly recognizable, editorial feel. No other free Astro template uses this pairing.
4. **Aubergine on warm white — fully untaken:** Not coral (Day 4), not forest green (Day 5), not cobalt (Day 6), not magenta (Day 7), not oxblood (Day 11), not lime (Day 3), not violet (Day 2). Aubergine/plum is a genuine gap in the template library.
5. **"What's coming" teaser cards:** Instead of a feature grid or a product mock, three abstracted teaser cards ("A new collection," "Carefully made," "Opening soon") that any brand can swap into their own language without redesign.
6. **Countdown as opt-in:** The countdown only renders if `PUBLIC_LAUNCH_DATE` is set. A brand that doesn't have a hard date yet doesn't get an empty countdown clock — they get elegant copy instead. More reusable, less awkward.
