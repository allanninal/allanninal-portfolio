import { test, expect } from '@playwright/test';

test.describe('Cardinal & Co. — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Cardinal & Co\. Movers/);
    await expect(page.locator('h1')).toContainText('decoded');
  });

  // The one day in this sprint where schema.org has the right type. Every
  // other trade had to fall back to HomeAndConstructionBusiness.
  test('uses the real MovingCompany schema type, not a fallback', async ({ page }) => {
    await page.goto('/');
    const types = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => JSON.parse(e.textContent || '{}')['@type']),
    );
    expect(JSON.stringify(types)).toContain('MovingCompany');
    expect(JSON.stringify(types)).not.toContain('HomeAndConstructionBusiness');
  });

  // The palette is the first achromatic one in the library. If a hue creeps
  // back in, the argument for this template's restraint goes with it.
  test('the palette is achromatic — no hue anywhere in the core colours', async ({ page }) => {
    await page.goto('/');
    const spread = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      const names = ['--color-bg', '--color-bg-alt', '--color-text', '--color-text-muted', '--color-accent', '--color-band'];
      return names.map((n) => {
        const hex = s.getPropertyValue(n).trim().replace('#', '');
        const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
        return Math.max(r, g, b) - Math.min(r, g, b);
      });
    });
    for (const s of spread) expect(s).toBeLessThan(10);
  });

  test('the decoder gives all four columns for nine terms', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#decoder .decode-row');
    expect(await rows.count()).toBe(9);
    for (const t of await rows.allTextContents()) {
      expect(t).toContain('Sounds like');
      expect(t).toContain('Actually means');
      expect(t).toContain('What it costs you');
    }
  });

  // The number that does the work on this page.
  test('valuation is worked with real weights and shows the 60c gap', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#valuation');
    await expect(v).toContainText('60 cents a pound');
    const rows = v.locator('tbody tr');
    expect(await rows.count()).toBe(5);
    // A 40 lb TV: $24.00 released, $240.00 full value.
    await expect(v).toContainText('$24.00');
    await expect(v).toContainText('$240.00');
  });

  test('valuation is stated as not being insurance', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#decoder')).toContainText(/It is not insurance/i);
  });

  test('estimate types carry a verdict in words, not colour', async ({ page }) => {
    await page.goto('/');
    const verdicts = await page.locator('#estimates .verdict').allTextContents();
    expect(verdicts.length).toBe(3);
    for (const v of verdicts) expect(['Ask for this', 'Fine', 'Read it twice']).toContain(v.trim());
  });

  test('costs show real 2026 figures', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#costs .rate-table tbody tr');
    expect(await rows.count()).toBe(6);
    await expect(page.locator('#costs')).toContainText('$3,020');
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('quote form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 85.
  test('no trace of the day-85 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['haulaway', 'baltimore', 'diversion', 'truck fraction', 'landfill']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro inventory sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/inventory-sheet/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Cube counts by room');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
