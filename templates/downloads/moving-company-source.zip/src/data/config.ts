/**
 * Cardinal & Co. Movers — every string the page renders.
 *
 * Business fictional. THE NUMBERS ARE REAL: 60¢/lb released value and the
 * $6/lb full-value floor are federally-defined figures (FMCSA), and the cost
 * ranges are 2026 US averages. Sources in RESEARCH.md.
 */

export const site = {
  name: 'Cardinal & Co. Movers',
  shortName: 'Cardinal & Co.',
  tagline: 'The contract, decoded before you sign it.',
  description:
    'A DOT-registered mover in Richmond. This page decodes the nine contract terms that cost customers money — starting with the free coverage that pays 60 cents a pound.',
  owner: 'Wendell Boateng',
  ownerRole: 'Owner',
  yearsExperience: 13,
  city: 'Richmond',
  state: 'VA',
  streetAddress: '3100 West Leigh Street',
  postalCode: '23230',
  phoneDisplay: '(804) 555-0129',
  phoneHref: '+18045550129',
  email: 'hello@cardinalmovers.example',
  formAction: '#',
  hours: 'Mon–Sat 7am–6pm',
  bookingWindow: 'Surveys within a week. Peak season books out by April.',
  dot: 'USDOT 3910442 · MC 1442087',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Cardinal & Co. Movers — Local & Long-Distance Moving in Richmond, VA',
  license: 'DOT-registered interstate carrier · Fully insured',
  instagram: 'https://www.instagram.com/cardinalmovers',
  facebook: 'https://www.facebook.com/cardinalmovers',
};

export const nav = [
  { label: 'The decoder', href: '#decoder' },
  { label: 'Valuation', href: '#valuation' },
  { label: 'Estimates', href: '#estimates' },
  { label: 'Costs', href: '#costs' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The decoder — the page's spine.
 *
 * Four columns per term: the word, what it sounds like, what it means, what it
 * costs you. The middle column is the point: these terms all sound reassuring
 * and several of them are not.
 */
export const terms = [
  {
    term: 'Valuation',
    sounds: 'Insurance.',
    means: 'It is not insurance. It is the mover’s declared limit of liability, regulated by the DOT rather than by an insurer.',
    costs: 'The free default pays 60¢ per pound. Actual insurance is a separate product you buy elsewhere.',
  },
  {
    term: 'Released value protection',
    sounds: 'Included protection, at no charge.',
    means: 'The federally-required free minimum. It pays 60 cents per pound per article, regardless of what the article is worth.',
    costs: 'A 40 lb television pays out $24. A 6 lb laptop pays out $3.60.',
  },
  {
    term: 'Full value protection',
    sounds: 'The expensive upgrade.',
    means: 'The mover must repair, replace or pay cash value. The floor is $6 per pound of shipment weight.',
    costs: 'Typically 1–2% of declared value. On most moves it is the difference between a claim and a shrug.',
  },
  {
    term: 'Binding estimate',
    sounds: 'A quote.',
    means: 'A fixed price for the services and items listed. It does not move unless you change the list.',
    costs: 'Nothing extra — but read what is on the list, because anything not on it is not in the price.',
  },
  {
    term: 'Non-binding estimate',
    sounds: 'A quote.',
    means: 'An informed guess. The final price is based on actual weight and can legally exceed the estimate.',
    costs: 'You must be able to pay 110% of it at delivery. The rest can be billed within 30 days.',
  },
  {
    term: 'Binding not-to-exceed',
    sounds: 'Complicated.',
    means: 'The best of the three. You pay the lower of the estimate or the actual weight.',
    costs: 'Nothing. If a mover offers this one, that is a good sign.',
  },
  {
    term: 'Accessorial charges',
    sounds: 'Small extras.',
    means: 'Anything beyond loading, driving and unloading — stairs, long carry, shuttle, packing, bulky items.',
    costs: 'Routinely several hundred dollars, and the single most common source of invoice shock.',
  },
  {
    term: 'Long carry',
    sounds: 'A short walk.',
    means: 'Distance from the truck to your door beyond an included allowance, often 75 feet.',
    costs: 'Charged per 50 or 75 feet. Ask what the allowance is before move day, not on it.',
  },
  {
    term: 'Shuttle service',
    sounds: 'A convenience.',
    means: 'A smaller truck used because the trailer physically cannot reach your street.',
    costs: 'One of the largest single accessorials. If your street is narrow, raise it at survey.',
  },
];

/** Valuation, worked with real weights. */
export const valuation = {
  released: 0.60,
  full: 6.00,
  items: [
    { item: 'Television, 55 inch', lb: 40 },
    { item: 'Laptop', lb: 6 },
    { item: 'Sofa', lb: 180 },
    { item: 'Dining table', lb: 120 },
    { item: 'Box of books', lb: 45 },
  ],
  note: 'Released value protection is free and federally required, so it is the default unless you actively choose otherwise. That is why it catches people — nobody declines it, they just never realise they accepted it.',
};

export const estimates = [
  { kind: 'Binding', price: 'Fixed', risk: 'Only changes if you change the inventory.', verdict: 'good' },
  { kind: 'Binding not-to-exceed', price: 'Lower of estimate or actual', risk: 'None to you.', verdict: 'best' },
  { kind: 'Non-binding', price: 'Based on actual weight', risk: 'Can exceed the estimate. You must pay 110% at delivery.', verdict: 'caution' },
];

/** Real 2026 US figures. */
export const costs = {
  rows: [
    { what: 'Average move, all types', figure: '~$3,020' },
    { what: 'Local move, average', figure: '~$1,489' },
    { what: 'Long-distance, average', figure: '~$3,124' },
    { what: 'Local, per mover per hour', figure: '$50 – $100+' },
    { what: 'Local minimum', figure: '2 – 4 hours' },
    { what: 'Long distance', figure: 'Shipment weight × mileage' },
  ],
  worked: 'A 7,000 lb shipment at $0.65 per pound is about $4,550 before accessorials. Weight is what you are actually buying on a long move, which is why a survey beats a phone quote.',
};

export const areas = [
  { zone: 'Richmond', towns: 'Fan District · Church Hill · Scott’s Addition · Northside' },
  { zone: 'West', towns: 'Short Pump · Glen Allen · Midlothian · Bon Air' },
  { zone: 'East & south', towns: 'Chesterfield · Petersburg · Hopewell · Sandston' },
  { zone: 'Long distance', towns: 'Interstate, DOT-registered — the whole eastern seaboard' },
];

export const reviews = [
  { name: 'Imani R.', town: 'The Fan', text: 'Wendell explained released value before I asked, then told me full value would cost about $90 on my shipment. The claim I filed for a cracked dresser paid the replacement.' },
  { name: 'Dave L.', town: 'Short Pump', text: 'Surveyed the house, spotted that the trailer could not get down my street, and priced the shuttle up front instead of on the day.' },
  { name: 'Georgia P.', town: 'Church Hill', text: 'Binding not-to-exceed. Came in under the estimate and they charged the lower number without me having to ask.' },
  { name: 'Trent M.', town: 'Midlothian', text: 'Third mover I called. First one to say the word "accessorial" out loud before I signed anything.' },
];

export const faqs = [
  { q: 'Is valuation the same as insurance?', a: 'No, and this is the single most common misunderstanding in the trade. Valuation is the mover’s declared limit of liability under DOT rules. Insurance is a separate product from an insurer. If you want true insurance you buy it separately — ask us and we will tell you who does it locally.' },
  { q: 'What does 60 cents a pound actually mean?', a: 'It means a 40 lb television is covered for $24. Released value protection is free and required by federal law, so it is what you get by default. It is not a scam, it is a floor — but almost nobody realises it is what they accepted.' },
  { q: 'Which estimate type should I ask for?', a: 'Binding not-to-exceed, every time. You pay the lower of the estimate or the actual weight, so the risk sits with us rather than you. If a mover will not offer it, ask why.' },
  { q: 'Why does a survey matter?', a: 'Long-distance price is weight, and nobody estimates weight accurately over the phone. A survey also catches the things that become accessorials — narrow streets, stairs, a long carry — while there is still time to price them honestly.' },
  { q: 'Can the price go up on move day?', a: 'On a binding estimate, only if you add items or services. On a non-binding one, yes — legally it can, and you must be able to pay 110% at delivery. That difference is why the estimate type matters more than the headline number.' },
  { q: 'What is the deposit situation?', a: 'We take none for local moves and a small one for interstate. A mover demanding a large cash deposit up front is a recognised warning sign; the FMCSA publishes guidance on exactly this at protectyourmove.gov.' },
];
