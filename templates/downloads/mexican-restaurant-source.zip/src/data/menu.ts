export type MenuItem = {
  name: string;
  description: string;
  price: string;
  badge?: string;
  vegetarian?: boolean;
  spicy?: boolean;
};

export type MenuCategory = {
  id: string;
  label: string;
  items: MenuItem[];
};

export const menuCategories: MenuCategory[] = [
  {
    id: 'tacos',
    label: 'Tacos',
    items: [
      {
        name: 'Taco de Carnitas',
        description: 'Slow-braised pork shoulder, salsa verde, onion & cilantro, corn tortilla',
        price: '$4.50',
        badge: 'Fan favorite',
      },
      {
        name: 'Taco de Birria',
        description: 'Stewed beef in dried-chile consommé, Oaxacan cheese, onion, cilantro, consommé for dipping',
        price: '$5.50',
        badge: 'Best seller',
      },
      {
        name: 'Taco de Rajas Poblanas',
        description: 'Roasted poblano strips, corn, crema, cotija cheese, corn tortilla',
        price: '$4.25',
        vegetarian: true,
      },
      {
        name: 'Taco de Camarón',
        description: 'Gulf shrimp sautéed in chile de árbol butter, cabbage slaw, lime crema, avocado',
        price: '$5.75',
        spicy: true,
      },
      {
        name: 'Taco al Pastor',
        description: 'Achiote-marinated pork, grilled pineapple, onion, cilantro, salsa roja',
        price: '$4.50',
        badge: 'Signature',
        spicy: true,
      },
      {
        name: 'Taco de Carne Asada',
        description: 'Grilled skirt steak, guacamole, salsa negra, corn tortilla',
        price: '$5.50',
      },
    ],
  },
  {
    id: 'antojitos',
    label: 'Antojitos',
    items: [
      {
        name: 'Tlayuda Oaxaqueña',
        description: 'Large crisp tortilla, black bean paste, Oaxacan quesillo, tasajo, avocado, salsa',
        price: '$14.00',
        badge: 'Signature',
      },
      {
        name: 'Quesadilla de Flor de Calabaza',
        description: 'Squash blossom & epazote quesadilla, handmade flour tortilla, salsa verde',
        price: '$10.50',
        vegetarian: true,
      },
      {
        name: 'Sopes de Chorizo',
        description: 'Three thick corn masa sopes, house chorizo, refried beans, crema, cotija, pickled jalapeño',
        price: '$11.00',
      },
      {
        name: 'Gorditas de Chicharrón',
        description: 'Twice-fried masa pockets filled with pork rinds in salsa verde, queso fresco',
        price: '$10.00',
        spicy: true,
      },
      {
        name: 'Elotes Estilo La Milpa',
        description: 'Grilled corn on the cob, chipotle mayo, cotija, chile piquín, lime — two per order',
        price: '$7.50',
        badge: 'Summer special',
        vegetarian: true,
      },
      {
        name: 'Guacamole y Totopos',
        description: 'Chunky house guacamole, hand-fried totopos, pico de gallo',
        price: '$9.00',
        vegetarian: true,
      },
    ],
  },
  {
    id: 'mains',
    label: 'Platos Fuertes',
    items: [
      {
        name: 'Mole Negro con Pollo',
        description: 'Braised chicken thigh in 12-hour Oaxacan black mole, arroz rojo, black beans, corn tortillas',
        price: '$19.00',
        badge: 'James Beard recognized',
      },
      {
        name: 'Enchiladas Suizas',
        description: 'Corn tortillas filled with pulled chicken, tomatillo cream sauce, Oaxacan cheese, sour cream',
        price: '$16.50',
      },
      {
        name: 'Pozole Rojo',
        description: 'Traditional pork and hominy soup, dried red chiles, garnished with cabbage, radish & oregano',
        price: '$14.00',
        spicy: true,
      },
      {
        name: 'Camarones a la Diabla',
        description: 'Gulf shrimp in fiery chile de árbol & tomato sauce, steamed rice, corn tortillas',
        price: '$20.50',
        spicy: true,
        badge: 'Extra hot',
      },
      {
        name: 'Plato Vegetariano',
        description: 'Charred seasonal vegetables, black bean purée, calabacitas con epazote, corn tortillas, crema',
        price: '$15.00',
        vegetarian: true,
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Bebidas',
    items: [
      {
        name: 'Margarita Clásica',
        description: 'Blanco tequila, fresh lime juice, triple sec, Himalayan salt rim — rocks or blended',
        price: '$10.00',
      },
      {
        name: 'Mezcal Negroni Rojo',
        description: 'Joven mezcal, Campari, sweet vermouth, orange peel — silky smoke-forward sipper',
        price: '$13.00',
        badge: 'Bar favorite',
      },
      {
        name: 'Paloma de Hibisco',
        description: 'Reposado tequila, house-made hibiscus syrup, grapefruit juice, soda, chile rim',
        price: '$12.00',
      },
      {
        name: 'Agua de Jamaica',
        description: 'House-made hibiscus flower agua fresca, cane sugar, fresh lime — no alcohol',
        price: '$4.00',
        vegetarian: true,
      },
      {
        name: 'Agua de Tamarindo',
        description: 'Fresh tamarind agua fresca, piloncillo, lime — no alcohol',
        price: '$4.00',
        vegetarian: true,
      },
      {
        name: 'Horchata',
        description: 'Traditional rice & cinnamon agua fresca, served cold — no alcohol',
        price: '$4.00',
        vegetarian: true,
      },
      {
        name: 'Modelo Especial',
        description: 'Mexican lager, 12 oz bottle, served with lime',
        price: '$5.50',
      },
      {
        name: 'Jarritos (assorted)',
        description: 'Tamarindo, Mandarina, or Toronja — 12.5 oz glass bottle',
        price: '$3.50',
        vegetarian: true,
      },
    ],
  },
];
