export const site = {
  name: 'La Milpa',
  tagline: 'Taqueria & Antojitos',
  neighborhood: 'East Side, San Antonio',
  description:
    'A family-owned taqueria rooted in Oaxacan and Michoacán tradition. Mole negro simmered overnight, hand-pressed tortillas, seasonal-fruit aguas.',
  cuisine: 'Mexican, Oaxacan, Taqueria',
  priceRange: '$$',
  phone: '(210) 555-0147',
  phoneDisplay: '(210) 555-0147',
  email: 'hola@lamilpasa.com',
  address: {
    street: '412 E Commerce St',
    city: 'San Antonio',
    state: 'TX',
    zip: '78205',
    full: '412 E Commerce St, San Antonio, TX 78205',
    country: 'US',
  },
  geo: {
    lat: 29.4246,
    lng: -98.4951,
  },
  mapUrl: 'https://maps.google.com/?q=412+E+Commerce+St+San+Antonio+TX+78205',
  orderUrl: 'https://www.toasttab.com',
  instagram: '@lamilpasa',
  instagramUrl: 'https://instagram.com/lamilpasa',
  facebook: 'La Milpa SA',
  facebookUrl: 'https://facebook.com/lamilpasa',
  rating: {
    value: 4.8,
    count: 532,
    max: 5,
  },
  estYear: 2009,
  og: {
    alt: 'La Milpa — Taqueria & Antojitos in San Antonio, Texas',
  },
};

export const owner = {
  name: 'Rosa Vásquez',
  title: 'Chef & Owner',
  origin: 'Oaxaca City, Mexico',
  bio: `Rosa Vásquez grew up in her grandmother's kitchen in Oaxaca City, where the smell of toasted chiles and fresh masa was as constant as sunrise. She moved to San Antonio at nineteen, worked every station in professional kitchens for a decade, then opened La Milpa in 2009 with a single comal and a market stall permit.

La Milpa has since grown into a sit-down taqueria with a loyal neighborhood following, but the philosophy hasn't changed: everything made from scratch, sourced as locally as possible, and priced so families can eat well without stretching their budget.

Rosa's mole negro — toasted, blended, and simmered for twelve hours — has been featured in Texas Monthly and earned a James Beard Foundation recognition in 2023.`,
  philosophy:
    "Good food doesn't need to be complicated. It needs time, honest ingredients, and someone who gives a damn.",
};

export const hours = [
  { day: 'Monday',    open: 'Closed',  close: '' },
  { day: 'Tuesday',   open: '11:00 AM', close: '9:00 PM' },
  { day: 'Wednesday', open: '11:00 AM', close: '9:00 PM' },
  { day: 'Thursday',  open: '11:00 AM', close: '9:00 PM' },
  { day: 'Friday',    open: '11:00 AM', close: '10:30 PM' },
  { day: 'Saturday',  open: '10:00 AM', close: '10:30 PM' },
  { day: 'Sunday',    open: '10:00 AM', close: '8:00 PM' },
];
