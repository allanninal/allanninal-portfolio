# Mexican Restaurant — Day 34 of 365

A vibrant, polished Astro template for a Mexican restaurant or taqueria. Built around a family-owned Oaxacan/Michoacán concept ("La Milpa"), this template features a festive but tasteful visual identity distinct from every prior food template in the series.

**Live demo:** https://example.com/

---

## Visual identity

- **Palette:** Talavera teal `#006D6A` (hero, sections) · Terracotta `#B5411F` (CTA, accent) · Marigold `#D4840A` (highlights) · Warm ivory `#FDF8F0` (background) — all WCAG AA compliant
- **Fonts:** Abril Fatface (display headings, festive serif) + Nunito (body, warm rounded sans)
- **Differentiator from prior food templates:**
  - restaurant-general (day 22): dark olive/gold, Libre Baskerville
  - coffee-shop (day 23): parchment/terracotta-rust, Fraunces
  - pizzeria (day 32): cream/tomato-red/basil, Playfair Display
  - sushi-bar (day 33): washi white/indigo, Cormorant Garamond
  - This template: vibrant teal/terracotta/marigold, Abril Fatface — distinct character

---

## Sections

1. **Hero** — Teal full-width hero with restaurant name (Abril Fatface display), tagline, star rating, address, and two CTAs (Order Takeout + View Menu)
2. **Menu** — Tabbed menu (Tacos · Antojitos · Platos Fuertes · Bebidas) with prices, vegetarian/spicy badges, and "fan favorite" labels
3. **Takeout CTA** — Prominent terracotta call-to-action band with Toast/ChowNow order integration placeholder and phone option
4. **Our Story** — Owner bio (Rosa Vásquez, Oaxacan roots), philosophy quote, chef stats card, regional heritage note
5. **Gallery** — 6-item SVG placeholder grid with food photography captions
6. **Hours & Location** — Weekly hours table with today-highlighting, embedded map placeholder, get directions + order CTAs

---

## Structured data

- `schema.org/Restaurant` with address, geo, hours, aggregateRating, menu, amenityFeature
- `schema.org/Menu` with category descriptions
- `schema.org/Person` (owner/founder)

---

## Quick start

```bash
git clone #
cd templates/templates/mexican-restaurant
npm install
npm run dev
```

Configure your restaurant details in `src/data/site.ts` and `src/data/menu.ts`.

### Environment variables

```bash
# Copy the example and fill in your values
cp .env.example .env
```

| Variable | Description |
|---|---|
| `PUBLIC_BASE_PATH` | Base path for deployment (e.g. `/` for root, `/mexican-restaurant/` for subdirectory) |
| `PUBLIC_SITE_URL` | Canonical site URL for SEO |
| `PUBLIC_TEMPLATE_HUB_URL` | Author deploy only — enables TemplateInfo bar + analytics |
| `PUBLIC_AUTHOR_DONATE_URL` | Ko-fi or other donation URL |

---

## Tests

```bash
npm test              # Playwright smoke + a11y + links + template-info
npm run test:a11y     # axe-core WCAG 2.1 AA
npm run test:links    # No broken internal links, external links have rel=noopener
npm run test:lighthouse  # Lighthouse CI ≥ 0.95 on all four categories
```

---

## Deploy to GitHub Pages

1. Fork this repo or copy `templates/mexican-restaurant/` to your own repo
2. Add secrets/vars to your repo: `PUBLIC_SITE_URL`, `PUBLIC_BASE_PATH`
3. Enable GitHub Pages (Settings → Pages → Actions source)
4. The included `.github/workflows/pages.yml` handles everything

---

## License

MIT — free to use, modify, and deploy commercially. Attribution appreciated but not required.

Built by [Allan Niñal](#) as roadmap.
