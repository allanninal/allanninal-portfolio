import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/La Milpa/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu-heading')).toBeVisible();
});

test('menu tab buttons are present', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const secondTab = tabs.nth(1);
  await secondTab.click();
  const selected = await secondTab.getAttribute('aria-selected');
  expect(selected).toBe('true');
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('story heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story-heading')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('gallery heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery-heading')).toBeVisible();
});

test('hours section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('hours heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours-heading')).toBeVisible();
});

test('takeout section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#takeout')).toBeVisible();
});

test('takeout heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#takeout-heading')).toBeVisible();
});

test('location section is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  // Free edition shows the download bar; the Pro-preview demo shows the Pro bar.
  const templateInfo = page.locator(
    '[aria-label="Free template — download or fork"], [aria-label="Pro edition — live preview"]',
  );
  await expect(templateInfo).toBeVisible();
});

test('Order Takeout CTA is visible in hero', async ({ page }) => {
  await page.goto('/');
  const hero = page.locator('#hero');
  const ctaLink = hero.locator('a[target="_blank"]').first();
  await expect(ctaLink).toBeVisible();
});

test('navigation links exist in header', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('JSON-LD Restaurant schema is present', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  let foundRestaurant = false;
  for (const script of scripts) {
    const content = await script.textContent();
    if (content && content.includes('"Restaurant"')) {
      foundRestaurant = true;
      break;
    }
  }
  expect(foundRestaurant).toBe(true);
});

test('site footer contains restaurant name', async ({ page }) => {
  await page.goto('/');
  // Check that La Milpa appears somewhere in the site footer
  // (the footer element is a direct child of body — exclude blockquote footer)
  const siteName = page.getByText('La Milpa').first();
  await expect(siteName).toBeVisible();
});
