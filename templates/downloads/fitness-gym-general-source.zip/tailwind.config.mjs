/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Russo One"', 'Impact', 'sans-serif'],
        body:    ['"Exo 2"', 'system-ui', 'sans-serif'],
      },
      colors: {
        carbon: {
          50:  '#F0F0EE',
          100: '#D8D8D6',
          200: '#B0B0AE',
          300: '#888888',
          400: '#606060',
          500: '#3C3C3E',
          600: '#252629',
          700: '#1A1B1E',
          800: '#111214',
          900: '#080809',
        },
        orange: {
          50:  '#FFF3EB',
          100: '#FFE2CC',
          200: '#FFBD99',
          300: '#FF9966',
          400: '#FF7133',
          500: '#EF4900',
          600: '#CC3D00',
          700: '#A83200',
          800: '#852700',
          900: '#611C00',
        },
      },
    },
  },
  plugins: [],
};
