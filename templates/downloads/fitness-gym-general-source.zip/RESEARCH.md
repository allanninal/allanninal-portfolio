# Day 60 — Fitness Gym General: Niche Research

## Slug
`fitness-gym-general`

## Differentiation from Days 1–59

### Visual register audit (all prior days — palette taken)
| Day | Template | Palette family | Fonts |
|-----|----------|----------------|-------|
| 1 | developer-portfolio | Amber #FFB020 on near-black | Inter + Geist Mono |
| 2 | saas-landing | Violet/indigo on light | Geist/Satoshi + Inter |
| 3 | startup-waitlist | Lime #A3E635 on dark | Geist |
| 4 | link-in-bio | Coral #FF6B4A on light | DM Sans |
| 5 | personal-blog | Forest green #1C4A2E on warm-white | Newsreader + Inter |
| 6 | documentation-site | Cobalt #2563EB on light | IBM Plex |
| 7 | mobile-app-landing | Magenta #DB2777 on warm off-white | Manrope |
| 8 | agency-studio | Burnt orange #C2410C on warm off-white | Fraunces + Space Grotesk |
| 9 | course-cohort-landing | Deep teal/jade #0D7377 on warm parchment | custom |
| 10 | open-source-project | Teal #14B8A6 on dark | Inter |
| 11 | newsletter-landing | Oxblood #881337 on cream | Newsreader |
| 12 | coming-soon | Aubergine #4A1942 on warm white | Fraunces + Space Grotesk |
| 13 | conference-event | Midnight-navy on dark | bold grotesque |
| 14–19 | various | per-day palettes | various |
| 22 | restaurant-general | Olive-charcoal + gold #C4973A | Libre Baskerville + Mulish |
| 23 | coffee-shop | Parchment + terracotta-rust | Fraunces + Plus Jakarta Sans |
| 25 | coach-consultant | Sage-linen + green | Raleway + Nunito |
| 27 | github-readme-profile | Navy #0D1117 + cyan | mono fonts |
| 29 | changelog-page | Warm off-white + indigo #6366F1 | Inter Tight + JetBrains Mono |
| 32 | pizzeria | Cream + tomato red #C0392B | Playfair Display + Nunito |
| 35 | designer-portfolio | Terracotta #C45B3A + parchment | Archivo Black + Cormorant |
| 36 | steakhouse | Near-black + oxblood + brass | DM Serif Display + Karla |
| 41 | juice-bar | Citrus-orange + leafy-green | Urbanist Variable + Geist |
| 42 | brewery | Slate-charcoal + copper-amber | Oswald + Work Sans |
| 43 | wine-bar | Deep-velvet + burgundy + gold | Cinzel + Montserrat |
| 44 | cocktail-lounge | Noir-black + emerald-neon | Bodoni Moda + IBM Plex Mono |
| 45 | tea-room | Parchment + celadon | Cardo + Figtree |
| 46 | brunch-spot | Sunny-yellow + coral + sky | Gabarito + Poppins |
| 47 | food-truck | — | — |
| 48 | catering-company | Midnight-navy + champagne-gold | Marcellus + Mulish |
| 49 | personal-chef | Aubergine + champagne-blush | Tenor Sans + Albert Sans |
| 50 | hair-salon | Mauve + champagne + ivory | Bellefair + Questrial |
| 51 | barbershop | Near-black + oxblood + brass | Teko + Hind |
| 52 | nail-salon | Coral + rose-gold + plum | Italiana + Plus Jakarta Sans |
| 53 | day-spa | Sage-green #3A6047 + stone + pearl | Crimson Pro + Raleway |
| 54 | massage-therapist | Deep ocean teal #1A4A5A + sand | Libre Baskerville + Source Sans 3 |
| 55 | tattoo-studio | Ink-black + bone-white + amber #E8A020 | Bebas Neue + Barlow |
| 56 | esthetician-skincare | Blush-ivory + warm-clay #C2705A | DM Serif Display + DM Sans |
| 57 | makeup-artist | Deep-plum #4A1860 + champagne-gold | Cormorant Garamond + Nunito Sans |
| 58 | eyelash-studio | Espresso-dark #1C1410 + dusty-rose | Playfair Display + DM Sans |
| 59 | nutritionist-clinic | Herb-green #1F7A54 + warm honey on crisp white | Josefin Sans + Bitter |

### Day 60 distinct visual register

- **Palette**: Carbon Black (#111214) + Electric Orange (#EF4900) + Concrete White (#F0F0EE)
  - Carbon (#111214): Near-black with very slight warm undertone — "raw steel, weight room floor"
  - Electric Orange (#EF4900): Vivid, high-energy orange — NOT amber (day 1: #FFB020, too yellow), NOT burnt orange (day 8: #C2410C, more muted/darker), NOT copper-amber (day 42: warmer/more brown), NOT terracotta (day 4/35: earthier). This is the "power neon" orange of gym signage, weight plates, and athletic branding.
  - Concrete White (#F0F0EE): Off-white text on dark — slightly warm tone to avoid harsh pure-white
  - Iron Surface (#1A1B1E): Card/section backgrounds, slightly lighter than base
  - Steel (#252629): Elevated surfaces, borders
  - This is a **dark-default template** — distinct register from most health/wellness templates (which are light-default)
  
- **Typography**: 
  - **Russo One** (display/headings): Ultra-bold, single-weight display font. Used in athletic branding, sports media. Conveys raw power and confidence. NOT used in any of days 1–59.
  - **Exo 2** (body/UI/navigation): Clean geometric sans with humanist warmth. Multiple weights available. Technical precision meets approachability. NOT used in any of days 1–59.
  - This font pairing has a "performance" register — sports tech meets iron gym.
  
- **Density**: High-density information layout — class schedule table, trainer grid, 3-tier membership pricing, testimonials, FAQ. Gym sites need to answer "what classes/when/how much" immediately.

### Color contrast checks (WCAG AA — dark-default template)
- Concrete White (#F0F0EE) on Carbon (#111214): ~13.2:1 — AAA ✓
- Concrete White (#F0F0EE) on Iron Surface (#1A1B1E): ~12.1:1 — AAA ✓
- Electric Orange (#EF4900) on Carbon (#111214): ~5.4:1 — AA ✓ (large text, headings, icons)
- Carbon Black (#111214) on Electric Orange (#EF4900): ~5.4:1 — AA ✓ (button text)
- Mid Concrete (#9A9B9F) on Carbon (#111214): ~4.7:1 — AA ✓ (muted text minimum)
- Electric Orange (#EF4900) on Iron Surface (#1A1B1E): ~4.9:1 — AA ✓ (eyebrow/label text)
- Avoid: #EF4900 for small body paragraph text — use #F0F0EE instead

## Persona
**Iron Peak Fitness** — General-purpose Commercial Gym
- Location: Austin, TX (South Lamar Blvd)
- Owner/Head Coach: **Marcus Cole**, CSCS, CPT (Certified Strength & Conditioning Specialist, Certified Personal Trainer)
- Practice: Premium mid-size gym — not a boutique studio, not a big-box chain
- Niche: Strength training, group fitness classes, personal training, 24/5 access

## Sections
1. **Hero** — "FORGE YOUR BEST SELF" + dual CTAs (Join Now / Try Free Day)
2. **Stats band** — 1,200+ Members · 35+ Classes/Week · 8 Certified Trainers · 5 Years
3. **Features** — Premium Equipment · Expert Coaching · All Fitness Levels · 24/5 Access
4. **Class Schedule** — Filterable weekly class table (HIIT · Spin · Strength · Yoga · Boxing)
5. **Trainers** — 4 trainer cards with specialty + certifications
6. **Membership** — 3-tier pricing: Day Pass $20 / Monthly $69 / Annual $599
7. **Testimonials** — 5 member reviews
8. **About** — Gym story + values
9. **FAQ** — 8 common questions
10. **Contact** — Hours, phone, address, inquiry form

## Schema.org
- `LocalBusiness` + `HealthClub` + `SportsActivityLocation`
- `FAQPage` + `Question` + `Answer`
- `Person` (owner/trainer)
- `Offer` (membership tiers)
