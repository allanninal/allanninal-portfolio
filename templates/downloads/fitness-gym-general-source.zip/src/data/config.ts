export const gym = {
  name:         'Iron Peak Fitness',
  tagline:      'Forge Your Best Self',
  description:  'Premium gym in Austin, TX — strength training, cardio, group fitness classes, and certified personal training for all fitness levels.',
  phone:        '(512) 555-0147',
  email:        'hello@ironpeakfitness.com',
  address:      '2200 S Lamar Blvd',
  city:         'Austin',
  state:        'TX',
  zip:          '78704',
  instagram:    'https://instagram.com/ironpeakfitness',
  facebook:     'https://facebook.com/ironpeakfitness',
  youtube:      'https://youtube.com/@ironpeakfitness',
  joinUrl:      'https://app.ironpeakfitness.com/join',
  trialUrl:     'https://app.ironpeakfitness.com/free-day',
  owner: {
    name:  'Marcus Cole',
    title: 'Owner & Head Strength Coach',
    certs: ['CSCS', 'CPT', 'Precision Nutrition L1'],
  },
  makerBio: {
    name:     'Iron Peak Fitness',
    url:      'https://allanninal.dev',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'Iron Peak Fitness | Gym in Austin TX — Classes, Trainers & Memberships',
  description:   'Iron Peak Fitness in Austin, TX offers strength training, HIIT, spin, yoga, and boxing classes with 8 certified trainers. Flexible memberships from $69/month. Join today or try a free day pass.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
