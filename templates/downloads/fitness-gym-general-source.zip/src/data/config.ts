export const gym = {
  name:         'Iron Peak Fitness',
  tagline:      'Forge Your Best Self',
  description:  'Premium gym in Austin, TX — strength training, cardio, group fitness classes, and certified personal training for all fitness levels.',
  phone:        '(512) 555-0147',
  email:        'hello@ironpeakfitness.com',
  address:      '2200 S Lamar Blvd',
  city:         'Austin',
  state:        'TX',
  zip:          '78704',
  instagram:    'https://instagram.com/ironpeakfitness',
  facebook:     'https://facebook.com/ironpeakfitness',
  youtube:      'https://youtube.com/@ironpeakfitness',
  joinUrl:      'https://app.ironpeakfitness.com/join',
  trialUrl:     'https://app.ironpeakfitness.com/free-day',
  owner: {
    name:  'Marcus Cole',
    title: 'Owner & Head Strength Coach',
    certs: ['CSCS', 'CPT', 'Precision Nutrition L1'],
  },
  makerBio: {
    name:     'Iron Peak Fitness',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Iron Peak Fitness — Gym in Austin TX, Classes & Trainers',
  description:   'Strength, HIIT, spin, yoga and boxing in Austin, TX with 8 certified trainers. Memberships from $69 a month, or try a free day pass.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
