/**
 * The task matrix — this template's whole argument.
 *
 * Every other trade template in this library answers "what do you do" with a
 * grid of service cards. A cleaning customer does not need that; they know what
 * cleaning is. What they do not know — and what every refund and one-star review
 * in this trade is actually about — is what was INCLUDED. "They didn't do the
 * baseboards." "I assumed inside the oven was part of it."
 *
 * So the page is the checklist, published in full, including the rows where the
 * answer is no. See docs/TEMPLATE_DIVERGENCE.md.
 *
 * tiers: 0 = not included, 1 = included, 2 = included on request at extra cost.
 */

export const tiers = [
  { id: 'standard', label: 'Standard', sub: 'Recurring maintenance' },
  { id: 'deep', label: 'Deep', sub: 'First clean, or twice a year' },
  { id: 'moveout', label: 'Move-out', sub: 'Empty home, deposit on the line' },
];

export type Row = { task: string; standard: 0 | 1 | 2; deep: 0 | 1 | 2; moveout: 0 | 1 | 2 };

export const rooms: { room: string; rows: Row[] }[] = [
  {
    room: 'Every room',
    rows: [
      { task: 'Floors vacuumed and mopped', standard: 1, deep: 1, moveout: 1 },
      { task: 'Surfaces dusted, reachable without a ladder', standard: 1, deep: 1, moveout: 1 },
      { task: 'Mirrors and interior glass', standard: 1, deep: 1, moveout: 1 },
      { task: 'Bins emptied, liners replaced', standard: 1, deep: 1, moveout: 1 },
      { task: 'Baseboards wiped', standard: 0, deep: 1, moveout: 1 },
      { task: 'Doors, frames and light switches wiped', standard: 0, deep: 1, moveout: 1 },
      { task: 'Ceiling fans and high dusting', standard: 0, deep: 1, moveout: 1 },
      { task: 'Interior windows', standard: 0, deep: 2, moveout: 1 },
      { task: 'Walls spot-cleaned', standard: 0, deep: 0, moveout: 1 },
      { task: 'Carpet shampooed', standard: 0, deep: 0, moveout: 2 },
    ],
  },
  {
    room: 'Kitchen',
    rows: [
      { task: 'Counters, sink and backsplash', standard: 1, deep: 1, moveout: 1 },
      { task: 'Appliance exteriors', standard: 1, deep: 1, moveout: 1 },
      { task: 'Stovetop and grates', standard: 1, deep: 1, moveout: 1 },
      { task: 'Microwave inside', standard: 1, deep: 1, moveout: 1 },
      { task: 'Cabinet fronts', standard: 0, deep: 1, moveout: 1 },
      { task: 'Inside the oven', standard: 0, deep: 2, moveout: 1 },
      { task: 'Inside the fridge', standard: 0, deep: 2, moveout: 1 },
      { task: 'Inside cabinets and drawers', standard: 0, deep: 0, moveout: 1 },
      { task: 'Range hood filter degreased', standard: 0, deep: 2, moveout: 1 },
    ],
  },
  {
    room: 'Bathrooms',
    rows: [
      { task: 'Toilet, inside and out', standard: 1, deep: 1, moveout: 1 },
      { task: 'Shower, tub and tiled walls', standard: 1, deep: 1, moveout: 1 },
      { task: 'Vanity, sink and taps', standard: 1, deep: 1, moveout: 1 },
      { task: 'Grout scrubbed', standard: 0, deep: 1, moveout: 1 },
      { task: 'Shower door hard-water removal', standard: 0, deep: 1, moveout: 1 },
      { task: 'Extractor fan cover', standard: 0, deep: 1, moveout: 1 },
      { task: 'Inside vanity cabinets', standard: 0, deep: 0, moveout: 1 },
    ],
  },
  {
    room: 'Bedrooms & living',
    rows: [
      { task: 'Beds made', standard: 1, deep: 1, moveout: 0 },
      { task: 'Bed linen changed (left out for us)', standard: 2, deep: 2, moveout: 0 },
      { task: 'Under-bed vacuumed', standard: 0, deep: 1, moveout: 1 },
      { task: 'Upholstery vacuumed', standard: 0, deep: 1, moveout: 1 },
      { task: 'Inside wardrobes and closets', standard: 0, deep: 0, moveout: 1 },
      { task: 'Blinds dusted', standard: 0, deep: 1, moveout: 1 },
    ],
  },
];

/**
 * The honest list. A cleaning company that will not say what it refuses to do
 * is a cleaning company you will argue with later.
 */
export const never = [
  { task: 'Exterior windows above the ground floor', why: 'Ladder work above one storey needs different insurance than we carry.' },
  { task: 'Mould remediation', why: 'Anything past surface mildew is a licensed trade. We will tell you what we are looking at and stop.' },
  { task: 'Pet accidents and biohazard', why: 'Blood, faeces and needles need containment we are not set up for.' },
  { task: 'Heavy clutter and hoarding', why: 'We clean surfaces, we do not sort belongings. We will happily quote once a space is clear.' },
  { task: 'Moving furniture over 25 lb', why: 'Two people and a bad back is how this trade ends careers. We clean around it, or you move it first.' },
  { task: 'Anything on a roof, in a crawlspace, or in an attic', why: 'Not a cleaning job, whatever the listing site says.' },
];

/** Real 2026 US figures — dollars per square foot cleaned. */
export const pricing = {
  perSqFt: [
    { tier: 'Standard', low: 0.10, high: 0.17, example: '$180 – $280' },
    { tier: 'Deep', low: 0.11, high: 0.30, example: '$250 – $450' },
    { tier: 'Move-out', low: 0.22, high: 0.33, example: '$250 – $420' },
  ],
  exampleSize: '2,000 sq ft',
  cadence: [
    { every: 'Weekly', discount: '20% off the per-visit price', note: 'Rarely the right answer for a household of two.' },
    { every: 'Every two weeks', discount: '15% off', note: 'What most homes actually need, and what we recommend first.' },
    { every: 'Every four weeks', discount: '10% off', note: 'Workable, but the first hour goes on catching up.' },
    { every: 'One-off', discount: 'Full price', note: 'No commitment, no discount, no hard feelings.' },
  ],
};
