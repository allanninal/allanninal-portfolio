/**
 * Fair Weather Cleaning Co. — every string the page renders.
 *
 * The business is fictional. The PRICES ARE NOT: the per-square-foot figures in
 * checklist.ts are real 2026 US averages, sourced in RESEARCH.md.
 *
 * Replace every contact detail before shipping this for a real business.
 */

export const site = {
  name: 'Fair Weather Cleaning Co.',
  shortName: 'Fair Weather',
  tagline: 'Recurring, deep and move-out cleaning across Madison.',
  description:
    'A four-person cleaning crew in Madison, Wisconsin. Employees rather than contractors, the same team each visit, and a task checklist published in full — including the parts we do not do.',
  owner: 'Renata Salgado',
  ownerRole: 'Owner',
  yearsExperience: 8,
  crewSize: 4,
  city: 'Madison',
  state: 'WI',
  streetAddress: '2210 Winnebago Street',
  postalCode: '53704',
  phoneDisplay: '(608) 555-0142',
  phoneHref: '+16085550142',
  email: 'hello@fairweatherclean.example',
  /* Formspree/Basin/your own endpoint. The demo posts nowhere. */
  formAction: '#',
  hours: 'Mon–Fri 8am–5pm · Saturdays for move-outs only',
  bookingWindow: 'Booking two weeks out for recurring, sooner for move-outs.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Fair Weather Cleaning Co. — House Cleaning in Madison, WI',
  license: 'Licensed, bonded and insured · Wisconsin',
  instagram: 'https://www.instagram.com/fairweatherclean',
  facebook: 'https://www.facebook.com/fairweatherclean',
};

export const nav = [
  { label: 'What we clean', href: '#matrix' },
  { label: 'What we don’t', href: '#never' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Who turns up', href: '#crew' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/** The differentiator that actually matters in this trade. */
export const crew = [
  {
    point: 'Employees, not contractors',
    body: 'Everyone who enters your home is on our payroll, background-checked and covered by our insurance. A contractor model pushes that liability onto you, and most of this industry uses it.',
  },
  {
    point: 'The same two people',
    body: 'You get the same pair each visit. They learn your home, which is the only reason a 90-minute clean gets faster rather than worse.',
  },
  {
    point: 'Bonded and insured',
    body: 'Two million in liability and a surety bond covering theft. Ask any cleaner for both certificates — a real company will send them without hesitating.',
  },
  {
    point: 'We bring everything',
    body: 'Products, cloths, vacuums. If you would rather we used yours — allergies, stone counters, a preference — leave them out and we will.',
  },
];

export const areas = [
  { zone: 'Central Madison', towns: 'Isthmus · Tenney-Lapham · Marquette · Willy Street · Downtown' },
  { zone: 'West', towns: 'Shorewood Hills · Hill Farms · Midvale Heights · Nakoma' },
  { zone: 'East & North', towns: 'Schenk-Atwood · Eken Park · Maple Bluff · Sherman' },
  { zone: 'Suburbs', towns: 'Middleton · Fitchburg · Sun Prairie · Verona · McFarland' },
];

export const reviews = [
  { name: 'Priya N.', town: 'Tenney-Lapham', text: 'They sent me the checklist before the first visit and then actually did all of it. I have never had that from a cleaner, and I have hired four.' },
  { name: 'Doug W.', town: 'Middleton', text: 'Asked about the oven, got told plainly it was extra on a deep clean and included on a move-out. No upsell, just the answer.' },
  { name: 'Marisa T.', town: 'Schenk-Atwood', text: 'Same two people every fortnight for two years. They know which cupboard the cat food is in. That is worth more than the discount.' },
  { name: 'Owen B.', town: 'Fitchburg', text: 'Move-out clean on a rental the landlord was clearly hoping to fight about. Got the full deposit back and sent Renata a photo of the cheque.' },
];

export const faqs = [
  { q: 'Do I have to be home?', a: 'No, and most of our recurring clients are not. We hold keys or codes in a locked system, only the assigned crew has access, and we text when we arrive and leave. If you would rather be there, that is completely fine too.' },
  { q: 'What if something gets broken?', a: 'We tell you the same day, before you find it. Two million in liability covers it and we have never argued about a claim. The things that break are usually lamps and picture frames; we would rather replace one than have you discover it on Friday night.' },
  { q: 'Can I skip a visit?', a: 'Yes, with 48 hours notice and no fee. Skip more than two in a row and the discount resets to the next cadence down, because the following clean takes longer.' },
  { q: 'Do you clean with anything harsh?', a: 'Standard products are fragrance-free and pet-safe. We keep bleach and a proper degreaser on the van for bathrooms and range hoods, and we will not use either if you ask us not to — just know the grout will not come as white.' },
  { q: 'Why is the first clean more expensive?', a: 'Because it is a deep clean. Whatever the previous arrangement was, there is catch-up in the baseboards, the grout and the tops of things. After that the maintenance price applies.' },
  { q: 'Are you actually insured, or is that just on the website?', a: 'Actually insured. Ask and we will email the certificate of insurance and the bond, both current. You should ask this of every cleaner you consider, and you should be suspicious of any hesitation.' },
];
