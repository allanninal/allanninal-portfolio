import { test, expect } from '@playwright/test';

test.describe('Fair Weather Cleaning — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Fair Weather Cleaning Co\./);
    await expect(page.locator('h1')).toContainText('checklist');
  });

  // The matrix IS the template. If it degrades to a card grid the whole
  // argument for this day is gone, so it is asserted as a real table.
  test('the task matrix is a real table with row and column headers', async ({ page }) => {
    await page.goto('/');
    const m = page.locator('table.matrix').first();
    await expect(m).toBeVisible();
    await expect(m.locator('caption')).toHaveCount(1);
    expect(await m.locator('thead th[scope="col"]').count()).toBe(4);
    // One <tbody> per room group, each introduced by a colgroup header.
    expect(await m.locator('tbody').count()).toBe(4);
    expect(await m.locator('th[scope="colgroup"]').count()).toBe(4);
    expect(await m.locator('tbody th[scope="row"]').count()).toBe(32);
  });

  test('every matrix cell carries a text label, not just a colour', async ({ page }) => {
    await page.goto('/');
    const cells = page.locator('table.matrix').first().locator('tbody td');
    const n = await cells.count();
    expect(n).toBe(96); // 32 tasks x 3 tiers
    // Each cell pairs an aria-hidden glyph with a visually-hidden word.
    expect(await cells.locator('.sr-only').count()).toBe(n);
  });

  // A checklist that only says yes is marketing. The noes are the point.
  test('the matrix contains real exclusions', async ({ page }) => {
    await page.goto('/');
    const body = page.locator('table.matrix').first();
    const no = await body.locator('.mk--no').count();
    const extra = await body.locator('.mk--extra').count();
    expect(no).toBeGreaterThan(20);
    expect(extra).toBeGreaterThan(3);
  });

  test('the never-do section states a reason for each refusal', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#never .never-item');
    expect(await items.count()).toBe(6);
    for (const t of await items.allTextContents()) expect(t.length).toBeGreaterThan(60);
  });

  test('pricing is shown per square foot and by cadence', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#pricing table.matrix tbody tr');
    expect(await rows.count()).toBe(3);
    for (const t of await rows.allTextContents()) expect(t).toMatch(/\$0\.\d{2}/);
    expect(await page.locator('#pricing dl > div').count()).toBe(4);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffold contamination: this template was scaffolded from day 77.
  test('no trace of the day-77 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['underfoot', 'marisol', 'providence', 'hardwood', 'subfloor']) {
      expect(html).not.toContain(noun);
    }
  });

  // Asserts the page cannot actually be scrolled sideways, rather than reading
  // documentElement.scrollWidth. That metric is unusable on this template: the
  // task matrix is a wide table inside an overflow-x:auto wrapper, and Chrome
  // inflates the ROOT scrollWidth to 662 because of it while body.scrollWidth
  // stays at the viewport's 375 and window.scrollX never leaves 0. Trying to
  // scroll and checking whether anything moved is the real question.
  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  // ...but the matrix itself must still scroll, or it is unreadable on a phone.
  test('the matrix scrolls inside its own container on a phone', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const m = await page.evaluate(() => {
      const w = document.querySelector('.matrix-wrap') as HTMLElement;
      return { visible: Math.round(w.getBoundingClientRect().width), content: w.scrollWidth };
    });
    expect(m.content).toBeGreaterThan(m.visible);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro checklist is absent from the free build', async ({ page }) => {
    const res = await page.goto('/move-out-checklist/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Where deposits actually go');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
