# Day 54 — Massage Therapist: Niche Research

## Slug
`massage-therapist`

## Differentiation from Days 1–53

### Visual register audit
| Day | Palette family | Fonts |
|-----|---------------|-------|
| 53 day-spa | sage/stone/cream | Crimson Pro + Raleway |
| 52 nail-salon | coral/rose-gold/plum | Italiana + Plus Jakarta Sans |
| 51 barbershop | near-black/oxblood/brass | Teko + Hind |
| 50 hair-salon | mauve/champagne/ivory | Bellefair + Questrial |
| 49 personal-chef | aubergine/blush/cream | Tenor Sans + Albert Sans |
| 48 catering-company | navy/gold | Marcellus + Mulish |

### Day 54 distinct register
- **Palette**: Deep Ocean Teal (#1A4A5A) + Warm Sand (#E8D5B7) + Linen White (#FAF8F5) + Amber (#C17A2E)
  - No green, no sage, no coral, no mauve, no navy, no oxblood
  - Teal is the dominant accent: clinical, trustworthy, health-oriented
  - Sand/linen warm the palette without going cream/champagne
- **Typography**: Libre Baskerville (serif headings) + Source Sans 3 Variable (body)
  - Neither used in days 1–53
  - Baskerville conveys professional credibility (clinical + approachable)
  - Source Sans 3 is highly legible for services/pricing copy
- **Density**: Mid-dense — more textual than nail-salon (which is gallery-heavy), less airy than day-spa

## Persona
**Mara Chen, LMT** — Licensed Massage Therapist, 9 years experience
- Location: Portland, OR (Pearl District)
- Credentials: Oregon State Licensed, NCBTMB certified, prenatal specialist
- Niche: Therapeutic/clinical massage for chronic pain, athletic recovery, and prenatal clients
- Tone: warm, knowledgeable, evidence-based (not luxury spa language)
- Booking platform: Jane App (common for solo therapists)

## Sections (single-page)
1. **Hero** — photo panel, name + credentials, tagline, Book CTA
2. **Modalities** — 6 massage types with duration + price cards (no tabs, horizontal scroll grid)
3. **About Mara** — bio, credentials, philosophy, headshot area
4. **Why Choose** — 4 trust-building callouts (licensed, trauma-informed, clean studio, flexible scheduling)
5. **Testimonials** — 5 quotes from named clients
6. **FAQ** — 6 questions for first-time clients (accordion)
7. **Hours & Booking** — schedule + Jane App booking embed placeholder
8. **Contact** — address, email, phone, map placeholder

## Schema.org
- `HealthAndBeautyBusiness` + `LocalBusiness`
- `Person` (the therapist)
- `Service` + `Offer` for each modality
- `FAQPage` for the FAQ section

## Color contrast checks
- Deep teal (#1A4A5A) on linen (#FAF8F5): contrast ratio ≈ 10.8:1 — AAA ✓
- Amber (#C17A2E) on linen (#FAF8F5): contrast ratio ≈ 3.6:1 — FAIL for body text
  → Use amber ONLY for decorative borders/icons, not body text
  → For links/badges: darken to #9A5C18 = 5.4:1 — AA ✓
- Muted text: #5A4A3A on linen = ≈ 5.2:1 — AA ✓
- White on teal (#1A4A5A): ≈ 10.8:1 — AAA ✓ (buttons)

## Image plan (free edition — decorative CSS, no Unsplash required for base)
The free edition uses CSS decorative shapes for visual interest.
A real image in the free edition would require Unsplash sourcing.
Decision: include 1 Unsplash hero image in the free edition (therapist hands on back) 
to demonstrate the photo-heavy nature of this niche.

## Key differentiators from day-spa
1. **Solo practitioner** vs team/establishment
2. **Clinical/therapeutic** language vs luxury/retreat language
3. **FAQ section** (first-timer anxiety — common in massage niche)
4. **Modality grid** (not tabbed) — scanner-friendly for busy clients
5. **Portland OR** not Brooklyn NY
6. **Jane App** booking (therapist-specific) vs MindBody (spa platform)
