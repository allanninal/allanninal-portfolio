# Massage Therapist — Day 54 of 365

A clean, clinically-focused website template for independent licensed massage therapists. Built with Astro + Tailwind CSS.

**Live demo:** https://templates.allanninal.dev/massage-therapist/

## Visual identity

- **Palette:** Deep Ocean Teal (#1A4A5A) + Warm Sand (#E8D5B7) + Linen White (#FAF8F5)
- **Typography:** Libre Baskerville (headings) + Source Sans 3 Variable (body)
- **Tone:** Evidence-based, clinical, warm — not luxury spa language

## Sections

1. **Hero** — full split layout with hero photo, therapist name + credentials, Book CTA
2. **Stats band** — years experience, clients served, rating, modalities
3. **Modalities** — 6 massage types with 60/90-min pricing, benefits list, highlight card
4. **Add-ons** — 4 session enhancements (aromatherapy, CBD balm, cupping, salt scrub)
5. **About** — therapist bio, philosophy, professional credentials list
6. **Why Choose** — 4 trust-building callouts (dark teal band)
7. **Testimonials** — 5 client reviews
8. **FAQ** — 6-item accordion for first-time clients
9. **Hours & Location** — studio hours table + address
10. **Booking CTA** — Jane App link + phone

## Stack

- [Astro](https://astro.build) (static output)
- [Tailwind CSS v3](https://tailwindcss.com)
- [@fontsource/libre-baskerville](https://fontsource.org/fonts/libre-baskerville) — self-hosted
- [@fontsource-variable/source-sans-3](https://fontsource.org/fonts/source-sans-3) — self-hosted
- Schema.org: `HealthAndBeautyBusiness` + `Person` + `Service` + `Offer` JSON-LD

## Getting started

```bash
npm install
npm run dev
```

## Environment variables

Copy `.env.example` to `.env`:

```
PUBLIC_TEMPLATE_HUB_URL=   # Leave blank in your own deploy
PUBLIC_SITE_URL=            # Defaults to https://templates.allanninal.dev
PUBLIC_BASE_PATH=           # Defaults to /massage-therapist/
```

## Build & test

```bash
npm run build               # Production build
npx playwright test         # Full test suite
```

## License

MIT — free to use, modify, and deploy. Attribution appreciated but not required.

---

Part of the [365 Astro Templates](https://templates.allanninal.dev) project by [Allan Niñal](https://www.linkedin.com/in/allanninal/).
