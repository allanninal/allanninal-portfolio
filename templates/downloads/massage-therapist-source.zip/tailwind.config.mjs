/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,md,mdx}'],
  theme: {
    extend: {
      colors: {
        // Deep Ocean Teal / Warm Sand / Linen palette
        teal:   { DEFAULT: '#1A4A5A', light: '#2D7A96', dark: '#102E38' },
        sand:   { DEFAULT: '#E8D5B7', light: '#F5EDD8', dark: '#C8AE87' },
        linen:  { DEFAULT: '#FAF8F5', muted: '#F0ECE4' },
        amber:  { DEFAULT: '#9A5C18', light: '#C17A2E' },
        slate:  { DEFAULT: '#3A3028', muted: '#5A4A3A' },
      },
      fontFamily: {
        serif: ['"Libre Baskerville"', 'Georgia', 'serif'],
        sans:  ['"Source Sans 3 Variable"', '"Source Sans 3"', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        widest: '0.25em',
      },
    },
  },
  plugins: [],
};
