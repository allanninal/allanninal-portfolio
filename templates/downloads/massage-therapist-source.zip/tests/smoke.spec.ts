import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Mara Chen/);
});

test('hero section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero')).toBeVisible();
});

test('hero heading contains key phrase', async ({ page }) => {
  await page.goto('/');
  const h1 = page.locator('h1');
  await expect(h1).toContainText('Therapeutic massage');
});

test('credential badges are present in hero', async ({ page }) => {
  await page.goto('/');
  const badges = page.locator('.credential-badge');
  const count = await badges.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('stats band is visible', async ({ page }) => {
  await page.goto('/');
  const stats = page.locator('.stats-band');
  await expect(stats).toBeVisible();
});

test('modalities section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#modalities')).toBeVisible();
});

test('modality cards render (at least 6)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.modality-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(6);
});

test('add-ons section renders', async ({ page }) => {
  await page.goto('/');
  const addons = page.locator('.addon-card');
  const count = await addons.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('about section contains therapist name', async ({ page }) => {
  await page.goto('/');
  const about = page.locator('#about');
  await expect(about).toContainText('Mara');
});

test('trust section is visible', async ({ page }) => {
  await page.goto('/');
  const trust = page.locator('.trust-section');
  await expect(trust).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('testimonial cards render (at least 3)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.testimonial-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('FAQ section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#faq')).toBeVisible();
});

test('FAQ accordion items render', async ({ page }) => {
  await page.goto('/');
  const triggers = page.locator('.faq-trigger');
  const count = await triggers.count();
  expect(count).toBeGreaterThanOrEqual(6);
});

test('FAQ accordion opens on click', async ({ page }) => {
  await page.goto('/');
  const firstTrigger = page.locator('.faq-trigger').first();
  await firstTrigger.click();
  const expanded = await firstTrigger.getAttribute('aria-expanded');
  expect(expanded).toBe('true');
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('hours table is present', async ({ page }) => {
  await page.goto('/');
  const table = page.locator('.hours-table');
  await expect(table).toBeVisible();
});

test('booking CTA section is visible', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('.booking-cta');
  await expect(cta).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist in header', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('Book Now button exists in header', async ({ page }) => {
  await page.goto('/');
  const bookBtn = page.locator('header .btn-book');
  await expect(bookBtn).toBeVisible();
});

test('footer has therapist name', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer.site-footer');
  await expect(footer).toContainText('Mara Chen');
});

test('hero photo renders', async ({ page }) => {
  await page.goto('/');
  const heroImg = page.locator('.hero-photo img');
  await expect(heroImg).toBeVisible();
});
