export const therapist = {
  name:        'Mara Chen, LMT',
  businessName:'Mara Chen Massage Therapy',
  tagline:     'Evidence-based therapeutic massage for lasting relief.',
  description:
    'Licensed Massage Therapist serving Portland, OR with 9 years of clinical experience specializing in therapeutic massage, sports recovery, and prenatal care.',
  address:     '2210 NW Thurman St, Suite 4, Portland, OR 97210',
  phone:       '+1 (503) 555-0174',
  email:       'hello@marachenlmt.com',
  instagram:   'https://www.instagram.com/',
  facebook:    'https://www.facebook.com/',
  linkedin:    '#',
  kofi:        '#',
  bookingUrl:  'https://jane.app/',
  credentials: [
    'Oregon State Licensed Massage Therapist #LMT-12847',
    'National Certification Board for Therapeutic Massage & Bodywork (NCBTMB)',
    'Prenatal Massage Specialist — Body Support Birth, Portland',
    'Continuing Education: myofascial release, sports massage, trigger point therapy',
  ],
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '9:00 am – 6:00 pm' },
    { day: 'Wednesday', open: '10:00 am – 7:00 pm' },
    { day: 'Thursday',  open: '9:00 am – 6:00 pm' },
    { day: 'Friday',    open: '9:00 am – 5:00 pm' },
    { day: 'Saturday',  open: '8:00 am – 3:00 pm' },
    { day: 'Sunday',    open: 'Closed' },
  ],
};

export const site = {
  title:         'Mara Chen, LMT — Massage Therapist, Portland OR',
  description:
    'Licensed Massage Therapist in Portland, OR. Swedish, deep tissue, sports, prenatal, hot stone & reflexology. Book online via Jane App.',
  language:      'en',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
};

export type Modality = {
  id:          string;
  name:        string;
  tagline:     string;
  duration60:  string;
  duration90:  string;
  description: string;
  benefits:    string[];
  highlight?:  boolean;
  icon:        string;
};

export const modalities: Modality[] = [
  {
    id:         'swedish',
    name:       'Swedish Relaxation',
    tagline:    'Classic full-body relaxation',
    duration60: '$95',
    duration90: '$135',
    icon:       '◇',
    description:
      'Long, flowing effleurage strokes, gentle kneading, and rhythmic tapotement calm the nervous system and ease muscular tension head to toe. The ideal entry point for new massage clients.',
    benefits:   ['Reduces cortisol levels', 'Improves circulation', 'Relieves muscle tension', 'Promotes better sleep'],
  },
  {
    id:         'deep-tissue',
    name:       'Deep Tissue',
    tagline:    'Targeted release for chronic tension',
    duration60: '$110',
    duration90: '$155',
    icon:       '◈',
    highlight:  true,
    description:
      'Sustained, firm pressure on dense connective tissue layers addresses chronic holding patterns, postural imbalances, and repetitive-use tension. Always adapted to your threshold — "therapeutic" not "painful".',
    benefits:   ['Breaks down adhesions', 'Corrects posture', 'Relieves chronic back/neck pain', 'Reduces inflammation'],
  },
  {
    id:         'sports',
    name:       'Sports & Active Recovery',
    tagline:    'For athletes and active bodies',
    duration60: '$110',
    duration90: '$155',
    icon:       '◉',
    description:
      'Combines compression, cross-fibre friction, and assisted stretching to accelerate recovery, reduce DOMS, and improve range of motion. Effective pre-event (activating) or post-event (flushing).',
    benefits:   ['Speeds muscle recovery', 'Reduces DOMS', 'Improves flexibility', 'Prevents overuse injuries'],
  },
  {
    id:         'prenatal',
    name:       'Prenatal Massage',
    tagline:    'Safe, nurturing care for expecting mothers',
    duration60: '$105',
    duration90: '$145',
    icon:       '◯',
    description:
      'Side-lying positioning with supportive bolsters relieves the lower back, hips, and sciatic discomfort common in the second and third trimesters. Mara is a certified prenatal specialist — all techniques are OB-cleared safe.',
    benefits:   ['Eases sciatic pain', 'Reduces ankle swelling', 'Improves sleep quality', 'Lowers pregnancy anxiety'],
  },
  {
    id:         'hot-stone',
    name:       'Hot Stone',
    tagline:    'Deep heat meets deep relaxation',
    duration60: '$120',
    duration90: '$165',
    icon:       '✦',
    description:
      'Smooth basalt stones, heated to 130°F, are placed along the spine and used as massage tools. The radiant warmth penetrates muscle layers in minutes, dramatically reducing the pressure needed for deep relief.',
    benefits:   ['Penetrating heat relief', 'Melts deep tension faster', 'Boosts circulation', 'Deeply sedating for stress'],
  },
  {
    id:         'reflexology',
    name:       'Foot Reflexology',
    tagline:    '45-minute foot & lower leg focus',
    duration60: '$75',
    duration90: '$—',
    icon:       '⊕',
    description:
      'Targeted thumb-walk pressure on reflex zones of the feet and lower legs. A complete 45-minute session for those short on time, or combined with another service as a relaxing add-on.',
    benefits:   ['Relieves plantar fasciitis', 'Reduces whole-body tension', 'Supports lymphatic flow', 'Great add-on or standalone'],
  },
];

export type AddOn = {
  name:        string;
  price:       string;
  description: string;
};

export const addOns: AddOn[] = [
  { name: 'Aromatherapy Upgrade',     price: '+$15', description: 'Custom essential oil blend — calming lavender, uplifting eucalyptus, or grounding cedarwood.' },
  { name: 'CBD Muscle Balm',           price: '+$20', description: 'Topical broad-spectrum CBD salve applied to target areas for amplified anti-inflammatory effect.' },
  { name: 'Cupping (Dry)',             price: '+$20', description: 'Silicone cups lift fascia and improve blood flow to stubborn shoulder/back adhesions.' },
  { name: 'Himalayan Salt Scrub',      price: '+$25', description: '10-minute back scrub with mineral-rich salt and jojoba oil before your massage.' },
];

export const testimonials = [
  {
    quote:   'My chronic lower-back pain of three years is finally manageable. Mara found the root cause in the first session — she has an incredible ability to read the body. I book every three weeks without fail.',
    author:  'Jonah P.',
    service: 'Deep Tissue — ongoing',
    rating:  5,
  },
  {
    quote:   'I was nervous about prenatal massage but Mara made me feel completely safe. The bolstering and positioning were perfect and my hips felt like a different body afterward. My OB has noticed the difference too.',
    author:  'Sonia R.',
    service: 'Prenatal Massage — 2nd trimester',
    rating:  5,
  },
  {
    quote:   'I run marathons and have worked with sports therapists in three cities. Mara is genuinely exceptional — she understands anatomy, respects athlete schedules, and the sessions actually translate to race-day performance.',
    author:  'Derek W.',
    service: 'Sports & Recovery',
    rating:  5,
  },
  {
    quote:   'The hot stone session was unlike anything I\'d experienced — the heat went so deep that knots I\'d had for years just dissolved. I left feeling five years younger. Already booked my next.',
    author:  'Layla K.',
    service: 'Hot Stone Massage',
    rating:  5,
  },
  {
    quote:   'I send every new client her way without hesitation. As a physical therapist, it matters to me that a massage therapist has evidence-based training and communicates with other providers. Mara is that person.',
    author:  'Dr. Amanda S., DPT',
    service: 'Referring PT Partner',
    rating:  5,
  },
];

export const faqs = [
  {
    q: 'What should I expect on my first visit?',
    a: "We\'ll start with a 5-minute intake consultation to review your health history, areas of concern, and pressure preferences. You\'ll undress to your comfort level and be fully draped throughout. Sessions include time to dress and a glass of water at the end.",
  },
  {
    q: 'What should I wear / how much do I undress?',
    a: 'Most clients undress fully, but you are always welcome to leave on whatever makes you comfortable. Only the area being worked is ever uncovered — professional draping is maintained at all times.',
  },
  {
    q: 'How often should I get a massage?',
    a: 'For general wellness and stress relief, once a month is a good baseline. For chronic pain or active athletic training, every 2–3 weeks is more effective. We can discuss a maintenance plan at your first appointment.',
  },
  {
    q: 'Is massage safe if I have a medical condition?',
    a: 'Most conditions are fully compatible with massage, sometimes with simple adaptations. Please list any diagnoses, medications, or recent surgeries on your intake form. Mara will discuss any contraindications before beginning.',
  },
  {
    q: 'Do you accept insurance?',
    a: 'I accept HSA and FSA cards (massage is often an eligible expense with a practitioner referral). I\'m not currently in-network with health insurance plans, but I can provide a detailed superbill if your plan reimburses out-of-network.',
  },
  {
    q: 'What is your cancellation policy?',
    a: 'Please cancel or reschedule at least 24 hours before your appointment via Jane App to avoid a 50% late-cancel fee. Emergency cancellations are handled on a case-by-case basis — please call or text rather than emailing.',
  },
];

export const stats = [
  { value: '9+',    label: 'Years of Experience' },
  { value: '2,400+', label: 'Clients Served' },
  { value: '4.98★', label: 'Average Rating' },
  { value: '6',     label: 'Modalities Offered' },
];

export const trustPoints = [
  {
    icon: '✦',
    title: 'Oregon State Licensed',
    body:  'License #LMT-12847, current and in good standing with the Oregon Health Licensing Office.',
  },
  {
    icon: '◈',
    title: 'Trauma-Informed Practice',
    body:  'Completed the Trauma Touch Therapy certification — a client-centred, consent-based approach where you are always in control.',
  },
  {
    icon: '◇',
    title: 'Clean & Calm Studio',
    body:  'Private suite on NW Thurman. Fresh linens each session, hospital-grade table warmers, soft lighting, and no walk-in interruptions.',
  },
  {
    icon: '◉',
    title: 'Flexible Scheduling',
    body:  'Online booking via Jane App, 24/7. Same-day slots often available Tuesday–Thursday. Cancellation up to 24 hours before your session.',
  },
];
