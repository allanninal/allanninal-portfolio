// Single source of truth for the resume — Nadia Costa, senior software engineer.
// Cloning users edit this file to make the resume theirs.

export const person = {
  fullName: 'Nadia Costa',
  shortName: 'Nadia',
  initials: 'NC',
  title: 'Senior Software Engineer',
  location: 'Lisbon, Portugal',
  openToRemote: true,
  email: 'landix.ninal@gmail.com',          // demo email — replace with yours
  emailDisplay: 'nadia@nadiacosta.dev',     // display-only label (so the demo
                                            // doesn't reveal the template author's email)
  phoneDisplay: '+351 21 555 0188',         // display-only; not a tel: link
  pronouns: 'she/her',
  shortBio:
    'Senior software engineer with 8 years building reliable infrastructure for fintech and SaaS. I write boring code on purpose — the simpler the system, the easier it is to keep running.',
  summary:
    'Engineer focused on operational simplicity, observability, and the messy hand-off between research code and production. Built and led teams from 3 to 12 people. Currently looking for a senior or staff role on a backend or platform team that values long-term maintainability over feature velocity.',
};

export const links = {
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  github: 'https://github.com/allanninal',
  website: 'https://example.com/nadia',
  twitter: 'https://x.com/allannin',
};

export const experience = [
  {
    company: 'Mira Financial',
    role: 'Staff Software Engineer',
    period: '2023 — Present',
    location: 'Remote · Lisbon-based',
    bullets: [
      'Led the migration of three core ledger services to Kubernetes; cut p99 reconciliation latency from 4.2s to 1.6s without changing the underlying algorithms.',
      'Designed and shipped the audit-log pipeline now used across all 14 product teams; survived two regulatory audits with zero deficiencies.',
      'Mentored four engineers from mid to senior level, two of whom now lead their own platform teams.',
    ],
  },
  {
    company: 'Cadence Systems',
    role: 'Senior Software Engineer',
    period: '2020 — 2023',
    location: 'London, UK',
    bullets: [
      'Built the multi-tenant feature-flag service that now ships every change at Cadence (~140 deploys/week).',
      'Drove a quarterly observability review program; reduced MTTR on customer-facing incidents from 28 min median to 9 min.',
      'Wrote the internal SLO playbook, adopted by 11 of 14 product teams within 6 months.',
    ],
  },
  {
    company: 'Volta Labs',
    role: 'Founding Engineer',
    period: '2018 — 2020',
    location: 'Lisbon, Portugal',
    bullets: [
      'Employee #2; built the v1 backend (Go + Postgres + Kafka), CI/CD pipeline, and on-call rotation policies.',
      'Shipped the API that won Volta its first three enterprise customers (combined ARR > €1.2M at exit).',
      'Helped recruit and onboard the first 6 engineering hires.',
    ],
  },
  {
    company: 'Tarefa.io',
    role: 'Software Engineer',
    period: '2016 — 2018',
    location: 'Porto, Portugal',
    bullets: [
      'Joined as the company\'s 4th engineer. Owned the billing subsystem from architecture through Stripe integration.',
      'Replaced a brittle cron-based scheduler with a queue + worker design that\'s still in production seven years later.',
    ],
  },
];

export const projects = [
  {
    name: 'queueview',
    description: 'A small, opinionated TUI for inspecting RabbitMQ queues from the terminal. ~1.2K stars on GitHub.',
    stack: ['Go', 'tview', 'AMQP 0.9.1'],
    href: 'https://github.com/allanninal',
  },
  {
    name: 'slo-helper',
    description: 'A Prometheus rule generator that turns a YAML SLO definition into the alerts and dashboards you actually need.',
    stack: ['Python', 'Prometheus', 'Grafana'],
    href: 'https://github.com/allanninal',
  },
  {
    name: 'ledger-sim',
    description: 'A double-entry ledger simulator built for engineering interview prep workshops. Used by 3 fintech bootcamps.',
    stack: ['TypeScript', 'PostgreSQL'],
    href: 'https://github.com/allanninal',
  },
  {
    name: 'audit-log-spec',
    description: 'A working RFC-style spec for tamper-evident audit logs in Postgres. Co-authored with two former Mira colleagues.',
    stack: ['PostgreSQL', 'Specification'],
    href: 'https://github.com/allanninal',
  },
];

export const education = [
  {
    institution: 'Universidade de Lisboa',
    degree: 'MSc, Computer Science',
    period: '2014 — 2016',
    detail: 'Thesis: "Snapshot Isolation Trade-offs in Distributed Ledgers." Advised by Prof. R. Almeida.',
  },
  {
    institution: 'Universidade de Coimbra',
    degree: 'BSc, Computer Engineering',
    period: '2010 — 2014',
    detail: 'Final project on causal consistency in geo-distributed databases.',
  },
];

export const skills = [
  {
    category: 'Languages',
    items: ['Go', 'TypeScript', 'Python', 'Rust (familiar)', 'SQL'],
  },
  {
    category: 'Frameworks & Tools',
    items: ['gRPC', 'Protobuf', 'Kafka', 'Prometheus', 'Grafana', 'OpenTelemetry', 'Terraform'],
  },
  {
    category: 'Platforms',
    items: ['Linux', 'Kubernetes', 'AWS', 'GCP', 'PostgreSQL', 'Redis', 'GitHub Actions'],
  },
];

export const languages = [
  { name: 'Portuguese', level: 'Native' },
  { name: 'English', level: 'C2' },
  { name: 'Spanish', level: 'B2' },
];

// schema.org — built from the data above.
export const knowsAbout = [
  'distributed systems',
  'observability',
  'platform engineering',
  'software architecture',
  'site reliability engineering',
];
