import type { Page } from '@playwright/test';

// The Pro edition (PUBLIC_EDITION=pro) adds the /cover-letter/ page; the free
// build redirects it, so it's only a real route under Pro.
export const ROUTES = [
  '/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/cover-letter/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    document.documentElement.classList.toggle('dark', t === 'dark');
    document.documentElement.dataset.theme = t;
    localStorage.setItem('theme', t);
  }, theme);
}
