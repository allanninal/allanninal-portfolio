import { test, expect } from '@playwright/test';

test('all target=_blank links use rel="noopener noreferrer"', async ({ page }) => {
  await page.goto('/');
  const ext = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];
  for (const a of ext) {
    const rel = await a.getAttribute('rel');
    const href = await a.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — rel="${rel}"`);
    }
  }
  expect(unsafe, `Unsafe external links:\n${unsafe.join('\n')}`).toEqual([]);
});

test('mailto links use a valid email format', async ({ page }) => {
  await page.goto('/');
  const mailtos = await page.locator('a[href^="mailto:"]').all();
  for (const m of mailtos) {
    const href = await m.getAttribute('href');
    expect(href).toMatch(/^mailto:[^\s@]+@[^\s@]+\.[^\s@]+/);
  }
});
