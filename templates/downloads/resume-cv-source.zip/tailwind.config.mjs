/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Inter Tight Variable"', '"Inter Tight"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        serif: ['"Source Serif 4 Variable"', '"Source Serif 4"', 'Georgia', 'serif'],
        display: ['"Source Serif 4 Variable"', '"Source Serif 4"', 'Georgia', 'serif'],
      },
      fontSize: {
        'xs':  ['0.75rem',  { lineHeight: '1.5' }],
        'sm':  ['0.875rem', { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.6' }],
        'lg':  ['1.125rem', { lineHeight: '1.55' }],
        'xl':  ['1.25rem',  { lineHeight: '1.4' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.5rem',   { lineHeight: '1.05' }],
        '5xl': ['3.5rem',   { lineHeight: '1.0' }],
      },
      maxWidth: {
        '7xl': '76rem',
        cv: '60rem',  // 960px — comfortable single-column resume width on screen
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
    },
  },
};
