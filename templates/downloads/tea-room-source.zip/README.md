# Tea Room — Day 45 of 365 Free Astro Templates

A serene tea room / tea house website template. Calm hero, curated tea list by category (green / black / oolong / herbal / matcha) with origin, tasting notes, and prices, afternoon tea service sets, reservation form, hours & location, founder story, gallery, newsletter.

**Live demo:** https://templates.allanninal.dev/tea-room/

**Part of the [365 Templates](https://templates.allanninal.dev/) project.**

---

## Design

- **Palette:** Parchment/oat (#FAF8F3 / #F5F0E8) background · Celadon green (#558374) accent · Clay (#3D2B1F) text
- **Fonts:** Cardo (classical serif, headings) + Figtree (clean humanist sans, body)
- **Mood:** Serene, unhurried, elegant — visually distinct from coffee-shop (parchment+terracotta+Fraunces) and all prior food templates

## Features

- 5-category tea menu (green, black, oolong, herbal, matcha) with interactive tab filter
- 4 afternoon tea sets with pricing and includes list
- Reservation form with name, email, date, guest count, occasion, and dietary notes
- Founder story section with blockquote
- SVG gallery (6 panels)
- Hours & illustrated location map
- Newsletter signup (Buttondown embed)
- `schema.org/CafeOrCoffeeShop` + `Menu` JSON-LD
- `AnalyticsHead` component (GA + AdSense, hub-gated)
- `TemplateInfo` download bar (3-button, hub-gated)
- Lighthouse ≥ 95 on all four categories
- axe-core WCAG 2.1 AA clean
- Playwright smoke + a11y + links + template-info test suite

## Quick start

```bash
git clone https://github.com/allanninal/templates
cd templates/templates/tea-room
npm install
npm run dev
```

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PUBLIC_BASE_PATH` | `/tea-room/` | Asset base path |
| `PUBLIC_SITE_URL` | `https://templates.allanninal.dev` | Canonical URL |
| `PUBLIC_TEMPLATE_HUB_URL` | _(empty)_ | Enables TemplateInfo download bar + analytics |
| `PUBLIC_AUTHOR_DONATE_URL` | `https://ko-fi.com/allanninal` | Ko-fi donation link in footer |

## Customise

1. Edit `src/data/config.ts` — tea room name, address, hours, social links
2. Edit `src/data/teas.ts` — your tea list with categories, origins, tasting notes, prices
3. Edit `src/data/menus.ts` — afternoon tea / high tea sets
4. Replace SVG gallery placeholders with real photos in `public/`
5. Wire the reservation form to Formspree, Netlify Forms, or your own API
6. Replace Buttondown newsletter handle with your own

## License

MIT — free to use, modify, and deploy. Attribution appreciated but not required.

Built by [Allan Ninal](https://www.linkedin.com/in/allanninal/) · [Ko-fi](https://ko-fi.com/allanninal) · [landix.ninal@gmail.com](mailto:landix.ninal@gmail.com)
