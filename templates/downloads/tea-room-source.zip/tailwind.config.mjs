/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Cardo', 'Georgia', 'serif'],
        sans: ['Figtree', 'system-ui', 'sans-serif'],
      },
      colors: {
        parchment: {
          DEFAULT: '#F5F0E8',
          50: '#FAF8F3',
          100: '#F5F0E8',
          200: '#EDE4D2',
          300: '#DDD0B8',
        },
        celadon: {
          DEFAULT: '#2C5247',
          50: '#E8F3F0',
          100: '#C0DACE',
          200: '#7EBAA8',
          300: '#558374',
          400: '#3D6B5C',
          500: '#2C5247',
          600: '#1E3B32',
          700: '#142A24',
          800: '#0C1C17',
        },
        clay: {
          DEFAULT: '#3D2B1F',
          100: '#7A5A46',
          200: '#5C4232',
          300: '#3D2B1F',
          400: '#2A1D14',
        },
        warm: {
          50: '#FAF8F3',
          100: '#F5F0E8',
          border: '#DDD0B8',
          muted: '#8A7566',
        },
      },
    },
  },
  plugins: [],
};
