import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Willow|Tea Room/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero section is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero')).toBeVisible();
});

test('featured teas section has articles', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#featured article');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('teas section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#teas')).toBeVisible();
});

test('tea category tabs are present', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('.tea-tab');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('afternoon-tea section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#afternoon-tea')).toBeVisible();
});

test('afternoon tea sets are listed', async ({ page }) => {
  await page.goto('/');
  const sets = page.locator('#afternoon-tea article');
  const count = await sets.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('reservations section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#reservations')).toBeVisible();
});

test('reservation form has email input', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#res-email')).toBeVisible();
});

test('newsletter section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#newsletter')).toBeVisible();
});

test('newsletter form has email input', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#newsletter-email')).toBeVisible();
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav');
  await expect(nav).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel =
    process.env.PUBLIC_EDITION === 'pro'
      ? 'Pro edition — live preview'
      : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('tea category tab switching works', async ({ page }) => {
  await page.goto('/');
  // Click the Black tab
  const blackTab = page.locator('.tea-tab[data-category="black"]');
  await blackTab.click();
  // The green panel should be hidden
  const greenPanel = page.locator('#panel-green');
  await expect(greenPanel).toBeHidden();
  // The black panel should be visible
  const blackPanel = page.locator('#panel-black');
  await expect(blackPanel).toBeVisible();
});
