import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo bar is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR)).toBeVisible();
});

test('TemplateInfo has a static-zip download button', async ({ page }) => {
  await page.goto('/');
  // Pro: single "Download free" → static zip. Free: "Download static" first.
  const btn = page.locator(`${BAR} a[download]`).first();
  await expect(btn).toBeVisible();
  const href = await btn.getAttribute('href');
  expect(href).toContain('tea-room-static.zip');
});

test('TemplateInfo source / Get-Pro affordance', async ({ page }) => {
  await page.goto('/');
  if (isPro) {
    // Pro bar swaps the source download for a locked "Get Pro static" → LinkedIn.
    const getPro = page.locator(BAR).getByText('Get Pro static');
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    return;
  }
  const btns = page.locator(`${BAR} a[download]`);
  expect(await btns.count()).toBeGreaterThanOrEqual(2);
  const href = await btns.nth(1).getAttribute('href');
  expect(href).toContain('tea-room-source.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  const allLink = page.locator(BAR).getByText('All 365');
  await expect(allLink).toBeVisible();
});

test('TemplateInfo links to LinkedIn (Build with me / Get Pro static)', async ({ page }) => {
  await page.goto('/');
  const link = page.locator(BAR).getByText(isPro ? 'Get Pro static' : 'Build with me');
  await expect(link).toBeVisible();
  const href = await link.getAttribute('href');
  expect(href).toContain('linkedin.com');
});

test('no github.com/allanninal/templates deep-links on page', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
