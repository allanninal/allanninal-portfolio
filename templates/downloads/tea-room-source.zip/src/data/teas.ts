export type Tea = {
  id: string;
  name: string;
  origin: string;
  category: 'green' | 'black' | 'oolong' | 'herbal' | 'matcha';
  tastingNotes: string[];
  description: string;
  pricePerCup: string;
  pricePerPot: string;
  steepTime: string;
  temperature: string;
  featured?: boolean;
};

export const TEAS: Tea[] = [
  // Green
  {
    id: 'dragon-well',
    name: 'Dragon Well (Longjing)',
    origin: 'Hangzhou, China',
    category: 'green',
    tastingNotes: ['Fresh grass', 'Toasted chestnut', 'Honey'],
    description:
      'One of China\'s most revered green teas, hand-pressed in a wok to produce flat, jade-green leaves with a gentle, sustained sweetness.',
    pricePerCup: '£4.20',
    pricePerPot: '£7.50',
    steepTime: '2 min',
    temperature: '75°C',
    featured: true,
  },
  {
    id: 'gyokuro',
    name: 'Gyokuro',
    origin: 'Uji, Japan',
    category: 'green',
    tastingNotes: ['Marine umami', 'Sweet seaweed', 'Cream'],
    description:
      'Shade-grown for three weeks before harvest, gyokuro develops an extraordinary depth of umami rarely found in any other tea.',
    pricePerCup: '£5.50',
    pricePerPot: '£9.80',
    steepTime: '2 min',
    temperature: '60°C',
  },
  {
    id: 'bi-luo-chun',
    name: 'Bi Luo Chun',
    origin: 'Jiangsu, China',
    category: 'green',
    tastingNotes: ['Floral', 'Fruity', 'Delicate vegetal'],
    description:
      'Tightly spiral-rolled tender buds harvested in early spring beside fruit orchards — the proximity lends a subtle stone-fruit perfume.',
    pricePerCup: '£4.50',
    pricePerPot: '£8.00',
    steepTime: '1.5 min',
    temperature: '70°C',
  },
  // Black
  {
    id: 'darjeeling-first-flush',
    name: 'Darjeeling First Flush',
    origin: 'Darjeeling, India',
    category: 'black',
    tastingNotes: ['Muscatel grape', 'Spring flowers', 'Light astringency'],
    description:
      'The champagne of teas — harvested in March from steep mountain gardens, producing a pale amber cup of extraordinary delicacy.',
    pricePerCup: '£4.80',
    pricePerPot: '£8.50',
    steepTime: '3 min',
    temperature: '90°C',
    featured: true,
  },
  {
    id: 'yunnan-gold',
    name: 'Yunnan Gold',
    origin: 'Yunnan, China',
    category: 'black',
    tastingNotes: ['Chocolate', 'Pepper', 'Malt'],
    description:
      'Made exclusively from golden-tipped buds of ancient Yunnan trees, this tea produces a rich, warming cup without any bitterness.',
    pricePerCup: '£5.00',
    pricePerPot: '£8.80',
    steepTime: '3 min',
    temperature: '95°C',
  },
  {
    id: 'earl-grey-classic',
    name: 'Earl Grey Classic',
    origin: 'Blend (Assam base)',
    category: 'black',
    tastingNotes: ['Bergamot citrus', 'Brisk malt', 'Floral finish'],
    description:
      'Our house Earl Grey uses a full-bodied Assam base balanced with true bergamot oil from Calabria — bright, aromatic, and wonderfully familiar.',
    pricePerCup: '£3.80',
    pricePerPot: '£6.80',
    steepTime: '4 min',
    temperature: '95°C',
  },
  // Oolong
  {
    id: 'tie-guan-yin',
    name: 'Tie Guan Yin',
    origin: 'Anxi, China',
    category: 'oolong',
    tastingNotes: ['Orchid', 'Toasted butter', 'Honey'],
    description:
      'Iron Goddess of Mercy — a lightly oxidised oolong with famously complex floral top notes and a long, sweet aftertaste.',
    pricePerCup: '£4.60',
    pricePerPot: '£8.20',
    steepTime: '3 min',
    temperature: '85°C',
    featured: true,
  },
  {
    id: 'dong-ding',
    name: 'Dong Ding',
    origin: 'Nantou County, Taiwan',
    category: 'oolong',
    tastingNotes: ['Roasted caramel', 'Stone fruit', 'Warm oak'],
    description:
      'A medium-roast oolong from the Frozen Summit mountain. The slow charcoal-roasting develops caramel richness while preserving a fruity core.',
    pricePerCup: '£4.80',
    pricePerPot: '£8.50',
    steepTime: '3 min',
    temperature: '90°C',
  },
  // Herbal
  {
    id: 'chamomile-honey',
    name: 'Chamomile & Honey Bush',
    origin: 'Egypt / South Africa',
    category: 'herbal',
    tastingNotes: ['Apple blossom', 'Honey', 'Warm vanilla'],
    description:
      'A twilight blend — whole chamomile flowers with naturally sweet honey bush from the Cape. Caffeine-free and deeply calming.',
    pricePerCup: '£3.50',
    pricePerPot: '£6.20',
    steepTime: '5 min',
    temperature: '100°C',
  },
  {
    id: 'peppermint-garden',
    name: 'Garden Peppermint',
    origin: 'Norfolk, England',
    category: 'herbal',
    tastingNotes: ['Crisp mint', 'Cool finish', 'Clean'],
    description:
      'Single-origin British peppermint grown in the Norfolk fens. Vibrantly fresh, intensely minty, and restorative at any hour.',
    pricePerCup: '£3.20',
    pricePerPot: '£5.80',
    steepTime: '5 min',
    temperature: '100°C',
  },
  {
    id: 'hibiscus-rose',
    name: 'Hibiscus & Rose',
    origin: 'Blend (Egypt / Bulgaria)',
    category: 'herbal',
    tastingNotes: ['Tart cherry', 'Rose petal', 'Summer berries'],
    description:
      'A ruby-red cup of dried hibiscus flowers and whole Damask rose petals. Vibrant and tart, beautiful served iced in summer.',
    pricePerCup: '£3.50',
    pricePerPot: '£6.20',
    steepTime: '5 min',
    temperature: '100°C',
  },
  // Matcha
  {
    id: 'ceremonial-matcha',
    name: 'Ceremonial Matcha',
    origin: 'Uji, Japan',
    category: 'matcha',
    tastingNotes: ['Umami', 'Creamy', 'Fresh spring greens'],
    description:
      'Stone-ground from the youngest shaded leaves, our ceremonial grade matcha is whisked to order — intensely green, silky, and profoundly alive.',
    pricePerCup: '£5.80',
    pricePerPot: '—',
    steepTime: 'Whisked',
    temperature: '70°C',
    featured: true,
  },
  {
    id: 'matcha-latte',
    name: 'Willow Matcha Latte',
    origin: 'Uji, Japan',
    category: 'matcha',
    tastingNotes: ['Creamy', 'Subtly sweet', 'Earthy green'],
    description:
      'Ceremonial matcha whisked with a splash of hot water, then finished with your choice of oat, almond, or whole milk, lightly steamed.',
    pricePerCup: '£5.20',
    pricePerPot: '—',
    steepTime: 'Whisked',
    temperature: '65°C',
  },
];

export const CATEGORIES = [
  { key: 'green',  label: 'Green',  subtitle: 'Delicate & vegetal' },
  { key: 'black',  label: 'Black',  subtitle: 'Robust & warming' },
  { key: 'oolong', label: 'Oolong', subtitle: 'Complex & layered' },
  { key: 'herbal', label: 'Herbal', subtitle: 'Caffeine-free & soothing' },
  { key: 'matcha', label: 'Matcha', subtitle: 'Stone-ground & vivid' },
] as const;
