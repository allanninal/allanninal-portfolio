export const site = {
  title: 'The Willow & Leaf Tea Room — Afternoon Tea & Rare Teas',
  description:
    'A serene tea room in Edinburgh offering curated teas from around the world — green, black, oolong, herbal & matcha — with afternoon tea service, high tea sets, and reservation-only evenings.',
  ogImage: '/og-image.png',
  language: 'en',
};

export const maker = {
  name: 'Allan Ninal',
  role: 'Full-Stack Developer & Template Maker',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  kofi: 'https://ko-fi.com/allanninal',
  email: 'landix.ninal@gmail.com',
};

export const tearoom = {
  name: 'Willow & Leaf',
  fullName: 'The Willow & Leaf Tea Room',
  tagline: 'A quiet place. A perfect cup.',
  address: '14 Victoria Terrace, Edinburgh, EH1 2JL',
  phone: '+44 131 220 4501',
  email: 'hello@willowandleaf.co.uk',
  reservationUrl: '#reservations',
  hours: [
    { day: 'Tuesday – Friday', time: '10:00 – 17:30' },
    { day: 'Saturday',         time: '09:30 – 18:00' },
    { day: 'Sunday',           time: '10:30 – 16:30' },
    { day: 'Monday',           time: 'Closed' },
  ],
  social: {
    instagram: 'https://instagram.com',
    facebook:  'https://facebook.com',
  },
};
