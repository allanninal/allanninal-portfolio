export type AfternoonTeaSet = {
  id: string;
  name: string;
  subtitle: string;
  price: string;
  priceNote: string;
  includes: string[];
  description: string;
  badge?: string;
};

export const AFTERNOON_TEA_SETS: AfternoonTeaSet[] = [
  {
    id: 'classic',
    name: 'Classic Afternoon Tea',
    subtitle: 'The timeless ritual',
    price: '£28',
    priceNote: 'per person',
    badge: 'Most Loved',
    includes: [
      'Finger sandwiches (smoked salmon, cucumber & cream cheese, egg & cress)',
      'Freshly baked plain & raisin scones with clotted cream & house-made jam',
      'Seasonal pastries & miniature cakes (chef\'s selection)',
      'One pot of tea from our full list, with free top-up',
    ],
    description:
      'Our flagship experience — an unhurried hour or more with the classic three-tier stand, served with quiet elegance at your own pace.',
  },
  {
    id: 'royal',
    name: 'Royal High Tea',
    subtitle: 'Elevated with champagne',
    price: '£48',
    priceNote: 'per person',
    badge: 'Celebration',
    includes: [
      'Everything in Classic Afternoon Tea',
      'Glass of Laurent-Perrier Rosé Champagne on arrival',
      'Smoked salmon & crème fraîche blinis',
      'Extended pastry selection (6 pieces per person)',
      'Commemorative Willow & Leaf card',
    ],
    description:
      'Perfect for celebrations, birthdays, or simply an occasion that deserves something extra. Pre-booking essential, 48-hour notice required.',
  },
  {
    id: 'childrens',
    name: "Children's Tea",
    subtitle: 'For little guests (under 12)',
    price: '£14',
    priceNote: 'per child',
    includes: [
      'Mini sandwiches (cheese, jam, or honey)',
      'Warm scone with strawberry jam & butter',
      'Selection of colourful petit fours',
      'Fruit tisane or warm apple & cinnamon drink',
    ],
    description:
      'A gentle introduction to the tea room tradition. Children are warmly welcomed when accompanied by adults.',
  },
  {
    id: 'vegan',
    name: 'Garden Afternoon Tea',
    subtitle: 'Fully plant-based',
    price: '£30',
    priceNote: 'per person',
    includes: [
      'Plant-based finger sandwiches (avocado & tomato, hummus & roasted pepper, cucumber & herb cream)',
      'Oat-milk scones with coconut cream & berry compote',
      'Seasonal vegan cakes & pastries',
      'One pot of tea (all herbal & green teas are naturally vegan)',
    ],
    description:
      'Everything you love about afternoon tea, thoughtfully crafted without any animal products. Please mention when booking.',
  },
];
