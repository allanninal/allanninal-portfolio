import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Sunday & Always/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu has at least 4 tab buttons', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('.menu-tab-btn');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  // Click "Savory" tab
  await page.locator('.menu-tab-btn[data-tab="savory"]').click();
  await expect(page.locator('.menu-panel[data-panel="savory"]')).not.toHaveClass(/hidden/);
  await expect(page.locator('.menu-panel[data-panel="sweet"]')).toHaveClass(/hidden/);
});

test('specials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#specials')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('hours section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('waitlist section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#waitlist')).toBeVisible();
});

test('waitlist form has required fields', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#waitlist-first')).toBeVisible();
  await expect(page.locator('#waitlist-party')).toBeVisible();
  await expect(page.locator('#waitlist-phone')).toBeVisible();
});

test('navigation links exist in header', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav');
  await expect(nav).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('restaurant has phone number in footer', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer');
  await expect(footer).toBeVisible();
  const phoneLink = footer.locator('a[href^="tel:"]');
  await expect(phoneLink).toBeVisible();
});

test('header has reserve CTA', async ({ page }) => {
  await page.goto('/');
  const header = page.locator('header');
  // There are two matching elements: desktop CTA and mobile menu CTA
  const cta = header.locator('a[href="#reservations"]').first();
  await expect(cta).toBeVisible();
});
