export const cafe = {
  name: 'Sunday & Always',
  tagline: 'Brunch, done right.',
  description: 'An all-day brunch spot in Brooklyn, NY. Fresh-pressed juices, bottomless mimosas, house-made pastries, and a menu that turns weekend mornings into something worth getting out of bed for.',
  address: '182 Havemeyer St, Brooklyn, NY 11211',
  phone: '(718) 555-0192',
  email: 'hello@sundayalways.com',
  url: 'https://example.com/',
  instagram: '#',
  reservationUrl: '#reservations',
  waitlistUrl: '#waitlist',
  priceRange: '$$',
  cuisine: ['American', 'Brunch', 'All-Day Breakfast'],
  openingHours: [
    { days: 'Saturday & Sunday', hours: '9:00 AM – 4:00 PM' },
    { days: 'Monday – Friday',   hours: '10:00 AM – 3:00 PM' },
  ],
  coords: { lat: 40.7146, lng: -73.9579 },
};

export const founder = {
  name: 'Priya Nair',
  role: 'Chef & Co-founder',
  bio: 'Priya spent eight years cooking in Manhattan hotel kitchens before moving to Brooklyn to open the neighborhood brunch spot she always wished existed — unhurried, abundant, and genuinely delicious.',
  linkedin: '#',
  email: 'hello@sundayalways.com',
};

export const site = {
  title: 'Sunday & Always — Brunch Spot in Brooklyn, NY',
  description: 'All-day brunch in Williamsburg, Brooklyn. Weekend brunch menu, bottomless mimosas, house-made pastries, and daily specials from 9 AM. No-reservation walk-in or join the waitlist.',
  ogImage: '/og-image.png',
  language: 'en',
};

export type MenuTag = 'VG' | 'GF' | 'DF' | 'NF' | 'NEW';

export type MenuItem = {
  name: string;
  description: string;
  price: number;
  tags: MenuTag[];
};

export type MenuSection = {
  id: string;
  label: string;
  emoji: string;
  items: MenuItem[];
};

export const menu: MenuSection[] = [
  {
    id: 'sweet',
    label: 'Sweet',
    emoji: '🥞',
    items: [
      {
        name: 'Lemon Ricotta Pancakes',
        description: 'Three fluffy ricotta pancakes, lemon curd, fresh blueberries, whipped cream',
        price: 18,
        tags: ['VG'],
      },
      {
        name: 'French Toast Royale',
        description: 'Brioche soaked in vanilla custard, caramelized banana, candied pecans, maple syrup',
        price: 17,
        tags: ['VG'],
      },
      {
        name: 'Açaí Granola Bowl',
        description: 'Blended açaí, house granola, seasonal fruit, coconut flakes, honey drizzle',
        price: 16,
        tags: ['VG', 'GF', 'DF'],
      },
      {
        name: 'Dutch Baby Pancake',
        description: 'Oven-puffed skillet pancake, powdered sugar, seasonal jam, crème fraîche',
        price: 15,
        tags: ['VG', 'NEW'],
      },
    ],
  },
  {
    id: 'savory',
    label: 'Savory',
    emoji: '🍳',
    items: [
      {
        name: 'Eggs Benedict',
        description: 'Two poached eggs, Canadian bacon, English muffin, classic hollandaise',
        price: 20,
        tags: [],
      },
      {
        name: 'Shakshuka',
        description: 'Eggs poached in spiced tomato-pepper sauce, crumbled feta, warm pita',
        price: 19,
        tags: ['VG', 'GF'],
      },
      {
        name: 'Smoked Salmon Bagel',
        description: 'House-cured salmon, whipped cream cheese, capers, pickled red onion, everything bagel',
        price: 22,
        tags: ['DF'],
      },
      {
        name: 'Avocado Toast Deluxe',
        description: 'Sourdough, smashed avocado, soft-boiled egg, everything seasoning, chili flakes, microgreens',
        price: 18,
        tags: ['VG', 'DF'],
      },
      {
        name: 'Sunday Skillet',
        description: 'House potatoes, scrambled eggs, roasted peppers, cheddar, fresh herbs, hot sauce',
        price: 21,
        tags: ['GF'],
      },
    ],
  },
  {
    id: 'sides',
    label: 'Sides',
    emoji: '🥑',
    items: [
      {
        name: 'House Potatoes',
        description: 'Crispy smashed potatoes, rosemary, garlic aioli',
        price: 7,
        tags: ['VG', 'GF', 'DF'],
      },
      {
        name: 'Seasonal Fruit Bowl',
        description: "Chef's selection of fresh-cut seasonal fruit",
        price: 8,
        tags: ['VG', 'GF', 'DF', 'NF'],
      },
      {
        name: 'Bacon or Sausage',
        description: 'Thick-cut applewood bacon or chicken-apple sausage (2 pieces)',
        price: 6,
        tags: ['GF'],
      },
      {
        name: 'Pastry Basket',
        description: 'House-made croissant, morning bun, and seasonal scone',
        price: 11,
        tags: ['VG'],
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Drinks',
    emoji: '🍹',
    items: [
      {
        name: 'Bottomless Mimosas',
        description: 'Classic OJ or grapefruit, rotating seasonal juice, 90-minute service',
        price: 25,
        tags: [],
      },
      {
        name: 'Bloody Mary',
        description: 'House mix, horseradish, celery salt, garnish bar — classic or spicy',
        price: 14,
        tags: ['GF', 'DF'],
      },
      {
        name: 'Aperol Spritz',
        description: 'Aperol, prosecco, splash of soda, orange slice',
        price: 13,
        tags: ['GF', 'DF', 'VG'],
      },
      {
        name: 'Cold-Pressed Juice',
        description: "Chef's seasonal blend — ask your server for today's selection",
        price: 9,
        tags: ['VG', 'GF', 'DF', 'NF'],
      },
      {
        name: 'Specialty Coffee',
        description: 'Single-origin pour-over, flat white, or iced latte — beans from Toby\'s Estate',
        price: 7,
        tags: ['VG', 'GF'],
      },
    ],
  },
];

export const specials = {
  headline: 'Bottomless Mimosas',
  subhead: '$25 · 90 minutes · Weekends only',
  description: 'Choose from classic orange, pink grapefruit, or our rotating seasonal juice. Refills come to you — no trips to the bar, no awkward waits. Just good company and great bubbles.',
  note: 'Available Saturday & Sunday, 9 AM – 2 PM. One order per person. Must be 21+ with valid ID.',
};

export const galleryImages = [
  { alt: 'Lemon ricotta pancakes with blueberries on a bright ceramic plate', bg: '#FEF3C7', src: 'pancakes' },
  { alt: 'Smoked salmon bagel platter with capers and dill', bg: '#E0F4FF', src: 'bagel' },
  { alt: 'Bottomless mimosas arriving at a sunny window table', bg: '#FEE6DC', src: 'mimosas' },
  { alt: 'Sunday brunch crowd on the Havemeyer Street patio', bg: '#FEF3C7', src: 'patio' },
  { alt: 'House-made pastry basket: croissant, morning bun, and scone', bg: '#FFFEF9', src: 'pastry' },
  { alt: 'Shakshuka with crumbled feta in a cast-iron skillet', bg: '#E0F4FF', src: 'shakshuka' },
];
