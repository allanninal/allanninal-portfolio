/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Gabarito Variable"', 'Gabarito', 'system-ui', 'sans-serif'],
        sans: ['Poppins', 'system-ui', 'sans-serif'],
      },
      colors: {
        sunny: {
          DEFAULT: '#F9C621',
          light: '#FEF3C7',
          dark:  '#92680A',
          text:  '#7A5308',
        },
        coral: {
          DEFAULT: '#E8602C',
          light: '#FEE6DC',
          dark:  '#B83E12',
          text:  '#9A300A',
        },
        sky: {
          DEFAULT: '#4DA6D8',
          light: '#E0F4FF',
          dark:  '#1E6FA4',
          text:  '#145A8A',
        },
        cream: {
          DEFAULT: '#FFFDF7',
          100:   '#FFF9ED',
          200:   '#FFF2D4',
        },
        ink: {
          DEFAULT: '#1A1208',
          muted:   '#5C4B2A',
          faint:   '#9B8A6A',
        },
      },
    },
  },
  plugins: [],
};
