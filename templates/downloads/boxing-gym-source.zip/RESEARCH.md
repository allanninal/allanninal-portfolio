# Day 62 — Boxing Gym: Niche Research

## Slug
`boxing-gym`

## Differentiation from Days 1–61

### Why boxing gym is distinct from Days 60 and 61

**Day 60 (fitness-gym-general):** General commercial gym with HIIT/Spin/Strength/Yoga/Boxing class mix. Palette: Carbon Black #111214 + Electric Orange #EF4900 (neutral-cool dark). Fonts: Russo One (wide, rounded, blocky) + Exo 2 (geometric technical). Persona: Iron Peak Fitness, Austin TX.

**Day 61 (crossfit-gym):** CrossFit "box" with WOD board as hero element. Palette: Steel Night #0E1520 (cold blue-dark) + Volt Yellow #C8F000 (neon yellow-green). Fonts: Anton (ultra-condensed) + Saira (tight technical). Persona: CrossFit Ironclad, Denver CO.

**Day 62 (boxing-gym):** Dedicated boxing gym — a fundamentally different niche:
- Not a general gym or CrossFit box — a BOXING GYM with deep combat-sports heritage
- Class types are boxing-specific: fundamentals, kickboxing, sparring, conditioning, youth
- "Intro session" not "On-Ramp" — different language, different culture
- Fighters/coaches roster with competitive credentials (Golden Gloves, pro records, national titles)
- Youth boxing program (ages 8–17) — not present in gym templates
- Philadelphia heritage (boxing capital of the East Coast)

### Visual register — palette taken matrix

| Day | Palette | Fonts |
|-----|---------|-------|
| 1 | Amber #FFB020 on near-black | Inter + Geist Mono |
| 2 | Violet/indigo on light | Geist/Satoshi + Inter |
| 3 | Lime #A3E635 on dark | Geist |
| 4 | Coral #FF6B4A on light | DM Sans |
| 5 | Forest green on warm-white | Newsreader + Inter |
| 6 | Cobalt #2563EB on light | IBM Plex |
| 7 | Magenta on warm off-white | Manrope |
| 8 | Burnt orange on warm off-white | Fraunces + Space Grotesk |
| 9 | Deep teal/jade on parchment | custom |
| 10 | Teal #14B8A6 on dark | Outfit + Geist Mono |
| 11 | Oxblood #881337 on cream | Lora + Work Sans |
| 12 | Aubergine on warm white | Fraunces + Space Grotesk |
| 13 | Midnight-navy + Amber #E8A020 | Bricolage Grotesque |
| 36 | Near-black + oxblood + brass | DM Serif Display + Karla |
| 42 | Slate-charcoal + copper-amber | Oswald + Work Sans |
| 43 | Deep velvet + burgundy + gold | Cinzel + Montserrat |
| 44 | Noir-black + emerald-neon | Bodoni Moda + IBM Plex Mono |
| 51 | Near-black + oxblood + brass | Teko + Hind |
| 55 | Ink-black + bone-white + amber | Bebas Neue + Barlow |
| 57 | Deep-plum + champagne-gold | Cormorant Garamond + Nunito Sans |
| 58 | Espresso-dark + dusty-rose | Playfair Display + DM Sans |
| 59 | Crisp white + herb-green + honey | Josefin Sans + Bitter |
| 60 | **Carbon Black #111214 + Electric Orange #EF4900** | **Russo One + Exo 2** |
| 61 | **Steel Night #0E1520 + Volt Yellow #C8F000** | **Anton + Saira** |

### Day 62 distinct visual register

**Palette: Ring Mat Black + Championship Red + Champion Gold (warm dark)**

- **Base:** Ring Mat Black `#1C1108` — very warm near-black (slight leather/amber undertone). Distinct from:
  - Day 60 Carbon Black `#111214` (neutral/cool)
  - Day 61 Steel Night `#0E1520` (cold blue undertone)
  - Day 44 Noir-black (neutral black)
  - Day 55 Ink-black (cooler)
  This is a WARM dark — like an old boxing gym's wooden floor, leather, canvas.

- **Accent:** Championship Red `#EF4444` — vivid true red. Distinct from:
  - Day 8 Burnt orange `#C2410C` (brown-orange, not red)
  - Day 11 Oxblood `#881337` (dark purple-red, not vivid)
  - Day 60 Electric Orange `#EF4900` (orange, not red)
  - Day 4 Coral `#FF6B4A` (warm pink-orange)
  `#EF4444` is a clean vivid blue-red — the actual boxing ring red, corner banner red, championship belt red.

- **Secondary:** Champion Gold `#C09030` — darker, more aged than champagne/brass tones. Distinct from:
  - Day 13 Amber `#E8A020` (lighter, more orange)
  - Day 42 Copper-amber (warmer/brighter)
  - Day 43 Gold (paired with deep velvet — different register)
  - Day 48 Champagne-gold (lighter, cooler)
  `#C09030` is the "championship belt gold" — aged, authoritative, earned.

**Typography: Black Ops One + Rubik**

- **Black Ops One** (Google Fonts, single weight 400): Military stencil combat display font. NOT used in any of days 1–61. Distinct from:
  - Anton (condensed, thin strokes) — Day 61
  - Russo One (wide, rounded, blocky) — Day 60
  - Bebas Neue (condensed, elegant) — Day 55
  - Teko (compressed, modern) — Day 51
  - Oswald (condensed, clean) — Day 42
  Black Ops One has a stencil/stamp quality — heavy serifs on a sans-serif base — used in military/combat sports branding. Perfect for a boxing gym.

- **Rubik** (Google Fonts, variable 300–700): Rounded geometric sans. NOT used in any of days 1–61. Distinct from:
  - Exo 2 (technical, angular) — Day 60
  - Saira (condensed, grid-based) — Day 61
  - Barlow (condensed, athletic) — Day 55
  Rubik's slight rounding on terminals gives it a welcoming approachability that balances Black Ops One's severity — important for a gym that welcomes absolute beginners.

**WCAG AA contrast verification:**
- `#F5EFE0` (Bone White) on `#1C1108`: ~15.7:1 — AAA ✓ (all text)
- `#EF4444` (Championship Red) on `#1C1108`: ~4.76:1 — AA ✓ (all text sizes)
- `#C09030` (Champion Gold) on `#1C1108`: ~6.51:1 — AAA ✓ (eyebrows, labels)
- `#9B8B75` (muted text) on `#1C1108`: ~5.53:1 — AA ✓
- `#1C1108` (dark text) on `#EF4444` (buttons): ~4.76:1 — AA ✓
- `#9B8B75` on `#2A1D0E` (surface): ~4.68:1 — AA ✓
- `#C09030` on `#2A1D0E` (surface): ~5.50:1 — AA ✓

Note: `#EF4444` on surface `#2A1D0E` is 4.03:1 — sufficient only for large/bold text. Used only as borders, icon fills, large heading accents, and button backgrounds on surface cards.

## Persona

**Corner Club Boxing** — Professional Boxing Gym
- Location: 1842 E Passyunk Ave, Philadelphia, PA 19148 (South Philly / Italian Market)
- Head Coach & Co-Founder: **Coach Marco Reyes** — USA Boxing Coach, NSCA-CSCS, Pennsylvania State Golden Gloves amateur champion, 12 years coaching
- Founded: 2012
- Tagline: "Step Into The Ring."
- Tone: gritty, authentic, welcoming to beginners, respectful of boxing heritage

### Coaches (4)
1. **Coach Marco Reyes** — Head Coach & Co-Founder. USA Boxing Coach, NSCA-CSCS. Former PA Golden Gloves champion. 12 years coaching. Teaches fundamentals, footwork, fight-IQ.
2. **Coach Dominique Osei** — Technique & Footwork Specialist. Pro record 8-2, WBC Youth Champion 2014. Teaches punch mechanics, ring generalship, defensive craft.
3. **Coach Sarah Vega** — Women's Boxing & Kickboxing. 2× National Amateur Champion, USA Boxing Coach, ACE-CPT. Leads beginner programs and youth classes.
4. **Coach Danny Cho** — Conditioning & Strength Coach. NSCA-CSCS, USAW Club Coach, Former D1 athlete. Programs bag work, jump rope, strength circuits.

## Sections

1. **Header** — sticky, gym name "CORNER CLUB BOXING", nav (Classes / Schedule / Coaches / Intro Session / Membership / FAQ), "Free Intro" + "Join Now" CTAs
2. **Hero** — warm dark, large headline "STEP INTO THE RING." + dual CTAs (Book Free Intro / View Classes), ring-rope decorative SVG elements
3. **Stats band** — Championship Red band: 200+ Members · 12+ Years · 4 Expert Coaches · 5 Class Types
4. **Classes** — 5 class type cards: Boxing Fundamentals, Kickboxing, Sparring, Fighter Conditioning, Youth Boxing (ages 8-17)
5. **Class Schedule** — filterable weekly table (All / Fundamentals / Kickboxing / Sparring / Conditioning / Youth), Mon–Sun
6. **Coaches** — 4 coach cards with initials avatar, role, credentials, specialty description
7. **Intro Session** — "Your First Session Is Free" — 30-min intro, 4-step breakdown (Meet Coach / Stance & Guard / First Combinations / Your Next Step)
8. **Membership** — 3 tiers: Pay-Per-Class $25 / Monthly Unlimited $109 / Annual Champion $999
9. **Testimonials** — 5 member stories (weight loss, youth boxing parent, training quality, community, conditioning)
10. **About** — Gym story (2012 South Philly origin) + 3 values: Technique First · Small Classes · Respect in the Gym
11. **FAQ** — 8 questions covering experience, gear, sparring safety, intro session, weight loss, women's classes, youth ages, cancellation
12. **Contact** — Hours (M-F 6am-9pm, Sat 8am-2pm, Sun 9am-12pm), phone, email, address, inquiry form with topic selector
13. **CTA Band** — Championship Red background, dark text, "Your First Session Is Free"
14. **Footer** — 4-column grid

## Schema.org Types
- `HealthClub` + `LocalBusiness` + `SportsActivityLocation`
- `Person` (head coach)
- `Offer` × 3 membership tiers
- `FAQPage` + `Question` + `Answer`
- `Service` (Boxing Training programs)

## Key differentiators from all prior templates

- **vs. fitness-gym-general (day 60):** Boxing-specific niche not general gym; class types boxing/kickboxing/sparring not HIIT/Spin/Yoga; warm dark palette not neutral-cool; Black Ops One not Russo One; Philadelphia not Austin; youth program; intro session not day-pass
- **vs. crossfit-gym (day 61):** Boxing gym not CrossFit box; no WOD board; no On-Ramp/foundations structure; competitive boxing pedigree (pro records, Golden Gloves) not CrossFit certifications; warm dark not cold blue-dark; Championship Red not Volt Yellow; Black Ops One not Anton; Rubik not Saira; Philadelphia not Denver
- **vs. barbershop (day 51):** Fitness not grooming; dark not oxblood-brass; athletic not heritage barber
