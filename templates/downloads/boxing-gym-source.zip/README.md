# Boxing Gym — Day 62 of 365

A professional boxing gym website template built with Astro and Tailwind CSS.

**Live demo:** https://templates.allanninal.dev/boxing-gym/

## Features

- Boxing, kickboxing, sparring, conditioning, and youth class sections
- Filterable weekly class schedule table
- 4 coach cards with credentials and specialties
- Free intro session section with 4-step breakdown
- 3-tier membership pricing
- 5 member/fighter testimonials
- About/story section with 3 gym values
- FAQ accordion (8 questions)
- Contact section with hours and inquiry form
- Sticky navigation with mobile hamburger menu
- Schema.org structured data (HealthClub, LocalBusiness, Person, FAQPage)
- WCAG AA accessibility (axe clean)
- Lighthouse ≥ 95 across all categories

## Design

- **Palette:** Ring Mat Black `#1C1108` + Championship Red `#EF4444` + Champion Gold `#C09030`
- **Fonts:** Black Ops One (display) + Rubik (body)
- **Mode:** Warm dark — distinct from fitness-gym-general (cool-neutral dark + orange) and crossfit-gym (cold blue-dark + volt yellow)

## Quick start

```bash
npm install
npm run dev
```

## Environment variables

Copy `.env.example` to `.env` and fill in:

| Variable | Description |
|---|---|
| `PUBLIC_SITE_URL` | Full URL for canonical tags |
| `PUBLIC_BASE_PATH` | Must end with `/` — e.g. `/boxing-gym/` |
| `PUBLIC_TEMPLATE_HUB_URL` | Set to enable download bar (leave blank to hide it) |
| `PUBLIC_EDITION` | Set to `pro` for Pro edition |
| `PUBLIC_SHOP_URL` | Override default shop URL |

## Stack

- [Astro](https://astro.build) 4.x
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [Fontsource](https://fontsource.org) (self-hosted fonts)
- Playwright + axe-core (tests)
- Lighthouse CI (performance audit)

## Part of the 365 Templates project

https://allanninal.dev
