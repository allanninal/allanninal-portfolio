import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
const BASE = process.env.PUBLIC_BASE_PATH || '/boxing-gym/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [
    tailwind({ applyBaseStyles: false }),
  ],
});
