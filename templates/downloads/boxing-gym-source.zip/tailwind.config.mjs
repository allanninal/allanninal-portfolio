/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Black Ops One"', 'Impact', 'sans-serif'],
        body:    ['"Rubik"', 'system-ui', 'sans-serif'],
      },
      colors: {
        ring: {
          50:  '#F5EFE0',
          100: '#E8D9C0',
          200: '#C4A880',
          300: '#9B8B75',
          400: '#7A6A54',
          500: '#4A3820',
          600: '#342510',
          700: '#2A1D0E',
          800: '#201508',
          900: '#1C1108',
        },
        red: {
          50:  '#FEF2F2',
          100: '#FDE8E8',
          200: '#FCA5A5',
          300: '#FC7272',
          400: '#F87171',
          500: '#EF4444',
          600: '#DC2626',
          700: '#B91C1C',
          800: '#991B1B',
          900: '#7F1D1D',
        },
        gold: {
          50:  '#FEFCE8',
          100: '#FEF9C3',
          200: '#F5D07A',
          300: '#E8B040',
          400: '#C09030',
          500: '#A07020',
          600: '#805010',
          700: '#604010',
          800: '#402808',
          900: '#201408',
        },
      },
    },
  },
  plugins: [],
};
