/**
 * Fight records and what each discipline actually demands.
 *
 * Why this file exists. A yoga studio, a pilates studio and a boxing gym had
 * measurably the same page — boxing-gym sat 0.032 from yoga-studio, which is
 * the same site with different words. The thing a boxing gym has that they do
 * not is a RECORD: coaches who competed, with a win-loss-KO line that is either
 * true or it is not. Burying that in a prose "certs" string threw away the one
 * piece of structure this niche owns.
 *
 * So the records are tabular here, and the disciplines are a definition list
 * rather than another grid of cards. See docs/TEMPLATE_DIVERGENCE.md.
 *
 * Records are fictional, like the gym. The FORMAT is the real amateur/pro
 * convention: wins-losses-draws, with knockouts noted separately.
 */

export const coachRecords = [
  {
    name: 'Marco Reyes',
    competed: 'Amateur',
    record: '48–6–1',
    ko: 21,
    division: 'Middleweight',
    honours: 'PA State Golden Gloves champion',
    years: '2004–2013',
  },
  {
    name: 'Dominique Osei',
    competed: 'Professional',
    record: '8–2–0',
    ko: 5,
    division: 'Super welterweight',
    honours: 'WBC Youth champion, 2014',
    years: '2012–2019',
  },
  {
    name: 'Sarah Vega',
    competed: 'Amateur',
    record: '31–4–0',
    ko: 9,
    division: 'Lightweight',
    honours: '2× national amateur champion',
    years: '2011–2018',
  },
  {
    name: 'Danny Cho',
    competed: 'Did not compete',
    record: '—',
    ko: 0,
    division: '—',
    honours: 'D1 track; strength & conditioning',
    years: '—',
  },
];

/**
 * The disciplines, as terms and what they ask of you. The last entry is
 * deliberate: a gym that tells everyone to spar is a gym that loses beginners
 * and gets people hurt.
 */
export const disciplines = [
  {
    term: 'Boxing fundamentals',
    demands: 'Three months before it stops feeling awkward. Stance, guard and footwork, drilled until they are boring. No contact.',
    suits: 'Everyone, including people who have never made a fist properly.',
  },
  {
    term: 'Kickboxing',
    demands: 'Hip mobility you probably do not have on day one, and the patience to build it.',
    suits: 'Anyone wanting range and conditioning without the head contact.',
  },
  {
    term: 'Fighter conditioning',
    demands: 'The hardest hour here, and no technique instruction. Bag work, rope, circuits.',
    suits: 'People who can already box, or who only want the engine.',
  },
  {
    term: 'Youth boxing, 8–17',
    demands: 'A parent who understands this is discipline first and competition a distant second.',
    suits: 'Kids. Contact is introduced slowly and only with consent.',
  },
  {
    term: 'Sparring',
    demands: 'Six months of fundamentals, a coach\'s sign-off, and your own headgear. We will turn you away without all three.',
    suits: 'Not most members, and that is the correct number.',
  },
];
