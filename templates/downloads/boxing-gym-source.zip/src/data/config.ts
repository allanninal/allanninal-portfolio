export const gym = {
  name:        'Corner Club Boxing',
  tagline:     'Step Into The Ring.',
  description: 'Professional boxing gym in Philadelphia — boxing, kickboxing, sparring, conditioning, and youth classes for all levels. Step into the ring today.',
  phone:       '(215) 555-0147',
  email:       'hello@cornerclubboxing.com',
  address:     '1842 E Passyunk Ave',
  city:        'Philadelphia',
  state:       'PA',
  zip:         '19148',
  instagram:   'https://instagram.com/cornerclubboxing',
  facebook:    'https://facebook.com/cornerclubboxing',
  youtube:     'https://youtube.com/@cornerclubboxing',
  bookUrl:     'https://app.cornerclubboxing.com/book',
  joinUrl:     'https://app.cornerclubboxing.com/join',
  headCoach: {
    name:  'Coach Marco Reyes',
    title: 'Head Coach & Co-Founder',
    certs: ['USA Boxing Coach', 'NSCA-CSCS', 'ISSA-CPT'],
  },
  makerBio: {
    name:     'Corner Club Boxing',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Corner Club Boxing | Boxing Gym in Philadelphia PA — Classes, Coaching & Membership',
  description:   'Corner Club Boxing is Philadelphia\'s premier boxing gym. Classes for all levels — boxing fundamentals, kickboxing, sparring, conditioning & youth boxing. Book your free intro session today.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
