// Yusra Benhaddou — Chicago, IL. Fictional.
//
// The organising idea: a screen is nine screens. The one in the mockup, and
// eight that decide whether the product works. Every state below is RENDERED
// on the page as live markup rather than shown as a picture of itself, which
// is the only honest way for a UI portfolio to claim it designs states.

export const site = {
  name:        'Yusra Benhaddou',
  shortName:   'Yusra Benhaddou',
  title:       'Yusra Benhaddou — UI designer, Chicago',
  tagline:     'A screen is nine screens.',
  owner:       'Yusra Benhaddou',
  ownerRole:   'UI designer',
  credential:  'Seven years · product UI and design systems',
  city:        'Chicago',
  state:       'IL',
  language:    'en',
  phoneDisplay: '(312) 555-0173',
  phoneHref:   '+13125550173',
  email:       'yusra@benhaddou.example',
  streetAddress: '2119 W Division St',
  postalCode:  '60622',
  hours:       'Replies within a day · contract or fractional',
  bookingWindow: 'Two days a week available from April',
  description:
    'Every portfolio shows the happy path: a list with six well-named items and a form with ' +
    'nothing wrong in it. That screen is about a ninth of the work. The other eight states are ' +
    'below, built as live markup rather than shown as pictures, with how often each one happens ' +
    'and what it costs when nobody draws it.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Nine states', href: '#states' },
  { label: 'The audit',   href: '#audit' },
  { label: 'Numbers',     href: '#numbers' },
  { label: 'Hire me',     href: '#contact' },
];

// ── The component ─────────────────────────────────────────────────────────
// One real component, rendered nine ways. A saved-addresses list, because it
// is boring, universal, and has every failure mode in it.

// Exactly 94 characters: the longest organisation name in the real database,
// and the value every text slot on the page was checked against. The
// too-long state renders this string and a test asserts its length, so the
// number in the prose cannot drift away from the thing on screen.
export const longestName =
  'Benhaddou-Vandermolen Facilities Management Cooperative of Greater Cook County (Northside Br.)';

export const component = {
  name: 'Saved addresses',
  where: 'Checkout, account settings, and the delivery step of three different flows',
  note:
    'One component, nine states, all of them live markup on this page. None of these is a ' +
    'screenshot. If a portfolio shows you a picture of an empty state, it has shown you that ' +
    'somebody drew an empty state, which is a different claim.',
};

// Sample rows the ideal state renders. Deliberately unglamorous.
export const addresses = [
  { label: 'Home',    line: '2119 W Division St, Chicago, IL 60622' },
  { label: 'Work',    line: '540 N Michigan Ave, Suite 1120, Chicago, IL 60611' },
  { label: 'Mum',     line: '84 Rue Ibn Batouta, Casablanca 20250' },
];

// `freq` is how often the state is reached in production, over a year of one
// real product. `cost` is what happens when it is not designed.
export const states = [
  { id: 'ideal',   k: 'Ideal',           freq: '61% of sessions',
    cost: 'It is the only one in the mockup, and it is the one nobody needs help with.' },
  { id: 'empty',   k: 'Empty',           freq: 'Every new account, once',
    cost: 'Left to the engineer it becomes a blank box. It is the first thing a new user ever sees and it is the cheapest state to get right.' },
  { id: 'loading', k: 'Loading',         freq: '100% of sessions, briefly',
    cost: 'A spinner where a skeleton belongs. The layout jumps when data lands, which reads as slower even when it is not.' },
  { id: 'error',   k: 'Error',           freq: '2.4% of loads',
    cost: 'Needs a real error string, which means asking an engineer what can actually fail. Skipping that conversation is how “Something went wrong” gets shipped.' },
  { id: 'offline', k: 'Offline',         freq: '0.9% of sessions',
    cost: 'Assumed to be the browser’s problem. The browser shows a dinosaur; your form still says Save.' },
  { id: 'denied',  k: 'No permission',   freq: '3.1% of sessions',
    cost: 'Requires knowing the permission model. Undesigned, it is usually an empty state, which tells a user their data is gone.' },
  { id: 'many',    k: 'Too much',        freq: '4% of accounts',
    cost: 'Designed with three rows, shipped to somebody with 4,000. The scroll container, the search and the count all have to exist before that happens.' },
  { id: 'long',    k: 'Too long',        freq: '11% of records',
    cost: 'A 94-character name in a slot drawn for 30. Either it truncates on purpose or it breaks the layout by accident, and one of those is a decision.' },
  { id: 'zoom',    k: 'At 200% zoom',    freq: 'WCAG 1.4.4, always',
    cost: 'A conformance requirement, not a nicety. Most component libraries fail it at the first fixed pixel height.' },
];

export const statesNote =
  'The frequencies are from one product over one year, and the point is not the exact numbers — ' +
  'it is that eight of the nine happen often enough to have a number at all. A state reached by ' +
  '2.4% of loads is reached by thousands of people a month, and it is the state they will tell ' +
  'somebody about.';

// ── The audit ─────────────────────────────────────────────────────────────
// Six shipped products against the same nine states. `d` = designed,
// `b` = browser default, `m` = missing entirely.

export const audit = [
  { p: 'Checkout, retail',        s: { ideal:'d', empty:'d', loading:'d', error:'d', offline:'b', denied:'d', many:'d', long:'d', zoom:'d' },
    n: 'The one that was resourced properly. Offline is still the browser’s, and that was a decision rather than an oversight.' },
  { p: 'Internal admin console',  s: { ideal:'d', empty:'d', loading:'d', error:'b', denied:'d', offline:'m', many:'d', long:'b', zoom:'m' },
    n: 'Internal tools get the least state work and have the most permission states. This one had eleven roles and three designed permission screens.' },
  { p: 'Booking flow, clinic',    s: { ideal:'d', empty:'d', loading:'d', error:'d', offline:'d', denied:'d', many:'b', long:'d', zoom:'d' },
    n: 'Healthcare, so zoom and error strings were audited by somebody outside the team. Too-much-data was left because a patient cannot have 4,000 appointments.' },
  { p: 'Reporting dashboard',     s: { ideal:'d', empty:'m', loading:'d', error:'b', offline:'m', denied:'b', many:'d', long:'m', zoom:'b' },
    n: 'The worst on this list and the best-looking. Every screenshot of it is full of data, which is exactly the problem the page is about.' },
  { p: 'Design system, v2',       s: { ideal:'d', empty:'d', loading:'d', error:'d', offline:'b', denied:'d', many:'d', long:'d', zoom:'d' },
    n: 'A system is where states are cheapest to fix, because you fix them once. Eight of nine designed, and the ninth is deliberate.' },
  { p: 'Marketing site CMS',      s: { ideal:'d', empty:'b', loading:'b', error:'b', offline:'m', denied:'m', many:'b', long:'m', zoom:'b' },
    n: 'Two weeks and no budget for states. I am including it because a portfolio of only the well-funded work is a portfolio of budgets.' },
];

export const auditNote =
  'Fifty-four cells. Browser default is not a failure — sometimes the browser’s behaviour is ' +
  'genuinely correct and drawing over it is worse. Missing is a failure, and there are enough of ' +
  'them here that leaving them off would have made the table decorative.';

// ── The numbers under a component ────────────────────────────────────────

export const numbers = [
  { k: 'Minimum hit target',      v: '44 × 44 px', n: 'WCAG 2.5.8 asks for 24; Apple and the actual behaviour of thumbs ask for 44. The row action here is 44 and the visible icon inside it is 20.' },
  { k: 'Type scale ratio',        v: '1.2', n: 'Minor third, six steps, 14 to 34 px. A 1.25 or 1.333 scale looks better on a specimen sheet and produces a heading that is too big three levels down.' },
  { k: 'Base line height',        v: '1.55', n: 'On body copy. WCAG 1.4.12 requires that 1.5 does not break the layout, which is a different and stricter thing than choosing 1.5.' },
  { k: 'Table collapses at',      v: '640 px', n: 'The width at which this row stops being a row and becomes a stacked block. Chosen from the longest realistic address, not from a device size.' },
  { k: 'Longest content tested',  v: '94 chars', n: 'The longest organisation name in the real database. Every text slot on the page was checked against it, which took an afternoon and found four breaks.' },
  { k: 'Focus ring',              v: '3 px, 2 px offset', n: 'Same ring everywhere, never removed, and checked at 3:1 against every background it can land on. It is the single most commonly deleted line of CSS in this trade.' },
  { k: 'Motion',                  v: '120–180 ms', n: 'Long enough to be seen, short enough not to be waited for, and all of it inside a prefers-reduced-motion query that turns it off completely.' },
  { k: 'Colours carrying meaning', v: '0', n: 'No state on this page is communicated by hue alone. Every one prints a word, and the audit cells carry a glyph as well.' },
];

// ── Handover ──────────────────────────────────────────────────────────────

export const handover = [
  { t: 'Every state, drawn',
    d: 'All nine, per component, in the same file. Not a happy-path screen with a note saying “also empty state”. The note is where the state goes to not get built.' },
  { t: 'The real strings',
    d: 'Error copy agreed with whoever knows what can fail, before handover. “Something went wrong” is what gets written when that conversation did not happen.' },
  { t: 'The longest content in the database',
    d: 'An actual query result, not filler text. Half the layout breaks in a product are one record somebody typed a full legal entity name into.' },
  { t: 'Tokens, not hex codes',
    d: 'Named to their role rather than their colour. A token called `--danger` survives a rebrand; one called `--red-600` becomes a lie the first time the red changes.' },
  { t: 'Two hours with the engineer',
    d: 'Booked before the last week. Everything above is worth less than this, and it is the first thing cut from a schedule.' },
];

export const said = {
  text: 'The handover had the empty state, the permission state and a 94-character company name already in it. I have built maybe forty of these and it is the first time I have not had to invent half of it myself on the Thursday.',
  who: 'Front-end engineer, retail checkout — 2025',
};

export const faqs = [
  {
    q: 'Why not just show the finished screens?',
    a: 'Because the finished screen is the part of the job everybody can already do. The reason a product feels unfinished is almost never the ideal state — it is the empty one that is a blank box, the error that says “Something went wrong”, and the table that breaks when somebody has four thousand rows.',
  },
  {
    q: 'Are these really rendered, or are they images?',
    a: 'Rendered. Everything in the nine-state section is live markup in this page, which you can confirm by resizing the window or by opening the inspector. A picture of an empty state proves somebody drew one; it does not prove it works.',
  },
  {
    q: 'Is “browser default” a failure?',
    a: 'No, and that is why it is its own verdict rather than being folded into Missing. Sometimes the browser’s behaviour is genuinely the right answer and drawing over it is worse — the offline page is the usual example. It is a failure when nobody decided, which is most of the time.',
  },
  {
    q: 'Do you work in Figma or in code?',
    a: 'Both, and the states are the reason. Nine states across a component set is where a design file becomes unmaintainable and where a coded prototype starts paying for itself. I hand over both and the code is the one that is correct.',
  },
  {
    q: 'What about the dashboard on this page that scores badly?',
    a: 'It is the best-looking thing I have made and it has three missing states. Leaving it off would have made the audit decorative, which is the exact failure mode of every portfolio that only shows work that went well.',
  },
  {
    q: 'Can you work with our existing design system?',
    a: 'Usually the fastest route, yes. The first thing I would do is audit it against these nine states, which takes about a day per component set and generally finds that the ideal state is beautiful and the other eight do not exist.',
  },
];
