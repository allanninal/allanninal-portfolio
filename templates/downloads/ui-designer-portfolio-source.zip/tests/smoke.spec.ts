import { test, expect } from '@playwright/test';

test.describe('Yusra Benhaddou — smoke tests', () => {
  test('homepage renders with the designer in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Yusra Benhaddou/);
    await expect(page.locator('h1')).toContainText('A screen is nine screens');
  });

  // A Person, plus a WebPage that declares its own accessibility — a real
  // schema vocabulary almost nothing uses, and the one part of this page's
  // argument a machine can read.
  test('emits a Person and an accessibility-declaring WebPage', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const person = JSON.parse(blocks.find((b) => b.includes('"Person"'))!);
    const wp = JSON.parse(blocks.find((b) => b.includes('accessibilityFeature'))!);
    expect(person['@type']).toBe('Person');
    expect(wp['@type']).toBe('WebPage');
    expect(wp.accessibilityHazard).toContain('noMotionSimulationHazard');
    expect(wp.accessibilityControl).toContain('fullKeyboardControl');
    expect(wp.accessibilityAPI).toBe('ARIA');
    // Narrow on purpose: a page claiming every feature has claimed nothing.
    expect(wp.accessibilityFeature).not.toContain('highContrastDisplay');
    expect(wp.accessibilityFeature).not.toContain('captions');
    expect(wp.accessibilityFeature.length).toBeLessThan(8);
    // Not the previous days' types.
    expect(blocks.join('')).not.toContain('ProfilePage');
    expect(blocks.join('')).not.toContain('MusicAlbum');
  });

  // ── The nine states ─────────────────────────────────────────────────────
  test('nine states are rendered as live markup, not images', async ({ page }) => {
    await page.goto('/');
    const figs = page.locator('#states figure.state');
    expect(await figs.count()).toBe(9);
    expect(await page.locator('#states img, #states picture').count()).toBe(0);
    for (const f of await figs.all()) {
      await expect(f).toBeVisible();
      expect((await f.boundingBox())!.height).toBeGreaterThan(120);
      // Real DOM inside the component well, not an image or a background.
      expect(await f.locator('.cmp *').count()).toBeGreaterThan(0);
    }
  });

  test('each state carries a frequency and the cost of skipping it', async ({ page }) => {
    await page.goto('/');
    for (const f of await page.locator('#states figure.state').all()) {
      expect(((await f.locator('.name').textContent()) || '').length).toBeGreaterThan(2);
      expect(((await f.locator('.freq').textContent()) || '').length).toBeGreaterThan(4);
      expect(((await f.locator('.cost').textContent()) || '').length).toBeGreaterThan(50);
    }
  });

  test('the states are structurally different from one another', async ({ page }) => {
    await page.goto('/');
    // The ideal state lists rows; empty, error, offline and denied are messages;
    // loading is skeletons; too-much scrolls. If they all rendered the same
    // markup the section would be nine copies of one screenshot.
    expect(await page.locator('#states .state--ideal .row').count()).toBeGreaterThan(2);
    expect(await page.locator('#states .state--empty .msg').count()).toBe(1);
    expect(await page.locator('#states .state--loading .skel').count()).toBeGreaterThan(2);
    expect(await page.locator('#states .state--many .scroller').count()).toBe(1);
    expect(await page.locator('#states .state--error .msg--error').count()).toBe(1);
    expect(await page.locator('#states .state--denied .msg--denied').count()).toBe(1);
  });

  test('the too-long state renders the exact string the page claims', async ({ page }) => {
    await page.goto('/');
    const line = (await page.locator('#states .state--long .row-line').textContent()) || '';
    const claimed = (await page.locator('#states .state--long .note').textContent()) || '';
    const n = Number((claimed.match(/(\d+)\s*characters/) || [])[1]);
    expect(n).toBeGreaterThan(80);
    // The number in the prose is the length of the thing actually on screen.
    const org = line.split(',')[0].trim();
    expect(org.length).toBe(n);
    // And the numbers table quotes the same figure.
    await expect(page.locator('#numbers')).toContainText(`${n} chars`);
  });

  test('the too-much state is a real scroll container and is reachable', async ({ page }) => {
    await page.goto('/');
    const sc = page.locator('#states .state--many .scroller');
    await expect(sc).toHaveAttribute('tabindex', '0');
    const over = await sc.evaluate((el) => el.scrollHeight > el.clientHeight);
    expect(over).toBe(true);
  });

  test('nothing on the page animates', async ({ page }) => {
    await page.goto('/');
    const moving = await page.evaluate(() => {
      let n = 0;
      document.querySelectorAll('*').forEach((el) => {
        const c = getComputedStyle(el);
        if (c.animationName !== 'none' || (c.transitionDuration !== '0s' && c.transitionProperty !== 'none')) n++;
      });
      return n;
    });
    expect(moving).toBe(0);
  });

  // ── The audit ───────────────────────────────────────────────────────────
  test('the audit covers every product against every state', async ({ page }) => {
    await page.goto('/');
    const states = await page.locator('#states figure.state').count();
    const cols = (await page.locator('#audit thead th').count()) - 1;
    const rows = await page.locator('#audit tbody tr').count();
    expect(cols).toBe(states);
    expect(await page.locator('#audit tbody .verdict').count()).toBe(cols * rows);
    const eyebrow = (await page.locator('#audit .eyebrow').textContent()) || '';
    expect(eyebrow).toContain(`${cols * rows} cells`);
  });

  test('three verdicts, each a word plus a glyph plus a colour', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#audit tbody .verdict');
    for (const el of await v.all()) {
      expect(((await el.textContent()) || '').trim()).toMatch(/^(Designed|Browser default|Missing)$/);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    const colours = await v.evaluateAll((els) => [...new Set(els.map((e) => getComputedStyle(e).color))]);
    expect(colours.length).toBe(3);
    // Browser default is explained as not-a-failure before the table uses it.
    await expect(page.locator('#audit .key')).toContainText(/only one of the three that is a failure/);
  });

  test('the missing count in the eyebrow matches the table', async ({ page }) => {
    await page.goto('/');
    const words = await page.locator('#audit tbody .verdict').allTextContents();
    const missing = words.filter((w) => /^Missing$/i.test(w.trim())).length;
    expect(missing).toBeGreaterThan(4);
    await expect(page.locator('#audit .eyebrow')).toContainText(`${missing} missing`);
  });

  // ── Numbers ─────────────────────────────────────────────────────────────
  test('the component honours the hit target the numbers table claims', async ({ page }) => {
    await page.goto('/');
    const claimed = (await page.locator('#numbers tbody tr').first().locator('td.v').textContent()) || '';
    const px = Number((claimed.match(/(\d+)/) || [])[1]);
    expect(px).toBeGreaterThanOrEqual(44);
    const acts = page.locator('#states .state--ideal .row-act');
    for (const a of await acts.all()) {
      const b = (await a.boundingBox())!;
      expect(Math.round(b.width)).toBeGreaterThanOrEqual(px);
      expect(Math.round(b.height)).toBeGreaterThanOrEqual(px);
    }
  });

  test('there is a testimonial, unlike the day before', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('blockquote').count()).toBe(1);
    await expect(page.locator('blockquote cite')).toContainText(/engineer/i);
  });

  test('the FAQ is an accordion and the contact form has two selects', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    expect(await page.locator('#contact select').count()).toBe(2);
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-121 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    // Leak tokens have to be distinctive: "not me" is a phrase this page can
    // legitimately use in prose, and an over-broad token that matches ordinary
    // English is a mistake this project has made more than once.
    for (const noun of ['devra okonkwo', 'minneapolis', 'contribution matrix', 'never measured', 'dispatch console']) {
      expect(html).not.toContain(noun);
    }
    expect(await page.locator('ol').count()).toBe(0);
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({
        sw: document.body.scrollWidth, iw: window.innerWidth,
      }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro state checklist is absent from the free build', async ({ page }) => {
    const res = await page.goto('/state-checklist/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
