import { test, expect } from '@playwright/test';

const STATES = ['Booked regularly', 'Can do, rarely cast', 'Hire somebody else'];

test.describe('Priya Nandakumar — smoke tests', () => {
  test('homepage renders with the performer name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Priya Nandakumar/);
    await expect(page.locator('h1')).toContainText('least useful sentence');
  });

  test('is a Person with an occupation and offers', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Voice actor');
    expect(json).toContain('makesOffer');
    expect(json).not.toContain('MusicComposition');
  });

  // The page spends its whole argument refusing to claim range. Emitting a
  // capability list would contradict it in the one place a machine reads.
  test('the markup claims no capability list', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('hasOccupation')) || '');
    const schema = JSON.parse(raw);
    expect(schema.knowsAbout).toBeUndefined();
    expect(schema.skills).toBeUndefined();
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#bracket table.bracket');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(350);
  });

  // ── The casting bracket ─────────────────────────────────────────────────
  test('every role type carries one of three states, with a glyph', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#bracket tbody tr');
    const n = await rows.count();
    expect(n).toBe(9);
    for (const r of await rows.all()) {
      const st = ((await r.locator('.st').textContent()) || '').trim();
      expect(STATES).toContain(st);
      expect(await r.locator('.st').getAttribute('data-glyph')).toBeTruthy();
    }
  });

  // The refusals are the argument. A page with none is claiming range again.
  test('some role types are refusals, and the counts are derived', async ({ page }) => {
    await page.goto('/');
    const states = (await page.locator('#bracket .st').allTextContents()).map((s) => s.trim());
    const yes = states.filter((s) => s === 'Booked regularly').length;
    const rare = states.filter((s) => s === 'Can do, rarely cast').length;
    const never = states.filter((s) => s === 'Hire somebody else').length;
    expect(never).toBeGreaterThan(0);
    await expect(page.locator('#bracket h2'))
      .toHaveText(`${yes} yes. ${rare} rarely. ${never} hire somebody else.`);
    const dd = page.locator('#bracket dl.tally dd');
    await expect(dd.nth(0)).toHaveText(String(yes));
    await expect(dd.nth(1)).toHaveText(String(rare));
    await expect(dd.nth(2)).toHaveText(String(never));
    await expect(page.locator('#bracket')).toContainText(/claiming range again/i);
  });

  // Refusals must never be offered as bookable options.
  test('the booking form does not offer the refused role types', async ({ page }) => {
    await page.goto('/');
    const refused: string[] = [];
    for (const r of await page.locator('#bracket tbody tr').all()) {
      const st = ((await r.locator('.st').textContent()) || '').trim();
      if (st === 'Hire somebody else') refused.push(((await r.locator('th').textContent()) || '').trim());
    }
    expect(refused.length).toBeGreaterThan(0);
    const opts = (await page.locator('#role option').allTextContents()).map((s) => s.trim());
    for (const r of refused) expect(opts).not.toContain(r);
  });

  test('the three state colours are distinct', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--cast-yes', '--cast-rare', '--cast-never'].map((k) => s.getPropertyValue(k).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  // ── Sessions ────────────────────────────────────────────────────────────
  test('every session requirement states what it costs to omit', async ({ page }) => {
    await page.goto('/');
    // The checklist became a definition list during the divergence rewrite;
    // this selector followed it rather than the page following the test.
    const items = page.locator('#sessions dl.needs > div');
    const n = await items.count();
    expect(n).toBeGreaterThan(3);
    for (const i of await items.all()) {
      await expect(i.locator('dd.cost')).toContainText(/Without it/);
    }
    await expect(page.locator('#sessions h2')).toContainText(`${n} things, all free.`);
  });

  // ── Demos, and the absence of audio ─────────────────────────────────────
  test('there is no audio, and the page distinguishes this from day 112', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('audio').count()).toBe(0);
    expect(await page.locator('img').count()).toBe(0);
    await expect(page.locator('#demos')).toContainText(/a metronome is honestly a metronome/i);
    await expect(page.locator('#faq')).toContainText(/somebody else's voice presented as hers/i);
  });

  test('the free raw read is offered ahead of the polished demo', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#demos')).toContainText(/Raw read/);
    await expect(page.locator('#demos h2')).toContainText(/free and nobody asks for it/i);
    await expect(page.locator('#rates')).toContainText(/Auditions and raw reads are free/i);
  });

  // The one template in this library whose FAQ is not an accordion: a
  // question and its answer are a term and a definition, and six short ones
  // open is less work than six closed.
  test('the FAQ is a definition list, fully readable without interaction', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#faq details').count()).toBe(0);
    const pairs = page.locator('#faq dl.qa > div');
    const n = await pairs.count();
    expect(n).toBeGreaterThan(4);
    for (const p of await pairs.all()) {
      await expect(p.locator('dt')).toBeVisible();
      await expect(p.locator('dd')).toBeVisible();
    }
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-115 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['aurelio sandoval', 'santa fe', 'catalogue', 'commission', 'premiere']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro session pack is absent from the free build', async ({ page }) => {
    const res = await page.goto('/session-pack/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
