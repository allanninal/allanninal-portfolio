// Priya Nandakumar — Tucson, AZ. Fictional.
//
// Character work: animation, games, ADR. Day 118 is the commercial/corporate
// voice-over page and the roadmap lines for the two are close enough to be a
// clone pair, so they are separated at the axis: this page is about what you
// get cast as, and 118 is about what usage costs.

export const site = {
  name:        'Priya Nandakumar',
  shortName:   'Priya Nandakumar',
  title:       'Priya Nandakumar — voice actor, Tucson',
  tagline:     '“Great range” is the least useful sentence in this industry.',
  owner:       'Priya Nandakumar',
  ownerRole:   'Voice actor · animation, games, ADR',
  credential:  'Union · home booth · since 2016',
  city:        'Tucson',
  state:       'AZ',
  language:    'en',
  phoneDisplay: '(520) 555-0158',
  phoneHref:   '+15205550158',
  email:       'priya@priyanandakumar.example',
  streetAddress: '340 N 4th Ave',
  postalCode:  '85705',
  hours:       'Booth available 8–6 Mountain · sessions patched or self-directed',
  bookingWindow: 'Next-day turnaround on self-tape · live sessions with a day’s notice',
  description:
    'A voice actor in Tucson. Casting directors are not looking for range — they are looking for ' +
    'a specific sound, fast, from a list. So this page says what I get booked for, what I can do ' +
    'and never get cast as, and the three things you should hire somebody else for.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The bracket', href: '#bracket' },
  { label: 'Sessions',    href: '#sessions' },
  { label: 'Demos',       href: '#demos' },
  { label: 'The booth',   href: '#booth' },
  { label: 'Rates',       href: '#rates' },
  { label: 'Book',        href: '#book' },
];

// ── The casting bracket ───────────────────────────────────────────────────
// Three states. The third is the point.

export const bracket = [
  { role: 'Warm adult lead',        state: 'yes',   booked: '40+', note: 'The centre of what I get hired for. Games, animation, narration-adjacent character work — the voice somebody trusts inside two lines.' },
  { role: 'Dry comic support',      state: 'yes',   booked: '25+', note: 'Timing rather than silliness. The friend who is unimpressed, the colleague who has seen this before.' },
  { role: 'Older matriarch',        state: 'yes',   booked: '12',  note: 'Placed rather than pushed. I do not do this by making the voice creaky, which is why it books.' },
  { role: 'Teen boy',               state: 'yes',   booked: '9',   note: 'A standard animation bracket and an honest fit. Not a stretch, and the sessions are shorter than people expect.' },
  { role: 'Villain, controlled',    state: 'rare',  booked: '3',   note: 'I can do it and the reads are good. I am rarely called for it, probably because nothing else on my demo suggests it.' },
  { role: 'High-energy commercial', state: 'rare',  booked: '2',   note: 'Technically within range and not what anybody hears when they hear me. If this is the job, day rate is the wrong conversation.' },
  { role: 'Creature and monster',   state: 'never', booked: '0',   note: 'Genuinely not my instrument, and it is a specialism with people who have spent a decade on it. Hire one of them.' },
  { role: 'Accents outside my own', state: 'never', booked: '0',   note: 'I will not do an accent that belongs to a community I am not from. Cast somebody who is; the performance will be better and the question will not arise.' },
  { role: 'Singing',                state: 'never', booked: '0',   note: 'I can hold a tune and that is a different job. A session that discovers this at hour two has wasted everybody’s afternoon.' },
];

export const STATE = {
  yes:   { label: 'Booked regularly', glyph: '●' },
  rare:  { label: 'Can do, rarely cast', glyph: '○' },
  never: { label: 'Hire somebody else',  glyph: '×' },
} as const;

export const bracketNote =
  'The third column is the whole point. A casting page with no "hire somebody else" row is a page ' +
  'claiming range again, in a table. Three of the nine here are things I will not take, and the ' +
  'accent row is not a limitation I am apologising for — it is a casting decision that belongs to ' +
  'somebody else and produces a better performance in their hands.';

// ── Sessions ──────────────────────────────────────────────────────────────

export const needs = [
  { what: 'A marked script',        why: 'Names, places and anything technical, with the pronunciation you want beside it. Not IPA — a rhyme is fine.',
    cost: 'Without it: roughly twenty minutes of a two-hour session, and a pickup later for the one word nobody flagged.' },
  { what: 'Someone who can answer', why: 'One named person, reachable during the session, who is allowed to make a call about a line.',
    cost: 'Without it: every ambiguity becomes three alternate reads, and somebody chooses badly from them a week later.' },
  { what: 'A reference for tone',   why: 'Thirty seconds of anything — a scene, a competitor’s spot, a performance you liked. Adjectives are the slow way.',
    cost: 'Without it: the first twenty minutes are a negotiation about what "natural" means.' },
  { what: 'The delivery spec',      why: 'Sample rate, file format, whether you want it processed, and one file or one per line.',
    cost: 'Without it: a re-export, usually on the day you needed it.' },
];

export const needsNote =
  'All four are free and none takes more than ten minutes. The reason they are on a public page ' +
  'rather than in a welcome email is that the email arrives after the booking, and three of these ' +
  'change what the booking should be.';

// ── Demos ─────────────────────────────────────────────────────────────────

export const demos = [
  { k: 'Character demo',   v: '75 sec',  n: 'Eight clips, edited and processed, from real sessions. It is the most flattering document I have and you should treat it that way.' },
  { k: 'Games demo',       v: '60 sec',  n: 'Combat, exertion and one long emotional take. The exertion is the part casting actually listens for.' },
  { k: 'Raw read',         v: 'Your copy', n: 'One unprocessed take of your own script, returned same day, free. This is the useful one and almost nobody asks for it.' },
  { k: 'Self-tape',        v: 'Next day', n: 'Slated, two takes, a director’s note if you send one. Delivered as WAV, no processing unless you ask.' },
];

export const demosNote =
  'A demo is edited, comped and processed — mine included. A raw read of your own copy tells you ' +
  'in ninety seconds what a demo cannot, it is free, and it is the thing to ask for before ' +
  'booking anybody, me or otherwise.';

export const noAudioNote =
  'There is no audio on this page. Day 112 in this library ships generated click tracks because a ' +
  'metronome is honestly a metronome; a voice cannot be generated that way. Priya Nandakumar is ' +
  'fictional, so any recording here would be somebody else’s voice presented as hers — closer to ' +
  'a stock headshot than to a click track. If you are using this template, your demos go here.';

// ── The booth, measured ───────────────────────────────────────────────────
// A voice actor who cannot state their own noise floor is telling you
// something. `value` and `limit` are in the same unit per row so the figure
// can be drawn against its threshold.

export const booth = {
  intro:
    'Every voice site says "professionally treated". These are the numbers, measured monthly with ' +
    'the same rig, and the one that matters to a client is the first: a noise floor low enough ' +
    'that a quiet read does not need denoising to sit in a mix.',
  rows: [
    { k: 'Noise floor',        value: 22, limit: 30, unit: 'dBA', better: 'lower',
      n: 'Measured over sixty seconds with the air off. Broadcast work generally wants under 30; games and animation are more forgiving and I would rather not rely on that.' },
    { k: 'Reverb time, RT60',  value: 0.14, limit: 0.30, unit: 's', better: 'lower',
      n: 'The room signature. Above about 0.3 a booth starts to sound like a booth, which is the one thing a booth must not do.' },
    { k: 'Signal to noise',    value: 68, limit: 60, unit: 'dB', better: 'higher',
      n: 'At a normal speaking level. The number that decides whether a whispered line is usable.' },
  ],
  note:
    'Ask any voice actor for these three and most cannot produce them, which is not a scandal — ' +
    'it is just that nobody asks. They take twenty minutes and a borrowed meter, and publishing ' +
    'them is the only claim about a booth that means anything.',
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Animation, per session', figure: '$450',   note: 'Up to four hours, union rates where applicable. Pickups inside 30 days are free — see the FAQ for why that is not generosity.' },
    { what: 'Games, per 100 lines',  figure: '$620',   note: 'Priced by line count rather than time, because efforts and exertion sessions take twice as long per line and everybody knows it.' },
    { what: 'ADR / dub',             figure: '$95/hr', note: 'Minimum two hours. Patched or in-person; the booth here is tested against broadcast spec monthly.' },
    { what: 'Self-tape audition',    figure: 'Free',   note: 'Always. A performer charging for auditions has misunderstood which side of the transaction they are on.' },
    { what: 'Raw read of your copy', figure: 'Free',   note: 'Same day. It costs me ten minutes and it saves us both a bad booking.' },
    { what: 'Usage and buyouts',     figure: 'Quoted', note: 'Character work is normally a session fee; broadcast usage is a different structure and a different page.' },
  ],
};

export const said = {
  text: 'The three roles she said not to hire her for were the reason we hired her for the other one. It is the only voice site I have ever forwarded to a director without editing it first.',
  who: 'Casting director, animation — 2025',
};

export const faqs = [
  {
    q: 'Why publish what you do not get cast as?',
    a: 'Because casting is a matching problem and a page that claims everything matches nothing. Three of the nine rows are things I will not take, and naming them makes the other six credible — which is the only thing a casting page can actually do.',
  },
  {
    q: 'Why no audio on this page?',
    a: 'Because this is a website template and the performer is fictional. Any recording here would be somebody else\'s voice presented as hers. Another template in this library does ship audio — generated click tracks, where a metronome is honestly a metronome — and a voice is not the same case.',
  },
  {
    q: 'Why are pickups free?',
    a: 'Not generosity: a pickup is usually caused by a script that changed or a word nobody flagged, and charging for it makes clients avoid asking, which produces worse work. Free inside thirty days is cheaper for me than a compromised take in the final mix.',
  },
  {
    q: 'Will you do an accent?',
    a: 'My own, and anything close to it. Not one that belongs to a community I am not from — cast somebody who is, and the performance will be better as well as the casting. This is on the page rather than in a conversation because it saves both of us the audition.',
  },
  {
    q: 'Patched session or self-directed?',
    a: 'Either. Patched is better for anything with performance nuance and self-directed is better for volume. If you are unsure, patch the first session and decide afterwards — the difference is obvious once you have heard both.',
  },
  {
    q: 'What does the booth sound like?',
    a: 'Treated, tested monthly against broadcast spec, with the noise floor measured rather than described. Ask for the numbers and I will send them; a voice actor who cannot state their own noise floor is telling you something.',
  },
];
