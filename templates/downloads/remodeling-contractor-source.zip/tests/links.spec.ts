import { test, expect } from '@playwright/test';

test.describe('Longfellow Kitchen Co. — link integrity', () => {

  // Google Analytics and AdSense render only on the author's deploy, and the
  // Playwright web server sets PUBLIC_TEMPLATE_HUB_URL, so they load here too.
  // Both are `async` scripts, which means the `load` event waits on them and
  // every navigation in this suite becomes a bet on a third-party CDN. They are
  // also not this template's layout or this template's accessibility. Blocked.
  test.beforeEach(async ({ page }) => {
    await page.route(
      /googletagmanager|googlesyndication|doubleclick|google-analytics/,
      route => route.abort(),
    );
  });
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title names this business and this city', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Longfellow Kitchen Co.');
    expect(title).toContain('Minneapolis');
  });

  // Scaffold contamination is the most common defect in this library: a template
  // is built by copying its neighbour, and everything not explicitly rewritten
  // survives. This asserts the day-75 nouns are gone from the rendered page.
  test('no trace of the source template survives in the rendered page', async ({ page }) => {
    await page.goto('/');
    const body = (await page.locator('body').innerText()).toLowerCase();
    for (const stale of [
      'wingfield', 'richmond', 'virginia', 'tenant improvement', 'blueline',
      'change order', 'pay application', 'schedule of values', 'lease checklist',
      'shockoe', 'carytown', 'bonding', 'occupancy classification', 'work letter',
    ]) {
      expect(body, `stale day-75 noun "${stale}" survived`).not.toContain(stale);
    }
    // The phrase "per square foot" DOES appear, three times, and all three are
    // the page refusing the convention or pricing a material inside a
    // per-project number. What must never appear is a $/sf figure.
    expect(body).not.toMatch(/\$\s?\d[\d,]*\s*(\/|per )s(q|quare)?\.?\s?f/);
    expect(body).toContain('no dollars per square foot anywhere on this page');
  });

  // ── The regression day 75 shipped ─────────────────────────────────────
  // Day 75's header was 81px wider than its 1200px container, so a horizontal
  // scrollbar appeared at 1200px and 1280px. `overflow-x: hidden` is
  // deliberately NOT set on body — clipping it would make this test pass while
  // the layout was still broken.
  const WIDTHS = [375, 768, 1024, 1180, 1200, 1280, 1440, 1920];
  for (const width of WIDTHS) {
    test(`no horizontal overflow at ${width}px`, async ({ page }) => {
      await page.setViewportSize({ width, height: 900 });
      await page.goto('/', { waitUntil: 'load' });
      const metrics = await page.evaluate(() => ({
        scrollWidth:  document.documentElement.scrollWidth,
        clientWidth:  document.documentElement.clientWidth,
        // Name the widest offender so a failure is actionable rather than a number.
        widest: (() => {
          const limit = document.documentElement.clientWidth;
          let worst = { sel: '', w: 0 };
          document.querySelectorAll<HTMLElement>('body *').forEach(el => {
            // Shapes inside a clipped background SVG are not offenders.
            if ((el as unknown as SVGElement).ownerSVGElement) return;
            const r = el.getBoundingClientRect();
            if (r.right > limit + 1 && r.width > worst.w) {
              worst = {
                sel: `${el.tagName.toLowerCase()}.${(el.className || '').toString().split(' ')[0]}`,
                w: Math.round(r.right),
              };
            }
          });
          return worst;
        })(),
      }));
      expect(
        metrics.scrollWidth,
        `overflow at ${width}px — widest offender ${metrics.widest.sel} reaching ${metrics.widest.w}px`,
      ).toBeLessThanOrEqual(metrics.clientWidth);
    });
  }

  test('no horizontal overflow on the design page at 1200px and 375px', async ({ page }) => {
    for (const width of [375, 1200]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto('/design/', { waitUntil: 'load' });
      const m = await page.evaluate(() => ({
        s: document.documentElement.scrollWidth,
        c: document.documentElement.clientWidth,
      }));
      expect(m.s, `design page overflows at ${width}px`).toBeLessThanOrEqual(m.c);
    }
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
    expect(description!.length).toBeLessThan(200);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
    expect(ogImage).toContain('og-image.png');
  });

  // Fonts imported from inside the CSS bundle are discovered only once the
  // stylesheet parses, which cost house-painter a CLS of 0.156 (KNOWN_DEFECTS
  // §14). The two above-the-fold faces are preloaded from Base.astro. There is
  // no third family and no monospace, so there is no third preload.
  test('above-the-fold font faces are preloaded', async ({ page }) => {
    await page.goto('/');
    const preloads = page.locator('link[rel="preload"][as="font"]');
    expect(await preloads.count()).toBe(2);
    const hrefs = await preloads.evaluateAll(els => els.map(e => e.getAttribute('href') ?? ''));
    expect(hrefs.some(h => h.includes('faustina-latin-700'))).toBe(true);
    expect(hrefs.some(h => h.includes('hanken-grotesk-latin-400'))).toBe(true);
    for (const h of hrefs) {
      const res = await page.request.get(h);
      expect(res.status()).toBe(200);
    }
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of [
      'records', 'cost', 'sink', 'living', 'middle',
      'behind', 'who', 'area', 'reviews', 'contact',
    ]) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('every in-page nav link resolves to a real section', async ({ page }) => {
    await page.goto('/');
    const hrefs = await page.locator('a[href^="#"]').evaluateAll(
      els => els.map(el => el.getAttribute('href')!).filter(h => h.length > 1),
    );
    expect(hrefs.length).toBeGreaterThan(5);
    for (const href of [...new Set(hrefs)]) {
      await expect(page.locator(href)).toBeAttached();
    }
  });

  test('tel links are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="tel:"]').count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('mailto link is present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="mailto:"]').count();
    expect(count).toBeGreaterThanOrEqual(1);
  });

  test('external links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const blanks = page.locator('a[target="_blank"]');
    const total = await blanks.count();
    expect(total).toBeGreaterThanOrEqual(2);
    const safe = await page.locator('a[target="_blank"][rel*="noopener"]').count();
    expect(safe).toBe(total);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  // schema.org has no RemodelingContractor, Remodeling, KitchenRemodeler or
  // Renovation type — none of those strings exists in the vocabulary, so none is
  // invented. GeneralContractor DOES exist and day 75 uses it; this template
  // must not, because this business refuses whole-project general contracting in
  // its own copy and structured data is the worst place to contradict yourself.
  test('business schema is the HomeAndConstructionBusiness array form', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const parsed = blocks.map(b => JSON.parse(b));
    const business = parsed.find(b => Array.isArray(b['@type']) && b.makesOffer);
    expect(business).toBeTruthy();
    expect(business['@type']).toEqual(['HomeAndConstructionBusiness', 'LocalBusiness']);
    expect(business.additionalType).toBe('https://en.wikipedia.org/wiki/Renovation');
    expect(Array.isArray(business.makesOffer)).toBe(true);
    expect(business.makesOffer.length).toBe(4);   // three scope bands + the bath
    expect(Array.isArray(business.knowsAbout)).toBe(true);
    expect(business.hasCredential.length).toBe(2);
    expect(business.hasCredential[0].name).toContain('Residential Building Contractor');
    expect(business.hasCredential[1].name).toContain('Lead-Safe');
    expect(business.founder['@type']).toBe('Person');
    expect(business.founder.name).toContain('Sam Ostergaard');
    // Fictional 555 contact details stay in the source on purpose.
    expect(business.telephone).toContain('555-0173');

    const allSchema = JSON.stringify(parsed);
    // No aggregateRating: the reviews are fictional and a star rating with
    // nothing behind it is what search engines penalise.
    expect(allSchema).not.toContain('aggregateRating');
    // And no invented types.
    expect(allSchema).not.toContain('GeneralContractor');
    expect(allSchema).not.toContain('RemodelingContractor');
    expect(allSchema).not.toContain('KitchenRemodeler');
  });

  test('FAQPage schema covers every question on the page', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const faq = blocks.map(b => JSON.parse(b)).find(b => b['@type'] === 'FAQPage');
    expect(faq).toBeTruthy();
    const rendered = await page.locator('details summary').count();
    expect(faq.mainEntity.length).toBe(rendered);
    expect(rendered).toBe(10);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('link[rel="icon"]')).toBeAttached();
  });

  test('three scope bands and one bath service', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.band-card').count()).toBe(3);
    expect(await page.locator('.bath-card').count()).toBe(1);
  });

  test('six displacement records, each with a week strip', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.record-card').count()).toBe(6);
    expect(await page.locator('.record-card table.strip-table').count()).toBe(6);
  });

  test('five allowances are explained by name', async ({ page }) => {
    await page.goto('/');
    const labels = await page.locator('.allowance-label').allTextContents();
    expect(labels).toEqual(['Appliances', 'Tile', 'Plumbing fixtures', 'Lighting', 'Countertop']);
  });

  test('seven existing-condition findings, and the RRP rule stated as law', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.finding-card').count()).toBe(7);
    await expect(page.locator('#behind')).toContainText('Renovation, Repair and Painting');
    await expect(page.locator('#behind')).toContainText('law');
  });

  test('the people section names both people and the named subcontractors', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#who')).toBeAttached();
    expect(await page.locator('.team-card').count()).toBe(2);
    await expect(page.locator('#who')).toContainText('Sam Ostergaard');
    await expect(page.locator('#who')).toContainText('Nadia Roelofs');
    expect(await page.locator('.trades-col').count()).toBe(2);
    expect(await page.locator('.trades-list li').count()).toBeGreaterThanOrEqual(10);
    await expect(page.locator('.key-panel')).toContainText('key');
  });

  test('contact form is present with a labelled control for every input', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.contact-form')).toBeAttached();
    const controls = page.locator('.contact-form input, .contact-form select, .contact-form textarea');
    const total = await controls.count();
    expect(total).toBeGreaterThanOrEqual(5);
    for (let i = 0; i < total; i++) {
      const id = await controls.nth(i).getAttribute('id');
      expect(id).toBeTruthy();
      await expect(page.locator(`label[for="${id}"]`)).toHaveCount(1);
    }
  });

  test('the contact section says what to have ready', async ({ page }) => {
    await page.goto('/');
    const ready = page.locator('.ready-list li');
    await expect(ready).toHaveCount(4);
    const text = (await ready.allTextContents()).join(' ');
    expect(text).toContain('Photographs of the room');
    expect(text).toContain('staying in the house');
    expect(text).toContain('Kids and pets');
    expect(text).toContain('target month');
  });

  // No decorative characters from Geometric Shapes, Miscellaneous Symbols,
  // Dingbats or the emoji planes, and no variation selectors. Day 74 shipped
  // U+25EB as `<glyph>&#xFE0E;` and it rendered as a tofu box; day 75 still set
  // the Pro bar's padlock as U+1F512.
  test('no decorative glyphs from the tofu-prone blocks', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const banned = /[■-◿☀-⛿✀-➿︎️]|[\u{1F300}-\u{1FAFF}]/u;
    expect(banned.test(html)).toBe(false);
  });

  test('the free edition does not ship the Pro kitchen-shutdown-plan page', async ({ page }) => {
    // The build under test is the free one, so /kitchen-shutdown-plan/ redirects home.
    const response = await page.goto('/kitchen-shutdown-plan/');
    expect(response?.status()).toBeLessThan(400);
    // The stub is a meta refresh, so wait for it to land before reading the DOM
    // rather than racing the navigation.
    await page.waitForURL(url => url.pathname === '/', { timeout: 15_000 });
    await expect(page.locator('h1')).toContainText('the day you get');
  });

  test('the design system page loads and is noindexed', async ({ page }) => {
    const response = await page.goto('/design/');
    expect(response?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
  });
});
