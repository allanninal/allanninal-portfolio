import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Longfellow Kitchen Co. — accessibility', () => {

  // Google Analytics and AdSense render only on the author's deploy, and the
  // Playwright web server sets PUBLIC_TEMPLATE_HUB_URL, so they load here too.
  // Both are `async` scripts, which means the `load` event waits on them and
  // every navigation in this suite becomes a bet on a third-party CDN. They are
  // also not this template's layout or this template's accessibility. Blocked.
  test.beforeEach(async ({ page }) => {
    await page.route(
      /googletagmanager|googlesyndication|doubleclick|google-analytics/,
      route => route.abort(),
    );
  });
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();

    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  // The maker strip is the element that has failed most often across the library:
  // 61 footers were "fixed" with a var() fallback chain that resolved to
  // currentColor and changed nothing. Both the paragraph and the link get their
  // own assertion, because repairing only the link leaves "Made by" failing.
  test('maker strip and credit contrast pass on the dark footer', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .include('footer')
      .withRules(['color-contrast'])
      .analyze();
    expect(results.violations).toEqual([]);

    const creditColour = await page.locator('p.maker-credit').evaluate(el => getComputedStyle(el).color);
    const linkColour   = await page.locator('p.maker-credit a').evaluate(el => getComputedStyle(el).color);
    // Explicit values, not inherited: #DACBD0 and #E2ABD2.
    expect(creditColour).toBe('rgb(218, 203, 208)');
    expect(linkColour).toBe('rgb(226, 171, 210)');
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  // Single h1, and the ten h2s are exactly the brief's section list in the
  // brief's order. The FAQ deliberately sits under an h3 inside the contact
  // section rather than becoming an eleventh h2.
  test('heading hierarchy is logical and the h2 list matches the brief', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('h1')).toHaveCount(1);
    await expect(page.locator('h1')).toContainText('the day you get');
    const h2s = await page.locator('h2').allTextContents();
    expect(h2s).toEqual([
      'Six kitchens, and how long each family lived without one.',
      'What a kitchen costs here, and what moves the number.',
      'When not to move the sink.',
      'What it is like to live here while we work.',
      'The two weeks in the middle when nothing happens.',
      'What is behind a 1926 kitchen wall.',
      'Who is in your house.',
      'South Minneapolis, and how far we go.',
      'What the neighbours say.',
      'Book a kitchen visit.',
    ]);
  });

  test('displacement records each carry the six labelled lines', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('.record-card');
    await expect(cards).toHaveCount(6);
    const specTerms = page.locator('.record-spec dt');
    await expect(specTerms).toHaveCount(36);   // 6 records × 6 lines
  });

  // The rule that makes the records credible. Six kitchens that all landed on
  // the promised Friday with the crew there every single day is an advert with a
  // calendar in it, and a homeowner reads it as one in four seconds.
  test('at least two records ran over, one finished early, and every one has a gap', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.record-days--over').count()).toBeGreaterThanOrEqual(2);
    expect(await page.locator('.record-days--under').count()).toBeGreaterThanOrEqual(1);

    // Every card must show a non-zero "nobody came" count. The over-flag is used
    // for both the promise flag and the nobody-came line, so this reads the text.
    const gaps = await page.locator('.record-days--over').allTextContents();
    const nobody = gaps.filter(t => t.includes('nobody came'));
    expect(nobody.length).toBe(6);
    nobody.forEach(t => {
      const n = Number(t.trim().split(' ')[0]);
      expect(Number.isFinite(n)).toBe(true);
      expect(n).toBeGreaterThan(0);
    });
  });

  // The week strip must be a real table with row AND column headers, and must
  // not convey anything by colour alone: three shapes plus a screen-reader
  // reading in every cell.
  test('the week strip is a real table with row and column headers', async ({ page }) => {
    await page.goto('/');
    const tables = page.locator('table.strip-table');
    await expect(tables).toHaveCount(6);

    for (let i = 0; i < 6; i++) {
      const t = tables.nth(i);
      await expect(t.locator('caption')).toHaveCount(1);
      // Four row headers, in the brief's order.
      const rowHeads = await t.locator('th[scope="row"]').allTextContents();
      expect(rowHeads).toEqual(['Kitchen sink', 'Cooking', 'Dust wall up', 'Crew on site']);
      // One column header per week, each reading "Week n" to a screen reader.
      const colHeads = t.locator('th[scope="col"]');
      const weeks = await colHeads.count();
      expect(weeks).toBeGreaterThanOrEqual(4);
      const first = await colHeads.first().locator('.sr-only').textContent();
      expect(first).toBe('Week 1');
      // Every block carries its own text reading; nothing is colour-only.
      const cells = t.locator('td.strip-cell');
      expect(await cells.count()).toBe(weeks * 4);
      expect(await t.locator('td.strip-cell .sr-only').count()).toBe(weeks * 4);
      expect(await t.locator('td.strip-cell .strip-block').count()).toBe(weeks * 4);
    }
  });

  test('the strip legend names three shapes, not three colours', async ({ page }) => {
    await page.goto('/');
    const legend = page.locator('.strip-key .strip-legend li');
    await expect(legend).toHaveCount(3);
    const text = (await legend.allTextContents()).join(' ');
    expect(text).toContain('Solid');
    expect(text).toContain('Hatched');
    expect(text).toContain('Outline');
  });

  test('scope bands are present with published per-project ranges', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.band-card')).toHaveCount(3);
    const ranges = await page.locator('.band-range').allTextContents();
    expect(ranges.length).toBe(3);
    ranges.forEach(r => {
      expect(r).toContain('$');
      // No dollars per square foot anywhere on this page — it is a commercial
      // convention and a kitchen is priced per project.
      expect(r).not.toContain('/sf');
    });
  });

  // The concession section must genuinely concede. A section that only lists
  // reasons to spend more is an advert and the reader knows.
  test('the concession section refuses work out loud', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.keep-card')).toHaveCount(4);
    await expect(page.locator('.refusal-card')).toHaveCount(3);
    await expect(page.locator('#sink')).toContainText('Hire a general contractor');
  });

  test('reviews are tagged with a neighbourhood and a scope', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('.review-card');
    await expect(cards).toHaveCount(6);
    expect(await page.locator('.review-hood').count()).toBe(6);
    expect(await page.locator('.review-scope').count()).toBe(6);
  });

  test('service zones are present', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.service-zone').count()).toBe(4);
  });

  test('the booking bar replaces the emergency bar', async ({ page }) => {
    await page.goto('/');
    const bar = page.locator('.booking-bar');
    await expect(bar).toBeVisible();
    await expect(bar).toContainText('late February');
    // A kitchen remodeler has no emergency. No emergency bar at all, no red.
    await expect(page.locator('.emergency-bar')).toHaveCount(0);
  });

  test('design system page passes axe', async ({ page }) => {
    await page.goto('/design/');
    await page.waitForLoadState('networkidle');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();
    if (results.violations.length > 0) {
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }
    expect(results.violations).toEqual([]);
  });
});
