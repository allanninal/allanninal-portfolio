// Longfellow Kitchen Co. — configuration data
// Day 76 of the 365-template roadmap
//
// Design note: day 75 sells to a business owner who has signed a lease on an
// empty commercial shell and is paying rent on a dark room. This template sells
// to a family who will be sleeping thirty feet from the demolition, and the
// difference decides every line in this file.
//
// A commercial tenant's fear is arithmetic. A homeowner's real fear is not on the
// invoice at all: strangers will be in the house, the house will be full of dust,
// and nobody will tell them when it ends. They have heard the story — the
// neighbours whose six-week kitchen took five months, who washed dishes in the
// bathtub until August, whose crew disappeared for two weeks with no explanation.
// Every remodeler's website answers the wrong question by showing the finished
// room. Nobody has ever shown them the middle.
//
// So the hook is `records`, and the unit of this page is the DAY, not the dollar.
// Each card is a displacement record: what the household lost, for exactly how
// many days, told from the family's side of the plastic. The fourth line is the
// one that matters and the one no contractor will publish — "days nobody came" is
// the single most common complaint in residential remodeling and the number every
// homeowner is silently counting anyway.
//
// The rule that makes it credible, and it is a hard rule: at least two of the six
// must have run past what was promised, with the reason stated, and every card
// must show a non-zero "nobody came" count. A record where six kitchens all
// landed on the promised Friday and the crew was there every single day is not a
// record, it is an advert with a calendar in it. This demo ships one job two days
// early, one that ran a week and a half over because of a subfloor discovery, and
// one where the delay was entirely the client's — because that also happens, and
// showing it is what makes the other five believable.

export const contractor = {
  name:        'Longfellow Kitchen Co.',
  tagline:     'One kitchen at a time in South Minneapolis, with the days you spend without a sink published in advance',
  description: 'Occupied-home kitchen remodels in South Minneapolis. One crew, one kitchen at a time. Every project on this site publishes how many days the family went without a sink, where they cooked, and how many weekdays nobody came.',
  phone:       '(612) 555-0173',
  phoneHref:   'tel:+16125550173',
  email:       'hello@longfellowkitchen.example',
  address:     '3814 E 42nd St',
  city:        'Minneapolis',
  state:       'MN',
  zip:         '55406',
  license:     'Minnesota DLI Residential Building Contractor licence #BC555-0173',
  licenseShort:'Minnesota Residential Building Contractor',
  leadSafe:    'EPA Lead-Safe Certified Firm #NAT-555-0173-1',
  licensed:    true,
  insured:     true,
  founded:     2018,
  yearsExperience: 20,
  // Booking replaces the emergency line. Nobody's kitchen remodel is a 2am
  // call-out, and "one kitchen at a time" is the promise the whole hook rests
  // on, so it belongs at the top of the page.
  booking:     'Booking kitchen starts from late February',
  bookingNote: 'One crew, one kitchen at a time. We are not on four jobs this week.',
  liability:   '$2,000,000 per occurrence, $4,000,000 aggregate, plus workers’ compensation on every employee',
  warrantyMonths: 24,
  crewCount:   1,
  bookUrl:     '#',
  owner: {
    name:     'Sam Ostergaard',
    title:    'Owner & Lead Carpenter',
    initials: 'SO',
    bio:      'I was a lead carpenter for twelve years at a larger remodeling firm before this — the man physically standing in your kitchen every day. In twelve years I was asked "so when do I get my sink back?" several hundred times and I was never once allowed to answer honestly, because the office had already promised a date the schedule could not hold and my job was to keep saying it. I started a one-kitchen-at-a-time shop specifically so the answer could be published in advance, on a website, before you call. Every number in the records below is one I would have wanted on the day I was standing in somebody’s dining room being asked.',
  },
  jobLead: {
    name:     'Nadia Roelofs',
    title:    'Job Lead',
    initials: 'NR',
    bio:      'Nadia is the person your household actually deals with. She is in the house on working days, she writes the end-of-day text that tells you what happened and who is coming tomorrow, and she is the one who calls you the afternoon we find something behind a wall rather than the following Monday. Nine years in residential remodeling, seven of them in South Minneapolis, which means she has met most of the inspectors on your job before and knows which ones want the panel schedule photographed.',
  },
  linkedin:  '#',
  instagram: '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Longfellow Kitchen Co. — Kitchen Remodeling, South Minneapolis MN',
  // Under 200 characters. Every page's meta description is asserted in
  // tests/links.spec.ts, on the Pro build as well as the free one — a Pro-only
  // page is invisible to a free-build audit (KNOWN_DEFECTS §5), which is exactly
  // where two over-long descriptions once sat unnoticed.
  description:   'South Minneapolis kitchen remodeler. One crew, one kitchen at a time. Six displacement records: days without a sink, where each family cooked, and how many weekdays nobody came.',
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

// ── The displacement records ────────────────────────────────────────────────
// The hook. Six labelled lines per project plus a week-by-week strip. The
// schema.org vocabulary has nothing that models a household's disruption
// schedule, so these stay semantic HTML: an <article> with a <dl>, plus a real
// <table> for the strip.
//
// `weeks` states are a three-level scale and the row header supplies the
// meaning, which is why each row carries its own `reading` map. Nothing in the
// strip is conveyed by colour: solid, hatched and outline are three shapes, and
// every cell renders a screen-reader reading as well.
export type StripState = 'full' | 'part' | 'none';

export type StripRow = {
  label: string;
  reading: Record<StripState, string>;
  weeks: StripState[];
};

export type Record6 = {
  slug: string;
  neighbourhood: string;
  scope: string;
  title: string;
  /** Line 1 — the house. */
  house: string;
  /** Line 2 — days without a kitchen sink. */
  sink: string;
  sinkDays: string;
  /** Line 3 — where you cooked, and for how long. */
  cooking: string;
  cookingDays: string;
  /** Line 4 — days we were actually in your house. The one that matters. */
  onSite: string;
  nobodyCame: number;
  /** Line 5 — the dust line. */
  dust: string;
  /** Line 6 — what we promised, what it took. */
  promise: string;
  promiseFlag: 'over' | 'under' | 'even';
  promiseFlagText: string;
  note?: string;
  strip: StripRow[];
};

// Four rows, in the brief's order, on every record. The reading strings are what
// a screen reader gets for each block; the shape is what a sighted reader gets.
const stripRows = (
  sink: StripState[],
  cooking: StripState[],
  dust: StripState[],
  crew: StripState[],
): StripRow[] => [
  {
    label: 'Kitchen sink',
    reading: {
      full: 'sink running all week',
      part: 'sink running part of the week',
      none: 'no kitchen sink this week',
    },
    weeks: sink,
  },
  {
    label: 'Cooking',
    reading: {
      full: 'cooking in the kitchen all week',
      part: 'kitchen back part of the week',
      none: 'temporary kitchen only',
    },
    weeks: cooking,
  },
  {
    label: 'Dust wall up',
    reading: {
      full: 'zip wall up all week',
      part: 'zip wall up part of the week',
      none: 'no zip wall this week',
    },
    weeks: dust,
  },
  {
    label: 'Crew on site',
    reading: {
      full: 'crew here all five weekdays',
      part: 'crew here some weekdays',
      none: 'nobody came this week',
    },
    weeks: crew,
  },
];

export const records: Record6[] = [
  {
    slug:          'longfellow-1926',
    neighbourhood: 'Longfellow',
    scope:         'Wall out',
    title:         'The 1926 story-and-a-half where the chimney chase could not move',
    house:         '1926 story-and-a-half, Longfellow. Kitchen 11 × 12, back stair and the chimney chase in the middle of the only good wall. Somebody knocked the pantry in badly in 1978 and left the header on a jack post.',
    sink:          'Disconnected 14 Apr, running again 6 May. You washed up in the basement laundry tub, which is twelve steps down and worse than it sounds by week three.',
    sinkDays:      '22 days without a kitchen sink',
    cooking:       'Induction plate and the microwave on a folding table in the dining room; fridge in the hall outside the bathroom. April, so the grill was back on from week two, which is the only reason this one was bearable.',
    cookingDays:   '31 days without a kitchen',
    onSite:        '31 working days on site. Nine weekdays nobody came: six waiting on the stone template and fabrication, two on the rough-in inspection, one for a spring snow that closed the fabricator.',
    nobodyCame:    9,
    dust:          'Zip wall across the dining room arch with a zippered door, negative-air machine in the kitchen window, adhesive film and hardboard from the back door to the front. The rest of the house stayed clean. The dining room did not, and we told you that on day one.',
    promise:       'We said seven weeks. It ran eight weeks and two days, because the header over the old pantry opening was carrying the back stair on a jack post and had to be engineered and replaced before cabinets could be set. Nine days of that were the engineer and the inspector, not us.',
    promiseFlag:   'over',
    promiseFlagText: 'Ran 7 working days past what we promised',
    note:          'This is the one we point at when somebody asks whether we ever run over. The header was not findable from inside a finished kitchen and it was not optional once it was open. What we could control was telling you on the afternoon we found it, with a number, rather than on the Friday you asked.',
    strip: stripRows(
      ['none','none','none','none','part','full','full','full'],
      ['none','none','none','none','none','part','full','full'],
      ['full','full','full','full','full','full','part','none'],
      ['full','part','none','part','full','full','part','part'],
    ),
  },
  {
    slug:          'standish-1924',
    neighbourhood: 'Standish',
    scope:         'Keep the layout',
    title:         'A 1924 bungalow that finished two days early, and why that is not a boast',
    house:         '1924 bungalow, Standish. Kitchen 10 × 11, sink stayed on the existing plumbing wall, no walls moved. New cabinets on the same footprint, new counter, new floor, one added circuit for the counter outlets.',
    sink:          'Disconnected 8 Sep, running again 19 Sep. Two-tub system in the laundry room downstairs, and we left the old faucet on a hose bib in the basement so there was hot water for it.',
    sinkDays:      '11 days without a kitchen sink',
    cooking:       'Induction plate and the toaster oven on the dining table, fridge stayed where it was because the doorway was wide enough. September, grill available the whole time.',
    cookingDays:   '17 days without a kitchen',
    onSite:        '19 working days on site. Four weekdays nobody came: three waiting on countertop fabrication after the template, one when the tile setter’s van broke down and we chose not to send somebody else who did not know the job.',
    nobodyCame:    4,
    dust:          'Zip wall across the kitchen doorway only — this house has a door there, which makes containment much easier and is worth knowing before you knock it out for an open plan. Negative air in the window, runner from the side door.',
    promise:       'We said four weeks. It took three weeks and three days. Nothing was found behind anything, the cabinets arrived on the date the supplier gave us, and the counter template went out the morning after the boxes were set.',
    promiseFlag:   'under',
    promiseFlagText: 'Finished 2 working days early',
    note:          'A keep-the-layout kitchen in a house where nothing is wrong is the one job that reliably lands early, and it is the least interesting record here. We publish it so the two that ran over have something honest to sit next to.',
    strip: stripRows(
      ['none','none','part','full'],
      ['none','none','none','part'],
      ['full','full','part','none'],
      ['full','part','part','full'],
    ),
  },
  {
    slug:          'nokomis-1938',
    neighbourhood: 'Nokomis',
    scope:         'Move the plumbing',
    title:         'The one where the subfloor was three layers and the bottom one was tile',
    house:         '1938 story-and-a-half, Nokomis. Kitchen 11 × 13 with a breakfast nook. Sink moved four feet along the same wall, dishwasher added, range moved to the opposite wall with a new vent run.',
    sink:          'Disconnected 6 Jan, running again 12 Feb. Bathtub and a dish tub for the first fortnight, then the laundry tub once we had put a temporary faucet on it. Thirty-seven days is the longest on this page and we are not going to pretend otherwise.',
    sinkDays:      '37 days without a kitchen sink',
    cooking:       'Induction plate, microwave and a kettle on a folding table in the dining room. Fridge in the back hall. This was a January start in Minneapolis, so there was no grill for any of it — that changes the plan and we say so before you sign.',
    cookingDays:   '44 days without a kitchen',
    onSite:        '34 working days on site. Eleven weekdays nobody came: five on countertop fabrication, three while the abatement contractor did the floor and nobody else could be in the room, two on inspections, one for the 21 January cold snap when nothing was moving in this city.',
    nobodyCame:    11,
    dust:          'Zip wall across the dining room opening, second wall at the basement stair, negative air in the window. During the three abatement days the containment was theirs, not ours, and the family stayed elsewhere for two of them.',
    promise:       'We said seven weeks. It ran eight weeks and three days. The floor was three layers — sheet vinyl over hardboard over 9-inch vinyl asbestos tile — which nobody could see until the cabinets came out, and abatement is a licensed contractor on their calendar, not ours.',
    promiseFlag:   'over',
    promiseFlagText: 'Ran 8 working days past what we promised',
    note:          'A week and a half over, and every day of it is on the strip. This is what a pre-1978 floor can do to a schedule, which is why the contingency exists and why we test the floor before we price the job rather than after.',
    strip: stripRows(
      ['none','none','none','none','none','none','none','part','full'],
      ['none','none','none','none','none','none','none','none','part'],
      ['full','full','full','full','full','full','full','part','none'],
      ['full','part','none','part','part','full','part','full','part'],
    ),
  },
  {
    slug:          'hiawatha-1916',
    neighbourhood: 'Hiawatha',
    scope:         'Move the plumbing',
    title:         'Nine days of this one were ours to lose and we did not lose them',
    house:         '1916 bungalow, Hiawatha. Kitchen 10 × 12 opening to a rear porch. Sink stayed, dishwasher added, range and hood moved, back door relocated three feet so the fridge had somewhere to be.',
    sink:          'Disconnected 3 Jun, running again 20 Jun. Laundry tub in the basement, and the family used the neighbour’s kitchen twice a week by arrangement, which is a real and underrated option on a block like this one.',
    sinkDays:      '17 days without a kitchen sink',
    cooking:       'Induction plate on the porch, microwave in the dining room, fridge on the porch under a tarp until the back door moved. June, so the grill did most of the work.',
    cookingDays:   '25 days without a kitchen',
    onSite:        '24 working days on site. Twelve weekdays nobody came, and nine of those were you: the tile was changed at the end of week three and the replacement was a special order. Three were countertop fabrication.',
    nobodyCame:    12,
    dust:          'Zip wall across the dining room arch, negative air in the porch door, hardboard the length of the hall. The porch was a staging area and it was not clean at any point.',
    promise:       'We said five weeks. It ran six weeks and four days. Nine working days of that were the tile change and we said so at the time, in writing, with the new date on the same email. Changing your mind is allowed and it has a number.',
    promiseFlag:   'over',
    promiseFlagText: 'Ran 9 working days past what we promised — all client-directed',
    note:          'We publish this one because a delay that is genuinely the client’s is the most common kind and no remodeler’s website will admit it exists. The honest version is that it costs days, we tell you how many on the day you decide, and nobody is angry about it later.',
    strip: stripRows(
      ['none','none','none','part','full','full','full'],
      ['none','none','none','none','none','part','full'],
      ['full','full','full','full','full','part','none'],
      ['full','part','part','none','part','full','part'],
    ),
  },
  {
    slug:          'powderhorn-1912',
    neighbourhood: 'Powderhorn',
    scope:         'Keep the layout',
    title:         'A duplex owner’s unit where the tenant upstairs never lost water',
    house:         '1912 duplex, Powderhorn, owner’s unit on the ground floor. Kitchen 9 × 12. Layout kept, galvanised supply replaced back to the basement stack because it would not have survived being disturbed.',
    sink:          'Disconnected 21 Oct, running again 4 Nov. Basement laundry tub. The upstairs tenant lost water for four hours on one morning, on a date they were given eight days in advance.',
    sinkDays:      '14 days without a kitchen sink',
    cooking:       'Induction plate and microwave in the front room, fridge in the same room. Late October, so the grill was a coat-on proposition and got used about twice.',
    cookingDays:   '21 days without a kitchen',
    onSite:        '22 working days on site. Five weekdays nobody came: four on countertop fabrication and one on the plumbing rough-in inspection, which in this city is a morning slot you cannot pick.',
    nobodyCame:    5,
    dust:          'Zip wall at the kitchen doorway and a second at the foot of the tenant’s stair, because the stair runs through the unit. Negative air in the window. The tenant’s entrance was never a work route and their stair was never dusty.',
    promise:       'We said five weeks. It took five weeks. The galvanised supply was priced as a contingency item before we started because a 1912 duplex will have it, and finding it is not a surprise, it is a Tuesday.',
    promiseFlag:   'even',
    promiseFlagText: 'Finished on the day we promised',
    strip: stripRows(
      ['none','none','none','part','full'],
      ['none','none','none','none','part'],
      ['full','full','full','part','none'],
      ['full','part','part','full','part'],
    ),
  },
  {
    slug:          'longfellow-1931',
    neighbourhood: 'Longfellow',
    scope:         'Wall out',
    title:         'A January start, which is a different job from the same kitchen in July',
    house:         '1931 bungalow, Longfellow. Kitchen 10 × 11 with a wall to the dining room taken out to a 7-foot opening, new header, knob-and-tube found in the ceiling above and removed back to the panel.',
    sink:          'Disconnected 13 Jan, running again 5 Feb. Basement laundry tub, with a space heater down there because the basement is 52 degrees in January and nobody warns you about that either.',
    sinkDays:      '23 days without a kitchen sink',
    cooking:       'Induction plate and microwave in the dining room, fridge in the front hall. No grill: this is Minneapolis in January and the grill is not an option between November and March, which changes the whole displacement plan.',
    cookingDays:   '30 days without a kitchen',
    onSite:        '28 working days on site. Seven weekdays nobody came: four on countertop fabrication, two on inspections — the electrical rough-in went to a second visit because the knob-and-tube removal changed the scope — and one for weather.',
    nobodyCame:    7,
    dust:          'Zip wall across the new opening while it was still a wall, then a full-height wall on a track once the opening was cut, because there is no door to close once the wall is gone. That is the honest cost of an open plan and it is worth knowing in advance.',
    promise:       'We said six weeks. It ran six weeks and one day. The knob-and-tube was found on the second day and added four days, and we bought two of them back by starting the floor while the electrician finished.',
    promiseFlag:   'over',
    promiseFlagText: 'Ran 1 working day past what we promised',
    note:          'A winter start is not worse, it is different: no grill, a cold basement for the washing-up, and a fabricator whose delivery week has weather in it. We plan it differently and we say so before you book a January date.',
    strip: stripRows(
      ['none','none','none','none','part','full'],
      ['none','none','none','none','none','part'],
      ['full','full','full','full','part','none'],
      ['full','part','part','full','part','part'],
    ),
  },
];

export const recordsNote =
  'Two of these six ran past what we promised, one ran over because the client changed the tile, one finished two days early and one landed on the day. Every one of them has a non-zero "nobody came" count, because a kitchen with a countertop in it has a fortnight where the countertop is somewhere else. A page where six families all got their sink back on the promised Friday is not a record, it is an advert with a calendar in it, and you would know that within four seconds.';

// ── What a kitchen costs here ───────────────────────────────────────────────
// No dollars per square foot anywhere. $/sf is a commercial convention; a
// residential kitchen is priced per project and a $/sf figure on a kitchen is
// either meaningless or misleading. Ranges are given per SCOPE BAND instead,
// with the two or three things that move each. This is a deliberate structural
// difference from day 75's pricing table.
export type ScopeBand = {
  slug: string;
  name: string;
  range: string;
  basis: string;
  duration: string;
  desc: string;
  movers: string[];
};

export const scopeBands: ScopeBand[] = [
  {
    slug:  'keep-the-layout',
    name:  'Keep the layout',
    range: '$38,000 – $62,000',
    basis: 'construction and cabinetry, with allowances listed below',
    duration: '3 – 4 weeks on site',
    desc:  'Everything stays where it is. New cabinets on the existing footprint, new counter, new floor, new lighting, paint, and whatever electrical the current code makes us bring up to date. The sink does not move, so the shut-off is short and the plumbing inspection is one visit.',
    movers: [
      'Cabinets: stock, semi-custom or made for the room. This is the single biggest line and the range inside it is wider than the range between two of these bands',
      'Countertop material, which is a per-square-foot decision inside a per-project job',
      'What the wiring turns out to be. A 1920s kitchen on two circuits with no ground is a real electrical scope even when nothing moves',
    ],
  },
  {
    slug:  'move-the-plumbing',
    name:  'Move plumbing and electrical within the room',
    range: '$60,000 – $95,000',
    basis: 'construction and cabinetry, with allowances listed below',
    duration: '5 – 7 weeks on site',
    desc:  'The walls stay up but the room is re-planned inside them. Sink moves along a wall or across the room, dishwasher gets added, the range and hood relocate with a new vent run, and the circuits get rebuilt to suit. Longer shut-off, more inspections, and the floor comes up.',
    movers: [
      'How far the sink moves and which direction the joists run. Along the joists is plumbing; across them is notching, blocking and sometimes an engineer',
      'Whether the range wall can take a vent run to the outside without going through the roof',
      'The floor, once it is up. Three layers with vinyl asbestos tile at the bottom is a licensed abatement contractor and days you cannot buy back',
    ],
  },
  {
    slug:  'take-the-wall-out',
    name:  'Take the wall out',
    range: '$92,000 – $165,000',
    basis: 'construction, cabinetry and structural work, with allowances listed below',
    duration: '7 – 10 weeks on site',
    desc:  'The wall between the kitchen and the dining room comes out, which means a header, which means a load path down to the footing. In a story-and-a-half that path usually runs somewhere inconvenient. This is the band where a permit review and a structural detail are part of the schedule rather than a formality.',
    movers: [
      'What the wall is holding. A partition is a morning; a bearing wall under the back stair is an engineer, a stamped detail, a header and posts',
      'Where the chimney chase is. It does not move, and in most South Minneapolis houses it is somewhere the plan wants to be',
      'Whether the ceiling can be flushed with the dining room, or the header drops and you live with a beam. Both are fine; only one is cheap',
    ],
  },
];

export const bathService = {
  name:  'One bathroom, as a second job',
  range: '$22,000 – $45,000',
  desc:  'A hall bath or a primary bath, priced and scheduled as its own job and usually run after the kitchen rather than beside it. A bath in a two-bathroom house is an inconvenience; a kitchen is a crisis, and running both at once turns an inconvenience into a second one. If you want both, we will tell you which order and why.',
};

export const allowances = {
  title: 'Allowances, explained once and properly',
  body:  'An allowance is a number we carry in the contract for something you have not chosen yet. It is how a residential quote gets quietly beaten by a cheaper one: a competitor sets the tile allowance at $4 a square foot, wins the job, and you discover in week five that the tile you actually want is $14 and the difference is yours. Ours are set at what the thing costs, we tell you which three products the number was built from, and when you pick the real one the contract adjusts up or down by the difference in writing.',
  items: [
    { label: 'Appliances',        body: 'Range, hood, refrigerator, dishwasher and often a microwave. The easiest one to check yourself, and the one where a low allowance is most obvious if you look.' },
    { label: 'Tile',             body: 'Floor and backsplash, priced per square foot including trim pieces. Ask what the number assumes about the trim, because bullnose and pencil liners are where a tile budget actually goes.' },
    { label: 'Plumbing fixtures', body: 'Sink, faucet, disposal, pot filler if you are having one. A cast-iron farmhouse sink and a stainless drop-in are not the same number and neither is the cabinet under them.' },
    { label: 'Lighting',          body: 'Ceiling fixtures, pendants and under-cabinet. Cans and their trims are usually in the electrical scope rather than the allowance, and it is worth asking which.' },
    { label: 'Countertop',        body: 'Material and fabrication, per square foot of finished top. The edge profile, the sink cut-out and whether the slab has to be seamed are all inside this number and all worth asking about.' },
  ],
};

export const pricingNote =
  'No dollars per square foot anywhere on this page. It is a commercial convention and it does not survive contact with a residential kitchen: two 110-square-foot kitchens in the same block can be $40,000 and $150,000, and dividing either by 110 tells you nothing you can use. These are 2026 South Minneapolis prices for the work, and a range becomes a real number after we have stood in the room.';

// ── When not to move the sink ───────────────────────────────────────────────
// The concession section must genuinely concede. A section that only lists
// reasons to spend more is an advert.
export const concession = {
  eyebrow: 'The Cheaper Answer, When It Is The Right One',
  title:   'When not to move the sink.',
  lede:    'In a lot of 1920s Minneapolis kitchens the plumbing wall is where it is because the stack is where it is, and moving the sink buys a marginally better layout for a large amount of money and a much longer shut-off. Here are the cases where we will tell you to keep it, and the cases where we will tell you not to hire us at all.',
  keepCases: [
    {
      label: 'The stack is in the wall behind the sink',
      body:  'Every house on the block has it in the same place, because they were built by the same crew in the same year. Moving the sink means a new drain run at slope, through or along the joists, and in a story-and-a-half with a finished basement ceiling that is a demolition job in a room you were not remodeling. Keep the sink; spend the money on the cabinets you will touch every day.',
    },
    {
      label: 'The window is over the sink and you like it there',
      body:  'The sink is under the window in these houses because that is where the light is. Moving it to an island buys you a view of the dining room and takes away the one place in the kitchen you actually want to stand. We have talked more people out of this than into it.',
    },
    {
      label: 'The layout is fine and the kitchen is just old',
      body:  'A 1924 galley with a working triangle and no dishwasher does not need re-planning; it needs cabinets, a counter, a floor, lighting and a dishwasher squeezed in where the old base cabinet was. That is the keep-the-layout band, it is three to four weeks, and eleven days without a sink rather than thirty-seven.',
    },
    {
      label: 'You are selling within three years',
      body:  'Doors, drawer fronts, paint, counters, a new sink and faucet, lighting and hardware will change the room more than most buyers can tell apart from a full remodel, for a fraction of the number and about two weeks of disruption. We do this work and we will quote it. It is not a lesser job, it is a different question.',
    },
  ],
  refusals: [
    {
      label: 'Additions — we do not do them',
      body:  'An addition is built outside the envelope: footings, foundation, framing, a structural permit, rough inspections and a roof tie-in. Your kitchen stays working the whole time, which means the entire thing this company is organised around — living in a house with no kitchen — does not apply. It is a different trade with a different schedule and a different set of subcontractors. Hire a general contractor. We will give you two names.',
    },
    {
      label: 'Whole-house gut renovation — also no',
      body:  'If the plan is to move out for four months and take the house back to the studs, you do not need a one-kitchen-at-a-time shop, you need a general contractor with a superintendent and six trades running at once. We would be the wrong end of the phone in month two. Same answer, same two names.',
    },
    {
      label: 'Two rooms at the same time',
      body:  'We will do your bath. We will not do it in the same six weeks as your kitchen, because one crew cannot be in two rooms and because a household that has lost both is a household that moves out. Kitchen first, bath in the autumn, and you keep somewhere to wash up in between.',
    },
  ],
};

// ── What it is like to live here while we work ──────────────────────────────
// The entire lived experience of the job is absent from remodeling websites, and
// it is the only subject the customer is actually thinking about at 11pm.
export type LivingItem = { label: string; body: string };

export const livingHere: LivingItem[] = [
  {
    label: 'The dust line, and where exactly it is',
    body:  'A zip wall with a zippered door across the opening between the kitchen and the next room, taped to the floor and the ceiling, before anything comes off a wall. You will be shown where it goes and you can move it before we build it. Once it is up, the room on our side is ours and the rest of the house is yours.',
  },
  {
    label: 'Negative air, which is the part that actually works',
    body:  'A machine in the kitchen window pulling air out of the containment through a HEPA filter, so the work area is at lower pressure than the house and dust does not drift under the plastic. Containment without negative air is a curtain. It runs on working days and it is not silent — about the volume of a bathroom fan.',
  },
  {
    label: 'Floor protection, all the way to the door we use',
    body:  'Adhesive film on carpet, hardboard on wood, and a runner along whatever route the crew walks from the vehicle to the containment. We pick that route with you on day one and we do not change it without telling you.',
  },
  {
    label: 'Water and power, and how long each is off',
    body:  'The kitchen supply goes off for the duration and you get the dates in advance. House water goes off in whole-house blocks measured in hours, not days, always scheduled and never the same morning we mention it. Kitchen circuits are dead from the day the electrician starts; the rest of the house stays live except for two short outages at the panel.',
  },
  {
    label: 'Quiet hours, and what we do about them',
    body:  'On site 7.30am to 4pm on weekdays. Nothing loud before 8am. Demolition, tile cutting and anything with a chop saw happen in the middle of the day, and if you work from home tell us on day one and we will put the loud work in blocks rather than spread it through the afternoon.',
  },
  {
    label: 'Which bathroom the crew uses',
    body:  'One that you nominate, on day one, and we put a runner to it and a supply of our own hand towels. If you would rather we did not use one at all, say so and we will arrange something. It is a fair thing to want and nobody will be offended.',
  },
  {
    label: 'The dog, the cat and the front door',
    body:  'The door is open while material comes in, which is a real risk to a cat with opinions. Tell us what lives here and we will work out the plan on day one — a closed room, a sign on the door, a check before anyone opens it. We would rather have this conversation than the other one.',
  },
  {
    label: 'End-of-day cleanup, every day',
    body:  'Tools away, floor swept and vacuumed with a HEPA vacuum inside the containment, the route wiped, and nothing sharp left where a child could reach it. The kitchen will not be clean — it is a construction site — but it will be tidy, and the rest of your house will be as it was that morning.',
  },
  {
    label: 'The end-of-day text, which is Nadia',
    body:  'Every working day, by 5pm: what happened, what did not, who is coming tomorrow and what they need access to. On a day nobody came, you still get the text, and it says why. That last part is the whole thing — the two weeks when nothing happens are only frightening when nobody tells you they are happening.',
  },
];

export const livingNote =
  'None of this is a favour and none of it is a differentiator. It is the job. It is on this page because no remodeler’s website mentions any of it, and because it is the only subject you are actually thinking about at 11pm the night before demolition.';

// ── The two weeks in the middle ─────────────────────────────────────────────
// The schedule told honestly. The fabrication gap is a FIELD, not a claim: lead
// times move constantly and vary by fabricator, so the template ships the row
// and asks the operator to put their own current number in it. A stale week
// count on a live site is worse than none.
export type Phase = {
  title: string;
  what: string;
  household: string;
};

export const phases: Phase[] = [
  {
    title:     'Before we start — cabinets are ordered and are not here yet',
    what:      'Cabinets are the long pole and they are ordered the day the contract is signed, not the week the carpenter is due. Ask us for today’s lead time in writing and we will send it dated; we deliberately do not print a week count on this website, because a number typed in March and read in September is not information.',
    household: 'Nothing is happening in your house yet and that is correct. This is the week to read the shutdown plan and set up the temporary kitchen while you still have a kitchen to cook in.',
  },
  {
    title:     'Week one — demolition and containment',
    what:      'Containment and negative air go up first, then the room comes out. This is the loudest, dustiest and fastest week of the job, and it is the week the house looks worst relative to how much has actually been done.',
    household: 'The sink goes off at the start of this week. This is the day the temporary kitchen has to already be working, not the day you set it up.',
  },
  {
    title:     'Weeks two to three — rough-in, inspection, and the first waiting',
    what:      'Plumbing, electrical and any framing, then a rough-in inspection before anything is closed up. Inspection slots are a morning the city gives you, not one you pick, and a failed detail means a second visit on their calendar.',
    household: 'One or two weekdays in here will have nobody in the house. Those are inspection days and days waiting on one. They are on the schedule you were given and they are on the strips above.',
  },
  {
    title:     'Weeks three to four — drywall, paint and floor',
    what:      'Close up, tape, sand, prime and paint before cabinets go in, because painting around a finished kitchen is slower and worse. Floor goes down under the cabinets where the material allows it.',
    household: 'The dustiest days after demolition are the sanding days. We warn you the afternoon before.',
  },
  {
    title:     'Week four or five — cabinets set, and then the gap',
    what:      'Cabinets are set and levelled. Then the countertop fabricator comes to template, and they cannot do it before the boxes are physically in place and level. The template goes away and the stone or quartz is cut to it. That pause is real and unavoidable.',
    household: 'This is the two weeks. Ask us for today’s template-to-install turnaround from our fabricator and we will give you the number in writing at contract; it moves, so we do not hard-code it here.',
  },
  {
    title:     'The gap — what actually happens, and what does not',
    what:      'We do the things that do not need a counter: paint touch-up, trim, the toe kick, hardware, the hood, hanging doors. There will still be whole weekdays with nobody here. That is not abandonment, it is a fabricator’s schedule, and it is the single most misread fortnight in residential remodeling.',
    household: 'You still get the end-of-day text every working day, including the ones where the text says nobody came and here is why. If you can take a week away, this is the week.',
  },
  {
    title:     'Final week — counter in, sink back, punch list',
    what:      'Counter is installed, the sink and dishwasher are plumbed in, the backsplash goes on, the final electrical trim goes in and the final inspection happens.',
    household: 'The sink comes back on the day the counter goes in, usually that afternoon. That is the date on every record above and it is the date we will give you on the first visit.',
  },
  {
    title:     'The last two per cent',
    what:      'Punch list. A drawer that needs adjusting, a caulk line, a switch plate, a piece of trim that was ordered wrong. It always takes longer than it should because it is a dozen small things each waiting on a different person.',
    household: 'We write the punch list with you in the room and we put a date on it. A close-out that drifts for six weeks is the most common complaint about the end of a remodel and it is entirely preventable.',
  },
];

export const leadTimeNote =
  'Two numbers on this page are deliberately not printed: the current cabinet lead time and the current countertop template-to-install turnaround. Both move constantly and both vary by supplier and fabricator, so we quote today’s in writing at contract and again if it changes. A stale week count on a live website is worse than no number at all — it is a promise somebody made to a different customer in a different quarter.';

// ── What is behind a 1926 kitchen wall ──────────────────────────────────────
export type Finding = { title: string; body: string };

export const findings: Finding[] = [
  {
    title: 'Knob-and-tube in the ceiling above',
    body:  'Common in anything wired before about 1935 and not always removed when the rest of the house was updated. It cannot be buried in insulation, it cannot be extended, and if it is live in the ceiling over your kitchen it comes out back to the panel. Usually a few days and an electrician, and it is not optional.',
  },
  {
    title: 'An undersized service with no spare breakers',
    body:  'A 60- or 100-amp service with a full panel, in a kitchen that is about to want a dishwasher, a disposal, a microwave circuit and two counter circuits. Sometimes a sub-panel; sometimes a service upgrade, which brings the utility onto the schedule and the utility is on its own calendar.',
  },
  {
    title: 'Galvanised supply that will not survive being disturbed',
    body:  'Eighty-year-old galvanised pipe is fine until somebody puts a wrench on it. If it is in the wall we are opening, it gets replaced back to something sound rather than reconnected and hoped about. We price this as a contingency item in any house of this age because finding it is not a surprise.',
  },
  {
    title: 'Joists notched out for the old drain',
    body:  'Somebody in 1961 needed the drain to go where the drain went and took half the depth out of three joists to do it. It has been fine for sixty years and it is still wrong, and once the floor is up it is visible and it is ours to deal with. Sistering three joists is a day; an engineer is sometimes a week.',
  },
  {
    title: 'Three layers of flooring, with vinyl asbestos tile at the bottom',
    body:  'Sheet vinyl over hardboard over 9-inch tile is the standard South Minneapolis sandwich. The bottom layer and the mastic under it are presumed to contain asbestos until tested. Abatement is a licensed contractor, on their schedule, with the room to themselves. It cost one of the records above eleven days.',
  },
  {
    title: 'No insulation in the exterior wall',
    body:  'Open a 1920s exterior wall and there is frequently nothing in it. While it is open it is cheap to insulate and air-seal, and in this climate that is the best value available anywhere in the job. It is not in the base price because we do not know it is empty until it is open.',
  },
  {
    title: 'A chimney chase that cannot move',
    body:  'The chase for a long-dead boiler flue, running up through the middle of the only good wall. It can sometimes be removed, which is a roof, a chimney and a structural conversation, and usually it stays and the plan is drawn around it. Knowing which on the first visit is most of what the first visit is for.',
  },
];

export const contingency = {
  title: 'The contingency, and whose money it is',
  body:  'Eight to twelve per cent on a pre-1940 house, higher than you will see quoted on a new-build remodel, and it is yours and not ours. It is spent only against a written, priced item that you see before the work happens, and whatever is left is credited on the final invoice. A contractor who will not tell you what the contingency was spent on has told you something.',
};

export const leadSafeNote = {
  title: 'Lead-safe work is the law here, not a badge',
  body:  'Your house was built before 1978, so this job falls under the EPA’s Renovation, Repair and Painting rule. That is not a certification we chose to collect — it is a federal requirement that the firm be certified, that a certified renovator be on site, and that lead-safe work practices be used on any disturbance of painted surfaces. It means containment, wet methods, HEPA vacuums, a cleaning verification at the end, and a pamphlet you have to be given before work starts. A remodeler who does not mention it in a South Minneapolis bungalow is either not certified or not telling you, and both are the same problem.',
};

// ── Who is in your house ────────────────────────────────────────────────────
export const employedCrew = [
  'Demolition, containment and daily clean',
  'Framing, headers and structural repair',
  'Cabinet setting and finish carpentry',
  'Trim, doors and hardware',
  'Punch list and close-out',
];

export const namedSubs = [
  { trade: 'Electrician', detail: 'Licensed Minnesota electrical contractor, pulls their own permit, on their own licence. Same two people on every job we run.' },
  { trade: 'Plumber',     detail: 'Licensed Minnesota plumbing contractor, pulls their own permit. The trades are separately licensed and separately permitted in this state and that is a good thing.' },
  { trade: 'Tile setter', detail: 'One person, self-employed, twenty-two years. He does not work for us, he works with us, and he is booked around your job rather than the other way round.' },
  { trade: 'Countertop fabricator', detail: 'Templates, fabricates and installs. The gap in the middle of your job is their calendar and we will tell you their current turnaround in writing.' },
  { trade: 'Abatement contractor', detail: 'Licensed, and only when a floor test comes back positive. They have the room to themselves for the days they are in it.' },
];

export const whoNote =
  'Everybody on our payroll is an employee, not day labour, and everybody who comes into your house — employee or subcontractor — has had a background check. We will tell you their names before they arrive and Nadia will introduce them on the day.';

export const keyPolicy = {
  title: 'The key, and what happens to it afterwards',
  body:  'One key, held by Nadia, logged in and out, and never copied. If you would rather use a lockbox we will use a lockbox and you set the code. On the last day the key comes back to you in person or the lockbox goes away with us, and if you have a smart lock you change the code that afternoon — we will remind you to, because most people forget and then wonder for two years.',
};

// ── South Minneapolis, and how far we go ────────────────────────────────────
export const serviceZones = [
  {
    zone:   'The core — where most of our work is',
    detail: 'Ten minutes from the shop',
    areas:  ['Longfellow', 'Standish', 'Hiawatha', 'Nokomis', 'Cooper', 'Howe'],
    note:   'The 1910s–1930s bungalow and story-and-a-half belt. We know what is behind these walls because we have been behind a hundred of them.',
  },
  {
    zone:   'South Minneapolis, the rest of it',
    detail: 'Twenty minutes',
    areas:  ['Powderhorn', 'Corcoran', 'Bryant', 'Field', 'Regina', 'Kingfield'],
    note:   'Same housing stock, same decade, same chimney chase in the same place. Duplexes are more common here and they change the plan.',
  },
  {
    zone:   'North of the creek and over the river',
    detail: 'Half an hour',
    areas:  ['Seward', 'Prospect Park', 'Linden Hills', 'Fulton', 'St Anthony Park', 'Merriam Park'],
    note:   'We take this work. St Paul is a different building department with a different inspection cadence, and we will say so on the first visit rather than discover it in week two.',
  },
  {
    zone:   'First-ring suburbs',
    detail: 'Thirty to forty minutes, and the edge',
    areas:  ['Richfield', 'St Louis Park', 'Edina (east)', 'Roseville', 'Falcon Heights', 'Golden Valley'],
    note:   'Post-war housing rather than pre-war, which is a different set of surprises — usually fewer. Beyond this the one-crew promise stops working and we will say no.',
  },
];

export const areaNote =
  'Bloomington, Eagan, Plymouth, Woodbury and everything past them is a no, and the reason is arithmetic rather than snobbery: one crew, one kitchen, and a lead carpenter who is in your house every working day cannot also be forty-five minutes away in traffic. If you are outside the map, tell us anyway and we will give you a name in your own suburb.';

// ── What you can check ──────────────────────────────────────────────────────
// No awards, no project counts, no "500+ kitchens", no aggregateRating.
export const credentials = [
  {
    title:     'Minnesota Residential Building Contractor licence',
    stat:      'BC555-0173',
    statLabel: 'Department of Labor and Industry',
    desc:      'Minnesota licenses residential building contractors through the Department of Labor and Industry, and the licence number is checkable on their public lookup in about thirty seconds. Plumbing and electrical are separately licensed and separately permitted by the trades themselves, which is why our plumber and our electrician pull their own permits on their own licences rather than under ours.',
  },
  {
    title:     'EPA Lead-Safe Certified Firm',
    stat:      'Required',
    statLabel: 'not optional, in a pre-1978 house',
    desc:      'Every house we work in was built before 1978, so the Renovation, Repair and Painting rule applies to all of it. A certified firm, a certified renovator on site, lead-safe work practices, and a cleaning verification at the end. This is on the list of things you can check rather than the list of things we are proud of, because it is the law.',
  },
  {
    title:     'Insurance and workers’ compensation, as numbers',
    stat:      '$2M / $4M',
    statLabel: 'per occurrence / aggregate',
    desc:      'General liability at two million per occurrence and four million aggregate, plus workers’ compensation on every employee. Ask any contractor for a certificate naming you, and ask specifically about workers’ comp: an uninsured injury in your house is a claim against your homeowner’s policy, and that is the sentence nobody says out loud.',
  },
  {
    title:     'Two years on the work, in writing',
    stat:      '24 months',
    statLabel: 'from the final inspection',
    desc:      'Two years on workmanship from the date of the final inspection, with manufacturer warranties on cabinets and appliances registered in your name at close-out. The close-out folder has the warranty documents, the paint colours and codes, and photographs of every wall taken before the drywall went on — which is the single most useful thing anybody has ever handed us and we now hand it to you.',
  },
];

// ── What the neighbours say ─────────────────────────────────────────────────
// Each review is tagged with the neighbourhood and the scope, because on this
// job the referral is literally a neighbour. No star ratings and no
// aggregateRating: the reviews are fictional, and a star rating with nothing
// behind it is what search engines penalise.
export type Review = { name: string; neighbourhood: string; scope: string; quote: string };

export const reviews: Review[] = [
  {
    name:          'Marit Halvorsen',
    neighbourhood: 'Longfellow',
    scope:         'Wall out · 8 weeks',
    quote:         'They told us on a Tuesday afternoon that the header was wrong and it would be seven working days, and it was seven working days. I had braced for the version where you find out in week eleven that it has been eleven weeks. Knowing the number on the day is worth more than the number being small.',
  },
  {
    name:          'Desmond Achebe',
    neighbourhood: 'Standish',
    scope:         'Keep the layout · 3 weeks',
    quote:         'Eleven days without a sink, and they said eleven days before we signed anything. My wife had the laundry tub set up with a drying rack on day one because we knew exactly what was coming. Nobody had ever given us a number like that in advance.',
  },
  {
    name:          'Ruth Vandersteen',
    neighbourhood: 'Nokomis',
    scope:         'Move the plumbing · 8.5 weeks',
    quote:         'Ours is the one on their website that ran a week and a half over. I want to say that the fact it is on their website is the reason I would use them again. The floor was asbestos and there was nothing to be done about it, and they put it in public rather than hoping we would not mention it.',
  },
  {
    name:          'Priya Raghunathan',
    neighbourhood: 'Powderhorn',
    scope:         'Keep the layout · 5 weeks · duplex',
    quote:         'I have a tenant upstairs and I was more worried about her than about me. She lost water for four hours, on a morning she had known about for over a week, and her stair was never dusty. That is the whole review.',
  },
  {
    name:          'Tomas Beckendorf',
    neighbourhood: 'Hiawatha',
    scope:         'Move the plumbing · 6.5 weeks',
    quote:         'We changed the tile in week three and it cost us nine days. They told us it would cost us nine days before we confirmed it, in an email, with the new finish date in the same paragraph. I have no complaint and I would have had a large one if the email had not existed.',
  },
  {
    name:          'Ingrid Sawatzky',
    neighbourhood: 'Field',
    scope:         'Talked out of it · no job',
    quote:         'Sam spent an hour telling me why moving my sink was a bad idea in this house and then quoted me for doors, counters, paint and lighting instead. It was about a third of what I had been braced for. I have sent him three neighbours since and none of them were me.',
  },
];

// ── FAQ ─────────────────────────────────────────────────────────────────────
// Rendered inside the contact section rather than as an eleventh h2, because the
// brief fixes the h2 list at ten and a FAQPage still has to exist.
export const faqs = [
  {
    q: 'How long will I actually be without a kitchen sink?',
    a: 'Eleven to thirty-seven days on the six jobs published on this page, and which end of that you land on is decided by the scope band rather than by us. Keep the layout is around a fortnight. Moving plumbing is three to five weeks. Taking a wall out is three to five weeks as well, because the sink is off from demolition until the countertop is installed either way. You will get a date on the first visit and you will get it again in writing at contract, and if it moves you will be told the afternoon it moves.',
  },
  {
    q: 'Why does nobody come for days in the middle of my job?',
    a: 'Because the countertop cannot be templated until the cabinets are physically set and level, and once it is templated it goes away to be cut. Nothing that needs a counter can happen while it is gone, and there are only so many trim and touch-up days to fill the gap with. Every record on this page publishes its own "nobody came" count with the reason next to each one. It is the single most misread fortnight in remodeling and it is entirely normal.',
  },
  {
    q: 'Can we stay in the house?',
    a: 'Yes, and almost everybody does. That is what this whole company is organised around. You will need a temporary kitchen, a plan for washing up, and a tolerance for a dining room that is not a dining room for a while. The one week worth being away for, if you can take it, is the demolition week or the sanding days. Our shutdown plan sets all of it out.',
  },
  {
    q: 'What about the dust, honestly?',
    a: 'Containment plus negative air is very good and it is not perfect. The room on our side of the plastic is a construction site. Soft furnishings in the next room will need cleaning at the end. Fine dust finds forced-air ducts, so we tape the kitchen registers and we recommend a filter change when we are done. The rest of the house stays genuinely clean, and the dining room does not.',
  },
  {
    q: 'Do you do bathrooms?',
    a: 'Yes, priced at twenty-two to forty-five thousand and scheduled as its own job, usually after the kitchen rather than beside it. We will not run both at once. A bath in a two-bathroom house is an inconvenience and a kitchen is a crisis, and taking both away from a household at the same time is how people end up moving out of their own remodel.',
  },
  {
    q: 'Will you build an addition, or do our whole house?',
    a: 'No to both, and it is not modesty. An addition is footings, foundation, framing, a structural permit and a roof tie-in, built outside the envelope while your kitchen keeps working — a different trade with a different schedule. A whole-house gut means you move out, which removes the entire problem we exist to solve. Hire a general contractor for either, and ask us for two names.',
  },
  {
    q: 'Is lead paint really an issue in my house?',
    a: 'Your house was built before 1978, so yes, legally. The EPA’s Renovation, Repair and Painting rule requires a certified firm, a certified renovator on site, lead-safe work practices and a cleaning verification, and it requires that you be given a pamphlet before work starts. It is not a badge, it is the law, and a remodeler working in a South Minneapolis bungalow who does not raise it has told you something.',
  },
  {
    q: 'What is an allowance and how do I know yours are honest?',
    a: 'An allowance is a number carried in the contract for something you have not picked yet — appliances, tile, plumbing fixtures, lighting, countertop. A low allowance is how a cheaper-looking quote wins and then is not cheaper. Ask any contractor which three specific products their tile allowance was built from. If the answer is a shrug, the allowance is a marketing number. Ours come with the three products written down.',
  },
  {
    q: 'How much of the number is cabinets?',
    a: 'Usually between a third and a half of the whole job, and the spread inside "cabinets" is wider than the spread between two of our scope bands. Stock, semi-custom and made-for-the-room are three genuinely different products at three genuinely different prices, and in a 1920s kitchen where nothing is square and the chimney chase is in the way, the made-for-the-room option buys usable inches that the other two cannot.',
  },
  {
    q: 'Can we start in January?',
    a: 'Yes, and it is a different job from the same kitchen in July. No grill for the whole of it, which takes an option off the temporary-kitchen plan. A basement laundry tub at 52 degrees. A fabricator whose delivery week has weather in it. We plan a winter start differently and we will walk you through the differences before you book the date rather than after.',
  },
];
