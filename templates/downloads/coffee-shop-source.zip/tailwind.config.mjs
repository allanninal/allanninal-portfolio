/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,mdx}'],
  theme: {
    extend: {
      colors: {
        // Cream/parchment base — light, warm, inviting
        parchment: {
          50:  '#FDFAF4',
          100: '#FAF5E8',
          200: '#F4EBD4',
          300: '#EAD9BA',
          400: '#D4B98A',
        },
        // Espresso brown — deep, rich, legible
        espresso: {
          900: '#1C0F07',
          800: '#2E1A0E',
          700: '#3D2314',
          600: '#5C3520',
          500: '#7A4A2E',
          400: '#9C6344',
        },
        // Terracotta-rust accent — distinct from olive-gold (Day 22)
        rust: {
          600: '#B8441A',
          500: '#B24A1B',
          400: '#D96533',
          300: '#E8845A',
        },
        // Stone — neutral mids
        stone: {
          200: '#E6DDD0',
          400: '#756857',
          600: '#6A5E51',
        },
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        sans: ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
