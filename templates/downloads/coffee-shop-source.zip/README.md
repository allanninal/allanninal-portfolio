# Day 23 — Coffee Shop Template

**Live demo:** https://example.com/

Part of the [365 Templates](https://example.com/templates) project — one free Astro template shipped every day.

---

## What's in the box

Light parchment + terracotta-rust, Fraunces + Plus Jakarta Sans. Specialty indie cafe: sensory hero, direct-trade bean origins (Ethiopia + Colombia), curated 6-drink menu, daytime hours, founder story, gallery, location, bean subscription. CafeOrCoffeeShop JSON-LD.

**Persona:** Mansa Filter. All business data is fictional — replace it in `src/data/menu.ts` before you ship.

**Page sections** (the `<h2>`s on the homepage, in order):

- Our beans, their story
- The menu is short. Intentionally.
- Come as you are, any day but Monday.
- Born from a road trip to Yirgacheffe.
- Come see for yourself.
- Find us on NW 23rd.
- Mansa, delivered to your door.

**Additional pages:** `/menu/`

---

## Stack

- [Astro](https://astro.build) 4.x (static output)
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [Fraunces](https://fonts.google.com/specimen/Fraunces) + [Plus Jakarta Sans](https://fonts.google.com/specimen/Plus+Jakarta+Sans) via `@fontsource`
- Playwright + axe-core for accessibility testing
- Lighthouse CI (≥ 95 all categories)

---

## Getting started

```bash
git clone https://github.com/<you>/<your-fork>.git
cd templates/coffee-shop
npm install

npm run dev      # dev server
npm run build    # production build
```

### Environment variables

| Variable | Purpose | Required |
|----------|---------|----------|
| `PUBLIC_SITE_URL` | Canonical site URL | No (defaults to `https://example.com`) |
| `PUBLIC_BASE_PATH` | Base path for asset URLs (e.g. `/coffee-shop/`) | No |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables the download bar + analytics (author's deploy only) | No |
| `PUBLIC_EDITION` | Set to `pro` to activate the Pro edition UI | No |

### Customization

1. Edit `src/data/menu.ts` — every string shown on the page lives there.
2. Replace `public/og-image.svg` and `public/favicon.svg` with your own brand marks.
3. Adjust the palette via the CSS custom properties in `src/styles/`.
4. Point any form `action` at your own endpoint (Formspree, Basin, your backend).

---

## Running tests

```bash
npm run test            # Playwright suite
npm run test:a11y       # axe WCAG 2.1 AA
npm run test:links      # link integrity
npm run test:lighthouse # Lighthouse ≥ 95 all categories
```

Tests run against system Google Chrome — no `playwright install` needed.

---

## License

MIT — free for personal and commercial use, under the repository’s root [LICENSE](../../LICENSE).

Made by [Allan Niñal](https://example.com) · [LinkedIn](#) · Day 23 of 365
