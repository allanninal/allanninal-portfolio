// Menu data — shared by MenuSection (homepage) and the Pro /menu page.
export const drinks = [
  { name: 'Mansa Filter', desc: 'Rotating single-origin pour-over, brewed to order on the Kalita Wave. Ask your barista what\'s on today.', price: '$5', badge: 'Pour-over' },
  { name: 'Single Origin Espresso', desc: 'A double shot of whatever we\'re proud of this week. Ask for the tasting notes — we\'ll tell you everything.', price: '$4', badge: 'Espresso' },
  { name: 'Oat Flat White', desc: 'Our Huila espresso pulled long, poured into perfectly steamed oat milk. Silky, nutty, not overpowering.', price: '$6', badge: 'Milk drink' },
  { name: 'Honey Lavender Latte', desc: 'House-made lavender honey syrup, double espresso, whole milk. Floral without being sweet.', price: '$6.50', badge: 'Signature' },
  { name: 'Cascara Fizz', desc: 'Cold-brewed cascara (coffee-cherry tea), a splash of orange bitters, topped with sparkling water. Caffeine-light.', price: '$5.50', badge: 'Cold' },
  { name: 'Cold Brew Tonic', desc: 'Our 20-hour cold brew cut with tonic water and a lime wheel. Bitter, bright, refreshing.', price: '$6', badge: 'Cold' },
];

export const food = [
  { name: 'Cardamom Croissant', price: '$4', note: 'Baked daily by Petite Chou Bakery' },
  { name: 'Avocado Toast', price: '$9', note: 'Sourdough · smoked salt · lemon · chilli flakes' },
  { name: 'Banana Walnut Loaf', price: '$4.50', note: 'Slice · house recipe · no refined sugar' },
  { name: 'Seasonal Fruit Bowl', price: '$7', note: 'Ask what\'s fresh today' },
  { name: 'Almond Frangipane Tart', price: '$5', note: 'Delivered Tue & Fri from Petite Chou' },
];
