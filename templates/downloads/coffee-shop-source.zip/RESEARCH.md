# Day 23 — Coffee Shop — Niche Research

## Persona
**Mansa Coffee** — an indie specialty coffee shop in a walkable urban neighbourhood (Portland, OR). Founded in 2019 by Amara Osei and her brother Kwesi after two years sourcing beans directly from smallholder farmers in Ethiopia's Yirgacheffe zone and Colombia's Huila department. The name "Mansa" means "king / chief" in Manding — a nod to their West African heritage and a statement that coffee, done right, is royalty. The space is warm and unhurried: exposed white brick, hanging plants, second-hand wooden tables, a copper espresso machine named "Goldie."

Conversion goal: visit in person OR subscribe to the monthly bean bag.

## Visual Identity
- **Palette family:** Parchment / cream ground — LIGHT background, completely opposite register from Day 22 (dark olive-charcoal).
  - Background: warm parchment `#FAF5E8` (cream — NOT white, NOT grey)
  - Card surfaces: `#F4EBD4` (slightly warmer card bg)
  - Hero section: deep espresso `#2E1A0E` (dark band for hero contrast)
  - Accent: terracotta-rust `#C9531F` — warmer than orange, less saturated than Red. NOT olive-gold (Day 22), NOT teal (Day 18), NOT emerald (Day 20), NOT coral (Day 4), NOT violet (Day 2), NOT lime (Day 3).
  - Text on light: `#2E1A0E` (espresso — full opaque, no transparency modifiers)
  - Text muted: `#6B5F52` (stone, legible)
  - Text faint: `#A89B8A`
  - Border: `#EAD9BA`

- **Density:** Spacious — generous vertical rhythm. Coffee shops are about slowing down. NOT bento-dense (Day 2), NOT compact editorial (Day 9). Wide breathing room, large imagery zones, unhurried reading pace.

- **Light metaphor:** Daylight through a café window. Warm, sun-bleached paper. NOT candlelit (Day 22), NOT studio dark (Day 19), NOT futurist dark (Day 13).

## Typography
- **Display/Headings:** **Fraunces** — a "slow" optical-size serif with italic flair. The `opsz` axis makes it sing at large sizes. Completely distinct from:
  - Libre Baskerville (Day 22 — sturdier, more formal)
  - Cormorant Garamond (Days 15 + 21 — thinner, more decorative)
  - Playfair Display (Day 17)
  - Newsreader (Day 5)
  - Lora (Day 11)
  - Source Serif 4 (Day 9)
  Fraunces reads as artisanal, crafted, unhurried — exactly right for specialty coffee.

- **Body/UI:** **Plus Jakarta Sans** — geometric humanist sans. Clean, modern, slightly warmer than Inter. Distinct from:
  - Mulish (Day 22)
  - DM Sans (Days 4 + 16)
  - Manrope (Day 7)
  - Work Sans (Day 11)
  - Public Sans (Day 18)
  - Plus Jakarta Sans is FRESH in the roadmap.

## Schema.org
- `CafeOrCoffeeShop` (LocalBusiness subtype — distinct from `Restaurant` on Day 22)
- `servesCuisine: "Coffee"` and `servesCuisine: "Specialty Coffee"`
- `priceRange: "$$"`
- `acceptsReservations: false` — coffee shops don't take reservations
- `openingHoursSpecification` — daytime hours only (7:00–17:00 weekdays, 8:00–16:00 weekends)
- `aggregateRating` — 4.8/5 from 312 reviews
- NO `Menu` schema — curated drink list is too small
- Optional: `Product` for bean subscriptions
- `Person` — co-founders Amara and Kwesi Osei

## Sections (single-page scroll)
1. **Hero** — Dark espresso band. "We open at 7." Large Fraunces display. Sensory tagline. Two CTAs: "Find us" + "Subscribe to our beans."
2. **Our Beans** — Origin story section. Yirgacheffe (Ethiopia) + Huila (Colombia) sourcing. Farm name, farmer name, roast profile. Direct-trade philosophy.
3. **What We Serve** — Short curated drink list (6 signature drinks) + light food sidebar (pastries/toasts). NOT a tabbed multi-section menu (differentiates from Day 22).
4. **Hours** — Simple 2-column table. Daytime-only. Weekday / Weekend split. Closed Mondays (many indie cafes close Monday).
5. **Our Story** — Founders Amara + Kwesi. Why this neighbourhood. What the space means. The copper espresso machine named Goldie.
6. **Gallery** — The space, the bar, a latte art close-up, the regulars. SVG placeholder art-direction.
7. **Location** — Address, transit, parking. No reservation CTA (coffee shops don't take reservations).
8. **Bean Subscription** — Monthly bag delivery. Two tiers: Single Origin ($22/mo) + The Blend ($17/mo). CTA to subscribe.
9. **Footer** — Shop name, short nav, contact email, Instagram handle (placeholder).

## Differentiation from all prior days
- Day 22 (restaurant-general): DARK olive-charcoal ground vs OUR LIGHT parchment. Olive-gold accent vs our terracotta-rust. Libre Baskerville vs Fraunces. `Restaurant` schema vs `CafeOrCoffeeShop`. Multi-tab menu vs curated short list.
- Day 21 (wedding): blush/ivory vs our warm parchment (different hue family — theirs cool blush, ours warm ochre-adjacent). Cormorant vs Fraunces. Event vs LocalBusiness.
- Day 20 (conference): dark emerald on near-black. Opposite register.
- Day 18 (course): deep teal + cream — cream ground is similar but teal accent is completely different from terracotta-rust; schema type and page shape entirely different.
- Day 15 (designer-portfolio): terracotta accent on light — however light-grey background vs our warm parchment, Archivo Black + Cormorant vs Fraunces + Plus Jakarta Sans, portfolio vs LocalBusiness. The terracotta hue family has a slight overlap but the density (designer = high-density work grid vs coffee = spacious editorial), typography, schema, and copy are all different.
- No prior day uses Fraunces or Plus Jakarta Sans.
- No prior day uses `CafeOrCoffeeShop` schema.

## Conversion logic
Primary: Walk in (Hours + Location section — always easy to find).
Secondary: Subscribe to beans (Bean Subscription section with two plans).
No OpenTable / no reservations — correct for the category.

## Realistic placeholder copy
- Shop: Mansa Coffee
- Address: 428 NW 23rd Avenue, Portland, OR 97210
- Phone: (503) 555-0183
- Email: hello@mansacoffee.com
- Instagram: @mansacoffee
- Founded: 2019
- Ethiopia farm: Konga Cooperative, Yirgacheffe — natural process, stone-fruit + floral
- Colombia farm: Finca La Serranía, Huila — washed, dark chocolate + citrus finish
- Farmers: Desta Bekele (Ethiopia), Carlos Munera (Colombia)
- Signature drinks: Mansa Filter ($5), Single Origin Espresso ($4), Oat Flat White ($6), Honey Lavender Latte ($6.50), Cascara Fizz ($5.50), Cold Brew Tonic ($6)
- Food: Cardamom Croissant ($4), Avocado Toast ($9), Banana Walnut Loaf ($4.50)
- Hours: Mon closed, Tue–Fri 7:00–17:00, Sat–Sun 8:00–16:00
- Bean subscription: Single Origin $22/mo, House Blend $17/mo
