import { test, expect } from '@playwright/test';

test.describe('Coffee Shop — smoke tests', () => {
  test('home page loads with shop name in title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Mansa Coffee/i);
    // Use heading role + level 1 to avoid strict-mode collision (name appears in nav + hero + footer)
    await expect(page.getByRole('heading', { level: 1 })).toContainText('7');
  });

  test('navigation links are present', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Main navigation' });
    // Use exact label "Our Beans" to avoid strict-mode collision with "Subscribe to beans"
    await expect(nav.getByRole('link', { name: 'Our Beans' })).toBeVisible();
    // exact: true — Pro nav also adds "Full Menu", which would collide in strict mode
    await expect(nav.getByRole('link', { name: 'Menu', exact: true })).toBeVisible();
    await expect(nav.getByRole('link', { name: 'Hours' })).toBeVisible();
    await expect(nav.getByRole('link', { name: 'Location' })).toBeVisible();
  });

  test('hero section is visible with sensory copy', async ({ page }) => {
    await page.goto('/');
    const hero = page.getByRole('region', { name: /Hero/i });
    await expect(hero).toBeVisible();
    await expect(hero.getByRole('heading', { level: 1 })).toContainText('7');
    // Check for Portland mention
    await expect(hero).toContainText('Portland');
  });

  test('beans section shows two origin countries', async ({ page }) => {
    await page.goto('/');
    const beansSection = page.locator('#beans');
    await expect(beansSection.getByRole('heading', { level: 2 })).toContainText('beans');
    // Ethiopia and Colombia origins
    await expect(beansSection.getByRole('article', { name: /Ethiopia/i })).toBeVisible();
    await expect(beansSection.getByRole('article', { name: /Colombia/i })).toBeVisible();
  });

  test('beans section shows farmer names', async ({ page }) => {
    await page.goto('/');
    const beansSection = page.locator('#beans');
    // Use locator with exact text to avoid strict-mode collisions in dl/dd elements
    await expect(beansSection.locator('dd', { hasText: 'Desta Bekele' }).first()).toBeVisible();
    await expect(beansSection.locator('dd', { hasText: 'Carlos Munera' }).first()).toBeVisible();
  });

  test('menu section shows signature drinks', async ({ page }) => {
    await page.goto('/');
    const menuSection = page.locator('#menu');
    await expect(menuSection.getByRole('heading', { level: 2 })).toBeVisible();
    // Check signature drinks exist
    await expect(menuSection.getByText('Mansa Filter')).toBeVisible();
    await expect(menuSection.getByText('Honey Lavender Latte')).toBeVisible();
    await expect(menuSection.getByText('Cold Brew Tonic')).toBeVisible();
  });

  test('menu section shows food items', async ({ page }) => {
    await page.goto('/');
    const menuSection = page.locator('#menu');
    await expect(menuSection.getByText('Cardamom Croissant')).toBeVisible();
    await expect(menuSection.getByText('Avocado Toast')).toBeVisible();
  });

  test('hours section shows Monday closed and daytime-only hours', async ({ page }) => {
    await page.goto('/');
    const hoursSection = page.locator('#hours');
    await expect(hoursSection.getByRole('heading', { level: 2 })).toBeVisible();
    // Should show "Closed" for Monday — scope to table cell to avoid strict-mode collision
    await expect(hoursSection.locator('td', { hasText: 'Monday' }).first()).toBeVisible();
    await expect(hoursSection.locator('td', { hasText: 'Closed' }).first()).toBeVisible();
    // Tuesday hours (multiple cells have this text — use first())
    await expect(hoursSection.locator('td').filter({ hasText: '7:00 – 17:00' }).first()).toBeVisible();
  });

  test('story section shows founders', async ({ page }) => {
    await page.goto('/');
    const storySection = page.locator('#story');
    await expect(storySection.getByRole('heading', { level: 2 })).toBeVisible();
    // Use blockquote footer as the anchor for Amara — appears exactly once there
    await expect(storySection.locator('blockquote footer')).toContainText('Amara Osei');
    // Check Kwesi is mentioned in a paragraph (multiple matches OK — use first())
    await expect(storySection.locator('p', { hasText: 'Kwesi' }).first()).toBeVisible();
  });

  test('gallery section is visible', async ({ page }) => {
    await page.goto('/');
    const gallerySection = page.locator('#gallery');
    await expect(gallerySection.getByRole('heading', { level: 2 })).toBeVisible();
    // The gallery grid is role="group", not role="list": its items are <figure>s,
    // and ARIA forbids role="listitem" on <figure>.
    await expect(gallerySection.getByRole('group', { name: /Photo gallery/i })).toBeVisible();
  });

  test('location section shows address', async ({ page }) => {
    await page.goto('/');
    const locationSection = page.locator('#location');
    await expect(locationSection.getByRole('heading', { level: 2 })).toBeVisible();
    // Address in the address element
    await expect(locationSection.locator('address')).toContainText('428 NW 23rd Avenue');
    await expect(locationSection.locator('address')).toContainText('Portland');
  });

  test('location section has no reservations CTA (coffee shop convention)', async ({ page }) => {
    await page.goto('/');
    const locationSection = page.locator('#location');
    // Coffee shops don't take reservations — no OpenTable link
    const openTableLink = locationSection.getByRole('link', { name: /OpenTable/i });
    await expect(openTableLink).toHaveCount(0);
    // Should mention walk-in
    await expect(locationSection).toContainText('walk-in');
  });

  test('subscribe section shows two bean plans', async ({ page }) => {
    await page.goto('/');
    const subscribeSection = page.locator('#subscribe');
    await expect(subscribeSection.getByRole('heading', { level: 2 })).toBeVisible();
    // Two plan headings scoped to this section
    await expect(subscribeSection.getByRole('heading', { name: 'Single Origin' })).toBeVisible();
    await expect(subscribeSection.getByRole('heading', { name: 'House Blend' })).toBeVisible();
    // Price check — use the large price span (exact: true to avoid collision with CTA link)
    await expect(subscribeSection.getByText('$22', { exact: true })).toBeVisible();
    await expect(subscribeSection.getByText('$17', { exact: true })).toBeVisible();
  });

  test('JSON-LD CafeOrCoffeeShop schema is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasCafe = false;
    let hasOpeningHours = false;
    let hasRating = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('CafeOrCoffeeShop')) hasCafe = true;
      if (content && content.includes('openingHoursSpecification')) hasOpeningHours = true;
      if (content && content.includes('AggregateRating')) hasRating = true;
    }
    expect(hasCafe).toBe(true);
    expect(hasOpeningHours).toBe(true);
    expect(hasRating).toBe(true);
  });

  test('JSON-LD has acceptsReservations false and servesCuisine', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasNoReservations = false;
    let hasCuisine = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('"acceptsReservations": false')) hasNoReservations = true;
      if (content && content.includes('servesCuisine')) hasCuisine = true;
    }
    expect(hasNoReservations).toBe(true);
    expect(hasCuisine).toBe(true);
  });

  test('JSON-LD has no Restaurant type (should be CafeOrCoffeeShop)', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    for (const script of scripts) {
      const content = await script.textContent();
      if (content) {
        // Should NOT have plain "Restaurant" type — this differentiates from Day 22
        expect(content).not.toMatch(/"@type":\s*"Restaurant"/);
      }
    }
  });

  test('no github.com deep-links in page source', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const deepLinks = html.match(/github\.com\/allanninal\/templates[^"'\s]*/g);
    expect(deepLinks).toBeNull();
  });

  test('footer shows shop contact info', async ({ page }) => {
    await page.goto('/');
    const footer = page.getByRole('contentinfo');
    await expect(footer).toContainText('Mansa Coffee');
    await expect(footer).toContainText('Portland');
    await expect(footer).toContainText('hello@mansacoffee.com');
  });
});
