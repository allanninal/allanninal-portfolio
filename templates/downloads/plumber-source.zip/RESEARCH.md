# Day 69 — Plumber: Niche Research

## Slug
`plumber`

## Sprint context
Day 69 is the FIRST template in Sprint 3 trade services. This sprint pivots from fitness/wellness (days 60–68) into "boring-but-lucrative" local trade businesses. The plumber template must establish a strong visual and structural base for the entire trade-services sub-sprint (days 69–90).

## Differentiation from Days 1–68

### Sprint 3 fitness/wellness taken (days 60–68)
| Day | Template | Palette | Fonts | Mode |
|-----|----------|---------|-------|------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 | dark |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira | dark |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Championship Red #EF4444 + Gold | Black Ops One + Rubik | dark |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 + Warm Clay #A05540 | EB Garamond + Quicksand | light |
| 64 | pilates-studio | Cool Stone #F5F4F1 + Deep Ocean Slate #2B5E7B | Prata + Fira Sans | light |
| 65 | dance-studio | Deep Stage Ink #0C0E18 + Rose Crimson #C4315A + Gold #D4A054 | Josefin Sans + Nunito Sans | dark |
| 66 | climbing-gym | Chalk #F6F5F2 + Summit Forest #1B6E3F + Route Ochre #6B4A1F | Barlow Condensed + DM Sans | light |
| 67 | martial-arts-dojo | Iron Night #090A12 + Tournament Blue #1C58E0 + Gold #D4AF37 | Oswald + Inter | dark |
| 68 | personal-trainer | Near-White #FAFAFA + Violet #7C3AED + Deep Purple-Black #0F0A1E | Syne + Lexend | light |

### Prior navies/blues used in days 1–68
- Cobalt #2563EB (day 6) — bright mid-blue
- Deep Ocean Slate #2B5E7B (day 64) — teal-navy
- Tournament Blue #1C58E0 (day 67) — vibrant mid-blue

### Why plumber is distinct

**Day 69 (plumber)** is the trade-services archetype and must be immediately readable as "professional local trade" — not fitness, not tech, not food/beverage. Key differentiators:

1. **Trade-services niche** — First template in this category. Hero positioning around trust (licensing, insurance, years of experience) rather than aspiration or transformation.

2. **Emergency prominence** — Plumbing's #1 use case is emergencies. A persistent red emergency bar at the very top of the page with a tel: link is unique among all 68 prior templates. No fitness or food template needed this.

3. **Service Area section** — A neighborhood/zip list organized by coverage zone is unique to local service businesses. No prior template has this.

4. **Licensing/credentials framing** — "Master Plumber License #NC-MP-48293" and "Licensed & Insured & Bonded" trust badges are specific to licensed trades. Different from gym certifications or chef accolades.

5. **Upfront/flat-rate pricing framing** — Trade-specific. Positioning around price transparency (no surprises) is a trade-services trust signal, not used in fitness or food.

6. **Deep Water Navy + Safety Orange** — Brand-new palette for day 69:
   - Navy `#0B2559`: Deeper and more saturated than Tournament Blue (#1C58E0), Deep Ocean Slate (#2B5E7B), and Cobalt (#2563EB). This is a midnight/nautical navy that reads as "deep water pipe" and signals trust/authority in the trade context.
   - Orange `#F97316` (Orange-500): Visual accent for pipe/emergency motifs. Brighter and more vivid than Electric Orange (#EF4900, day 60). Used decoratively only.
   - Emergency Red `#DC2626`: Alert-specific, used only for the emergency bar and emergency CTA. Not the primary brand color.
   - Background: Slate-50 `#F8FAFC` — slightly cooler and crisper than yoga's warm linen, pilates's cool stone, climbing's chalk. The cool undertone reinforces "water/pipe."

7. **Fonts: Sora + Plus Jakarta Sans** — Both FIRST USE in the 365 library:
   - **Sora**: Modern, geometric, slightly technical. Not a sport/fitness font. Not editorial. Reads as "professional service" — similar visual weight to Poppins but more structured. Perfect for trade headings.
   - **Plus Jakarta Sans**: Technical, highly legible, professional. Designed for clarity at all scales. Great for service descriptions, pricing details, area lists.

## Design decisions

### Palette: Deep Water Navy + Safety Orange (light-default, navy hero)

| Token | Value | Use | Contrast |
|-------|-------|-----|----------|
| `--color-bg` | `#F8FAFC` | Page background (Slate-50) | — |
| `--color-bg-alt` | `#EFF6FF` | Alternate section bg (Blue-50, water feel) | — |
| `--color-surface` | `#FFFFFF` | Card surfaces | — |
| `--color-accent` | `#0B2559` | CTA buttons | White on this: 18.3:1 ✓✓✓ |
| `--color-accent-hover` | `#1E3A8A` | Button hover state | White on this: 10.7:1 ✓✓✓ |
| `--color-accent-text` | `#1E3A8A` | Eyebrow text, link text on light | 9.83:1 on #F8FAFC ✓✓✓ |
| `--color-on-accent` | `#FFFFFF` | Text on navy CTA buttons | 18.3:1 ✓✓✓ |
| `--color-emergency` | `#DC2626` | Emergency bar + emergency CTA | White on this: 5.38:1 ✓ |
| `--color-orange` | `#F97316` | Decorative only (SVG pipes, icon strokes) | Not used as text color |
| `--color-text` | `#111827` | Body text (Gray-900) | 18.1:1 on #F8FAFC ✓✓✓ |
| `--color-text-muted` | `#4B5563` | Secondary text (Gray-600) | 7.22:1 on #F8FAFC ✓✓ |
| `--color-text-faint` | `#374151` | Fine text (Gray-700) | 10.3:1 on #F8FAFC ✓✓✓ |
| `--color-dark-bg` | `#0B2559` | Hero + dark CTA sections | — |
| `--color-dark-text` | `#F1F5F9` | Text on dark hero (Slate-100) | 15.9:1 on #0B2559 ✓✓✓ |
| `--color-dark-muted` | `#93C5FD` | Muted text on dark hero (Blue-300) | 8.10:1 on #0B2559 ✓✓✓ |

WCAG note: Orange `#F97316` is decorative-only. It is NOT used as text color on any background — its luminance (L=0.325) produces only 2.8:1 against white, failing AA. All structural text uses navy (#0B2559 or #1E3A8A) or gray variants that definitively pass.

### Fonts: Both FIRST USE in 365 library

- **Display: Sora** (`@fontsource/sora`) — Modern geometric sans designed for clarity and professional brand communication. Distinct from: Russo One (blocky/stencil), Anton (ultra-condensed), Syne (art/fashion geometric), Oswald (classic condensed). Sora's slightly humanist terminals make it readable at display sizes without feeling aggressive. Ideal for trade service headings.
- **Body: Plus Jakarta Sans** (`@fontsource/plus-jakarta-sans`) — Designed as a professional, highly legible body font for modern business communications. Distinct from: Lexend (accessibility-first), Fira Sans (technical), DM Sans (minimal), Nunito Sans (rounded). Plus Jakarta Sans has slight geometric structure that pairs perfectly with Sora.

### Persona: Blue Ridge Plumbing

- **Business:** Blue Ridge Plumbing
- **Location:** 4218 Monroe Rd, Charlotte, NC 28205
- **Owner:** Mike Harrington — Owner & Master Plumber
- **License:** NC Master Plumber License #MP-48293
- **Founded:** 2009 (15+ years experience)
- **Phone:** (704) 555-0199 (emergency line too)
- **Email:** landix.ninal@gmail.com (Allan's canonical demo email)
- **Tagline:** "Charlotte's Trusted Master Plumber — Licensed, Insured & Available 24/7"

### Service Area (Charlotte Metro)
Zones:
- **South Charlotte:** Ballantyne, Pineville, Matthews, Steele Creek, Arrowood
- **East Charlotte:** Mint Hill, Monroe Rd, Central Ave, Plaza Midwood
- **North Charlotte:** Huntersville, Cornelius, Davidson, Mooresville
- **West Charlotte:** Gastonia (service calls), Belmont, Mount Holly

Zip codes served: 28201–28285 (Charlotte) plus 28036, 28078, 28031, 28115, 28054, 28056

### Sections

1. **Emergency bar** — Red (#DC2626) full-width banner at very top: "24/7 EMERGENCY LINE — (704) 555-0199"
2. **Sticky header** — White bg, Blue Ridge Plumbing logo, nav links, "Request Service" button, mobile toggle
3. **Hero** — Navy (#0B2559) bg, pipe/water SVG motif, large headline, dual CTAs (Call Now / Request Service), 3 trust badges below CTAs
4. **Trust badge strip** — White bg, 4 horizontal badges: Licensed & Insured | Master Plumber | Same-Day Service | 5-Star Rated
5. **Services grid** — 6 services: Drain Cleaning, Water Heater Installation, Leak Detection, Toilets & Fixtures, Pipe Repair & Repiping, Emergency Plumbing
6. **Why Choose Us** — 4-column layout: Flat-Rate Pricing | Same-Day Availability | 24/7 Emergency | 15+ Years
7. **Service Area** — 4-zone neighborhood list with zip codes
8. **Pricing** — 3 transparent tiers: Service Call ($89), Standard Service, Emergency
9. **Reviews** — 5 Google-style reviews with star ratings
10. **About Owner** — Mike Harrington bio, license credentials, avatar initials (MH), certification chips
11. **FAQ** — 8 questions covering emergency response, pricing, insurance, licensing, common repairs
12. **Contact** — Form (Formspree) + emergency phone + address
13. **Final CTA Band** — Navy bg, "Plumbing emergency? Don't wait." with phone CTA
14. **Footer** — Dark navy, 4-column grid

### Schema.org types
- `Plumber` (extends `LocalBusiness`)
- `LocalBusiness` with `openingHoursSpecification` (24/7)
- `Person` (owner Mike Harrington)
- `Service` × 6 (each plumbing service)
- `FAQPage` + 8 `Question`/`Answer` pairs
- `WebSite`

### Key differentiators from all prior templates
- **vs. personal-trainer (day 68):** Trade service not personal coaching; navy/crisp not violet/near-white; emergency bar not applicable in fitness; service area not relevant to gym; licensing/insurance framing vs. certification framing; Sora+Jakarta not Syne+Lexend
- **vs. fitness-gym-general (day 60):** Trade service not gym; light palette not carbon black; no class schedule; service area map/list not workout types; pipe SVG motif not dumbbell icons
- **vs. all prior dark templates:** Light-default with navy hero — not a pure dark template. The palette is clean, professional, and utility-focused.
