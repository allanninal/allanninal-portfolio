// Blue Ridge Plumbing — configuration data
// Day 69 of the 365-template roadmap

export const plumber = {
  name:        'Blue Ridge Plumbing',
  tagline:     "Charlotte's Trusted Master Plumber — Licensed, Insured & Available 24/7",
  description: 'Licensed & insured master plumbing contractor serving Charlotte, NC and surrounding areas. Drain cleaning, water heaters, leak repair, pipe replacement, and 24/7 emergency service.',
  phone:       '(704) 555-0199',
  phoneHref:   'tel:+17045550199',
  email:       'landix.ninal@gmail.com',
  address:     '4218 Monroe Rd',
  city:        'Charlotte',
  state:       'NC',
  zip:         '28205',
  license:     'NC Master Plumber License #MP-48293',
  licensed:    true,
  insured:     true,
  bonded:      true,
  founded:     2009,
  yearsExperience: 15,
  bookUrl:     'https://linkedin.com/in/allanninal',
  owner: {
    name:     'Mike Harrington',
    title:    'Owner & Master Plumber',
    initials: 'MH',
    bio:      "I started Blue Ridge Plumbing in 2009 after 8 years as a journeyman plumber in the Charlotte metro. I earned my Master Plumber license because I believed homeowners and businesses deserved to work with someone fully accountable for the work — not just a company name, but a licensed professional standing behind every job. In 15 years we've served thousands of Charlotte families.",
  },
  instagram: 'https://www.instagram.com/allan.ninal/',
  facebook:  'https://www.facebook.com/allan.ninal/',
  makerBio: {
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    site:     'https://allanninal.dev',
  },
};

export const site = {
  title:         'Blue Ridge Plumbing — Charlotte NC | Licensed Master Plumber',
  description:   "Charlotte's trusted licensed & insured master plumber. Drain cleaning, water heater installation, leak detection, pipe repair, and 24/7 emergency plumbing service. Upfront flat-rate pricing. Call (704) 555-0199.",
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@allannin',
};

export const services = [
  {
    slug:     'drain-cleaning',
    name:     'Drain Cleaning',
    icon:     'drain',
    tagline:  'Slow or blocked? Fixed fast.',
    desc:     'Kitchen drains, bathroom drains, floor drains, and main sewer line cleaning. We use professional-grade cable machines and hydro-jetting to clear blockages — not just push them downstream. Same-day appointments available.',
    includes: ['Camera inspection', 'Cable snake clearing', 'Hydro-jet for severe blockages', 'Root intrusion treatment', 'Preventive enzyme treatment'],
  },
  {
    slug:     'water-heater',
    name:     'Water Heater Installation',
    icon:     'heater',
    tagline:  'Hot water restored same day.',
    desc:     'Traditional tank and tankless water heater installation, replacement, and repair. We stock the most common sizes so most same-day replacements are possible. Gas, electric, and hybrid heat pump models available.',
    includes: ['Free on-site estimate', 'Same-day installation available', 'Gas & electric models', 'Tankless upgrade consultations', '6-year parts warranty on new units'],
  },
  {
    slug:     'leak-detection',
    name:     'Leak Detection & Repair',
    icon:     'leak',
    tagline:  'Find it fast. Fix it right.',
    desc:     'Hidden pipe leaks, slab leaks, and water line breaks. We use electronic leak detection equipment to locate leaks without unnecessary destruction. Early detection saves thousands in water damage repair costs.',
    includes: ['Electronic leak locating', 'Slab leak detection', 'Water line leak repair', 'Pipe re-routing options', 'Pressure testing after repair'],
  },
  {
    slug:     'toilets-fixtures',
    name:     'Toilets & Fixtures',
    icon:     'fixture',
    tagline:  'Running, leaking, or outdated.',
    desc:     'Toilet repair and replacement, faucet installation, sink installation, garbage disposal, dishwasher hookups, and bathroom fixture upgrades. We bring the parts — no extra trip to the hardware store.',
    includes: ['Toilet repair & replacement', 'Faucet installation', 'Garbage disposal hookup', 'Dishwasher installation', 'Shut-off valve replacement'],
  },
  {
    slug:     'pipe-repair',
    name:     'Pipe Repair & Repiping',
    icon:     'pipe',
    tagline:  'Burst pipes, old pipes, corroded pipes.',
    desc:     'Emergency pipe burst repairs, pinhole leak repairs, galvanized pipe replacement, and whole-home repiping with PEX or copper. We handle permit-required work and coordinate final inspections.',
    includes: ['Emergency burst pipe repair', 'Pinhole & corroded pipe repair', 'Galvanized-to-PEX conversion', 'Whole-home repipe', 'Permit & inspection coordination'],
  },
  {
    slug:     'emergency',
    name:     'Emergency Plumbing',
    icon:     'emergency',
    tagline:  '24/7 — we pick up the phone.',
    desc:     'Burst pipes, sewage backups, flooding, no hot water, gas line concerns. We dispatch within the hour, any time of day or night, any day of the year. Charlotte\'s emergency plumber — not an answering service.',
    includes: ['24/7/365 response', '1-hour dispatch', 'Burst pipe repair', 'Sewage backup clearing', 'Flood mitigation start'],
  },
];

export const whyUs = [
  {
    title:   'Upfront Flat-Rate Pricing',
    desc:    'You get the price before we start — no surprise charges when the job is done. Our rates are posted and consistent. What we quote is what you pay.',
    stat:    '0',
    statLabel: 'Hidden Fees',
  },
  {
    title:   'Same-Day Service',
    desc:    'Most service calls are available same day when you call before noon. We stock common parts on every truck so one visit usually fixes it.',
    stat:    '90%',
    statLabel: 'Same-Day Fix',
  },
  {
    title:   '24/7 Emergency Line',
    desc:    'Real people answer our emergency line — not a voicemail, not an answering service. When your pipes burst at 2am, you need a real plumber on the line.',
    stat:    '24/7',
    statLabel: 'Always Available',
  },
  {
    title:   '15+ Years in Charlotte',
    desc:    "We've been serving Charlotte families since 2009. We know the city's homes, the local codes, and the water quality issues specific to the Charlotte metro.",
    stat:    '15+',
    statLabel: 'Years Serving Charlotte',
  },
];

export const serviceArea = [
  {
    zone:       'South Charlotte',
    neighborhoods: ['Ballantyne', 'Pineville', 'Matthews', 'Steele Creek', 'Arrowood', 'South Park'],
    zips:       ['28277', '28226', '28105', '28217', '28210', '28209'],
  },
  {
    zone:       'East Charlotte',
    neighborhoods: ['Mint Hill', 'Plaza Midwood', 'Central Ave', 'Monroe Rd', 'Eastway', 'Shamrock Dr'],
    zips:       ['28227', '28205', '28206', '28212', '28215', '28211'],
  },
  {
    zone:       'North Charlotte',
    neighborhoods: ['Huntersville', 'Cornelius', 'Davidson', 'Mooresville', 'Concord', 'NoDa'],
    zips:       ['28078', '28031', '28036', '28115', '28025', '28205'],
  },
  {
    zone:       'West Charlotte',
    neighborhoods: ['Gastonia (Service Calls)', 'Belmont', 'Mount Holly', 'Cramerton', 'Lowell', 'West Blvd'],
    zips:       ['28052', '28012', '28120', '28032', '28098', '28208'],
  },
];

export const pricing = [
  {
    name:     'Service Call',
    price:    '$89',
    period:   'diagnostic fee',
    desc:     'We come out, diagnose the problem, and give you an exact flat-rate quote before any work begins. The $89 diagnostic fee is waived when you proceed with the repair.',
    includes: [
      'On-site plumber visit',
      'Full problem diagnosis',
      'Upfront repair quote',
      'No obligation to proceed',
      'Fee waived if you book the repair',
    ],
    cta:      'Schedule Diagnostic',
    featured: false,
    tag:      '',
  },
  {
    name:     'Standard Service',
    price:    'From $189',
    period:   'flat rate per job',
    desc:     'Most common plumbing repairs — leaky faucets, running toilets, drain cleaning, fixture installs, shut-off valve replacement. Flat-rate price quoted before we start. Parts included.',
    includes: [
      'Drain cleaning (single drain)',
      'Faucet & fixture repair/replacement',
      'Toilet repair or replacement',
      'Garbage disposal install',
      'Shut-off valve replacement',
      'Parts & labor included',
    ],
    cta:      'Request Service',
    featured: true,
    tag:      'Most Common',
  },
  {
    name:     'After-Hours & Emergency',
    price:    'From $289',
    period:   'emergency dispatch',
    desc:     'Emergency response for burst pipes, sewage backups, major leaks, and flooding situations. Dispatched within the hour. After-hours pricing applies 8pm–7am and all day weekends.',
    includes: [
      '1-hour dispatch guarantee',
      '24/7/365 availability',
      'Burst pipe immediate repair',
      'Sewage backup clearing',
      'Flood mitigation start',
      'No after-hours price surprises',
    ],
    cta:      'Call Emergency Line',
    featured: false,
    tag:      '',
  },
];

export const reviews = [
  {
    name:    'Susan M.',
    detail:  'South Charlotte homeowner',
    rating:  5,
    quote:   'Called at 6am when our main line backed up. Mike had a plumber here by 7:30. Job was done by 10am and the price was exactly what they quoted on the phone. No surprises. This is how it should work.',
  },
  {
    name:    'James P.',
    detail:  'Property manager, 8 units in Plaza Midwood',
    rating:  5,
    quote:   "Blue Ridge has been our go-to for three years. When you manage rentals, you need a plumber who picks up the phone and shows up when they say. These guys are the only plumbers in Charlotte I trust with my tenants.",
  },
  {
    name:    'Linda K.',
    detail:  'Huntersville homeowner',
    rating:  5,
    quote:   "Our water heater died on Christmas Eve. I didn't expect anyone to come out, but Blue Ridge sent someone within two hours. Had hot water back by evening. They could have charged anything — they charged the standard rate. Integrity.",
  },
  {
    name:    'Marcus T.',
    detail:  'General contractor, Charlotte',
    rating:  5,
    quote:   "I've used six plumbing companies in Charlotte over the years. Blue Ridge is the only one I recommend to homeowners. Their work passes inspection first try, every time. That matters on a job site.",
  },
  {
    name:    'Diane R.',
    detail:  'Ballantyne homeowner, 12 years customer',
    rating:  5,
    quote:   "We've used them for everything — new water heater, bathroom remodel plumbing, a slab leak. Mike is honest. He'll tell you when something doesn't need replacing yet. That's rare. We'll never call anyone else.",
  },
];

export const faqs = [
  {
    q: 'How fast can you respond to a plumbing emergency?',
    a: "For true emergencies — burst pipes, sewage backup, no water at all — we dispatch within the hour, 24 hours a day, 7 days a week. When you call our emergency line, a licensed plumber answers. You won't get an answering service or a callback the next morning. We understand that water damage happens fast.",
  },
  {
    q: 'Do you give upfront pricing before starting work?',
    a: "Yes — always. Our plumbers won't start any work until you've seen and approved the flat-rate price in writing. The diagnostic fee ($89) is waived when you proceed with the repair. The price we quote is the price you pay — no hourly surprises, no \"it took longer than expected\" markups.",
  },
  {
    q: 'Are you licensed and insured?',
    a: "Mike Harrington holds NC Master Plumber License #MP-48293. Blue Ridge Plumbing carries $1M general liability insurance and workers' compensation coverage on all employees. We pull permits for all permit-required work and coordinate the final inspection. You can verify our license at nclbgc.org.",
  },
  {
    q: 'What areas do you serve?',
    a: "We serve Charlotte and the greater Charlotte metro: South Charlotte (Ballantyne, Pineville, Matthews), East Charlotte (Mint Hill, Plaza Midwood), North Charlotte (Huntersville, Cornelius, Davidson, Mooresville), and West Charlotte (Gastonia area, Belmont, Mount Holly). Call us and we'll confirm your address is in our service area.",
  },
  {
    q: 'Can you fix a slab leak?',
    a: "Yes. Slab leaks are one of our specialties. We use electronic leak detection equipment to locate the leak without unnecessary excavation, then discuss repair options with you — direct-access repair, pipe re-routing, or epoxy pipe lining, depending on your home's situation. We also help you document the leak for insurance claims.",
  },
  {
    q: 'How long does a water heater installation take?',
    a: 'Most standard water heater replacements (40–50 gallon tank) take 2–3 hours. We stock the most common models on our trucks, so same-day replacement is usually possible when you call before noon. Tankless water heater installations typically take 4–6 hours and may require a permit — we handle that paperwork.',
  },
  {
    q: 'My drain is slow but not totally blocked. Is that an emergency?',
    a: "Not an emergency, but worth addressing. A slow drain usually means partial blockage — hair, grease buildup, or early root intrusion. Left alone, it becomes a full backup (which IS an emergency). We offer same-day appointments for slow drains. A cable snake service typically resolves it and costs less than an emergency call.",
  },
  {
    q: 'Do you offer any warranty on your plumbing work?',
    a: "Yes. All labor is warranted for one year from the date of service — if the same problem recurs due to our workmanship, we come back at no charge. Parts carry the manufacturer's warranty (typically 1–5 years depending on the part). New water heaters carry a separate 6-year parts warranty on the tank.",
  },
];
