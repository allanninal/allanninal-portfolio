import { test, expect } from '@playwright/test';

test.describe('Slate Harbour Games — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Slate Harbour Games/);
    await expect(page.locator('h1')).toContainText('We publish the salary bands');
  });

  // Third schema mapping in three days: Person (103-108), VideoGame (109),
  // Organization here. Picking the type from what the page is, not from what
  // the scaffold carried, is a per-template decision every time.
  test('is marked up as an Organization with real company properties', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Organization"');
    expect(json).toContain('numberOfEmployees');
    expect(json).toContain('foundingDate');
    expect(json).not.toContain('"VideoGame"');
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const bands = page.locator('#pay table.bands');
    await expect(bands).toBeVisible();
    const box = await bands.boundingBox();
    expect(box!.height).toBeGreaterThan(250);
  });

  // ── Pay ─────────────────────────────────────────────────────────────────
  test('every band is a real range, not "competitive"', async ({ page }) => {
    await page.goto('/');
    const bands = (await page.locator('#pay .range').allTextContents()).map((s) => s.trim());
    expect(bands.length).toBeGreaterThan(3);
    const salaryBands = bands.filter((b) => b.includes('$') && b.includes('–'));
    expect(salaryBands.length).toBeGreaterThanOrEqual(4);
    const html = (await page.content()).toLowerCase();
    // The page argues against the word, so it may name it — but never as a band.
    for (const b of bands) expect(b.toLowerCase()).not.toContain('competitive');
    expect(html).toContain('least checkable word');
  });

  // ── Crunch ──────────────────────────────────────────────────────────────
  test('the crunch record is dated, counted and includes an unpaid period', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#crunch ol.record > li');
    const n = await rows.count();
    expect(n).toBe(3);
    let weeks = 0;
    for (const r of await rows.all()) {
      // The date and the week count are separate elements: reading the whole
      // cell gave "Oct – Nov 20216 weeks" and the first draft of this test
      // parsed 20216 out of it.
      expect((await r.locator('.when').textContent()) || '').toMatch(/20\d\d/);
      const wk = ((await r.locator('.wk').textContent()) || '').match(/(\d+) weeks/);
      expect(wk).not.toBeNull();
      weeks += Number(wk![1]);
    }
    const paids = (await page.locator('#crunch .paid').allTextContents()).map((s) => s.trim());
    expect(paids.length).toBe(n);
    for (const p of paids) expect(['Paid', 'Unpaid']).toContain(p);
    const unpaid = paids.filter((p) => p === 'Unpaid').length;
    expect(unpaid).toBeGreaterThan(0);
    await expect(page.locator('#crunch h2'))
      .toContainText(`${n} periods in 7 years. ${weeks} weeks. ${unpaid} unpaid.`);
  });

  test('paid and unpaid are words with glyphs, and not the accent', async ({ page }) => {
    await page.goto('/');
    for (const p of await page.locator('#crunch .paid').all()) {
      expect(await p.getAttribute('data-glyph')).toBeTruthy();
    }
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--mark-good', '--mark-bad', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  // ── Team ────────────────────────────────────────────────────────────────
  test('the team list says who to email, and carries no headshots', async ({ page }) => {
    await page.goto('/');
    const people = page.locator('#team ul.team > li');
    const n = await people.count();
    expect(n).toBe(9);
    for (const p of await people.all()) {
      await expect(p.locator('.for b')).toHaveText('Come to me for');
      expect(((await p.locator('.for span').textContent()) || '').length).toBeGreaterThan(30);
    }
    await expect(page.locator('#team h2')).toContainText(`${n} people`);
    expect(await page.locator('img').count()).toBe(0);
    await expect(page.locator('#faq')).toContainText(/nine people are fictional/i);
  });

  // ── Projects ────────────────────────────────────────────────────────────
  test('every project states how it was funded', async ({ page }) => {
    await page.goto('/');
    const arts = page.locator('#projects article');
    expect(await arts.count()).toBe(3);
    const text = (await arts.allTextContents()).join(' ').toLowerCase();
    expect(text).toContain('self-funded');
    expect(text).toContain('publisher');
    expect(text).toContain('grant');
  });

  // ── Cannot offer ────────────────────────────────────────────────────────
  test('the page lists what the studio cannot offer', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#cannot ul.cannot > li');
    const n = await items.count();
    expect(n).toBeGreaterThanOrEqual(4);
    await expect(page.locator('#cannot h2')).toContainText(`${n} things we cannot offer you.`);
    await expect(page.locator('#cannot')).toContainText(/below what a large publisher pays/i);
  });

  test('open roles are disclosures that carry their band', async ({ page }) => {
    await page.goto('/');
    const roles = page.locator('#roles details');
    const n = await roles.count();
    expect(n).toBe(2);
    for (const r of await roles.all()) {
      expect(await r.getAttribute('open')).toBeNull();
      await expect(r.locator('.meta')).toContainText(/band/i);
    }
    await expect(page.locator('#roles h2')).toContainText(`${n} open`);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the application form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-109 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['lowtide', 'bellingham', 'wishlist', 'lighthouse', 'hollow pine', 'videogame']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro hiring kit is absent from the free build', async ({ page }) => {
    const res = await page.goto('/hiring-kit/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
