// Slate Harbour Games — Lawrence, KS. Nine people. Fictional.
//
// An organisation page: not a solo portfolio (days 101-108) and not a product
// page (109). Every small-studio careers page says the same four things —
// passionate team, like a family, work-life balance, competitive salary — and
// not one of them is checkable. So this one publishes the bands and the crunch
// record, which are.

export const site = {
  name:        'Slate Harbour Games',
  shortName:   'Slate Harbour',
  title:       'Slate Harbour Games — nine people in Lawrence, Kansas',
  tagline:     'We publish the salary bands.',
  owner:       'Slate Harbour Games',
  ownerRole:   'Independent game studio',
  credential:  'Founded 2019 · nine people · two shipped titles',
  city:        'Lawrence',
  state:       'KS',
  language:    'en',
  phoneDisplay: '(785) 555-0148',
  phoneHref:   '+17855550148',
  email:       'hello@slateharbour.example',
  streetAddress: '804 Massachusetts St',
  postalCode:  '66044',
  hours:       'Mon–Thu core hours 10–4 · Friday is nobody’s meeting day',
  bookingWindow: 'Two roles open · applications read by a person',
  description:
    'A nine-person studio in Lawrence, Kansas. Every careers page in this industry says ' +
    '"competitive salary" and "we’re like a family". This one publishes the actual bands, ' +
    'the actual crunch record with dates, and a short list of what we cannot offer you.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Projects', href: '#projects' },
  { label: 'The team', href: '#team' },
  { label: 'Pay',      href: '#pay' },
  { label: 'Crunch',   href: '#crunch' },
  { label: 'Open roles', href: '#roles' },
];

export const counts = [
  { label: 'People',          value: '9' },
  { label: 'Years',           value: '7' },
  { label: 'Shipped titles',  value: '2' },
];

// ── Projects ──────────────────────────────────────────────────────────────
// Each carries its funding line. Funding decides what a studio is ABLE to
// make, and almost no studio page says which it was.

export const projects = [
  {
    name: 'Kettle Row', year: '2024', state: 'Shipped',
    funding: 'Self-funded from contract work',
    body: 'A twelve-hour management game about running a canal lock. Paid for by eighteen months of the team doing contract tools work for other studios, which is why it took three years rather than eighteen months.',
    outcome: 'Made its money back in fourteen months. Not a hit; a business.',
  },
  {
    name: 'Fathom Line', year: '2021', state: 'Shipped',
    funding: 'Publisher advance, recouped 2023',
    body: 'Our first commercial release. A publisher paid for it, which meant it existed at all and also meant the scope was agreed by somebody who was not going to build it.',
    outcome: 'Recouped, which is more than most advances do. We would take a publisher deal again, on different terms.',
  },
  {
    name: 'Untitled, 2027', year: 'In development', state: 'In development',
    funding: 'Self-funded plus a state arts grant',
    body: 'Eighteen months in. We are not showing it yet because it is not ready and announcing early costs a studio our size more attention than it buys.',
    outcome: 'Funded through Q3 2027 without new money. That is the number that matters and it is why we can say no to a bad deal.',
  },
];

export const projectsNote =
  'Every studio page lists what was made. Almost none says how it was paid for, and funding is ' +
  'the thing that actually decides what a studio can make — a publisher advance and a grant and ' +
  'a year of contract work produce three different games from the same nine people.';

// ── The team ──────────────────────────────────────────────────────────────
// "Come to me for" rather than a job title. No headshots.

export const team = [
  { name: 'Marisol Vance',  role: 'Studio lead',        forThis: 'Contracts, publishing conversations, anything that needs a decision made this week.' },
  { name: 'Tobias Rusk',    role: 'Technical director',  forThis: 'Engine questions, build pipeline, whether a thing is possible before you scope it.' },
  { name: 'Ines Aurand',    role: 'Design lead',         forThis: 'Systems design, playtest scheduling, and the reason a feature was cut.' },
  { name: 'Devon Achebe',   role: 'Art director',        forThis: 'Style guides, outsourcing, and whether your asset spec is going to survive our pipeline.' },
  { name: 'Rowan Pike',     role: 'Gameplay programmer',  forThis: 'Anything in the player-facing code, and the accessibility options list.' },
  { name: 'Sana Delacroix', role: 'Tools programmer',    forThis: 'The editor, the build machine, and the reason your import is slow.' },
  { name: 'Ezra Halloway',  role: 'Producer',            forThis: 'Schedules, external partners, and the honest answer about a date.' },
  { name: 'Nadia Storm',    role: 'Audio',               forThis: 'Music, sound, and mix — including the accessibility side of the mix, which is most of it.' },
  { name: 'Quill Ferrante', role: 'Community and support', forThis: 'Press, players, refunds, and everything that arrives in an inbox.' },
];

export const teamNote =
  'No headshots, deliberately. A photograph tells you nothing about who to email and a job title ' +
  'tells you slightly less than the sentence beside it does. If you need something from this ' +
  'studio, the second column is the page.';

// ── Pay ───────────────────────────────────────────────────────────────────

export const pay = {
  intro:
    '"Competitive" is the least checkable word in the language. These are the real bands, they ' +
    'are the same for everyone at a level regardless of what somebody negotiated, and they are on ' +
    'this page rather than revealed at offer stage.',
  rows: [
    { role: 'Junior — any discipline',  band: '$58k – $68k',  note: 'Zero to two years. We hire one or two a year and we do not expect them to arrive knowing our engine.' },
    { role: 'Mid — any discipline',     band: '$78k – $95k',  note: 'The band most of the studio sits in. Movement within it is annual and written down.' },
    { role: 'Senior — any discipline',  band: '$102k – $124k', note: 'Discipline does not change the band. A senior artist and a senior programmer are paid the same here.' },
    { role: 'Lead / director',          band: '$128k – $145k', note: 'Four of the nine. Leads are still expected to do the craft, which is why the band is not wider.' },
    { role: 'Profit share',             band: '8% of net',     note: 'Split evenly by headcount, not by seniority. It paid out twice in seven years and both times it was small.' },
  ],
  closing:
    'What we do not do: equity instead of salary, unpaid trials, or "we will revisit it after ' +
    'launch". If any of those turn up in a conversation with us, it is a mistake and you should ' +
    'say so.',
};

// ── The crunch record ─────────────────────────────────────────────────────
// Dated, with causes. `paid` says whether the overtime was paid, in words.

export const crunch = {
  intro:
    'Seven years, two shipped titles, and three periods where people worked more than their ' +
    'contracted hours. Here they are, with what caused each one and whether it was paid. A studio ' +
    'that claims zero is either very lucky, very new, or not counting.',
  entries: [
    {
      when: 'Oct – Nov 2021', weeks: 6, paid: 'yes',
      what: 'Fathom Line certification',
      why: 'A platform submission failed twice on a memory bug nobody had budgeted for. Six weeks at roughly fifty hours. Paid at 1.5×, and everyone took the following two weeks off.',
    },
    {
      when: 'Mar 2023', weeks: 2, paid: 'no',
      what: 'A festival build',
      why: 'We chased a showcase deadline we did not need to hit. Two weeks, unpaid because we were between funding, and it is the one on this list we should simply not have done.',
    },
    {
      when: 'Aug – Sep 2024', weeks: 4, paid: 'yes',
      what: 'Kettle Row launch window',
      why: 'A launch-week bug affecting saves. Four people, four weeks, paid, and we shipped the fix in six days. This is the kind we think is defensible and we would still rather not have had it.',
    },
  ],
  policy: [
    'Contracted hours are 37.5. Core hours are 10 to 4, Monday to Thursday.',
    'Overtime is paid at 1.5× or taken back as time, the person’s choice, decided by them and not by a lead.',
    'Nobody schedules work in the last two weeks of December.',
    'If a date needs crunch to hit, the date moves first. That has happened twice and both times it cost us less than the crunch would have.',
  ],
  note:
    'Publishing this is uncomfortable and it is the only version of a crunch policy worth having. ' +
    '"We do not crunch" is unverifiable; "we crunched three times in seven years, here is when, ' +
    'and one of them was our own fault" is something you can hold us to at an interview.',
};

// ── What we cannot offer ──────────────────────────────────────────────────

export const cannot = [
  'A big-studio salary. Our senior band is real and it is below what a large publisher pays in a coastal city.',
  'Full remote. We are hybrid with three days in Lawrence, because a nine-person team loses something we have not worked out how to replace.',
  'A fast promotion track. There are four leads and nine people; the arithmetic is not in your favour and pretending otherwise wastes your time.',
  'Work on a huge franchise. Our games sell in the tens of thousands and that is the plan.',
  'Certainty past 2027. We are funded through Q3 and we will tell the team the moment that changes, as we have both previous times.',
];

export const said = {
  text: 'I left after four years because I wanted to work on something bigger, and they wrote me a reference the same week. The bands on this page are the bands I was actually paid. I have worked at two studios since where that sentence would not be true.',
  who: 'A former gameplay programmer, quoted with permission',
};

// ── Open roles ────────────────────────────────────────────────────────────

export const roles = [
  {
    title: 'Gameplay programmer, mid',
    meta: 'Mid band · hybrid, Lawrence · open until filled',
    body: 'You would work on the 2027 project’s core systems alongside Rowan. We care that you have shipped something and can explain a decision you now think was wrong. We do not care which engine, and we do not have a degree requirement. The process is a 45-minute call, a paid four-hour task, and a half day with the team. Three steps, and we tell you the band before the first one because it is already on this page.',
  },
  {
    title: 'Environment artist, mid or senior',
    meta: 'Mid or senior band · hybrid, Lawrence · open until filled',
    body: 'Working with Devon on the 2027 project. Portfolio over CV, and we would rather see three finished environments than thirty pieces. If your portfolio is mostly one style, say so — we will tell you honestly whether that style is the one we need.',
  },
];

export const rolesNote =
  'Two roles, both real, both with the band on them. If neither fits, we keep speculative ' +
  'applications for twelve months and we answer every one of them, which takes Quill about an ' +
  'hour a week and is the cheapest thing we do for our reputation.';

export const faqs = [
  {
    q: 'Why publish salary bands?',
    a: 'Because "competitive" means nothing, because it stops the person who negotiates hardest being paid the most for the same work, and because it saves both sides a conversation that would otherwise happen in round three. It also means we cannot quietly underpay somebody, which is the actual reason most studios do not do it.',
  },
  {
    q: 'Do you really only crunch three times in seven years?',
    a: 'Three periods where people worked beyond contracted hours, yes, and they are listed with dates. If we have forgotten one, somebody who worked here will tell us and we will add it. That is the point of writing it down.',
  },
  {
    q: 'Why are there no team photos?',
    a: 'Because a headshot tells you nothing about who to email. The team list gives you a name, what they do and what to come to them for, which is what a visitor actually needs. This is also a website template, and the nine people are fictional — using stock portraits as fake employees would be inventing identities rather than inventing a company.',
  },
  {
    q: 'Are you hiring outside Kansas?',
    a: 'Not right now, and we say so plainly rather than letting people apply and find out. We are hybrid with three days in Lawrence. If that changes it will change on this page first.',
  },
  {
    q: 'Do you do unpaid test tasks?',
    a: 'No. Our task is four hours and it is paid at the mid contract rate whether or not you get the job. A studio that asks for unpaid work is telling you how it will treat you later.',
  },
  {
    q: 'What happens if the funding runs out?',
    a: 'We tell the team, immediately, as we did in 2022 and again in 2023. Both times we had six months of notice and both times nobody was surprised. We would rather lose people to a planned exit than to an announcement.',
  },
];
