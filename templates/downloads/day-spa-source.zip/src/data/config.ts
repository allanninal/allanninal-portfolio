export const spa = {
  name: 'Serenity & Stone',
  tagline: 'A sanctuary of calm, crafted for you.',
  description:
    'A luxury day spa and wellness retreat offering restorative massage, advanced facials, body treatments, sauna experiences, and curated day-retreat packages.',
  address: '84 Willow Crescent, Brooklyn, NY 11201',
  phone: '+1 (718) 555-0192',
  email: 'hello@serenitystone.com',
  instagram: 'https://www.instagram.com/',
  facebook: 'https://www.facebook.com/',
  bookingUrl: 'https://www.mindbodyonline.com/',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  kofi: 'https://ko-fi.com/allanninal',
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '9:00 am – 7:00 pm' },
    { day: 'Wednesday', open: '9:00 am – 7:00 pm' },
    { day: 'Thursday',  open: '9:00 am – 8:00 pm' },
    { day: 'Friday',    open: '9:00 am – 8:00 pm' },
    { day: 'Saturday',  open: '8:00 am – 7:00 pm' },
    { day: 'Sunday',    open: '9:00 am – 6:00 pm' },
  ],
};

export const site = {
  title: 'Serenity & Stone — Day Spa, Brooklyn NY',
  description:
    'Serenity & Stone is a luxury day spa in Brooklyn offering therapeutic massage, advanced facials, body treatments, infrared sauna, and bespoke spa packages. Book your retreat today.',
  language: 'en',
  ogImage: '/og-image.png',
  twitterHandle: '@allanninal',
};

export type Treatment = {
  name: string;
  duration: string;
  price: string;
  description: string;
  highlight?: boolean;
};

export type TreatmentCategory = {
  id: string;
  category: string;
  icon: string;
  intro: string;
  items: Treatment[];
};

export const treatments: TreatmentCategory[] = [
  {
    id: 'massage',
    category: 'Massage',
    icon: '◇',
    intro: 'From deep-tissue relief to silk-soft relaxation, each massage is tailored to your body on the day.',
    items: [
      { name: 'Swedish Relaxation Massage',  duration: '60 min', price: '$110', description: 'Long, flowing strokes ease muscular tension and calm the nervous system.' },
      { name: 'Deep Tissue Massage',         duration: '60 min', price: '$130', description: 'Sustained pressure on dense muscle layers for chronic tension and postural imbalance.' },
      { name: 'Hot Stone Massage',           duration: '75 min', price: '$155', description: 'Basalt stones, warmed to 130°F, melt tightness while heat penetrates deeply.', highlight: true },
      { name: 'Aromatherapy Massage',        duration: '60 min', price: '$125', description: 'Custom essential oil blend — choose from calming lavender, uplifting citrus, or grounding cedarwood.' },
      { name: 'Prenatal Massage',            duration: '60 min', price: '$120', description: 'Gentle side-lying treatment for mothers-to-be, relieving lower back and hip tension.' },
      { name: 'Couples Massage',             duration: '60 min', price: '$220', description: 'Two therapists, one treatment room — share the experience side by side.' },
    ],
  },
  {
    id: 'facials',
    category: 'Facials',
    icon: '◯',
    intro: 'Clinically informed and deeply nourishing — every facial begins with a skin analysis so your therapist chooses exactly the right actives.',
    items: [
      { name: 'Signature Glow Facial',       duration: '60 min', price: '$115', description: 'Double cleanse, enzyme exfoliation, custom serum, and LED light therapy for visible radiance.', highlight: true },
      { name: 'Hydrating Restore Facial',    duration: '75 min', price: '$135', description: 'Hyaluronic acid infusion and peptide masking for dehydrated or sensitised skin.' },
      { name: 'Clarifying Purify Facial',    duration: '60 min', price: '$115', description: 'Salicylic peel, extractions, and targeted blemish control for oily and breakout-prone skin.' },
      { name: 'Anti-Ageing Lift Facial',     duration: '90 min', price: '$165', description: 'Microcurrent sculpting, retinol micro-peel, and peptide collagen masking.' },
      { name: 'Sensitive Calm Facial',       duration: '60 min', price: '$110', description: 'Fragrance-free formulas, cooling jade tool, and oat-silk mask for reactive skin.' },
    ],
  },
  {
    id: 'body',
    category: 'Body Treatments',
    icon: '◈',
    intro: 'Full-body rituals that exfoliate, detoxify, and restore from scalp to sole.',
    items: [
      { name: 'Salt & Sage Body Scrub',      duration: '45 min', price: '$90',  description: 'Dead Sea salt and dried sage exfoliate, followed by a warm rinse and shea butter seal.' },
      { name: 'Detox Seaweed Wrap',          duration: '60 min', price: '$120', description: 'Marine algae minerals draw out impurities while the skin is cocooned in warmth.', highlight: true },
      { name: 'Cocoa Butter Body Ritual',    duration: '75 min', price: '$140', description: 'Warm cocoa-sugar scrub, warm oil massage, and a nourishing butter mask.' },
      { name: 'Back Facial',                 duration: '45 min', price: '$95',  description: 'Deep cleanse, exfoliation, extractions, and masking for the hard-to-reach back.' },
      { name: 'Himalayan Salt Stone Ritual', duration: '75 min', price: '$150', description: 'Salt stones smooth skin and balance mineral energy in a restorative full-body treatment.' },
    ],
  },
  {
    id: 'sauna',
    category: 'Sauna & Heat',
    icon: '✦',
    intro: 'Our private infrared sauna suites support detox, circulation, and deep relaxation at your own pace.',
    items: [
      { name: 'Infrared Sauna — Single',     duration: '45 min', price: '$55',  description: 'Private infrared suite with chromotherapy lighting and chilled eucalyptus towels.' },
      { name: 'Infrared Sauna — Couple',     duration: '45 min', price: '$90',  description: 'Share the heat — our spacious duo suite seats two comfortably.' },
      { name: 'Sauna & Scrub Combo',         duration: '90 min', price: '$145', description: 'Infrared session followed immediately by the Salt & Sage Body Scrub.', highlight: true },
      { name: 'Sauna & Facial Combo',        duration: '105 min', price: '$160', description: 'Open pores with infrared heat, then seal results with the Signature Glow Facial.' },
    ],
  },
];

export type SpaPackage = {
  id: string;
  name: string;
  subtitle: string;
  duration: string;
  price: string;
  priceNote?: string;
  includes: string[];
  highlight?: boolean;
};

export const packages: SpaPackage[] = [
  {
    id: 'restoration',
    name: 'The Restoration',
    subtitle: 'Half-day wellness reset',
    duration: '3 hours',
    price: '$285',
    includes: [
      'Swedish Relaxation Massage (60 min)',
      'Signature Glow Facial (60 min)',
      'Herbal foot soak',
      'Seasonal refreshment tray',
    ],
  },
  {
    id: 'sanctuary',
    name: 'The Sanctuary',
    subtitle: 'Our signature full-day retreat',
    duration: '5.5 hours',
    price: '$495',
    priceNote: 'Most popular',
    highlight: true,
    includes: [
      'Infrared Sauna Suite (45 min)',
      'Hot Stone Massage (75 min)',
      'Signature Glow Facial (60 min)',
      'Salt & Sage Body Scrub (45 min)',
      'Light spa lunch included',
      'Complimentary robe & slippers',
    ],
  },
  {
    id: 'couples-retreat',
    name: 'Couples Retreat',
    subtitle: 'Share the stillness together',
    duration: '4 hours',
    price: '$580',
    includes: [
      'Couples Sauna Suite (45 min)',
      'Couples Massage, side-by-side (60 min)',
      'Two Signature Glow Facials (60 min each)',
      'Champagne and seasonal fruit board',
      'Matching robes & slippers',
    ],
  },
  {
    id: 'revive',
    name: 'The Revive',
    subtitle: 'Express 2-hour refresh',
    duration: '2 hours',
    price: '$195',
    includes: [
      'Deep Tissue or Swedish Massage (60 min)',
      'Hydrating Restore Facial (60 min)',
      'Herbal tea on arrival',
    ],
  },
];

export const testimonials = [
  {
    quote: 'The Sanctuary day was the most restorative thing I have done in years. I floated out of there. Everything from the sauna to the hot stone massage was immaculate.',
    author: 'Elisa M.',
    service: 'The Sanctuary Package',
    rating: 5,
  },
  {
    quote: 'My skin has never looked better. The Signature Glow Facial therapist read my skin exactly right and the LED session made a visible difference by the next morning.',
    author: 'Camille D.',
    service: 'Signature Glow Facial',
    rating: 5,
  },
  {
    quote: 'We booked the Couples Retreat for our anniversary. The side-by-side massage room was perfect, and the champagne and fruit board was such a beautiful touch. Already rebooked.',
    author: 'James & Priya T.',
    service: 'Couples Retreat Package',
    rating: 5,
  },
  {
    quote: 'The infrared sauna suite feels like a private sanctuary. I come monthly and always pair it with the scrub — the combo leaves my skin incredibly smooth.',
    author: 'Naomi K.',
    service: 'Sauna & Scrub Combo',
    rating: 5,
  },
  {
    quote: 'The deep tissue massage was exactly the right level of pressure — firm without being painful. My therapist clearly knew anatomy. Slept better than I have in months.',
    author: 'Daniel R.',
    service: 'Deep Tissue Massage',
    rating: 5,
  },
  {
    quote: 'Serenity & Stone sets a new standard. The space is beautifully designed, the staff are genuinely attentive, and the treatments deliver what they promise. My go-to for reset days.',
    author: 'Vivienne H.',
    service: 'Restoration Package',
    rating: 5,
  },
];

export type Facility = {
  name: string;
  description: string;
  icon: string;
};

export const facilities: Facility[] = [
  {
    name: 'Infrared Sauna Suites',
    description: 'Two private full-spectrum infrared suites with chromotherapy lighting and a pre-heated arrival temperature.',
    icon: '◇',
  },
  {
    name: 'Relaxation Lounge',
    description: 'Warm stone seating, weighted eye masks, and herbal teas — arrive early and unwind before your treatment.',
    icon: '◯',
  },
  {
    name: 'Hydrotherapy Showers',
    description: 'Multiple pressure settings and a cold plunge rinse option to lock in treatment results.',
    icon: '◈',
  },
  {
    name: 'Treatment Suites',
    description: 'Seven private treatment rooms with heated tables, weighted blankets, and bespoke ambient soundscapes.',
    icon: '✦',
  },
  {
    name: 'Couples Suite',
    description: 'Our grand duo room with twin treatment tables, a shared sauna corner, and a private dressing area.',
    icon: '⊕',
  },
  {
    name: 'Spa Boutique',
    description: 'Curated retail — the same professional-grade oils, serums, and scrubs used in your treatments.',
    icon: '◆',
  },
];

export const stats = [
  { value: '12+', label: 'Years in Brooklyn' },
  { value: '7',   label: 'Treatment Suites' },
  { value: '4,800+', label: 'Guests Welcomed' },
  { value: '4.9★',  label: 'Average Rating' },
];

export const giftCardDenominations = ['$50', '$100', '$150', '$200', '$250', '$500'];
