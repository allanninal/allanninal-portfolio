import { test, expect } from '@playwright/test';

// Edition-aware: the Pro build swaps the free download bar for a live-preview strip.
const TEMPLATE_INFO_LABEL = process.env.PUBLIC_EDITION === 'pro'
  ? 'Pro edition — live preview'
  : 'Free template — download or fork';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Serenity & Stone/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  const hero = page.locator('#hero');
  await expect(hero).toBeVisible();
});

test('treatments section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#treatments')).toBeVisible();
});

test('treatment tabs are present', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('treatment cards render', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#treatments .treatment-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('tab switching works', async ({ page }) => {
  await page.goto('/');
  const secondTab = page.locator('[role="tab"]').nth(1);
  await secondTab.click();
  const selected = await secondTab.getAttribute('aria-selected');
  expect(selected).toBe('true');
});

test('packages section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#packages')).toBeVisible();
});

test('package cards render', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#packages .package-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('gift cards section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gift-cards')).toBeVisible();
});

test('facilities section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#facilities')).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('hours table is present', async ({ page }) => {
  await page.goto('/');
  const table = page.locator('.hours-table');
  await expect(table).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(`[aria-label="${TEMPLATE_INFO_LABEL}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('Book Now button exists in header', async ({ page }) => {
  await page.goto('/');
  const bookBtn = page.locator('header .btn-book');
  await expect(bookBtn).toBeVisible();
});

test('footer has spa name', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer.site-footer');
  await expect(footer).toContainText('Serenity');
});
