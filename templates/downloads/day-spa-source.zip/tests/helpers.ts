import type { Page } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';

// Single-page template; the Pro edition adds the printable /menu/ page.
export const ROUTES = isPro ? ['/', '/menu/'] : ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(_page: Page, _theme: 'light' | 'dark') {
  // Day Spa is light-only; no theme toggle needed
}
