/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,md,mdx}'],
  theme: {
    extend: {
      colors: {
        // Misty sage / warm stone / pearl white palette
        sage:    { DEFAULT: '#7A9E87', light: '#A8C4AE', dark: '#4D7A5C' },
        stone:   { DEFAULT: '#8C7B6A', light: '#B5A898', dark: '#5E4F40' },
        cream:   { DEFAULT: '#F5F0E8', muted: '#EAE3D8' },
        clay:    { DEFAULT: '#C4A882' },
        mist:    { DEFAULT: '#D8E5DC' },
        charcoal: { DEFAULT: '#2C2A27' },
      },
      fontFamily: {
        serif: ['"Crimson Pro"', 'Georgia', 'serif'],
        sans:  ['"Raleway Variable"', '"Raleway"', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        widest: '0.25em',
      },
    },
  },
  plugins: [],
};
