# Day Spa — Astro Template (Day 53 of 365)

A luxury day spa and wellness retreat template built with Astro and Tailwind CSS.

**Live demo:** https://example.com/

## Design

- **Palette:** Misty sage / warm stone / pearl cream — distinct calm-luxe spa aesthetic
- **Fonts:** Crimson Pro (elegant serif display) + Raleway Variable (refined clean sans)
- **Persona:** Serenity & Stone — Brooklyn luxury day spa, 12+ years, 7 treatment suites

## Sections

1. Hero — serene full-viewport hero with decorative leaf shapes and booking CTA
2. Stats band — 4 key stats (years, suites, guests, rating) on charcoal
3. Treatments — tabbed menu with 4 categories (Massage / Facials / Body Treatments / Sauna & Heat), each with duration + price + description
4. Packages — 4 curated day-retreat bundles (half-day, full-day, couples, express)
5. Gift Cards — visual gift card with denomination amounts
6. Facilities — 6 facility cards (sauna suites, relaxation lounge, hydrotherapy showers, treatment suites, couples suite, boutique)
7. Testimonials — 6 guest reviews
8. About — founder story with visual treatment grid
9. Hours & Location — weekly hours table + address
10. Booking CTA — full-width section linking to Mindbody booking

## Schema.org

- `DaySpa` + `HealthAndBeautyBusiness`
- `Service` with `OfferCatalog`
- Opening hours specification

## Stack

- [Astro](https://astro.build) 4.x — static output
- [Tailwind CSS](https://tailwindcss.com) 3.x
- Crimson Pro + Raleway Variable (via Fontsource)
- Playwright for testing
- Lighthouse CI for quality gates

## Quick start

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
# or with a custom base path:
PUBLIC_BASE_PATH=/day-spa/ npm run build
```

## Tests

```bash
npm test              # Playwright (smoke + a11y + links + template-info)
npm run test:a11y     # axe accessibility only
npm run test:links    # broken links + rel check
npm run test:lighthouse # Lighthouse CI (≥0.95 all categories)
```

## License

MIT — free to use, customize, and deploy. Attribution appreciated but not required.

Built by [Allan Niñal](#) as part of the 365 Astro Templates challenge.
