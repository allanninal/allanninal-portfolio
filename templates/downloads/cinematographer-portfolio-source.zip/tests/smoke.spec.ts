import { test, expect } from '@playwright/test';

test.describe('Halden Rask — smoke tests', () => {
  test('homepage renders with the DP name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Halden Rask/);
    await expect(page.locator('h1')).toContainText('cannot judge cinematography');
  });

  test('handles the schema.org cinematographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q222344');
  });

  // ── The shot list ───────────────────────────────────────────────────────
  test('every setup carries lens, movement, take count and duration', async ({ page }) => {
    await page.goto('/');
    const shots = page.locator('#scene li.shot');
    expect(await shots.count()).toBe(12);
    for (const s of await shots.all()) {
      // 14E is a '100mm macro', so the focal length is not the whole field.
      await expect(s.locator('.shot-spec')).toContainText(/^\d+mm.* · \w/);
      await expect(s.locator('.shot-takes')).toContainText(/\d+ takes · \d+s/);
    }
  });

  test('the headline totals are summed from the shot list, not typed', async ({ page }) => {
    await page.goto('/');
    const specs = await page.locator('#scene .shot-takes').allTextContents();
    let takes = 0, secs = 0;
    for (const t of specs) {
      const m = t.match(/(\d+) takes · (\d+)s/);
      expect(m).not.toBeNull();
      takes += Number(m![1]); secs += Number(m![2]);
    }
    const h2 = page.locator('#scene h2');
    await expect(h2).toContainText(`${takes} takes`);
    await expect(h2).toContainText(`${Math.floor(secs / 60)}m ${secs % 60}s on screen`);
  });

  // The evidence sits in the setup it came from, not in a gallery elsewhere.
  test('frames sit inside the setups they came from', async ({ page }) => {
    await page.goto('/');
    const frames = page.locator('#scene li.shot figure.shot-frame img');
    expect(await frames.count()).toBe(4);
    for (const f of await frames.all()) {
      const alt = (await f.getAttribute('alt')) || '';
      expect(alt.length).toBeGreaterThan(30);
      expect(await f.getAttribute('width')).toBeTruthy();
    }
    // No separate gallery repeating them — that would contradict the argument.
    expect(await page.locator('#gallery, #frames').count()).toBe(0);
  });

  test('all images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  // ── Format ──────────────────────────────────────────────────────────────
  test('the ratio diagram is decorative and the list carries the text', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#format .ratio-fig svg')).toHaveAttribute('aria-hidden', 'true');
    expect(await page.locator('#format .ratio-fig svg rect').count()).toBe(4);
    const rows = page.locator('#format .ratio-list li');
    expect(await rows.count()).toBe(4);
    for (const r of await rows.all()) {
      await expect(r.locator('.cost')).not.toBeEmpty();
    }
  });

  test('the rectangles are drawn to the ratios they are labelled with', async ({ page }) => {
    await page.goto('/');
    const labels = (await page.locator('#format .ratio-list .r').allTextContents())
      .map((t) => Number(t.split(':')[0]) / Number(t.split(':')[1]));
    const drawn = await page.locator('#format .ratio-fig svg rect').evaluateAll((rs) =>
      rs.map((r) => Number(r.getAttribute('width')) / Number(r.getAttribute('height'))));
    expect(drawn.length).toBe(labels.length);
    for (let i = 0; i < labels.length; i++) {
      // 1px of stroke inset per box, so allow a little slack on the shortest.
      expect(Math.abs(drawn[i] - labels[i])).toBeLessThan(0.12);
    }
  });

  // ── Credit ──────────────────────────────────────────────────────────────
  test('the page gives credit away rather than claiming it', async ({ page }) => {
    await page.goto('/');
    const c = page.locator('#credit');
    await expect(c).toContainText(/grade is the colourist/i);
    await expect(c).toContainText(/production designer/i);
    await expect(c).toContainText(/director/i);
  });

  test('day rate and kit are priced as separate lines', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#rates');
    await expect(r.locator('.term', { hasText: 'Day rate, DP only' })).toContainText('$950');
    await expect(r.locator('.term', { hasText: 'Kit — camera package' })).toContainText('$650/day');
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the enquiry form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-100 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['second room', 'run of show', 'same-night', 'awards', 'lanyard', 'q622237']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro look book is absent from the free build', async ({ page }) => {
    const res = await page.goto('/look-book/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
