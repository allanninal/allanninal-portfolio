// Halden Rask — Pittsburgh, PA.
//
// First template out of stills. Days 91-100 were ten photography axes; this
// one is defined by what separates the media: a still cannot show motion,
// duration or the cut. So the page leads with a shot list, not with frames.

export const site = {
  name:        'Halden Rask',
  shortName:   'Halden Rask',
  title:       'Halden Rask — Cinematographer, Pittsburgh',
  tagline:     'You cannot judge cinematography from a frame.',
  owner:       'Halden Rask',
  ownerRole:   'Director of photography',
  credential:  'Narrative and commercial · Pittsburgh and travelling',
  license:     'Director of photography, shooting since 2013',
  city:        'Pittsburgh',
  state:       'PA',
  language:    'en',
  phoneDisplay: '(412) 555-0167',
  phoneHref:   '+14125550167',
  email:       'halden@haldenrask.example',
  streetAddress: '3609 Butler St',
  postalCode:  '15201',
  hours:       'Prep and recce weekdays · shooting anywhere',
  bookingWindow: 'Reading scripts for spring. Commercials at four weeks.',
  description:
    'A director of photography in Pittsburgh. A reel is ninety seconds cut from the best ' +
    'three seconds of forty jobs, so instead of one this page opens with a real shot list: ' +
    'one scene, twelve setups, and what nine hours actually produces.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'One scene',  href: '#scene' },
  { label: 'Format',     href: '#format' },
  { label: 'Not mine alone', href: '#credit' },
  { label: 'Rates',      href: '#rates' },
  { label: 'Enquire',    href: '#enquire' },
];

// ── One scene ─────────────────────────────────────────────────────────────
// A real shot list. `secs` is the length of the take that survived the cut;
// the page sums them and compares against the shooting day.

export const scene = {
  title: 'Scene 14 — the hillside, night',
  summary: 'Two pages. One location, blue hour into full dark, a nine-hour day.',
  dayHours: 9,
  shots: [
    { n: '14A', what: 'Wide, city below',            lens: '25mm', move: 'Locked off', takes: 4, secs: 22,
      note: 'Shot first and shot fast — the blue hour that makes this frame lasts about twenty-five minutes and does not come back.',
      file: 'f01.jpg', alt: 'A figure seen from behind on a hillside above a city at blue hour, face not visible',
      cap: '14A · 25mm · locked off · take 3' },
    { n: '14B', what: 'Medium, over the shoulder',    lens: '40mm', move: 'Slow push', takes: 7, secs: 18, note: 'The push is a foot and a half over eighteen seconds. Nobody watching will notice it and the scene stops working without it.' },
    { n: '14C', what: 'Clean single, him',            lens: '65mm', move: 'Handheld', takes: 9, secs: 31, note: 'Nine takes because the performance changed, not because the camera did.' },
    { n: '14D', what: 'Clean single, reverse',        lens: '65mm', move: 'Handheld', takes: 6, secs: 28, note: 'Shot after the turnaround, which costs forty minutes of relighting and is the single biggest scheduling decision in any scene.' },
    { n: '14E', what: 'Insert — the hourglass',       lens: '100mm macro', move: 'Locked off', takes: 3, secs: 6,
      note: 'Six seconds on screen, forty minutes to light. Inserts are always the thing that gets cut for time and always the thing the edit needs.',
      file: 'f04.jpg', alt: 'An hourglass on a table in warm backlight, the sand mid-fall and the background thrown out of focus',
      cap: '14E · 100mm macro · locked off · take 2' },
    { n: '14F', what: 'Silhouette, backlit',          lens: '40mm', move: 'Locked off', takes: 5, secs: 14,
      note: 'One source through haze, everything else off. The simplest lighting on the day and the frame most people ask about.',
      file: 'f02.jpg', alt: 'A silhouetted figure with a hand raised to the face, rimmed by a single hard backlight through haze',
      cap: '14F · 40mm · single source · take 5' },
    { n: '14G', what: 'Tracking, along the ridge',    lens: '32mm', move: 'Dolly', takes: 8, secs: 26, note: 'Eight takes to get one where the track is not visible in the grass. Dolly on uneven ground is mostly carpentry.' },
    { n: '14H', what: 'Two-shot, low',                lens: '32mm', move: 'Locked off', takes: 4, secs: 19, note: 'Low because the hill is doing the work. The camera height is the only real decision in this setup.' },
    { n: '14J', what: 'Night exterior, the treeline',  lens: '25mm', move: 'Locked off', takes: 3, secs: 17,
      note: 'Moonlight is a large soft source a long way away, which is expensive to fake and cheap to wait for. We waited.',
      file: 'f03.jpg', alt: 'A dense forest at night lit only by cool moonlight falling between the trunks',
      cap: '14J · 25mm · available moonlight · take 1' },
    { n: '14K', what: 'Hands, detail',                lens: '65mm', move: 'Handheld', takes: 5, secs: 8,  note: 'Cutaway insurance. Half of these never make the cut and the half that do save a scene.' },
    { n: '14L', what: 'Exit, wide',                   lens: '25mm', move: 'Locked off', takes: 2, secs: 12, note: 'The same setup as 14A relit for full dark. Reusing a position is the cheapest twenty minutes on any schedule.' },
    { n: '14M', what: 'Safety wide, whole scene',      lens: '32mm', move: 'Locked off', takes: 2, secs: 41, note: 'One continuous pass of the entire scene, always shot last. It has rescued more edits than any other single habit.' },
  ],
  note:
    'Sixty takes, twelve setups, nine hours on a hillside. What reaches the screen is under ' +
    'four minutes and most of it is from the takes nobody predicted. A reel shows you the ' +
    'three prettiest seconds of that and tells you nothing about whether the day was run well.',
};

// ── Format ────────────────────────────────────────────────────────────────
// Ratios drawn to scale from these numbers.

export const ratios = [
  { r: '2.39:1', w: 2.39, use: 'Anamorphic scope',      cost: 'Buys width, costs headroom. Faces sit low in frame and a two-shot stops being a compromise.' },
  { r: '1.85:1', w: 1.85, use: 'Theatrical flat',        cost: 'The compromise nobody notices, which is exactly why it is the default for most features.' },
  { r: '16:9',   w: 1.78, use: 'What the platform wants', cost: 'A hair narrower than 1.85 and the only one that will not be letterboxed on the client’s site.' },
  { r: '4:3',    w: 1.33, use: 'Academy',                 cost: 'A decision, not nostalgia. It privileges the single over the two-shot and makes a room feel taller than it is.' },
];

export const formatNote =
  'Aspect ratio is chosen before a lens is, and it changes blocking, headroom and how many ' +
  'people you can hold in a frame. It is also the decision most often made by whoever built ' +
  'the delivery spec rather than by anyone who will be on set.';

// ── Not mine alone ────────────────────────────────────────────────────────

export const credit = {
  headline: 'Three sentences on what is not mine.',
  lines: [
    'The grade is the colourist’s. A great deal of what people call cinematography is decisions made weeks after the camera was packed, by somebody who was never on set.',
    'The room is the production designer’s. I choose where to put the light; they chose that there is a window there at all.',
    'Holding the shot is the director’s. Almost every frame anyone remembers is remembered because somebody decided not to cut away from it.',
  ],
  closing:
    'A DP who takes credit for all of that is describing a job that does not exist. What is ' +
    'mine is the light, the lens, the movement, and getting twelve setups done before the ' +
    'location goes dark.',
};

export const rates = {
  rows: [
    { what: 'Day rate, DP only',      figure: '$950',   note: 'Ten hours including setup. Prep and recce days are billed at half.' },
    { what: 'Kit — camera package',   figure: '$650/day', note: 'Separate line, always. Conflating the two is how a quote looks cheap and an invoice does not.' },
    { what: 'Kit — lighting and grip', figure: 'Quoted', note: 'Priced against the look, not against the day. This is the line that decides what is possible.' },
    { what: 'Prep and recce',         figure: '$475',   note: 'Half day rate. A scene shot without a recce costs more than the recce did.' },
    { what: 'Overtime',               figure: '1.5×',   note: 'After ten hours, and I will tell you at hour nine rather than on the invoice.' },
    { what: 'Travel and per diem',    figure: 'At cost', note: 'Agreed before, itemised after.' },
  ],
};

export const faqs = [
  {
    q: 'Can I see a reel?',
    a: 'Yes, and it will mislead you the way every reel does — ninety seconds cut from the best three seconds of forty jobs. Read the shot list on this page first. It tells you more about how I would run your day than any montage can.',
  },
  {
    q: 'Why is the kit a separate line?',
    a: 'Because a day rate and a camera package are different things and conflating them is how a quote looks cheap and an invoice does not. You are also free to hire the package elsewhere; I will tell you if the price you have been given is fair.',
  },
  {
    q: 'How many setups can we get in a day?',
    a: 'Twelve on a single location with one turnaround, which is what the scene on this page was. Add a company move and it is eight. Anyone promising twenty either has two units or has not thought about the relight.',
  },
  {
    q: 'Can you get that look on our budget?',
    a: 'Sometimes, and I will say so plainly rather than quote and disappoint you. The lighting and grip line is the one that decides it — not the camera, which matters far less than anyone outside the trade expects.',
  },
  {
    q: 'Who chooses the aspect ratio?',
    a: 'Ideally the director and I do, in prep. Frequently it is decided by whoever wrote the delivery spec, and then we find out on the day that the two-shot does not fit. It is worth ten minutes in the first conversation.',
  },
  {
    q: 'Do you grade your own work?',
    a: 'No. I supervise and I have opinions, but the colourist is a specialist and the difference between us is visible. Budget for them — it is the cheapest way to make everything else you paid for look like what you paid for.',
  },
];
