# Day 17 — Writer / Author Site: RESEARCH.md

## Differentiation mandate

Day 17 must be visually distinct from all prior 16 templates, with particular attention to the adjacent text/editorial family:
- Day 5 personal-blog: Newsreader serif, forest green, blog-as-musings
- Day 9 resume-cv: Source Serif 4 + Inter Tight, editorial CV
- Day 11 newsletter-landing: Lora + Work Sans, cream + oxblood
- Day 12 coming-soon: Fraunces + Space Grotesk, aubergine + warm-white
- Day 15 designer-portfolio: Cormorant Garamond + Archivo Black, terracotta

## Chosen visual register: Literary-Prussian / Book Jacket

**Palette:**
- Background: `#F7F4EE` — warm ivory paper (distinct from Day 11's cream `#FAF8F3` and Day 12's warm white)
- Ink: `#1A1410` — deep warm near-black (warmer than Day 16's `#0D0D0D`)
- Accent: `#1B4F72` — Prussian blue (untaken; very different from teal/cobalt/indigo/violet/navy used in other days; on ivory it reads "literary" not "tech")
- Accent light tint: `#D4E8F7` — pale blue for cover tints and hover states
- Secondary text: `#6B6059` — warm medium-gray

**Rationale for Prussian blue:** Deep forest green taken (Day 5), oxblood/burgundy taken (Day 11), aubergine taken (Day 12), terracotta taken (Day 15), teal on dark taken (Day 10), cobalt on white taken (Day 6), indigo on dark taken (Day 1), violet/cyan taken (Day 2). Prussian blue `#1B4F72` on warm ivory reads as 19th-century literary — think Penguin Classics, older Knopf covers. Never used in prior days.

**Typography:**
- Display headings: **Playfair Display** (Google Fonts, `@fontsource/playfair-display`) — untaken in prior days. Transitional display serif, high-contrast hairline strokes — perfect for large book title treatment and accent headings. Distinguished from: Newsreader (Day 5), Source Serif 4 (Day 9), Lora (Day 11), Fraunces (Day 12), Cormorant Garamond (Day 15).
- Body text: **Crimson Pro** (Google Fonts, `@fontsource/crimson-pro`) — elegant, readable at body sizes, feels like a well-set book page. Not used in any prior template.
- Secondary UI / labels: **Inter** (already used in several templates but only for sans UI fallback; the dominant serif pair is fully fresh)

**Density profile:** Medium-editorial. Wide margins at desktop. Large book cover art. Generous leading (1.8) on body text for excerpt readability. Feels like opening a book.

## Persona

**Author:** Eleanor Voss — literary fiction author. Published 4 books with Riverhead Books (Penguin Random House imprint). Based in Edinburgh. Writes novels at the intersection of historical fiction and psychological mystery.

**Books (CSS-only book covers — Penguin Modern Classics treatment):**

1. **The Salt Archive** (2023) — Riverhead Books
   - Genre: Literary mystery / Historical fiction
   - Cover: Prussian blue background with ivory title text
   - ISBN: 978-1-59448-123-4
   - Tagline: "A code hidden in shipwreck salvage. A family unraveling in real time."
   - Retailers: Amazon, Bookshop.org, Barnes & Noble, Audiobook, Library

2. **Where Silence Accumulates** (2021) — Riverhead Books
   - Genre: Literary fiction / Psychological
   - Cover: Deep warm charcoal background with ivory title text + Prussian blue ornament
   - ISBN: 978-1-59448-098-4
   - Tagline: "Memory as evidence. The past as crime scene."

3. **The Glass Inheritance** (2019) — Riverhead Books
   - Genre: Literary fiction
   - Cover: Warm ivory with Prussian blue decorative element
   - ISBN: 978-1-59448-072-5
   - Tagline: "Three generations of women keeping the same impossible secret."

4. **Fieldnotes on Grief** (2017) — Riverhead Books
   - Genre: Literary debut / Memoir-adjacent fiction
   - Cover: Muted sage with near-black title (slightly older, different era in career)
   - ISBN: 978-1-59448-049-7
   - Tagline: "A debut novel written in the debris of loss."

## Key sections

1. **Hero** — Latest book (The Salt Archive) as CSS book cover, large. Title + subtitle + tagline. Buy CTAs: Amazon, Bookshop.org, Audiobook. "Read an excerpt" secondary CTA.
2. **Books grid / bibliography** — All 4 books with CSS covers, title, year, tagline, retailer links.
3. **Excerpt** — A 300-word excerpt from The Salt Archive, beautifully typeset in Crimson Pro at 19px, generous leading. "Read the first chapter →" CTA.
4. **Press & Acclaim** — 4 blurbs from fictional outlets (The New York Times Book Review, The Guardian, The Atlantic, Kirkus Reviews). Press logos strip.
5. **Events** — 3 upcoming author readings/signings (Edinburgh Book Festival, PEN America Literary Gala, Shakespeare & Co Paris).
6. **About the author** — 3-paragraph bio. Awards (fictional: Booker Prize longlist 2023, PEN/Faulkner finalist 2021). Illustrated by SVG avatar or CSS portrait.
7. **Newsletter** — "Letters from the Desk" — monthly notes on writing, research, and the books that shaped each novel. Buttondown signup.
8. **Contact / Press** — Press inquiries to landix.ninal@gmail.com. LinkedIn primary CTA.

## Schema.org

- `Person` for Eleanor Voss
- `Book` for each of the 4 books (with isbn, publisher, datePublished, inLanguage, author)
- JSON-LD embedded in `<head>`

## Technical choices

- Astro 4 + Tailwind 3 (consistent with roadmap)
- `@fontsource/playfair-display` + `@fontsource/crimson-pro` (self-hosted for Lighthouse perf)
- CSS-only book covers via `BookCover.astro` component (accepts title, author, accent, background props)
- Static site, no JS beyond minimal scroll behavior
- Full a11y: WCAG AA contrast throughout (Prussian blue on ivory: 7.2:1; body text on ivory: 16.8:1)
- Sitemap via @astrojs/sitemap
- OG image: og-image.svg + og-image.png committed to /public/

## What makes this template unique vs adjacent days

| Feature | Day 17 | Day 5 (blog) | Day 11 (newsletter) | Day 15 (designer) |
|---------|--------|--------------|---------------------|-------------------|
| Hero unit | CSS book cover | Article feed | Newsletter signup | Case study grid |
| Primary CTA | "Buy now" (retailer links) | "Read posts" | "Subscribe" | "View work" |
| Book covers | CSS-component | None | None | None |
| Excerpt | Beautifully typeset 300 words | Short post previews | Sample issues | None |
| Press section | NYT/Guardian blurbs | None | Reader quotes | None |
| Events | Readings/signings | None | None | None |
| Schema.org | Person + Book(x4) | Blog/Article | Periodical | Person + CreativeWork |
| Palette | Prussian blue + ivory | Forest green + light | Oxblood + cream | Terracotta + parchment |
| Display font | Playfair Display | Newsreader | Lora | Cormorant Garamond |

The book-as-product architecture, CSS book cover component, Prussian blue / warm ivory palette, and Playfair Display typography are all first uses in this roadmap.
