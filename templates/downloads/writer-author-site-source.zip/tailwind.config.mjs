/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Core palette — Prussian blue on warm ivory
        ivory:    '#F7F4EE',
        ink:      '#1A1410',
        prussian: '#1B4F72',
        'prussian-light': '#2E6B9E',
        'prussian-pale': '#D4E8F7',
        muted:    '#6B6059',
        border:   '#DDD8CE',
        sage:     '#7A8C6E',  // for oldest book cover
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        body:    ['"Crimson Pro"', 'Georgia', 'serif'],
        ui:      ['Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-xl': ['clamp(2.5rem, 5vw, 4.5rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'display-lg': ['clamp(2rem, 4vw, 3.25rem)', { lineHeight: '1.15', letterSpacing: '-0.015em' }],
        'display-md': ['clamp(1.5rem, 3vw, 2.25rem)', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'body-lg':    ['1.1875rem', { lineHeight: '1.8', letterSpacing: '0.005em' }],
        'body-base':  ['1.0625rem', { lineHeight: '1.75' }],
      },
      maxWidth: {
        prose: '68ch',
        content: '1120px',
      },
      spacing: {
        section: 'clamp(4rem, 8vw, 8rem)',
      },
    },
  },
  plugins: [],
};
