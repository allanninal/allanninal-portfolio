import { test, expect } from '@playwright/test';

test.describe('Writer / Author Site — interactions', () => {
  test('mobile nav toggles', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');

    const toggle = page.locator('#nav-toggle');
    const menu   = page.locator('#mobile-menu');

    // Initially hidden (JS adds 'hidden' class; template ships with it)
    const isHiddenInitially = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenInitially).toBe(true);

    // Open — JS removes 'hidden' class
    await toggle.click();
    await page.waitForTimeout(100);
    const isHiddenAfterOpen = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterOpen).toBe(false);

    // Close by clicking a link
    await menu.locator('a').first().click();
    const isHiddenAfterClose = await menu.evaluate(
      el => el.classList.contains('hidden')
    );
    expect(isHiddenAfterClose).toBe(true);
  });

  test('buy buttons are keyboard-navigable', async ({ page }) => {
    await page.goto('/');
    // Tab to first CTA link in hero
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    // Should be able to reach links without error
    const focusedElement = await page.evaluate(() => document.activeElement?.tagName);
    expect(['A', 'BUTTON', 'INPUT']).toContain(focusedElement);
  });

  test('newsletter form submits without JS errors', async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // scripts can 403 under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead/i;
    const errors: string[] = [];
    page.on('console', msg => {
      if (msg.type() !== 'error') return;
      const text = msg.text();
      const url = msg.location()?.url || '';
      // Skip third-party scripts and their generic "failed to load resource" 403s.
      if (THIRD_PARTY.test(text) || THIRD_PARTY.test(url)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(text);
    });

    await page.goto('/');
    const emailInput = page.locator('#newsletter-email');
    await emailInput.fill('test@example.com');
    // Don't actually submit (no backend in tests)
    expect(errors).toHaveLength(0);
  });

  test('excerpt section renders text content', async ({ page }) => {
    await page.goto('/');
    await page.locator('#excerpt').scrollIntoViewIfNeeded();
    const excerptText = page.locator('#excerpt .prose-book');
    await expect(excerptText).toBeVisible();
    const text = await excerptText.textContent();
    expect(text?.length).toBeGreaterThan(100);
  });

  test('all four books appear in bibliography', async ({ page }) => {
    await page.goto('/');
    const bookSection = page.locator('#books');
    await bookSection.scrollIntoViewIfNeeded();
    const articles = bookSection.locator('article');
    await expect(articles).toHaveCount(4);
  });
});
