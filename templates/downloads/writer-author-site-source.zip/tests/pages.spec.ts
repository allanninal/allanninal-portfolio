import { test, expect } from '@playwright/test';

test.describe('Writer / Author Site — pages', () => {
  test('homepage loads with correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Eleanor Voss/);
  });

  test('homepage has hero section with book title', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toContainText('The Salt Archive');
  });

  test('books section is present', async ({ page }) => {
    await page.goto('/');
    const booksSection = page.locator('#books');
    await expect(booksSection).toBeVisible();
  });

  test('excerpt section is present', async ({ page }) => {
    await page.goto('/');
    const excerptSection = page.locator('#excerpt');
    await expect(excerptSection).toBeVisible();
  });

  test('press section is present', async ({ page }) => {
    await page.goto('/');
    const pressSection = page.locator('#press');
    await expect(pressSection).toBeVisible();
  });

  test('about section is present', async ({ page }) => {
    await page.goto('/');
    const aboutSection = page.locator('#about');
    await expect(aboutSection).toBeVisible();
  });

  test('events section is present', async ({ page }) => {
    await page.goto('/');
    const eventsSection = page.locator('#events');
    await expect(eventsSection).toBeVisible();
  });

  test('newsletter section is present', async ({ page }) => {
    await page.goto('/');
    const newsletterSection = page.locator('#newsletter');
    await expect(newsletterSection).toBeVisible();
  });

  test('sitemap exists', async ({ page }) => {
    const response = await page.request.get('/sitemap-index.xml');
    expect(response.status()).toBe(200);
  });

  test('footer is present', async ({ page }) => {
    await page.goto('/');
    // Site footer — use role or target the outermost footer (body > footer)
    const footer = page.locator('body > footer');
    await expect(footer).toBeAttached();
  });
});
