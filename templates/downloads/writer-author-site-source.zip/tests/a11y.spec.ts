import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const isPro = process.env.PUBLIC_EDITION === 'pro';

test.describe('Writer / Author Site — accessibility', () => {
  test('homepage passes axe accessibility audit', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('Pro press-kit page passes axe accessibility audit', async ({ page }) => {
    test.skip(!isPro, 'The /press-kit/ page only exists in the Pro edition');
    await page.goto('/press-kit/');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('has skip-to-content link', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('a[href="#main"]');
    await expect(skipLink).toBeAttached();
  });

  test('all images have alt text', async ({ page }) => {
    await page.goto('/');
    const imagesWithoutAlt = await page.locator('img:not([alt])').count();
    expect(imagesWithoutAlt).toBe(0);
  });

  test('heading hierarchy is correct — h1 exists', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const count = await h1.count();
    expect(count).toBe(1);
  });

  test('nav has aria-label', async ({ page }) => {
    await page.goto('/');
    const nav = page.locator('nav[aria-label]');
    await expect(nav.first()).toBeVisible();
  });

  test('form inputs have labels', async ({ page }) => {
    await page.goto('/');
    const emailInput = page.locator('#newsletter-email');
    await expect(emailInput).toBeVisible();
    // The input should have an associated label (sr-only is fine)
    const label = page.locator('label[for="newsletter-email"]');
    await expect(label).toBeAttached();
  });
});
