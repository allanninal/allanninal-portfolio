# Writer / Author Site — Day 17 / 365

A literary author website template for published writers. The book is the hero — not the blog, not the newsletter. Built with Astro + Tailwind.

**Live demo:** https://example.com/

## What's inside

- **Hero** centered on the latest book: CSS book cover (Penguin-style), title, tagline, multi-retailer CTAs
- **Bibliography** grid — 4 books with CSS covers, publisher/year, retailer links
- **Excerpt** — beautifully typeset first-chapter excerpt in Crimson Pro at large body size
- **Press & Acclaim** — pull quote cards from major outlets, outlet logos strip
- **Events** — author readings, signings, and festivals with ticket links
- **About the author** — multi-paragraph bio, awards, CSS illustrated portrait
- **Newsletter** — Buttondown signup for monthly letters from the desk
- **Contact** — press inquiry email + LinkedIn CTA

## Design decisions

- **Palette:** Warm ivory `#F7F4EE` + deep warm ink `#1A1410` + Prussian blue `#1B4F72` — literary book jacket aesthetic
- **Typography:** Playfair Display (display headings) + Crimson Pro (body + excerpt) — both untaken in the prior 16 templates
- **Book covers:** CSS-only `BookCover.astro` component — Penguin Modern Classics treatment with publisher strip, ornament, title, author — no image files, works at any size
- **Schema.org:** `Person` + `Book` (x4) with `isbn`, `publisher`, `datePublished`, `inLanguage`, `author`

## Customization

All editable content lives in `src/data/author.ts`:
- `author` — name, bio, socials, newsletter config, press email
- `books[]` — title, year, publisher, ISBN, tagline, description, cover colors, retailers, excerpt
- `press[]` — review blurbs and outlet attributions
- `events[]` — upcoming readings, signings, festival appearances

To change the newsletter provider (Mailchimp, ConvertKit, Substack), update `author.newsletter.actionUrl` and `author.newsletter.buttondownSlug`.

## Tech stack

| | |
|---|---|
| Framework | Astro 4 (static output) |
| Styling | Tailwind CSS 3 |
| Display font | Playfair Display (self-hosted via @fontsource) |
| Body font | Crimson Pro (self-hosted via @fontsource) |
| Tests | Playwright + axe-core + Lighthouse CI + linkinator |

## Running locally

```bash
npm install
npm run dev
```

Build for production:
```bash
PUBLIC_BASE_PATH=/your-base-path/ npm run build
```

## License

MIT — see [LICENSE](./LICENSE).

---

Part of the [365 Templates](https://example.com/templates) project by [Allan Niñal](https://example.com).
