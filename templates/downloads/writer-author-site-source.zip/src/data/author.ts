// Single source of truth for the author site.
// Cloning users: edit this file to personalize the template.

export const author = {
  name: 'Eleanor Voss',
  pronouns: 'she/her',
  location: 'Edinburgh, Scotland',
  email: 'hello@eleanorvoss.com',
  // Short bio for hero/meta (1–2 sentences)
  tagline: 'Literary fiction. Four novels. Published by Riverhead Books.',
  // Full bio paragraphs for About section
  bio: [
    'Eleanor Voss writes novels at the intersection of historical mystery and psychological fiction. Her books have been longlisted for the Booker Prize, shortlisted for the PEN/Faulkner Award, and translated into fourteen languages.',
    'Born in Glasgow, she studied history at the University of Edinburgh, where she wrote her undergraduate thesis on archival silence and disappeared records — a preoccupation that surfaces in all four of her novels. She has been a writer-in-residence at the British Library and a visiting fellow at Princeton.',
    'She lives in Edinburgh with too many books and not enough shelf space. She writes every morning, submits to no social media, and sends a monthly letter to readers from her desk.',
  ],
  // Awards & recognition
  awards: [
    'Booker Prize Longlist, 2023 — The Salt Archive',
    'PEN/Faulkner Award Finalist, 2021 — Where Silence Accumulates',
    'Edinburgh International Book Festival First Book Award, 2017 — Fieldnotes on Grief',
    "Women's Prize for Fiction Longlist, 2019 — The Glass Inheritance",
  ],
  // Social links
  socials: {
    linkedin: '#',
    github: '#',
    x: '#',
    bluesky: 'https://bsky.app/profile/allanninal.bsky.social',
    mastodon: 'https://mastodon.social/@example',
  },
  // Publisher
  publisher: 'Riverhead Books (Penguin Random House)',
  // Agent / press contact
  pressEmail: 'hello@eleanorvoss.com',
  // Newsletter
  newsletter: {
    name: 'Letters from the Desk',
    description: 'Monthly notes on writing, research, the books that shaped each novel, and the history that keeps bleeding into the fiction. No promotional content — just a letter.',
    buttondownSlug: 'eleanor-voss',
    actionUrl: 'https://buttondown.email/api/emails/embed-subscribe/eleanor-voss',
  },
  // Ko-fi
  kofi: '#',
};

export type Book = {
  slug: string;
  title: string;
  subtitle: string;
  year: number;
  publisher: string;
  isbn: string;
  tagline: string;
  description: string;
  coverAccent: string;     // CSS color for cover background
  coverText: string;       // CSS color for cover title text
  coverOrnament: string;   // CSS color for ornamental element
  retailers: { label: string; url: string; icon: string }[];
  excerpt: string;
  excerptSource: string;
};

export const books: Book[] = [
  {
    slug: 'the-salt-archive',
    title: 'The Salt Archive',
    subtitle: 'A Novel',
    year: 2023,
    publisher: 'Riverhead Books',
    isbn: '978-1-59448-123-4',
    tagline: 'A code hidden in shipwreck salvage. A family unraveling in real time.',
    description: 'When marine archaeologist Nora Cairn discovers a water-damaged logbook in the wreckage of an 1847 schooner, she finds entries that should not exist — addresses, names, coordinates — written in a cipher that matches her dead mother\'s private shorthand. The Salt Archive is a novel about archives and obsession, about the evidence we preserve and the evidence we destroy, and about the moment you realize you have been the subject of an investigation you never knew was happening.',
    coverAccent: '#1B4F72',
    coverText: '#F7F4EE',
    coverOrnament: '#D4E8F7',
    retailers: [
      { label: 'Bookshop.org', url: 'https://bookshop.org', icon: 'bookshop' },
      { label: 'Amazon', url: 'https://www.amazon.com', icon: 'amazon' },
      { label: 'Barnes & Noble', url: 'https://www.barnesandnoble.com', icon: 'bn' },
      { label: 'Audiobook', url: 'https://www.audible.com', icon: 'audio' },
      { label: 'Library', url: 'https://www.worldcat.org', icon: 'library' },
    ],
    excerpt: `The logbook was wrapped in oilskin, which was itself sealed inside a copper cylinder the size of a rolled umbrella. Nora had opened hundreds of preservation cylinders — they were standard issue on merchant ships from the 1820s onward, a technology borrowed from the postal service — and she had found the usual contents: manifests, insurance documents, the occasional letter. She had never found what she found in this one.

The first forty pages were exactly what the manifest promised: cargo records for a schooner called the *Patience*, out of Greenock, September 1847. Wool, oilcloth, three crates labeled *iron fittings* that never arrived at their destination in Aberdeen because the *Patience* went down in the Firth of Forth during a storm on the fifth of October. All of this was known. All of this was in the Lloyd's Register.

What came after page forty was not in the Register.

A cipher. Dense, meticulous, organized into columns. She photographed every page before touching it further, the habit of twenty years. Then she looked at the cipher more carefully and felt the particular cold she associated with archive rooms and revelations: the cold of something that should not exist.

The shorthand was her mother's.`,
    excerptSource: 'The Salt Archive, Chapter One (pp. 11–12)',
  },
  {
    slug: 'where-silence-accumulates',
    title: 'Where Silence Accumulates',
    subtitle: 'A Novel',
    year: 2021,
    publisher: 'Riverhead Books',
    isbn: '978-1-59448-098-4',
    tagline: 'Memory as evidence. The past as crime scene.',
    description: 'A woman returns to her childhood home in the Scottish Borders to sort through her father\'s estate and discovers, in the walls of his study, the meticulous documentation of a decades-long obsession she cannot name. Where Silence Accumulates is an interior novel — claustrophobic, precise, and devastatingly patient — about the stories we tell ourselves to survive our families.',
    coverAccent: '#2C2520',
    coverText: '#F7F4EE',
    coverOrnament: '#1B4F72',
    retailers: [
      { label: 'Bookshop.org', url: 'https://bookshop.org', icon: 'bookshop' },
      { label: 'Amazon', url: 'https://www.amazon.com', icon: 'amazon' },
      { label: 'Barnes & Noble', url: 'https://www.barnesandnoble.com', icon: 'bn' },
      { label: 'Audiobook', url: 'https://www.audible.com', icon: 'audio' },
      { label: 'Library', url: 'https://www.worldcat.org', icon: 'library' },
    ],
    excerpt: `She had been in the house for three days before she found the first folder.

It was behind the false back of a filing cabinet — a detail so theatrical she almost laughed, standing there in her father's study with a sheaf of papers in her hand and the afternoon light coming through windows he had never bothered to clean. Theatrical. Her father had not been a theatrical man. He had been a civil engineer who collected stamps and voted without enthusiasm and made his feelings known through silence, which he had practiced with the dedication of a concert pianist.

The folder contained forty-three photographs of a woman Margot did not recognize.`,
    excerptSource: 'Where Silence Accumulates, Chapter One (p. 3)',
  },
  {
    slug: 'the-glass-inheritance',
    title: 'The Glass Inheritance',
    subtitle: 'A Novel',
    year: 2019,
    publisher: 'Riverhead Books',
    isbn: '978-1-59448-072-5',
    tagline: 'Three generations of women keeping the same impossible secret.',
    description: 'Moving between Edinburgh in 2019, Lisbon in 1974, and Glasgow in 1945, The Glass Inheritance follows three women from the same family across seventy years of silence. The secret at the novel\'s center is mundane in its origins and catastrophic in its consequences — a pattern that Voss traces with the care of a forensic historian.',
    coverAccent: '#F7F4EE',
    coverText: '#1A1410',
    coverOrnament: '#1B4F72',
    retailers: [
      { label: 'Bookshop.org', url: 'https://bookshop.org', icon: 'bookshop' },
      { label: 'Amazon', url: 'https://www.amazon.com', icon: 'amazon' },
      { label: 'Barnes & Noble', url: 'https://www.barnesandnoble.com', icon: 'bn' },
      { label: 'Library', url: 'https://www.worldcat.org', icon: 'library' },
    ],
    excerpt: `Glasgow, 1945. Margaret receives the letter on a Tuesday, which she will later identify as the last ordinary Tuesday of her life. She reads it in the kitchen, standing up, because she has not yet learned that news of a certain weight requires a chair.`,
    excerptSource: 'The Glass Inheritance, Prologue (p. 1)',
  },
  {
    slug: 'fieldnotes-on-grief',
    title: 'Fieldnotes on Grief',
    subtitle: 'A Novel',
    year: 2017,
    publisher: 'Riverhead Books',
    isbn: '978-1-59448-049-7',
    tagline: 'A debut novel written in the debris of loss.',
    description: 'A young archaeologist catalogues the objects her mother left behind — methodically, as if loss were a site to be excavated. Fieldnotes on Grief is a debut novel of extraordinary restraint, written in the form of a field journal, with numbered entries and no chapter breaks. It won the Edinburgh International Book Festival First Book Award and established Voss as one of the most distinctive voices in British literary fiction.',
    coverAccent: '#7A8C6E',
    coverText: '#1A1410',
    coverOrnament: '#F7F4EE',
    retailers: [
      { label: 'Bookshop.org', url: 'https://bookshop.org', icon: 'bookshop' },
      { label: 'Amazon', url: 'https://www.amazon.com', icon: 'amazon' },
      { label: 'Barnes & Noble', url: 'https://www.barnesandnoble.com', icon: 'bn' },
      { label: 'Library', url: 'https://www.worldcat.org', icon: 'library' },
    ],
    excerpt: `Entry 1. The notebook was her idea. She said: if you ever lose me, catalogue the things I leave. Don't mourn them. Study them. It will help. I wrote it down in pencil on the inside cover of a Moleskine I bought in a train station in Berlin, and I did not think about it again for eleven years.`,
    excerptSource: 'Fieldnotes on Grief, Entry 1 (p. 1)',
  },
];

export const press = [
  {
    outlet: 'The New York Times Book Review',
    quote: 'Voss writes with the patient ruthlessness of a forensic examiner. The Salt Archive is a novel of perfect compression — every sentence load-bearing, every revelation earned.',
    reviewer: 'Sarah Goldblatt',
    book: 'The Salt Archive',
    logo: 'nytbr',
  },
  {
    outlet: 'The Guardian',
    quote: 'Where Silence Accumulates confirms Voss as the inheritor of Penelope Fitzgerald\'s legacy: precise, pitiless, and quietly devastating. One of the finest British novels of the past decade.',
    reviewer: 'James Meek',
    book: 'Where Silence Accumulates',
    logo: 'guardian',
  },
  {
    outlet: 'The Atlantic',
    quote: 'The Glass Inheritance is a masterwork of structural audacity. Voss moves across seventy years of family history without a wasted word, locating in the smallest domestic details the exact weight of inherited silence.',
    reviewer: 'Ann Hulbert',
    book: 'The Glass Inheritance',
    logo: 'atlantic',
  },
  {
    outlet: 'Kirkus Reviews',
    quote: 'A debut of devastating emotional precision. Fieldnotes on Grief is unlike anything published this year — formally inventive, intellectually rigorous, and shot through with grief so controlled it becomes a kind of beauty.',
    reviewer: 'Starred Review',
    book: 'Fieldnotes on Grief',
    logo: 'kirkus',
  },
];

export const events = [
  {
    title: 'Edinburgh International Book Festival',
    date: '2026-08-14',
    dateDisplay: 'August 14, 2026',
    location: 'Charlotte Square Gardens, Edinburgh',
    description: 'In conversation with journalist and critic Lucy Kellaway on The Salt Archive, archival fiction, and the ethics of reconstructing the past.',
    ticketUrl: 'https://www.edbookfest.co.uk',
    type: 'Festival',
  },
  {
    title: 'PEN America Literary Gala',
    date: '2026-05-20',
    dateDisplay: 'May 20, 2026',
    location: 'American Museum of Natural History, New York',
    description: 'Reading from The Salt Archive and remarks on literature, archives, and freedom of expression.',
    ticketUrl: 'https://pen.org',
    type: 'Gala',
  },
  {
    title: 'Shakespeare and Company, Paris',
    date: '2026-06-07',
    dateDisplay: 'June 7, 2026',
    location: 'Shakespeare and Company, Paris',
    description: 'Evening reading and signing. The Salt Archive in paperback will be available at the event.',
    ticketUrl: 'https://www.shakespeareandcompany.com',
    type: 'Reading',
  },
];
