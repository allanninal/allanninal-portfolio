/**
 * The repair-or-replace decision — the thing that makes an HVAC site different
 * from a plumber's or an electrician's.
 *
 * A blocked drain has one answer: fix it. A dead compressor on a fourteen-year-old
 * condenser has two, and the customer cannot choose between them without numbers.
 * This data drives the comparison table and the two seasonal tracks that replaced
 * the generic six-service grid, which was the shape every other trade template in
 * this library already had.
 *
 * FIGURES ARE REAL 2026 US AVERAGES, not invented. Sources in RESEARCH.md.
 */

/** The two rules the trade actually uses, stated plainly. */
export const rules = [
  {
    name: 'The 50% rule',
    body:
      'If one repair costs more than half what a replacement system is worth, replacing is the better financial call. The same applies cumulatively: spend more than half a new system across 12–24 months of repairs and you are funding a system that is already leaving.',
  },
  {
    name: 'The age rule',
    body:
      'Central AC and heat pumps last about 10–15 years. Gas furnaces last 15–20. Inside that window a repair usually buys real time; past it, a repair often buys a season.',
  },
  {
    name: 'The efficiency rule',
    body:
      'Moving off an old SEER 9–10 unit to a current SEER2 system cuts cooling energy by more than a third. On a system that is already failing, that saving is part of the replacement cost, not a bonus on top of it.',
  },
];

/** Real installed replacement ranges, 2026 US averages. */
export const replacement = [
  { system: 'Central air conditioner', low: 3500, high: 7500, life: '10–15 years' },
  { system: 'Gas furnace', low: 3000, high: 6500, life: '15–20 years' },
  { system: 'Heat pump', low: 4000, high: 10000, life: '10–15 years' },
  { system: 'Full system — AC and furnace together', low: 6000, high: 12000, life: '—' },
];

/**
 * The decision table. `verdict` is deliberately mixed: a table where every row
 * says "replace" is a sales page, not a decision aid.
 */
export const decisions = [
  {
    age: 'Under 8 years',
    repair: 'Under $500',
    verdict: 'repair',
    why: 'Well inside its service life and cheap to put right. Replacing now throws away years you have already paid for.',
  },
  {
    age: 'Under 8 years',
    repair: '$500 – $1,500',
    verdict: 'repair',
    why: 'Still repair, but ask what failed. One expensive part on a young system is bad luck; two in a year is a pattern.',
  },
  {
    age: '8 – 12 years',
    repair: 'Under $1,000',
    verdict: 'repair',
    why: 'Below half a replacement, and the system has usable life left. We will tell you what we expect to fail next.',
  },
  {
    age: '8 – 12 years',
    repair: 'Over $2,000',
    verdict: 'either',
    why: 'The genuinely hard case. It turns on whether the cabinet and coil are sound and how long you plan to stay in the house.',
  },
  {
    age: '12 – 15 years',
    repair: 'Over $1,500',
    verdict: 'replace',
    why: 'Past half a new system on equipment near the end of its life. A repair here buys a season, not a decade.',
  },
  {
    age: 'Over 15 years',
    repair: 'Any major repair',
    verdict: 'replace',
    why: 'At this age the efficiency gain alone changes the arithmetic. We will still repair it if you ask — it is your money — but we will have told you first.',
  },
];

/** Two seasonal tracks. HVAC is one trade doing two opposite jobs. */
export const seasons = {
  cooling: {
    label: 'Cooling · April to September',
    items: [
      { term: 'Warning sign', def: 'Runs constantly and the house never reaches setpoint.' },
      { term: 'Usually', def: 'Low refrigerant from a leak, a failing capacitor, or a condenser packed with cottonwood.' },
      { term: 'Do first', def: 'Change the filter and hose the outdoor coil. Both are free and both fix this surprisingly often.' },
      { term: 'Call us when', def: 'The outdoor unit hums but the fan does not turn, or there is ice on the line.' },
    ],
  },
  heating: {
    label: 'Heating · October to March',
    items: [
      { term: 'Warning sign', def: 'Short cycling — the burner lights, runs briefly, and shuts off again.' },
      { term: 'Usually', def: 'A dirty flame sensor, a blocked flue, or a restricted filter overheating the exchanger.' },
      { term: 'Do first', def: 'Change the filter, and check nothing is stacked against the return.' },
      { term: 'Call us when', def: 'You smell gas, the CO alarm sounds, or the exchanger is cracked. Leave the house for the first two.' },
    ],
  },
};

/** What the repair number itself looks like, for scale. */
export const repairContext = {
  typical: '$150 – $2,500',
  average: '$350',
  note: 'Most repairs land near the bottom of that range. The ones that reach the top are compressors, heat exchangers and coils — which is exactly when the table above starts mattering.',
};
