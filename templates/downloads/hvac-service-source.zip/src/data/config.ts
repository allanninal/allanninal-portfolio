// Meridian Air — configuration data
// Day 71 of the 365-template roadmap

export const hvac = {
  name:        'Meridian Air',
  tagline:     "Kansas City's Heating & Cooling Specialists — NATE-Certified, 24/7 No-Heat Response",
  description: 'Licensed & insured HVAC contractor serving Kansas City, MO and the surrounding metro. AC repair and replacement, furnace service, heat pump installation, ductwork, indoor air quality, and 24/7 emergency no-heat/no-cool response.',
  phone:       '(816) 555-0193',
  phoneHref:   'tel:+18165550193',
  email:       'hello@meridianair.com',
  address:     '4120 Wyandotte St',
  city:        'Kansas City',
  state:       'MO',
  zip:         '64111',
  license:     'MO HVAC Contractor License #MC-41207 · EPA 608 Universal',
  licensed:    true,
  insured:     true,
  bonded:      true,
  founded:     2007,
  yearsExperience: 18,
  bookUrl:     '#',
  owner: {
    name:     'Ray Delgado',
    title:    'Owner & NATE-Certified Technician',
    initials: 'RD',
    bio:      "I started Meridian Air in 2007 after twelve years installing and servicing systems for a regional contractor. What pushed me out on my own was watching too many crews sell oversized equipment because it was easier than running the numbers. An oversized air conditioner short-cycles, never pulls the humidity out, and dies years early — and the homeowner pays for it twice. We run a Manual J load calculation on every replacement, no exceptions. It takes an extra hour and it is the difference between a system that lasts eighteen years and one that limps to ten.",
  },
  instagram: '#',
  facebook:  '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Meridian Air — HVAC Repair & Install, Kansas City MO',
  description:   "Kansas City's NATE-certified heating and cooling contractor. AC repair, furnaces, heat pumps, ductwork and air quality. 24/7 no-heat response.",
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

export const services = [
  {
    slug:     'ac-repair',
    name:     'AC Repair & Replacement',
    icon:     'cooling',
    tagline:  'Warm air, short cycling, or a system past its years.',
    desc:     'Diagnosis and repair for air conditioners blowing warm, freezing up, short cycling or tripping the breaker. When a system is beyond economical repair we size the replacement with a Manual J load calculation rather than matching whatever was there before.',
    includes: ['Refrigerant leak detection', 'Capacitor & contactor replacement', 'Condenser coil cleaning', 'Frozen evaporator diagnosis', 'Manual J sizing on replacements', 'Old equipment haul-away'],
  },
  {
    slug:     'furnace',
    name:     'Furnace Repair & Install',
    icon:     'heating',
    tagline:  'No heat, short cycling, or a cracked heat exchanger.',
    desc:     'Gas and electric furnace service across every major brand. We test the heat exchanger for cracks on every no-heat call — a cracked exchanger is a carbon monoxide risk, and it is the one finding we will never quietly leave in service.',
    includes: ['No-heat diagnosis & repair', 'Heat exchanger inspection', 'Ignitor & flame sensor service', 'Blower motor replacement', 'Gas & electric furnace install', 'Combustion & CO safety testing'],
  },
  {
    slug:     'heat-pumps',
    name:     'Heat Pump Systems',
    icon:     'heatpump',
    tagline:  'Cold-climate and dual-fuel, sized for Missouri winters.',
    desc:     'Modern cold-climate heat pumps hold their capacity far lower than the units people remember from the nineties. We install single-zone and multi-zone ductless systems, and dual-fuel setups that hand off to the furnace at the balance point where gas actually becomes cheaper.',
    includes: ['Cold-climate heat pump install', 'Ductless mini-split systems', 'Dual-fuel changeover setup', 'Balance point calculation', 'Federal & utility rebate paperwork', 'Existing-ductwork assessment'],
  },
  {
    slug:     'ductwork',
    name:     'Ductwork & Airflow',
    icon:     'duct',
    tagline:  'The room that never gets comfortable, solved properly.',
    desc:     'Static pressure testing, duct leakage sealing, return-air correction and new duct runs. Most comfort complaints blamed on the equipment are really an airflow problem — a bedroom that stays hot is usually starved of return air, not short of tonnage.',
    includes: ['Static pressure testing', 'Duct leakage sealing', 'Return-air correction', 'New supply runs & registers', 'Zoning damper installation', 'Attic & crawlspace duct insulation'],
  },
  {
    slug:     'air-quality',
    name:     'Indoor Air Quality',
    icon:     'air',
    tagline:  'Humidity, filtration and ventilation that actually work.',
    desc:     'Whole-home humidifiers for dry winter air, dehumidification for August, media filter cabinets that hold a real MERV 13 without choking the blower, and fresh-air ventilation for tight modern envelopes. Sized to the system so filtration does not cost you airflow.',
    includes: ['Whole-home humidifiers', 'Media filter cabinets (MERV 11–13)', 'Dehumidification systems', 'UV coil treatment', 'Fresh-air ventilation', 'Duct inspection & cleaning referral'],
  },
  {
    slug:     'emergency',
    name:     'Emergency No-Heat / No-Cool',
    icon:     'emergency',
    tagline:  '24/7 — when the house is 55°F or climbing past 85°F.',
    desc:     'Complete heating or cooling failure, a furnace locking out on repeated ignition faults, a carbon monoxide alarm, or an outdoor unit that will not start in August. We dispatch within the hour, and a technician answers the phone rather than an answering service.',
    includes: ['24/7/365 response', '1-hour dispatch window', 'No-heat & no-cool priority', 'CO alarm investigation', 'Temporary heat available', 'After-hours parts stocked on trucks'],
  },
];

export const whyUs = [
  {
    title:   'Manual J on Every Install',
    desc:    'We calculate the actual load — square footage, insulation, window area, orientation, infiltration — before quoting equipment. Replacing like-for-like carries forward whatever mistake was made the first time, and oversizing is the most common one.',
    stat:    '100%',
    statLabel: 'Load-Calculated Installs',
  },
  {
    title:   'NATE-Certified Technicians',
    desc:    'Every technician on our payroll holds NATE certification and EPA 608 refrigerant handling. No subcontracted install crews, and no helper running a service call alone in their second week.',
    stat:    'NATE',
    statLabel: 'Certified, Every Tech',
  },
  {
    title:   'Answered by a Technician',
    desc:    'When the heat quits at 2am in February you get someone who can tell you whether it is safe to wait until morning — not a call centre taking a message for the morning dispatcher.',
    stat:    '24/7',
    statLabel: 'Real Person, Any Hour',
  },
  {
    title:   '18 Years in Kansas City',
    desc:    'We know which subdivisions were built with undersized returns, which decade of equipment is failing now, and how a Missouri August behaves against the design day the equipment was rated for.',
    stat:    '18',
    statLabel: 'Years Serving KC',
  },
];

export const serviceArea = [
  {
    zone:       'Kansas City Central',
    neighborhoods: ['Westport', 'Brookside', 'Waldo', 'Country Club Plaza', 'Midtown', 'Hyde Park'],
    zips:       ['64111', '64112', '64113', '64114', '64110', '64109'],
  },
  {
    zone:       'The Northland',
    neighborhoods: ['Gladstone', 'Liberty', 'Parkville', 'Riverside', 'Kearney', 'Smithville'],
    zips:       ['64118', '64068', '64152', '64150', '64060', '64089'],
  },
  {
    zone:       'South Metro',
    neighborhoods: ["Lee's Summit", 'Grandview', 'Raymore', 'Belton', 'Blue Springs', 'Lone Jack'],
    zips:       ['64063', '64030', '64083', '64012', '64015', '64070'],
  },
  {
    zone:       'Johnson County, KS',
    neighborhoods: ['Overland Park', 'Leawood', 'Prairie Village', 'Olathe', 'Lenexa', 'Shawnee'],
    zips:       ['66210', '66211', '66208', '66061', '66215', '66203'],
  },
];

export const pricing = [
  {
    name:     'Diagnostic Visit',
    price:    '$89',
    period:   'per call',
    desc:     'A technician comes out, tests the system and gives you a flat-rate repair price before touching anything. The $89 is credited against the repair if you go ahead, and waived entirely for Meridian Club members.',
    includes: [
      'Full system diagnostic',
      'Flat-rate quote before work starts',
      'Credited toward the repair',
      'Same-day slots before noon',
      'No overtime charge at weekends',
    ],
    cta:      'Book a diagnostic',
    featured: false,
    tag:      '',
  },
  {
    name:     'Seasonal Tune-Up',
    price:    '$129',
    period:   'per system',
    desc:     'The pre-season service that prevents most emergency calls. Cooling in spring, heating in autumn — 21 checkpoints including refrigerant charge, combustion analysis and a heat exchanger inspection.',
    includes: [
      '21-point system inspection',
      'Refrigerant charge verification',
      'Combustion & CO testing',
      'Heat exchanger inspection',
      'Condenser coil clean',
      'Written condition report',
    ],
    cta:      'Book a tune-up',
    featured: true,
    tag:      'Most booked',
  },
  {
    name:     'System Replacement',
    price:    'Free',
    period:   'quote & load calc',
    desc:     'A full Manual J load calculation, ductwork assessment and equipment options at three efficiency tiers — with the operating-cost difference shown, not just the sticker price. No charge, no obligation.',
    includes: [
      'Manual J load calculation',
      'Static pressure & duct assessment',
      'Three efficiency tiers quoted',
      'Operating-cost comparison',
      'Rebate & tax credit paperwork',
      'Financing options available',
    ],
    cta:      'Request a quote',
    featured: false,
    tag:      '',
  },
];

export const reviews = [
  {
    name:    'Alicia W.',
    detail:  'Brookside homeowner',
    rating:  5,
    quote:   'Two other companies quoted a five-ton unit because that is what we had. Ray ran the load calculation and told us the house needed three and a half — and that the old one had been short cycling for years, which explained why upstairs was always clammy. The new system is quieter, the humidity problem is gone, and it cost less than the quotes we turned down.',
  },
  {
    name:    'Marcus T.',
    detail:  'Overland Park, KS',
    rating:  5,
    quote:   'Furnace died on the coldest night of January. I called at 11pm expecting an answering service and got a technician who walked me through shutting off the gas, then had someone at the house before 1am. They brought space heaters in for the family while they worked. You do not forget that.',
  },
  {
    name:    'The Nguyen family',
    detail:  'Liberty · 4 years in the Meridian Club',
    rating:  5,
    quote:   'We joined the maintenance club after a repair and have not had an emergency since. They come in spring and autumn, they call to schedule rather than making us chase them, and last visit they caught a failing ignitor before it left us without heat.',
  },
  {
    name:    'Dana K.',
    detail:  'Property manager · 22 units in Waldo',
    rating:  5,
    quote:   'I manage twenty-two units and Meridian handles all of them. What earns the contract each year is honesty about what needs replacing now versus what has another two seasons in it. A less scrupulous contractor could have sold me eight new systems by now.',
  },
  {
    name:    'Robert E.',
    detail:  'Prairie Village homeowner',
    rating:  5,
    quote:   'One bedroom over the garage ran ten degrees hotter than the rest of the house every summer. Three companies wanted to sell me a mini-split. Meridian tested static pressure, found the return was strangled, corrected the ductwork — and the room now matches the thermostat, for a fraction of the equipment I nearly bought.',
  },
];

export const faqs = [
  {
    q: 'How fast can you get here when the heat or the air conditioning fails?',
    a: 'For a genuine no-heat or no-cool emergency we dispatch within the hour, any hour, any day of the year. A technician answers the phone — so if it is safe to wait until morning, we will tell you that honestly rather than charging an after-hours rate you did not need.',
  },
  {
    q: 'How often does a system actually need servicing?',
    a: 'Once a year per system as a minimum: cooling in spring, heating in autumn. Most manufacturers require documented annual maintenance to keep the parts warranty valid, and the majority of emergency calls we run are failures a tune-up would have caught — a weak capacitor, a dirty flame sensor, a refrigerant charge that has been drifting for two summers.',
  },
  {
    q: 'What size air conditioner does my house need?',
    a: 'It is not a square-footage rule of thumb, which is exactly why so many homes are oversized. We run a Manual J load calculation using insulation levels, window area and orientation, ceiling heights and air infiltration. An oversized unit cools the air quickly, shuts off before it removes humidity, and wears itself out short cycling — a house that feels cold and clammy is usually oversized, not underpowered.',
  },
  {
    q: 'Is it worth repairing my system, or should I replace it?',
    a: 'A reasonable starting point is to multiply the repair cost by the age of the system; if that exceeds replacement cost, replacing usually wins. Beyond that we look at whether it still runs R-22, how it compares against current efficiency, and whether the ductwork can support a new system. We give you both numbers and the operating-cost difference, then leave the decision with you.',
  },
  {
    q: 'Do heat pumps actually work through a Missouri winter?',
    a: 'Modern cold-climate heat pumps hold useful capacity well below freezing — a long way from the reputation the technology earned decades ago. For most Kansas City homes we recommend dual fuel: the heat pump carries the majority of the season at lower cost and the furnace takes over below the balance point, where gas becomes the cheaper fuel. We calculate that crossover for your house and your utility rates.',
  },
  {
    q: 'What is happening with refrigerant, and does it affect me?',
    a: 'R-22 has not been produced since 2020, so systems still running it face steep and rising costs for any refrigerant repair. The industry has also moved on from R-410A to lower-GWP refrigerants such as R-454B on new equipment. If your system uses R-22, a significant leak is usually the point where replacement makes more sense than repair.',
  },
  {
    q: 'How often should I change the filter?',
    a: 'A one-inch filter every one to three months; a four- or five-inch media filter every six to twelve. Pets, allergies and construction dust shorten all of those. The costly mistake is fitting a very dense filter to a system that cannot pull air through it — high MERV in a thin filter starves the blower and can freeze the coil. If you want serious filtration the answer is a deeper cabinet, not a denser one-inch.',
  },
  {
    q: 'Are you licensed and insured, and do you pull permits?',
    a: 'Meridian Air holds Missouri HVAC Contractor License #MC-41207 and every technician carries EPA 608 Universal certification. We carry $2M general liability and workers\' compensation on all employees. Equipment changeouts are permitted and inspected wherever the jurisdiction requires it — which protects your warranty and your position when you sell the house.',
  },
];
