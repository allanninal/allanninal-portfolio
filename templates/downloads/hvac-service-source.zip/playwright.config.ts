import { defineConfig, devices } from '@playwright/test';

process.env.PUBLIC_BASE_PATH ??= '/';

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? 'github' : 'list',
  use: {
    baseURL: 'http://localhost:4321',
    trace: 'retain-on-failure',
  },
  webServer: {
    // The specs all goto('/'), but a production build is based at /hvac-service/,
    // so '/' served Astro's 404 page and axe audited THAT — 526 phantom contrast
    // violations. Build the test server at the root, as test:lighthouse already does.
    command: 'PUBLIC_BASE_PATH=/ PUBLIC_TEMPLATE_HUB_URL= npm run build && npm run preview -- --host 127.0.0.1 --port 4321',
    url: 'http://localhost:4321/',
    reuseExistingServer: !process.env.CI,
    timeout: 180_000,
    env: {
      PUBLIC_SITE_URL:         'http://localhost:4321',
      PUBLIC_BASE_PATH:        '/',
      PUBLIC_TEMPLATE_HUB_URL: '',
    },
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        channel: 'chrome',
      },
    },
  ],
});
