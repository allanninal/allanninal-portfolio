import { test, expect } from '@playwright/test';

test.describe('Meridian Air — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title is set correctly', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Meridian Air');
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of ['services', 'service-area', 'pricing', 'reviews', 'about', 'faq', 'contact']) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('tel links are present', async ({ page }) => {
    await page.goto('/');
    const telLinks = page.locator('a[href^="tel:"]');
    const count = await telLinks.count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('mailto link is present', async ({ page }) => {
    await page.goto('/');
    const mailLinks = page.locator('a[href^="mailto:"]');
    const count = await mailLinks.count();
    expect(count).toBeGreaterThanOrEqual(1);
  });

  test('external links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const externalLinks = page.locator('a[target="_blank"][rel*="noopener"]');
    const count = await externalLinks.count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    const favicon = page.locator('link[rel="icon"]');
    await expect(favicon).toBeAttached();
  });

  test('pricing section has three tiers', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBe(3);
  });

  test('service cards show all 6 services', async ({ page }) => {
    await page.goto('/');
    const serviceCards = page.locator('.service-card');
    const count = await serviceCards.count();
    expect(count).toBe(6);
  });

  test('review cards show 5 reviews', async ({ page }) => {
    await page.goto('/');
    const reviewCards = page.locator('.review-card');
    const count = await reviewCards.count();
    expect(count).toBe(5);
  });

  test('service area zones are all present', async ({ page }) => {
    await page.goto('/');
    const zones = page.locator('.area-zone');
    const count = await zones.count();
    expect(count).toBe(4);
  });

  test('about section is present with owner avatar', async ({ page }) => {
    await page.goto('/');
    const aboutSection = page.locator('#about');
    await expect(aboutSection).toBeAttached();
    const avatar = page.locator('.about-avatar');
    await expect(avatar).toBeAttached();
  });

  test('cred chips are present in about section', async ({ page }) => {
    await page.goto('/');
    const credChips = page.locator('.cred-chip');
    const count = await credChips.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('emergency bar is in DOM', async ({ page }) => {
    await page.goto('/');
    const emergencyBar = page.locator('.emergency-bar');
    await expect(emergencyBar).toBeAttached();
  });

  test('contact form is present', async ({ page }) => {
    await page.goto('/');
    const form = page.locator('.contact-form');
    await expect(form).toBeAttached();
  });

  test('FAQ section has multiple items', async ({ page }) => {
    await page.goto('/');
    const faqItems = page.locator('details');
    const count = await faqItems.count();
    expect(count).toBeGreaterThanOrEqual(6);
  });
});
