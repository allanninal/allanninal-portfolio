import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Meridian Air — accessibility', () => {
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();
    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  test('heading hierarchy is logical', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toHaveCount(1);
  });

  // The six-card service grid was removed when this template was retrofitted
  // away from being structurally identical to electrician. What replaced it is
  // a decision table, and the table is the accessibility-relevant part: it must
  // carry real header semantics, not be a grid of divs pretending.
  test('the decision tables are real tables with header semantics', async ({ page }) => {
    await page.goto('/');
    const tables = page.locator('table.decision-table');
    expect(await tables.count()).toBe(2);
    const first = tables.first();
    expect(await first.locator('thead th[scope="col"]').count()).toBe(4);
    expect(await first.locator('tbody th[scope="row"]').count()).toBe(6);
    await expect(first.locator('caption')).toHaveCount(1);
  });

  test('each seasonal track is a definition list', async ({ page }) => {
    await page.goto('/');
    const lists = page.locator('#seasons dl.season-list');
    expect(await lists.count()).toBe(2);
    for (let i = 0; i < 2; i++) {
      expect(await lists.nth(i).locator('dt').count()).toBe(4);
      expect(await lists.nth(i).locator('dd').count()).toBe(4);
    }
  });

  test('pricing cards are present', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('review cards are present', async ({ page }) => {
    await page.goto('/');
    const reviewCards = page.locator('.review-card');
    const count = await reviewCards.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('area zones are present', async ({ page }) => {
    await page.goto('/');
    const zones = page.locator('.area-zone');
    const count = await zones.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('emergency bar is visible', async ({ page }) => {
    await page.goto('/');
    const emergencyBar = page.locator('.emergency-bar');
    await expect(emergencyBar).toBeVisible();
  });

  test('emergency bar has tel link', async ({ page }) => {
    await page.goto('/');
    const telLinks = page.locator('.emergency-bar a[href^="tel:"]');
    const count = await telLinks.count();
    expect(count).toBeGreaterThanOrEqual(1);
  });
});
