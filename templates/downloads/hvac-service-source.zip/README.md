# Day 71 — HVAC Service Template

**Live demo:** https://example.com/

Part of the [365 Templates](https://example.com/templates) project — one free Astro template shipped every day.

---

## What's in the box

Dark-default graphite + copper. Manual J sizing story, seasonal tune-up club, HVACBusiness schema with 24-city areaServed.

**Persona:** Meridian Air. All business data is fictional — replace it in `src/data/config.ts` before you ship.

**Page sections** (the `<h2>`s on the homepage, in order):

- Heating and cooling for Kansas City homes.
- Sized properly. Serviced on time. Answered at 2am.
- We cover Kansas City and the wider metro.
- Flat-rate pricing. No surprises.
- What Kansas City homeowners say.
- Hi, I'm Ray Delgado.
- Common questions
- Request service or ask a question.
- No heat? No cooling? Call now, any hour.

**Additional pages:** `/maintenance-plans/`

---

## Stack

- [Astro](https://astro.build) 4.x (static output)
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [Chivo](https://fonts.google.com/specimen/Chivo) + [Be Vietnam Pro](https://fonts.google.com/specimen/Be+Vietnam+Pro) via `@fontsource`
- Playwright + axe-core for accessibility testing
- Lighthouse CI (≥ 95 all categories)

---

## Getting started

```bash
git clone https://github.com/<you>/<your-fork>.git
cd templates/hvac-service
npm install

npm run dev      # dev server
npm run build    # production build
```

### Environment variables

| Variable | Purpose | Required |
|----------|---------|----------|
| `PUBLIC_SITE_URL` | Canonical site URL | No (defaults to `https://example.com`) |
| `PUBLIC_BASE_PATH` | Base path for asset URLs (e.g. `/hvac-service/`) | No |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables the download bar + analytics (author's deploy only) | No |
| `PUBLIC_EDITION` | Set to `pro` to activate the Pro edition UI | No |

### Customization

1. Edit `src/data/config.ts` (and `src/data/maintenancePlans.ts`) — every string shown on the page lives there.
2. Replace `public/og-image.svg` and `public/favicon.svg` with your own brand marks.
3. Adjust the palette via the CSS custom properties in `src/styles/`.
4. Point any form `action` at your own endpoint (Formspree, Basin, your backend).

---

## Running tests

```bash
npm run test            # Playwright suite
npm run test:a11y       # axe WCAG 2.1 AA
npm run test:links      # link integrity
npm run test:lighthouse # Lighthouse ≥ 95 all categories
```

Tests run against system Google Chrome — no `playwright install` needed.

---

## License

MIT — free for personal and commercial use, under the repository’s root [LICENSE](../../LICENSE).

Made by [Allan Niñal](https://example.com) · [LinkedIn](#) · Day 71 of 365
