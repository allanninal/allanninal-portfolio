/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Dark-default by intentional design — OSS dev-tool register.
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Outfit Variable"', 'Outfit', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Outfit Variable"', 'Outfit', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"Geist Mono Variable"', '"Geist Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
      },
      fontSize: {
        'xs':  ['0.75rem',  { lineHeight: '1.5' }],
        'sm':  ['0.875rem', { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.65' }],
        'lg':  ['1.125rem', { lineHeight: '1.55' }],
        'xl':  ['1.25rem',  { lineHeight: '1.4' }],
        '2xl': ['1.5rem',   { lineHeight: '1.25' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.5rem',   { lineHeight: '1.05' }],
        '5xl': ['3.5rem',   { lineHeight: '1.0' }],
        '6xl': ['4.5rem',   { lineHeight: '0.98' }],
      },
      maxWidth: {
        '7xl': '70rem',  // ~1120px
        prose: '64ch',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
    },
  },
};
