// Single source of truth for `heron`. Cloning users edit this file.

export const project = {
  name: 'heron',
  tagline: 'Upload once. Never twice.',
  description:
    'A static-asset uploader for S3, R2, and B2 with built-in deduplication and fingerprinted output paths. Ship faster builds without re-uploading what you already have.',
  longDescription:
    'heron is a single-binary CLI written in Go. It hashes your build output, compares against a remote manifest, and uploads only what\'s changed. Works with any S3-compatible object store. No daemon, no config server, no telemetry.',
  version: 'v0.9.1',
  license: 'MIT',
  programmingLanguage: 'Go',
  // Repo slug — used for shields.io, contrib.rocks, GitHub link, edit links.
  repo: 'heron-cli/heron',
  repoUrl: 'https://github.com/heron-cli/heron',
  docsUrl: 'https://github.com/heron-cli/heron#readme',
  changelogUrl: 'https://github.com/heron-cli/heron/blob/main/CHANGELOG.md',
  // Stats are static — ship a script that updates them at deploy time
  // from the GitHub / pkg.go.dev API. Documented in README.
  stats: {
    stars: 2147,
    starsLabel: '2.1k',
    contributors: 38,
    monthlyDownloads: 184_000,
    monthlyDownloadsLabel: '184k',
  },
  operatingSystems: ['macOS', 'Linux', 'Windows'],
};

export const installs: Array<{ id: string; label: string; cmd: string; lang: string }> = [
  { id: 'brew',  label: 'Homebrew',  cmd: 'brew install heron-cli/heron/heron', lang: 'bash' },
  { id: 'go',    label: 'go install', cmd: 'go install github.com/heron-cli/heron@latest', lang: 'bash' },
  { id: 'curl',  label: 'curl | sh', cmd: 'curl -fsSL https://get.heron.dev | sh', lang: 'bash' },
];

export const features = [
  {
    icon: 'fingerprint',
    title: 'Content-addressed uploads',
    body: 'SHA-256 of every file becomes its remote path. Identical builds upload zero bytes. Diff-only deploys, even on a fresh CI runner.',
  },
  {
    icon: 'zap',
    title: 'No daemon, no server',
    body: 'A single static binary, ~6MB. No background process. No license server. Reads from your build directory, writes to S3. That\'s it.',
  },
  {
    icon: 'shield',
    title: 'Atomic deploys',
    body: 'Every push generates a manifest. Atomic switch-over via a single object update. Rollback by pointing to a prior manifest in one command.',
  },
  {
    icon: 'cloud',
    title: 'S3, R2, B2, MinIO',
    body: 'Anything S3-compatible. Tested daily against AWS S3, Cloudflare R2, Backblaze B2, and self-hosted MinIO. Bring your own credentials.',
  },
  {
    icon: 'gauge',
    title: 'Concurrent by default',
    body: 'Parallel multipart uploads with backpressure. 1,000-file deploys finish in 6–12 seconds on a residential connection. Configurable per profile.',
  },
  {
    icon: 'lock',
    title: 'Zero telemetry',
    body: 'No "phone home." No anonymous metrics. No license activation. Audit the source — it\'s 4,200 lines of Go and a Cobra config.',
  },
];

export const usedBy = [
  'Basalt CI',
  'Stackform',
  'Riverline',
  'Cinder Studio',
  'Northshore Labs',
  'Quill Editorial',
];

export const ctaLinks = {
  primary:   { label: 'Read the Docs', href: 'https://github.com/heron-cli/heron#readme', external: true },
  secondary: { label: 'View on GitHub', href: 'https://github.com/heron-cli/heron', external: true },
};

export const author = {
  name: 'Allan Ninal',
  handle: 'allanninal',
  email: 'landix.ninal@gmail.com',
  socials: {
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    github:   'https://github.com/allanninal',
    x:        'https://x.com/allannin',
  },
};
