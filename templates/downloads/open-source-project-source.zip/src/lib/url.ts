// Base-path-aware URL helper.
const BASE = import.meta.env.BASE_URL;
export function url(path: string): string {
  const trimmedBase = BASE.endsWith('/') ? BASE.slice(0, -1) : BASE;
  if (!path || path === '/') return BASE;
  if (path.startsWith('#')) return path;
  const trimmedPath = path.startsWith('/') ? path : `/${path}`;
  return `${trimmedBase}${trimmedPath}`;
}
