import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
const BASE = process.env.PUBLIC_BASE_PATH || '/open-source-project/';
const siteUrl = SITE.endsWith('/') ? SITE.slice(0, -1) : SITE;
const baseUrl = BASE.endsWith('/') ? BASE : `${BASE}/`;

export default defineConfig({
  site: siteUrl,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  // Shiki — vitesse-dark pairs with the #0D1117 GitHub-register base. It does NOT pass AA on
  // every token, contrary to what this comment used to claim: its comment colour is #758575DD,
  // and the DD alpha composites it to #687668 over the #121212 code ground — 3.91:1. Astro 4.x
  // does NOT forward Shiki's `colorReplacements` (verified: the token survives the build), so
  // that single token is overridden in global.css instead.
  markdown: {
    shikiConfig: {
      theme: 'vitesse-dark',
      wrap: false,
    },
  },
  integrations: [
    tailwind({ applyBaseStyles: false }),
    sitemap({ customPages: [`${siteUrl}${baseUrl}`] }),
  ],
});
