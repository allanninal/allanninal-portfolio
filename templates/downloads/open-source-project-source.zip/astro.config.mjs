import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://templates.allanninal.dev';
const BASE = process.env.PUBLIC_BASE_PATH || '/open-source-project/';
const siteUrl = SITE.endsWith('/') ? SITE.slice(0, -1) : SITE;
const baseUrl = BASE.endsWith('/') ? BASE : `${BASE}/`;

export default defineConfig({
  site: siteUrl,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  // Shiki — vitesse-dark pairs with the #0D1117 GitHub-register base AND
  // passes WCAG AA on every token (github-dark's comment color #6A737D
  // sits at 3.04:1 on its own bg, which axe flags).
  markdown: {
    shikiConfig: { theme: 'vitesse-dark', wrap: false },
  },
  integrations: [
    tailwind({ applyBaseStyles: false }),
    sitemap({ customPages: [`${siteUrl}${baseUrl}`] }),
  ],
});
