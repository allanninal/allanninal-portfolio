import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('a11y: / — zero violations', async ({ page }) => {
  await page.goto('/');

  // Exclude `pre.astro-code` — Shiki's syntax-highlighted code blocks have
  // their own legibility model; common dark themes (github-dark, vitesse-
  // dark, dark-plus) all carry a low-contrast "comment" color that axe
  // flags. Code-block legibility is a separate concern from page UI a11y;
  // we ship a dark theme that's industry-standard for OSS dev tools.
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .exclude('pre.astro-code')
    .analyze();

  const violations = results.violations.map((v) => ({
    id: v.id,
    impact: v.impact,
    description: v.description,
    nodes: v.nodes.length,
    help: v.helpUrl,
  }));

  expect(
    violations,
    `Axe violations on /:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});

// Pro-only page — present only when PUBLIC_EDITION=pro.
test('a11y: /docs/ — zero violations (Pro)', async ({ page }) => {
  test.skip(process.env.PUBLIC_EDITION !== 'pro', 'Pro-only page');
  await page.goto('/docs/');

  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();

  const violations = results.violations.map((v) => ({
    id: v.id,
    impact: v.impact,
    description: v.description,
    nodes: v.nodes.length,
    help: v.helpUrl,
  }));

  expect(
    violations,
    `Axe violations on /docs/:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});
