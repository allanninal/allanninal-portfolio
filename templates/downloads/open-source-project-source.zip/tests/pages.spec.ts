import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    const errors: string[] = [];
    // Ignore third-party noise from the author-deploy analytics/ads stack
    // (GA + AdSense), which 403/CSP-warn under a real Chrome but never under
    // the bundled headless browser. None of it is the template's own code.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const isThirdParty = (m: ConsoleMessage) =>
      THIRD_PARTY.test(m.text()) ||
      THIRD_PARTY.test(m.location()?.url ?? '') ||
      /failed to load resource/i.test(m.text());
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() === 'error' && !isThirdParty(m)) errors.push(`console.error: ${m.text()}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home meta description is set', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home emits SoftwareSourceCode JSON-LD with required fields', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const src = docs.find((d) => d && d['@type'] === 'SoftwareSourceCode');
  expect(src, 'SoftwareSourceCode JSON-LD missing').toBeTruthy();
  expect(src.name).toBe('heron');
  expect(src.codeRepository).toContain('github.com');
  expect(src.programmingLanguage).toBe('Go');
  expect(src.license).toContain('MIT');
  expect(src.version).toBeTruthy();
});

test('home emits SoftwareApplication JSON-LD with offer + OS', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const app = docs.find((d) => d && d['@type'] === 'SoftwareApplication');
  expect(app, 'SoftwareApplication JSON-LD missing').toBeTruthy();
  expect(app.applicationCategory).toBe('DeveloperApplication');
  expect(app.operatingSystem).toContain('macOS');
  expect(app.operatingSystem).toContain('Linux');
  expect(app.offers).toBeTruthy();
  expect(String(app.offers.price)).toBe('0');
  expect(app.softwareVersion).toBeTruthy();
});

test('OG image absolute and 1200×630', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toMatch(/^https?:\/\//);
  expect(og).toContain('og-image.png');
  expect(await page.locator('meta[property="og:image:width"]').getAttribute('content')).toBe('1200');
  expect(await page.locator('meta[property="og:image:height"]').getAttribute('content')).toBe('630');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  expect(await page.locator('meta[name="twitter:card"]').getAttribute('content')).toBe('summary_large_image');
});

test('canonical link is absolute', async ({ page }) => {
  await page.goto('/');
  const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
  expect(canonical).toMatch(/^https?:\/\//);
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});
