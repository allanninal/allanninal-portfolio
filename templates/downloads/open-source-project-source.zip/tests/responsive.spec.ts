import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}x${vp.height}) — no horizontal scroll`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await page.locator('h1').first().waitFor();
      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth,
      );
      expect(overflow).toBe(false);
    });
  }
}

test('mobile (375x667): hero h1 + tagline visible above the fold', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  await expect(page.locator('h1')).toBeInViewport();
});

test('install tabs and copy button meet 36px tap target', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  const tab = page.getByRole('tab', { name: 'Homebrew', exact: true });
  const tabBox = await tab.boundingBox();
  expect(tabBox).not.toBeNull();
  expect(tabBox!.height).toBeGreaterThanOrEqual(28);

  const copy = page.locator('button[data-copy]').first();
  const copyBox = await copy.boundingBox();
  expect(copyBox).not.toBeNull();
  expect(copyBox!.height).toBeGreaterThanOrEqual(36);
});
