import type { Page } from '@playwright/test';

// The Pro edition (PUBLIC_EDITION=pro) adds the in-house /docs/ page; the free
// build redirects it (to the external README), so it's only a real route under Pro.
export const ROUTES = [
  '/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/docs/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];
