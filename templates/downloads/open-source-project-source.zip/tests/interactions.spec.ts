import { test, expect } from '@playwright/test';

// ── Hero ───────────────────────────────────────────────────────────────

test('hero shows project name and tagline', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toContainText(/upload once/i);
  await expect(page.locator('h1')).toContainText(/never twice/i);
});

test('hero shows version + license + language eyebrow', async ({ page }) => {
  await page.goto('/');
  // First label-eyebrow contains "Go · MIT · v0.9.1"
  const eyebrow = page.locator('p.label-eyebrow').first();
  await expect(eyebrow).toContainText('Go');
  await expect(eyebrow).toContainText('MIT');
  await expect(eyebrow).toContainText('v0.9.1');
});

test('static star count visible in hero (layout doesn\'t depend on shields.io)', async ({ page }) => {
  await page.goto('/');
  // "★ 2.1k" is hardcoded text — independent of shields.io image
  await expect(page.getByText('2.1k', { exact: false }).first()).toBeVisible();
  await expect(page.getByText(/stars on github/i).first()).toBeVisible();
});

// ── Install tabs (vanilla, accessible) ────────────────────────────────

test('install tabs render all three options (Homebrew, go install, curl | sh)', async ({ page }) => {
  await page.goto('/');
  for (const label of ['Homebrew', 'go install', 'curl | sh']) {
    await expect(page.getByRole('tab', { name: label, exact: true })).toBeVisible();
  }
});

test('first install tab is selected by default and shows brew command', async ({ page }) => {
  await page.goto('/');
  const brewTab = page.getByRole('tab', { name: 'Homebrew', exact: true });
  expect(await brewTab.getAttribute('aria-selected')).toBe('true');
  // brew install command visible
  await expect(page.getByText('brew install heron-cli/heron/heron')).toBeVisible();
});

test('clicking the curl tab swaps the visible install command', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('tab', { name: 'curl | sh', exact: true }).click();
  await expect(page.getByText('curl -fsSL https://get.heron.dev')).toBeVisible();
  // brew snippet hidden (its panel has hidden attribute)
  const brewPanel = page.locator('[data-install-panel="brew"]');
  expect(await brewPanel.evaluate((el: HTMLElement) => el.hidden)).toBe(true);
});

test('keyboard arrow keys cycle install tabs', async ({ page }) => {
  await page.goto('/');
  const brew = page.getByRole('tab', { name: 'Homebrew', exact: true });
  await brew.focus();
  await page.keyboard.press('ArrowRight');
  // After ArrowRight, "go install" should be selected and focused
  const go = page.getByRole('tab', { name: 'go install', exact: true });
  expect(await go.getAttribute('aria-selected')).toBe('true');
});

// ── Copy-to-clipboard ─────────────────────────────────────────────────

test('Copy button writes the install command to clipboard and shows feedback', async ({ page, browserName, context }) => {
  // Grant clipboard permissions in Chromium
  if (browserName === 'chromium') {
    await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  }

  await page.goto('/');
  const copyBtn = page.locator('button[data-copy]').first();
  await copyBtn.click();
  // Feedback: button text changes to "Copied"
  await expect(copyBtn).toHaveText('Copied');
  // Verify clipboard
  const text = await page.evaluate(() => navigator.clipboard.readText());
  expect(text).toContain('brew install');
});

// ── Stats row ─────────────────────────────────────────────────────────

test('stats row shows three numbers with labels', async ({ page }) => {
  await page.goto('/');
  const numbers = page.locator('.stat-num');
  expect(await numbers.count()).toBe(3);
  // Use exact match scoped to .stat-label so "Contributors" doesn't also
  // match the section heading or the "Built with help from N people" line.
  for (const label of ['GitHub stars', 'Contributors', 'Monthly downloads']) {
    await expect(page.locator('.stat-label', { hasText: new RegExp(`^${label}$`, 'i') })).toBeVisible();
  }
});

// ── Features ─────────────────────────────────────────────────────────

test('features grid renders 6 cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#features ul[role="list"] > li');
  expect(await cards.count()).toBe(6);
});

// ── How it works — has Shiki-highlighted code blocks ─────────────────

test('how it works renders two Shiki code blocks (toml + bash)', async ({ page }) => {
  await page.goto('/');
  const codeBlocks = page.locator('pre.astro-code');
  expect(await codeBlocks.count()).toBeGreaterThanOrEqual(2);
});

test('Shiki code blocks render with a dark theme bg', async ({ page }) => {
  await page.goto('/');
  // Verify the bg is some dark color (not white). The exact theme is
  // vitesse-dark — picked because github-dark's comment color fails WCAG
  // AA (#6A737D on its own bg = 3.04:1, axe flags it).
  const bg = await page.locator('pre.astro-code').first().evaluate((el) => getComputedStyle(el).backgroundColor);
  const m = bg.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
  expect(m, `expected rgb() format; got: ${bg}`).not.toBeNull();
  const [r, g, b] = [m![1], m![2], m![3]].map(Number);
  expect(r).toBeLessThan(80);
  expect(g).toBeLessThan(80);
  expect(b).toBeLessThan(80);
});

// ── Used by ─────────────────────────────────────────────────────────

test('used-by lists fictional company names (no logos)', async ({ page }) => {
  await page.goto('/');
  for (const name of ['Basalt CI', 'Stackform', 'Riverline']) {
    await expect(page.getByText(name).first()).toBeVisible();
  }
  // No <img> elements inside the used-by section
  const imgs = page.locator('section[aria-labelledby="used-by-heading"] img');
  expect(await imgs.count()).toBe(0);
});

// ── Contributors ────────────────────────────────────────────────────

test('contributors section uses contrib.rocks image src', async ({ page }) => {
  await page.goto('/');
  const img = page.locator('img.contributors-img');
  await expect(img).toBeAttached();
  expect(await img.getAttribute('src')).toContain('contrib.rocks');
  expect(await img.getAttribute('loading')).toBe('lazy');
});

test('contributors fallback grid is hidden when the img has not failed', async ({ page }) => {
  await page.goto('/');
  // The CSS rule: .contributors-fallback { display: none }
  // Then a sibling-combinator override:
  //   .contributors-img.failed + .contributors-fallback { display: grid }
  //
  // In the test env contrib.rocks may fail (rate limit / DNS / blocked)
  // which triggers the img's `onerror` -> .failed class. We disarm both
  // the handler and the class to test the steady-state "image loaded fine"
  // CSS path deterministically.
  await page.evaluate(() => {
    const img = document.querySelector('img.contributors-img') as HTMLImageElement | null;
    if (!img) return;
    img.removeAttribute('onerror');
    img.classList.remove('failed');
  });
  const fallback = page.locator('.contributors-fallback');
  expect(await fallback.evaluate((el) => getComputedStyle(el).display)).toBe('none');
});

test('contributors fallback grid reveals when contrib.rocks img errors', async ({ page }) => {
  await page.goto('/');
  // Trigger the onerror handler manually
  await page.evaluate(() => {
    const img = document.querySelector('img.contributors-img') as HTMLImageElement | null;
    img?.classList.add('failed');
  });
  const fallback = page.locator('.contributors-fallback');
  expect(await fallback.evaluate((el) => getComputedStyle(el).display)).toBe('grid');
});

// ── CTA band ────────────────────────────────────────────────────────

test('CTA band shows "Read the Docs" + GitHub buttons', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('section[aria-labelledby="cta-heading"]');
  await expect(cta.getByRole('link', { name: /read the docs/i })).toBeVisible();
  await expect(cta.getByRole('link', { name: /view on github/i })).toBeVisible();
});

// ── Header GitHub link ─────────────────────────────────────────────

test('header has GitHub link pointing to the repo', async ({ page }) => {
  await page.goto('/');
  const ghLink = page.locator('header a').filter({ hasText: /github/i }).first();
  expect(await ghLink.getAttribute('href')).toContain('github.com');
});

// ── External-link safety ───────────────────────────────────────────

test('all target=_blank links use rel="noopener noreferrer"', async ({ page }) => {
  await page.goto('/');
  const ext = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];
  for (const a of ext) {
    const rel = await a.getAttribute('rel');
    const href = await a.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — rel="${rel}"`);
    }
  }
  expect(unsafe).toEqual([]);
});

// ── LinkedIn-primary in footer ────────────────────────────────────

test('footer LinkedIn link uses accent color', async ({ page }) => {
  await page.goto('/');
  const li = page.locator('footer a[href*="linkedin.com"]').first();
  const color = await li.evaluate((el) => getComputedStyle(el).color);
  // accent #14B8A6 → rgb(20, 184, 166)
  expect(color).toBe('rgb(20, 184, 166)');
});
