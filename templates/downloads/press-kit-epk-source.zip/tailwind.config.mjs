/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,mdx}'],
  theme: {
    extend: {
      colors: {
        // Near-black base — editorial dark background
        ink: {
          950: '#050505',
          900: '#0A0A0A',
          800: '#111111',
          700: '#1C1C1C',
          600: '#2A2A2A',
          500: '#3D3D3D',
          400: '#5A5A5A',
          300: '#888888',
          200: '#AAAAAA',
          100: '#CCCCCC',
          50:  '#F5F5F5',
        },
        // Warm cream — light sections
        cream: {
          50:  '#FDFBF8',
          100: '#FAF7F2',
          200: '#F0EBE3',
          300: '#E0D9D0',
          400: '#C8BFB5',
          500: '#A09690',
        },
        // Electric red — signature accent
        red: {
          700: '#B01F2A',
          600: '#CC2B38',
          500: '#E63946',
          400: '#EF5F6A',
          300: '#F7909A',
          100: '#FDDFE2',
          50:  '#FFF5F6',
        },
      },
      fontFamily: {
        display: ['"DM Serif Display"', 'Georgia', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        '10xl': ['10rem', { lineHeight: '0.9', letterSpacing: '-0.03em' }],
        '9xl':  ['8rem',  { lineHeight: '0.9', letterSpacing: '-0.025em' }],
      },
    },
  },
  plugins: [],
};
