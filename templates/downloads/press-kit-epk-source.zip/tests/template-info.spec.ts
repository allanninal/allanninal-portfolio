import { test, expect } from '@playwright/test';

// Asserts the canonical TemplateInfo download bar. Edition-aware: the Pro
// edition swaps the bar for a "Pro edition — live preview" strip with a locked
// Get-Pro link. Requires playwright.config.ts to set PUBLIC_TEMPLATE_HUB_URL.

const isPro = process.env.PUBLIC_EDITION === 'pro';
const barName = isPro
  ? /Pro edition — live preview/i
  : /Free template — download or fork/i;

test.describe('TemplateInfo download bar', () => {
  test('renders the canonical links with correct hrefs', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', { name: barName });
    await expect(bar).toBeVisible();

    const slug = 'press-kit-epk';
    await expect(bar.getByRole('link', { name: /All 365/i })).toHaveAttribute(
      'href',
      /www\.allanninal\.dev\/templates/
    );

    if (isPro) {
      await expect(bar.getByRole('link', { name: /Get Pro static/i })).toHaveAttribute(
        'href',
        '#'
      );
      await expect(bar.getByRole('link', { name: /Download free/i })).toHaveAttribute(
        'href',
        new RegExp(`/downloads/${slug}-static\\.zip$`)
      );
      return;
    }

    await expect(bar.getByRole('link', { name: /Download static/i })).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-static\\.zip$`)
    );
    await expect(bar.getByRole('link', { name: /Source \(Astro\)/i })).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-source\\.zip$`)
    );
    // This slot is the Pro CTA (same position as "Get Pro →" in the canonical
    // ai-startup-landing bar); it points at the Pro catalogue, not LinkedIn.
    // The "Build with me" wording on it is a stale label, tracked separately.
    await expect(bar.getByRole('link', { name: /Build with me/i })).toHaveAttribute(
      'href',
      /www\.allanninal\.dev\/templates\/pro\//
    );
  });

  test('contains zero github.com links in bar', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', { name: barName });
    const hrefs = await bar
      .locator('a')
      .evaluateAll((els) => els.map((e) => e.getAttribute('href') || ''));
    expect(hrefs.filter((h) => h.includes('github.com'))).toEqual([]);
  });

  test('bar shows the edition label', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', { name: barName });
    await expect(bar).toContainText(isPro ? 'live preview' : 'Day 27 of 365');
  });
});
