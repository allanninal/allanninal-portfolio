import { test, expect } from '@playwright/test';

test.describe('Press Kit EPK — smoke tests', () => {

  // Index page loads
  test('index page loads with h1 "Lila Marin"', async ({ page }) => {
    await page.goto('/');
    // Scoped to hero section to avoid nav/footer duplicates
    const hero = page.locator('#hero');
    const heading = hero.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText(/Lila\s*Marin/i);
  });

  test('index page has correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Lila Marin.*Press Kit/i);
  });

  // Sections visible
  test('bio section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#bio');
    await expect(section).toBeVisible();
    const h2 = section.getByRole('heading', { level: 2 });
    await expect(h2).toBeVisible();
  });

  test('photos section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#photos');
    await expect(section).toBeVisible();
    const heading = section.getByRole('heading', { level: 2 });
    await expect(heading).toBeVisible();
  });

  test('press photos section has 4 article cards', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#photos');
    const cards = section.locator('article');
    await expect(cards).toHaveCount(4);
  });

  test('branding section is present with 4 logo assets', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#branding');
    await expect(section).toBeVisible();
    const logoCards = section.locator('article');
    await expect(logoCards).toHaveCount(4);
  });

  test('discography section has 5 releases', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#music');
    await expect(section).toBeVisible();
    const releases = section.locator('article');
    await expect(releases).toHaveCount(5);
  });

  test('press quotes section has 6 blockquotes', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#press');
    await expect(section).toBeVisible();
    const quotes = section.locator('blockquote');
    await expect(quotes).toHaveCount(6);
  });

  test('tour dates section has 6 rows in table', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#tour');
    await expect(section).toBeVisible();
    const rows = section.locator('tbody tr');
    await expect(rows).toHaveCount(6);
  });

  test('contact section has 4 contact cards', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#contact');
    await expect(section).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(4);
  });

  test('footer is present with copyright text', async ({ page }) => {
    await page.goto('/');
    const footer = page.getByRole('contentinfo');
    await expect(footer).toBeVisible();
    await expect(footer).toContainText(/Lila Marin/i);
  });

  // Download links exist in dist
  test('press kit zip download link is present', async ({ page }) => {
    await page.goto('/');
    const hero = page.locator('#hero');
    const zipLink = hero.getByRole('link', { name: /Download Press Kit/i });
    await expect(zipLink).toBeVisible();
    const href = await zipLink.getAttribute('href');
    expect(href).toMatch(/press-kit\.zip$/);
  });

  test('one-sheet PDF download link is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#one-sheet');
    // Match by aria-label which is more stable than visible text with parens
    const pdfLink = section.locator('a[aria-label="Download one-sheet PDF"]');
    await expect(pdfLink).toBeVisible();
    const href = await pdfLink.getAttribute('href');
    expect(href).toMatch(/one-sheet\.pdf$/);
  });

  test('brand guidelines PDF download link is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#branding');
    const pdfLink = section.getByRole('link', { name: /Brand Guidelines/i });
    await expect(pdfLink).toBeVisible();
    const href = await pdfLink.getAttribute('href');
    expect(href).toMatch(/brand-guidelines\.pdf$/);
  });

  // Photo download links
  test('all 4 photo download links are present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#photos');
    const downloadLinks = section.locator('a[download]');
    await expect(downloadLinks).toHaveCount(4);
  });

  // Logo download links
  test('all 4 logo download links are present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#branding');
    const downloadLinks = section.locator('article a[download]');
    await expect(downloadLinks).toHaveCount(4);
  });

  // JSON-LD present
  test('JSON-LD script is present on page', async ({ page }) => {
    await page.goto('/');
    const ldScript = page.locator('script[type="application/ld+json"]');
    await expect(ldScript).toBeVisible({ visible: false }); // script tags aren't "visible" — check count
    expect(await ldScript.count()).toBeGreaterThan(0);
  });

  test('JSON-LD contains Person schema', async ({ page }) => {
    await page.goto('/');
    const ldScript = page.locator('script[type="application/ld+json"]');
    const content = await ldScript.textContent();
    const data = JSON.parse(content ?? '{}');
    const graph = data['@graph'] ?? [];
    const personNode = graph.find((n: { '@type': string }) => n['@type'] === 'Person');
    expect(personNode).toBeDefined();
    expect(personNode.name).toBe('Lila Marin');
  });

  test('JSON-LD contains MusicGroup schema', async ({ page }) => {
    await page.goto('/');
    const ldScript = page.locator('script[type="application/ld+json"]');
    const content = await ldScript.textContent();
    const data = JSON.parse(content ?? '{}');
    const graph = data['@graph'] ?? [];
    const mgNode = graph.find((n: { '@type': string }) => n['@type'] === 'MusicGroup');
    expect(mgNode).toBeDefined();
  });

  // Responsive: no horizontal overflow on mobile
  test('no horizontal overflow on mobile (375px)', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const docWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const vp = await page.evaluate(() => window.innerWidth);
    expect(docWidth).toBeLessThanOrEqual(vp + 1);
  });

  test('no horizontal overflow on tablet (768px)', async ({ page }) => {
    await page.setViewportSize({ width: 768, height: 1024 });
    await page.goto('/');
    const docWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const vp = await page.evaluate(() => window.innerWidth);
    expect(docWidth).toBeLessThanOrEqual(vp + 1);
  });

  // No github deep-links
  test('no github.com/allanninal/templates deep-links on page', async ({ page }) => {
    await page.goto('/');
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) => h.includes('github.com/allanninal/templates'));
    expect(deepLinks).toEqual([]);
  });

  // Navigation
  test('sticky nav is present', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: /Main navigation/i });
    await expect(nav).toBeVisible();
  });

  // Social strip
  test('social strip has Spotify link', async ({ page }) => {
    await page.goto('/');
    const social = page.getByRole('region', { name: /Social media links/i });
    await expect(social).toBeVisible();
    const spotifyLink = social.getByRole('link', { name: /Spotify/i });
    await expect(spotifyLink).toBeVisible();
  });

  // Stats in hero
  test('hero shows 80K monthly listeners stat', async ({ page }) => {
    await page.goto('/');
    const hero = page.locator('#hero');
    await expect(hero).toContainText('80K');
  });

  // Pro-only fact sheet — present only when PUBLIC_EDITION=pro.
  const isPro = process.env.PUBLIC_EDITION === 'pro';
  test.describe('Pro edition — fact sheet', () => {
    test.skip(!isPro, 'Pro-only page');

    test('Fact Sheet nav link points at /fact-sheet/', async ({ page }) => {
      await page.goto('/');
      const link = page.locator('a', { hasText: 'Fact Sheet' }).first();
      await expect(link).toHaveAttribute('href', /\/fact-sheet\/?$/);
    });

    test('fact sheet page renders the key sections', async ({ page }) => {
      await page.goto('/fact-sheet/');
      await expect(page.getByRole('heading', { level: 1 })).toContainText(/Lila\s*Marin/i);
      await expect(page.getByRole('heading', { name: /Quick facts/i })).toBeVisible();
      await expect(page.getByRole('heading', { name: /Recent releases/i })).toBeVisible();
      await expect(page.getByRole('heading', { name: /Contacts/i })).toBeVisible();
      await expect(page.locator('#print-fs')).toBeVisible();
    });
  });
});
