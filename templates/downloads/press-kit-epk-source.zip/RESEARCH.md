# RESEARCH: press-kit-epk (Day 27)

## Niche definition

**Electronic Press Kit (EPK) for indie musicians and public figures.** Journalists, bookers, A&R reps, podcast producers, and brand partners visit this page to grab facts, photos, and downloadable assets fast. The format is editorial-utilitarian: clear sections, instant scan, plenty of "download" CTAs.

**Persona:** Lila Marin — indie acoustic-electronic artist based in Portland, OR. A singer-songwriter bridging ambient folk and electronic production. Think: Bon Iver meets Bonobo. Three studio albums, 80K monthly Spotify listeners, international touring.

## Visual differentiation

### Prior days exhaustive summary
- Day 1: dark background, amber `#FFB020`, Inter + custom mono
- Day 2: light violet/cyan, `#7C3AED` + `#06B6D4`
- Day 3: dark, lime `#A3E635`
- Day 4: light coral `#C13B1F`, DM Sans
- Day 5: light, forest green `#2D6A4F`, Newsreader
- Day 6: dark cobalt + IBM Plex Serif
- Day 7: light, magenta, Manrope (TAKEN — see note below)
- Day 8: deep charcoal `#1A1917`, burnt orange `#C2410C`, Fraunces + General Sans
- Day 9: editorial CV, Source Serif 4 + Inter Tight
- Day 10: dark teal, Outfit + Geist Mono
- Day 11: cream + oxblood, Lora + Work Sans
- Day 12: aubergine + warm white, Fraunces + Space Grotesk
- Day 13: near-black + amber, Bricolage Grotesque + JetBrains Mono
- Day 14: warm paper + electric blue, Plus Jakarta Sans + JetBrains Mono
- Day 15: light terracotta, Archivo Black + Cormorant Garamond (TAKEN)
- Day 16: pure white + slate-indigo, DM Sans
- Day 17: ivory + Prussian blue, Playfair Display + Crimson Pro (TAKEN — Playfair)
- Day 18: deep teal + cream, Spectral + Public Sans
- Day 19: dark studio, podcast
- Day 20: emerald `#10B981` on near-black, Syne + Inter
- Day 21: blush/rosé `#C4847A`, Cormorant Garamond + DM Sans (TAKEN)
- Day 22: dark olive-charcoal + olive-gold, Libre Baskerville + Mulish
- Day 23: parchment cream + terracotta-rust, Fraunces + Plus Jakarta Sans
- Day 24: civic navy `#1E3A5F`, IBM Plex Serif + Inter
- Day 25: sage-grey `#4A6741` + warm linen, Raleway + Nunito
- Day 26: dark charcoal `#1A1A1A` + amber/brick/slate, Outfit

**Note on Playfair Display:** Used in Day 17 as display heading. For Day 27 we use **Crimson Pro** (the body font from Day 17) as the display face in a very different role — heavy editorial headlines. Paired with **Manrope** (used in Day 7 primarily as body, here as a tight grotesque label/nav font). The _combination_ Crimson Pro headline + Manrope UI is unique — Day 17 used Playfair headline + Crimson body, Day 7 used Manrope solo. Alternatively, we will use **Cormorant Garamond** → no, TAKEN Day 21. Best choice: **Playfair Display Bold** as a magazine-cover heading with **Inter Tight** as the grotesque. Wait — Playfair was Day 17. Let's use **Libre Baskerville** as the editorial display → TAKEN Day 22. 

**Final font decision:** Use **Lora** (available, used in Day 11 as body — but that was body role) as hero display + **Manrope** as UI/label. Actually, cleanest approach: use **Recoleta** (not yet used, similar vibe to editorial magazine serifs). Recoleta is not on Google Fonts, so use a reliable fallback. Instead, go with **DM Serif Display** (not yet used in any day) as the headline serif — it has a strong editorial quality. Pair with **Manrope** for grotesque utility labels.

**Final confirmed choice:** **DM Serif Display** + **Manrope** — both available on Google Fonts, neither combination used in any prior day.

### Color palette

**Editorial magazine-cover energy:**
- Background: `#0A0A0A` (near-black with warmth) — primary page background
- Surface light: `#FAF7F2` (warm cream) — bio, contact sections
- Surface mid: `#111111` (dark card background)
- Accent: `#E63946` (electric red — magazine cover red, completely distinct from every prior day)
- Accent hover: `#CC2B38`
- Text primary on dark: `#F5F5F5`
- Text secondary on dark: `#A8A29E`
- Text primary on light: `#0A0A0A`
- Text secondary on light: `#4A4A4A`
- Border/divider: `#2A2A2A` (on dark bg) / `#E0D9D0` (on cream bg)

**Why this is distinct:** No prior day uses electric red as accent. The near-black + cream + red triad is a classic editorial print register (think: music magazine, art book). The contrast with prior days: Day 26 was dark with warm amber; Day 25 was sage green on linen; Day 24 was civic navy on off-white; Day 3's lime is the most "bright accent on dark" but lime vs. red are very different.

## Sections (single-page)

1. **Nav** — minimal: artist logo/name left, skip-nav + social icons right. Sticky.
2. **Hero** — full-viewport, large artist photo background (dark overlay), artist name in 96–120px DM Serif Display, role + genre tagline, 2 CTAs: "Download Press Kit (.zip)" (primary) + "Book Lila" (secondary).
3. **Bio** — Short bio (50 words) + Long bio (250 words). Copy-to-clipboard buttons per version. Toggle/accordion UX.
4. **Press Photos** — 4 photo cards: hero-color, bw-portrait, live-performance, studio-close. Each shows filename, resolution, credit, license. Download button per photo.
5. **Logo + Branding** — wordmark (light/dark variants), icon/monogram (light/dark). Brand colors + hex. Brand fonts. "Brand Guidelines (.pdf)" link. SVG download per asset.
6. **Discography** — 3 albums + 2 EPs. Cover art placeholder, release date, label, streaming links (Spotify, Apple Music). Newest first.
7. **Press Quotes** — 6 pull quotes with publication (Pitchfork, NPR Music, The Wire, KEXP, Stereogum, The Quietus), date, link.
8. **Tour Dates** — upcoming shows table: date + venue + city + ticket link. 6 dates.
9. **One-Sheet / EPK PDF** — large CTA section: "Everything in one file". Download full press kit PDF.
10. **Contact** — Booking, Management, Press/Publicity, General. Each: name + email + phone (where applicable).
11. **Social strip** — Spotify, Apple Music, YouTube, Instagram, X, Bandcamp icon links.
12. **Footer** — copyright + "Press inquiries get 24-hour reply" note.

## Schema.org (JSON-LD)

- `Person` — Lila Marin (artist)
- `MusicGroup` — Lila Marin (as solo artist entity)
- `ImageObject` — each press photo
- `MediaObject` / `DataDownload` — press kit zip, one-sheet PDF
- `BreadcrumbList`
- `sameAs` links: Spotify, Apple Music, Instagram, YouTube, Bandcamp

## Technical notes

- **Asset placeholders:** All downloads will be real files in `public/press-kit/`:
  - `press-kit.zip` — tiny placeholder (a few hundred bytes) 
  - `photos/hero-color-2400px.jpg`, `bw-portrait-square.jpg`, `live-performance.jpg`, `studio-close.jpg` — Unsplash-sourced tiny placeholders (or SVG placeholder images to keep size down)
  - `logos/wordmark-light.svg`, `wordmark-dark.svg`, `icon-light.svg`, `icon-dark.svg`
  - `one-sheet.pdf` — 1-page minimal PDF stub
  - `brand-guidelines.pdf` — stub
- All download `<a>` elements have `download` attribute + `href` pointing to `/press-kit/...`
- No external images in hero — use CSS gradient + SVG placeholder to stay under 2 MB
- FontAwesome icons → use SVG inline or icon fonts via CDN? No — use inline SVG for social icons to avoid external CSS blocking load

## Differentiation story

Day 27 occupies a completely different register than all prior days:
- **Format:** Asset-download hub for press/industry (vs. consumer landing pages, portfolios, or service businesses)
- **Audience:** Journalists and bookers (vs. customers, fans, or clients)
- **Visual register:** Editorial print / music magazine cover (near-black + red + cream) — no prior day is in this palette
- **Font combo:** DM Serif Display + Manrope — untouched combination
- **Schema:** MusicGroup + Person + DataDownload — only day with music industry structured data
- **Key interaction:** Copy-bio buttons, multi-asset download grid — unique to press kit format
