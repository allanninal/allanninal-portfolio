import { test, expect } from '@playwright/test';

test.describe('Clearwater Window — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Clearwater Window Co\./);
    await expect(page.locator('h1')).toContainText('Portland');
  });

  // The before/after pair is this template's primary device. If it degrades to
  // a card grid the archetype is gone, so the figure/figcaption pairing is
  // asserted rather than assumed.
  test('the work set is built from real figures with captions', async ({ page }) => {
    await page.goto('/');
    const figures = page.locator('#work figure');
    expect(await figures.count()).toBe(6);
    expect(await figures.locator('figcaption').count()).toBe(6);
    // Each pair is two panes: a before with grime, an after without.
    expect(await page.locator('#work .pane').count()).toBe(12);
    expect(await page.locator('#work .grime').count()).toBe(6);
    expect(await page.locator('#work .pane--after').count()).toBe(6);
  });

  test('each pair names the grime and the method, not just "before/after"', async ({ page }) => {
    await page.goto('/');
    const caps = page.locator('#work figcaption');
    for (const t of await caps.allTextContents()) {
      expect(t).toContain('What was on it');
      expect(t).toContain('What we did');
      expect(t.length).toBeGreaterThan(120);
    }
  });

  // Six visually distinct grime types, not one smudge reused six times.
  test('the six grime overlays are all different', async ({ page }) => {
    await page.goto('/');
    const classes = await page.$$eval('#work .grime', (els) =>
      els.map((e) => Array.from(e.classList).find((c) => c.startsWith('grime--'))),
    );
    expect(new Set(classes).size).toBe(6);
  });

  test('scope splits what is included from what is quoted separately', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('#scope');
    expect(await s.locator('ul li').count()).toBe(6);
    expect(await s.locator('dl > div').count()).toBe(4);
    // The refusal must survive: no ladders above the second storey, no ice.
    await expect(s).toContainText(/ladders above the second storey/i);
  });

  test('pricing shows per-pane rates and whole-home totals', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#pricing .rate-table tbody tr');
    expect(await rows.count()).toBe(4);
    for (const t of await rows.allTextContents()) expect(t).toMatch(/\$\d/);
    expect(await page.locator('#pricing dl > div').count()).toBe(2);
  });

  test('the coastal section gives a different cause per season', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#coastal dl > div').count()).toBe(4);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 78.
  test('no trace of the day-78 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['fair weather', 'madison', 'renata', 'move-out', 'wisconsin']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro hard-water guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/hard-water-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('The four stages');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
