/**
 * Clearwater Window Co. — every string the page renders.
 *
 * Business fictional; PRICES ARE REAL 2026 US figures (sources in RESEARCH.md).
 * Replace every contact detail before shipping this for a real business.
 */

export const site = {
  name: 'Clearwater Window Co.',
  shortName: 'Clearwater',
  tagline: 'Window cleaning for Portland, inside and out.',
  description:
    'Eleven years on Portland glass. Priced per pane so you can check the arithmetic, with screens, tracks and sills included rather than quietly billed as extras.',
  owner: 'Ike Brennan',
  ownerRole: 'Owner',
  yearsExperience: 11,
  city: 'Portland',
  state: 'ME',
  streetAddress: '54 Washington Avenue',
  postalCode: '04101',
  phoneDisplay: '(207) 555-0118',
  phoneHref: '+12075550118',
  email: 'hello@clearwaterwindow.example',
  formAction: '#',
  hours: 'Mon–Sat 7am–4pm · Weather permitting, and we will tell you when it is not',
  bookingWindow: 'Booking about ten days out. Storm damage sooner.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Clearwater Window Co. — Window Cleaning in Portland, ME',
  license: 'Licensed and insured · Maine',
  instagram: 'https://www.instagram.com/clearwaterwindow',
  facebook: 'https://www.facebook.com/clearwaterwindow',
};

export const nav = [
  { label: 'Before & after', href: '#work' },
  { label: 'What’s included', href: '#scope' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Salt & pollen', href: '#coastal' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The before/after set — the page's primary content.
 *
 * `grime` drives the CSS overlay on the "before" pane, so each pair looks like
 * the specific thing it names rather than a generic smudge. No photography
 * ships in the free edition.
 */
export const pairs = [
  { id: 'salt', title: 'Salt film, East End', grime: 'salt', was: 'Nine months of sea spray. Looks like haze until the light is behind it, then you cannot see the harbour.', did: 'Two-pass wash, deionised rinse. No squeegee marks because nothing dries on the glass.' },
  { id: 'pollen', title: 'Pine pollen, Deering', grime: 'pollen', was: 'Late-May yellow, baked on by a week of sun. Rain spreads it rather than removing it.', did: 'Softened first, then washed. Rushing this scratches the glass with its own pollen.' },
  { id: 'mineral', title: 'Sprinkler spotting, Falmouth', grime: 'mineral', was: 'Hard-water spray from an irrigation head aimed six inches too high for three summers.', did: 'Polished out with a cerium compound. Caught in time — another season and it would have been etched.' },
  { id: 'construction', title: 'Post-build spatter, Munjoy Hill', grime: 'construction', was: 'Paint spots, plaster dust and a stucco splash the builder said would "come off in the rain".', did: 'Bladed wet, then washed. Slow work, and the only method that does not leave arcs.' },
  { id: 'soot', title: 'Chimney soot, West End', grime: 'soot', was: 'A winter of wood smoke drifting back onto north-facing sashes.', did: 'Degreased before washing. Soot is oily; plain water just moves it around.' },
  { id: 'tracks', title: 'Tracks and sills, Rosemont', grime: 'tracks', was: 'Sand, grit and two dead spiders per track. The part most quotes leave out.', did: 'Vacuumed, brushed and wiped. Included in our price, which is the whole point of listing it here.' },
];

/** The dividing line in this trade is scope, not labour rate. */
export const scope = {
  included: [
    'Interior and exterior glass',
    'Screens removed, washed and refitted',
    'Tracks vacuumed and wiped',
    'Sills and frames wiped down',
    'Ground and second-storey windows',
    'Cobwebs cleared from the reveal',
  ],
  extra: [
    { item: 'Hard-water mineral removal', price: '$8 – $75 per pane', note: 'Depends entirely on whether it has etched. We test one pane first and tell you.' },
    { item: 'Above the second floor', price: '$10 – $40 per window', note: 'Different equipment, different insurance.' },
    { item: 'Post-construction spatter', price: 'Quoted per job', note: 'Bladed work is slow and it is not fair to fold it into a standard rate.' },
    { item: 'Storm windows removed and stored', price: '$6 per unit', note: 'Seasonal, and worth booking with a spring clean.' },
  ],
  never: 'We do not use ladders above the second storey, and we will not work on ice. Both of those are how people in this trade end up in hospital.',
};

/** Real 2026 US figures. */
export const pricing = {
  rows: [
    { what: 'Standard pane, ground floor', rate: '$4 – $8' },
    { what: 'Per window, both sides', rate: '$10 – $18' },
    { what: 'Large picture or bay pane', rate: '$8 – $15' },
    { what: 'Second-storey premium', rate: '+$2 – $4 per pane' },
  ],
  homes: [
    { size: 'Small home · 10–15 windows', total: '$150 – $275' },
    { size: 'Medium home · 20–25 windows', total: '$250 – $450' },
  ],
  average: '$220',
};

/** Why coastal glass films faster — the local honesty section. */
export const coastal = [
  { season: 'Spring', cause: 'Pine pollen', body: 'Two heavy weeks in late May. It bakes on, and rain makes it worse before it makes it better.' },
  { season: 'Summer', cause: 'Irrigation spray', body: 'The single most common cause of permanent mineral etching we see. Check where your heads point.' },
  { season: 'Autumn', cause: 'Salt and storm spray', body: 'Onshore wind carries salt well past the waterfront. Deering gets it too, just slower.' },
  { season: 'Winter', cause: 'Road sand and wood smoke', body: 'Sand pits the lower panes; soot films the upper ones. Different problems, different passes.' },
];

export const areas = [
  { zone: 'Peninsula', towns: 'East End · Munjoy Hill · West End · Old Port · Bayside' },
  { zone: 'Off-peninsula', towns: 'Deering · Rosemont · North Deering · Riverton' },
  { zone: 'North', towns: 'Falmouth · Cumberland · Yarmouth · Freeport' },
  { zone: 'South', towns: 'South Portland · Cape Elizabeth · Scarborough · Westbrook' },
];

export const reviews = [
  { name: 'Hattie L.', town: 'Munjoy Hill', text: 'He tested one pane for the mineral staining, showed me the difference, and told me the other four were too far gone to polish. Did not charge me to try anyway.' },
  { name: 'Ross D.', town: 'Falmouth', text: 'Two other quotes were cheaper until I read what they covered. Neither included screens or tracks. Clearwater was the same money once you compared like for like.' },
  { name: 'Nadia F.', town: 'West End', text: 'Rescheduled himself when the forecast turned, which I appreciated more than if he had turned up and done a bad job in the wind.' },
  { name: 'Peter O.', town: 'Cape Elizabeth', text: 'Eleven years of salt on a 1902 house. I did not know the glass was that colour.' },
];

export const faqs = [
  { q: 'How often does Portland glass actually need doing?', a: 'Three times a year on the peninsula, twice off it. Salt is the reason — an inland house at the same price point would be fine on two. We would rather tell you that than sell you four.' },
  { q: 'Do you clean in winter?', a: 'Yes, down to about 25°F with the right solution. Not in ice, not in high wind, and not when the forecast says the glass will freeze before it dries.' },
  { q: 'What happens if it rains the next day?', a: 'Clean glass sheds rain and stays clear. What makes windows look bad after rain is the dirt that was already there. If yours spot badly within 48 hours, call us and we will come back.' },
  { q: 'Can you get hard-water stains out?', a: 'Sometimes. If the minerals sit on the glass, a cerium polish removes them. If they have etched into it, nothing removes them and anyone who says otherwise is about to take your money. We test one pane and show you before quoting the rest.' },
  { q: 'Do I need to be home?', a: 'For exterior only, no. For interiors, yes, or leave access arranged. We text on the way and send a photo of the finished glass either way.' },
  { q: 'Why is your quote higher than the one I got yesterday?', a: 'Almost always scope. Ask the other quote whether screens, tracks and sills are included. If they are, and it is still cheaper, take it — genuinely.' },
];
