import { test, expect } from '@playwright/test';

const HUB = 'https://templates.allanninal.dev';
const SLUG = 'changelog-page';

// Edition-aware: the Pro build swaps the free download bar for a "Pro edition —
// live preview" strip (different aria-label; no source-zip link; Get-Pro CTA).
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';
const barSel = `aside[aria-label="${barLabel}"]`;

test('TemplateInfo bar renders the correct links', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(barSel);
  await expect(bar).toBeVisible();

  // Static ZIP — free "Download static" / Pro "Download free", both point here.
  const staticLink = bar.locator(`a[href="${HUB}/downloads/${SLUG}-static.zip"]`);
  await expect(staticLink).toBeVisible();
  await expect(staticLink).toHaveAttribute('download');

  // Source ZIP — free edition only (the Pro bar has no source-zip link).
  if (!isPro) {
    const sourceLink = bar.locator(`a[href="${HUB}/downloads/${SLUG}-source.zip"]`);
    await expect(sourceLink).toBeVisible();
    await expect(sourceLink).toHaveAttribute('download');
  }

  // All 365 gallery
  await expect(bar.locator(`a[href="${HUB}"]`)).toBeVisible();

  // LinkedIn CTA — free "Build with me" / Pro locked "Get Pro static".
  await expect(bar.locator('a[href*="linkedin.com/in/allanninal"]')).toBeVisible();
});

test('TemplateInfo bar has zero github.com links inside it', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(barSel);
  const githubLinks = bar.locator('a[href*="github.com"]');
  expect(await githubLinks.count()).toBe(0);
});

test('TemplateInfo bar shows the edition label', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(barSel);
  await expect(bar).toContainText(isPro ? 'live preview' : 'Day 29');
});
