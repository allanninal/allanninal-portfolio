import { test, expect } from '@playwright/test';
import { ROUTES } from './helpers';

// External resources (GA, AdSense) 403 in test — intercept and block them
// so they don't pollute console errors.
for (const route of ROUTES) {
  test(`page ${route} renders`, async ({ page }) => {
    const errors: string[] = [];

    // Block external analytics/ad scripts to avoid 403 console errors
    await page.route(/googletagmanager|googlesyndication|doubleclick|google-analytics|pagead2/, (route) => {
      route.abort();
    });

    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => {
      if (m.type() === 'error') {
        const text = m.text();
        // Ignore: aborted-network resource errors from our blocked external scripts
        if (text.includes('net::ERR_ABORTED') || text.includes('Failed to load resource')) return;
        errors.push(text);
      }
    });

    const res = await page.goto(route);
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('header').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}: ${errors.join('\n')}`).toEqual([]);
  });
}

test('index page has Inkframe hero h1', async ({ page }) => {
  await page.goto('/');
  const h1 = page.locator('h1').first();
  await expect(h1).toContainText('Inkframe');
});

test('entry count shown in hero', async ({ page }) => {
  await page.goto('/');
  const eyebrow = page.locator('.label-eyebrow').first();
  await expect(eyebrow).toContainText('updates');
});

test('per-entry page shows version pill', async ({ page }) => {
  await page.goto('/changelog/2026-03-28-ai-comment-summarization/');
  const version = page.locator('.version-pill').first();
  await expect(version).toBeVisible();
  await expect(version).toContainText('v2.5.0');
});

test('per-entry breadcrumb renders correctly', async ({ page }) => {
  await page.goto('/changelog/2026-03-28-ai-comment-summarization/');
  const breadcrumb = page.locator('nav[aria-label="Breadcrumb"]');
  await expect(breadcrumb).toBeVisible();
  await expect(breadcrumb).toContainText('Changelog');
  await expect(breadcrumb).toContainText('AI Comment Summarization');
});

test('year archive 2026 has correct h1', async ({ page }) => {
  await page.goto('/changelog/2026/');
  await expect(page.locator('h1').first()).toContainText('2026');
});

test('year archive only shows entries from that year', async ({ page }) => {
  await page.goto('/changelog/2026/');
  const cards = page.locator('article[data-year]');
  const count = await cards.count();
  expect(count).toBeGreaterThan(0);
  for (let i = 0; i < count; i++) {
    const year = await cards.nth(i).getAttribute('data-year');
    expect(year).toBe('2026');
  }
});

test('RSS feed returns XML', async ({ page }) => {
  const res = await page.goto('/rss.xml');
  expect(res?.status()).toBe(200);
  const contentType = res?.headers()['content-type'] ?? '';
  expect(contentType).toContain('xml');
  const body = await res?.text();
  expect(body).toContain('<rss');
  expect(body).toContain('Inkframe Changelog');
});

test('RSS feed contains entries with version prefix', async ({ page }) => {
  const res = await page.goto('/rss.xml');
  const body = await res?.text();
  expect(body).toContain('[v2.5.0]');
});

test('RSS link in head', async ({ page }) => {
  await page.goto('/');
  const rssLink = page.locator('head link[rel="alternate"][type="application/rss+xml"]');
  await expect(rssLink).toHaveAttribute('href', /rss\.xml/);
});
