import type { Page } from '@playwright/test';

// Keep in sync with src/pages/ — one entry per route.
export const ROUTES = [
  '/',
  '/changelog/2026-03-28-ai-comment-summarization/',
  '/changelog/2026-03-14-figma-variables-sync-fix/',
  '/changelog/2026-02-27-breaking-webhook-payload/',
  '/changelog/2026-02-18-security-token-scope-fix/',
  '/changelog/2026-01-30-team-workspaces-launch/',
  '/changelog/2026-01-20-deprecation-v1-export-api/',
  '/changelog/2026/',
  // Pro edition adds the standalone roadmap page; the free build redirects it,
  // so it's only a real route under Pro.
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/roadmap/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    localStorage.setItem('theme', t);
    document.documentElement.setAttribute('data-theme', t);
  }, theme);
}
