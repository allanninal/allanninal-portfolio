import { test, expect } from '@playwright/test';
import { ROUTES, setTheme } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${route} renders in ${theme} mode`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);
      await page.reload();
      const dataTheme = await page.evaluate(() =>
        document.documentElement.getAttribute('data-theme')
      );
      expect(dataTheme).toBe(theme);
      // Ensure the page still has its main content after reload
      await expect(page.locator('h1').first()).toBeVisible();
    });
  }
}
