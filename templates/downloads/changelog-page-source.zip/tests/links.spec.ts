import { test, expect } from '@playwright/test';
import { ROUTES } from './helpers';

test('no broken internal links on index', async ({ page }) => {
  await page.goto('/');
  const internalLinks = await page.locator('a[href^="/"]').all();
  for (const link of internalLinks) {
    const href = await link.getAttribute('href');
    if (!href) continue;
    // Skip external-ish paths
    if (href.includes('rss.xml')) continue;
    const res = await page.request.get(href);
    expect(
      res.status(),
      `Broken internal link: ${href} returned ${res.status()}`
    ).toBeLessThan(400);
  }
});

test('external links have rel="noopener noreferrer" when target="_blank"', async ({ page }) => {
  for (const route of ROUTES) {
    await page.goto(route);
    const externalLinks = await page.locator('a[target="_blank"]').all();
    for (const link of externalLinks) {
      const rel = await link.getAttribute('rel');
      expect(
        rel,
        `Link missing rel on ${route}: ${await link.getAttribute('href')}`
      ).toContain('noopener');
    }
  }
});

test('no github.com/allanninal/templates deep-links anywhere', async ({ page }) => {
  for (const route of ROUTES) {
    await page.goto(route);
    const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
    expect(
      await badLinks.count(),
      `Found github.com/allanninal/templates link on ${route}`
    ).toBe(0);
  }
});
