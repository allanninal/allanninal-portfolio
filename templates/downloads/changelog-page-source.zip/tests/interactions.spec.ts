import { test, expect } from '@playwright/test';

test('theme toggle switches to dark', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => {
    localStorage.removeItem('theme');
    document.documentElement.setAttribute('data-theme', 'light');
  });
  const toggle = page.locator('#theme-toggle');
  await toggle.click();
  const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(theme).toBe('dark');
});

test('theme toggle persists across reload', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => {
    localStorage.setItem('theme', 'dark');
    document.documentElement.setAttribute('data-theme', 'dark');
  });
  await page.reload();
  const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(theme).toBe('dark');
});

test('filter chip "New" toggles aria-pressed', async ({ page }) => {
  await page.goto('/');
  const chip = page.locator('.filter-chip[data-tag="New"]');
  await expect(chip).toHaveAttribute('aria-pressed', 'false');
  await chip.click();
  await expect(chip).toHaveAttribute('aria-pressed', 'true');
  await chip.click();
  await expect(chip).toHaveAttribute('aria-pressed', 'false');
});

async function getVisibleEntryTags(page: import('@playwright/test').Page): Promise<string[][]> {
  return page.evaluate(() => {
    const entries = document.querySelectorAll('article[data-tags]');
    const visible: string[][] = [];
    entries.forEach((el) => {
      const htmlEl = el as HTMLElement;
      if (htmlEl.style.display !== 'none') {
        const tags = htmlEl.getAttribute('data-tags') || '';
        visible.push(tags.split(','));
      }
    });
    return visible;
  });
}

test('filter chip "Fix" hides non-Fix entries', async ({ page }) => {
  await page.goto('/');
  const chip = page.locator('.filter-chip[data-tag="Fix"]');
  await chip.click();
  await page.waitForTimeout(100);
  const visibleTags = await getVisibleEntryTags(page);
  expect(visibleTags.length).toBeGreaterThan(0);
  for (const tags of visibleTags) {
    expect(tags).toContain('Fix');
  }
});

test('filter chip "Breaking" hides non-Breaking entries', async ({ page }) => {
  await page.goto('/');
  const chip = page.locator('.filter-chip[data-tag="Breaking"]');
  await chip.click();
  await page.waitForTimeout(100);
  const visibleTags = await getVisibleEntryTags(page);
  expect(visibleTags.length).toBeGreaterThan(0);
  for (const tags of visibleTags) {
    // Breaking OR Deprecated (both use Breaking pill) - but our schema only has Breaking entry
    const hasBreaking = tags.includes('Breaking') || tags.includes('Deprecated');
    expect(hasBreaking).toBe(true);
  }
});

test('filter chip "Security" hides non-Security entries', async ({ page }) => {
  await page.goto('/');
  const chip = page.locator('.filter-chip[data-tag="Security"]');
  await chip.click();
  await page.waitForTimeout(100);
  const visibleTags = await getVisibleEntryTags(page);
  expect(visibleTags.length).toBeGreaterThan(0);
  for (const tags of visibleTags) {
    expect(tags).toContain('Security');
  }
});

test('filter chip "Improvement" hides non-Improvement entries', async ({ page }) => {
  await page.goto('/');
  const chip = page.locator('.filter-chip[data-tag="Improvement"]');
  await chip.click();
  await page.waitForTimeout(100);
  const visibleTags = await getVisibleEntryTags(page);
  expect(visibleTags.length).toBeGreaterThan(0);
  for (const tags of visibleTags) {
    expect(tags).toContain('Improvement');
  }
});

test('clearing all filter chips shows all entries', async ({ page }) => {
  await page.goto('/');
  const allCards = page.locator('article[data-tags]');
  const totalCount = await allCards.count();

  const chip = page.locator('.filter-chip[data-tag="New"]');
  await chip.click();
  await page.waitForTimeout(50);
  await chip.click(); // toggle back off
  await page.waitForTimeout(100);

  const visibleCount = await page.evaluate(() => {
    const entries = document.querySelectorAll('article[data-tags]');
    let count = 0;
    entries.forEach((el) => {
      if ((el as HTMLElement).style.display !== 'none') count++;
    });
    return count;
  });
  expect(visibleCount).toBe(totalCount);
});

test('year selector filters by year', async ({ page }) => {
  await page.goto('/');
  const yearSelect = page.locator('#year-select');
  await yearSelect.selectOption('2026');
  await page.waitForTimeout(100);
  const visibleYears = await page.evaluate(() => {
    const entries = document.querySelectorAll('article[data-year]');
    const visible: string[] = [];
    entries.forEach((el) => {
      const htmlEl = el as HTMLElement;
      if (htmlEl.style.display !== 'none') {
        visible.push(htmlEl.getAttribute('data-year') || '');
      }
    });
    return visible;
  });
  expect(visibleYears.length).toBeGreaterThan(0);
  for (const year of visibleYears) {
    expect(year).toBe('2026');
  }
});

test('search input filters entries by title', async ({ page }) => {
  await page.goto('/');
  const searchInput = page.locator('#search-entries');
  await searchInput.fill('AI Comment');
  const visibleCards = page.locator('article[data-tags]:not([style*="display: none"]):not([style*="display:none"])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThanOrEqual(1);
});

test('/ keypress focuses search input', async ({ page }) => {
  await page.goto('/');
  await page.keyboard.press('/');
  const searchInput = page.locator('#search-entries');
  await expect(searchInput).toBeFocused();
});

test('Buttondown subscribe form has correct action', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('form[action*="buttondown.email"]');
  await expect(form).toBeVisible();
  await expect(form).toHaveAttribute('action', /inkframe/);
  await expect(form).toHaveAttribute('method', 'POST');
});

test('subscribe form has email input with label', async ({ page }) => {
  await page.goto('/');
  const input = page.locator('#bd-email');
  await expect(input).toBeVisible();
  await expect(input).toHaveAttribute('type', 'email');
  await expect(input).toHaveAttribute('required');
});

test('RSS link in header visible', async ({ page }) => {
  await page.goto('/');
  const rssLink = page.locator('header a[href*="rss.xml"]');
  await expect(rssLink).toBeVisible();
});

test('per-entry share-on-X link has correct href', async ({ page }) => {
  await page.goto('/changelog/2026-03-28-ai-comment-summarization/');
  const xLink = page.locator('a[aria-label="Share on X (Twitter)"]');
  await expect(xLink).toBeVisible();
  await expect(xLink).toHaveAttribute('href', /x\.com\/intent\/tweet/);
});

test('per-entry share-on-LinkedIn link has correct href', async ({ page }) => {
  await page.goto('/changelog/2026-03-28-ai-comment-summarization/');
  const linkedInLink = page.locator('a[aria-label="Share on LinkedIn"]');
  await expect(linkedInLink).toBeVisible();
  await expect(linkedInLink).toHaveAttribute('href', /linkedin\.com\/sharing/);
});

test('per-entry back-to-changelog link works', async ({ page }) => {
  await page.goto('/changelog/2026-03-28-ai-comment-summarization/');
  const backLink = page.locator('text=← Back to changelog');
  await expect(backLink).toBeVisible();
  await backLink.click();
  await expect(page).toHaveURL('/');
});

test('year archive back link returns to index', async ({ page }) => {
  await page.goto('/changelog/2026/');
  const backLink = page.locator('text=← All changelog entries');
  await expect(backLink).toBeVisible();
});

test('footer donate link renders when env var set', async ({ page }) => {
  await page.goto('/');
  const donateLink = page.locator('footer a[href*="ko-fi"]');
  await expect(donateLink).toBeVisible();
});

test('no github.com/allanninal/templates link in footer', async ({ page }) => {
  await page.goto('/');
  const githubTemplatesLinks = page.locator('footer a[href*="github.com/allanninal/templates"]');
  expect(await githubTemplatesLinks.count()).toBe(0);
});
