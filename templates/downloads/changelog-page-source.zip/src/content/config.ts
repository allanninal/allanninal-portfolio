import { defineCollection, z } from 'astro:content';

const changelog = defineCollection({
  type: 'content',
  schema: z.object({
    date:    z.coerce.date(),
    version: z.string(),
    title:   z.string(),
    tags:    z.array(z.enum(['New', 'Improvement', 'Fix', 'Breaking', 'Security', 'Deprecated'])),
    image:   z.string().optional(),
    summary: z.string().max(160),
    draft:   z.boolean().default(false),
  }),
});

export const collections = { changelog };
