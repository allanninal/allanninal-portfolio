import rss from '@astrojs/rss';
import { getCollection } from 'astro:content';
import type { APIContext } from 'astro';

export async function GET(context: APIContext) {
  const entries = await getCollection('changelog', ({ data }) => !data.draft);

  // Sort reverse-chronological
  entries.sort((a, b) => b.data.date.getTime() - a.data.date.getTime());

  const base = import.meta.env.BASE_URL || '/';
  const siteUrl = import.meta.env.PUBLIC_SITE_URL || context.site?.toString() || 'https://www.allanninal.dev/templates';
  const feedUrl = `${siteUrl}${base}rss.xml`;

  return rss({
    title: 'Inkframe Changelog',
    description: 'Release notes for Inkframe — the AI-assisted design review tool. Track new features, improvements, fixes, and breaking changes.',
    site: siteUrl,
    customData: '<language>en-us</language>',
    items: entries.map((entry) => ({
      title: `[${entry.data.version}] ${entry.data.title}`,
      pubDate: entry.data.date,
      description: entry.data.summary,
      link: `${siteUrl}${base}changelog/${entry.slug}/`,
    })),
  });
}
