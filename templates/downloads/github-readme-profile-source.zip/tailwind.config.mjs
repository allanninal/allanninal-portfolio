/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Map CSS variables so tw utilities work: bg-bg, text-accent, etc.
        bg:          'var(--color-bg)',
        surface:     'var(--color-surface)',
        'surface-alt': 'var(--color-surface-alt)',
        accent:      'var(--color-accent)',
        'accent-dim': 'var(--color-accent-dim)',
        text:        'var(--color-text)',
        muted:       'var(--color-text-muted)',
        border:      'var(--color-border)',
        green:       'var(--color-green)',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans:    ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'Menlo', 'monospace'],
      },
    },
  },
  plugins: [],
};
