import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES, setTheme } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`a11y ${route} (${theme} color-scheme) — zero violations`, async ({ page }) => {
      await setTheme(page, theme);
      await page.goto(route);
      // Wait for the generator script to finish
      await page.waitForLoadState('networkidle');

      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        // Exclude external image loads (shields.io badges in preview) which
        // may render as broken images in test environment and trigger img-alt
        // rules for browser-loaded images we don't control.
        .exclude('#preview-content img')
        .analyze();

      if (results.violations.length > 0) {
        const summary = results.violations.map((v) =>
          `[${v.id}] ${v.description} — ${v.nodes.map((n) => n.html.substring(0, 80)).join('; ')}`
        );
        expect(results.violations, `a11y violations on ${route} (${theme}):\n${summary.join('\n')}`).toEqual([]);
      }
    });
  }
}
