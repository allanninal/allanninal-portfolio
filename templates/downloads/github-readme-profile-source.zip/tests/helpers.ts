import type { Page } from '@playwright/test';

// Single source of truth for routes — keep in sync with src/pages/.
// The Pro edition (PUBLIC_EDITION=pro) adds the /widgets/ gallery; the free
// build redirects it, so it's only a real route under Pro.
export const ROUTES = [
  '/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/widgets/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// Dark-only template — setTheme always applies dark, but we accept the param
// for API compatibility with the standard test harness.
export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    try { localStorage.setItem('theme', t); } catch (_) { /* ignore */ }
  }, theme);
}
