import { test, expect } from '@playwright/test';
import { ROUTES, setTheme } from './helpers';

// Dark-only template — we test with both color-scheme media queries
// to ensure the dark palette holds in both emulation modes.

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${route} renders without errors in ${theme} color-scheme`, async ({ page }) => {
      await setTheme(page, theme);
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(e.message));
      await page.goto(route);
      await expect(page.locator('h1').first()).toBeVisible();
      await expect(page.locator('footer').first()).toBeVisible();

      const realErrors = errors.filter((e) =>
        !e.includes('net::ERR_') && !e.includes('favicon')
      );
      expect(realErrors).toEqual([]);
    });

    test(`${route} background is dark (#0D1117) in ${theme} mode`, async ({ page }) => {
      await setTheme(page, theme);
      await page.goto(route);
      const bodyBg = await page.evaluate(() => {
        return window.getComputedStyle(document.body).backgroundColor;
      });
      // Should be dark regardless of system color scheme
      // rgb(13, 17, 23) is #0D1117
      expect(bodyBg).toBe('rgb(13, 17, 23)');
    });
  }
}
