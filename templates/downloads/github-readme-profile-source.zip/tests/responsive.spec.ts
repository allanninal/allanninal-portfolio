import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}px) has no horizontal overflow`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(overflow).toBe(false);
    });

    test(`${route} @ ${vp.name} (${vp.width}px) has visible hero heading`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await expect(page.locator('h1').first()).toBeVisible();
    });

    // The generator form only exists on the home page; the Pro /widgets/ page
    // is a content gallery with no form.
    if (route === '/') {
      test(`${route} @ ${vp.name} (${vp.width}px) generator form is visible`, async ({ page }) => {
        await page.setViewportSize({ width: vp.width, height: vp.height });
        await page.goto(route);
        const form = page.locator('#readme-form');
        await expect(form).toBeVisible();
      });
    }
  }
}
