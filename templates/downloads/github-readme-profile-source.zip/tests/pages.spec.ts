import { test, expect } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`page ${route} renders with no console errors`, async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));

    const res = await page.goto(route);
    expect(res?.status()).toBe(200);

    // Semantic landmarks
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('nav').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    await expect(page.locator('main').first()).toBeVisible();
    await expect(page.locator('header').first()).toBeVisible();

    // Filter expected network errors: AdSense/GA scripts return 403/blocked in test env;
    // shields.io and external stats card URLs are expected to fail in offline test runs.
    const realErrors = errors.filter((e) =>
      !e.includes('net::ERR_') &&
      !e.includes('Failed to fetch') &&
      !e.includes('favicon') &&
      !e.includes('403') &&
      !e.includes('adsbygoogle') &&
      !e.includes('googlesyndication') &&
      !e.includes('googletagmanager') &&
      !e.includes('shields.io') &&
      !e.includes('Failed to load resource')
    );
    expect(realErrors, `console errors on ${route}: ${realErrors.join('\n')}`).toEqual([]);
  });
}

test('home page has correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/GitHub README Profile Generator/);
});

test('hero section is visible and has heading', async ({ page }) => {
  await page.goto('/');
  const hero = page.locator('#hero');
  await expect(hero).toBeVisible();
  const h1 = hero.locator('h1');
  await expect(h1).toBeVisible();
  await expect(h1).toContainText('GitHub profile');
});

test('generator section is visible', async ({ page }) => {
  await page.goto('/');
  const gen = page.locator('#generator');
  await expect(gen).toBeVisible();
});

test('presets section has 4 persona cards', async ({ page }) => {
  await page.goto('/');
  const section = page.locator('#presets');
  await expect(section).toBeVisible();
  const cards = section.locator('article');
  await expect(cards).toHaveCount(4);
});

test('why section renders 3 trust cards', async ({ page }) => {
  await page.goto('/');
  const section = page.locator('#why');
  await expect(section).toBeVisible();
  const cards = section.locator('.card');
  await expect(cards).toHaveCount(3);
});

test('guide section renders 5 numbered steps', async ({ page }) => {
  await page.goto('/');
  const section = page.locator('#guide');
  await expect(section).toBeVisible();
  const steps = section.locator('li');
  await expect(steps).toHaveCount(5);
});

test('FAQ section renders 6 items', async ({ page }) => {
  await page.goto('/');
  const section = page.locator('#faq');
  await expect(section).toBeVisible();
  const items = section.locator('[id^="faq-btn-"]');
  await expect(items).toHaveCount(6);
});

test('footer is visible with LinkedIn link', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer');
  await expect(footer).toBeVisible();
  const li = footer.getByRole('link', { name: /LinkedIn/i });
  await expect(li).toBeVisible();
  await expect(li).toHaveAttribute('href', /linkedin\.com/);
});

test('no github.com/allanninal/templates deep-links anywhere', async ({ page }) => {
  await page.goto('/');
  const allLinks = await page.locator('a').evaluateAll(
    (els) => els.map((e) => e.getAttribute('href') || '')
  );
  const deepLinks = allLinks.filter((h) =>
    h.includes('github.com/allanninal/templates')
  );
  expect(deepLinks).toEqual([]);
});
