import { test, expect } from '@playwright/test';

test('no broken internal links on home page', async ({ page }) => {
  await page.goto('/');
  const links = await page.locator('a[href]').evaluateAll(
    (els) => els.map((e) => (e as HTMLAnchorElement).href)
  );

  const internalLinks = links.filter((href) => {
    try {
      const u = new URL(href);
      return u.hostname === 'localhost';
    } catch {
      return href.startsWith('/') || href.startsWith('#');
    }
  });

  for (const href of internalLinks) {
    const res = await page.request.get(href).catch(() => null);
    if (res) {
      expect(res.status(), `Broken link: ${href}`).toBeLessThan(400);
    }
  }
});

test('all external links have rel="noopener noreferrer" when target="_blank"', async ({ page }) => {
  await page.goto('/');
  const blankLinks = await page.locator('a[target="_blank"]').evaluateAll(
    (els) => els.map((e) => ({
      href: e.getAttribute('href') || '',
      rel: e.getAttribute('rel') || '',
    }))
  );

  for (const { href, rel } of blankLinks) {
    expect(
      rel,
      `External link ${href} is missing rel="noopener noreferrer"`
    ).toContain('noopener');
    expect(rel).toContain('noreferrer');
  }
});
