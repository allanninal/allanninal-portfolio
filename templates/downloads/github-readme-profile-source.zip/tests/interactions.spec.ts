import { test, expect } from '@playwright/test';

test.describe('Generator interactions', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  // ---- Form renders ----
  test('generator form renders all field groups', async ({ page }) => {
    const form = page.locator('#readme-form');
    await expect(form).toBeVisible();
    await expect(page.locator('#field-name')).toBeVisible();
    await expect(page.locator('#field-role')).toBeVisible();
    await expect(page.locator('#field-github')).toBeVisible();
    await expect(page.locator('#field-twitter')).toBeVisible();
    await expect(page.locator('#field-linkedin')).toBeVisible();
  });

  // ---- Tech chips ----
  test('tech chip toggles selected state on click', async ({ page }) => {
    const chip = page.locator('[data-tech-id="react"]');
    await expect(chip).toBeVisible();
    await expect(chip).toHaveAttribute('aria-pressed', 'false');
    await chip.click();
    await expect(chip).toHaveAttribute('aria-pressed', 'true');
    await chip.click();
    await expect(chip).toHaveAttribute('aria-pressed', 'false');
  });

  // ---- Tab switching ----
  test('tab switch from Preview to Markdown works', async ({ page }) => {
    const tabMarkdown = page.locator('#tab-markdown');
    const panelMarkdown = page.locator('#panel-markdown');
    const panelPreview = page.locator('#panel-preview');

    await expect(panelPreview).toBeVisible();
    await expect(panelMarkdown).toBeHidden();

    await tabMarkdown.click();
    await expect(panelMarkdown).toBeVisible();
    await expect(panelPreview).toBeHidden();
    await expect(tabMarkdown).toHaveAttribute('aria-selected', 'true');
  });

  // ---- Live markdown update ----
  test('typing in name field updates preview', async ({ page }) => {
    await page.locator('#field-name').fill('Test Developer');
    const preview = page.locator('#preview-content');
    await expect(preview).toContainText('Test Developer');
  });

  test('typing in github username updates preview', async ({ page }) => {
    await page.locator('#field-name').fill('Demo Dev');
    await page.locator('#field-github').fill('demodev123');
    // Switch to markdown view
    await page.locator('#tab-markdown').click();
    const code = page.locator('#markdown-code');
    await expect(code).toContainText('demodev123');
  });

  // ---- Copy to clipboard ----
  test('copy button shows Copied! feedback and reverts', async ({ page, context }) => {
    // Grant clipboard write permissions
    await context.grantPermissions(['clipboard-read', 'clipboard-write']);

    // Fill enough to generate
    await page.locator('#field-name').fill('Copy Test Dev');
    await page.locator('#field-github').fill('copytestdev');
    // Switch to markdown tab so btn-copy is visible
    await page.locator('#tab-markdown').click();

    const copyBtn = page.locator('#btn-copy');
    await expect(copyBtn).toBeVisible();
    await copyBtn.click();
    await expect(copyBtn).toContainText('Copied!');
    // Should revert after ~1.5s
    await page.waitForTimeout(2000);
    await expect(copyBtn).not.toContainText('Copied!');
  });

  test('bottom copy button shows Copied! feedback', async ({ page, context }) => {
    // Grant clipboard write permissions
    await context.grantPermissions(['clipboard-read', 'clipboard-write']);
    await page.locator('#field-name').fill('Copy Test Dev 2');
    const copyBtn = page.locator('#btn-copy-bottom');
    await expect(copyBtn).toBeVisible();
    await copyBtn.click();
    await expect(copyBtn).toContainText('Copied!');
  });

  // ---- Download ----
  test('download button triggers file download', async ({ page }) => {
    await page.locator('#field-name').fill('Download Test');
    await page.locator('#field-github').fill('downloadtest');
    // Listen for download event
    const downloadPromise = page.waitForEvent('download');
    await page.locator('#btn-download-bottom').click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toBe('README.md');
  });

  // ---- Persona presets ----
  test('Load preset (Full-Stack Dev) populates form fields', async ({ page }) => {
    const presetBtn = page.getByRole('button', { name: /Load preset.*Full-Stack Dev/i });
    await presetBtn.click();
    await expect(page.locator('#field-name')).toHaveValue('Alex Rivera');
    await expect(page.locator('#field-role')).toHaveValue(/Full-Stack Engineer/);
    await expect(page.locator('#field-github')).toHaveValue('alexrivera-dev');
  });

  test('Load preset (OSS Maintainer) populates correct fields', async ({ page }) => {
    const presetBtn = page.getByRole('button', { name: /Load preset.*OSS Maintainer/i });
    await presetBtn.click();
    await expect(page.locator('#field-name')).toHaveValue('Sam Chen');
    await expect(page.locator('#field-github')).toHaveValue('samchen-oss');
  });

  test('Load preset (Design Engineer) populates correct fields', async ({ page }) => {
    const presetBtn = page.getByRole('button', { name: /Load preset.*Design Engineer/i });
    await presetBtn.click();
    await expect(page.locator('#field-name')).toHaveValue('Jordan Park');
    await expect(page.locator('#field-github')).toHaveValue('jordanpark-design');
  });

  test('Load preset (Indie Maker) populates correct fields', async ({ page }) => {
    const presetBtn = page.getByRole('button', { name: /Load preset.*Indie Maker/i });
    await presetBtn.click();
    await expect(page.locator('#field-name')).toHaveValue('Morgan Ellis');
    await expect(page.locator('#field-github')).toHaveValue('morgan-makes');
  });

  test('Load preset selects correct tech chips', async ({ page }) => {
    const presetBtn = page.getByRole('button', { name: /Load preset.*Full-Stack Dev/i });
    await presetBtn.click();
    // Full-stack dev preset includes react
    const reactChip = page.locator('[data-tech-id="react"]');
    await expect(reactChip).toHaveAttribute('aria-pressed', 'true');
  });

  // ---- Advanced toggles (inside <details> — must open first) ----
  test('toggle switches change aria-checked state', async ({ page }) => {
    // Open the advanced details panel first
    await page.locator('details').first().locator('summary').click();
    const statsToggle = page.locator('#toggle-stats');
    await expect(statsToggle).toBeVisible();
    await expect(statsToggle).toHaveAttribute('aria-checked', 'true');
    await statsToggle.click();
    await expect(statsToggle).toHaveAttribute('aria-checked', 'false');
    await statsToggle.click();
    await expect(statsToggle).toHaveAttribute('aria-checked', 'true');
  });

  test('langs toggle starts off and can be toggled on', async ({ page }) => {
    // Open the advanced details panel first
    await page.locator('details').first().locator('summary').click();
    const langsToggle = page.locator('#toggle-langs');
    await expect(langsToggle).toBeVisible();
    await expect(langsToggle).toHaveAttribute('aria-checked', 'false');
    await langsToggle.click();
    await expect(langsToggle).toHaveAttribute('aria-checked', 'true');
  });

  // ---- FAQ accordion ----
  test('FAQ item 0 expands on click and shows answer', async ({ page }) => {
    const faqBtn = page.locator('#faq-btn-0');
    const faqAnswer = page.locator('#faq-answer-0');
    await expect(faqBtn).toBeVisible();
    await expect(faqAnswer).toBeHidden();
    await faqBtn.click();
    await expect(faqAnswer).toBeVisible();
    await expect(faqBtn).toHaveAttribute('aria-expanded', 'true');
  });

  test('FAQ item 1 expands and collapses', async ({ page }) => {
    const faqBtn = page.locator('#faq-btn-1');
    const faqAnswer = page.locator('#faq-answer-1');
    await faqBtn.click();
    await expect(faqAnswer).toBeVisible();
    await faqBtn.click();
    await expect(faqAnswer).toBeHidden();
    await expect(faqBtn).toHaveAttribute('aria-expanded', 'false');
  });

  test('multiple FAQ items can be open at once', async ({ page }) => {
    await page.locator('#faq-btn-0').click();
    await page.locator('#faq-btn-2').click();
    await expect(page.locator('#faq-answer-0')).toBeVisible();
    await expect(page.locator('#faq-answer-2')).toBeVisible();
  });

  // ---- Advanced section details toggle ----
  test('advanced options details section opens on click', async ({ page }) => {
    const details = page.locator('details').first();
    await expect(details).not.toHaveAttribute('open');
    await details.locator('summary').click();
    await expect(details).toHaveAttribute('open', '');
  });

  // ---- Footer contact links ----
  test('footer LinkedIn link is present and correct', async ({ page }) => {
    const footer = page.locator('footer');
    const linkedin = footer.getByRole('link', { name: /LinkedIn/i });
    await expect(linkedin).toBeVisible();
    await expect(linkedin).toHaveAttribute('href', '#');
  });

  test('footer email link is present', async ({ page }) => {
    const footer = page.locator('footer');
    const email = footer.getByRole('link', { name: /hello@alexrivera\.com/i });
    await expect(email).toBeVisible();
    await expect(email).toHaveAttribute('href', 'mailto:hello@alexrivera.com');
  });

  // ---- No github.com private repo links ----
  test('no github.com/allanninal/templates deep-links exist', async ({ page }) => {
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) =>
      h.includes('github.com/allanninal/templates')
    );
    expect(deepLinks).toEqual([]);
  });

  // ---- Generate button validates github username ----
  test('generate button shows error when github username is empty', async ({ page }) => {
    await page.locator('#field-name').fill('Test');
    // Ensure github is empty
    await page.locator('#field-github').fill('');
    await page.locator('#btn-generate').click();
    const errEl = page.locator('#field-github-error');
    await expect(errEl).toBeVisible();
    await expect(errEl).toContainText(/required/i);
  });

  // ---- Alignment radio ----
  test('alignment radio switches between center and left', async ({ page }) => {
    // Open advanced
    await page.locator('details').first().locator('summary').click();
    const centerRadio = page.locator('input[name="alignment"][value="center"]');
    const leftRadio   = page.locator('input[name="alignment"][value="left"]');
    await expect(centerRadio).toBeChecked();
    await leftRadio.click();
    await expect(leftRadio).toBeChecked();
    await expect(centerRadio).not.toBeChecked();
  });

});
