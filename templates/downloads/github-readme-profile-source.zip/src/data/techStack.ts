export interface Tech {
  id: string;
  name: string;
  logo: string;       // simple-icons name for shields.io
  color: string;      // hex badge color (no #)
  labelColor: string; // hex label color (no #)
  logoColor: string;  // white or a hex
}

export const TECH_STACK: Tech[] = [
  { id: 'react',       name: 'React',        logo: 'react',        color: '20232A', labelColor: '20232A', logoColor: '61DAFB' },
  { id: 'vue',         name: 'Vue.js',        logo: 'vuedotjs',     color: '4FC08D', labelColor: '4FC08D', logoColor: 'white' },
  { id: 'angular',     name: 'Angular',       logo: 'angular',      color: 'DD0031', labelColor: 'DD0031', logoColor: 'white' },
  { id: 'nextjs',      name: 'Next.js',       logo: 'nextdotjs',    color: '000000', labelColor: '000000', logoColor: 'white' },
  { id: 'svelte',      name: 'Svelte',        logo: 'svelte',       color: 'FF3E00', labelColor: 'FF3E00', logoColor: 'white' },
  { id: 'typescript',  name: 'TypeScript',    logo: 'typescript',   color: '3178C6', labelColor: '3178C6', logoColor: 'white' },
  { id: 'javascript',  name: 'JavaScript',    logo: 'javascript',   color: 'F7DF1E', labelColor: 'F7DF1E', logoColor: '000000' },
  { id: 'python',      name: 'Python',        logo: 'python',       color: '3776AB', labelColor: '3776AB', logoColor: 'white' },
  { id: 'rust',        name: 'Rust',          logo: 'rust',         color: '000000', labelColor: '000000', logoColor: 'white' },
  { id: 'go',          name: 'Go',            logo: 'go',           color: '00ADD8', labelColor: '00ADD8', logoColor: 'white' },
  { id: 'java',        name: 'Java',          logo: 'coffeescript', color: '007396', labelColor: '007396', logoColor: 'white' },
  { id: 'kotlin',      name: 'Kotlin',        logo: 'kotlin',       color: '7F52FF', labelColor: '7F52FF', logoColor: 'white' },
  { id: 'swift',       name: 'Swift',         logo: 'swift',        color: 'FA7343', labelColor: 'FA7343', logoColor: 'white' },
  { id: 'cpp',         name: 'C++',           logo: 'cplusplus',    color: '00599C', labelColor: '00599C', logoColor: 'white' },
  { id: 'nodejs',      name: 'Node.js',       logo: 'nodedotjs',    color: '339933', labelColor: '339933', logoColor: 'white' },
  { id: 'deno',        name: 'Deno',          logo: 'deno',         color: '000000', labelColor: '000000', logoColor: 'white' },
  { id: 'postgresql',  name: 'PostgreSQL',    logo: 'postgresql',   color: '4169E1', labelColor: '4169E1', logoColor: 'white' },
  { id: 'mysql',       name: 'MySQL',         logo: 'mysql',        color: '4479A1', labelColor: '4479A1', logoColor: 'white' },
  { id: 'mongodb',     name: 'MongoDB',       logo: 'mongodb',      color: '47A248', labelColor: '47A248', logoColor: 'white' },
  { id: 'redis',       name: 'Redis',         logo: 'redis',        color: 'DC382D', labelColor: 'DC382D', logoColor: 'white' },
  { id: 'docker',      name: 'Docker',        logo: 'docker',       color: '2496ED', labelColor: '2496ED', logoColor: 'white' },
  { id: 'kubernetes',  name: 'Kubernetes',    logo: 'kubernetes',   color: '326CE5', labelColor: '326CE5', logoColor: 'white' },
  { id: 'aws',         name: 'AWS',           logo: 'amazonaws',    color: '232F3E', labelColor: '232F3E', logoColor: 'white' },
  { id: 'gcp',         name: 'GCP',           logo: 'googlecloud',  color: '4285F4', labelColor: '4285F4', logoColor: 'white' },
  { id: 'azure',       name: 'Azure',         logo: 'microsoftazure', color: '0078D4', labelColor: '0078D4', logoColor: 'white' },
  { id: 'linux',       name: 'Linux',         logo: 'linux',        color: 'FCC624', labelColor: 'FCC624', logoColor: '000000' },
  { id: 'git',         name: 'Git',           logo: 'git',          color: 'F05032', labelColor: 'F05032', logoColor: 'white' },
  { id: 'figma',       name: 'Figma',         logo: 'figma',        color: 'F24E1E', labelColor: 'F24E1E', logoColor: 'white' },
  { id: 'tailwindcss', name: 'TailwindCSS',   logo: 'tailwindcss',  color: '06B6D4', labelColor: '06B6D4', logoColor: 'white' },
  { id: 'graphql',     name: 'GraphQL',       logo: 'graphql',      color: 'E10098', labelColor: 'E10098', logoColor: 'white' },
];

export function getBadgeUrl(tech: Tech): string {
  const label = encodeURIComponent(tech.name);
  return `https://img.shields.io/badge/${label}-${tech.color}?style=flat&logo=${tech.logo}&logoColor=${tech.logoColor}`;
}
