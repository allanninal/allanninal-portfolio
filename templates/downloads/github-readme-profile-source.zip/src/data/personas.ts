export interface Persona {
  id: string;
  label: string;
  description: string;
  icon: string;
  form: {
    name: string;
    role: string;
    location: string;
    focus: string;
    funFact: string;
    githubUsername: string;
    twitter: string;
    linkedin: string;
    portfolio: string;
    devto: string;
    techStack: string[];   // tech ids
    statsCard: boolean;
    statsTheme: string;
    topLangs: boolean;
    streakStats: boolean;
    visitorCounter: boolean;
    alignment: 'center' | 'left';
  };
}

export const PERSONAS: Persona[] = [
  {
    id: 'fullstack-dev',
    label: 'Full-Stack Dev',
    description: 'Building web apps end-to-end with TypeScript, React, and Node.js.',
    icon: '🖥️',
    form: {
      name: 'Alex Rivera',
      role: 'Full-Stack Engineer · Open Source Enthusiast',
      location: 'San Francisco, CA',
      focus: 'Building a real-time collaborative code editor with WebSockets and CRDT',
      funFact: 'I once deployed a production app from 30,000 ft on an airplane Wi-Fi — it worked.',
      githubUsername: 'alexrivera-dev',
      twitter: 'alexrivera_dev',
      linkedin: 'in/alexrivera-dev',
      portfolio: 'https://alexrivera.dev',
      devto: 'alexrivera_dev',
      techStack: ['typescript', 'react', 'nextjs', 'nodejs', 'postgresql', 'docker', 'tailwindcss', 'git'],
      statsCard: true,
      statsTheme: 'tokyonight',
      topLangs: true,
      streakStats: true,
      visitorCounter: false,
      alignment: 'center',
    },
  },
  {
    id: 'oss-maintainer',
    label: 'OSS Maintainer',
    description: 'Maintaining open-source libraries used by thousands of developers.',
    icon: '🔧',
    form: {
      name: 'Sam Chen',
      role: 'OSS Maintainer · Rust & Go Craftsperson',
      location: 'Berlin, Germany',
      focus: 'Maintaining a Rust CLI toolkit with 4k GitHub stars and writing its v2 rewrite',
      funFact: 'My most-starred repo started as a 2 AM weekend hack I never expected anyone to use.',
      githubUsername: 'samchen-oss',
      twitter: 'samchen_oss',
      linkedin: 'in/samchen-oss',
      portfolio: 'https://samchen.dev',
      devto: '',
      techStack: ['rust', 'go', 'python', 'linux', 'git', 'docker', 'kubernetes'],
      statsCard: true,
      statsTheme: 'gruvbox',
      topLangs: true,
      streakStats: true,
      visitorCounter: true,
      alignment: 'center',
    },
  },
  {
    id: 'design-engineer',
    label: 'Design Engineer',
    description: 'Bridging design and code — component systems, Figma to production.',
    icon: '🎨',
    form: {
      name: 'Jordan Park',
      role: 'Design Engineer · Component Systems · Accessibility',
      location: 'London, UK',
      focus: 'Building a headless component library with Radix UI, TailwindCSS, and Storybook',
      funFact: 'I can spot a misaligned pixel from across the room. My colleagues find it charming.',
      githubUsername: 'jordanpark-design',
      twitter: 'jordanpark_design',
      linkedin: 'in/jordanpark-design',
      portfolio: 'https://jordanpark.design',
      devto: 'jordanpark_design',
      techStack: ['figma', 'react', 'typescript', 'tailwindcss', 'svelte', 'graphql'],
      statsCard: true,
      statsTheme: 'radical',
      topLangs: false,
      streakStats: false,
      visitorCounter: false,
      alignment: 'center',
    },
  },
  {
    id: 'indie-maker',
    label: 'Indie Maker',
    description: 'Shipping small SaaS products, tools, and experiments solo.',
    icon: '🚀',
    form: {
      name: 'Morgan Ellis',
      role: 'Indie Maker · Shipping products, one weekend at a time',
      location: 'Remote · anywhere with good Wi-Fi',
      focus: 'Launching a no-code form builder for developers who hate wiring forms',
      funFact: 'I\'ve shipped 12 products in 18 months. 2 make money. That\'s considered a win.',
      githubUsername: 'morgan-makes',
      twitter: 'morgan_makes',
      linkedin: 'in/morgan-makes',
      portfolio: 'https://morgan.build',
      devto: 'morgan_makes',
      techStack: ['javascript', 'nextjs', 'tailwindcss', 'postgresql', 'redis', 'docker'],
      statsCard: true,
      statsTheme: 'onedark',
      topLangs: false,
      streakStats: true,
      visitorCounter: true,
      alignment: 'left',
    },
  },
];
