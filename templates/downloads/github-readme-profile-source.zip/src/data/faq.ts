export interface FaqItem {
  question: string;
  answer: string;
}

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: 'Do my inputs leave the browser?',
    answer: 'No. All markdown assembly is pure JavaScript string interpolation that runs entirely in your browser. No network requests are made with your data — not to our servers, not to any third party. You can verify this by opening DevTools → Network while filling the form.',
  },
  {
    question: 'Can I edit the generated markdown afterward?',
    answer: 'Yes — it\'s plain markdown. Copy it, paste it into any text editor (VS Code, Typora, even GitHub\'s web editor), and change whatever you like. Add sections, remove sections, tweak wording. The generated output is just a starting point.',
  },
  {
    question: 'What are github-readme-stats and streak-stats?',
    answer: 'They\'re free, open-source services that render SVG stat cards from your public GitHub data. The images are fetched by GitHub\'s servers when someone views your profile — not by this tool. github-readme-stats is by @anuraghazra; streak-stats is by @DenverCoder1. Both are MIT-licensed.',
  },
  {
    question: 'What is my GitHub username vs my display name?',
    answer: 'Your GitHub username is what appears in your profile URL: github.com/username. Your display name is the full name shown on your profile page — they can be completely different. The generator uses your username for stats card URLs and your display name for the README heading.',
  },
  {
    question: 'Why does the stats card show a placeholder in the preview?',
    answer: 'The in-page preview renders the markdown output visually. Stats cards require GitHub\'s servers to fetch your live data and render an SVG — that only works once you paste the README into your GitHub profile. The preview uses a static placeholder to keep the generator 100% offline-capable.',
  },
  {
    question: 'Can I add the contribution snake animation?',
    answer: 'The snake animation (by @Platane/snk) requires a GitHub Actions workflow inside your special <username>/<username> repository to regenerate the SVG on every push. This is outside the scope of a pure markdown generator. We link to the Platane/snk documentation in the FAQ answer so you can wire it up separately after pasting your README.',
  },
];
