// Single source of truth for the Flowra app landing page.
// Cloning users edit this file to make the site theirs.

export const app = {
  name: 'Flowra',
  tagline: 'Build habits that stick.',
  oneLiner:
    'A warm, gentle habit tracker that turns "I should" into "I did" — one streak at a time.',
  category: 'HealthApplication',          // schema.org applicationCategory
  operatingSystems: 'iOS, Android',
  price: 0,                                // free; in-app purchases live in the stores
  currency: 'USD',
  version: '2.4.1',
  url: 'https://example.com/flowra',       // app's marketing URL
  // Aggregated rating displayed in hero, social proof, and JSON-LD.
  rating: { value: 4.9, count: 1247 },
  // Hardcoded download count — updated manually in source by the operator.
  // Live counters require a server; static is the right fit for a marketing page.
  downloads: 50_000,
  countries: 120,
  // Real App Store / Play Store IDs — fill in via env vars.
  // The defaults below are obvious placeholders that link to a search rather
  // than a 404, so the demo has working buttons.
  appStoreUrl:
    'https://apps.apple.com/us/app/streaks/id963034692',  // placeholder real-world streak app
  playStoreUrl:
    'https://play.google.com/store/apps/details?id=com.headspace.android',  // placeholder
  appStoreId: '963034692', // for the Apple smart banner <meta>
};

export const founder = {
  name: 'Flowra',
  role: 'Indie iOS / Android developer',
  location: 'Toronto, ON',
  email: 'hello@flowra.com',
  socials: {
    linkedin: '#',
    x:        '#',
    github:   '#',
    instagram: '#',
  },
};

export const features = [
  {
    icon: 'flame',
    title: 'Streak tracking',
    description:
      'Each day you check in, your streak grows. Miss one — Flowra holds your place once a month so a sick day doesn\'t cost you a year.',
  },
  {
    icon: 'bell',
    title: 'Smart reminders',
    description:
      'Reminders that learn your routine. Wake-up coffee at 7:14? Flowra knows. Yoga every Tuesday? Got it.',
  },
  {
    icon: 'layout',
    title: 'Home-screen widgets',
    description:
      'iOS and Android widgets show today\'s habits at a glance. Tap to check off without unlocking the app.',
  },
  {
    icon: 'chart',
    title: 'Progress stats',
    description:
      'Six-month consistency view, longest streaks per habit, weekday heatmaps. Numbers without judgement.',
  },
  {
    icon: 'cloud',
    title: 'iCloud + Drive sync',
    description:
      'Your habits sync across iPhone, iPad, Android tablet, and Apple Watch. End-to-end encrypted.',
  },
  {
    icon: 'moon',
    title: 'Dark mode',
    description:
      'Yes, the app has dark mode. (This landing page is light-only by design — read about it in the FAQ.)',
  },
];

export const steps = [
  {
    n: 1,
    title: 'Set a habit',
    body: 'Pick something small — drink water, read 10 pages, walk after lunch. Anything you can do in under 5 minutes.',
  },
  {
    n: 2,
    title: 'Check it off',
    body: 'Tap the circle when you\'ve done it. That\'s the entire interaction. No notes, no scoring, no dopamine dance.',
  },
  {
    n: 3,
    title: 'Watch the streak grow',
    body: 'Day by day the number ticks up. After two weeks you stop needing reminders. That\'s the goal.',
  },
];

// `avatar` (filename without extension, in public/images/pro/reviews/) drives
// the Pro edition's reviewer headshots. Free shows text-only reviews.
export const reviews = [
  {
    name: 'Daniella M.',
    rating: 5,
    text: '"Finally a habit tracker that doesn\'t make me feel like a guilty algorithm. The grace day saved my 90-day meditation streak."',
    avatar: 'daniella',
  },
  {
    name: 'Marcus J.',
    rating: 5,
    text: '"The widget is the whole reason I use this. Three taps, dishes done, streak +1, on with my day."',
    avatar: 'marcus',
  },
  {
    name: 'Priya R.',
    rating: 5,
    text: '"I\'ve tried six habit apps. This is the only one I\'m still using a year later. The interface respects my time."',
    avatar: 'priya',
  },
];

export const faqs = [
  {
    q: 'Is Flowra free?',
    a: 'Yes — the app is free to download and use. There\'s an optional Flowra+ subscription ($1.99/mo) that unlocks unlimited habits, widget themes, and Apple Watch complications. The free tier covers everything you need to build five daily habits.',
  },
  {
    q: 'Is Flowra on iOS, Android, or both?',
    a: 'Both. The iPhone version came first; Android arrived in 2024. The two clients sync to the same backend, so you can switch devices without losing your streak.',
  },
  {
    q: 'Will my habits sync across devices?',
    a: 'Yes — via iCloud (iOS / iPadOS / macOS) and Google Drive (Android). Your habit data is end-to-end encrypted before it leaves your device. Flowra\'s server only holds opaque blobs.',
  },
  {
    q: 'Can I add custom habits or only pick from a list?',
    a: 'Anything you want. Habits are short text strings — "20 push-ups," "call mom," "no Coke today." Add them on the fly; rename them anytime.',
  },
  {
    q: 'Is my data private? Do you sell it?',
    a: 'No. Your habits are encrypted before sync. Flowra does not have access to them. We don\'t sell, share, or aggregate user data — and there is no analytics SDK in the app. Privacy details live in the in-app settings and our Privacy page.',
  },
];

export const screenshots = [
  {
    id: 'dashboard',
    label: 'Today',
    caption: 'Your habits, in order, as they fit your day.',
  },
  {
    id: 'list',
    label: 'Streaks',
    caption: 'Streak counts and longest runs at a glance.',
  },
  {
    id: 'stats',
    label: 'Progress',
    caption: 'Six-month consistency view per habit.',
  },
];
