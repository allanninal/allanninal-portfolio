# mobile-app-landing

A free, MIT-licensed **single-page mobile-app landing** template for indie iOS/Android developers and small mobile teams. Demonstrated by marketing a fictional `Flowra` habit-tracker app — real placeholder copy, App Store + Google Play badges, SVG phone mockups with CSS-rendered screens, and `MobileApplication` schema.org JSON-LD.

**Light-only · Manrope · Magenta `#DB2777` on warm off-white `#FFF7F9`.**

![Preview](./preview.png)

**Live demo:** [example.com](https://example.com/)

---

## Features

- **Real fictional product (Flowra)** with substantive copy across every section. Authors swap text, not structure.
- **SVG phone-frame component** with three CSS-rendered fake-iOS screens (dashboard, streaks, stats). No third-party mockup PNGs, no licensing concerns, infinite-scale on retina, fully editable as Astro components.
- **Official App Store + Google Play badge SVGs** — pure inline SVG with proper Apple/Google brand colors and gradients. No external CDN, no rasterized PNG, no broken image when offline.
- **`MobileApplication` schema.org JSON-LD** with `applicationCategory`, `operatingSystem`, `offers.price`, full `aggregateRating` (`ratingValue` + `ratingCount` + `bestRating`/`worstRating`), and `author` Person reference. Unlocks star-rating rich results in Google Search — a concrete SEO advantage that no surveyed free template ships.
- **Apple smart banner pre-wired.** A `<meta name="apple-itunes-app" content="app-id=…">` tag in `<head>` triggers iOS Safari's native install prompt automatically. Activates when you set `PUBLIC_APP_STORE_ID`; inert otherwise.
- **Light-only by design.** Habit/wellness apps cluster on warm off-white (Headspace, Streaks, Calm). Dark mode is a documented v2 extension, not a missing feature.
- **Manrope variable font, magenta accent.** Type stack and palette completely fresh from Days 1-6. The pink-600 accent is darkened to pink-900 for body-copy text contexts so axe color-contrast passes at all sizes.
- **Native `<details>`/`<summary>` FAQ.** Zero JavaScript for the accordion — works without JS, native screen-reader support, no a11y debt.
- **Custom `@font-face` with `font-display: optional`.** Skips the Manrope swap-in if not cached, preserving CLS. Lighthouse Performance score: 1.0 (CLS = 0).
- **GH Pages deploy pre-wired.** `pages.yml` workflow, `base` path, `site:` config — same as every other day in this sprint.
- **Full test suite — 43 Playwright tests** including: every route renders without console errors, `MobileApplication` JSON-LD with required fields, OG image absolute URL with 1200×630 dimensions, Twitter `summary_large_image`, Apple smart banner present, FAQ toggle works WITH and WITHOUT JavaScript (verifying the native `<details>` story), 6 features rendered, 3 phone mockups in screenshots, 3 review cards, LinkedIn-first footer, both store badges in hero AND final CTA, mobile tap targets, axe clean, Lighthouse all four ≥ 95.

## Stack

- **Framework:** Astro 4 (static output)
- **Styles:** Tailwind CSS, CSS custom properties for theme tokens
- **Fonts:** Manrope Variable (latin subset, custom @font-face for `font-display: optional`)
- **Phone mockup:** Pure SVG with `<foreignObject>` for HTML/CSS screen content
- **Testing:** Playwright, @axe-core/playwright, Lighthouse CI, linkinator

## Quick start

```bash
unzip mobile-app-landing-source.zip -d my-app
cd my-app
npm install
cp .env.example .env
npm run dev
```

## Customize

### 1. App identity

Edit `src/data/site.ts`. The `app` object is the source of truth for name, tagline, store URLs, ratings, version, downloads, etc.

```ts
export const app = {
  name: 'Flowra',
  tagline: 'Build habits that stick.',
  oneLiner: '...',
  category: 'HealthApplication',  // schema.org applicationCategory
  appStoreUrl: 'https://apps.apple.com/.../id963034692',
  playStoreUrl: 'https://play.google.com/store/apps/details?id=...',
  appStoreId: '963034692',         // for Apple smart banner
  rating: { value: 4.9, count: 1247 },
  downloads: 50_000,
  countries: 120,
};
```

Schema.org `applicationCategory` values: `HealthApplication`, `LifestyleApplication`, `ProductivityApplication`, `EducationApplication`, `EntertainmentApplication`, `GameApplication`, etc. — full list at [schema.org/MobileApplication](https://schema.org/MobileApplication).

### 2. Apple smart banner

Set `PUBLIC_APP_STORE_ID` in `.env` to your numeric App Store app ID:

```bash
PUBLIC_APP_STORE_ID=963034692
```

When set, iOS Safari renders a native install banner at the top of the page automatically. Without an ID, the `<meta>` falls back to the placeholder in `site.ts` for the demo.

### 3. Features, steps, reviews, FAQ

Edit the corresponding arrays in `src/data/site.ts`:

- `features[]` — 6 feature cards (icon, title, description). Icon names map to inline Lucide-style SVG paths in `FeatureGrid.astro`.
- `steps[]` — 3 numbered "How it works" steps.
- `reviews[]` — 3 App Store-style review cards.
- `faqs[]` — 5 question/answer pairs rendered with native `<details>`.

### 4. Phone mockup screens

The `<PhoneFrame>` component (`src/components/PhoneFrame.astro`) is a pure SVG with a `<foreignObject>` slot. Drop any HTML/CSS into the slot:

```astro
<PhoneFrame ariaLabel="My screen">
  <div style="height:100%;background:#FFF;padding:20px;">
    Your screen content
  </div>
</PhoneFrame>
```

Three example screens ship in `src/components/screens/`: `DashboardScreen`, `StreaksScreen`, `StatsScreen`. They're plain HTML/CSS — no images, no fixtures.

### 5. Theme tokens

Edit `:root` in `src/styles/global.css`. The accent comes in two shades:

- `--color-accent: #DB2777` (pink-600) — used for buttons, accents on visuals, focus rings. Passes WCAG AA at 18px+ on warm-white.
- `--color-accent-deep: #831843` (pink-900) — used for body-copy links and the eyebrow label. Passes WCAG AA at all sizes.

If you swap the accent hue, **verify both shades pass AA against `--color-bg` and `--color-surface-2`**. See [accent-contrast-check](../../.claude/skills/accent-contrast-check/SKILL.md) in the parent repo.

### 6. Privacy page

`src/pages/privacy.astro` is a static page with placeholder content. Edit the prose, keep the schema.org-compatible structure (h1, h2 sections), and ship.

### 7. Dark mode

Out of scope for v1. To add it: introduce `:root[data-theme='dark']` overrides for the surface/text/accent tokens, add a toggle in `SiteHeader.astro`. The CSS-rendered phone screens will need a dark variant — they currently hardcode light surfaces.

---

## Deploy to GitHub Pages

> The source repo is private — there is no Fork button. Download the source ZIP from [example.com](https://example.com/) and follow these steps.

1. **Unzip + init**:

   ```bash
   unzip mobile-app-landing-source.zip -d my-app
   cd my-app
   git init && git add . && git commit -m "init from mobile-app-landing template"
   ```

2. **Push** to a GitHub repository.

3. **Settings → Pages → Source: GitHub Actions.** The included `pages.yml` builds and deploys.

### Custom domain

Add `CNAME` in `public/`, set `PUBLIC_SITE_URL` and `PUBLIC_BASE_PATH=/` in repo Variables → Actions.

---

## Testing

```bash
npm run test:all
# = npm run build && npm run test && npm run test:links && npm run test:lighthouse
```

| Suite | What it covers |
|---|---|
| `tests/pages.spec.ts` | Every route renders, h1, footer, no console errors; meta description; **`MobileApplication` JSON-LD** with `applicationCategory`, `operatingSystem`, `offers.price`, `aggregateRating` (ratingValue + ratingCount + bestRating); `WebSite` JSON-LD; **Apple smart banner** `<meta>` tag; OG image absolute + 1200x630 dimensions; Twitter `summary_large_image`; canonical URLs; sitemap; robots.txt |
| `tests/interactions.spec.ts` | Hero shows app name + tagline + store badges + phone mockup; App Store badge → apps.apple.com; Google Play → play.google.com; badges appear in hero AND final CTA; `rel="noopener noreferrer"` on every external; social proof bar (3 stats); 6 feature cards; 3 phone mockups in screenshots; 3 numbered steps; 3 review cards; **FAQ uses native `<details>` and toggles WITH AND WITHOUT JavaScript** (proves it's accessible by default); donate link points to ko-fi; LinkedIn precedes email in the footer; privacy page renders |
| `tests/responsive.spec.ts` | No horizontal scroll at 4 viewports; mobile shows hero h1 + tagline + first store badge above the fold; "Get the app" header button hits 36px; App Store badge ≥ 40px on mobile |
| `tests/a11y.spec.ts` | Zero axe violations on `/` and `/privacy/` |
| `tests/links.spec.ts` | Internal links resolve; hash anchors point to existing IDs; mailto links well-formed |

---

## Support and donations

This template is **free and MIT-licensed**.


---

## License

MIT — see [LICENSE](./LICENSE).

Part of the [365-template series](https://example.com/templates/) — Day 7 of 365 free, MIT-licensed static website templates.
