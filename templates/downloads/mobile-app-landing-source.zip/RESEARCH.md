# Mobile App Landing Template — Research Brief

> **Assumption:** Single-page marketing site for a consumer mobile app targeting iOS and Android. The defining structural elements are App Store + Google Play download badges, a centered phone mockup hero, a screenshot carousel or grid, and a feature grid. Target author: indie iOS/Android developer or a small mobile team who needs a credible, fast-shipping landing page.

> **Fictional app chosen:** `Zenly` is taken, so we use **Flowra** — a habit-streak tracker. "Build habits that stick." Free download, optional premium upgrade. iOS + Android. This covers the most common indie-app archetype and gives natural content for every section (streaks, stats, reminders, widgets).

---

## Audience & primary CTA

- **Who visits:** Someone who found the app on social media, Product Hunt, or a Google search — evaluating whether to download before tapping the App Store link.
- **Primary CTA:** Tap "Download on the App Store" or "Get it on Google Play" — both badges in the hero, repeated in the final CTA section.
- **Secondary CTAs:** See features (scroll anchor), view screenshots, read reviews. No signup, no email capture — downloads are the metric.

---

## Reference sites (real businesses)

- https://streaksapp.com — Award-winner credibility badge (Apple Design Award) placed above the fold; App Store badge appears twice (hero + footer); multi-device mockup grid; minimal prose, feature-first layout. White/black, clean sans-serif, no visual clutter. Proves minimalist works for productivity apps.
- https://www.headspace.com — Illustrated hero characters (not photorealistic); calming muted palette; FAQ section mid-page; App Store badges in footer (web-first site). Social proof via org count ("4,000+ leading organizations") and individual testimonial cards. Soft sans-serif, generous whitespace.
- https://rocketmoney.com — Phone mockups embedded alongside each feature section (not just hero); QR code in hero for mobile-to-app handoff; "10 million+ members" social proof; tiered feature comparison. Fintech register: dark navy, confident typography.
- https://culturedcode.com/things/ — Premium minimal register; video hero; multi-platform mockup collage; press accolades section; newsletter in footer; App Store badges per platform. Proves that photography-quality device mockups elevate perceived quality.
- https://www.duolingo.com — Vibrant mascot-driven, high contrast green; playful illustration-heavy hero; social proof via "500M+ learners" counter; no traditional feature grid — the app IS the demonstration. Shows how brand character can carry the page.
- https://reflect.app — Feature-driven scroll (no carousel); testimonial "Wall of Love"; pricing section mid-page; bold headline, minimal decoration; video preview in hero. Note-taking register: restrained, typographically strong.
- https://rocketmoney.com — (see above; second note: QR code in hero is a good static substitute for smart banners)

---

## Existing templates surveyed

- https://github.com/sofiyevsr/mobile-app-landing-template — Astro + DaisyUI + TailwindCSS; ships 3D icons, iPhone 15 frames, avatar images; CabinSketch/Rowdies fonts (quirky, not premium); no schema.org; no dark mode; no real placeholder content; 68 stars. Strength: modular sections. Weakness: generic DaisyUI theme, no SEO, no accessibility mention.
- https://github.com/tailwindtoolbox/App-Landing-Page — Plain HTML + CDN Tailwind; no build step, no component structure; dated design patterns (full-width gradient hero, cards in 3-column grid). Strength: zero friction to edit. Weakness: looks 2019.
- https://github.com/cruip/tailwind-landing-page-template — React/Next.js; Tailwind v4; polished SaaS register, not app-focused; no phone mockup component; no App Store badges; no schema. Strong for SaaS, wrong register for consumer app landing.
- **Saturated patterns:** Purple/blue gradient + floating card mockups; generic "App Name — Download Now" headline; stock phone frame images with placeholder screenshots; no real app content. Every free template marketplace looks the same.
- **Missing:** A template with (a) a specific fictional app with real placeholder copy, (b) SVG phone frame component with embedded screenshots, (c) official App Store/Play Store badge SVGs, (d) `MobileApplication` schema.org JSON-LD, (e) Manrope typography, (f) a warm non-blue/non-green palette, (g) GH Pages pre-wired, (h) accessible color contrast throughout.

---

## Decision: Visual register

**Playful-premium hybrid.** Pure minimal (Things 3 register) requires real photography-quality assets we cannot generate. Pure playful (Duolingo) requires illustration assets. The sweet spot: **warm, confident, slightly playful** — large rounded type, a single strong accent color, subtle gradients on the hero, SVG phone frame with real-looking CSS-rendered screenshots. This matches the Headspace/Streaks midpoint and is achievable in pure HTML/CSS/SVG without assets from a designer.

---

## Palette decision

**Deep magenta: `#DB2777` (Tailwind pink-600)** as primary accent. Background: soft warm off-white `#FFF7F9` (light). Text: `#1A0A10` (near-black, warm). Secondary surface: `#FCE7F3` (pink-50 equivalent). CTA hover: `#BE185D` (pink-700). This palette reads "consumer health/wellness/productivity" — common for habit trackers — and is completely unused across Days 1–6. No blue, no green, no amber, no coral.

**No dark mode.** Habit/wellness apps are predominantly light-default (Headspace, Streaks, Calm). The warm off-white base is the brand. Dark mode would require a full re-palette; out of scope for v1. Document this as a known extension point.

---

## Typography decision

**Manrope** (Google Fonts, OFL licensed) for all text — headings, body, UI labels. Manrope is a modern semi-geometric sans: warmer than Inter, more distinctive than DM Sans, friendlier than IBM Plex. It sits between Apple's SF and DIN Pro — ideal for consumer app landing pages. None of the prior six days use it. Weight range: 400 (body), 600 (subheadings), 800 (hero display). No second font family needed; Manrope's weight range is wide enough for hierarchy without a pairing.

---

## Phone mockup decision

**SVG phone frame with embedded `<image>` tags pointing to screenshot PNGs.** The frame is a pure SVG: rounded rect for the outer shell, inner viewport, notch/dynamic island cutout, thin bezel stroke. Screenshots are 5 PNG files committed to `public/screenshots/`. This is lighter than a PNG frame (infinite scale, 0 quality loss on retina), more premium than pure CSS, and avoids licensing concerns with third-party mockup assets. The SVG frame is authored once in the template; the user swaps in their own screenshots.

---

## Screenshots decision

**Pure HTML/CSS "screenshots"** rendered as styled divs — faked UI screens showing the Flowra habit tracker interface. Three screens: (1) dashboard with streak counters, (2) habit list with checkboxes, (3) progress/stats chart. These are self-contained HTML components that look like real iOS UI without requiring image files. No licensing risk. Builder renders them into PNGs at build time or leaves them as CSS — either works.

---

## Must-have sections (in order)

1. **Hero** — App name + one-liner tagline, subhead (1 sentence value prop), App Store badge + Play Store badge side-by-side, SVG phone mockup showing the dashboard screen, star rating teaser ("4.9 ★ on the App Store").
2. **Social proof bar** — 3 stats: "50,000+ downloads", "4.9 ★ avg rating", "120 countries". Single horizontal strip, muted background.
3. **Features** — 6-feature grid (2×3 on desktop, 1 col on mobile). Each: icon (Lucide SVG), feature name, 1-sentence description. Icons are magenta-tinted on pink-tinted card. Features: streak tracking, smart reminders, widgets, progress stats, iCloud sync, dark mode (ironic — the app has dark mode even if the landing doesn't).
4. **How it works** — 3 numbered steps (Set a habit → Check it off → Watch your streak grow). Horizontal on desktop, stacked on mobile. Simple illustration or icon per step.
5. **Screenshots** — Horizontal scroll carousel on mobile, 3-up grid on desktop. Each screenshot in an SVG phone frame. Captions below.
6. **Social proof / Reviews** — App Store rating (4.9/5, rendered as star SVG + number) + 3 pull-quote cards with reviewer name, star count, short quote. Pattern from Headspace + Rocket Money.
7. **FAQ** — 5 questions using `<details>`/`<summary>` accordion (no JS required). Questions: Is it free? iOS or Android? Does it sync? Can I add custom habits? Is my data private?
8. **Final CTA** — Repeat the two download badges, centered, with a short motivational line. Magenta background section.
9. **Footer** — App name, tagline, Privacy Policy link, Support email link, copyright. Social links (Twitter/X, Instagram) as icon SVGs.

**Explicitly no pricing section** — Flowra is free download with optional in-app purchase. Pricing belongs in the app stores, not on the landing page. This matches the real-world pattern for consumer apps (Headspace buries pricing, Streaks doesn't show it at all on the landing).

---

## Design conventions (from reference sites)

- **Typography:** Rounded/humanist sans-serif universally. Large hero display weight (700–800). Body 400 at 1rem/1.7. Manrope fits this pattern exactly.
- **Color palette tendency:** Wellness/productivity apps cluster in warm neutrals with a single bold accent. Blue is fintech (Revolut), green is sustainability/nature, magenta/pink is wellness/habit — unused in our prior days.
- **Imagery style:** Device mockups (not lifestyle photography) are the primary visual. Illustration-accented heroes in the playful register. We use SVG phone + CSS screenshots — zero image dependencies.
- **Density:** Sparse to medium. Generous whitespace between sections. Hero is nearly full-viewport. Feature grid is the densest section. Not bento-dense.

---

## Trust signals to include

- Apple Design Award or Editor's Choice badge SVG (fictional "Featured in App Store" chip)
- Star rating (4.9 ★) in hero and reviews section
- Download count ("50,000+ downloads")
- 3 App Store-style review cards with reviewer first name + star count
- "Built by an indie developer" line in footer — signals a real human, not a faceless company
- Privacy Policy link (static `/privacy.html` stub page) — GDPR/CCPA trust signal for European users

---

## SEO / schema.org

- **Type:** `MobileApplication` (subclass of `SoftwareApplication`)
- **Required properties:** `name`, `offers.price` (0 for free), `aggregateRating` (ratingValue + ratingCount), `operatingSystem` ("iOS, Android"), `applicationCategory` ("HealthApplication"), `url`
- **Recommended:** `description`, `screenshot` (array of screenshot URLs), `downloadUrl` (App Store link), `softwareVersion`, `author` (Person or Organization)
- **Also add:** `WebSite` with `name` + `url` on the root page
- **Suggested OG image:** Flowra wordmark in Manrope 800 on magenta `#DB2777`, phone mockup to the right, tagline beneath. 1200×630 static PNG committed to `public/og.png`.

---

## Static-only fit

No concerns. Everything works at build time or client-side only:

- **Download badges:** Static SVG `<img>` tags linking to App Store / Play Store URLs. No JS.
- **Screenshot carousel:** CSS scroll-snap + `overflow-x: scroll` on mobile; no JS needed for basic carousel.
- **FAQ accordion:** Native `<details>`/`<summary>` HTML — zero JS, fully accessible.
- **App Store rating:** Hardcoded number + SVG stars. Updated manually when the author ships. No API call.
- **Contact/support link:** `mailto:` link. No form, no server.
- **App Store smart banners** (`<meta name="apple-itunes-app">`) — static `<meta>` tag in `<head>`. Zero JS, GH Pages compatible. Worth including; document the app ID placeholder.

---

## Differentiation — what we'll do better

1. **Manrope + magenta `#DB2777` — completely unused register.** No existing free template uses this combination. Immediately recognizable as "not the default."
2. **SVG phone frame component.** The sofiyevsr template uses a third-party iPhone 15 frame PNG. Our SVG is infinitely scalable, lighter, and authored in the template — the user edits one SVG file to swap screenshots.
3. **Real fictional app content throughout.** Every section has copy for "Flowra" — not "App Name" and "Lorem ipsum." The author sees a complete, credible page and replaces text, not structure.
4. **`MobileApplication` JSON-LD schema.** None of the surveyed free templates include it. Unlocks App Store rich results in Google Search (star rating display).
5. **Official App Store + Play Store badge SVGs committed to `public/`.** Most templates link to external CDNs or use placeholder images. We ship the real badges, sized correctly per Apple/Google brand guidelines.
6. **Native `<details>` FAQ — zero JS.** Common templates use JS accordion libs. Our FAQ is accessible, works without JS, degrades gracefully, and adds no bundle weight.
7. **Apple smart banner `<meta>` tag pre-wired** with a placeholder app ID comment. The author fills in one value; mobile Safari shows a native install prompt automatically.
8. **GH Pages deploy pre-wired.** `pages.yml` workflow, correct `base` path — same as every other day in this sprint.

---

## Explicitly NOT building

- **App Store smart-link routing / deep links** — requires a server or a third-party service (Branch.io, Adjust). Out of scope. Static `<a href>` links to both stores suffice.
- **Regional store variants** — single `en` locale, single store URL per platform. Regional routing requires server-side geolocation.
- **In-app purchase / pricing page** — IAP lives in the app stores. A static pricing section would be stale every time the developer adjusts pricing.
- **Version-specific download links** — App Store always serves the latest. No version routing needed.
- **Real-time download counter** — a live counter requires a server or third-party analytics widget. Hardcoded "50,000+" is the static substitute and common practice (Streaks, Headspace both use hardcoded figures).
- **Video background / lottie animations** — too heavy for a static template; conflicts with the performance story. CSS transitions only.
- **Dark mode toggle** — intentional omission. The warm magenta/pink palette is the brand. A dark-mode inversion would require a full re-design; document as v2 extension point.
