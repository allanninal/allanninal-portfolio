import { test, expect } from '@playwright/test';

// ── Hero ───────────────────────────────────────────────────────────────────

test('hero shows app name, tagline, store badges, and a phone mockup', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toContainText(/build habits/i);
  // Star rating teaser
  await expect(page.getByText(/4\.9/).first()).toBeVisible();
  // Both store badges as <a> with aria-labels
  await expect(page.getByRole('link', { name: /download .* on the app store/i }).first()).toBeVisible();
  await expect(page.getByRole('link', { name: /get .* on google play/i }).first()).toBeVisible();
  // Phone mockup SVG with our aria-label
  await expect(page.getByRole('img', { name: /flowra dashboard preview/i })).toBeVisible();
});

// ── Store badges (the conversion goal) ────────────────────────────────────

test('App Store badge link points to apps.apple.com', async ({ page }) => {
  await page.goto('/');
  const badge = page.getByRole('link', { name: /download .* on the app store/i }).first();
  const href = await badge.getAttribute('href');
  expect(href).toContain('apps.apple.com');
});

test('Google Play badge link points to play.google.com', async ({ page }) => {
  await page.goto('/');
  const badge = page.getByRole('link', { name: /get .* on google play/i }).first();
  const href = await badge.getAttribute('href');
  expect(href).toContain('play.google.com');
});

test('store badges appear in the hero AND in the final CTA', async ({ page }) => {
  await page.goto('/');
  // [data-store="app-store"] is set on every App Store badge link
  const appStoreBadges = page.locator('a[data-store="app-store"]');
  expect(await appStoreBadges.count()).toBeGreaterThanOrEqual(2);
  const playBadges = page.locator('a[data-store="google-play"]');
  expect(await playBadges.count()).toBeGreaterThanOrEqual(2);
});

test('every external link uses rel="noopener noreferrer"', async ({ page }) => {
  await page.goto('/');
  const externals = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];
  for (const a of externals) {
    const rel = await a.getAttribute('rel');
    const href = await a.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — rel="${rel}"`);
    }
  }
  expect(unsafe).toEqual([]);
});

// ── Social proof bar ───────────────────────────────────────────────────────

test('social proof bar shows three stats', async ({ page }) => {
  await page.goto('/');
  // 50,000+ downloads, 4.9 ★, 120 countries
  await expect(page.getByText('50,000+')).toBeVisible();
  await expect(page.getByText(/120/)).toBeVisible();
  await expect(page.getByText(/4\.9 ★/)).toBeVisible();
});

// ── Feature grid ───────────────────────────────────────────────────────────

test('feature grid renders all six features', async ({ page }) => {
  await page.goto('/');
  // Each feature is a <li> inside #features
  const features = page.locator('#features ul[role="list"] > li');
  expect(await features.count()).toBe(6);
});

// ── Screenshots ────────────────────────────────────────────────────────────

test('screenshots section shows three phone mockups', async ({ page }) => {
  await page.goto('/');
  // Each phone mockup carries role="img" with a Flowra-related label
  const phones = page.getByRole('img', { name: /flowra .* screen/i });
  expect(await phones.count()).toBeGreaterThanOrEqual(3);
});

// ── How it works ───────────────────────────────────────────────────────────

test('how it works shows three numbered steps', async ({ page }) => {
  await page.goto('/');
  // Headings 01, 02, 03
  for (const n of ['01', '02', '03']) {
    await expect(page.getByText(n).first()).toBeVisible();
  }
});

// ── Reviews ───────────────────────────────────────────────────────────────

test('reviews section shows three review cards', async ({ page }) => {
  await page.goto('/');
  // <blockquote>s in the reviews section
  const cards = page.locator('blockquote');
  expect(await cards.count()).toBeGreaterThanOrEqual(3);
});

// ── FAQ — native <details>, no JS ─────────────────────────────────────────

test('FAQ uses native <details>/<summary> and toggles open/closed', async ({ page }) => {
  await page.goto('/');
  const faqDetails = page.locator('#faq details');
  expect(await faqDetails.count()).toBeGreaterThanOrEqual(5);

  const first = faqDetails.first();
  // Closed by default
  expect(await first.evaluate((el: HTMLDetailsElement) => el.open)).toBe(false);

  // Click summary → opens
  await first.locator('summary').click();
  expect(await first.evaluate((el: HTMLDetailsElement) => el.open)).toBe(true);

  // Click again → closes
  await first.locator('summary').click();
  expect(await first.evaluate((el: HTMLDetailsElement) => el.open)).toBe(false);
});

test('FAQ does not require JavaScript to toggle', async ({ browser }) => {
  // Verify the accordion works with JS disabled — proves it's native HTML.
  const ctx = await browser.newContext({ javaScriptEnabled: false });
  const page = await ctx.newPage();
  await page.goto('/');
  const first = page.locator('#faq details').first();
  // Even without JS, <details> should be present and clickable; the
  // toggle is handled by the browser's native HTML implementation.
  await first.locator('summary').click();
  expect(await first.evaluate((el: HTMLDetailsElement) => el.open)).toBe(true);
  await ctx.close();
});

// ── Final CTA ─────────────────────────────────────────────────────────────

test('final CTA renders both store badges centered', async ({ page }) => {
  await page.goto('/');
  // Scroll to the end and verify the gradient CTA section exists
  const finalCta = page.locator('section').last();
  await expect(finalCta.getByRole('heading', { level: 2 })).toBeVisible();
  await expect(finalCta.getByRole('link', { name: /app store/i })).toBeVisible();
  await expect(finalCta.getByRole('link', { name: /google play/i })).toBeVisible();
});

// ── LinkedIn-primary contact convention ────────────────────────────────────

test('footer lists LinkedIn before email', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer').first();
  const hrefs = await footer.locator('a[href]').evaluateAll((els) =>
    els.map((e) => (e as HTMLAnchorElement).getAttribute('href') || ''),
  );
  const idxLinkedIn = hrefs.findIndex((h) => h.includes('linkedin.com'));
  const idxEmail = hrefs.findIndex((h) => h.startsWith('mailto:'));
  expect(idxLinkedIn).toBeGreaterThan(-1);
  expect(idxEmail).toBeGreaterThan(-1);
  expect(idxLinkedIn).toBeLessThan(idxEmail);
});

test('footer donate link points to ko-fi when env var is set', async ({ page }) => {
  await page.goto('/');
  const donate = page.locator('[data-donate-url]').first();
  if ((await donate.count()) > 0) {
    expect(await donate.getAttribute('href')).toContain('ko-fi.com');
  }
});

// ── Privacy page ─────────────────────────────────────────────────────────

test('privacy page renders and links from footer', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Privacy' }).first().click();
  await expect(page).toHaveURL(/\/privacy\//);
  await expect(page.locator('h1')).toContainText(/privacy/i);
});
