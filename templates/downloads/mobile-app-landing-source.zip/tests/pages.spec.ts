import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // scripts can 403 under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead/i;
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() !== 'error') return;
      const txt = m.text();
      const u = m.location()?.url || '';
      if (THIRD_PARTY.test(txt) || THIRD_PARTY.test(u)) return;
      if (/failed to load resource/i.test(txt)) return;
      errors.push(`console.error: ${txt}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home page meta description is present', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home emits MobileApplication JSON-LD with required fields', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const app = docs.find((d) => d && d['@type'] === 'MobileApplication');
  expect(app, 'MobileApplication JSON-LD missing').toBeTruthy();
  expect(app.name).toBe('Flowra');
  expect(app.applicationCategory).toBe('HealthApplication');
  expect(app.operatingSystem).toContain('iOS');
  expect(app.operatingSystem).toContain('Android');

  // Free app — Offer with price 0
  expect(app.offers).toBeTruthy();
  expect(String(app.offers.price)).toBe('0');

  // Aggregate rating with rich-results-required fields
  expect(app.aggregateRating).toBeTruthy();
  expect(parseFloat(app.aggregateRating.ratingValue)).toBeGreaterThanOrEqual(1);
  expect(parseInt(app.aggregateRating.ratingCount, 10)).toBeGreaterThan(0);
  expect(app.aggregateRating.bestRating).toBe('5');

  // Author for trust signal
  expect(app.author).toBeTruthy();
  expect(app.author['@type']).toBe('Person');
});

test('home emits WebSite JSON-LD', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const ws = docs.find((d) => d && d['@type'] === 'WebSite');
  expect(ws, 'WebSite JSON-LD missing').toBeTruthy();
});

test('Apple smart banner meta tag is present', async ({ page }) => {
  await page.goto('/');
  const banner = page.locator('meta[name="apple-itunes-app"]');
  await expect(banner).toHaveCount(1);
  const content = await banner.getAttribute('content');
  expect(content).toMatch(/^app-id=\d+/);
});

test('OG image is absolute and reachable', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toBeTruthy();
  expect(og!).toMatch(/^https?:\/\//);
  expect(og!).toContain('og-image.png');
  // OG image dimensions
  expect(await page.locator('meta[property="og:image:width"]').getAttribute('content')).toBe('1200');
  expect(await page.locator('meta[property="og:image:height"]').getAttribute('content')).toBe('630');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  expect(await page.locator('meta[name="twitter:card"]').getAttribute('content')).toBe('summary_large_image');
});

test('canonical link is absolute on every route', async ({ page }) => {
  for (const route of ROUTES) {
    await page.goto(route);
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical, `canonical missing on ${route}`).toBeTruthy();
    expect(canonical, `canonical not absolute on ${route}`).toMatch(/^https?:\/\//);
  }
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});
