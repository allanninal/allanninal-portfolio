import type { Page } from '@playwright/test';

export const ROUTES = ['/', '/privacy/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// No theme switcher in this template — the design is light-only on purpose.
// Helper retained for parity with other templates.
export async function setLight(page: Page) {
  await page.emulateMedia({ colorScheme: 'light' });
}
