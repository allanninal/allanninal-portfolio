import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES } from './helpers';

const isPro = process.env.PUBLIC_EDITION === 'pro';

test('a11y: Pro /press-kit/ — zero violations', async ({ page }) => {
  test.skip(!isPro, 'The /press-kit/ page only exists in the Pro edition');
  await page.goto('/press-kit/');
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  const violations = results.violations.map((v) => ({
    id: v.id, impact: v.impact, description: v.description, nodes: v.nodes.length, help: v.helpUrl,
  }));
  expect(
    violations,
    `Axe violations on /press-kit/:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});

for (const route of ROUTES) {
  test(`a11y: ${route} — zero violations`, async ({ page }) => {
    await page.goto(route);

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();

    const violations = results.violations.map((v) => ({
      id: v.id,
      impact: v.impact,
      description: v.description,
      nodes: v.nodes.length,
      help: v.helpUrl,
    }));

    expect(
      violations,
      `Axe violations on ${route}:\n${JSON.stringify(violations, null, 2)}`,
    ).toEqual([]);
  });
}
