/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Light-only by intentional design — habit/wellness apps cluster on warm
  // off-white. Dark mode is documented as a v2 extension point.
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Manrope Variable"', 'Manrope', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Manrope Variable"', 'Manrope', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'xs':  ['0.75rem',   { lineHeight: '1.5' }],
        'sm':  ['0.875rem',  { lineHeight: '1.55' }],
        'base':['1rem',      { lineHeight: '1.65' }],
        'lg':  ['1.125rem',  { lineHeight: '1.55' }],
        'xl':  ['1.25rem',   { lineHeight: '1.45' }],
        '2xl': ['1.5rem',    { lineHeight: '1.3' }],
        '3xl': ['1.875rem',  { lineHeight: '1.2' }],
        '4xl': ['2.25rem',   { lineHeight: '1.15' }],
        '5xl': ['3rem',      { lineHeight: '1.05' }],
        '6xl': ['3.75rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '80rem',
        prose: '68ch',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
};
