// Noor Haddad — Tulsa, OK.
//
// Roadmap line: "Turntables, projects, contact." A turntable is a reel by
// another name, and days 101 and 104 have both already argued that a
// showreel-led page tells a client nothing about how the work will go. Making
// that argument a third time would be a re-skin, so the axis moves to the
// thing a turntable is specifically good at hiding: whether the asset under
// the render is usable.

export const site = {
  name:        'Noor Haddad',
  shortName:   'Noor Haddad',
  title:       'Noor Haddad — 3D artist, Tulsa',
  tagline:     'Ask for the wireframe.',
  owner:       'Noor Haddad',
  ownerRole:   '3D artist and technical modeller',
  credential:  'Hard-surface and environment assets since 2016',
  city:        'Tulsa',
  state:       'OK',
  language:    'en',
  phoneDisplay: '(918) 555-0126',
  phoneHref:   '+19185550126',
  email:       'noor@noorhaddad.example',
  streetAddress: '108 E Reconciliation Way',
  postalCode:  '74103',
  hours:       'Mon–Fri · asynchronous, email first',
  bookingWindow: 'Taking asset work from the middle of next month.',
  description:
    'A 3D artist in Tulsa. A beauty render is the easiest thing in this trade to fake and the ' +
    'hardest thing to use — it can sit on top of a mesh nobody can rig, unwrap or ship. These ' +
    'are the seven checks worth demanding before you accept any 3D asset, including from me.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The checks',   href: '#checks' },
  { label: 'Budgets',      href: '#budgets' },
  { label: 'Turntables',   href: '#turntable' },
  { label: 'Rates',        href: '#rates' },
  { label: 'Brief',        href: '#brief' },
];

// ── The seven checks ──────────────────────────────────────────────────────
// `state` is what this studio's own delivered assets do, not a rating of the
// check — the page is asserting it passes its own list, which is the only way
// publishing a list like this is worth anything.

export const checks = [
  {
    check: 'Quad topology, and edge loops where it bends',
    means: 'The mesh is built from four-sided faces that follow the form, with denser loops at anything that has to deform or catch a highlight.',
    breaks: 'A triangulated or n-gon mesh cannot be rigged without pinching, and subdividing it produces artefacts that look like dents. Fixing this after texturing means redoing the texturing.',
    verify: 'Ask for a wireframe screenshot of one shot, from the front. You are looking for four-sided faces and for the density to sit where the shape changes, not spread evenly across a flat panel. You do not need to know 3D to see whether a wireframe is orderly or a mess.',
    state: 'ok',
  },
  {
    check: 'Real-world scale, in the units of the target',
    means: 'A one-metre crate is one metre in the file, in the unit system the engine or renderer expects.',
    breaks: 'Import at 100× or 0.01×, and every physics, lighting and camera value downstream is wrong. Rescaling on import is not a fix — it moves the problem into every scene the asset appears in.',
    verify: 'Ask for the asset\'s bounding-box dimensions in millimetres and compare them with the real object. Thirty seconds, one email, and it catches the single most common integration failure there is.',
    state: 'ok',
  },
  {
    check: 'Pivot at the origin, Y or Z up as agreed',
    means: 'The object sits at 0,0,0 with a sensible pivot — the base of a crate, the hinge of a door — and its up-axis matches the target application.',
    breaks: 'An asset with its pivot forty metres away rotates in an arc instead of spinning. An axis mismatch lands every prop on its side, and "just rotate it" bakes a correction into every instance forever.',
    verify: 'Ask where the pivot is and which axis is up. If the answer is "wherever it ended up", that is the answer.',
    state: 'ok',
  },
  {
    check: 'UVs unwrapped, with a stated texel density',
    means: 'The surface is laid out flat without overlaps, at a consistent number of texture pixels per real-world centimetre across the whole asset.',
    breaks: 'Inconsistent density means one panel is crisp and the one next to it is mush, in the same shot. Overlapping UVs make lightmap baking impossible, which is discovered at the worst possible moment.',
    verify: 'Ask for a UV layout screenshot and the texel density figure. A layout that fills the square without overlaps and a number like "10.24 px/cm" is the answer you want; "it\'s unwrapped" is not.',
    state: 'ok',
  },
  {
    check: 'Naming and hierarchy a stranger can read',
    means: 'Objects, materials and textures are named for what they are, and the hierarchy groups things the way somebody would want to move them.',
    breaks: 'A scene of Cube.001 through Cube.147 is technically a delivery and practically a puzzle. It costs a day of somebody else\'s time and it is the cheapest of all these problems to have avoided.',
    verify: 'Ask for a screenshot of the outliner. You do not need to understand the names — you need them to look like words.',
    state: 'ok',
  },
  {
    check: 'A triangle count against a stated target',
    means: 'The count is quoted for a named platform, not offered as a virtue in the abstract.',
    breaks: '"Low poly" without a target is meaningless. The same asset is extravagant on a phone and starved in a film close-up, and finding out which after the fact means rebuilding rather than adjusting.',
    verify: 'Ask for the triangle count and what target it was built for. If the second half of that answer does not exist, neither does the first.',
    state: 'ok',
  },
  {
    check: 'Materials and maps in an agreed set',
    means: 'A known number of material slots, a stated map set — base colour, roughness, metalness, normal — at agreed resolutions, in a format the target reads.',
    breaks: 'Twelve materials on a background prop is twelve draw calls that did not need to exist. A 4K map set on a crate seen from ten metres is memory spent on nothing, and both are invisible in a render.',
    verify: 'Ask how many material slots there are and what resolution the maps are. Two numbers, and they tell you more about whether an asset will ship than any turntable will.',
    state: 'ok',
  },
];

export const checksNote =
  'These are not a rating of me — they are the list I would want a client to hold me to, and ' +
  'every asset that leaves here passes all seven. Publishing it is only worth anything if it ' +
  'cuts both ways, so: ask me for any of the seven on any piece of work in this portfolio, and ' +
  'if I cannot produce it the answer is that I did not do it.';

// ── Budgets ───────────────────────────────────────────────────────────────

export const budgets = {
  intro:
    '"Low poly" is not a property of an asset. It is a relationship between an asset and a ' +
    'target, and the same crate is extravagant in the first row and starved in the last.',
  rows: [
    { target: 'Mobile, background prop',  tris: '300 – 1,500',      maps: '512 – 1K',  note: 'Draw calls matter more than triangles here. One material, always.' },
    { target: 'Mobile, hero object',      tris: '3,000 – 8,000',    maps: '1K – 2K',   note: 'The thing the player holds or stands next to. Everything else in the scene pays for it.' },
    { target: 'VR, interactive',          tris: '2,000 – 10,000',   maps: '1K – 2K',   note: 'Rendered twice, ninety times a second. The strictest budget on this list and the one most often ignored.' },
    { target: 'PC / console, hero',       tris: '40,000 – 150,000', maps: '2K – 4K',   note: 'Where most "game-ready" portfolio work actually sits, whatever the description says.' },
    { target: 'Archviz, still image',     tris: '200,000 +',        maps: '4K',        note: 'Almost unbounded, because nothing has to run in real time. The constraint is render time, not memory.' },
    { target: 'Film, hero asset',         tris: 'Millions',         maps: '4K – 8K udim', note: 'Subdivided at render. The base cage is what gets reviewed and it is far lighter than the number suggests.' },
  ],
};

// ── Turntables ────────────────────────────────────────────────────────────

export const turntable = {
  proves: [
    'The silhouette reads from every angle.',
    'The materials respond sensibly to light.',
    'Somebody spent time on the lookdev.',
  ],
  provesNot: [
    'That the topology can deform.',
    'That the asset imports at the right scale.',
    'That the UVs will bake.',
    'That anyone but its author can navigate the file.',
    'That it fits any performance budget at all.',
  ],
  note:
    'A turntable is a good thing and I will send you one. It is just worth being clear about ' +
    'which half of the job it covers — three of the things it shows you, and none of the five ' +
    'that decide whether the asset ships.',
};

export const said = {
  text: 'We approved a set of props from renders and lost most of a sprint to it. Every mesh imported at a hundred times scale, the pivots were wherever the artist had left them, and two of the props shared overlapping UVs so nothing baked. The renders were genuinely beautiful. That was the problem.',
  who: 'Technical art lead, mid-size games studio — on why they now ask for wireframes first',
};

export const rates = {
  rows: [
    { what: 'Hard-surface prop, game-ready', figure: 'From $380',  note: 'High-poly, retopologised, unwrapped, baked and textured against your stated target. All seven checks, every time.' },
    { what: 'Hero asset, PC or console',     figure: 'From $1,400', note: 'Quoted from reference and a target, never from a description. A prop and a hero are different jobs, not different sizes.' },
    { what: 'Environment set, 10–20 pieces', figure: 'From $6,200', note: 'Kit-based, with a shared material set and a modular grid agreed before anything is modelled.' },
    { what: 'Retopology and UVs only',       figure: '$65/hr',      note: 'The rescue job. Frequently cheaper than it sounds and occasionally more expensive than rebuilding, which I will tell you before starting.' },
    { what: 'Source files',                  figure: 'Included',    note: 'Blend or Max plus FBX and glTF, named and organised. A file only its author can open is not a delivery.' },
  ],
};

export const faqs = [
  {
    q: 'Is this list a dig at other artists?',
    a: 'No, and it would be a cheap one — a lot of superb modellers have never had a client ask for a texel density figure, because almost no client knows to. It is a list for the person commissioning the work, and the reason it is on my site rather than in a forum post is that I would like to be held to it too.',
  },
  {
    q: 'Can I see turntables?',
    a: 'Yes, in the first email, alongside a wireframe and a UV layout for the same asset. Sending all three together is the entire argument of this page in practice rather than in prose.',
  },
  {
    q: 'What if we do not know our triangle budget?',
    a: 'Then that is the first conversation, and it is a short one — the platform and the object\'s role in the scene decide it. Guessing a number and building to it is how an asset gets rebuilt.',
  },
  {
    q: 'Do you do characters?',
    a: 'No. Hard-surface, props and environments. Character work is a different craft with a different failure mode and I would rather refer you to somebody who does it every day.',
  },
  {
    q: 'Which software?',
    a: 'Blender and Substance, with Max when a studio pipeline needs it. It matters far less than anyone outside the trade expects — the checks on this page are software-agnostic and so is a bad mesh.',
  },
  {
    q: 'Can you fix assets we already have?',
    a: 'Often. Send one file and I will tell you honestly whether retopology is cheaper than rebuilding, including when the answer costs me the bigger job.',
  },
];
