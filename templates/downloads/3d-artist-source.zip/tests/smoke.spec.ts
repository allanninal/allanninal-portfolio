import { test, expect } from '@playwright/test';

test.describe('Noor Haddad — smoke tests', () => {
  test('homepage renders with the artist name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Noor Haddad/);
    await expect(page.locator('h1')).toContainText('Ask for the wireframe');
  });

  test('is marked up as a Person, with no business-only fields', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q1417684');
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // ── The checks ──────────────────────────────────────────────────────────
  test('every check states what it means, what breaks, and how to verify it', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#checks article.check');
    const n = await items.count();
    expect(n).toBe(7);
    for (const c of await items.all()) {
      await expect(c.locator('h3')).not.toBeEmpty();
      await expect(c.locator('.check-means')).not.toBeEmpty();
      await expect(c.locator('.check-breaks')).toContainText('Without it:');
      await expect(c.locator('details summary')).toContainText(/thirty seconds/i);
    }
    await expect(page.locator('#checks h2')).toContainText(`${n} checks`);
  });

  test('the verification steps are disclosures, closed by default', async ({ page }) => {
    await page.goto('/');
    const d = page.locator('#checks article.check details');
    expect(await d.count()).toBe(7);
    for (const one of await d.all()) {
      expect(await one.getAttribute('open')).toBeNull();
    }
    const first = d.first();
    await first.locator('summary').click();
    await expect(first).toHaveAttribute('open', '');
  });

  // A checklist page must not encode pass/fail in hue alone.
  test('each check carries its state in words, and the state colours are not the accent', async ({ page }) => {
    await page.goto('/');
    const flags = await page.locator('#checks .check-flag').allTextContents();
    expect(flags.length).toBe(7);
    for (const f of flags) {
      expect(['Every asset here passes', 'Not guaranteed here']).toContain(f.trim());
    }
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--check-ok', '--check-bad', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  test('the studio submits itself to its own list', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#checks')).toContainText(/it cuts both ways/i);
    const flags = await page.locator('#checks .check-flag').allTextContents();
    const passing = flags.filter((f) => f.trim() === 'Every asset here passes').length;
    await expect(page.locator('#checks')).toContainText(`${passing} of ${flags.length} asserted`);
  });

  // ── The topology figure ─────────────────────────────────────────────────
  test('the only picture is drawn, decorative, and explained in text', async ({ page }) => {
    await page.goto('/');
    const raster = await page.locator('img').evaluateAll((imgs) =>
      imgs.map((i) => i.getAttribute('src') || '').filter((s) => /\.(jpe?g|png|webp|avif)$/i.test(s)));
    expect(raster).toEqual([]);
    const svgs = page.locator('figure.topo svg');
    expect(await svgs.count()).toBe(2);
    for (const s of await svgs.all()) await expect(s).toHaveAttribute('aria-hidden', 'true');
    await expect(page.locator('figure.topo figcaption')).toContainText(/only one of them can be rigged/i);
    // the two labels are words, not just colours
    const labels = await page.locator('figure.topo .lbl').allTextContents();
    expect(labels.join(' ').toLowerCase()).toContain('quads');
    expect(labels.join(' ').toLowerCase()).toContain('triangles');
  });

  // ── Budgets ─────────────────────────────────────────────────────────────
  test('every budget row names a target, a triangle range and a map size', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#budgets tbody tr');
    expect(await rows.count()).toBeGreaterThan(4);
    for (const r of await rows.all()) {
      expect(await r.locator('td.num').count()).toBe(2);
    }
  });

  test('the brief form offers exactly the targets the budget table lists', async ({ page }) => {
    await page.goto('/');
    const targets = await page.locator('#budgets tbody th').allTextContents();
    const opts = await page.locator('#target option').allTextContents();
    for (const t of targets) expect(opts).toContain(t);
    await expect(page.locator('#target')).toHaveAttribute('required', '');
  });

  // ── Turntables ──────────────────────────────────────────────────────────
  test('the turntable section counts both lists', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('#turntable');
    const lists = s.locator('ul[role="list"]');
    expect(await lists.count()).toBe(2);
    const proves = await lists.nth(0).locator('li').count();
    const not = await lists.nth(1).locator('li').count();
    expect(not).toBeGreaterThan(proves);
    await expect(s.locator('h2')).toContainText(`Proves ${proves} things`);
    await expect(s.locator('h2')).toContainText(`the ${not} that decide`);
  });

  test('a client is quoted on the failure this page is about', async ({ page }) => {
    await page.goto('/');
    const q = page.locator('#turntable blockquote.said');
    await expect(q).toContainText(/hundred times scale/i);
    await expect(q.locator('cite')).toHaveCount(1);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the brief form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-104 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['dara okonkwo', 'lincoln', 'keyframe', 'storyboard', 'q1058500', 'schibsted']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro asset spec is absent from the free build', async ({ page }) => {
    const res = await page.goto('/asset-spec/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
