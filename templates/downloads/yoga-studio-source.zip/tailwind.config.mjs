/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"EB Garamond"', 'Georgia', 'serif'],
        body:    ['"Quicksand"', 'system-ui', 'sans-serif'],
      },
      colors: {
        linen: {
          50:  '#FDFAF6',
          100: '#F8F4EE',
          200: '#EEE6DA',
          300: '#E2D6C6',
          400: '#C4B8A8',
          500: '#A09080',
          600: '#7A6F6A',
          700: '#5A5050',
          800: '#3D3530',
          900: '#2C2420',
        },
        sage: {
          50:  '#EDF4F0',
          100: '#C0D8C8',
          200: '#92BBA4',
          300: '#6E9D83',
          400: '#5E7C6A',
          500: '#4A6557',
          600: '#3B5145',
          700: '#2E4035',
          800: '#1F2E25',
          900: '#101D17',
        },
        clay: {
          50:  '#FAF0EB',
          100: '#EDCCBC',
          200: '#D4987C',
          300: '#C07060',
          400: '#B05545',
          500: '#A05540',
          600: '#854030',
          700: '#6A2E22',
          800: '#4E1E16',
          900: '#340F0A',
        },
      },
    },
  },
  plugins: [],
};
