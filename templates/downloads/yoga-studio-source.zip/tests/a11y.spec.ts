import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Yoga Studio — accessibility', () => {
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();

    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  test('heading hierarchy is logical', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toHaveCount(1);
  });

  test('class schedule filter buttons have aria-pressed', async ({ page }) => {
    await page.goto('/');
    const filterBtns = page.locator('.filter-btn');
    const count = await filterBtns.count();
    expect(count).toBeGreaterThan(0);
    const firstBtn = filterBtns.first();
    await expect(firstBtn).toHaveAttribute('aria-pressed', 'true');
  });

  test('class cards have accessible names', async ({ page }) => {
    await page.goto('/');
    const classCards = page.locator('.class-card');
    const count = await classCards.count();
    expect(count).toBeGreaterThanOrEqual(6);
  });
});
