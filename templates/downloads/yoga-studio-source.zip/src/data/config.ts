export const studio = {
  name:        'Sattva Yoga Studio',
  tagline:     'Find Your Stillness.',
  description: 'Mind-body yoga studio in Portland OR — Vinyasa, Hatha, Yin, Restorative, Prenatal, and Meditation classes for all levels. Begin your practice today.',
  phone:       '(503) 555-0182',
  email:       'hello@sattvayoga.com',
  address:     '2218 NE Broadway St',
  city:        'Portland',
  state:       'OR',
  zip:         '97212',
  instagram:   'https://instagram.com/sattvayogapdx',
  facebook:    'https://facebook.com/sattvayogapdx',
  youtube:     'https://youtube.com/@sattvayogapdx',
  bookUrl:     'https://app.sattvayoga.com/book',
  joinUrl:     'https://app.sattvayoga.com/join',
  headTeacher: {
    name:  'Sofia Andersen',
    title: 'Founder & Lead Teacher',
    certs: ['E-RYT-500', 'RPYT', 'Mindfulness Teacher'],
  },
  makerBio: {
    name:     'Sattva Yoga Studio',
    url:      'https://allanninal.dev',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'Sattva Yoga Studio | Yoga Classes in Portland OR — Vinyasa, Hatha, Yin & More',
  description:   'Sattva Yoga Studio offers Vinyasa, Hatha, Yin, Restorative, Prenatal and Meditation classes in Portland OR. All levels welcome. New student special: $30 for 30 days.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
