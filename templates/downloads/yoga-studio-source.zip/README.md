# Yoga Studio — Day 63 of 365

A serene, light-default yoga studio template for **Sattva Yoga Studio** in Portland, OR. Deliberately distinct from the three preceding dark-default fitness gym templates (days 60–62) — warm linen palette, dusty sage accent, and EB Garamond + Quicksand typography convey calm, clarity, and welcoming community.

**Live demo:** https://example.com/

## Features

- Six class types: Vinyasa, Hatha, Yin, Restorative, Prenatal, Meditation
- JS-filterable weekly class schedule table
- Four teacher profiles with RYT credentials
- New student special callout ($30 / 30 days)
- Three-tier class package pricing (Single / 10-Pack / Monthly Unlimited)
- Studio philosophy with three pillars
- Five student testimonials
- Eight-item FAQ accordion with `FAQPage` JSON-LD
- Formspree contact form with hours panel
- Schema.org: `SportsActivityLocation + HealthClub + LocalBusiness + Person + Service + Offer + FAQPage`

## Design

- **Palette:** Warm Linen `#F8F4EE` body · Dusty Sage `#4A6557` accent · Warm Clay `#A05540` secondary
- **Fonts:** EB Garamond (display/headings) · Quicksand (body/UI)
- **Theme:** Light-default — first light template in the fitness sprint (days 60–63)

## Quick start

```bash
npm install
npm run dev
```

## Environment variables

See `.env.example`. Key variables:

| Variable | Purpose |
|---|---|
| `PUBLIC_BASE_PATH` | URL base path (e.g. `/yoga-studio/`) |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables download bar — leave blank for clean clone |
| `PUBLIC_EDITION` | Set to `pro` for Pro edition |
| `PUBLIC_SHOP_URL` | Pro shop URL (defaults to `#`) |

## Tests

```bash
npm test               # Playwright smoke + a11y + links
npm run test:lighthouse # Lighthouse ≥ 95 all categories
```

## License

MIT — free for personal and commercial use. Attribution appreciated but not required.

Part of the [365 Templates](https://example.com) project by [Allan Niñal](#).
