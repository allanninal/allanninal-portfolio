# Day 63 — Yoga Studio: Niche Research

## Slug
`yoga-studio`

## Differentiation from Days 1–62

### Why yoga studio is distinct from Days 60–62 (the three dark fitness templates)

**Day 60 (fitness-gym-general):** General commercial gym. Palette: Carbon Black #111214 + Electric Orange #EF4900 (neutral-cool dark). Fonts: Russo One + Exo 2. Iron Peak Fitness, Austin TX.

**Day 61 (crossfit-gym):** CrossFit box. Palette: Steel Night #0E1520 (cold blue-dark) + Volt Yellow #C8F000. Fonts: Anton + Saira. CrossFit Ironclad, Denver CO.

**Day 62 (boxing-gym):** Boxing gym. Palette: Ring Mat Black #1C1108 (warm dark) + Championship Red #EF4444 + Champion Gold #C09030. Fonts: Black Ops One + Rubik. Corner Club Boxing, Philadelphia PA.

**Day 63 (yoga-studio):** The OPPOSITE vibe from days 60–62:
- Not a high-intensity gym but a mind-body wellness studio
- Light-default template (all 3 prior fitness days are dark-default)
- Class types are meditative/restorative (Vinyasa, Hatha, Yin, Restorative, Prenatal, Meditation) not athletic
- Teacher certifications are yoga-specific (RYT-200, RYT-500, E-RYT, Prenatal) not athletic (CF-L2, CSCS, USAW)
- Language: "teacher" not "coach", "practice" not "workout", "studio" not "gym/box"
- Intro offer: "New Student Special: $30/30 days" not "free intro session"
- Location: Portland OR (wellness/mindfulness culture) vs Philadelphia/Denver/Austin

### Visual register — palette taken matrix (days 1–62)

| Days | Palette family | Fonts |
|------|----------------|-------|
| 1 | Amber #FFB020 on near-black | Inter + Geist Mono |
| 2 | Violet/indigo on light | Geist/Satoshi + Inter |
| 3 | Lime #A3E635 on dark | Geist |
| 4 | Coral #FF6B4A on light | DM Sans |
| 5 | Forest green #1C4A2E on warm-white | Newsreader + Inter |
| 6 | Cobalt #2563EB on light | IBM Plex |
| 7 | Magenta #DB2777 on warm off-white | Manrope |
| 8 | Burnt orange #C2410C on warm off-white | Fraunces + Space Grotesk |
| 9 | Deep teal/jade #0D7377 on parchment | custom |
| 10 | Teal #14B8A6 on dark | Outfit + Geist Mono |
| 11 | Oxblood #881337 on cream | Lora + Work Sans |
| 12 | Aubergine #4A1942 on warm white | Fraunces + Space Grotesk |
| 13 | Midnight-navy + Amber #E8A020 on dark | Bricolage Grotesque |
| 22 | Olive-charcoal + gold #C4973A | Libre Baskerville + Mulish |
| 23 | Parchment + terracotta-rust | Fraunces + Plus Jakarta Sans |
| 25 | Sage-linen #6B8F71 + green | Raleway + Nunito |
| 27 | Navy #0D1117 + cyan #00D4FF | Space Grotesk + JetBrains Mono |
| 29 | Warm off-white + indigo #6366F1 | Inter Tight + JetBrains Mono |
| 32 | Cream + tomato red #C0392B | Playfair Display + Nunito |
| 35 | Terracotta #C45B3A + parchment | Archivo Black + Cormorant |
| 36 | Near-black + oxblood + brass | DM Serif Display + Karla |
| 37 | Buttercream + strawberry-rose | Playfair Display + Nunito |
| 38 | Champagne ivory + pistachio | Gilda Display + Jost |
| 39 | Bubblegum-pink + sky-blue | Fredoka + Nunito Sans |
| 40 | Pistachio + strawberry + vanilla | Pacifico + Source Sans 3 |
| 41 | Citrus-orange + leafy-green | Urbanist Variable + Geist |
| 42 | Slate-charcoal + copper-amber | Oswald + Work Sans |
| 43 | Deep velvet + burgundy + gold | Cinzel + Montserrat |
| 44 | Noir-black + emerald-neon | Bodoni Moda + IBM Plex Mono |
| 45 | Parchment + celadon | Cardo + Figtree |
| 46 | Sunny-yellow + coral + sky | Gabarito + Poppins |
| 48 | Midnight-navy + champagne-gold | Marcellus + Mulish |
| 49 | Aubergine + champagne-blush | Tenor Sans + Albert Sans |
| 50 | Mauve + champagne + ivory | Bellefair + Questrial |
| 51 | Near-black + oxblood + brass | Teko + Hind |
| 52 | Coral + rose-gold + plum | Italiana + Plus Jakarta Sans |
| 53 | Sage-green #3A6047 + stone + pearl | Crimson Pro + Raleway |
| 54 | Deep ocean teal #1A4A5A + sand | Libre Baskerville + Source Sans 3 |
| 55 | Ink-black + bone-white + amber #E8A020 | Bebas Neue + Barlow |
| 56 | Blush-ivory + warm-clay #C2705A + forest | DM Serif Display + DM Sans |
| 57 | Deep-plum #4A1860 + champagne-gold | Cormorant Garamond + Nunito Sans |
| 58 | Espresso-dark #1C1410 + dusty-rose | Playfair Display + DM Sans |
| 59 | Crisp white + herb-green #1F7A54 + honey | Josefin Sans + Bitter |
| 60 | **Carbon Black #111214 + Electric Orange #EF4900** | **Russo One + Exo 2** |
| 61 | **Steel Night #0E1520 + Volt Yellow #C8F000** | **Anton + Saira** |
| 62 | **Ring Mat Black #1C1108 + Championship Red #EF4444 + Gold #C09030** | **Black Ops One + Rubik** |

### Day 63 distinct visual register

**LIGHT-DEFAULT template** — the first in Sprint 3 (days 60–63 were all dark-default gym templates). Deliberately serene, warm, and airy.

**Palette: Warm Linen + Dusty Sage + Warm Clay**

- **Base background:** Warm Linen `#F8F4EE`
  — Warm off-white with slight yellow-amber undertone. Distinct from:
  - Day 4 Coral light (pinkish, vivid)
  - Day 23 parchment (slightly cooler/whiter)
  - Day 45 parchment (similar territory, but day 45 uses celadon which is teal-green, distinct)
  - Day 38 champagne ivory (cooler, more golden)
  — This is a softer, warmer, earthier linen — like natural woven fabric, appropriate for a yoga studio

- **Accent: Dusty Sage** `#4A6557`
  — Muted, earthy green with a grey undertone. Distinct from:
  - Day 5 Forest green `#1C4A2E` (darker, purer green)
  - Day 9 Deep teal/jade `#0D7377` (blue-green, much darker/more saturated)
  - Day 10 Teal `#14B8A6` (bright blue-green)
  - Day 25 Sage-linen `#6B8F71` (lighter, more yellow-green)
  - Day 53 Sage-green `#3A6047` (darker, deeper, richer)
  - Day 59 Herb-green `#1F7A54` (vivid emerald-green)
  `#4A6557` is a **dusty, muted sage** — neither forest green nor teal. It has a grey desaturation that gives it serenity. WCAG: white `#FFFFFF` on `#4A6557` = 6.06:1 ✓ AA. Dark text on linen: use dark text `#2C2420` everywhere, sage only for large/bold elements.

- **Secondary: Warm Clay** `#A05540`
  — A dusty terracotta. Distinct from:
  - Day 8 Burnt orange `#C2410C` (darker, more brown-orange)
  - Day 23 Terracotta-rust (similar family but higher saturation, different shade)
  - Day 35 Terracotta `#C45B3A` (more vivid orange-red)
  - Day 56 Warm-clay `#C2705A` (lighter, pinker)
  `#A05540` is more muted and dusty — aged pot terracotta, earthy and grounded. WCAG: `#A05540` on `#F8F4EE` linen = ~4.68:1 ✓ AA for all text when used at 14px+.

- **Surface:** `#FFFFFF` for cards/panels
- **Surface-2:** `#EEE6DA` for alternating section backgrounds
- **Text:** `#2C2420` — warm near-black (high contrast on all surfaces)
- **Text muted:** `#7A6F6A` — warm brown-gray (~4.6:1 on linen ✓ AA)
- **Border:** `#DDD4C8` — warm light border
- **Border strong:** `#C4B8A8`

**WCAG AA contrast checks:**
- `#2C2420` on `#F8F4EE`: ~14.9:1 AAA ✓
- `#2C2420` on `#FFFFFF`: ~16.8:1 AAA ✓
- `#2C2420` on `#EEE6DA`: ~14.2:1 AAA ✓
- `#FFFFFF` on `#4A6557`: ~6.06:1 AA ✓ (buttons, badges)
- `#7A6F6A` on `#F8F4EE`: ~4.6:1 AA ✓ (muted text)
- `#7A6F6A` on `#FFFFFF`: ~4.8:1 AA ✓ (muted text on cards)
- `#A05540` on `#F8F4EE`: ~4.68:1 AA ✓ (clay text, eyebrows)
- `#4A6557` on `#F8F4EE`: ~3.98:1 — meets large text threshold (18px+) but use sparingly for small text; prefer `#2C2420` for body copy
- `#FFFFFF` on `#A05540`: ~4.68:1 AA ✓ (white on clay background)

**Typography: EB Garamond + Quicksand**

- **EB Garamond** (Google Fonts — `@fontsource/eb-garamond`): Old-style humanist serif with elegant proportions. NOT used in any of days 1–62. Distinct from:
  - Playfair Display (modern high-contrast serif, days 32/37/58)
  - Cinzel (all-caps classical, day 43)
  - Cormorant Garamond (condensed high-contrast, day 57)
  - Cardo (scholarly text serif, day 45)
  - Lora (slab serif, day 11)
  - Libre Baskerville (transitional serif, days 22/54)
  - DM Serif Display (geometric serif, days 36/56)
  - Crimson Pro (text serif, day 53)
  EB Garamond has the Renaissance-era warmth of original Garamond punchcuts — open apertures, old-style figures, slightly irregular pen-drawn quality. Perfect for a yoga studio evoking ancient wisdom.

- **Quicksand** (Google Fonts — `@fontsource/quicksand`): Rounded geometric sans-serif with low x-height and soft letter forms. NOT used in any of days 1–62. Distinct from all prior sans-serifs. The gentle roundness mirrors the circular, flowing quality of yoga practice. Excellent readability at body sizes.

## Persona

**Sattva Yoga Studio** — Mind-Body Wellness Studio
- Location: 2218 NE Broadway St, Portland, OR 97212 (NE Portland — Irvington neighborhood)
- Founder & Lead Teacher: **Sofia Andersen**, E-RYT-500, Prenatal Yoga Certified (RPYT), Mindfulness Teacher
- Founded: 2016
- Name meaning: *sattva* (Sanskrit) — purity, clarity, balance, harmony. The quality of luminous awareness.
- Tagline: "Find Your Stillness."
- Tone: Warm, grounded, welcoming, non-intimidating, community-focused, spiritually curious

### Teachers (4)
1. **Sofia Andersen** — Founder & Lead Teacher. E-RYT-500, RPYT (Prenatal), Mindfulness Meditation Teacher. Teaches Vinyasa, Prenatal, and Meditation. Former architect who discovered yoga during burnout and trained with teachers in Mysore, India. 14 years of practice, 9 years of teaching.
2. **James Okoro** — Yin & Restorative Specialist. RYT-500, Yin Yoga Trained (Paulie Zink lineage). Teaches Yin and Restorative. His classes are fully booked every week — students describe them as "90 minutes of complete peace." 7 years of practice, 5 years of teaching.
3. **Maya Chen** — Hatha & Vinyasa Teacher. RYT-200, Yoga Alliance registered. Teaches Hatha and Vinyasa Flow. Known for clear alignment cues and her "accessible to all bodies" teaching philosophy. 5 years of practice, 3 years of teaching.
4. **Lena Müller** — Restorative & Therapeutic Teacher. RYT-500, C-IAYT (Certified Yoga Therapist). Teaches Restorative and Yoga Nidra. Works with students recovering from injury, managing chronic pain, or navigating life transitions. 10 years practice, 6 years teaching.

## Class Types (6)

1. **Vinyasa Flow** — All levels — 60 min. Breath-linked movement. Builds heat, strength, and flexibility through dynamic sequences. Modifications always offered.
2. **Hatha Yoga** — Beginners welcome — 75 min. Classical yoga postures held longer, with detailed alignment instruction. The foundation of all yoga styles. Excellent starting point.
3. **Yin Yoga** — All levels — 90 min. Long, passive holds (3–5 minutes) targeting connective tissue, fascia, and joints. Deeply meditative. A cooling counterbalance to active life.
4. **Restorative Yoga** — All levels — 75 min. Fully supported postures with props — bolsters, blankets, blocks. Zero effort, total release. Suitable for injury recovery.
5. **Prenatal Yoga** — Pregnant students — 60 min. Modified poses safe for all trimesters. Breathwork for labor preparation. Community with other expectant mothers.
6. **Meditation** — All levels — 45 min. Guided sitting practice. Body scan, breath awareness, loving-kindness. Suitable for absolute beginners.

## Sections

1. **Header** — sticky, light linen background, studio name, nav (Classes / Schedule / Teachers / Philosophy / Pricing / FAQ), "Book a Class" CTA
2. **Hero** — airy light section with SVG lotus/botanical decorations, headline "Find Your Stillness." + dual CTAs
3. **Stats band** — sage green background: 6+ Class Types · 4 Expert Teachers · 10+ Years Combined · Est. 2016
4. **Classes** — 6 class type cards: Vinyasa, Hatha, Yin, Restorative, Prenatal, Meditation
5. **Class Schedule** — filterable weekly table (All / Vinyasa / Hatha / Yin / Restorative / Prenatal / Meditation)
6. **Teachers** — 4 teacher cards with RYT credentials and initials avatars
7. **New Student Special** — intro offer section: $30 for 30 Days + 4-step "What to expect" cards
8. **Class Packages** — 3 pricing tiers: Single Class $22 / 10-Class Pack $180 / Monthly Unlimited $125
9. **Philosophy** — Studio story + 3 pillars (Present in the Body / All Bodies Welcome / Community Over Competition)
10. **Testimonials** — 5 student stories
11. **FAQ** — 8 questions about yoga styles, experience level, props, prenatal safety, etc.
12. **Contact** — Hours, address, phone, email, booking form
13. **CTA Band** — sage background, warm clay accent
14. **Footer** — 4-column grid

## Schema.org Types
- `SportsActivityLocation` + `LocalBusiness` + `HealthClub`
- `Person` × 4 teachers
- `Offer` × 3 pricing tiers
- `FAQPage` + `Question` + `Answer`
- `Service` (yoga instruction)

## Key differentiators from all prior templates

- **vs. fitness-gym-general (day 60):** Mind-body wellness studio not commercial gym; light palette not dark; EB Garamond + Quicksand not Russo One + Exo 2; Vinyasa/Yin not HIIT/Spin; teachers not coaches; RYT credentials not CSCS; prenatal program; meditation classes; Portland not Austin
- **vs. crossfit-gym (day 61):** Yoga not CrossFit; no WOD; serene not industrial; sage not volt yellow; no On-Ramp equivalent; community and stillness values not intensity and competition
- **vs. boxing-gym (day 62):** Yoga studio not boxing gym; light template not dark; EB Garamond + Quicksand not Black Ops One + Rubik; restorative/prenatal classes not sparring/conditioning; meditative philosophy not combat heritage; Portland OR not Philadelphia PA
- **vs. day-spa (day 53):** Active practice not passive treatment; classes/schedule not spa treatments; RYT teachers not therapists; sage #4A6557 (distinctly different from day 53's deeper #3A6047); EB Garamond + Quicksand not Crimson Pro + Raleway
- **vs. nutritionist-clinic (day 59):** Physical movement practice not clinical nutrition; studio not clinic; multiple class formats not consultation appointments; community class culture
