import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Ember & Bone/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero heading contains restaurant name', async ({ page }) => {
  await page.goto('/');
  const heading = await page.locator('#hero-heading').textContent();
  expect(heading?.toLowerCase()).toContain('ember');
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu-heading')).toBeVisible();
});

test('menu tabs exist and are interactive', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  // Click "First Course" tab
  const startersTab = page.locator('[role="tab"]', { hasText: /first course/i });
  await startersTab.click();
  expect(await startersTab.getAttribute('aria-selected')).toBe('true');

  const startersPanel = page.locator('[data-panel="starters"]');
  await expect(startersPanel).toBeVisible();
});

test('private dining section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#private-dining')).toBeVisible();
});

test('private dining heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#private-dining-heading')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('reservations section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#reservations')).toBeVisible();
});

test('hours section is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('reserve CTA button is present in header', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('header a[href*="reservations"]').first();
  await expect(cta).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  // Free edition shows the download bar; the Pro-preview demo shows the Pro bar.
  const templateInfo = page.locator(
    '[aria-label="Free template — download or fork"], [aria-label="Pro edition — live preview"]',
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('a[href="#main-content"]');
  await expect(skipLink).toBeAttached();
});

test('navigation has accessible label', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('footer nav has accessible label', async ({ page }) => {
  await page.goto('/');
  const footerNav = page.locator('nav[aria-label="Footer navigation"]');
  await expect(footerNav).toBeVisible();
});

test('restaurant name appears in page', async ({ page }) => {
  await page.goto('/');
  const content = await page.content();
  expect(content).toContain('Ember & Bone');
});
