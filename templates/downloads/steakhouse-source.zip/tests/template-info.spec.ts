import { test, expect } from '@playwright/test';

test('TemplateInfo bar renders with hub URL', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  await expect(bar).toBeVisible();
});

test('TemplateInfo shows Day 36 text', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  const text = await bar.textContent();
  expect(text).toContain('36');
});

test('TemplateInfo has download static button', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  const staticBtn = bar.locator('a', { hasText: /download static/i });
  await expect(staticBtn).toBeVisible();
  const href = await staticBtn.getAttribute('href');
  expect(href).toContain('steakhouse-static.zip');
});

test('TemplateInfo has Astro source button', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  const srcBtn = bar.locator('a', { hasText: /source.*astro/i });
  await expect(srcBtn).toBeVisible();
  const href = await srcBtn.getAttribute('href');
  expect(href).toContain('steakhouse-source.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  const all365 = bar.locator('a', { hasText: /all 365/i });
  await expect(all365).toBeVisible();
});

test('TemplateInfo has Build with me link pointing to LinkedIn', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator('[aria-label="Free template — download or fork"]');
  const hireLink = bar.locator('a', { hasText: /build with me/i });
  await expect(hireLink).toBeVisible();
  const href = await hireLink.getAttribute('href');
  expect(href).toContain('linkedin.com');
});

test('no github.com/allanninal/templates private repo links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
