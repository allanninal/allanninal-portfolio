import type { Page } from '@playwright/test';

// Single-page template — only one route
export const ROUTES = ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// Dark-only template — no theme toggle, but keep stub for a11y runner compatibility
export async function setTheme(page: Page, theme: 'light' | 'dark') {
  // Steakhouse is dark-only; light mode sets no change but avoids test errors
  await page.emulateMedia({ colorScheme: theme });
}
