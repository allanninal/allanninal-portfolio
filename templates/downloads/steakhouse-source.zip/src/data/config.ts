export const restaurant = {
  name: 'Ember & Bone',
  tagline: 'Premium aged beef. Refined craft cocktails. Unwavering hospitality.',
  shortTagline: 'An upscale chophouse in the heart of Chicago.',
  description:
    'Ember & Bone is Chicago\'s premier dry-age chophouse — a temple to American beef where every cut is hand-selected, in-house dry-aged for 28–60 days, and finished over live fire. Impeccable wine, craft cocktails, and intimate private dining rooms complete the experience.',
  address: '312 West Erie Street, Chicago, IL 60654',
  phone: '+1 (312) 555-0182',
  email: 'reservations@emberandbone.com',
  reservationUrl: '#reservations',
  instagram: 'https://instagram.com/emberandbone',
  facebook: 'https://facebook.com/emberandbone',
  estYear: '2009',
};

export const hours = [
  { day: 'Monday',    lunch: 'Closed',         dinner: 'Closed'         },
  { day: 'Tuesday',   lunch: 'Closed',         dinner: '5:00 – 10:00 PM' },
  { day: 'Wednesday', lunch: 'Closed',         dinner: '5:00 – 10:00 PM' },
  { day: 'Thursday',  lunch: 'Closed',         dinner: '5:00 – 10:30 PM' },
  { day: 'Friday',    lunch: '12:00 – 2:30 PM', dinner: '5:00 – 11:00 PM' },
  { day: 'Saturday',  lunch: '12:00 – 3:00 PM', dinner: '5:00 – 11:00 PM' },
  { day: 'Sunday',    lunch: '11:30 – 3:00 PM', dinner: '5:00 – 9:30 PM'  },
];

export type CutGrade = 'USDA Prime' | 'A5 Wagyu' | 'Dry-Aged' | 'Heritage';

export type MenuItem = {
  name: string;
  description: string;
  price: string;
  weight?: string;
  grade?: CutGrade;
  featured?: boolean;
  note?: string;
};

export type MenuCategory = {
  id: string;
  label: string;
  intro?: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: 'cuts',
    label: 'Prime Cuts',
    intro: 'Hand-selected, USDA Prime and A5 Wagyu. All steaks finished with aged compound butter and fleur de sel.',
    items: [
      {
        name: '45-Day Dry-Aged Ribeye',
        description: 'Bone-in 45-day house dry-aged USDA Prime ribeye. Intense marbling, concentrated funk, caramelized crust from the 1,800°F broiler. Served with au jus and crispy shallots.',
        price: '$72',
        weight: '22 oz',
        grade: 'Dry-Aged',
        featured: true,
      },
      {
        name: 'A5 Wagyu Strip',
        description: 'Miyazaki Prefecture A5 Japanese Wagyu New York strip. Butter-tender, richly marbled beyond reckoning. Presented tableside on a warmed Himalayan salt block.',
        price: '$145',
        weight: '8 oz',
        grade: 'A5 Wagyu',
        featured: true,
        note: 'Market availability — ask your server',
      },
      {
        name: 'USDA Prime Porterhouse',
        description: 'A showstopper for two. Aged 28 days in-house. The filet side supple and buttery; the strip side bold and mineral. Carved tableside.',
        price: '$120',
        weight: '40 oz (for two)',
        grade: 'USDA Prime',
      },
      {
        name: 'Bone-In Filet Mignon',
        description: 'USDA Prime centre-cut tenderloin, left on the bone for maximum flavour. The most tender bite in the house. Served with truffle compound butter.',
        price: '$68',
        weight: '10 oz',
        grade: 'USDA Prime',
      },
      {
        name: 'Heritage Breed Tomahawk',
        description: 'Long-bone Heritage Angus tomahawk, 60-day dry-aged. Big smoke, deep mineral notes, an extraordinary amount of steak. Perfect for sharing.',
        price: '$185',
        weight: '48 oz (for two–three)',
        grade: 'Heritage',
        note: 'Reserve 24 hours in advance',
      },
      {
        name: 'Classic NY Strip',
        description: '28-day aged USDA Prime New York strip — the quintessential steakhouse cut. Firm, beefy, with a clean mineral finish.',
        price: '$58',
        weight: '16 oz',
        grade: 'USDA Prime',
      },
    ],
  },
  {
    id: 'starters',
    label: 'First Course',
    intro: 'Begin with intention. Refined flavours that prime the palate without overshadowing what follows.',
    items: [
      {
        name: 'Bone Marrow Canoe',
        description: 'Roasted split bone marrow, herb gremolata, pickled red onion, grilled crostini. The fat of the feast.',
        price: '$22',
        featured: true,
      },
      {
        name: 'Wagyu Beef Tartare',
        description: 'Hand-chopped A5 Wagyu, Dijon, capers, shallot, egg yolk, toasted brioche soldiers. Finished with truffle oil and ossetra caviar.',
        price: '$34',
      },
      {
        name: 'Chilled Shellfish Tower',
        description: 'East Coast oysters, poached jumbo shrimp, Dungeness crab claws, scallop crudo. Mignonette, cocktail sauce, lemon.',
        price: '$68',
        note: 'Serves two',
      },
      {
        name: 'Ember-Roasted Beet Salad',
        description: 'Flame-roasted golden and red beets, whipped Maytag blue, candied walnuts, micro-frisée, aged sherry vinaigrette.',
        price: '$18',
      },
      {
        name: 'French Onion Soup',
        description: 'Caramelised sweet onion, 24-hour Prime bone broth, day-old sourdough crouton, melted Gruyère and Comté crust. A house classic since 2009.',
        price: '$16',
      },
      {
        name: 'Ember Wedge',
        description: 'Iceberg wedge, house-cured bacon lardons, heirloom tomato, Buttermilk–Roquefort dressing, chive oil.',
        price: '$17',
      },
    ],
  },
  {
    id: 'sides',
    label: 'Accompaniments',
    intro: 'Designed to complement, never to compete. Order two or three for the table.',
    items: [
      {
        name: 'Truffle & Parmesan Hand-Cut Frites',
        description: 'Double-fried kennebec fries, black truffle oil, Parmigiano-Reggiano, fresh chives. Served in a copper pail.',
        price: '$16',
        featured: true,
      },
      {
        name: 'Creamed Spinach',
        description: 'A steakhouse non-negotiable. Wilted baby spinach, heavy cream reduction, shallot, nutmeg, panko crust.',
        price: '$13',
      },
      {
        name: 'Lobster Mac & Cheese',
        description: 'Cavatappi, aged white cheddar and Gruyère mornay, butter-poached Maine lobster knuckle, truffle breadcrumb top.',
        price: '$22',
      },
      {
        name: 'Roasted Bone Marrow Mash',
        description: 'Yukon Gold potato, roasted marrow, brown butter, chive, fleur de sel. A luxury side.',
        price: '$14',
      },
      {
        name: 'Grilled Asparagus',
        description: 'Thick-stalk asparagus over live coals, hollandaise, lemon zest, shaved bottarga.',
        price: '$15',
      },
      {
        name: 'Sautéed Wild Mushrooms',
        description: 'Chanterelle, hen of the woods, porcini. Butter, garlic, fresh thyme, dry sherry reduction.',
        price: '$16',
      },
    ],
  },
  {
    id: 'wine-cocktails',
    label: 'Wine & Cocktails',
    intro: 'A 600-label wine cellar and a cocktail program built around barrel-aged spirits and house-made infusions.',
    items: [
      {
        name: 'The Ember Old Fashioned',
        description: 'Knob Creek 9yr bourbon, demerara, Angostura & mole bitters, charred orange peel, smoked lapsang sphere. Our signature — order it once.',
        price: '$22',
        featured: true,
      },
      {
        name: 'Bone Dry Martini',
        description: 'Noilly Prat vermouth rinse, Hendrick\'s Orbium gin, lemon oil, gold-leaf olive skewer.',
        price: '$20',
      },
      {
        name: 'Bordeaux — Château Léoville Barton, Saint-Julien 2016',
        description: 'Deep garnet. Cedar, blackcurrant, graphite, tobacco leaf. A structured Médoc to partner the ribeye.',
        price: '$28 / glass · $145 / bottle',
      },
      {
        name: 'Napa Cabernet — Stag\'s Leap Wine Cellars "Artemis" 2019',
        description: 'Dark fruit, cocoa, crème de cassis. Plush tannins, long finish. A California benchmark.',
        price: '$24 / glass · $118 / bottle',
      },
      {
        name: 'Burgundy — Louis Jadot Chambolle-Musigny 2018',
        description: 'Pale ruby, ethereal. Rose petal, cherry, forest floor. The elegant counterpoint to Wagyu.',
        price: '$32 / glass · $165 / bottle',
      },
      {
        name: 'Classic Martini / Manhattan',
        description: 'Made to order, your specification.',
        price: 'from $18',
      },
    ],
  },
];

export const privateDining = {
  headline: 'Private Dining & Events',
  description:
    'Ember & Bone houses three private dining rooms — from intimate ten-seat chef\'s tables to a full buyout of our 60-person vault room. Each room is available for corporate dinners, rehearsal events, and milestone celebrations.',
  rooms: [
    {
      name: 'The Vault',
      capacity: 'Up to 60 seated',
      description:
        'Our original 1920s bank vault — exposed limestone walls, arched ceilings, a dedicated bar. Exclusive buyout only.',
    },
    {
      name: 'The Library',
      capacity: 'Up to 24 seated',
      description:
        'Floor-to-ceiling mahogany shelves, fireplace, ambient candlelight. Perfect for corporate dinners and product launches.',
    },
    {
      name: 'The Chef\'s Table',
      capacity: 'Up to 10 seated',
      description:
        'Direct sight-lines into the kitchen. A behind-the-scenes experience with a dedicated kitchen liaison and custom tasting menu.',
    },
  ],
  contactEmail: 'events@emberandbone.com',
};

export const story = {
  headline: 'Forty-five days. One perfect steak.',
  body: [
    'Ember & Bone opened in 2009 with a single conviction: that the most extraordinary thing you can serve someone is a piece of beef that has been patiently, obsessively cared for. Not finished in two weeks. Not sourced from a broker. Dry-aged in-house, from cattle we know by name and ranch.',
    'Our dry-aging program runs 28-to-60-day cycles in a custom-built Himalayan salt-lined chamber on the premises. During that time, moisture evaporates, enzymes break down muscle fibre, and flavour compounds concentrate into something you can only achieve with time and discipline. No shortcuts exist.',
    'We source exclusively from four heritage Angus and Wagyu ranches — two in Nebraska, one in Colorado, one in Kagoshima Prefecture, Japan. We visit each ranch at least once a year. We know the feed, the land, and the people. That knowledge comes through in every bite.',
  ],
  dryAgingStats: [
    { label: 'Dry-Age Range',    value: '28–60 days' },
    { label: 'Salt-Wall Chambers', value: '3 in-house' },
    { label: 'Ranch Partners',   value: '4 ranches' },
    { label: 'Est.',             value: '2009' },
  ],
};

export const galleryItems = [
  { id: 'ribeye', alt: 'Perfectly seared dry-aged ribeye on a cast-iron plate with au jus', label: '45-Day Ribeye' },
  { id: 'bone-marrow', alt: 'Bone marrow canoe with gremolata and grilled crostini on a dark board', label: 'Bone Marrow' },
  { id: 'wagyu', alt: 'A5 Wagyu strip presented on a Himalayan salt block at tableside', label: 'A5 Wagyu' },
  { id: 'dining', alt: 'Interior of Ember & Bone — candlelit tables, dark leather, warm brass fixtures', label: 'The Dining Room' },
  { id: 'vault', alt: 'The vault private dining room with arched limestone ceiling', label: 'The Vault' },
  { id: 'dry-age', alt: 'Dry-aging chamber lined with Himalayan salt with cuts on hooks', label: 'Dry-Age Chamber' },
];

export const maker = {
  name: 'Ember & Bone',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  email: 'hello@emberbone.com',
  kofi: 'https://ko-fi.com/allanninal',
};

export const site = {
  title: 'Ember & Bone — Prime Steakhouse, Chicago IL',
  description:
    'Ember & Bone is Chicago\'s premier dry-age chophouse. Hand-selected USDA Prime and A5 Wagyu, in-house 28–60 day dry-aging, live-fire cooking, and refined craft cocktails. Reserve your table.',
  url: 'https://www.allanninal.dev/templates/steakhouse/',
  ogImage: '/og-image.png',
  language: 'en',
};
