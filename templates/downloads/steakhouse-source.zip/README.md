# Steakhouse — Day 36 of 365

A premium dark chophouse template for upscale steakhouses and fine dining establishments. Built with Astro + Tailwind CSS.

**Live demo:** https://templates.allanninal.dev/steakhouse/

## Design

- **Palette:** Near-black obsidian (#0F0D0B) + oxblood (#6B1B1B) + warm brass (#C49A3C) + ivory (#F5F0E8). Dark-only, cinematic, no compromises.
- **Typography:** DM Serif Display (headings) + Karla (body/UI). Elegant yet distinct from every prior food template in the series.
- **Persona:** Upscale chophouse with an in-house dry-aging program, multi-level private dining, and a serious wine list.

## Sections

1. **Hero** — Full-height dark hero with restaurant name, brass italic tagline, CTA buttons, and stat strip (dry-age range, ranch partners, wine labels).
2. **Menu** — 4-tab keyboard-navigable menu: Prime Cuts (with weight + grade badges), First Course, Accompaniments, Wine & Cocktails.
3. **Private Dining** — Three named rooms (The Vault, The Library, The Chef's Table) with capacity and description.
4. **Our Story** — Dry-aging philosophy with in-house chamber illustration, stat band, and sourcing narrative.
5. **Gallery** — 6-tile grid (2 wide + 4 standard) with descriptor captions.
6. **Reservations & Hours** — OpenTable + Resy placeholder CTAs, phone/email, full 7-day hours table (today highlighted), Google Maps link.

## Schema.org

- `Restaurant` (Chicago, $$$$, servesCuisine: Steakhouse/American/Chophouse)
- `Menu` with 4 `MenuSection` entries
- `Person` (template author)

## Quick start

```bash
npm install
npm run dev
```

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `PUBLIC_BASE_PATH` | Sub-path for subdirectory deploys | `/steakhouse/` |
| `PUBLIC_SITE_URL` | Canonical site URL | `https://templates.allanninal.dev` |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables TemplateInfo download bar + analytics (author only) | _(empty)_ |
| `PUBLIC_AUTHOR_DONATE_URL` | Ko-fi link in footer | `https://ko-fi.com/allanninal` |

## Customizing

- **Restaurant name/address/contact:** `src/data/config.ts` → `restaurant` object
- **Menu items:** `src/data/config.ts` → `menu` array
- **Private dining rooms:** `src/data/config.ts` → `privateDining`
- **Story/dry-aging stats:** `src/data/config.ts` → `story`
- **Colors:** `src/styles/global.css` CSS custom properties
- **Fonts:** Replace `@fontsource/dm-serif-display` + `@fontsource/karla` imports
- **Gallery:** Replace SVG placeholder tiles with `<img>` tags in `GallerySection.astro`

## Deploy to GitHub Pages

```bash
# In your repo: Settings → Pages → Source: GitHub Actions
# Then push — the included pages.yml handles the rest.
```

## Tests

```bash
npm test              # Playwright smoke + a11y + template-info
npm run test:a11y     # axe-core WCAG 2.1 AA
npm run test:links    # broken link check + noopener audit
npm run test:lighthouse  # Lighthouse CI (≥0.95 all categories)
```

---

MIT License · Template by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · Day 36 of 365
