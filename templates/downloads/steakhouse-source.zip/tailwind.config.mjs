/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"DM Serif Display"', 'Georgia', 'serif'],
        sans: ['"Karla"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        obsidian: {
          DEFAULT: '#0F0D0B',
          100: '#1A1714',
          200: '#252119',
          300: '#2E291F',
        },
        oxblood: {
          DEFAULT: '#6B1B1B',
          light: '#8B2424',
          dark: '#4A1212',
          muted: '#3D1010',
        },
        brass: {
          DEFAULT: '#C49A3C',
          light: '#D4B05E',
          pale: '#E8D49A',
          dark: '#9A7828',
        },
        ivory: {
          DEFAULT: '#F5F0E8',
          dark: '#EAE3D4',
          muted: '#C8BFAC',
        },
      },
    },
  },
  plugins: [],
};
