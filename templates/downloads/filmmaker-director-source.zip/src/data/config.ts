// Wren Sandoval — Duluth, MN.
//
// The roadmap line for day 103 is "bio, films, festivals, contact". Three of
// those four are the same page every independent filmmaker has. The fourth has
// a real artefact behind it that nobody publishes: the submission ledger. A
// laurel wall is literally the subset of that ledger which said yes, shown
// without the denominator.
//
// Every total the page quotes — submissions, selections, fees, budget — is
// summed from these arrays at build time. Hard-coding them is how a headline
// stops matching its own table three edits later.
//
// EVERY FESTIVAL NAMED BELOW IS INVENTED. Publishing a fabricated rejection
// record against real festivals would be defamatory rather than honest, so the
// names are fictional and the shape of the record is the true part.

export const site = {
  name:        'Wren Sandoval',
  shortName:   'Wren Sandoval',
  title:       'Wren Sandoval — Director, Duluth',
  tagline:     'Forty-one submissions. Six selections.',
  owner:       'Wren Sandoval',
  ownerRole:   'Writer and director',
  credential:  'Four shorts since 2018 · Duluth, Minnesota',
  city:        'Duluth',
  state:       'MN',
  language:    'en',
  phoneDisplay: '(218) 555-0114',
  phoneHref:   '+12185550114',
  email:       'wren@wrensandoval.example',
  streetAddress: '412 E Superior St',
  postalCode:  '55802',
  hours:       'Writing weekday mornings · reachable by email',
  bookingWindow: 'Between films. Reading commissions for the winter.',
  description:
    'A writer and director in Duluth. Every filmmaker’s site shows the laurels; ' +
    'this one shows the denominator — the complete submission ledger for one short film, ' +
    'including the entry fees and the twenty-nine festivals that said no.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The ledger',   href: '#ledger' },
  { label: 'What it was for', href: '#worth' },
  { label: 'Films',        href: '#films' },
  { label: 'What it cost',  href: '#budget' },
  { label: 'Contact',      href: '#contact' },
];

// ── The ledger ────────────────────────────────────────────────────────────
// One short film, fourteen months, every submission. `out` is one of
// yes | no | nil | out, and is rendered as a word and a glyph before it is
// rendered as a colour.

export const ledgerFilm = {
  title: 'Hollow Ice',
  runtime: '12 min',
  year: '2025',
  window: 'March 2025 – May 2026',
};

export const ledger = [
  { fest: 'North Shore Shorts',           when: 'Mar 25', fee: 35, out: 'no' },
  { fest: 'Rivermouth Film Days',         when: 'Mar 25', fee: 45, out: 'yes', note: 'World premiere. Fourteen people in the room and two of them mattered.' },
  { fest: 'Cascadia Independent',         when: 'Apr 25', fee: 60, out: 'no' },
  { fest: 'Bell Harbour Festival',        when: 'Apr 25', fee: 55, out: 'no' },
  { fest: 'Greatlakes New Voices',        when: 'Apr 25', fee: 30, out: 'yes', note: 'The screening that led to the commission. See below — it was not the laurel that did it.' },
  { fest: 'Ninth Ward Shorts',            when: 'Apr 25', fee: 40, out: 'no' },
  { fest: 'Tallgrass Motion',             when: 'May 25', fee: 25, out: 'nil' },
  { fest: 'Pinewood International',       when: 'May 25', fee: 75, out: 'no', note: 'The most expensive entry of the run and a form rejection eleven weeks later.' },
  { fest: 'Iron Range Film Week',         when: 'May 25', fee: 20, out: 'yes' },
  { fest: 'Barrow Street Shorts',         when: 'May 25', fee: 50, out: 'no' },
  { fest: 'Fen & Field Festival',         when: 'Jun 25', fee: 35, out: 'no' },
  { fest: 'Kestrel Documentary Days',     when: 'Jun 25', fee: 40, out: 'out', note: 'Withdrawn. It is not a documentary and I knew that when I paid.' },
  { fest: 'Portage Film Society',         when: 'Jun 25', fee: 15, out: 'yes' },
  { fest: 'Verdigris New Cinema',         when: 'Jun 25', fee: 65, out: 'no' },
  { fest: 'Saltmarsh Shorts',             when: 'Jul 25', fee: 30, out: 'no' },
  { fest: 'Copperline Festival',          when: 'Jul 25', fee: 45, out: 'nil' },
  { fest: 'Bright Hollow Film Fest',      when: 'Jul 25', fee: 40, out: 'no' },
  { fest: 'Ashgrove Independent',         when: 'Aug 25', fee: 55, out: 'no' },
  { fest: 'Meridian Shorts Weekend',      when: 'Aug 25', fee: 25, out: 'no' },
  { fest: 'Quarry Lake Cinema',           when: 'Aug 25', fee: 20, out: 'yes', note: 'The only programmer who wrote back with an actual note. That email is worth more than four of the selections.' },
  { fest: 'Halyard Film Festival',        when: 'Sep 25', fee: 60, out: 'no' },
  { fest: 'Junction 14 Shorts',           when: 'Sep 25', fee: 35, out: 'no' },
  { fest: 'Wildseed Screen Days',         when: 'Sep 25', fee: 30, out: 'no' },
  { fest: 'Umber Coast Festival',         when: 'Sep 25', fee: 50, out: 'nil' },
  { fest: 'Two Rivers New Work',          when: 'Oct 25', fee: 25, out: 'no' },
  { fest: 'Lanternhouse Shorts',          when: 'Oct 25', fee: 40, out: 'no' },
  { fest: 'Sable Point Film Fest',        when: 'Oct 25', fee: 45, out: 'no' },
  { fest: 'Fernwick International',       when: 'Nov 25', fee: 70, out: 'no', note: 'Submitted on the late deadline, which cost an extra $25 and changed nothing.' },
  { fest: 'Cold Harbour Screen',          when: 'Nov 25', fee: 30, out: 'no' },
  { fest: 'Bittern Bay Shorts',           when: 'Nov 25', fee: 20, out: 'no' },
  { fest: 'Marrow Street Cinema',         when: 'Dec 25', fee: 35, out: 'nil' },
  { fest: 'Hemlock Ridge Festival',       when: 'Dec 25', fee: 40, out: 'no' },
  { fest: 'Alder & Ash Film Days',        when: 'Jan 26', fee: 25, out: 'no' },
  { fest: 'Silt River Shorts',            when: 'Jan 26', fee: 30, out: 'yes', note: 'Fourteen months after the premiere. Runs are longer than anyone tells you.' },
  { fest: 'Cindergrove Independent',      when: 'Feb 26', fee: 45, out: 'no' },
  { fest: 'Wrenfield Screen Festival',    when: 'Feb 26', fee: 55, out: 'no' },
  { fest: 'Blue Hour Film Week',          when: 'Mar 26', fee: 35, out: 'out', note: 'Withdrawn. Their premiere rules would have disqualified the film and I read them too late.' },
  { fest: 'Peregrine Shorts',             when: 'Mar 26', fee: 20, out: 'no' },
  { fest: 'Longacre Cinema Days',         when: 'Apr 26', fee: 40, out: 'no' },
  { fest: 'Thistledown Festival',         when: 'Apr 26', fee: 30, out: 'no' },
  { fest: 'Estuary New Film',             when: 'May 26', fee: 25, out: 'no' },
];

export const OUTCOME = {
  yes: { label: 'Selected',  glyph: '●' },
  no:  { label: 'Declined',  glyph: '×' },
  nil: { label: 'No reply',  glyph: '–' },
  out: { label: 'Withdrawn', glyph: '↩' },
} as const;

export const ledgerNote =
  'Nobody publishes this. The laurel wall on every other site in this trade is the same list ' +
  'with thirty-five rows deleted — which is not dishonest exactly, but it does mean a first-time ' +
  'filmmaker looking at six laurels has no way to know whether that took six submissions or ' +
  'forty-one. It took forty-one. That is normal, and finding it out from a page rather than from ' +
  'fourteen months of your own money is the entire reason this table is here.';

// ── What the run was actually for ─────────────────────────────────────────

export const worth = [
  {
    head: 'One screening led to work. Not one laurel did.',
    body: 'A producer in the audience at Greatlakes commissioned a six-minute piece four months later. She had not seen the laurel, the website or the trailer — she was in the room. Everything else the run produced was for me, not for anyone hiring.',
  },
  {
    head: 'One programmer now answers email.',
    body: 'The Quarry Lake note was three paragraphs about why the second act does not work, and it was right. A relationship with somebody who will read your next film honestly is the rarest thing a submission fee can buy, and it is not what the fee is advertised as buying.',
  },
  {
    head: 'The rest was a marketing budget with no attribution.',
    body: 'Thirty-five rejections and four withdrawals cost a real amount of money and produced no measurable outcome. I would spend it again, and I want to be precise about what it did and did not do rather than imply the laurels are a career.',
  },
];

// ── Films ─────────────────────────────────────────────────────────────────

export const films = [
  {
    title: 'Hollow Ice', year: '2025', runtime: '12 min', format: 'Digital, 2.39:1',
    logline: 'A shipping-lane pilot spends her last winter learning the ice will not hold.',
    body: 'Shot over nine days on Superior in January and February. The ledger above is this film. The second act still does not work and I am no longer going to re-cut it.',
    img: 'still-01.jpg',
    alt: 'A frozen lake in black and white: a dark timber crib sitting out on the ice near the shore, under a wide flat horizon and streaked cloud',
    cap: 'Hollow Ice · exterior, day 4',
    where: 'Rivermouth, Greatlakes New Voices, Iron Range, Portage, Quarry Lake, Silt River',
  },
  {
    title: 'The Long Way Round', year: '2023', runtime: '9 min', format: 'Digital, 1.85:1',
    logline: 'Two brothers drive a body four hundred miles because neither will say why.',
    body: 'Made for $1,900, most of it fuel. Nine festivals, two selections, and the first thing I made that somebody outside my own circle asked to programme.',
    where: 'Rivermouth, Bittern Bay',
  },
  {
    title: 'Understory', year: '2021', runtime: '14 min', format: '16mm, 4:3',
    logline: 'A forestry survey crew disagrees about what they found.',
    body: 'The only thing I have shot on film. It cost four times what it should have and taught me more than the three digital shorts combined, which is an argument for doing it once and not twice.',
    img: 'still-02.jpg',
    alt: 'A dense conifer treeline with fog rolling down over the tops, the furthest trees dissolving into pale mist',
    cap: 'Understory · 16mm, reel 3',
    where: 'Tallgrass, Fen & Field, Copperline',
  },
  {
    title: 'Nightwatch, Berth 4', year: '2018', runtime: '7 min', format: 'Digital, 16:9',
    logline: 'A dock guard talks to nobody for seven minutes.',
    body: 'First film. Two people, one location, no money, and it is on this page because pretending you started somewhere better than you did is not useful to anybody reading.',
    where: 'North Shore Shorts',
  },
];

// ── Budget ────────────────────────────────────────────────────────────────

export const budget = {
  film: 'Hollow Ice',
  rows: [
    { line: 'Crew — six people, nine days',   amt: 3600, why: 'Day rates, below scale, agreed in advance and paid on time. This is the line I will not cut.' },
    { line: 'Camera and lighting hire',        amt: 1450, why: 'Two weeks including prep and a weather contingency day we ended up using.' },
    { line: 'Food and transport',              amt: 780,  why: 'Nine days of feeding six people in January. Consistently underestimated by every first-time budget I have seen, including my first three.' },
    { line: 'Post — sound and colour',         amt: 1200, why: 'Two specialists, both worth it. The cheapest way to make everything else you paid for look like what you paid for.' },
    { line: 'Insurance and permits',           amt: 340,  why: 'Not optional, and the reason a location said yes.' },
    { line: 'Festival entry fees',             amt: 1590, why: 'The line almost every "how I made my short" post omits, and the reason the two totals under this list are different numbers.' },
  ],
  note:
    'Funded by two years of commercial directing work, a $2,000 regional arts grant, and no ' +
    'crowdfunding. I mention the last one because a budget page that quietly leaves out where the ' +
    'money came from is as incomplete as one that leaves out the fees.',
};

export const said = {
  text: 'The second act does not work — you cut away from her three times in ninety seconds and every one of them is you flinching. Everything either side of it is confident. Send me the next one.',
  who: 'Programmer’s note, Quarry Lake Cinema, August 2025 — quoted with permission',
};

export const rates = {
  rows: [
    { what: 'Commissioned short, 3–8 min',  figure: 'From $9,500', note: 'Writing, directing and delivery. Crew and kit are quoted separately and shown to you as a real budget, not folded into one number.' },
    { what: 'Directing only, your script',  figure: '$1,100/day',  note: 'Plus prep. I will tell you in the first call if I think somebody else is a better fit for the material.' },
    { what: 'Development — script reads',   figure: '$350',        note: 'A written response inside a week. Frequently the cheapest useful thing I do for anybody.' },
    { what: 'Grant and pitch material',     figure: '$600',        note: 'Treatment, lookbook and budget in the format a regional arts council actually asks for.' },
  ],
};

export const faqs = [
  {
    q: 'Why publish the rejections?',
    a: 'Because the alternative is a laurel wall, which is the same list with thirty-five rows deleted. Somebody making their first short and looking at six laurels has no way to know whether that took six submissions or forty-one. It took forty-one. Knowing that from a page is cheaper than finding it out from fourteen months of your own money.',
  },
  {
    q: 'Does a festival run get you work?',
    a: 'Once, in my case, and it was a person in a room rather than a laurel on a website. I would still do it, but I would not describe it as a business development strategy, and I would be suspicious of anyone who does.',
  },
  {
    q: 'Are those real festival names?',
    a: 'No. The shape of the record is real; the names are invented. Publishing a rejection record against named real festivals would be a different and much less defensible kind of honesty.',
  },
  {
    q: 'How do you choose where to submit?',
    a: 'Tiers, waivers and premiere status, in that order — and getting the third one wrong is what the two withdrawals in the ledger are. There is a longer method than fits in an answer here.',
  },
  {
    q: 'Will you read my script?',
    a: 'Yes, as a paid read, and you will get a written response inside a week rather than a coffee that never gets scheduled. If it is not for me I will say so in the first paragraph rather than the last.',
  },
  {
    q: 'Do you take commercial work?',
    a: 'Yes, and it paid for two of the four films on this page. I do not treat it as the thing I do while waiting to make films; it is how the films get made, which is a more honest framing than most directors offer.',
  },
];
