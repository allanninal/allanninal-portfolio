import { test, expect } from '@playwright/test';

const OUTCOMES = ['Selected', 'Declined', 'No reply', 'Withdrawn'];

test.describe('Wren Sandoval — smoke tests', () => {
  test('homepage renders with the director name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Wren Sandoval/);
    await expect(page.locator('h1')).toContainText(/\d+ submissions\. \d+ selections\./);
  });

  test('is marked up as a Person, not a business', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q2526255');
    // A person has no opening hours or price range, and pretending otherwise
    // is how the last three templates' schema got copied forward unread.
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // ── The ledger ──────────────────────────────────────────────────────────
  test('the headline totals are summed from the ledger, not typed', async ({ page }) => {
    await page.goto('/');
    const marks = (await page.locator('#ledger .led-out').allTextContents()).map((s) => s.trim());
    expect(marks.length).toBeGreaterThan(30);
    const yes = marks.filter((m) => m.endsWith('Selected')).length;
    await expect(page.locator('h1')).toContainText(`${marks.length} submissions. ${yes} selections.`);

    const tally = page.locator('#ledger .tally dd');
    await expect(tally.nth(0)).toHaveText(String(marks.length));
    await expect(tally.nth(1)).toHaveText(String(yes));
  });

  test('the fee total is summed from the ledger', async ({ page }) => {
    await page.goto('/');
    const fees = (await page.locator('#ledger .led-fee').allTextContents())
      .map((t) => Number(t.replace('$', '')));
    const total = fees.reduce((a, b) => a + b, 0);
    await expect(page.locator('#ledger .tally dd').nth(3))
      .toHaveText(`$${total.toLocaleString('en-US')}`);
  });

  // The page is entirely made of outcomes, so an outcome must never be only a colour.
  test('every outcome is a word and a glyph before it is a colour', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#ledger .led-out');
    for (const r of await rows.all()) {
      const txt = ((await r.textContent()) || '').trim();
      expect(OUTCOMES.some((o) => txt.endsWith(o))).toBe(true);
      expect(await r.getAttribute('data-glyph')).toBeTruthy();
    }
    // and the three outcome colours are distinct from the accent
    const colours = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--outcome-yes', '--outcome-no', '--outcome-nil', '--color-accent']
        .map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(colours).size).toBe(4);
  });

  test('the ledger has more declines than selections and says so', async ({ page }) => {
    await page.goto('/');
    const marks = (await page.locator('#ledger .led-out').allTextContents()).map((s) => s.trim());
    const yes = marks.filter((m) => m.endsWith('Selected')).length;
    const no  = marks.filter((m) => m.endsWith('Declined')).length;
    expect(no).toBeGreaterThan(yes * 3);
    await expect(page.locator('#ledger')).toContainText(/laurel wall/i);
  });

  // ── Films ───────────────────────────────────────────────────────────────
  test('films are disclosures and only some carry a still', async ({ page }) => {
    await page.goto('/');
    const films = page.locator('#films details.film');
    expect(await films.count()).toBe(4);
    const stills = page.locator('#films details.film figure img');
    const n = await stills.count();
    expect(n).toBeGreaterThan(0);
    expect(n).toBeLessThan(4);
    for (const s of await stills.all()) {
      expect(((await s.getAttribute('alt')) || '').length).toBeGreaterThan(30);
    }
    // the page explains the gap rather than leaving it to be noticed
    await expect(page.locator('#films')).toContainText(`${n} of the 4 have a frame here`);
  });

  test('all images load', async ({ page }) => {
    await page.goto('/');
    for (const d of await page.locator('#films details.film').all()) {
      await d.locator('summary').click();
    }
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  // ── Budget ──────────────────────────────────────────────────────────────
  test('both budget totals are summed and the fee line is inside one of them', async ({ page }) => {
    await page.goto('/');
    const amts = (await page.locator('#budget .budget dd.amt').allTextContents())
      .map((t) => Number(t.replace(/[$,]/g, '')));
    const total = amts.reduce((a, b) => a + b, 0);
    const fees = (await page.locator('#ledger .led-fee').allTextContents())
      .map((t) => Number(t.replace('$', ''))).reduce((a, b) => a + b, 0);
    expect(amts).toContain(fees);
    const h2 = page.locator('#budget h2');
    await expect(h2).toContainText(`$${(total - fees).toLocaleString('en-US')} to make`);
    await expect(h2).toContainText(`$${total.toLocaleString('en-US')} to make and run`);
  });

  // ── Honesty ─────────────────────────────────────────────────────────────
  test('the page says the festival names are invented', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#faq')).toContainText(/names are invented/i);
    await expect(page.locator('footer')).toContainText(/invented/i);
  });

  test('it prints its own bad review', async ({ page }) => {
    await page.goto('/');
    const q = page.locator('blockquote.said');
    await expect(q).toContainText(/does not work/i);
    await expect(q.locator('cite')).toHaveCount(1);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the contact form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-102 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['fenn motion', 'knoxville', 'deliverable', 'reframe', 'q1762059', 'bricolage']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro submission strategy is absent from the free build', async ({ page }) => {
    const res = await page.goto('/submission-strategy/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
