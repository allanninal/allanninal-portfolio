# Day 24 — Non-Profit Template Research

## Niche
A modern NGO / 501(c)(3) non-profit landing page that converts strangers into donors or volunteers within 30 seconds. Persona: **Mangrove Coast Foundation** — an environmental conservation org protecting Philippine coastlines.

## Visual Differentiation from Days 1–23

### Palettes already taken (summary)
- Day 1: dark zinc + teal (dark-default)
- Day 2: light white + violet/indigo
- Day 3: dark near-black + lime
- Day 4: warm off-white + terracotta/coral
- Day 5: warm white + forest green `#1C4A2E`
- Day 6: near-white + cobalt blue `#2563EB`
- Day 7: soft warm white + magenta/pink
- Day 8: warm off-white + burnt orange `#C2410C`
- Day 9: white + slate-700 muted
- Day 10: GitHub dark `#0D1117` + teal `#14B8A6`
- Day 11: cream `#FAF7F2` + oxblood `#881337`
- Day 12: warm white `#FDFAF6` + aubergine `#4A1942`
- Day 13: near-black + amber `#F59E0B`
- Day 14: warm paper + electric blue
- Day 15: warm white + terracotta (designer)
- Day 16: pure white + slate-indigo
- Day 17: ivory + Prussian blue
- Day 18: warm cream + deep teal `#0D7377`
- Day 19: warm dark near-black + burgundy `#C0392B`
- Day 20: near-black + emerald green
- Day 21: blush/ivory + dusty rose
- Day 22: dark olive-charcoal + olive-gold
- Day 23: parchment + terracotta-rust

### Day 24 — chosen palette
**Civic Navy + Cool White** — institutional, trustworthy, authoritative.

```
--color-bg:         #F4F7FB   /* cool off-white, barely blue-tinted */
--color-surface:    #FFFFFF   /* card / section surfaces */
--color-navy:       #1E3A5F   /* primary accent — deep civic navy */
--color-navy-700:   #2A5080   /* hover states */
--color-navy-100:   #D4E3F5   /* light tints for bands */
--color-gold:       #D4931A   /* secondary accent — warmth + trust signal */
--color-text:       #1A2433   /* near-black body text */
--color-muted:      #5A6B7E   /* secondary text */
--color-border:     #C8D7E8   /* subtle dividers */
```

**Why untaken:** Deep civic navy `#1E3A5F` on cool off-white is the institutional register used by Johns Hopkins, UNICEF, Charity:Water's reports. It reads instantly as "trustworthy organization." No prior template uses this cool navy + secondary gold combination. Day 6 used cobalt `#2563EB` (brighter, more saturated, tech-register) on near-white (not cool blue-white). Day 17's Prussian blue was dark-on-ivory (completely different register). Day 18's teal is green-family. This is the first true "institutional blue" in the roadmap.

### Typography — chosen pair
- **Display headings:** **Newsreader** — BUT this was Day 5. Cross-checking: Day 5 used Newsreader for body reading. We are using **Source Serif 4** for display (Day 9 used Source Serif 4 too). Next candidate: **Spectral** (Day 18 used Spectral). Try **Libre Baskerville** — Day 22 (restaurant) used Libre Baskerville as display. 

**Final choice: Inter + IBM Plex Serif**
- Body / UI: **Inter** (already in repo stack — acceptable for body in combination with new display)
- Display headings: **IBM Plex Serif** (Google Fonts, `@fontsource/ibm-plex-serif`) — IBM's companion slab-serif. High-contrast, authoritative at large display sizes. Completely untaken in all 23 prior days. IBM Plex Sans was used (Day 6 documentation) but IBM Plex Serif is a different face — the serif variant with distinct ink traps and slab characteristics. Reads as "annual report" and "institutional publication" — exactly the register for a non-profit.

**Differentiation table:**
| Aspect | Day 24 (non-profit) | Nearest prior |
|--------|--------------------|----|
| Display font | IBM Plex Serif | IBM Plex Sans (Day 6) — different face |
| Body font | Inter | Used elsewhere but never as body alongside IBM Plex Serif |
| Palette | Civic navy `#1E3A5F` + cool white | Cobalt `#2563EB` (Day 6, brighter, tech) |
| Background | Cool off-white `#F4F7FB` | Day 6: near-white (warmer), Day 17: ivory |
| Schema | NGO + DonateAction | Unique |
| Primary CTA | Donate / Volunteer | Unique dual-CTA structure |

## Org persona
**Mangrove Coast Foundation**
- Legal name: Mangrove Coast Foundation, Inc.
- Mission: Restoring Philippine coastal ecosystems through mangrove reforestation, marine protected area advocacy, and coastal community livelihood programs.
- 501(c)(3) EIN placeholder: 47-8823190
- Charity Navigator: 4-star (placeholder URL)
- GuideStar: Gold Seal of Transparency (placeholder URL)
- Founded: 2012
- HQ: Cebu City, Philippines / US registered 501(c)(3)
- Impact: 2.3M mangrove seedlings planted, $4.8M raised, 38 coastal communities served, 14 countries with partner orgs

## Sections (in order)
1. **Nav** — Logo + nav links + sticky "Donate" button (navy filled)
2. **Hero** — Full-screen with mission statement, "Donate Now" primary CTA, "Volunteer" secondary CTA, subtle wave SVG at bottom
3. **Impact stats band** — 4 counters: seedlings planted, funds raised, communities served, years protecting coastlines
4. **Mission / what we do** — 2-paragraph prose
5. **Programs** — 3 focus areas with icons: Reforestation, Marine Protected Areas, Community Livelihoods
6. **Stories** — 3 beneficiary mini-cards with image placeholder + quote
7. **Donate section** — Amount presets ($25/$50/$100/custom), monthly/one-time toggle, "where your money goes" breakdown bar
8. **Volunteer form** — Name + email + interest dropdown, Formspree-placeholder action
9. **Board / team** — 4 board members with portrait + role + 1-line bio
10. **Financial transparency** — Annual report link, registry numbers, charity ratings
11. **Press / partners** — Logo strip
12. **FAQ** — 5 questions
13. **Footer** — Registry numbers, tax-deductible note, social links, copyright

## Schema.org
- Primary: `NGO` (subtype of `Organization`)
- `legalName`, `taxID`, `nonprofitStatus: 'Nonprofit501c3'`, `foundingDate`, `award`
- `sameAs`: Charity Navigator placeholder, GuideStar placeholder
- `potentialAction`: `DonateAction` pointing to Ko-fi URL
- Optional: `Person` for board members, `BreadcrumbList`

## Key design decisions
- No Tailwind opacity modifiers on colored backgrounds — use explicit hex
- Navy text on white: `#1E3A5F` on `#FFFFFF` = 8.4:1 (AAA)
- Navy bg with white text: `#FFFFFF` on `#1E3A5F` = 8.4:1 (AAA)
- Gold `#D4931A` on white — CHECK: 3.4:1 (fails AA for small text) — use only for icons/decorative, never for body text under 18px. Use `#A06D10` (dark gold) for any interactive text on light backgrounds — 5.1:1 (AA).
- Sticky nav donate button: navy bg + white text (8.4:1 — AAA)
- Section alternation: cool white `#F4F7FB` / pure white `#FFFFFF`
- Wave SVG divider between hero and stats band

## Fonts to install
- `@fontsource/ibm-plex-serif` — display headings (IBM Plex Serif, 400 + 600 + 700)
- `@fontsource/inter` — body / UI (400 + 500 + 600)

## Donate placeholder
Ko-fi: `https://ko-fi.com/allanninal`
Code comment: "Replace with your actual donation processor (Stripe Checkout, Donorbox, GiveButter)"
