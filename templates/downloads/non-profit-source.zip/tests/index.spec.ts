import { test, expect } from '@playwright/test';

test.describe('Non-Profit template — home page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  // Nav
  test('sticky nav renders with donate button', async ({ page }) => {
    const nav = page.getByRole('navigation', { name: /Main navigation/i });
    await expect(nav).toBeVisible();
    const donateBtn = page.locator('#nav-donate-btn');
    await expect(donateBtn).toBeVisible();
    await expect(donateBtn).toHaveAttribute('href', /ko-fi\.com/);
  });

  // Hero
  test('hero section renders mission and CTAs', async ({ page }) => {
    const hero = page.locator('#hero');
    await expect(hero).toBeVisible();
    // Heading — scoped to hero to avoid strict-mode collision
    const heading = hero.getByRole('heading', { level: 1 });
    await expect(heading).toContainText('Mangrove');
    // Primary donate CTA
    const donateBtn = page.locator('#hero-donate-btn');
    await expect(donateBtn).toBeVisible();
    await expect(donateBtn).toHaveAttribute('href', /ko-fi\.com/);
    // Volunteer link
    const volunteerLink = hero.getByRole('link', { name: /Volunteer/i });
    await expect(volunteerLink).toBeVisible();
  });

  // Impact stats
  test('impact stats section renders 4 counters', async ({ page }) => {
    const section = page.locator('#impact');
    await expect(section).toBeVisible();
    const heading = section.getByRole('heading', { level: 2 });
    await expect(heading).toBeVisible();
    // 4 stat cards
    const cards = section.locator('.grid > div');
    await expect(cards).toHaveCount(4);
  });

  // Mission + Programs
  test('mission section renders 3 program cards', async ({ page }) => {
    const section = page.locator('#mission');
    await expect(section).toBeVisible();
    const programs = section.locator('article');
    await expect(programs).toHaveCount(3);
  });

  // Stories
  test('stories section renders 3 beneficiary cards', async ({ page }) => {
    const section = page.locator('#stories');
    await expect(section).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(3);
  });

  // Donate section
  test('donate section renders amount presets and donate button', async ({ page }) => {
    const section = page.locator('#donate');
    await expect(section).toBeVisible();
    const heading = section.getByRole('heading', { level: 2 });
    await expect(heading).toBeVisible();
    // Amount preset buttons
    const presets = section.locator('.amount-btn');
    await expect(presets).toHaveCount(4);
    // Donate button
    const donateBtn = page.locator('#donate-section-btn');
    await expect(donateBtn).toBeVisible();
    await expect(donateBtn).toHaveAttribute('href', /ko-fi\.com/);
  });

  // Volunteer form
  test('volunteer form has required fields and submit button', async ({ page }) => {
    const form = page.locator('#volunteer form');
    await expect(form).toBeVisible();
    await expect(page.locator('#volunteer-name')).toBeVisible();
    await expect(page.locator('#volunteer-email')).toBeVisible();
    await expect(page.locator('#volunteer-interest')).toBeVisible();
    const submitBtn = form.getByRole('button', { name: /Submit/i });
    await expect(submitBtn).toBeVisible();
  });

  // Board
  test('board section renders 4 member cards', async ({ page }) => {
    const section = page.locator('#board');
    await expect(section).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(4);
  });

  // FAQ accordion
  test('FAQ section renders and accordion works', async ({ page }) => {
    const section = page.locator('#faq');
    await expect(section).toBeVisible();
    // First FAQ item
    const firstBtn = page.locator('#faq-btn-0');
    await expect(firstBtn).toBeVisible();
    // Answer hidden initially
    const firstAnswer = page.locator('#faq-answer-0');
    await expect(firstAnswer).toBeHidden();
    // Click to open
    await firstBtn.click();
    await expect(firstAnswer).toBeVisible();
  });

  // Footer
  test('footer renders with org name and registry info', async ({ page }) => {
    const footer = page.getByRole('contentinfo');
    await expect(footer).toBeVisible();
    await expect(footer).toContainText('Mangrove Coast Foundation');
    await expect(footer).toContainText('47-8823190');
    await expect(footer).toContainText('501(c)(3)');
  });

  // No github.com links in src
  test('no github.com/allanninal/templates links anywhere on page', async ({ page }) => {
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) =>
      h.includes('github.com/allanninal/templates')
    );
    expect(deepLinks).toEqual([]);
  });
});
