/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,mdx}'],
  theme: {
    extend: {
      colors: {
        // Cool off-white background — institutional, clean
        frost: {
          50:  '#F8FAFD',
          100: '#F4F7FB',
          200: '#E8EFF8',
          300: '#D4E3F5',
          400: '#AECCE8',
        },
        // Civic navy — primary accent (trustworthy, institutional)
        navy: {
          900: '#0F2236',
          800: '#1E3A5F',
          700: '#2A5080',
          600: '#3668A0',
          500: '#4A7FBD',
          400: '#7AAAD4',
          100: '#D4E3F5',
          50:  '#EBF2FA',
        },
        // Warm gold — secondary accent (warmth, trust signal)
        gold: {
          700: '#8B5A0A',
          600: '#A06D10',
          500: '#C48A18',
          400: '#D4931A',
          300: '#E8B040',
          200: '#F5D48A',
          100: '#FDF0C8',
        },
        // Ink — text
        ink: {
          900: '#1A2433',
          800: '#253141',
          700: '#334255',
          600: '#4A5A6E',
          500: '#5A6B7E',
          400: '#7A8D9E',
          300: '#9AAAB8',
          200: '#C8D7E8',
          100: '#E8EFF8',
          50:  '#F4F7FB',
        },
      },
      fontFamily: {
        display: ['IBM Plex Serif', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
