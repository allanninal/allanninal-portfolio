export const org = {
  name: 'Mangrove Coast Foundation',
  legalName: 'Mangrove Coast Foundation, Inc.',
  tagline: 'Restoring Philippine Coastlines, One Mangrove at a Time',
  mission:
    'We protect and restore Philippine coastal ecosystems through science-led mangrove reforestation, marine protected area advocacy, and sustainable livelihood programs for coastal communities.',
  missionLong: `The Philippines has lost over 70% of its original mangrove forests since the 1960s to aquaculture, urban expansion, and unsustainable fishing. Mangroves are not just trees — they are biodiversity hotspots, storm buffers, carbon sinks, and the primary nursery for coastal fisheries that 1.5 million Filipino families depend on.

Mangrove Coast Foundation was established in 2012 to reverse that decline. We work directly with coastal communities, local government units, and international conservation partners to plant, protect, and monitor mangroves — and to ensure the people who live alongside them have the knowledge and livelihoods to be their long-term stewards.`,
  founded: '2012',
  ein: '47-8823190',
  status: '501(c)(3) Public Charity',
  email: 'info@mangrovecoast.org',
  phone: '+1 (415) 555-0174',
  address: {
    street: '1 Conservancy Plaza, Suite 300',
    city: 'San Francisco',
    state: 'CA',
    zip: '94105',
    country: 'US',
  },
  kofi: '#',
  charityNavigator: 'https://www.charitynavigator.org/ein/478823190',
  guidestar: 'https://www.guidestar.org/profile/47-8823190',
  linkedin: '#',
  instagram: 'https://instagram.com/mangrovecoast',
  twitter: 'https://twitter.com/mangrovecoast',
};

export const stats = [
  { number: '2.3M+', label: 'Mangrove Seedlings Planted', icon: 'tree' },
  { number: '$4.8M', label: 'Raised for Conservation', icon: 'dollar' },
  { number: '38', label: 'Coastal Communities Served', icon: 'community' },
  { number: '12', label: 'Years Protecting Coastlines', icon: 'years' },
];

export const programs = [
  {
    id: 'reforestation',
    title: 'Mangrove Reforestation',
    icon: 'leaf',
    description:
      'Direct-planting programs with community nurseries in Bohol, Palawan, and Samar. Each seedling is GPS-tagged and monitored for 3 years. Survival rate: 87%.',
  },
  {
    id: 'mpa',
    title: 'Marine Protected Areas',
    icon: 'shield',
    description:
      'We advocate for and co-manage 14 marine protected areas with local government units, protecting over 8,400 hectares of coastal habitat from destructive fishing.',
  },
  {
    id: 'livelihoods',
    title: 'Community Livelihoods',
    icon: 'hands',
    description:
      'Aquasilviculture, eco-tourism, and sustainable crab-fattening programs that give coastal families economic alternatives to destructive practices.',
  },
];

export const stories = [
  {
    name: 'Lita Reyes',
    location: 'Bohol, Philippines',
    quote:
      "Before the mangroves came back, we had to go further and further out to sea just to catch enough fish for the week. Now my husband's catch is double, and our children can swim safely near the shore again.",
    role: 'Fisher and community nursery manager',
    initials: 'LR',
    color: '#1E3A5F',
  },
  {
    name: 'Eduardo Santos',
    location: 'Samar, Philippines',
    quote:
      "Typhoon Odette hit us hard, but the communities with restored mangrove belts lost far fewer homes. The trees are a living sea wall. I've seen it with my own eyes.",
    role: 'Barangay Captain, Eastern Samar',
    initials: 'ES',
    color: '#2A5080',
  },
  {
    name: 'Maria Clara Lim',
    location: 'Palawan, Philippines',
    quote:
      'I started as a volunteer planter eight years ago. Now I run our MPA monitoring program and train the next generation. This foundation gave me a career and gave my village a future.',
    role: 'Marine biologist and MPA co-manager',
    initials: 'ML',
    color: '#A06D10',
  },
];

export const board = [
  {
    name: 'Dr. Sofia Alcantara',
    avatar: 'sofia-alcantara',
    role: 'Board Chair',
    bio: 'Marine ecologist, UP Visayas. 20 years of mangrove research.',
    initials: 'SA',
    color: '#1E3A5F',
  },
  {
    name: 'James Park',
    avatar: 'james-park',
    role: 'Treasurer',
    bio: 'CFO at Pacific Conservation Partners. CPA with 15 years in nonprofit finance.',
    initials: 'JP',
    color: '#2A5080',
  },
  {
    name: 'Atty. Grace Villanueva',
    avatar: 'grace-villanueva',
    role: 'Legal Counsel',
    bio: 'Environmental law specialist, Ateneo Law School. Advocates for MPA legislation.',
    initials: 'GV',
    color: '#A06D10',
  },
  {
    name: 'Rafael Mendez',
    avatar: 'rafael-mendez',
    role: 'Programs Director',
    bio: 'Former DENR official. Led national mangrove inventory program 2015–2020.',
    initials: 'RM',
    color: '#334255',
  },
];

export const faqs = [
  {
    q: 'Is my donation tax-deductible?',
    a: 'Yes. Mangrove Coast Foundation is registered as a 501(c)(3) public charity in the United States (EIN 47-8823190). Donations from US taxpayers are fully tax-deductible to the extent permitted by law. You will receive a donation receipt by email.',
  },
  {
    q: 'How is my donation used?',
    a: '82 cents of every dollar go directly to programs — reforestation, MPA management, and livelihoods. 10% covers fundraising costs, and 8% covers administration. We publish audited financials every June. You can download the latest annual report below.',
  },
  {
    q: "Can I volunteer if I'm not based in the Philippines?",
    a: 'Absolutely. Remote volunteers help with grant writing, data analysis, translation, and social media. On-the-ground volunteer trips to our planting sites run twice a year (April and October). Fill out the volunteer form above to register your interest.',
  },
  {
    q: 'What is a monthly donation compared to a one-time gift?',
    a: 'Monthly giving is our highest-impact program. It lets us plan ahead, commit to multi-year community partnerships, and reduce administrative overhead. A monthly gift of $25 plants ~100 seedlings per year. You can cancel anytime.',
  },
  {
    q: 'How do I know my money is making a real difference?',
    a: 'Every project is GPS-logged and photographed. Monthly donors receive a quarterly impact report with survival rates, hectares protected, and community livelihoods supported. We post annual audited financial statements and hold our Charity Navigator 4-star rating.',
  },
];

export const moneyBreakdown = [
  { label: 'Direct Programs', pct: 82, color: '#1E3A5F' },
  { label: 'Fundraising', pct: 10, color: '#4A7FBD' },
  { label: 'Administration', pct: 8, color: '#AECCE8' },
];

export const partners = [
  { name: 'DENR Philippines', abbr: 'DENR' },
  { name: 'IUCN', abbr: 'IUCN' },
  { name: 'The Nature Conservancy', abbr: 'TNC' },
  { name: 'WWF Philippines', abbr: 'WWF' },
  { name: 'UN Environment', abbr: 'UNEP' },
  { name: 'Blue Carbon Initiative', abbr: 'BCI' },
];
