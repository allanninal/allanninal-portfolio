// A real feed, hand-built rather than pulled in as a dependency.
//
// RSS is not legacy in this niche: for a comic that posts a chapter every few
// months it is the only subscribe surface that does not depend on an algorithm
// deciding the reader should see it, and it is what the "updates weekly" line
// on most comic sites is standing in for. Fourteen lines of XML is cheaper than
// a plugin and cannot drift from the archive, because it reads the same list.
import type { APIRoute } from 'astro';
import { site, chapters } from '~/data/config';

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** RFC 822, which is what RSS wants — and built from the ISO date at noon UTC
 *  so no reader's timezone can shift a chapter onto the previous day. */
const rfc822 = (iso: string) => new Date(`${iso}T12:00:00Z`).toUTCString();

export const GET: APIRoute = (context) => {
  const origin = context.site ?? new URL('https://example.com');
  const base = import.meta.env.BASE_URL;
  const home = new URL(base, origin).toString();

  const items = [...chapters].reverse().map((c) => {
    const url = new URL(`${base}chapters/${c.id}/`, origin).toString();
    const label = c.n === null ? c.title : `Chapter ${c.n} — ${c.title}`;
    const note = c.note ? ` Content note: ${c.note}` : '';
    const desc = `${c.blurb} ${c.pages} pages, reading ${c.rtl ? 'right to left' : 'left to right'}.${note}`;
    return `    <item>
      <title>${esc(label)}</title>
      <link>${esc(url)}</link>
      <guid isPermaLink="true">${esc(url)}</guid>
      <pubDate>${rfc822(c.posted)}</pubDate>
      <description>${esc(desc)}</description>
    </item>`;
  });

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>${esc(site.name)}</title>
    <link>${esc(home)}</link>
    <description>${esc(site.premise)}</description>
    <language>${site.language}</language>
${items.join('\n')}
  </channel>
</rss>
`;

  return new Response(xml, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};
