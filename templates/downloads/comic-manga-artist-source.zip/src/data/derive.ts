// Everything the page counts, counted in one place.
//
// A comic archive whose masthead says "490 pages" above a table that adds up to
// 431 is the commonest defect in this niche, and it is a data-modelling problem
// rather than a proofreading one: the total was typed. Nothing here is typed.
import type { Chapter } from '~/data/config';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** ISO date → "6 Sep 2022". Parsed by hand rather than through Date, because
 *  `new Date('2022-09-06')` is UTC midnight and prints as the 5th anywhere west
 *  of Greenwich — which is where this comic is set. */
export function fmtDate(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

export function stats(list: Chapter[]) {
  return {
    chapters: list.length,
    pages: list.reduce((n, c) => n + c.pages, 0),
    spreadChapters: list.filter((c) => c.spreads.length > 0).length,
    spreads: list.reduce((n, c) => n + c.spreads.length, 0),
  };
}

export type YearRow = { year: string; chapters: number; pages: number; longestGapWeeks: number };

/** Chapters and pages posted per calendar year, plus the longest gap that ENDED
 *  in that year. A gap belongs to the year the reader was waiting in, which is
 *  the year of the chapter that ended the wait. */
export function byYear(list: Chapter[]): YearRow[] {
  const sorted = [...list].sort((a, b) => a.posted.localeCompare(b.posted));
  const rows = new Map<string, YearRow>();
  sorted.forEach((c, i) => {
    const year = c.posted.slice(0, 4);
    const row = rows.get(year) ?? { year, chapters: 0, pages: 0, longestGapWeeks: 0 };
    row.chapters += 1;
    row.pages += c.pages;
    if (i > 0) {
      const gap = Math.round((Date.parse(c.posted) - Date.parse(sorted[i - 1].posted)) / 604_800_000);
      if (gap > row.longestGapWeeks) row.longestGapWeeks = gap;
    }
    rows.set(year, row);
  });
  return [...rows.values()];
}

/** Previous / next in publication order, which is the only order the pager can
 *  use. The three entry points are a reading-order claim and they live on the
 *  archive page, next to the sentence that explains them. */
export function neighbours(list: Chapter[], id: string) {
  const i = list.findIndex((c) => c.id === id);
  return {
    index: i,
    prev: i > 0 ? list[i - 1] : null,
    next: i < list.length - 1 ? list[i + 1] : null,
    first: list[0],
    last: list[list.length - 1],
  };
}
