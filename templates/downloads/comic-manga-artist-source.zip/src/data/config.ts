// Mira Tolentino — "Low Tide Radio", Astoria, Oregon. Fictional.
//
// The organising idea: for a comic that has been running four years, the
// archive IS the site. A new reader arrives with three questions — where do I
// start, how long is this, is it still being made — and the usual comic
// homepage (banner, bio, "latest page", Support) answers none of them.
//
// So the landing page is the table of contents, every row opens, and the three
// answers sit above it instead of a hero. Everything below is data; the page
// derives every total from it so no number on the page can drift from the list.

export const site = {
  name:        'Low Tide Radio',
  shortName:   'Low Tide Radio',
  title:       'Low Tide Radio — a comic by Mira Tolentino',
  tagline:     'Four years, eighteen chapters, and three places to start.',
  owner:       'Mira Tolentino',
  ownerRole:   'Comic artist',
  credential:  'Drawn in Astoria, Oregon · right to left · all ages',
  city:        'Astoria',
  state:       'OR',
  language:    'en',
  email:       'mira@lowtideradio.example',
  status:      'Ongoing',
  statusNote:  'Chapter 19 is being drawn. Buffer: 11 pages.',
  rating:      'All ages',
  direction:   'Right to left',
  premise:
    'Nene Ocampo is sixteen and would rather be anywhere than Astoria. Her grandfather has the ' +
    'keys to a shut-down AM station above the boat yard, two hundred watts of transmitter and ' +
    'nobody to talk to. What they put on the air at six every morning turns into the thing the ' +
    'town sets its clocks and its tides by.',
  // Kept inside the 160 characters Google and LinkedIn truncate at, which the
  // seo-aeo-audit checklist calls P0. The long version of this sentence is the
  // premise above, where it is read rather than clipped.
  description:
    'The complete Low Tide Radio archive — every chapter with its page count, reading direction ' +
    'and content note on the row, and three places a new reader can start.',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Start here',  href: '#start' },
  { label: 'Archive',     href: '#archive' },
  { label: 'The record',  href: '#record' },
  { label: 'Read it elsewhere', href: '#mirrors' },
  { label: 'About',       href: '#about' },
];

// ── The chapters ──────────────────────────────────────────────────────────
// `id` is the URL segment and the row anchor. `pages` is the real sheet count
// rendered on the chapter page. `spreads` lists the double-page spreads by the
// number of their left-hand page — they are why this site is still the
// canonical place to read, because a vertical-scroll mirror cuts them in half.

export type Chapter = {
  id: string;
  n: number | null;      // null = not in the numbered run
  title: string;
  arc: string;
  posted: string;        // ISO
  pages: number;
  rtl: boolean;
  spreads: number[];
  note?: string;         // content note, shown before the reader clicks
  blurb: string;
};

export const arcs = [
  { id: 'signal-check', name: 'Signal Check', span: 'Chapters 1–5 · 2022–2023',
    n: 'A locked building, a transmitter nobody has switched on since 2004, and a first broadcast that four people hear.' },
  { id: 'dead-air',     name: 'Dead Air',     span: 'Chapters 6–11 · 2023–2024',
    n: 'The show has listeners now, which turns out to be a different problem from having none.' },
  { id: 'storm-watch',  name: 'Storm Watch',  span: 'Chapters 12–18 · 2024– ',
    n: 'A November bar crossing, a relay tower on the ridge, and what a small station is actually for.' },
  { id: 'side',         name: 'Side stories', span: 'Standalone · reads on its own',
    n: 'Drawn for a print anthology, left to right, and it needs nothing from the main run.' },
];

export const chapters: Chapter[] = [
  { id: '1',  n: 1,  arc: 'signal-check', title: 'Static',
    posted: '2022-09-06', pages: 34, rtl: true, spreads: [8],
    blurb: 'Nene is handed a key ring and a building with a hole in the roof.' },
  { id: '2',  n: 2,  arc: 'signal-check', title: 'The Tower on Cannery Hill',
    posted: '2022-10-25', pages: 22, rtl: true, spreads: [],
    blurb: 'Two hundred feet of guyed mast, and the reason the licence never lapsed.' },
  { id: '3',  n: 3,  arc: 'signal-check', title: 'Two Hundred Watts',
    posted: '2022-12-13', pages: 20, rtl: true, spreads: [],
    blurb: 'What that number covers at night, and what it does not.' },
  { id: '4',  n: 4,  arc: 'signal-check', title: 'Lolo’s Tape Box',
    posted: '2023-02-21', pages: 26, rtl: true, spreads: [14],
    blurb: 'Forty reels labelled in a hand Nene can read and a language she cannot.' },
  { id: '5',  n: 5,  arc: 'signal-check', title: 'First Broadcast',
    posted: '2023-05-09', pages: 30, rtl: true, spreads: [6, 22],
    blurb: 'Six in the morning. Tide table, weather, one song. Four people hear it.' },

  { id: '6',  n: 6,  arc: 'dead-air', title: 'Dead Air',
    posted: '2023-07-11', pages: 28, rtl: true, spreads: [],
    blurb: 'The arc opener, and the chapter that catches a new reader up without a recap page.' },
  { id: '7',  n: 7,  arc: 'dead-air', title: 'The Six O’Clock Tide',
    posted: '2023-08-22', pages: 22, rtl: true, spreads: [],
    blurb: 'A crab boat starts planning its morning around the broadcast.' },
  { id: '8',  n: 8,  arc: 'dead-air', title: 'Sponsors',
    posted: '2023-10-03', pages: 18, rtl: true, spreads: [],
    blurb: 'The hardware store offers forty dollars a month and an opinion.' },
  { id: '9',  n: 9,  arc: 'dead-air', title: 'A Letter From Neah Bay',
    posted: '2023-11-14', pages: 24, rtl: true, spreads: [],
    blurb: 'Somebody 120 miles north is listening on a skip signal after dark.' },
  { id: '10', n: 10, arc: 'dead-air', title: 'Interference',
    posted: '2023-12-19', pages: 26, rtl: true, spreads: [12],
    blurb: 'A new LED sign at the marina wipes out the band from four blocks away.' },
  { id: '11', n: 11, arc: 'dead-air', title: 'Sign-Off',
    posted: '2024-02-13', pages: 32, rtl: true, spreads: [10, 28],
    note: 'A hospital stay, on and off page.',
    blurb: 'The arc ends with the station running and one of its two people not in it.' },

  { id: 'the-nine-oclock-bell', n: null, arc: 'side', title: 'The Nine O’Clock Bell',
    posted: '2024-06-18', pages: 24, rtl: false, spreads: [],
    blurb: 'A standalone about the harbour bell and the man who rang it for thirty years. Drawn left to right for a print anthology, and it reads on its own — no chapter before it is needed.' },

  { id: '12', n: 12, arc: 'storm-watch', title: 'Storm Watch',
    posted: '2024-09-24', pages: 28, rtl: true, spreads: [],
    blurb: 'Back after seven months, and the show has to be rebuilt from a cold start.' },
  { id: '13', n: 13, arc: 'storm-watch', title: 'Small Craft Advisory',
    posted: '2024-11-19', pages: 24, rtl: true, spreads: [],
    note: 'Peril at sea. Nobody drowns.',
    blurb: 'A November bar crossing, read out live because nobody else will.' },
  { id: '14', n: 14, arc: 'storm-watch', title: 'The Bar at the Mouth',
    posted: '2025-03-04', pages: 26, rtl: true, spreads: [16],
    blurb: 'Why the Columbia bar is the reason a two-hundred-watt station still matters.' },
  { id: '15', n: 15, arc: 'storm-watch', title: 'Relay',
    posted: '2025-06-17', pages: 22, rtl: true, spreads: [],
    blurb: 'A second aerial on the ridge, put up by six people and a borrowed truck.' },
  { id: '16', n: 16, arc: 'storm-watch', title: 'Night Programme',
    posted: '2025-10-07', pages: 28, rtl: true, spreads: [20],
    blurb: 'Nene takes the ten o’clock hour, alone, and finds out who is awake.' },
  { id: '17', n: 17, arc: 'storm-watch', title: 'What the Tide Line Keeps',
    posted: '2026-02-10', pages: 30, rtl: true, spreads: [12],
    blurb: 'Winter, and the first chapter drawn entirely in the new room over the chandlery.' },
  { id: '18', n: 18, arc: 'storm-watch', title: 'Six in the Morning, Still',
    posted: '2026-06-23', pages: 26, rtl: true, spreads: [18],
    blurb: 'The most recent chapter. Chapter 19 is on the drawing board.' },
];

// ── The three doors ───────────────────────────────────────────────────────
// In the order recommended, which is not chapter order. This is the fact the
// schema.org block deliberately does not assert: there is no vocabulary for
// "start here instead", so it stays on the page and out of the markup.

export const doors = [
  { chapter: '1',
    k: 'Start at the beginning',
    n: 'Thirty-four pages, and the whole premise is set up by page nine. The right answer if you read comics from page one on principle — most people do, and it works.' },
  { chapter: '6',
    k: 'Jump on at chapter 6',
    n: 'The arc opener. It was written to be readable cold: the station is running, the cast is introduced by doing things rather than by being introduced, and nothing before it is load-bearing. This is what I tell people who bounced off a four-year archive.' },
  { chapter: 'the-nine-oclock-bell',
    k: 'Read the one-shot first',
    n: 'Twenty-four pages, self-contained, left to right. Costs you fifteen minutes and tells you whether you like the drawing and the pace, which is the actual question you are asking.' },
];

// ── The schedule record ───────────────────────────────────────────────────
// Not a schedule. A schedule is a promise and this is what happened. The
// chapter and page counts per year are computed from `chapters`; only the
// sentence is written by hand.

export const record: Record<string, string> = {
  '2022': 'Started on a twelve-page buffer, which lasted until December. Weekly pages, three weeks late by Christmas.',
  '2023': 'The steadiest year, and the first one anybody outside Astoria read. Two arcs running, buffer rebuilt twice, nothing later than the gap in the column to the left.',
  '2024': 'The gap year. Nothing new was drawn between February and September — a move and a wrist injury, said on the day rather than in September. The one-shot that posted in June had been finished before the hiatus and was held back for exactly this.',
  '2025': 'Back on a slower and truer cadence — a chapter every three to four months instead of a page a week. Fewer updates, and none of them missed.',
  '2026': 'Two chapters posted and a third being drawn. Four to five months apart is the true rate of one person drawing pages, and saying so is the point of this table.',
};

export const recordNote =
  'Every comic site says "updates weekly". This one says what actually posted, because a schedule ' +
  'is a promise and an archive is a record, and a reader deciding whether to start a four-year ' +
  'comic is asking about the record.';

// ── Where else to read ────────────────────────────────────────────────────

export const mirrors = [
  { k: 'Webtoon Canvas', href: 'https://www.webtoons.com/en/canvas',
    n: 'Re-cut into vertical scroll, one chapter per episode. Where most new readers actually arrive.' },
  { k: 'Tapas', href: 'https://tapas.io/',
    n: 'Same vertical-scroll cut, posted a week behind. Comments there get read; comments here get read faster.' },
  { k: 'GlobalComix', href: 'https://globalcomix.com/',
    n: 'Page-based and right to left, so the spreads survive. The closest mirror to this site.' },
];

export const mirrorNote =
  'Two of those three re-cut the pages into a vertical strip, and a double-page spread does not ' +
  'survive that cut — it becomes two half-drawings. Nine chapters here contain one. That is the ' +
  'whole reason this archive still exists next to platforms with a hundred times its traffic.';

// ── How it is made ────────────────────────────────────────────────────────

export const madeWith = [
  { t: 'Right to left, because that is how it is drawn',
    d: 'Panel order, page turns and every reveal are built for a right-hand page turn. Flipping the art to read left to right mirrors every face and every drawn word, so the site turns the pages instead. The one-shot is the exception and it is marked on its row.' },
  { t: 'Screentone, not grey fills',
    d: 'Dot tone at 60 lpi, 10% to 40%. It is the reason the pages hold up printed at B6 and the reason they need a real page view rather than a strip that rescales them.' },
  { t: 'Pages, not episodes',
    d: 'The unit is a printed page with a fixed trim, so a chapter is a page count and not a scroll length. Every number in this archive is a page count for that reason.' },
  { t: 'A buffer, always',
    d: 'Eleven pages ahead as of this week. The buffer is what turns a wrist injury into a slower month instead of a seven-month gap, which is a lesson from 2024 and not a theory.' },
];

export const faqs = [
  {
    q: 'Do I have to start at chapter 1?',
    a: 'No, and most people should not. Chapter 6 opens an arc and was written to be read cold; the one-shot is standalone and takes fifteen minutes. Chapter 1 is the best experience and the highest cost, which is exactly the trade-off the three doors above are there to make visible.',
  },
  {
    q: 'Which way do the pages read?',
    a: 'Right to left, Japanese order, on every chapter except The Nine O’Clock Bell, which was drawn left to right for a print anthology. The reading direction is on every row of the archive before you click, and on every chapter page as a note above the sheets.',
  },
  {
    q: 'Is it finished?',
    a: 'No. Chapter 18 posted in June 2026 and chapter 19 is being drawn, with eleven pages of buffer. The record below says what posted every year since 2022, including the seven months in 2024 when nothing new was drawn.',
  },
  {
    q: 'Is it suitable for younger readers?',
    a: 'All ages. Two chapters carry a content note on their row — a hospital stay in chapter 11 and peril at sea in chapter 13 — and neither is graphic. Nothing else in the archive needs one.',
  },
  {
    q: 'Why read here instead of on Webtoon?',
    a: 'Only for the spreads. Nine chapters contain a double-page spread, and a vertical-scroll mirror cuts each one into two half-drawings. If you are reading on a phone in a queue, the mirror is fine and I would rather you read it there than not at all.',
  },
  {
    q: 'Are those the real pages?',
    a: 'No — this is a website template, and what each chapter page renders is the panel layout of every page at the real count, with the real spreads marked. That is the thumbnail stage a comic is built from — the ‘name’, as it is called — and it is what you replace with your own artwork. Nobody buying a template wants somebody else’s comic in it.',
  },
];

// ── The template's own note ───────────────────────────────────────────────

export const templateNote =
  'Low Tide Radio is a fictional comic invented for this template. Every chapter page renders its ' +
  'pages as panel layouts rather than artwork — drop your own images in and the archive, the ' +
  'pager and the counts all keep working, because every number on this site is computed from one ' +
  'list in src/data/config.ts.';
