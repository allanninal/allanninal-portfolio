import { test, expect } from '@playwright/test';

test.describe('Low Tide Radio — smoke tests', () => {
  test('the archive is the home page', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Low Tide Radio/);
    await expect(page.locator('h1')).toHaveText('Low Tide Radio');
    // Index-first: the first heading below the masthead is where to start, and
    // the archive itself is above the fold on a desktop viewport in the sense
    // that it is the second section rather than the sixth.
    const ids = await page.locator('main section[id]').evaluateAll((s) => s.map((x) => x.id));
    expect(ids.slice(0, 2)).toEqual(['start', 'archive']);
  });

  // ── Schema ──────────────────────────────────────────────────────────────
  // A ComicSeries of ComicIssues. The deliberate withholding is any claim
  // about ORDER beyond publication order: the page's argument is that three
  // chapters are valid entry points, and schema can only assert one sequence.
  test('the series is ComicSeries and asserts no reading order', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const series = JSON.parse(blocks.find((b) => b.includes('ComicSeries'))!);
    expect(series['@type']).toBe('ComicSeries');
    expect(series.contentRating).toBeTruthy();
    expect(series.aggregateRating).toBeUndefined();
    expect(series.numberOfPages).toBeUndefined();

    const rows = await page.locator('table.chapters tbody tr').count();
    expect(series.hasPart.length).toBe(rows);
    for (const part of series.hasPart) {
      expect(part['@type']).toBe('ComicIssue');
      expect(part.contentRating).toBeTruthy();
      expect(part.position).toBeUndefined();
    }
    // Exactly one part carries no issueNumber: the standalone side story.
    expect(series.hasPart.filter((p: any) => p.issueNumber === undefined).length).toBe(1);

    const all = blocks.join('');
    expect(all).toContain('"Person"');
    expect(all).not.toContain('ItemList"');
    expect(all).not.toContain('aggregateRating');
    // Day 126's type must not have survived the scaffold.
    expect(all).not.toContain('VisualArtwork');
  });

  // ── The archive ─────────────────────────────────────────────────────────
  test('every figure in the masthead is the sum of the archive below it', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('table.chapters tbody tr');
    const n = await rows.count();
    const figures = await page.locator('.figures .v').allTextContents();
    expect(Number(figures[0])).toBe(n);

    const pageCounts = await page.locator('table.chapters tbody td:nth-child(3) .num').allTextContents();
    const total = pageCounts.reduce((a, b) => a + Number(b), 0);
    expect(Number(figures[1])).toBe(total);
    expect(total).toBeGreaterThan(400);
  });

  test('every chapter row opens a chapter page', async ({ page }) => {
    await page.goto('/');
    const links = page.locator('table.chapters tbody th a.t');
    const n = await links.count();
    expect(n).toBe(await page.locator('table.chapters tbody tr').count());
    for (const href of await links.evaluateAll((as) => as.map((a) => a.getAttribute('href')))) {
      expect(href).toMatch(/\/chapters\/[^/]+\/$/);
    }
  });

  test('reading direction and content notes are on the row, before the click', async ({ page }) => {
    await page.goto('/');
    const dirs = await page.locator('table.chapters tbody td:nth-child(4)').allTextContents();
    expect(dirs.length).toBeGreaterThan(10);
    expect(dirs.filter((d) => /left to right/i.test(d)).length).toBe(1);
    expect(dirs.filter((d) => /right to left/i.test(d)).length).toBe(dirs.length - 1);
    // Two chapters carry a note; the rest render an em dash rather than nothing.
    const notes = await page.locator('table.chapters tbody td:nth-child(5)').allTextContents();
    expect(notes.filter((t) => t.trim() !== '—').length).toBe(2);
  });

  test('the three doors are marked in the archive and are not consecutive', async ({ page }) => {
    await page.goto('/');
    const doors = page.locator('.doors > li');
    expect(await doors.count()).toBe(3);
    const marked = page.locator('table.chapters tbody tr.entry');
    expect(await marked.count()).toBe(3);
    const ids = await marked.evaluateAll((rows) => rows.map((r) => r.id));
    expect(new Set(ids).size).toBe(3);
    expect(ids).toContain('ch-1');
  });

  // ── The record ──────────────────────────────────────────────────────────
  test('the record reports a gap it does not hide', async ({ page }) => {
    await page.goto('/');
    const gaps = await page.locator('#record tbody td:nth-child(4)').allTextContents();
    const weeks = gaps.map((g) => Number(g.replace(/\D/g, '')));
    expect(Math.max(...weeks)).toBeGreaterThan(12);
    await expect(page.locator('#record')).toContainText(/what actually posted|what posted/i);
    await expect(page.locator('#record')).toContainText(/gap year/i);
  });

  // ── The structural claim ────────────────────────────────────────────────
  // This template has no lead form. A comic's subscribe surface is a feed and
  // a mirror account, and shipping a contact form here would be the scaffold
  // talking rather than the niche.
  test('there is no form and no select anywhere on the archive', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('form').count()).toBe(0);
    expect(await page.locator('select, input, textarea').count()).toBe(0);
    expect(await page.locator('details').count()).toBe(0);
  });

  test('the feed exists and lists every chapter, newest first', async ({ page, request }) => {
    await page.goto('/');
    const rows = await page.locator('table.chapters tbody tr').count();
    const res = await request.get('/rss.xml');
    expect(res.status()).toBe(200);
    const xml = await res.text();
    expect((xml.match(/<item>/g) || []).length).toBe(rows);
    const dates = [...xml.matchAll(/<pubDate>([^<]+)<\/pubDate>/g)].map((m) => Date.parse(m[1]));
    expect(dates).toEqual([...dates].sort((a, b) => b - a));
  });

  // The page's whole thesis is that its numbers are counted rather than typed.
  // The one place a count is written in prose is the spread sentence, so it is
  // checked against the figure the masthead computes.
  test('the prose spread count matches the computed one', async ({ page }) => {
    await page.goto('/');
    const figures = await page.locator('.figures .v').allTextContents();
    const n = Number(figures[2]);
    const words = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight',
      'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen'];
    const spreadRows = await page.locator('table.chapters tbody td:nth-child(3)')
      .evaluateAll((tds) => tds.filter((t) => /spread/i.test(t.textContent || '')).length);
    expect(spreadRows).toBe(n);
    await expect(page.locator('#mirrors')).toContainText(
      new RegExp(`${words[n]} chapters here contain one`, 'i'));
  });

  // ── The reader ──────────────────────────────────────────────────────────
  test('a chapter page reads right to left and renders one sheet per page', async ({ page }) => {
    await page.goto('/chapters/1/');
    await expect(page.locator('h1')).toContainText('Chapter 1');
    const grid = page.locator('.sheets');
    await expect(grid).toHaveAttribute('dir', 'rtl');

    // A spread covers two page numbers, so sheets < pages by the spread count.
    const pagesTxt = (await page.locator('.meta-strip dd').nth(1).textContent()) || '';
    const pages = Number(pagesTxt.trim().split(' ')[0]);
    const spreads = await page.locator('.sheet.spread').count();
    expect(spreads).toBeGreaterThan(0);
    expect(await page.locator('.sheet').count()).toBe(pages - spreads);

    // Layouts, not pictures.
    expect(await page.locator('.sheets img').count()).toBe(0);
    expect(await page.locator('.sheets svg[aria-hidden="true"]').count()).toBeGreaterThan(10);
  });

  test('the one-shot is the only chapter that reads left to right', async ({ page }) => {
    await page.goto('/chapters/the-nine-oclock-bell/');
    await expect(page.locator('.sheets')).toHaveAttribute('dir', 'ltr');
    await expect(page.locator('.meta-strip')).toContainText('Left to right');
  });

  // An "aria-disabled" link is still a link. The ends of the run render as
  // text, which is why the library-wide dead-href test can stay strict.
  test('the pager has no dead ends at either end of the run', async ({ page }) => {
    await page.goto('/chapters/1/');
    const first = page.locator('nav.pager').first();
    await expect(first.locator('span', { hasText: 'First' })).toBeVisible();
    expect(await first.locator('a[href="#"]').count()).toBe(0);

    await page.goto('/chapters/18/');
    const last = page.locator('nav.pager').first();
    await expect(last.locator('span', { hasText: 'Latest' })).toBeVisible();
    await expect(last.locator('a', { hasText: 'Previous' })).toBeVisible();
  });

  test('a chapter page links back to its own row in the archive', async ({ page }) => {
    await page.goto('/chapters/6/');
    const back = page.locator('nav.pager a', { hasText: 'All chapters' }).first();
    await expect(back).toHaveAttribute('href', /#ch-6$/);
    await expect(page.locator('.note-box').first()).toContainText(/start here/i);
  });

  // ── Hygiene ─────────────────────────────────────────────────────────────
  test('no trace of the day-126 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['mackaye', 'risograph', 'newsprint', 'athens', 'vinyl cut', 'embroidery']) {
      expect(html, `day-126 copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    // Five full navigations of a 19-row archive, while the axe sweep is running
    // in a sibling worker. The 30s default is not enough for the traffic.
    test.setTimeout(120_000);
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('a chapter page cannot be scrolled sideways either', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1440, 900, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/chapters/11/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro volume plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/volume-plan/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
