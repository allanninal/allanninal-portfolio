import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo bar renders with hub URL', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR)).toBeVisible();
});

test('TemplateInfo shows edition tagline', async ({ page }) => {
  await page.goto('/');
  const text = await page.locator(BAR).textContent();
  expect(text).toContain(isPro ? 'Pro edition' : '38');
});

test('TemplateInfo has a static-zip download button', async ({ page }) => {
  await page.goto('/');
  const staticBtn = page.locator(BAR).locator('a', {
    hasText: isPro ? /download free/i : /download static/i,
  });
  await expect(staticBtn).toBeVisible();
  const href = await staticBtn.getAttribute('href');
  expect(href).toContain('patisserie-static.zip');
});

test('TemplateInfo source / Get-Pro affordance', async ({ page }) => {
  await page.goto('/');
  if (isPro) {
    const getPro = page.locator(BAR).locator('a', { hasText: /get pro static/i });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    return;
  }
  const srcBtn = page.locator(BAR).locator('a', { hasText: /source.*astro/i });
  await expect(srcBtn).toBeVisible();
  const href = await srcBtn.getAttribute('href');
  expect(href).toContain('patisserie-source.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  const all365 = page.locator(BAR).locator('a', { hasText: /all 365/i });
  await expect(all365).toBeVisible();
});

test('TemplateInfo links to LinkedIn (Build with me / Get Pro static)', async ({ page }) => {
  await page.goto('/');
  const link = page.locator(BAR).locator('a', {
    hasText: isPro ? /get pro static/i : /build with me/i,
  });
  await expect(link).toBeVisible();
  const href = await link.getAttribute('href');
  expect(href).toContain('linkedin.com');
});

test('no github.com/allanninal/templates private repo links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
