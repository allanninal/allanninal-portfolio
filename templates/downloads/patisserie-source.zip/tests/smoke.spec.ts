import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Maison Véron/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero heading contains pâtisserie reference', async ({ page }) => {
  await page.goto('/');
  const heading = await page.locator('#hero-heading').textContent();
  expect(heading?.toLowerCase()).toMatch(/p.tisserie|fran/i);
});

test('collection section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#collection')).toBeVisible();
});

test('collection heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#collection-heading')).toBeVisible();
});

test('collection tabs exist and are interactive', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('collection tab switching works', async ({ page }) => {
  await page.goto('/');
  const viennoiserieTab = page.locator('[role="tab"]', { hasText: /viennoiserie/i });
  await viennoiserieTab.click();
  expect(await viennoiserieTab.getAttribute('aria-selected')).toBe('true');

  const viennoiseriePanel = page.locator('[data-panel="viennoiserie"]');
  await expect(viennoiseriePanel).toBeVisible();
});

test('seasonal section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#saison')).toBeVisible();
});

test('inquiry section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#commande')).toBeVisible();
});

test('commission form is present', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('form[name="commande-enquiry"]');
  await expect(form).toBeVisible();
});

test('maison section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#maison')).toBeVisible();
});

test('galerie section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#galerie')).toBeVisible();
});

test('horaires section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#horaires')).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('a[href="#main-content"]');
  await expect(skipLink).toBeAttached();
});

test('navigation has accessible label', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('footer nav has accessible label', async ({ page }) => {
  await page.goto('/');
  const footerNav = page.locator('nav[aria-label="Footer navigation"]');
  await expect(footerNav).toBeVisible();
});

test('patisserie name appears in page', async ({ page }) => {
  await page.goto('/');
  const content = await page.content();
  expect(content).toContain('Maison Véron');
});

test('inquiry CTA button is present in header', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('header a[href*="commande"]').first();
  await expect(cta).toBeAttached();
});
