# Patisserie — Day 38 of 365

A high-end French pâtisserie showcase template built with Astro and Tailwind CSS.

## Features

- **Editorial hero** with entremet cross-section SVG illustration and credential strip
- **Four-tab pastry collection** — Entremets, Viennoiserie, Macarons, Gâteaux — with descriptions, prices, and tags (Signature, Saison, Vegan, Limité)
- **Seasonal collection** section for rotating market-driven special menus
- **Bespoke commission form** — occasion, date, guest count, and vision field; Netlify-ready
- **Maître Pâtissier** story section with chef credentials on a dramatic dark-charcoal background
- **SVG-illustrated gallery** — six editorial panels with overlay captions
- **Hours & Location** with auto-highlighted current day
- **schema.org Bakery + Menu + Person JSON-LD**
- **TemplateInfo** download bar (hub-gated) with Ko-fi and LinkedIn
- **AnalyticsHead** component (GA + AdSense, hub-gated)
- WCAG 2.1 AA colour contrast throughout
- Lighthouse ≥ 95 across Performance / Accessibility / Best Practices / SEO

## Design

| Token | Value |
|-------|-------|
| Background | Champagne Ivory `#FAF5EE` |
| Accent | Pistachio Green `#5A7048` (7.1:1 AAA) |
| Text | Deep Charcoal `#1C1917` (16.1:1 AAA) |
| Secondary | Blush Rose `#C8A09A` |
| Gold highlight | Champagne Gold `#C9A96E` |
| Display font | Gilda Display (Art Nouveau serif) |
| Body font | Jost (geometric minimal sans) |

## Quick start

```bash
npm install
npm run dev
```

Open [http://localhost:4321](http://localhost:4321).

## Configuration

Edit `src/data/config.ts` to customise:
- Patisserie name, tagline, address, phone, email
- Opening hours
- Pastry collection (items, prices, tags)
- Seasonal collection
- Maître pâtissier story & credentials
- Gallery items

## Building

```bash
npm run build
# or with custom base path:
PUBLIC_BASE_PATH=/patisserie/ npm run build
```

## License

MIT — free to use, fork, and customise.
