export const patisserie = {
  name: 'Maison Véron',
  tagline: 'French pâtisserie. Refined by tradition.',
  shortTagline: 'A Parisian-inspired pâtisserie crafting entremets, viennoiserie, and bespoke gâteaux.',
  description:
    'Maison Véron is a high-end French pâtisserie where every creation begins with the finest seasonal ingredients and classical technique. From delicate entremets and hand-laminated viennoiserie to bespoke occasion gâteaux, each piece is crafted with the precision and artistry of a maître pâtissier.',
  address: '24 Rue Saint-Honoré, San Francisco, CA 94108',
  phone: '+1 (415) 555-0291',
  email: 'bonjour@maisonveron.com',
  orderUrl: '#commande',
  instagram: 'https://instagram.com/maisonveron',
  facebook: 'https://facebook.com/maisonveron',
  estYear: '2018',
  reservationUrl: '#commande',
};

export const hours = [
  { day: 'Lundi / Monday',   open: 'Fermé / Closed', note: '' },
  { day: 'Mardi / Tuesday',  open: '8:00 – 18:00',   note: '' },
  { day: 'Mercredi / Wednesday', open: '8:00 – 18:00', note: '' },
  { day: 'Jeudi / Thursday', open: '8:00 – 18:00',   note: '' },
  { day: 'Vendredi / Friday',open: '8:00 – 19:00',   note: '' },
  { day: 'Samedi / Saturday',open: '8:00 – 19:00',   note: 'Seasonal tasting window 10–12' },
  { day: 'Dimanche / Sunday',open: '9:00 – 14:00',   note: 'Sunday brunch selections' },
];

export type PastryTag = 'signature' | 'seasonal' | 'vegan' | 'gluten-free' | 'limited';

export type PastryItem = {
  name: string;
  frenchName?: string;
  description: string;
  price: string;
  tags?: PastryTag[];
  note?: string;
};

export type PastryCategory = {
  id: string;
  label: string;
  frenchLabel: string;
  description: string;
  items: PastryItem[];
};

export const collection: PastryCategory[] = [
  {
    id: 'entremet',
    label: 'Entremets',
    frenchLabel: 'Les Entremets',
    description: 'Multi-layered mousse cakes with mirror glazes and sculpted finishes. Each is assembled over two days and limited to eight portions.',
    items: [
      {
        name: 'Champagne Rose',
        frenchName: 'Champagne & Rose',
        description: 'Champagne mousse, rose-litchi gelée, almond dacquoise, and a blush mirror glaze dusted with edible silver. Our most requested creation.',
        price: '$22 / slice',
        tags: ['signature'],
      },
      {
        name: 'Pistachio Praline',
        frenchName: 'Pistache & Praline',
        description: 'Sicilian pistachio mousse over feuilletine croustillant, hazelnut praline insert, and a pistachio velvet finish.',
        price: '$21 / slice',
        tags: ['signature'],
      },
      {
        name: 'Dark Chocolate Caramel',
        frenchName: 'Chocolat & Caramel',
        description: '72% Valrhona chocolate mousse, salted caramel insert, chocolate biscuit joconde, mirror glaze. Intense and deeply satisfying.',
        price: '$20 / slice',
        tags: ['signature', 'vegan'],
      },
      {
        name: 'Yuzu Elderflower',
        frenchName: 'Yuzu & Fleur de Sureau',
        description: 'Yuzu curd mousse, elderflower panna cotta insert, genoise légère, and a pale gold glaze. Spring–summer only.',
        price: '$23 / slice',
        tags: ['seasonal', 'limited'],
        note: 'Available April – September',
      },
    ],
  },
  {
    id: 'viennoiserie',
    label: 'Viennoiserie',
    frenchLabel: 'La Viennoiserie',
    description: 'Hand-laminated pastry using 84% cultured butter and a 72-hour cold-ferment process. Baked in two rounds — 8 AM and 11 AM.',
    items: [
      {
        name: 'Croissant Beurre',
        frenchName: 'Croissant Beurre',
        description: 'The foundation. 27 alternating layers of dough and cultured butter. Shatters on touch, melts on the palate.',
        price: '$5.50',
        tags: ['signature'],
      },
      {
        name: 'Kouign-Amann',
        frenchName: 'Kouign-Amann',
        description: 'Breton laminated dough folded with cane sugar and salted butter. Deeply caramelised crust, tender center. Twelve made daily.',
        price: '$6',
        tags: ['signature', 'limited'],
        note: 'Limited to 12 per day',
      },
      {
        name: 'Pain au Chocolat Valrhona',
        frenchName: 'Pain au Chocolat',
        description: 'Two batons of Valrhona 66% encased in laminated dough. Slightly bitter counterpoint to the butter.',
        price: '$5.75',
        tags: ['signature'],
      },
      {
        name: 'Escargot Pistache',
        frenchName: 'Escargot Pistache',
        description: 'Rolled croissant dough spiralled with pistachio frangipane and candied orange. A Maison Véron original.',
        price: '$6.50',
        tags: ['seasonal'],
      },
      {
        name: 'Chausson aux Pommes',
        frenchName: 'Chausson aux Pommes',
        description: 'Rough-puff pastry enclosing compote of Granny Smith apples, vanilla, and a touch of calvados. Weekend only.',
        price: '$6',
        tags: ['seasonal'],
        note: 'Saturday & Sunday only',
      },
    ],
  },
  {
    id: 'macarons',
    label: 'Macarons',
    frenchLabel: 'Les Macarons',
    description: 'French meringue macarons aged overnight for the ideal chew. A rotating seasonal selection with four permanent signatures.',
    items: [
      {
        name: 'Rose Ispahan',
        frenchName: 'Rose & Framboise',
        description: 'Rose-scented shell, raspberry-rose ganache, crystallised rose petal. The classic Maison Véron signature.',
        price: '$4 each · $22 / 6',
        tags: ['signature'],
      },
      {
        name: 'Vanille Bourbon',
        frenchName: 'Vanille Bourbon',
        description: 'Madagascan bourbon vanilla bean infused into a Swiss meringue buttercream. Pale ivory and flawlessly simple.',
        price: '$4 each · $22 / 6',
        tags: ['signature'],
      },
      {
        name: 'Chocolat Noir',
        frenchName: 'Chocolat Intense',
        description: '70% Manjari chocolate ganache, a touch of fleur de sel. For those who prefer depth over sweetness.',
        price: '$4 each · $22 / 6',
        tags: ['signature'],
      },
      {
        name: 'Seasonal Flavour',
        frenchName: 'Saveur du Saison',
        description: 'Changes with the market. Yuzu tart, fig & honey, saffron mango, wild blackcurrant — ask at the counter.',
        price: '$4.50 each',
        tags: ['seasonal', 'limited'],
      },
    ],
  },
  {
    id: 'gateaux',
    label: 'Gâteaux',
    frenchLabel: 'Les Gâteaux',
    description: 'Whole cakes for celebrations and ceremonies. Each is assembled to order and requires 72 hours minimum notice.',
    items: [
      {
        name: 'Fraisier',
        frenchName: 'Fraisier de Saison',
        description: 'Génoise légère, mousseline cream, fresh-market strawberries, mirror glaze. Spring–summer. Serves 8–10.',
        price: 'from $185',
        tags: ['seasonal'],
        note: 'April – August only',
      },
      {
        name: 'Bûche de Noël',
        frenchName: 'Bûche de Noël',
        description: 'Holiday log cake in rotating flavours. Champagne & pear, chestnut & praline, or dark chocolate. Serves 10.',
        price: 'from $210',
        tags: ['seasonal', 'limited'],
        note: 'November – January',
      },
      {
        name: 'Bespoke Wedding Gâteau',
        frenchName: 'Pièce Montée',
        description: 'Multi-tiered celebration cake designed in consultation with our maître pâtissier. Custom flavour profiles, décor, and scale. For weddings, galas, and milestone events.',
        price: 'from $450',
        note: 'Consultation required — min. 2 weeks notice',
      },
      {
        name: 'Tarte aux Fruits',
        frenchName: 'Tarte aux Fruits de Saison',
        description: 'Pâte sucrée shell, vanilla pastry cream, seasonal market fruit arranged in the classic Parisian style. Available in 20cm and 26cm.',
        price: 'from $62',
        tags: ['signature'],
      },
    ],
  },
];

export const seasonal = {
  headline: 'La Collection Estivale',
  subheadline: 'Summer 2026',
  description:
    'Each season, our maître pâtissier curates a limited collection around the finest market arrivals. Summer 2026 centres on white peach, lavender, and verbena — delicate, floral, and ephemeral. Available through September.',
  pieces: [
    {
      name: 'Pêche Blanche & Verveine',
      description: 'White peach mousse, verbena gelée, lemon sablé breton.',
      available: true,
    },
    {
      name: 'Lavande & Miel de Provence',
      description: 'Lavender honey ganache, fleur de sel caramel, almond streusel.',
      available: true,
    },
    {
      name: 'Figue & Fromage Blanc',
      description: 'Slow-roasted fig compote, fromage blanc mousse, walnut crumble. Coming August.',
      available: false,
    },
  ],
};

export const story = {
  headline: 'Maître Pâtissier',
  chefName: 'Hélène Marchand',
  chefTitle: 'Maître Pâtissière & Fondatrice',
  bio: [
    "Hélène Marchand trained in Lyon and Paris before opening Maison Véron in San Francisco in 2018 — bringing the rigour of classical French technique to California's abundance of seasonal produce.",
    'Her philosophy is precise and uncompromising: every layer must serve a purpose; every flavour must earn its place. The result is pâtisserie that is simultaneously faithful to tradition and responsive to the season.',
    'Maison Véron has been recognised by the Michelin Guide and named among the best patisseries in the United States by Bon Appétit.',
  ],
  credentials: [
    'Certified Maître Pâtissier, Confédération Nationale de la Pâtisserie',
    'Formée chez Pierre Hermé, Paris',
    'Michelin Guide recognition, 2022 & 2023',
    "Bon Appétit — Best Patisserie, West Coast 2024",
  ],
  stats: [
    { label: 'Opened',            value: '2018' },
    { label: 'Training',          value: 'Lyon & Paris' },
    { label: 'Daily Entremets',   value: '≤ 40' },
    { label: 'Butter (weekly)',   value: '12 kg' },
  ],
};

export const galleryItems = [
  { alt: 'A champagne-rose entremet with blush mirror glaze on a marble plinth, dusted with edible silver', label: 'Champagne Rose Entremet', src: 'entremet' },
  { alt: 'Freshly baked kouign-amann with deep caramel crust on a white linen cloth', label: 'Kouign-Amann', src: 'kouign-amann' },
  { alt: 'A row of rose macarons with crystallised rose petals on a slate board', label: 'Rose Macarons', src: 'macarons' },
  { alt: 'Hands shaping laminated croissant dough on a cold marble surface in morning light', label: 'Viennoiserie Atelier', src: 'atelier' },
  { alt: 'A three-tier bespoke wedding gâteau decorated with sugar roses and gold leaf in a patisserie salon', label: 'Bespoke Wedding Gâteau', src: 'gateau' },
  { alt: 'Interior of Maison Véron — pale stone walls, gilded display cases, natural light through arched windows', label: 'Maison Véron', src: 'interior' },
];

export const inquiry = {
  headline: 'Commande Spéciale',
  subheadline: 'Bespoke & Catering Enquiries',
  description:
    'For bespoke gâteaux, private catering, and wholesale enquiries, please complete the form below. Our team responds within one business day. For urgent matters, call us directly.',
  occasions: [
    'Wedding / Mariage',
    'Engagement / Fiançailles',
    'Private Dinner / Dîner Privé',
    'Corporate Event / Événement d\'entreprise',
    'Birthday / Anniversaire',
    'Christening / Baptême',
    'Other / Autre',
  ],
};

export const maker = {
  name: 'Maison Véron',
  linkedin: '#',
  twitter: '#',
  github: '#',
  email: 'hello@maisonvron.com',
  kofi: '#',
};

export const site = {
  title: 'Maison Véron — French Pâtisserie, San Francisco',
  description:
    'A high-end French pâtisserie in San Francisco. Entremets, viennoiserie, macarons and bespoke gâteaux, plus seasonal collections and catering.',
  url: 'https://example.com/',
  ogImage: '/og-image.png',
  language: 'fr',
};
