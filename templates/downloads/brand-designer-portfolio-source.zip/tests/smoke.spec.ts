import { test, expect } from '@playwright/test';

const int = (s: string) => Number((s.match(/[\d,]+/) || ['0'])[0].replace(/,/g, ''));

test.describe('Marit Halvorsen — smoke tests', () => {
  test('homepage renders with the designer in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Marit Halvorsen/);
    await expect(page.locator('h1')).toContainText('rules are for the people');
  });

  // A Person plus the identity as a CreativeWork whose status is Revised —
  // not day 122's accessibility WebPage, not day 121's ProfilePage.
  test('emits the identity as a CreativeWork with a revised status', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const work = JSON.parse(blocks.find((b) => b.includes('CreativeWork'))!);
    expect(work.dateCreated).toBe('2025-03');
    expect(work.dateModified).toBe('2026-09');
    expect(work.creativeWorkStatus).toMatch(/withdrawn or rewritten/);
    // No logo file exists in this template, so none is claimed.
    expect(work.image).toBeUndefined();
    expect(JSON.stringify(work)).not.toContain('aggregateRating');
    expect(blocks.join('')).not.toContain('ProfilePage');
    expect(blocks.join('')).not.toContain('accessibilityFeature');
  });

  // ── The audit ───────────────────────────────────────────────────────────
  test('ten rule cards, each with a count, a verdict and what broke it', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#rules article.rule');
    expect(await cards.count()).toBe(10);
    for (const c of await cards.all()) {
      await expect(c).toBeVisible();
      expect(((await c.locator('.rule-say').textContent()) || '').length).toBeGreaterThan(30);
      const held = (await c.locator('.rule-held').textContent()) || '';
      const [h, a] = (held.match(/\d+/g) || []).map(Number);
      expect(a).toBeGreaterThan(0);
      expect(h).toBeLessThanOrEqual(a);
      expect(((await c.locator('.rule-broke').textContent()) || '').length).toBeGreaterThan(60);
    }
  });

  test('three verdicts, carried by word and glyph and by no colour at all', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#rules .verdict');
    expect(await v.count()).toBe(10);
    for (const el of await v.all()) {
      expect(((await el.textContent()) || '').trim()).toMatch(/^(Keep|Rewrite|Drop)$/);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    // Two of the three verdicts share the plain text colour: hue is NOT a
    // signal on this page, because colour is reserved for the client.
    const colours = await v.evaluateAll((els) => [...new Set(els.map((e) => getComputedStyle(e).color))]);
    expect(colours.length).toBeLessThan(3);
    // Drop is distinguished structurally instead.
    const drop = page.locator('#rules .verdict--drop').first();
    expect(await drop.evaluate((e) => getComputedStyle(e).textDecorationLine)).toContain('line-through');
  });

  test('two rules are deleted, and the headline counts them', async ({ page }) => {
    await page.goto('/');
    const words = await page.locator('#rules .verdict').allTextContents();
    const dropped = words.filter((w) => /^Drop$/i.test(w.trim())).length;
    expect(dropped).toBe(2);
    await expect(page.locator('#rules h2')).toContainText(`${dropped} of them should not exist`);
  });

  test('the applied total in the headline is the sum of the cards', async ({ page }) => {
    await page.goto('/');
    const totals = await page.locator('#rules .rule-held').evaluateAll((els) =>
      els.map((e) => (e.textContent || '').match(/\d+/g)!.map(Number)));
    const applied = totals.reduce((a, [, n]) => a + n, 0);
    const held = totals.reduce((a, [n]) => a + n, 0);
    const h2 = (await page.locator('#rules h2').textContent()) || '';
    expect(h2).toContain(applied.toLocaleString('en-US'));
    expect(await page.locator('#rules').textContent()).toContain(held.toLocaleString('en-US'));
  });

  // ── Rule 7, enforced on this page ───────────────────────────────────────
  test('the client flag colour never carries a character of text', async ({ page }) => {
    for (const path of ['/', '/specimen/']) {
      await page.goto(path);
      const offenders = await page.evaluate(() => {
        const flag = 'rgb(228, 85, 43)';
        const out: string[] = [];
        document.querySelectorAll('*').forEach((el) => {
          const text = [...el.childNodes]
            .filter((n) => n.nodeType === 3)
            .map((n) => (n.textContent || '').trim())
            .join('');
          if (text && getComputedStyle(el as Element).color === flag) out.push(text.slice(0, 40));
        });
        // SVG text too.
        document.querySelectorAll('svg text, svg tspan').forEach((el) => {
          const f = (el.getAttribute('fill') || '').toLowerCase();
          if (f.includes('flag') || f === '#e4552b') out.push('svg: ' + (el.textContent || ''));
        });
        return out;
      });
      expect(offenders, `flag used as a text colour on ${path}`).toEqual([]);
    }
  });

  test('the specimen states the failing ratio rather than hiding it', async ({ page }) => {
    await page.goto('/specimen/');
    await expect(page.locator('h1')).toContainText('Three colours');
    expect(await page.locator('.swatch').count()).toBe(3);
    await expect(page.locator('body')).toContainText('3.73:1');
    await expect(page.locator('body')).toContainText(/never carries type|never allowed to carry type/i);
  });

  // ── Drawn rules ─────────────────────────────────────────────────────────
  test('both drawings are generated from the numbers the rules state', async ({ page }) => {
    await page.goto('/');
    const figs = page.locator('#drawn figure.dwg');
    expect(await figs.count()).toBe(2);
    for (const f of await figs.all()) {
      await expect(f.locator('svg')).toHaveAttribute('aria-hidden', 'true');
      expect(((await f.locator('figcaption').textContent()) || '').length).toBeGreaterThan(120);
    }
    // The minimum-width figure and rule 4 must quote the same millimetres.
    const cap = (await figs.nth(1).locator('figcaption').textContent()) || '';
    const mm = Number((cap.match(/(\d+)\s*mm/) || [])[1]);
    expect(mm).toBeGreaterThan(10);
    const rule4 = (await page.locator('#rules article.rule').nth(3).textContent()) || '';
    expect(rule4).toContain(`${mm} mm`);
  });

  // ── Touchpoints ─────────────────────────────────────────────────────────
  test('most touchpoints have never opened the guidelines', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#touch tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(5);
    const read = (await page.locator('#touch tbody td.v').allTextContents())
      .filter((t) => t.trim() === 'Yes').length;
    expect(read).toBeLessThan(n / 2);
    await expect(page.locator('#touch .eyebrow')).toContainText(`${read} of them has opened`);
  });

  // ── Absences and shape ──────────────────────────────────────────────────
  test('there is no footer navigation', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer nav').count()).toBe(0);
    expect(await page.locator('nav').count()).toBe(2);
  });

  test('there is no logo image anywhere in the template', async ({ page }) => {
    for (const path of ['/', '/specimen/']) {
      await page.goto(path);
      expect(await page.locator('img').count()).toBe(0);
    }
  });

  test('the specimen page is free, not gated', async ({ page }) => {
    const res = await page.goto('/specimen/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).not.toContain('refresh');
    await expect(page.locator('.plate .mark').first()).toBeVisible();
  });

  test('the FAQ is an accordion and the form asks for a measurement', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    for (const id of ['#name', '#email', '#smallest', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('select').count()).toBe(0);
  });

  test('no trace of the day-122 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['yusra benhaddou', 'chicago', 'saved addresses', 'browser default', 'skeleton']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro audit method is absent from the free build', async ({ page }) => {
    const res = await page.goto('/audit-method/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
