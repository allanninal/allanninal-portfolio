// Marit Halvorsen — Portland, ME. Fictional, and so is Kestrel Ferry Line, the
// identity this page audits.
//
// The organising idea: an identity is judged eighteen months later, by people
// who were not in the room and will never open the PDF. Every rule below
// carries how many times it was actually applied and how often it held, and
// two of them are marked Drop because they were bad rules that I wrote.

export const site = {
  name:        'Marit Halvorsen',
  shortName:   'Marit Halvorsen',
  title:       'Marit Halvorsen — brand designer, Portland, Maine',
  tagline:     'The rules are for the people who aren’t me.',
  owner:       'Marit Halvorsen',
  ownerRole:   'Brand designer',
  credential:  'Twelve years · identity systems for operators, not for launches',
  city:        'Portland',
  state:       'ME',
  language:    'en',
  phoneDisplay: '(207) 555-0142',
  phoneHref:   '+12075550142',
  email:       'marit@halvorsen.example',
  streetAddress: '58 Fore St',
  postalCode:  '04101',
  hours:       'One identity at a time · audits any time',
  bookingWindow: 'Booked from May · an identity is four months and an audit is a fortnight',
  description:
    'An identity is not judged on the day it is delivered. It is judged eighteen months later, ' +
    'on a slide made by a receptionist at four in the afternoon and a sign ordered by a ' +
    'franchisee from a local fabricator. Below is one identity, ten rules, and how each one ' +
    'actually held — including the two I got wrong.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The audit',  href: '#rules' },
  { label: 'Touchpoints', href: '#touch' },
  { label: 'Specimen',   href: 'specimen/' },
  { label: 'Work with me', href: '#contact' },
];

// ── The identity being audited ────────────────────────────────────────────
// Two colours that pass against each other, and one that deliberately does
// not carry type. The flaw is real and it is rule 7.

export const identity = {
  client: 'Kestrel Ferry Line',
  what: 'Casco Bay passenger and freight ferry · six vessels · eleven landings',
  when: 'Delivered March 2025 · audited September 2026',
  colours: [
    { k: 'Ink',   v: '#12303A', n: 'The only colour type is ever set in. 10.69:1 against Sand and 13.91:1 against white.' },
    { k: 'Sand',  v: '#E8E1D3', n: 'The ground. Chosen because it is printable on uncoated stock and survives a vinyl match within a shade.' },
    { k: 'Flag',  v: '#E4552B', n: 'Fill only, never type. It sits at 3.73:1 on Ink, which fails AA, and rule 7 exists because of that number.' },
  ],
  clearSpace: 0.5,   // multiples of the mark's height
  minWidth: 22,      // millimetres
  minWidthPx: 96,    // screen equivalent
};

// ── The ten rules ─────────────────────────────────────────────────────────
// `applied` is how many times the rule was actually invoked in eighteen months.
// `held` is how many of those it survived. `verdict` is keep | rewrite | drop.

export const rules = [
  {
    n: 1, k: 'One ink for type',
    say: 'All text is Ink. Not Flag, not a tint of Ink, not black.',
    applied: 412, held: 401, verdict: 'keep',
    broke: 'Eleven times, all in one franchise office using a Word template from 2019 that nobody could edit. Fixed by sending a new template rather than by writing a longer rule.',
  },
  {
    n: 2, k: 'The mark sits on Sand or on white',
    say: 'Never on a photograph. If the only option is a photograph, use the wordmark on a Sand bar.',
    applied: 188, held: 176, verdict: 'keep',
    broke: 'Twelve times on social, always over a sunset. The escape hatch in the second sentence is why it is only twelve.',
  },
  {
    n: 3, k: 'Half the mark’s height of clear space',
    say: 'Nothing within half the height of the mark on any side. Measure with the mark itself.',
    applied: 340, held: 305, verdict: 'keep',
    broke: 'Thirty-five times, mostly on 1:1 social avatars where half a height does not fit in the crop. That is a real gap and the fix is a separate avatar lockup, which now exists.',
  },
  {
    n: 4, k: 'Never smaller than 22 mm',
    say: 'Below 22 mm wide, use the K mark alone. On screen that is 96 px.',
    applied: 96, held: 61, verdict: 'rewrite',
    broke: 'Thirty-five times on ticket stock, where the printable area is 19 mm and always was. The rule was written from a letterhead and never checked against a ticket. Rewritten to 18 mm with a thicker mark.',
  },
  {
    n: 5, k: 'Sentence case everywhere',
    say: 'Headings, buttons, signs, ticket stubs. No all-caps except on the hull.',
    applied: 520, held: 511, verdict: 'keep',
    broke: 'Nine times on wayfinding, where a fabricator defaulted to caps. Cheap to fix and it is the rule people follow most easily, because it is the one they can check without a ruler.',
  },
  {
    n: 6, k: 'One typeface, two weights',
    say: 'Regular and Bold. If it is not installed, use Georgia and do not apologise.',
    applied: 640, held: 598, verdict: 'keep',
    broke: 'Forty-two times, all of them a substitute font on a machine without the licence. The second sentence is the entire reason this rule works, and it took three identities to learn to write it.',
  },
  {
    n: 7, k: 'Flag never carries type',
    say: 'Flag is a fill. Text on it fails contrast at 3.73:1 and it is not a judgement call.',
    applied: 210, held: 204, verdict: 'keep',
    broke: 'Six times, twice by me. The number in the rule is what makes it enforceable — a rule that says “avoid” gets argued with and a rule that says 3.73:1 does not.',
  },
  {
    n: 8, k: 'Photography is people working',
    say: 'Crew, ropes, weather, freight. No empty decks and no sunsets without a person in them.',
    applied: 74, held: 41, verdict: 'rewrite',
    broke: 'Thirty-three times, because the marketing lead genuinely needed a sunset for the summer campaign and the rule gave nowhere to go. Rewritten with a named exception rather than pretending the pressure does not exist.',
  },
  {
    n: 9, k: 'The mark is never rotated or outlined',
    say: 'Not on merchandise, not for an anniversary, not once.',
    applied: 31, held: 31, verdict: 'drop',
    broke: 'Never broken, and it never would have been. It is a rule against something nobody wanted to do, which means it is decoration in a document people already find too long. Dropped so the other nine get read.',
  },
  {
    n: 10, k: 'No gradients anywhere',
    say: 'Flat colour only, in every medium.',
    applied: 55, held: 38, verdict: 'drop',
    broke: 'Seventeen times, always on screen, always where a gradient was doing something a flat fill could not — a long deck panel, a fade behind a header photograph. I wrote it out of taste rather than out of a constraint and it cost the identity credibility every time somebody sensibly ignored it.',
  },
];

export const rulesNote =
  'Eighteen months, one operator, eleven landings and six vessels. The two rules marked Drop are ' +
  'the useful part of this page: rule 9 was never broken because nobody ever wanted to break it, ' +
  'which makes it filler in a document that is already too long, and rule 10 was taste with a ' +
  'rule number on it. A guideline that contains rules people are right to ignore teaches everyone ' +
  'that the rules are optional.';

// ── How a rule gets written ──────────────────────────────────────────────

export const howWritten = [
  { k: 'It says what to do, not what to avoid', n: '“All text is Ink” is followable. “Avoid using Flag for text” requires the reader to already know what to use instead, at four in the afternoon, in Word.' },
  { k: 'It contains a number wherever possible', n: 'Half a mark height. 22 mm. 3.73:1. A rule with a number in it is checkable by somebody who is not a designer, and it survives an argument with a fabricator.' },
  { k: 'It names the escape hatch', n: 'What to do when the ideal is impossible — a substitute typeface, a Sand bar over a photograph. Rules without escape hatches are broken silently; rules with them are broken visibly and correctly.' },
  { k: 'It is testable in one glance', n: 'If checking compliance needs a ruler and a colour picker, only a designer will ever check it, which means it will be checked twice.' },
  { k: 'It earns its place', n: 'Every rule costs attention from the ones around it. Ten rules that get read beat forty that get skimmed, and this audit exists to delete rules rather than to add them.' },
];

// ── The order things get made ────────────────────────────────────────────

export const order = [
  { k: 'The sign spec', n: 'First, before the mark is finished. A sign is one colour, 8 mm of stroke at 40 metres, and it constrains the mark more than any other application. Designing the sign last is how a beautiful mark becomes an unreadable one at a ferry landing.' },
  { k: 'The one-colour version', n: 'Second. Stamped parts, embroidery, a fax header that still exists. Anything that survives one colour survives everything.' },
  { k: 'The small version', n: 'Third. 22 mm, then 18 mm, then the avatar crop. Scale down before scaling up; the large version is never the problem.' },
  { k: 'The type system', n: 'Fourth, and chosen for what is installable rather than for what is beautiful. The second-best typeface that everybody has beats the best one that three people have licensed.' },
  { k: 'The colour', n: 'Fifth. Last, deliberately. Colour is the part everybody has an opinion about and the part that survives least intact through print, vinyl, fabric and screen.' },
  { k: 'The document', n: 'Last, and short. Ten rules, four pages, and a folder of files people can use without reading anything.' },
];

// ── Touchpoints ───────────────────────────────────────────────────────────

export const touchpoints = [
  { k: 'Vessel hull and superstructure', who: 'Marine painter, Rockland', pdf: 'No',  n: 'Works from a one-colour vector and a phone call. Has never seen the guidelines and produced the best application on the whole system.' },
  { k: 'Landing signage, eleven sites',  who: 'Two local sign shops',     pdf: 'No',  n: 'One shop reads the spec sheet, the other reads the drawing. Both are right; the guidelines are irrelevant to both.' },
  { k: 'Ticket stock',                   who: 'Printer, Biddeford',       pdf: 'No',  n: 'Where rule 4 died. The printable area was 19 mm and had been for years.' },
  { k: 'Crew uniforms',                  who: 'Embroiderer, Portland',    pdf: 'No',  n: 'One colour, 4 mm stitch. Chose the K mark alone without being told, which is what a correctly built small version does.' },
  { k: 'Timetables and notices',         who: 'Office staff, in Word',    pdf: 'Some', n: 'The highest-volume application by an order of magnitude and the one no identity project ever budgets for. A template was worth more than forty pages of PDF.' },
  { k: 'Social and web',                 who: 'Marketing lead',           pdf: 'Yes', n: 'The only person on this list who has read the document, and the source of most of the sunset problem in rule 8.' },
  { k: 'Vehicle wraps, three vans',      who: 'Installer, from a JPEG',   pdf: 'No',  n: 'Sent a JPEG by someone in a hurry. Survived because the mark works in one colour at a distance, which is rule 3’s real job.' },
];

export const touchNote =
  'Two of seven have opened the guidelines. That is not a failure of the client and it is not ' +
  'unusual — it is the normal condition of every identity that has ever been used by people with ' +
  'other jobs. The document is for the two. The files, the templates and the ten short rules are ' +
  'for the five.';

// ── What a brand is not ───────────────────────────────────────────────────

export const isNot = [
  { t: 'Not the logo',
    d: 'The mark is the smallest deliverable and the one everybody talks about. It appears on this system in seven sizes and one colour, and it took about a tenth of the four months.' },
  { t: 'Not the guidelines document',
    d: 'The document records the decisions. Five of the seven people applying this identity have never opened it and produced correct work anyway, because the files and the templates carried the rules instead.' },
  { t: 'Not a mood board of adjectives',
    d: '“Confident, human, nautical” describes eleven thousand companies. A rule that says all text is Ink describes exactly one, and it can be followed.' },
  { t: 'Not finished at delivery',
    d: 'This audit is the deliverable that matters. It cost a fortnight, it deleted two rules and rewrote two more, and it is the only reason I know rule 4 was written from a letterhead.' },
];

export const files = [
  { t: 'A folder of the right file, per use',
    d: 'One-colour EPS, RGB SVG, a 1:1 avatar lockup, and a 48 px favicon that somebody has actually looked at. Named for where they go, not for what they are.' },
  { t: 'Templates, not instructions',
    d: 'A Word letterhead, a slide deck, a notice template with the type already set. This is what the office actually uses and it is the highest-leverage hour in any identity project.' },
  { t: 'The ten rules on one page',
    d: 'A single side, no images, printable, pinnable. The four-page document exists too and is read by the two people who would have got it right regardless.' },
];

export const needs = [
  { t: 'The worst application you have',
    d: 'The ugliest sign, the oldest van, the form letter from 2019. It tells me more than a brief does, and it is where the constraints live.' },
  { t: 'Whoever actually makes things',
    d: 'The office manager who builds the notices, half an hour, once. Every identity I have got right had that conversation and every one I have got wrong did not.' },
  { t: 'A real measurement of the smallest thing',
    d: 'The printable area on the ticket. The stitch count. The 8 mm stroke on the sign. One measurement, taken rather than assumed, is worth a month of revisions.' },
  { t: 'Permission to come back in eighteen months',
    d: 'A fortnight, a year and a half later, to find out which rules held. It costs less than any other part of the project and it is the only part that produces evidence.' },
];

export const said = {
  text: 'The audit came back saying two of the rules should be deleted and one of them was one we had been apologising for internally for a year. Nobody has ever handed us a document that argued against itself and it is the reason we still use the rest of it.',
  who: 'Operations director, Kestrel Ferry Line — 2026',
};

export const faqs = [
  {
    q: 'Why publish rules you got wrong?',
    a: 'Because a guideline containing rules people are right to ignore teaches everybody that the rules are optional, and that costs the other eight. Rule 10 banned gradients out of taste rather than out of a constraint, and every sensible person who ignored it learned something about how much the document was worth.',
  },
  {
    q: 'Is an audit really a separate piece of work?',
    a: 'A fortnight, eighteen months after delivery. It is the cheapest thing on my rate sheet and the only part of any identity project that produces evidence rather than opinion. Two of these ten rules would still be in the document without it.',
  },
  {
    q: 'What if we cannot install the typeface everywhere?',
    a: 'Then it is the wrong typeface, and that is a decision to make in month one rather than a problem to discover in month twenty. Rule 6 names Georgia as the fallback in the rule itself, which is why forty-two substitutions did not damage the system.',
  },
  {
    q: 'How long should a guidelines document be?',
    a: 'Short enough to be read by somebody who does not want to read it. Ten rules on one printable side, plus a folder of files named for where they go. The long document is for the two people who would have got it right anyway.',
  },
  {
    q: 'Do you design the logo first?',
    a: 'No. The sign specification comes first, before the mark is finished, because a sign is one colour at forty metres and constrains the mark more than any other application. Colour comes last, because it is the part everyone has an opinion about and the part that survives least intact through vinyl, fabric and screen.',
  },
  {
    q: 'Why is your own site almost colourless?',
    a: 'Because the only saturated colour on it belongs to the client. A brand designer’s portfolio competing with the work inside it is a common failure and a slightly embarrassing one. The one place colour appears here is inside the specimen blocks, which is where it belongs.',
  },
];
