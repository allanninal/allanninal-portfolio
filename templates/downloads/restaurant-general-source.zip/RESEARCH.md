# Day 22 — Restaurant (General) — Niche Research

## Persona
**The Cedar & Rye** — a mid-market neighborhood bistro/gastropub in a walkable urban district. Chef-owner Marcus Webb opened it six years ago. The aesthetic is "warm modern American" — wood, linen, candlelight, a chalkboard specials wall — but the site is clean and confident, not rustic. Think Rose's Luxury, Olamaie, Joe Beef energy rather than Eleven Madison Park formality.

## Visual Identity
- **Palette family:** Warm olive / deep charcoal — entirely distinct from all Days 1–21.
  - Background: deep warm charcoal `#1A1A13` (near-black but olive-tinted — candlelit room)
  - Surface cards: `#252519` (slightly lighter charcoal)
  - Surface light: `#2E2E20` (menu card background)
  - Border: `#3A3A28` (subtle olive-tinted border)
  - Accent (olive-gold): `#C4973A` — warm, sophisticated, untaken
  - Accent dark (hover): `#A87C2A`
  - Accent light tint: `#3D3010` — for subtle badge backgrounds
  - Text: `#F0EDE4` (warm off-white, not glaring white on dark)
  - Text muted: `#9A9480` (warm grey-tan)
  - Text faint: `#5A5548`
- **Density:** Medium. Full-width sections, clear visual hierarchy, editorial rhythm. Not sparse (Day 21 wedding) but not bento-dense (Day 2 SaaS). Each section is purposeful.
- **Lighting metaphor:** Everything reads as if lit by warm Edison bulbs. Dark ground, gold accents, cream text.

## Typography
- **Display/Headings:** **Libre Baskerville** — a sturdy, warmly-spaced transitional serif. Confident at large sizes. NOT Playfair Display (Day 17), NOT Cormorant Garamond (Days 15 + 21), NOT Source Serif 4 (Day 9), NOT Lora (Day 11), NOT Fraunces (Day 12), NOT Newsreader (Day 5). Libre Baskerville reads as "neighborhood institution" — letterpress-adjacent, durable.
- **Body/UI:** **Mulish** — clean humanist sans, similar weight to DM Sans but distinct. Readable at menu-item density, doesn't feel sterile.
- Font combination is FRESH: no prior day uses Libre Baskerville or Mulish.

## Schema.org
- `Restaurant` (LocalBusiness subtype) with:
  - `servesCuisine: "Modern American"`
  - `priceRange: "$$"`
  - `acceptsReservations: true`
  - `openingHoursSpecification` — 7-day structured array
  - `aggregateRating` — realistic 4.6/5 from 284 reviews
- `Menu` type — separate restaurant menu items
- `Person` — chef/owner Marcus Webb
- NO `Event` / NO `Offer` — differentiates from Day 20 (conference) and Day 21 (wedding)
- Day 23 coffee-shop will use `CafeOrCoffeeShop` subtype — keep `Restaurant` type fully distinct here

## Sections (single page — full-width scroll)
1. **Hero** — full-screen dark section, restaurant name "The Cedar & Rye", cuisine descriptor + neighborhood, "Make a Reservation →" CTA, subtle grain texture overlay
2. **About** — chef Marcus Webb, origin story, philosophy ("seasonal sourcing, honest cooking"), neighborhood paragraph
3. **Menu** — tabbed: Starters / Mains / Desserts / Drinks. 4–6 real menu items per section with prices. No lorem ipsum.
4. **Hours** — 7-day grid table (Mon–Sun), plus holiday note
5. **Reservations** — prominent CTA to OpenTable placeholder, phone number, walk-in policy note
6. **Press / Awards** — 3 pull quotes from real-feeling press sources (New York Times Dining, Eater, local paper)
7. **Private Events** — small section, inquiry link
8. **Gallery** — 4 food/space SVG placeholder images (CSS art-direction, no Unsplash)
9. **Location** — address, neighborhood map placeholder, parking note, transit
10. **Newsletter** — "Join the chef's table" — email opt-in for seasonal menus and special events
11. **Footer** — name, nav links, contact email placeholder

## Differentiation from prior days
- Day 21 (wedding-invitation-modern): blush/ivory, light bg, Cormorant + DM Sans — entirely different palette register (light vs dark, blush vs olive-charcoal)
- Day 20 (conference-event): dark emerald `#10B981` on near-black — our accent is olive-gold `#C4973A` (completely different hue family); conference vs food/hospitality LocalBusiness context
- Day 18 (course-cohort-landing): deep teal on warm cream — different bg register (cream vs charcoal), different accent (teal vs olive-gold), different schema type
- Day 11 (newsletter-landing): cream + oxblood, light bg — different palette entirely
- Day 8 (agency-studio): burnt orange `#C2410C` on warm off-white — our dark ground inverts the register; burnt orange vs olive-gold
- This is the ONLY dark olive-charcoal + gold palette in the roadmap. The Restaurant type with full openingHoursSpecification is unique.

## Content placeholders (all realistic, no lorem ipsum)
- Restaurant: The Cedar & Rye
- Tagline: Seasonal American Kitchen · Williamsburg, Brooklyn
- Chef/Owner: Marcus Webb
- Address: 142 Metropolitan Avenue, Williamsburg, Brooklyn, NY 11211
- Phone: (718) 555-0142
- Email: hello@cedarandrye.com (placeholder — NOT Allan's real email)
- Cuisine: Modern American
- Price range: $$
- Hours: Mon closed / Tue–Thu 5:00–10:00 PM / Fri 5:00–11:00 PM / Sat 11:00 AM–11:00 PM / Sun 11:00 AM–9:00 PM
- OpenTable reservation link: https://www.opentable.com/restaurant/profile/cedar-and-rye (placeholder)
- Instagram: @cedarandrye (placeholder)

### Menu items (realistic)
**Starters** — Grilled Octopus $18 / Burrata & Stone Fruit $16 / Wagyu Beef Tartare $22 / Roasted Beet Salad $14
**Mains** — Pan-Seared Duck Breast $38 / Seared Halibut $36 / Braised Short Rib $42 / Ricotta Cavatelli (v) $28 / Grilled NY Strip $52
**Desserts** — Valrhona Chocolate Tart $12 / Seasonal Crème Brûlée $11 / Affogato $9 / Cheese Board $18
**Drinks** — Smoky Paloma $16 / The Cedar Old Fashioned $17 / Rye Negroni $15 / Local Draft (rotating) $9

## Color contrast audit (WCAG AA)
- Text `#F0EDE4` on bg `#1A1A13`: 15.4:1 (AAA) ✓
- Muted `#9A9480` on bg `#1A1A13`: 5.2:1 (AA) ✓
- Accent `#C4973A` on bg `#1A1A13`: 5.8:1 (AA) ✓ — safe for headings, large text, and badges
- Accent `#C4973A` on surface `#252519`: 5.5:1 (AA) ✓
- `#F0EDE4` on accent `#C4973A` button: must check — `#F0EDE4` (very light) on `#C4973A` (medium warm gold): ~2.8:1 — FAILS AA
- **CORRECTIVE:** For CTA buttons, use `#1A1A13` (near-black text) on `#C4973A` background — `#1A1A13` on `#C4973A`: 5.8:1 (AA) ✓
- Accent `#A87C2A` (hover): `#1A1A13` on `#A87C2A`: 4.9:1 (AA) ✓
- No opacity modifiers on text — use full-opaque tokens only

## OG / Favicon
- `og-image.svg` + `og-image.png`: dark `#1A1A13` background, "The Cedar & Rye" in Libre Baskerville-approximate serif SVG text, gold accent horizontal rule, "Seasonal American Kitchen · Brooklyn" subtitle in sans. 1200×630.
- `favicon.svg` + `favicon.ico`: gold "C&R" monogram on dark background

## Notes for Day 23 (coffee-shop — closely related)
- Coffee shop will use `CafeOrCoffeeShop` LocalBusiness subtype (not `Restaurant`)
- Should use a LIGHT palette to contrast with this dark template
- Natural palette candidates: warm cream + deep espresso brown, or white + terracotta-brown
- Different font pairing — e.g., Fraunces + Inter Tight or similar
- Coffee shop is typically daytime-only (simpler hours) vs restaurant full day/evening split
- Coffee shop emphasizes signature drinks + sourcing story; restaurant emphasizes chef + full menu
