/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Libre Baskerville"', 'Georgia', 'ui-serif', 'serif'],
        sans: ['"Mulish"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      colors: {
        // Deep warm olive-charcoal + gold — unique to Day 22
        bg:       '#1A1A13',
        surface:  '#252519',
        'surface-light': '#2E2E20',
        border:   '#3A3A28',
        // Olive-gold accent — WCAG AA compliant at full opacity
        accent: {
          DEFAULT: '#C4973A',
          dark:    '#A87C2A',
          light:   '#3D3010',
          dim:     '#8C6A22',
        },
        text: {
          DEFAULT: '#F0EDE4',
          muted:   '#9A9480',
          faint:   '#5A5548',
        },
      },
      fontSize: {
        xs:    ['0.8rem',   { lineHeight: '1.5' }],
        sm:    ['0.9rem',   { lineHeight: '1.55' }],
        base:  ['1rem',     { lineHeight: '1.7' }],
        lg:    ['1.125rem', { lineHeight: '1.65' }],
        xl:    ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.35' }],
        '3xl': ['1.875rem', { lineHeight: '1.25' }],
        '4xl': ['2.25rem',  { lineHeight: '1.15' }],
        '5xl': ['3rem',     { lineHeight: '1.1' }],
        '6xl': ['3.75rem',  { lineHeight: '1.05' }],
        '7xl': ['4.5rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '80rem',
        '8xl': '88rem',
      },
    },
  },
};
