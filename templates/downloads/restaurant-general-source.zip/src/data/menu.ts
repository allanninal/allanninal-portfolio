export type MenuItem = {
  name: string;
  description: string;
  price: string;
  note?: string; // "v" for vegetarian, "gf" for gluten-free, etc.
  dietary?: string[];
};

export type MenuSection = {
  id: string;
  label: string;
  items: MenuItem[];
};

export const menu: MenuSection[] = [
  {
    id: 'starters',
    label: 'Starters',
    items: [
      {
        name: 'Grilled Octopus',
        description: 'Charred tentacles, smoked paprika aioli, pickled Fresno chiles, fingerling potato',
        price: '$18',
        dietary: ['gf'],
      },
      {
        name: 'Burrata & Stone Fruit',
        description: 'Fresh burrata, grilled peach, torn basil, aged balsamic, torn sourdough croutons',
        price: '$16',
        dietary: ['v'],
      },
      {
        name: 'Wagyu Beef Tartare',
        description: 'Hand-chopped wagyu, dijon, capers, soft egg yolk, sourdough crisps',
        price: '$22',
      },
      {
        name: 'Roasted Beet Salad',
        description: 'Golden and candy-stripe beets, whipped goat cheese, candied walnuts, tarragon vinaigrette',
        price: '$14',
        dietary: ['v', 'gf'],
      },
      {
        name: 'Clam Chowder',
        description: 'New England style, local littlenecks, smoked bacon, chive oil, oyster crackers',
        price: '$15',
      },
    ],
  },
  {
    id: 'mains',
    label: 'Mains',
    items: [
      {
        name: 'Pan-Seared Duck Breast',
        description: 'Muscovy duck, sour cherry gastrique, roasted root vegetables, duck fat potato cake',
        price: '$38',
        dietary: ['gf'],
      },
      {
        name: 'Seared Halibut',
        description: 'Pacific halibut, brown butter, caperberries, summer squash, heirloom tomato salsa verde',
        price: '$36',
        dietary: ['gf'],
      },
      {
        name: 'Braised Short Rib',
        description: '48-hour red wine braise, celery root purée, gremolata, pickled shallots',
        price: '$42',
        dietary: ['gf'],
      },
      {
        name: 'Ricotta Cavatelli',
        description: 'Hand-rolled cavatelli, roasted wild mushrooms, truffle butter, pecorino, herb oil',
        price: '$28',
        dietary: ['v'],
      },
      {
        name: 'Grilled NY Strip',
        description: '14 oz dry-aged strip, compound herb butter, bone marrow, charred scallion, house frites',
        price: '$52',
        dietary: ['gf'],
      },
    ],
  },
  {
    id: 'desserts',
    label: 'Desserts',
    items: [
      {
        name: 'Valrhona Chocolate Tart',
        description: 'Dark chocolate ganache, fleur de sel, crème fraîche, cocoa tuile',
        price: '$12',
        dietary: ['v'],
      },
      {
        name: 'Seasonal Crème Brûlée',
        description: 'This week: lavender-honey with fresh blueberry compote',
        price: '$11',
        dietary: ['v', 'gf'],
      },
      {
        name: 'Affogato',
        description: 'Two scoops Stumptown vanilla bean ice cream, double espresso, Amaro Montenegro',
        price: '$9',
        dietary: ['v', 'gf'],
      },
      {
        name: 'Artisan Cheese Board',
        description: 'Three selections from Murray\'s Cheese, seasonal accoutrements, honeycomb, house crackers',
        price: '$18',
        dietary: ['v'],
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Drinks',
    items: [
      {
        name: 'The Cedar Old Fashioned',
        description: 'Cedar-infused rye, Angostura, Demerara, orange peel, smoked boulder cherry',
        price: '$17',
      },
      {
        name: 'Rye Negroni',
        description: 'Rittenhouse rye, Campari, sweet vermouth, orange bitters, expressed orange',
        price: '$15',
      },
      {
        name: 'Smoky Paloma',
        description: 'Mezcal, fresh grapefruit, Aperol, smoked salt rim, sparkling water',
        price: '$16',
      },
      {
        name: 'The Garden Spritz',
        description: 'Elderflower liqueur, cucumber, fresh lime, prosecco, mint',
        price: '$14',
        dietary: ['v'],
      },
      {
        name: 'Local Draft (Rotating)',
        description: 'Ask your server for today\'s selection — always sourced from Brooklyn and Hudson Valley breweries',
        price: '$9',
      },
      {
        name: 'Non-Alcoholic: Shrub Soda',
        description: 'House-made shrub (seasonal fruit + apple cider vinegar), sparkling water, herb garnish',
        price: '$8',
        dietary: ['v', 'gf'],
      },
    ],
  },
];
