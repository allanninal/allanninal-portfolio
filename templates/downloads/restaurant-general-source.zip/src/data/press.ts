export type PressQuote = {
  quote: string;
  source: string;
  author?: string;
  url?: string;
};

export const pressQuotes: PressQuote[] = [
  {
    quote:
      'Marcus Webb has done something rare: built a neighborhood restaurant that feels essential — not just convenient. The braised short rib alone warrants a pilgrimage.',
    source: 'The New York Times Dining',
    author: 'Pete Wells',
  },
  {
    quote:
      'The Cedar & Rye is exactly the kind of place Williamsburg needed: warm, chef-driven, and free of pretension. Go for the duck. Stay for the Old Fashioned.',
    source: 'Eater NY',
  },
  {
    quote:
      "One of Brooklyn's most dependable kitchens. Webb's seasonal menu changes every six weeks, and somehow it keeps getting better.",
    source: 'Brooklyn Magazine',
    author: 'Danielle Torres',
  },
];

export const awards = [
  { label: 'Bib Gourmand', source: 'MICHELIN Guide NYC', year: '2023' },
  { label: 'Best New Restaurant', source: 'Brooklyn Magazine', year: '2019' },
  { label: 'Top 10 Neighborhood Spots', source: 'Eater NY', year: '2022' },
];
