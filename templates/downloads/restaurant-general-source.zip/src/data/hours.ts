export type DayHours = {
  day: string;
  dayFull: string;
  open: string | null;
  close: string | null;
  note?: string;
};

export const hours: DayHours[] = [
  { day: 'Mon', dayFull: 'Monday',    open: null,     close: null,     note: 'Closed' },
  { day: 'Tue', dayFull: 'Tuesday',   open: '5:00 PM', close: '10:00 PM' },
  { day: 'Wed', dayFull: 'Wednesday', open: '5:00 PM', close: '10:00 PM' },
  { day: 'Thu', dayFull: 'Thursday',  open: '5:00 PM', close: '10:00 PM' },
  { day: 'Fri', dayFull: 'Friday',    open: '5:00 PM', close: '11:00 PM' },
  { day: 'Sat', dayFull: 'Saturday',  open: '11:00 AM', close: '11:00 PM', note: 'Brunch + Dinner' },
  { day: 'Sun', dayFull: 'Sunday',    open: '11:00 AM', close: '9:00 PM',  note: 'Brunch + Dinner' },
];

// openingHoursSpecification schema.org format
export const openingHoursSpec = [
  { dayOfWeek: 'http://schema.org/Tuesday',   opens: '17:00', closes: '22:00' },
  { dayOfWeek: 'http://schema.org/Wednesday', opens: '17:00', closes: '22:00' },
  { dayOfWeek: 'http://schema.org/Thursday',  opens: '17:00', closes: '22:00' },
  { dayOfWeek: 'http://schema.org/Friday',    opens: '17:00', closes: '23:00' },
  { dayOfWeek: 'http://schema.org/Saturday',  opens: '11:00', closes: '23:00' },
  { dayOfWeek: 'http://schema.org/Sunday',    opens: '11:00', closes: '21:00' },
];
