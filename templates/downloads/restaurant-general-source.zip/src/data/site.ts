export const site = {
  name: 'The Cedar & Rye',
  tagline: 'Seasonal American Kitchen',
  neighborhood: 'Williamsburg, Brooklyn',
  description:
    'A neighborhood bistro in Williamsburg, Brooklyn serving seasonal American cuisine from honest, locally sourced ingredients. Warmth and craft.',
  cuisine: 'Modern American',
  priceRange: '$$',
  phone: '(718) 555-0142',
  phoneDisplay: '(718) 555-0142',
  email: 'hello@cedarandrye.com',
  address: {
    street: '142 Metropolitan Avenue',
    city: 'Brooklyn',
    state: 'NY',
    zip: '11211',
    full: '142 Metropolitan Avenue, Williamsburg, Brooklyn, NY 11211',
    country: 'US',
  },
  geo: {
    lat: 40.7141,
    lng: -73.9526,
  },
  mapUrl: 'https://maps.google.com/?q=142+Metropolitan+Avenue+Brooklyn+NY+11211',
  reservationUrl: 'https://www.opentable.com/restaurant/profile/cedar-and-rye',
  privateEventsEmail: 'events@cedarandrye.com',
  instagram: '@cedarandrye',
  instagramUrl: 'https://instagram.com/cedarandrye',
  rating: {
    value: 4.6,
    count: 284,
    max: 5,
  },
  og: {
    alt: 'The Cedar & Rye — Seasonal American Kitchen in Williamsburg, Brooklyn',
  },
};

export const chef = {
  name: 'Marcus Webb',
  title: 'Chef & Owner',
  bio: `Marcus Webb grew up eating at his grandmother's table in Richmond, Virginia — where Sunday supper meant slow-cooked greens, hand-rolled biscuits, and a house that smelled like possibility. That memory drives everything at The Cedar & Rye.

After training under James Beard Award–winning chef Elena Vasquez at Meridian in San Francisco and a stage at a two-Michelin-star kitchen in Lyon, Marcus returned east and opened The Cedar & Rye in 2018 with a simple conviction: the best cooking starts at the farmers market, not a flavor lab.

He changes the menu every six weeks. He knows his beef farmer by first name. He believes dessert should never be an afterthought.`,
  philosophy:
    'Seasonal sourcing. Honest cooking. The belief that a neighborhood restaurant should feel like the best version of home.',
};
