# The Cedar & Rye — Restaurant Template

**Day 22 of 365** — Free, MIT-licensed static website template for a mid-market neighborhood restaurant.

[Live Demo](https://templates.allanninal.dev/restaurant-general/) · [All 365 Templates](https://templates.allanninal.dev)

---

## What's in the box

A complete single-page restaurant website for a modern American bistro / gastropub persona. Sections:

- **Hero** — full-screen dark with restaurant name, cuisine descriptor, reservation CTA
- **About** — chef/owner bio, philosophy, neighborhood story
- **Menu** — tabbed Starters / Mains / Desserts / Drinks with prices and dietary tags
- **Hours** — 7-day grid table with special day notes
- **Reservations** — OpenTable/Resy/Tock placeholder CTA, phone, walk-in policy
- **Press & Awards** — 3 pull-quote cards (NYT Dining, Eater, local press), MICHELIN Bib Gourmand badge
- **Private Events** — buyout / catering inquiry with stat cards
- **Gallery** — 4 CSS art-direction placeholder images (no external assets required)
- **Location** — address, SVG map placeholder, transit + parking notes
- **Newsletter** — email opt-in for events and seasonal menu drops

### Technical details

- **Stack:** Astro 4 · Tailwind CSS 3 · TypeScript
- **Fonts:** Libre Baskerville (display) · Mulish (body/UI) — self-hosted via @fontsource
- **Schema.org:** `Restaurant` with `openingHoursSpecification` (7-day), `AggregateRating`, `servesCuisine`, `acceptsReservations`; `Menu`; `Person` (chef)
- **Performance:** Static output, self-hosted fonts, no external CDN calls
- **Accessibility:** WCAG 2.1 AA compliant — full-opacity tokens, no opacity modifiers on text, dark text on gold CTA buttons

---

## Quick start

```bash
# 1. Clone or download this template
git clone https://github.com/allanninal/templates
cd templates/templates/restaurant-general

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev

# 4. Build for production
PUBLIC_BASE_PATH=/ npm run build
```

## Environment variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

| Variable | Default | Description |
|---|---|---|
| `PUBLIC_BASE_PATH` | `/restaurant-general/` | Base path for asset resolution. Use `/` for standalone deploys. |
| `PUBLIC_SITE_URL` | `https://example.com` | Canonical site URL for sitemap and OG tags. |
| `PUBLIC_TEMPLATE_HUB_URL` | *(blank)* | Author-only. When set, enables the TemplateInfo download bar and Google Analytics. Leave blank when cloning. |

## Customizing

All copy lives in `src/data/`:
- `site.ts` — restaurant name, address, phone, social links, chef bio
- `menu.ts` — menu sections and items with prices and dietary tags
- `hours.ts` — 7-day opening hours
- `press.ts` — pull quotes and awards

Palette and typography live in `tailwind.config.mjs` and `src/styles/global.css`.

## Deploy

Works on any static host. One-click deploys:

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/allanninal/templates)

For GitHub Pages, use the included `.github/workflows/pages.yml`. Set `PUBLIC_BASE_PATH=/` in the workflow env.

---

MIT License · [Allan Niñal](https://templates.allanninal.dev)
