import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
// Day 132 — jewelry-designer. Change this line if you fork the template — a
// leftover slug here builds with every asset resolving under the wrong
// base path and the page renders with no CSS at all.
const BASE = process.env.PUBLIC_BASE_PATH || '/jewelry-designer/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [
    tailwind({ applyBaseStyles: false }),
  ],
});
