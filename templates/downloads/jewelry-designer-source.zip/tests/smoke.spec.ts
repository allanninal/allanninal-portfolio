import { test, expect } from '@playwright/test';

test.describe('Kelham Bench Jewellery — smoke tests', () => {
  test('the hero leads with the formula claim, not a fixed price', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Kelham Bench Jewellery/);
    await expect(page.locator('h1')).toContainText(/Gold at \$142\.86\/g today/i);
  });

  test('primary nav is the page spine, not Home/About/Services', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Primary' });
    const links = await nav.getByRole('link').allTextContents();
    expect(links).toEqual(['The formula', 'Worked presets', 'Hallmarks', 'Stones', 'Sizing', 'Metal care', 'Store', 'FAQ']);
  });

  // ── The configurator (JS on) ─────────────────────────────────────────────
  test('the default configurator total is computed, matching the exact arithmetic', async ({ page }) => {
    await page.goto('/');
    const output = page.locator('#quote-output');
    await expect(output).toContainText('$109.38');
    await expect(output).toContainText('$6.96'); // metal cost, 3.5g sterling * 0.925 * $2.15/g
    await expect(output).toContainText('$102.00'); // 1.5hr * $68/hr labour
  });

  test('changing an input recomputes the total live, debounced (aria-live polite)', async ({ page }) => {
    await page.goto('/');
    const output = page.locator('#quote-output');
    await expect(output).toHaveAttribute('aria-live', 'polite');
    await page.locator('#grams').fill('10');
    await page.locator('#grams').dispatchEvent('input');
    // 10g sterling: 10 * 0.925 * 2.15 = 19.8875 -> 19.89, over the 7.78g silver
    // hallmark threshold, so the fee line should now read "Required".
    await expect(output).toContainText('$10.55', { timeout: 2000 });
    await expect(output).not.toContainText('not required at this weight');
  });

  test('changing the metal select recomputes immediately, no debounce needed', async ({ page }) => {
    await page.goto('/');
    await page.locator('#metal').selectOption('18k');
    const output = page.locator('#quote-output');
    // 3.5g 18k gold: 3.5 * 0.750 * 142.86 = 375.0075 -> 375.01
    await expect(output).toContainText('$375.01');
  });

  // ── The formula ───────────────────────────────────────────────────────────
  test('the formula ol lists all seven steps in order', async ({ page }) => {
    await page.goto('/');
    const items = await page.locator('#formula ol.seq li .k').allTextContents();
    expect(items).toEqual([
      'Weigh the metal', 'Apply fineness', "Multiply by today's spot",
      'Add labour', 'Add stone cost', 'Add wastage', 'The total',
    ]);
  });

  // ── Worked presets — the JS-off fallback, same numbers as the live tool ──
  test('the worked-presets table computes the exact same arithmetic as the configurator', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#presets table.spec tbody tr');
    await expect(rows).toHaveCount(3);
    await expect(rows.nth(0)).toContainText('$105.57'); // 3mm sterling band
    await expect(rows.nth(1)).toContainText('$1,859.65'); // 1ct solitaire
    await expect(rows.nth(2)).toContainText('$708.69'); // signet
  });

  test('hallmark fee is charged only on presets that clear the legal weight threshold', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#presets table.spec tbody tr');
    await expect(rows.nth(0)).toContainText('n/a'); // 3.2g sterling, under 7.78g silver threshold
    await expect(rows.nth(1)).toContainText('$22.00'); // 4.1g 18k gold, over 1g gold threshold
    await expect(rows.nth(2)).toContainText('$22.00'); // 8.5g 9k gold, over 1g gold threshold
  });

  // ── Hallmarks ─────────────────────────────────────────────────────────────
  test('four assay office figures render, Sheffield carries the sponsor\'s mark', async ({ page }) => {
    await page.goto('/');
    const figures = page.locator('#hallmarks figure.hallmark-figure');
    await expect(figures).toHaveCount(4);
    const sheffield = page.locator('#hallmarks figure.is-studio-office');
    await expect(sheffield).toHaveCount(1);
    await expect(sheffield).toContainText('Sheffield');
    await expect(sheffield).toContainText('IV');
  });

  test('legal hallmarking thresholds table lists all four metals', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#hallmarks table.spec tbody tr');
    await expect(rows).toHaveCount(4);
    await expect(rows).toContainText(['Gold', 'Silver', 'Platinum', 'Palladium']);
  });

  // ── Stones ────────────────────────────────────────────────────────────────
  test('the carat-to-diameter figure renders four sizes', async ({ page }) => {
    await page.goto('/');
    const svg = page.locator('#stones svg[role="img"]');
    await expect(svg).toHaveCount(1);
    const label = await svg.getAttribute('aria-label');
    expect(label).toMatch(/0\.5 carat/);
    expect(label).toMatch(/2 carat/);
  });

  test('the lab-grown vs mined price gap and FTC disclosure are both stated', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#stones').innerText();
    expect(text).toMatch(/\$4,000/);
    expect(text).toMatch(/\$750/);
    expect(text).toMatch(/FTC/);
  });

  // ── Sizing ────────────────────────────────────────────────────────────────
  test('the ring-size table has US, UK, EU and mm columns', async ({ page }) => {
    await page.goto('/');
    const headers = await page.locator('#sizing table.spec thead th').allTextContents();
    expect(headers).toEqual(['US', 'UK', 'EU', 'Circumference']);
    expect(await page.locator('#sizing table.spec tbody tr').count()).toBeGreaterThanOrEqual(8);
  });

  // ── Metal care ────────────────────────────────────────────────────────────
  test('the rhodium schedule states interval, per-visit cost and a 10-year total', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#metal-care').innerText();
    expect(text).toMatch(/12.{1,2}24 months/);
    expect(text).toMatch(/\$60\.00.{1,2}\$120\.00/);
    expect(text).toMatch(/\$400\.00.{1,2}\$1,000\.00/);
  });

  // ── Store ─────────────────────────────────────────────────────────────────
  test('the store lists between 6 and 8 fixed-price pieces', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#store .store-card');
    const count = await cards.count();
    expect(count).toBeGreaterThanOrEqual(6);
    expect(count).toBeLessThanOrEqual(8);
    for (let i = 0; i < count; i++) {
      await expect(cards.nth(i).locator('.price')).toContainText('$');
    }
  });

  // ── Schema ────────────────────────────────────────────────────────────────
  test('JewelryStore carries the sponsor\'s mark as identifier, withholds priceRange and aggregateRating', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const storeBlock = blocks.find((b) => b.includes('"JewelryStore"'))!;
    const store = JSON.parse(storeBlock);
    expect(store.identifier.value).toBe('IV');
    expect(store.priceRange).toBeUndefined();
    expect(store.aggregateRating).toBeUndefined();
  });

  test('every store Product carries a settled price and Offer', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const productBlock = blocks.find((b) => b.includes('"Product"'))!;
    const products = JSON.parse(productBlock)['@graph'];
    expect(products.length).toBeGreaterThanOrEqual(6);
    for (const p of products) {
      expect(typeof p.offers.price).toBe('number');
      expect(p.offers.availability).toBe('https://schema.org/InStock');
      expect(p.gtin).toBeUndefined();
      expect(p.mpn).toBeUndefined();
    }
  });

  test('the commission Service carries no price, no priceRange and no offers at all', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const serviceBlock = blocks.find((b) => b.includes('"Service"'))!;
    const service = JSON.parse(serviceBlock);
    expect(service.price).toBeUndefined();
    expect(service.priceRange).toBeUndefined();
    expect(service.offers).toBeUndefined();
    expect(service.priceValidUntil).toBeUndefined();
  });

  test('no priceValidUntil is emitted anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    expect(html).not.toContain('priceValidUntil');
  });

  // ── Commissions form ──────────────────────────────────────────────────────
  test('the commission form requires the essentials and names a man-woman couple context', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#occasion', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    const text = await page.locator('#commission').innerText();
    expect(text).toMatch(/a man and a woman/i);
  });

  // ── Contact ───────────────────────────────────────────────────────────────
  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('.contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Quote rail ────────────────────────────────────────────────────────────
  test('the quote rail mirrors the same total the hero computes', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.goto('/');
    await expect(page.locator('#quote-rail-total')).toContainText('$109.38');
    await page.locator('#metal').selectOption('18k');
    // 3.5g 18k: metal 375.01 + labour 102.00 + wastage 22.50 + hallmark fee 22.00 (over the 1g gold threshold)
    await expect(page.locator('#quote-rail-total')).toContainText('$521.51');
  });

  // ── Hygiene ───────────────────────────────────────────────────────────────
  test('no trace of the day-130/131 source templates survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['teresa', 'ibarra', 'painting', 'varnish', 'iris calder', 'firing', 'kiln']) {
      expect(html, `earlier-day copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1920, 1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/ux-designer-portfolio/i);
  });

  // The Commission Quote Sheet is Pro-only. In the free build it must not be
  // reachable as real content — Astro.redirect() renders it as a meta-refresh
  // stub — and it must not be linked from the homepage.
  test('the Pro Commission Quote Sheet is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="quote-sheet"]').count()).toBe(0);

    const res = await page.goto('/quote-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
