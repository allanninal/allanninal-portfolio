import { test, expect } from '@playwright/test';

// Hard requirement from RESEARCH.md: the configurator must work with
// JavaScript disabled. This spec runs in its own browser context with
// javaScriptEnabled: false, and asserts the page degrades to a genuinely
// usable, non-blank, non-broken state — not merely "doesn't crash".
test.describe('configurator with JavaScript disabled', () => {
  test.use({ javaScriptEnabled: false });

  test('the form still renders every input, with sensible defaults', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#quote-form')).toBeVisible();
    await expect(page.locator('#metal')).toBeVisible();
    await expect(page.locator('#grams')).toHaveValue('3.5');
    await expect(page.locator('#stone-cost')).toHaveValue('0');
    await expect(page.locator('#labour-hours')).toHaveValue('1.5');
  });

  test('the output box shows a real, computed total — not blank, not broken', async ({ page }) => {
    await page.goto('/');
    const output = page.locator('#quote-output');
    await expect(output).toBeVisible();
    // Server-rendered from the exact same computeQuote() the live JS version
    // would call — 3.5g sterling, 1.5hr labour, no stone.
    await expect(output).toContainText('$109.38');
    await expect(output).toContainText('$3.69');
    await expect(output).toContainText('$102.00');
  });

  test('a noscript note explains the calculator needs JS and points at the worked presets', async ({ page }) => {
    await page.goto('/');
    // <noscript> content is real DOM when JS is off — the browser parses it
    // as ordinary markup rather than an opaque, unparsed text node.
    const note = page.locator('#quote-js-note');
    await expect(note).toBeVisible();
    await expect(note).toContainText(/needs JavaScript/i);
    const presetsLink = note.getByRole('link', { name: /worked presets/i });
    await expect(presetsLink).toHaveAttribute('href', '#presets');
  });

  test('the worked-presets table renders in full and computes the same arithmetic', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#presets table.spec tbody tr');
    await expect(rows).toHaveCount(3);
    await expect(rows.nth(0)).toContainText('$105.57');
    await expect(rows.nth(1)).toContainText('$1,859.65');
    await expect(rows.nth(2)).toContainText('$708.69');
  });

  test('the rest of the page — hallmarks, sizing, store, FAQ — renders without script', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#hallmarks figure.hallmark-figure')).toHaveCount(4);
    await expect(page.locator('#sizing table.spec tbody tr').first()).toBeVisible();
    await expect(page.locator('#store .store-card').first()).toBeVisible();
    await expect(page.locator('#faq details.faq-item').first()).toBeVisible();
  });

  test('changing an input without JS does not blank or break the output — it simply does not update', async ({ page }) => {
    await page.goto('/');
    await page.locator('#grams').fill('99');
    // No listener is attached (no script executed), so the output legitimately
    // still shows the server-rendered default rather than a recomputed
    // figure — the point under test is that it stays a valid total, never
    // an empty box or a JS error.
    const output = page.locator('#quote-output');
    await expect(output).toContainText('$109.38');
    await expect(output).not.toBeEmpty();
  });
});
