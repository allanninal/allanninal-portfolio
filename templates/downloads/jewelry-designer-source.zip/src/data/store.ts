// Ready-to-wear store items — each already cast at a known weight against a
// spot price already paid, so each gets a real, settled price and a real
// Product + Offer in schema. This is the opposite case from the custom
// commission below it on the page: a piece here is fixed the moment it's
// cast, not evaluated the day it's read. See RESEARCH.md, "The axis" and
// "Schema.org". Named after Sheffield neighbourhoods, a small, deliberate
// nod to the studio's real city — same device as Imogen's Sheffield-rose
// hallmark citation.
import type { MetalId } from '~/data/pricing';

export type StoreItem = {
  id: string;
  title: string;
  form: 'Stacking band' | 'Signet ring' | 'Hoop earrings' | 'Chain bracelet';
  metalId: MetalId;
  description: string;
  priceUSD: number;
  sku: string;
};

export const STORE_ITEMS: StoreItem[] = [
  {
    id: 'kelham-band-9k',
    title: 'Kelham Stacking Band, 2 mm',
    form: 'Stacking band',
    metalId: '9k',
    description: '9k gold, 2 mm half-round profile. Sits flush against a solitaire without crowding it.',
    priceUSD: 185,
    sku: 'KBJ-BAND-9K-2',
  },
  {
    id: 'kelham-band-sterling',
    title: 'Kelham Stacking Band, 2 mm',
    form: 'Stacking band',
    metalId: 'sterling',
    description: 'The same 2 mm profile in sterling silver — an everyday stack, not a special-occasion one.',
    priceUSD: 65,
    sku: 'KBJ-BAND-AG-2',
  },
  {
    id: 'rivelin-signet-14k',
    title: 'Rivelin Signet Ring',
    form: 'Signet ring',
    metalId: '14k',
    description: '14k gold, hand-engraved oval face, ready for a monogram or left plain.',
    priceUSD: 890,
    sku: 'KBJ-SIG-14K',
  },
  {
    id: 'rivelin-signet-sterling',
    title: 'Rivelin Signet Ring',
    form: 'Signet ring',
    metalId: 'sterling',
    description: 'The same oval-face signet in sterling silver.',
    priceUSD: 210,
    sku: 'KBJ-SIG-AG',
  },
  {
    id: 'loxley-hoops-9k',
    title: 'Loxley Hoop Earrings, 12 mm',
    form: 'Hoop earrings',
    metalId: '9k',
    description: '9k gold, 12 mm diameter, hinged post — small enough for daily wear.',
    priceUSD: 245,
    sku: 'KBJ-HOOP-9K-12',
  },
  {
    id: 'loxley-hoops-sterling',
    title: 'Loxley Hoop Earrings, 12 mm',
    form: 'Hoop earrings',
    metalId: 'sterling',
    description: 'The same 12 mm hoop in sterling silver.',
    priceUSD: 75,
    sku: 'KBJ-HOOP-AG-12',
  },
  {
    id: 'portobello-wide-band-18k',
    title: 'Portobello Wide Band, 6 mm',
    form: 'Stacking band',
    metalId: '18k',
    description: '18k gold, 6 mm flat-court profile — worn alone, not stacked.',
    priceUSD: 1240,
    sku: 'KBJ-BAND-18K-6',
  },
  {
    id: 'crookes-chain-bracelet',
    title: 'Crookes Chain Bracelet',
    form: 'Chain bracelet',
    metalId: 'sterling',
    description: 'Sterling silver curb-link bracelet, 18 cm, lobster clasp.',
    priceUSD: 145,
    sku: 'KBJ-BRC-AG',
  },
];
