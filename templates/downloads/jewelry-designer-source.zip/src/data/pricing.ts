// The single source of every number this template computes. The configurator,
// the worked-example table (JS-off fallback), the Commission Quote Sheet
// (Pro), and the store's fixed-price catalogue all read from this file and
// from src/lib/quote.ts — never a second, independently-typed copy of the
// same figure. See RESEARCH.md, "The axis".
//
// ── Spot prices: build-time constants, not a live fetch ─────────────────
// Nothing in this template calls a pricing API. Whoever runs this studio
// updates ONE line here whenever they want a fresh quote, and every
// derived number on the page moves with it. Both figures are real
// observations on the stated date from the stated dealer — gold from
// RESEARCH.md, silver looked up separately at the same date and dealer.
// Neither is a placeholder: a template whose whole argument is that a
// price is a dated formula cannot itself ship an undated guess.
export const GOLD_SPOT = {
  metal: 'Gold' as const,
  pricePerGramUSD: 142.86,
  observedDate: '2026-09-06',
  source: 'JM Bullion',
  sourceUrl: 'https://www.jmbullion.com/charts/gold-price/',
};

export const SILVER_SPOT = {
  metal: 'Silver' as const,
  pricePerGramUSD: 2.15,
  observedDate: '2026-09-06',
  source: 'JM Bullion',
  sourceUrl: 'https://www.jmbullion.com/charts/silver-price/',
};

export function spotForMetalType(metalType: 'gold' | 'silver'): number {
  return metalType === 'gold' ? GOLD_SPOT.pricePerGramUSD : SILVER_SPOT.pricePerGramUSD;
}

// ── Fineness — a legal fact, not a marketing claim ───────────────────────
// 9k = 375/1000, 14k = 585/1000, 18k = 750/1000, sterling = 925/1000.
// Source: IIFL gold-purity chart / AJLuxe gold-purity guide (RESEARCH.md).
export type MetalId = 'sterling' | '9k' | '14k' | '18k';

export type Metal = {
  id: MetalId;
  label: string;
  metalType: 'gold' | 'silver';
  finenessPer1000: number;
};

export const METALS: Record<MetalId, Metal> = {
  sterling: { id: 'sterling', label: 'Sterling silver', metalType: 'silver', finenessPer1000: 925 },
  '9k': { id: '9k', label: '9k gold', metalType: 'gold', finenessPer1000: 375 },
  '14k': { id: '14k', label: '14k gold', metalType: 'gold', finenessPer1000: 585 },
  '18k': { id: '18k', label: '18k gold', metalType: 'gold', finenessPer1000: 750 },
};

export const METAL_ORDER: MetalId[] = ['sterling', '9k', '14k', '18k'];

// ── Labour — this studio's own stated rate, not an industry benchmark ────
// The research turned up no reliable public figure for independent
// bench-jeweller shop billing rates — only employed-wage data (ZipRecruiter,
// bench-jeweler hourly wage, Sept 2026). Presented on the page as Kelham
// Bench's own rate, never as a market average.
export const STUDIO_LABOUR_RATE_USD_PER_HOUR = 68;

// ── Wastage — offcuts, filing dust and polishing loss on the metal itself.
export const WASTAGE_RATE = 0.06;

// ── Hallmarking — a legally struck third-party mark, not the jeweller's word.
// Source: Edinburgh Assay Office / ComplianceGate UK hallmarking guides,
// Kernowcraft hallmarking Q&A (RESEARCH.md).
export type AssayOfficeId = 'london' | 'birmingham' | 'sheffield' | 'edinburgh';

export type AssayOffice = {
  id: AssayOfficeId;
  name: string;
  mark: string;
  markDescription: string;
  foundedYear: number;
  isStudioOffice: boolean;
};

export const ASSAY_OFFICES: AssayOffice[] = [
  { id: 'london', name: 'London', mark: "Leopard's head", markDescription: 'A crowned leopard’s head, the oldest hallmark in continuous use anywhere.', foundedYear: 1478, isStudioOffice: false },
  { id: 'birmingham', name: 'Birmingham', mark: 'Anchor', markDescription: 'An anchor, chosen by a coin toss over Sheffield’s crossed swords in 1773.', foundedYear: 1773, isStudioOffice: false },
  { id: 'sheffield', name: 'Sheffield', mark: 'Rose', markDescription: 'A Tudor rose, adopted in 1975 after the office began life in 1773 marking crossed swords.', foundedYear: 1773, isStudioOffice: true },
  { id: 'edinburgh', name: 'Edinburgh', mark: 'Castle', markDescription: 'A three-towered castle, Scotland’s assay mark since the office’s founding.', foundedYear: 1457, isStudioOffice: false },
];

export type HallmarkThreshold = { metal: string; thresholdGrams: number };
export const HALLMARK_THRESHOLDS: HallmarkThreshold[] = [
  { metal: 'Gold', thresholdGrams: 1 },
  { metal: 'Silver', thresholdGrams: 7.78 },
  { metal: 'Platinum', thresholdGrams: 0.5 },
  { metal: 'Palladium', thresholdGrams: 1 },
];

export const HALLMARKING_FEE_USD = 22;

export const SPONSOR_MARK = {
  studioName: 'Kelham Bench Jewellery',
  initials: 'IV',
  makerName: 'Imogen Vasey',
  office: 'Sheffield' as const,
  registeredSince: 2019,
};

/** Requires a hallmark: true when the piece's metal weight clears the legal threshold for that metal. */
export function requiresHallmark(metalType: 'gold' | 'silver', grams: number): boolean {
  const row = HALLMARK_THRESHOLDS.find((t) => t.metal.toLowerCase() === metalType);
  return row ? grams > row.thresholdGrams : false;
}

// ── Stones — carat-to-diameter, and the lab-grown vs mined price gap ─────
// Source: VRAI / Beyond4Cs diamond-size charts; idyl / The Diamond Guys
// 2026 lab-grown vs mined pricing (RESEARCH.md).
export type CaratRow = { carat: number; mm: number };
export const CARAT_TO_MM: CaratRow[] = [
  { carat: 0.5, mm: 5.2 },
  { carat: 1, mm: 6.5 },
  { carat: 1.5, mm: 7.4 },
  { carat: 2, mm: 8.2 },
];

export const LAB_VS_MINED = {
  grade: '1 ct, G colour / VS2 clarity',
  minedLowUSD: 4000,
  minedHighUSD: 8000,
  labGrownLowUSD: 750,
  labGrownHighUSD: 1500,
  ftcNote:
    'Under the FTC Jewelry Guides (16 CFR Part 23), a lab-grown stone must be disclosed as lab-grown at first mention — it is chemically, optically and physically the same material as a mined stone, at a fraction of the price, and it is not something a studio quietly upgrades a customer into.',
};

// ── Ring sizing — US / UK / EU / circumference in mm ──────────────────────
// Source: 25karats / Antoanetta ring-size conversion charts (RESEARCH.md).
export type RingSizeRow = { us: string; uk: string; eu: string; mm: number };
export const RING_SIZES: RingSizeRow[] = [
  { us: '3', uk: 'F', eu: '44.0', mm: 44.0 },
  { us: '4', uk: 'H½', eu: '46.8', mm: 46.8 },
  { us: '5', uk: 'J½', eu: '49.3', mm: 49.3 },
  { us: '6', uk: 'L½', eu: '51.9', mm: 51.9 },
  { us: '7', uk: 'N½', eu: '54.4', mm: 54.4 },
  { us: '8', uk: 'P½', eu: '57.0', mm: 57.0 },
  { us: '9', uk: 'R½', eu: '59.5', mm: 59.5 },
  { us: '10', uk: 'T½', eu: '62.1', mm: 62.1 },
  { us: '11', uk: 'V½', eu: '64.6', mm: 64.6 },
];

// ── Rhodium replate schedule — the recurring cost white-gold buyers are
// routinely not quoted up front. Source: J.H. Young Jewellers / Martin Inc.
// rhodium-plating cost and care guides (RESEARCH.md).
export const RHODIUM_SCHEDULE = {
  intervalMonthsLow: 12,
  intervalMonthsHigh: 24,
  costPerVisitLowUSD: 60,
  costPerVisitHighUSD: 120,
  tenYearTotalLowUSD: 400,
  tenYearTotalHighUSD: 1000,
};

// ── Worked presets — the JS-off fallback, computed by the exact same
// function the live configurator calls. See src/lib/quote.ts.
export type PresetId = 'band' | 'solitaire' | 'signet';
export type Preset = {
  id: PresetId;
  label: string;
  metalId: MetalId;
  grams: number;
  stoneCostUSD: number;
  labourHours: number;
  note: string;
};

export const WORKED_PRESETS: Preset[] = [
  {
    id: 'band',
    label: '3 mm sterling band',
    metalId: 'sterling',
    grams: 3.2,
    stoneCostUSD: 0,
    labourHours: 1.5,
    note: 'Plain 3 mm court-profile band, no stone.',
  },
  {
    id: 'solitaire',
    label: '1 ct lab-grown solitaire',
    metalId: '18k',
    grams: 4.1,
    stoneCostUSD: 1100,
    labourHours: 4,
    note: `1 ct lab-grown, ${'G colour / VS2 clarity'}, 4-claw setting.`,
  },
  {
    id: 'signet',
    label: 'Signet ring',
    metalId: '9k',
    grams: 8.5,
    stoneCostUSD: 0,
    labourHours: 3,
    note: 'Hand-engraved signet, no stone.',
  },
];

export const DEFAULT_CONFIGURATOR_INPUT = {
  metalId: 'sterling' as MetalId,
  grams: 3.5,
  stoneCostUSD: 0,
  labourHours: 1.5,
};
