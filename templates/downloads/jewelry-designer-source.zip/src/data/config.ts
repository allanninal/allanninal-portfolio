// Imogen Vasey — Kelham Bench Jewellery. Fictional studio, Sheffield, UK.
// Demo address below is a placeholder; replace it with your own before
// deploying (see README). All commission and store copy assumes a
// man-woman couple for engagement/wedding pieces, per house convention.
import { GOLD_SPOT } from '~/data/pricing';

export const site = {
  name: 'Kelham Bench Jewellery',
  title: 'Kelham Bench Jewellery — Imogen Vasey, bench jeweller, Sheffield',
  tagline: `Gold at $${GOLD_SPOT.pricePerGramUSD.toFixed(2)}/g today — a quote is a formula, not a price list.`,
  owner: 'Imogen Vasey',
  ownerRole: 'Bench jeweller',
  studioName: 'Kelham Bench Jewellery',
  addressLine: '14 Cornish Place Yard',
  city: 'Sheffield',
  state: 'South Yorkshire',
  zip: 'S6 3AA',
  country: 'GB',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'A Sheffield bench-jewellery studio that publishes the formula behind a quote — metal, fineness, ' +
    "today's gold spot, labour and stone — instead of a price list that goes stale the day gold moves.",
  ogImage: '/og-image.png',
};

export const primaryNav = [
  { label: 'The formula', href: '#formula' },
  { label: 'Worked presets', href: '#presets' },
  { label: 'Hallmarks', href: '#hallmarks' },
  { label: 'Stones', href: '#stones' },
  { label: 'Sizing', href: '#sizing' },
  { label: 'Metal care', href: '#metal-care' },
  { label: 'Store', href: '#store' },
  { label: 'FAQ', href: '#faq' },
];

export const howTheNumberIsBuilt = [
  { step: 'Weigh the metal', detail: 'Grams, on a certified bench scale, before a single stone is set.' },
  { step: 'Apply fineness', detail: 'Sterling 925, 9k 375, 14k 585, or 18k 750 — a legal fraction, not a rounding choice.' },
  { step: "Multiply by today's spot", detail: 'Gold or silver, read the day the quote is generated — see the observation date next to every total on this page.' },
  { step: 'Add labour', detail: "Hours on the bench × Kelham Bench's own stated rate — see the note below the calculator." },
  { step: 'Add stone cost', detail: 'As quoted for the specific stone — mined or lab-grown, disclosed either way.' },
  { step: 'Add wastage', detail: 'A percentage of the metal cost — offcuts, filing dust and polishing loss that never make it into the finished piece.' },
  { step: 'The total', detail: 'Metal + labour + stone + wastage (+ a hallmarking fee, if the piece clears the legal weight threshold below).' },
];

export const commissionLeadTime = [
  { step: 'Consultation', detail: 'Metal, stone and sizing discussed together — the quote below is generated live, in the room or on a call.' },
  { step: 'CAD or hand sketch', detail: 'A wax or CAD model approved before a single gram of metal is cut.' },
  { step: 'Cast or fabricate', detail: 'Cast for most rings; hand-fabricated for anything with soldered joints or engraving that a cast can’t hold crisply.' },
  { step: 'Set the stone', detail: 'Mined or lab-grown, disclosed either way — see the Stones section below.' },
  { step: 'Hallmark', detail: `Sent to Sheffield Assay Office if the piece clears the legal weight threshold — see the Hallmarks section.` },
  { step: 'Polish & deliver', detail: 'Final polish, ring sizing checked once more, then collection or insured shipping. Realistically 4–6 weeks end to end.' },
];

export const faq = [
  {
    q: 'Can any ring be resized?',
    a: 'Most plain and light pavé bands, yes — a jeweller can usually move a size or two either way. Eternity bands set with stones all the way around, channel-set bands, and some tension settings cannot be resized without unsetting and resetting every stone, because there is no bare metal left to stretch or cut. Ask before you order if resizing matters to you.',
  },
  {
    q: 'What does a hallmark actually certify?',
    a: "A hallmark is an independent Assay Office's own struck mark, registered against the maker's sponsor's mark — it certifies the metal's fineness was tested and found to match what's claimed, not a design or a maker's reputation. It is a third party's word, not the studio's.",
  },
  {
    q: 'Is lab-grown "real"?',
    a: 'Yes — a lab-grown diamond is chemically, optically and physically identical to a mined one; the difference is where the carbon crystallised, not what it is. See the Stones section for the price gap at the same grade, and the FTC disclosure rule this studio follows.',
  },
];
