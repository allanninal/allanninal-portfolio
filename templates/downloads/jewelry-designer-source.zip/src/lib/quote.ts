// The only place a quote is computed. The hero configurator's client-side
// script, the worked-presets table (its JS-off fallback), and the Pro
// Commission Quote Sheet all import computeQuote() from here rather than
// re-deriving the arithmetic — so none of them can quietly disagree with
// each other. See RESEARCH.md, "The axis".
import { METALS, spotForMetalType, STUDIO_LABOUR_RATE_USD_PER_HOUR, WASTAGE_RATE, requiresHallmark, HALLMARKING_FEE_USD, type MetalId, type Metal } from '~/data/pricing';

export type QuoteInput = {
  metalId: MetalId;
  grams: number;
  stoneCostUSD: number;
  labourHours: number;
};

export type QuoteBreakdown = {
  metal: Metal;
  spotPerGram: number;
  finenessFraction: number;
  metalCost: number;
  labourCost: number;
  stoneCost: number;
  wastageCost: number;
  subtotal: number;
  hallmarkRequired: boolean;
  hallmarkFee: number;
  total: number;
};

function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function computeQuote(input: QuoteInput): QuoteBreakdown {
  const metal = METALS[input.metalId];
  const spotPerGram = spotForMetalType(metal.metalType);
  const finenessFraction = metal.finenessPer1000 / 1000;
  const grams = Math.max(0, input.grams || 0);
  const stoneCostUSD = Math.max(0, input.stoneCostUSD || 0);
  const labourHours = Math.max(0, input.labourHours || 0);

  const metalCost = round2(grams * finenessFraction * spotPerGram);
  const labourCost = round2(labourHours * STUDIO_LABOUR_RATE_USD_PER_HOUR);
  const stoneCost = round2(stoneCostUSD);
  const wastageCost = round2(metalCost * WASTAGE_RATE);
  const hallmarkRequired = requiresHallmark(metal.metalType, grams);
  const hallmarkFee = hallmarkRequired ? HALLMARKING_FEE_USD : 0;

  const subtotal = round2(metalCost + labourCost + stoneCost);
  const total = round2(subtotal + wastageCost + hallmarkFee);

  return {
    metal,
    spotPerGram,
    finenessFraction,
    metalCost,
    labourCost,
    stoneCost,
    wastageCost,
    subtotal,
    hallmarkRequired,
    hallmarkFee,
    total,
  };
}

export function formatUSD(n: number): string {
  return `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatFineness(finenessPer1000: number): string {
  return `${finenessPer1000}/1000`;
}
