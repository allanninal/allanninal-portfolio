import { test, expect } from '@playwright/test';

test.describe('The Bellwether Four — smoke tests', () => {
  test('homepage renders with the band name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/The Bellwether Four/);
    await expect(page.locator('h1')).toContainText('Fewer have the agreement');
  });

  test('is a MusicGroup with members and albums', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"MusicGroup"');
    expect(json).toContain('"member"');
    expect(json).toContain('"MusicAlbum"');
    // Day 113 emitted MusicEvent; this page has no tour spine and should not.
    expect(json).not.toContain('MusicEvent');
  });

  // A departed member emitted as current is the same class of error as day 113
  // publishing a sold-out show as available.
  test('only current members are emitted as member', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('MusicGroup')) || '');
    const schema = JSON.parse(raw);
    const states = (await page.locator('#lineup .state').allTextContents()).map((s) => s.trim());
    const current = states.filter((s) => s === 'Current').length;
    const past = states.filter((s) => s === 'Left').length;
    expect(past).toBeGreaterThan(0);
    expect(schema.member.length).toBe(current);
    const names = schema.member.map((m: any) => m.name);
    const pageNames = await page.locator('#lineup tbody th').allTextContents();
    for (const n of names) expect(pageNames).toContain(n);
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#deal table.deal');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(300);
  });

  // ── The agreement ───────────────────────────────────────────────────────
  test('every question has an answer and a reason', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#deal tbody tr');
    const n = await rows.count();
    expect(n).toBe(5);
    for (const r of await rows.all()) {
      expect(((await r.locator('.ours').textContent()) || '').trim().length).toBeGreaterThan(3);
      expect(((await r.locator('td').last().textContent()) || '').length).toBeGreaterThan(80);
    }
    await expect(page.locator('#deal h2')).toContainText(`${n} questions`);
  });

  test('the page says why publishing the agreement is worth doing', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#deal')).toContainText(/checkable claim in a field/i);
  });

  // ── Line-up ─────────────────────────────────────────────────────────────
  test('former members are listed with dates and a reason', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#lineup tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(4);
    for (const r of await rows.all()) {
      expect(((await r.locator('.years').textContent()) || '')).toMatch(/20\d\d/);
      const st = ((await r.locator('.state').textContent()) || '').trim();
      expect(['Current', 'Left']).toContain(st);
      expect(await r.locator('.state').getAttribute('data-glyph')).toBeTruthy();
    }
    const states = (await page.locator('#lineup .state').allTextContents()).map((s) => s.trim());
    const current = states.filter((s) => s === 'Current').length;
    await expect(page.locator('#lineup h2'))
      .toHaveText(`${current} now. ${n - current} who left, still listed.`);
    await expect(page.locator('#lineup')).toContainText(/quietly edits people out/i);
  });

  test('member state is not the accent colour', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--member-past', '--color-accent'].map((k) => s.getPropertyValue(k).trim());
    });
    expect(new Set(c).size).toBe(2);
  });

  // ── The deliberate refusal ──────────────────────────────────────────────
  // Day 113 is the tour-listing template. Building it well again here would be
  // the re-skin, so the dates section is a strip and the page says so.
  test('the dates section is a strip, not a second tour page', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#dates li');
    const n = await items.count();
    expect(n).toBeLessThanOrEqual(8);
    expect(await page.locator('#dates details').count()).toBe(0);
    await expect(page.locator('#dates h2')).toHaveText(`${n} shows.`);
    await expect(page.locator('#dates')).toContainText(/a whole page in its own right/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the page admits the band is fictional', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#faq')).toContainText(/The Bellwether Four is fictional/i);
  });

  test('the contact form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-113 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    // Not 'seated' or 'standing': this page names them deliberately, in the
    // sentence explaining that a full tour listing is a different page. A leak
    // check has to use tokens that cannot appear on purpose.
    for (const noun of ['wren halloway', 'portland, me', 'sold out', 'one stream', 'six emails']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro band agreement is absent from the free build', async ({ page }) => {
    const res = await page.goto('/band-agreement/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
