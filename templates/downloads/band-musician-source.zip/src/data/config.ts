// The Bellwether Four — Asheville, NC. Fictional.
//
// This template sits one day after the singer-songwriter and the roadmap lines
// are nearly identical ("tour dates, music embeds, merch"). Shipping that twice
// is the clone-pair failure docs/TEMPLATE_DIVERGENCE.md exists to catch, so the
// divergence here is in what the page is ABOUT: a solo artist is one person
// deciding; a band is four people with a shared bank account, a shared name and
// usually no written agreement.

export const site = {
  name:        'The Bellwether Four',
  shortName:   'Bellwether',
  title:       'The Bellwether Four — four people, one name, a written agreement',
  tagline:     'Most bands have the name. Fewer have the agreement.',
  owner:       'The Bellwether Four',
  ownerRole:   'Four-piece · Asheville, NC',
  credential:  'Together since 2019 · three records',
  city:        'Asheville',
  state:       'NC',
  language:    'en',
  phoneDisplay: '(828) 555-0136',
  phoneHref:   '+18285550136',
  email:       'hello@bellwetherfour.example',
  streetAddress: '31 Biltmore Ave',
  postalCode:  '28801',
  hours:       'One shared inbox, read by whoever is not driving',
  bookingWindow: 'Booking spring · agreement below, in full',
  description:
    'A four-piece from Asheville. Every band answers the same five questions eventually — how ' +
    'songwriting splits, how money splits, who owns the name, what happens when somebody leaves, ' +
    'and who decides. Most answer them in an argument. Ours are written down and on this page.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'How it works', href: '#deal' },
  { label: 'Line-up',      href: '#lineup' },
  { label: 'Records',      href: '#records' },
  { label: 'Dates',        href: '#dates' },
  { label: 'Contact',      href: '#contact' },
];

// ── The agreement ─────────────────────────────────────────────────────────

export const deal = [
  {
    q: 'Songwriting splits',
    ours: 'Equal, four ways',
    why: 'Whoever brought the song in, the arrangement is four people in a room and the recording is the arrangement. Equal splits are not the fairest answer in every band — they are the answer that has never once caused an argument in this one, and that is worth more than being technically right.',
  },
  {
    q: 'Live and recording income',
    ours: 'Equal after costs',
    why: 'Costs come out first — van, strings, the merch float — and the rest is divided four ways whether or not somebody sat out a song. Sitting out a song is a musical decision and it should never be a financial one.',
  },
  {
    q: 'Who owns the name',
    ours: 'All four, jointly',
    why: 'Nobody can take it and nobody can be taken off it. If two of us left, the two remaining would need the other two to agree before touring under it. That is deliberately awkward, because the alternative is a name owned by whoever registered it first.',
  },
  {
    q: 'When somebody leaves',
    ours: 'Splits freeze, credits stay',
    why: 'A departing member keeps their share of everything recorded up to the day they left, forever, and takes no share of anything after it. Their name stays on the records. This is the clause we wrote after watching a friend’s band get it wrong.',
  },
  {
    q: 'Who decides',
    ours: '3 of 4, or it waits',
    why: 'Three votes carries. A two-two split means the answer is no for now, which sounds like a recipe for paralysis and has in practice meant about four deferred decisions in seven years, all of which improved by waiting.',
  },
];

export const dealNote =
  'Publishing this is not oversharing. It is the same move as a studio publishing its salary ' +
  'bands: a checkable claim in a field that runs on unverifiable ones. It also does the recruiting ' +
  'that "we’re like a family" is supposed to do and never does — every person who has joined this ' +
  'band read these five rows first and two of them said the last one was why they said yes.';

// ── Line-up ───────────────────────────────────────────────────────────────

export const lineup = [
  { name: 'Junie Marchetti', plays: 'Guitar, voice',    from: '2019', to: null,   state: 'now',
    note: 'Writes most of the words, which under the first row of the agreement earns her exactly the same as everybody else.' },
  { name: 'Emory Bell',      plays: 'Bass, voice',      from: '2019', to: null,   state: 'now',
    note: 'Also runs the accounts, which is a job and is paid as one out of costs before the split.' },
  { name: 'Vess Okoro',      plays: 'Drums',            from: '2019', to: null,   state: 'now',
    note: 'Founding member. Has never once voted with the majority on a setlist and is usually right.' },
  { name: 'Callum Reyes',    plays: 'Keys, pedal steel', from: '2023', to: null,  state: 'now',
    note: 'Joined after Ondine left. Read the agreement before the first rehearsal, which is how it should work.' },
  { name: 'Ondine Ruiz',     plays: 'Keys',             from: '2019', to: '2022', state: 'past',
    note: 'Left to make her own records, amicably and with three months’ notice. Keeps her share of the first two records and takes none of the third.' },
  { name: 'Hattie Lowe',     plays: 'Fiddle',           from: '2020', to: '2021', state: 'past',
    note: 'Toured with us for eighteen months. It was the wrong fit musically and we said so late, which was our mistake rather than hers.' },
];

export const lineupNote =
  'Two former members, both listed, both with the reason. A band page that quietly edits people ' +
  'out is telling a reader something they will work out anyway, and it is telling anybody ' +
  'thinking of joining rather more than that.';

// ── Records ───────────────────────────────────────────────────────────────

export const records = [
  { title: 'Fever Dream Radio', year: '2022', len: '41 min', tracks: 11,
    what: 'Recorded with the line-up that has Ondine on it and Callum not. The keys on it are hers and the credit stays hers.' },
  { title: 'Slow Handed', year: '2024', len: '26 min', tracks: 7,
    what: 'An EP made in nine days between tours. The first thing written after the agreement was signed and, we think, audibly less careful.' },
  { title: 'Ninth & Vance', year: '2025', len: '47 min', tracks: 12,
    what: 'The current record, and the first with pedal steel on it. Split four ways like everything else.' },
];

// ── Dates — deliberately a strip, not a spine ─────────────────────────────

export const dates = [
  { d: 'Fri 10 Oct', v: 'Bramble Hall',       c: 'Portsmouth, NH' },
  { d: 'Sat 11 Oct', v: 'Harborlight',        c: 'Boston, MA' },
  { d: 'Thu 16 Oct', v: 'Ninth & Vance',      c: 'Philadelphia, PA' },
  { d: 'Fri 17 Oct', v: 'The Wharf Rooms',    c: 'Baltimore, MD' },
  { d: 'Fri 24 Oct', v: 'Corktown Social',    c: 'Chicago, IL' },
  { d: 'Sat 25 Oct', v: 'Northline Hall',     c: 'Milwaukee, WI' },
];

export const datesNote =
  'Six dates, and that is all this section is. A full tour listing — seated or standing, solo or ' +
  'band, who is on before — is a whole page in its own right and it is not what this one is about.';

export const said = {
  text: 'They sent us the agreement with the booking email. I have worked with four hundred bands and I had never seen one, let alone one on a public page. It is the reason I remembered them.',
  who: 'Booking agent, Southeast — 2024',
};

export const faqs = [
  {
    q: 'Why publish the agreement?',
    a: 'Because almost no band has one, every band needs one, and the ones that end badly end on exactly these five questions. Publishing ours costs us nothing and might save somebody reading it a friendship. It also recruits: everyone who has joined read these rows first.',
  },
  {
    q: 'Equal splits even when one person writes the song?',
    a: 'In this band, yes, and we would not tell another band to copy it. Equal splits are not the fairest answer everywhere — they are the answer that has never caused an argument here. What matters is that the answer is written down before there is money to argue about.',
  },
  {
    q: 'Why list former members?',
    a: 'Because they played on records people own, their credits are permanent under the fourth row, and editing them out would be dishonest about our own history. It is also the clearest possible statement of how somebody would be treated if they left tomorrow.',
  },
  {
    q: 'What happens if two people want to leave?',
    a: 'The name needs all four to agree before anybody tours under it, which is deliberately awkward. We would rather a hard conversation than a situation where whoever registered a domain first owns seven years of other people’s work.',
  },
  {
    q: 'Is this a real band?',
    a: 'No. This is a website template and The Bellwether Four is fictional — the same fictional band named in passing on another template in this library. The agreement is written as a real one would be, because that is the useful part to inherit.',
  },
  {
    q: 'Do you have a lawyer?',
    a: 'Yes, and you should too before signing anything. Nothing on this page is legal advice; it is a description of what we agreed, which is a different thing and a much cheaper first step than most bands realise.',
  },
];
