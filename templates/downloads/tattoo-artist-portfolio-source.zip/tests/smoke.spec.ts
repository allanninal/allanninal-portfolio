import { test, expect } from '@playwright/test';

test.describe('Iona Petrakis — smoke tests', () => {
  test('the page leads with placement', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Iona Petrakis/);
    await expect(page.locator('h1')).toContainText(/Placement first/i);
    // The body map is the first section after the masthead, not the fifth.
    const ids = await page.locator('main section[id]').evaluateAll((s) => s.map((x) => x.id));
    expect(ids[0]).toBe('placement');
  });

  // ── Schema ──────────────────────────────────────────────────────────────
  // Person + Service. The withholding is price: the page states an hourly rate
  // and a deposit in plain text, and the markup still refuses to encode either,
  // because a session length is set by the placement rather than by a menu.
  test('the service asserts no price of any kind', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const service = JSON.parse(blocks.find((b) => b.includes('"Service"'))!);
    expect(service['@type']).toBe('Service');
    expect(service.serviceType).toBe('Tattooing');
    expect(service.areaServed).toBeTruthy();
    expect(service.audience.suggestedMinAge).toBe(18);

    const zoneRows = await page.locator('#floors tbody tr').count();
    expect(service.hasOfferCatalog.itemListElement.length).toBe(zoneRows);
    for (const item of service.hasOfferCatalog.itemListElement) {
      expect(item['@type']).toBe('Service');
      expect(item.price).toBeUndefined();
      expect(item.offers).toBeUndefined();
    }

    const all = blocks.join('');
    expect(all).toContain('"Person"');
    for (const forbidden of ['priceRange', '"offers"', 'aggregateRating', '"image"']) {
      expect(all, `schema must not assert ${forbidden}`).not.toContain(forbidden);
    }
    // The rate IS on the page — the omission is in the markup, not the copy.
    await expect(page.locator('#booking')).toContainText('$180');
  });

  // ── The body map ────────────────────────────────────────────────────────
  test('every zone has a marker on the figure and a numbered block beside it', async ({ page }) => {
    await page.goto('/');
    const blocks = page.locator('#placement .zone');
    const n = await blocks.count();
    expect(n).toBe(8);

    // One marker per zone, numbered in the same order as the list.
    const marks = await page.locator('.bodymap svg text').allTextContents();
    const numbered = marks.filter((t) => /^\d+$/.test(t.trim()));
    expect(numbered.map((t) => t.trim())).toEqual(
      Array.from({ length: n }, (_, i) => String(i + 1)));

    const headings = await page.locator('#placement .zone h3').allTextContents();
    headings.forEach((h, i) => expect(h.trim().startsWith(String(i + 1))).toBe(true));
  });

  test('the map is a diagram, not a photograph, and the page has no images at all', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('img, picture').count()).toBe(0);
    await expect(page.locator('.bodymap svg')).toHaveAttribute('aria-hidden', 'true');
  });

  // The split screen is the layout claim, and it is CSS: the pane pins on a
  // wide viewport and stops pinning where there is no room for two panes.
  test('the figure pane is sticky on desktop and static on a phone', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/');
    const pos = async () => page.locator('.split .pane').evaluate((el) => getComputedStyle(el).position);
    expect(await pos()).toBe('sticky');

    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/');
    expect(await pos()).toBe('static');
    // …and the page says so rather than hiding it.
    await expect(page.locator('.bodymap figcaption')).toContainText(/stops being sticky/i);
  });

  test('every number on the map is repeated in the table', async ({ page }) => {
    await page.goto('/');
    const floors = await page.locator('#placement .zone .nums dd').allTextContents();
    const table = (await page.locator('#floors table').textContent()) || '';
    for (const f of floors) expect(table).toContain(f.trim());
    expect(await page.locator('#floors tbody tr').count()).toBe(8);
  });

  test('two zones carry conditions and both say what they are', async ({ page }) => {
    await page.goto('/');
    const policies = page.locator('#placement .zone .policy');
    expect(await policies.count()).toBeGreaterThanOrEqual(2);
    await expect(page.locator('#placement')).toContainText(/Hands and fingers/);
    await expect(page.locator('#placement')).toContainText(/Neck and throat/);
  });

  // ── Flash ───────────────────────────────────────────────────────────────
  // The claim on the page is that each design is stroked at the line-weight
  // floor of its zone. That is checkable, so it is checked: sorting the designs
  // by rendered stroke width must give the same order as sorting their zones by
  // floor. A stylesheet that "looked right" would fail this.
  test('flash stroke weight follows the zone floor, not taste', async ({ page }) => {
    await page.goto('/');
    const designs = page.locator('.design');
    expect(await designs.count()).toBe(10);

    const rows = await designs.evaluateAll((figs) =>
      figs.map((f) => ({
        zone: f.getAttribute('data-zone'),
        weight: Number(f.getAttribute('data-weight')),
        stroke: Number(f.querySelector('svg g')?.getAttribute('stroke-width') ?? 0),
      })));
    for (const r of rows) expect(r.stroke).toBeCloseTo(r.weight, 2);

    // Floors, read from the zone table rather than hard-coded here.
    const floors = Object.fromEntries(await page.locator('#placement .zone').evaluateAll((zs) =>
      zs.map((z) => [z.id.replace('zone-', ''),
        parseFloat(z.querySelector('.nums dd')?.textContent || '0')])));
    const byWeight = [...rows].sort((a, b) => a.weight - b.weight).map((r) => r.zone);
    const byFloor = [...rows].sort((a, b) => floors[a.zone!] - floors[b.zone!]).map((r) => r.zone);
    expect(byWeight.map((z) => floors[z!])).toEqual(byFloor.map((z) => floors[z!]));

    // The heaviest design is drawn for a zone with a heavier floor than the lightest.
    const min = rows.reduce((a, r) => (r.weight < a.weight ? r : a));
    const max = rows.reduce((a, r) => (r.weight > a.weight ? r : a));
    expect(floors[max.zone!]).toBeGreaterThan(floors[min.zone!]);
  });

  test('one-time-only flash is marked, and the count in the eyebrow agrees', async ({ page }) => {
    await page.goto('/');
    const marked = await page.locator('.design .once').count();
    expect(marked).toBeGreaterThan(0);
    await expect(page.locator('#flash .eyebrow')).toContainText(`${marked} of them one-time only`);
  });

  // ── Booking ─────────────────────────────────────────────────────────────
  test('the form asks placement before anything else it needs', async ({ page }) => {
    await page.goto('/');
    const select = page.locator('#zone');
    await expect(select).toHaveAttribute('required', '');
    // Every zone is offered, plus the empty prompt and an "unsure" escape.
    expect(await select.locator('option').count()).toBe(10);
    await expect(page.locator('label[for="zone"] .hint')).toContainText(/sets the floor/i);
    for (const id of ['#name', '#email', '#size', '#brief']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // ── Sub-pages ───────────────────────────────────────────────────────────
  test('the aftercare sheet is free, printable and reachable', async ({ page }) => {
    await page.goto('/');
    await page.locator('#ageing a', { hasText: /aftercare/i }).first().click();
    await expect(page).toHaveURL(/\/aftercare\/$/);
    await expect(page.locator('h1')).toContainText('Aftercare');
    await expect(page.locator('button', { hasText: /Print/i })).toBeVisible();
    await expect(page.locator('main')).toContainText(/Call a doctor/i);
  });

  test('the Pro consult sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/consult-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });

  // ── Hygiene ─────────────────────────────────────────────────────────────
  test('no trace of the day-127 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['low tide radio', 'chapter', 'comic', 'astoria', 'screentone', 'right to left']) {
      expect(html, `day-127 copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('nothing on the page is a photograph or a rate card', async ({ page }) => {
    await page.goto('/');
    // Day 55 (tattoo-studio) is the photo-led studio template. This one is not.
    expect(await page.locator('img').count()).toBe(0);
    expect(await page.locator('table').count()).toBe(1);
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1440, 1280, 960, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });
});
