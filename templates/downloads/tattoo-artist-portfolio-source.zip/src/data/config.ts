// Iona Petrakis — Louisville, KY. Fictional.
//
// The organising idea: every tattoo portfolio is a grid of photographs taken
// twenty minutes after the needle came off, on whichever body part photographs
// best. That hides the two facts that decide whether the client still likes it
// in ten years — ink spreads, and every zone has a line-weight floor below which
// a design becomes a blob. So the spine of this site is a body map, and the
// flash, the ageing notes and the booking form all hang off it.
//
// The millimetre floors and the ten-year spread figures are this artist's stated
// practice, not published research, and the page says so.

export const site = {
  name:        'Iona Petrakis',
  shortName:   'Iona Petrakis',
  title:       'Iona Petrakis — fine line and traditional tattooing, Louisville',
  tagline:     'Placement first. The drawing comes second.',
  owner:       'Iona Petrakis',
  ownerRole:   'Tattoo artist',
  credential:  'Eleven years · private studio, by appointment · Kentucky licence #KY-4471',
  studio:      'Second-floor studio on Frankfort Ave',
  city:        'Louisville',
  state:       'KY',
  language:    'en',
  phoneDisplay: '(502) 555-0146',
  phoneHref:   '+15025550146',
  email:       'iona@petrakistattoo.example',
  streetAddress: '2118 Frankfort Ave',
  postalCode:  '40206',
  hours:       'Tuesday to Saturday · one client at a time',
  minimumAge:  18,
  hourly:      '$180/hour',
  deposit:     '$150, comes off the last session',
  bookingWindow: 'Books open the first Monday of each month · currently drawing five weeks out',
  // Held inside the 160 characters Google and LinkedIn truncate at — the
  // seo-aeo-audit checklist calls that P0. The long version is `intro`, which
  // is read on the page rather than clipped in a result.
  description:
    'Fine line and traditional tattooing built around placement: an eight-zone body map, the ' +
    'thinnest line each zone holds, and what ink does there over ten years.',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Placement', href: '#placement' },
  { label: 'How it ages', href: '#ageing' },
  { label: 'Flash',      href: '#flash' },
  { label: 'The work I decline', href: '#decline' },
  { label: 'Booking',    href: '#booking' },
];

export const intro =
  'Everything below is decided before a needle is switched on. Where a piece goes changes what can ' +
  'be drawn in it, how thin the thinnest line is allowed to be, how long it takes to heal and how ' +
  'it looks in ten years. A design that is right for an outer thigh is a repair job on a finger, ' +
  'and no amount of care afterwards fixes that.';

// ── The body map ──────────────────────────────────────────────────────────
// Eight zones. `floor` is the thinnest line this artist will lay there; `gap`
// is the minimum clear space between two lines; `spread` is how much wider she
// expects a line to read at ten years; `heal` is surface healing in days.
// `policy` is what she will and will not do there, which is the half of the
// answer most portfolios leave out.

export type Zone = {
  id: string;
  k: string;
  floor: string;
  gap: string;
  spread: string;
  heal: string;
  sun: 'High' | 'Medium' | 'Low';
  sit: string;
  n: string;
  policy?: string;
};

export const zones: Zone[] = [
  { id: 'outer-arm', k: 'Outer upper arm',
    floor: '0.25 mm', gap: '1.5 mm', spread: '+20%', heal: '14–18 days', sun: 'Medium', sit: 'Easy, 3–4 hours',
    n: 'Thick skin, little movement, easy to keep covered. The zone that holds fine line best, which is why so much of the work below lives here. If you are unsure where a first piece should go, it should probably go here.' },
  { id: 'outer-thigh', k: 'Outer thigh',
    floor: '0.25 mm', gap: '1.5 mm', spread: '+20%', heal: '16–21 days', sun: 'Low', sit: 'Easy, 4–5 hours',
    n: 'The other zone that behaves. Rarely sunburnt, rarely rubbed, and there is enough of it for a piece to be drawn at the size it wants rather than shrunk to fit.' },
  { id: 'upper-back', k: 'Upper back and shoulder blade',
    floor: '0.3 mm', gap: '1.8 mm', spread: '+25%', heal: '18–24 days', sun: 'Low', sit: 'Moderate, 4 hours',
    n: 'Broad, flat and still. Heals slowly because you sleep on it, and it is the one zone where you cannot check your own aftercare in a mirror without help.' },
  { id: 'forearm', k: 'Inner forearm',
    floor: '0.3 mm', gap: '2 mm', spread: '+30%', heal: '12–16 days', sun: 'High', sit: 'Easy, 3 hours',
    n: 'Thin skin over not much fat, so the needle depth window is narrow and this is where blowout shows up as a blue-grey halo. Also the most sun-exposed place on most people, which is the other half of why it fades.' },
  { id: 'ribs', k: 'Ribs and side',
    floor: '0.35 mm', gap: '2 mm', spread: '+30%', heal: '18–25 days', sun: 'Low', sit: 'Hard, 2–3 hours maximum',
    n: 'Skin stretches over bone with every breath, which makes it the least predictable surface I work on and the reason I cap the session at three hours whatever you say about your pain tolerance.' },
  { id: 'ankle', k: 'Ankle and top of foot',
    floor: '0.4 mm', gap: '2.5 mm', spread: '+40%', heal: '21–30 days', sun: 'High', sit: 'Hard, 2 hours',
    n: 'Thin skin, bone directly underneath, and shoes rubbing it for the whole heal. Expect a touch-up and budget for it rather than being disappointed by it.' },
  { id: 'hand', k: 'Hands and fingers',
    floor: '0.5 mm', gap: '3 mm', spread: '+60%', heal: '10–14 days, then it moves for a year', sun: 'High', sit: 'Hard, 90 minutes',
    n: 'Skin that regenerates faster than anywhere else and is washed thirty times a day. Fine line here is a subscription, not a tattoo — I have seen a two-week-old finger piece close up into a smudge.',
    policy: 'Only for people who already have visible work, only bold, and only after a conversation about the fact that it will need redoing.' },
  { id: 'neck', k: 'Neck and throat',
    floor: '0.5 mm', gap: '3 mm', spread: '+35%', heal: '14–20 days', sun: 'High', sit: 'Hard, 2 hours',
    n: 'The skin takes ink well. The problem is not the skin.',
    policy: 'Not on a first tattoo, and not on the same day you decide you want one. Come back in three months and I will still be here.' },
];

export const zoneNote =
  'These are my numbers, from my own healed photographs, not published research. Another artist ' +
  'will give you slightly different ones and that is fine — what matters is that whoever tattoos ' +
  'you has numbers at all, and will tell you when the design you have brought is under the floor.';

export const mapNote =
  'The figure stays put while you read, because that is what a consultation looks like: my finger ' +
  'on the diagram, your question about that spot. On a phone it stops being sticky and sits above ' +
  'the list instead — the layout gives up gracefully rather than pretending a 375-pixel screen has ' +
  'room for two panes.';

// ── How it ages ───────────────────────────────────────────────────────────

export const ageing = [
  { t: 'Days 3 to 7 — it peels and looks wrong',
    d: 'Thin translucent flakes come away and the piece goes dull, cloudy, almost milky. Every client who messages me in a panic messages me in this window. Do not pick it, do not scrub it, and do not judge the tattoo yet.' },
  { t: 'Weeks 2 to 3 — the surface closes',
    d: 'Flaking finishes and the colour comes back up. The outer skin is healed here, which is not the same as healed: the deeper layers keep settling for up to six months, so the piece is still moving under a surface that looks finished.' },
  { t: 'Week 6 — the real photograph',
    d: 'This is when I ask for a picture, and it is the only kind of photograph in my portfolio. A day-one shot shows my hand; a six-week shot shows what you actually own.' },
  { t: 'Year 2 — the lines find their width',
    d: 'Ink settles outward slightly and the thinnest lines put on the width they were always going to put on. A design drawn with the floor in mind still reads. One drawn at the floor does not.' },
  { t: 'Year 10 — spacing, not weight, is what saved it',
    d: 'What blurs a piece is not thin lines, it is thin lines drawn too close together: two lines 1 mm apart on a forearm are one line by then. The gap column on the map is doing more work than the floor column.' },
];

export const ageingNote =
  'Sun is the other half of this and it is not subtle. The same design on a covered thigh and on ' +
  'a bare forearm is two different tattoos at year ten, and the difference is sunscreen.';

// ── Flash ─────────────────────────────────────────────────────────────────
// Drawn in the page as SVG rather than photographed, because a tattoo design is
// line art and this is a template: swap them for your own and everything else
// on the page still works. `once` marks a one-time-only design, which is real
// flash practice — the repeatable ones can be tattooed on more than one person.

export type Flash = {
  id: string;
  k: string;
  mm: number;          // designed width in millimetres
  zone: string;        // zone id it was drawn for
  once: boolean;
  n: string;
};

export const flash: Flash[] = [
  { id: 'yarrow',   k: 'Yarrow stem',       mm: 90,  zone: 'outer-arm',   once: false, n: 'Three stems, one heavy. Drawn to survive at 90 mm and no smaller — the umbel closes up below that.' },
  { id: 'swallow',  k: 'Swallow',           mm: 70,  zone: 'outer-arm',   once: false, n: 'Traditional, bold outline, no interior hatching. The design I recommend most often for a first tattoo.' },
  { id: 'moth',     k: 'Moth',              mm: 110, zone: 'upper-back',  once: true,  n: 'One-time only. The wing spacing is 2 mm at the tightest point, which is why it is a back piece and not a wrist piece.' },
  { id: 'anchor',   k: 'Anchor and rope',   mm: 80,  zone: 'outer-arm',   once: false, n: 'Old-school weight throughout. This one will still read at fifty years, which is not something I say often.' },
  { id: 'fern',     k: 'Fern frond',        mm: 120, zone: 'outer-thigh', once: false, n: 'Twenty-two leaflets. At 120 mm they hold; scaled to 60 mm they merge into a green-grey shape and I will say no.' },
  { id: 'wheat',    k: 'Wheat sheaf',       mm: 100, zone: 'outer-thigh', once: false, n: 'Drawn for the thigh, where the 1.5 mm gaps are safe. Memorial piece originally; it has been tattooed four times since.' },
  { id: 'compass',  k: 'Compass rose',      mm: 85,  zone: 'upper-back',  once: false, n: 'Symmetrical, which means it shows every millimetre of drift. Placed on the flattest part of the back for that reason.' },
  { id: 'sparrow',  k: 'Sparrow, small',    mm: 55,  zone: 'forearm',     once: false, n: 'The smallest design I will put on an inner forearm. Below 55 mm the beak and the tail merge into the body.' },
  { id: 'thistle',  k: 'Thistle',           mm: 95,  zone: 'outer-arm',   once: true,  n: 'One-time only, drawn for a client who did not book. It is yours if you want it and it stays a one-off.' },
  { id: 'crescent', k: 'Crescent and stem', mm: 65,  zone: 'ankle',       once: false, n: 'Bold enough for an ankle at 0.4 mm minimum. Every ankle piece I draw is drawn twice as heavy as the same design elsewhere.' },
];

export const flashNote =
  'These are line drawings in the page rather than photographs, which is the honest way to publish ' +
  'flash: flash IS line art, and a photograph of it on somebody else’s arm tells you about their ' +
  'arm. Each one carries the width it was drawn for. Ask me to shrink it and the answer is usually ' +
  'no, for the reason in the second column.';

// ── The appointment ───────────────────────────────────────────────────────

export const appointment = [
  { k: 'You send a placement, not a picture', n: 'Where it goes, roughly how big in centimetres, and whether you have existing work near it. A reference image is useful and it is the fourth thing I need, not the first.' },
  { k: 'I answer within a week, including no', n: 'If the design is under the floor for the zone you want, I will say so and offer the version that is not. About one enquiry in six gets that answer.' },
  { k: 'Deposit books the day', n: 'One hundred and fifty dollars, and it comes off the last session rather than being an extra. It is non-refundable inside 72 hours, because that day is then gone.' },
  { k: 'Stencil goes on and we both look', n: 'Placement is still changeable at this point and it is the last moment it is. I have moved a stencil eleven times for one client and it was the right call.' },
  { k: 'The session, capped by the zone', n: 'Three hours on ribs, five on a thigh. When skin has had enough it stops taking ink cleanly and pushing on is how a good piece gets a bad hour in it.' },
  { k: 'Six-week photograph, then a touch-up if it needs one', n: 'One touch-up inside six months is included and I would rather do it than not. After that it is time, and time is charged.' },
];

// ── What I decline ────────────────────────────────────────────────────────

export const decline = [
  { t: 'Hate imagery, in any of its dog whistles',
    d: 'Including the numbers and the runes that are pretending not to be. This is not a debate I have; it is a door.' },
  { t: 'Another artist’s design, copied',
    d: 'Bring it as a reference and I will draw you something that owes it something. Tracing another tattooer’s flash line for line is taking their work, and the tattoo community is small enough that everyone finds out anyway.' },
  { t: 'Anything on a client who has been drinking',
    d: 'Alcohol thins the blood, the ink does not sit, and consent given at 2 p.m. after lunch drinks is not consent I want to rely on. Rebooked, no deposit lost.' },
  { t: 'A design under the floor for the zone you want it in',
    d: 'I will offer the redrawn version, at the weight the zone will hold. If you want the original at the original weight, somebody else will do it and it will look like a smudge in two years — I would rather you heard that from me first.' },
  { t: 'Cover-ups I cannot do well',
    d: 'Some existing work needs laser first and some needs a different artist. Saying so costs me the booking and saves you a second bad tattoo on top of the first.' },
];

export const said = {
  text: 'She turned down the size I asked for and drew it 30 mm bigger, and I was annoyed for about a week. It is four years old now and every line in it is still a line.',
  who: 'Client, second piece — 2025',
};

export const faqs = [
  {
    q: 'Why do you ask where before you ask what?',
    a: 'Because the zone sets the floor. The thinnest line a piece of skin will hold is a property of that skin, not of the drawing, and a design that is beautiful at 0.2 mm on paper is a grey mark on a finger in eighteen months. Tell me the placement and I can tell you in one message whether what you want is possible there.',
  },
  {
    q: 'Do fine line tattoos really age badly?',
    a: 'Not inherently. They age badly when they are drawn at the floor rather than above it, and when the gaps between lines are tighter than the zone allows — two lines a millimetre apart on a forearm are one line at year ten. Fine line on an outer arm or thigh, drawn with the spread built in, holds up for a decade and longer.',
  },
  {
    q: 'What is a blowout, and can you avoid it?',
    a: 'It is ink pushed past the dermis into the fat below, where it spreads out like a drop in water and reads as a blue-grey halo. It comes from needle depth or angle, and it happens most on thin skin over little fat — inner wrist, ankle, fingers. It is avoidable, it is on the artist, and it is one reason those zones carry a heavier floor here.',
  },
  {
    q: 'Will you tattoo my hands or my neck?',
    a: 'Hands, only if you already have visible work, only bold, and only after we have talked about the fact that it will need redoing — the skin there turns over faster than anywhere else. Neck, not on a first tattoo and not on the day you decide you want one. Come back in three months; I will still be here.',
  },
  {
    q: 'How much, and what is the deposit?',
    a: 'Hourly, $180, and a $150 deposit that comes off the last session rather than being an extra. I do not quote a flat price from a photograph because the session length is set by the placement and by how your skin takes ink, and a number I invent before seeing either is a number I will have to walk back.',
  },
  {
    q: 'It is peeling and looks terrible. Is it ruined?',
    a: 'Almost certainly not, and you are in days three to seven. It goes dull and cloudy while the surface flakes, and the colour comes back through week two. The outer skin closes in two to three weeks; the deeper layers keep settling for up to six months. Do not pick it, and send me a photograph at six weeks rather than at day five.',
  },
];

export const templateNote =
  'Iona Petrakis is a fictional artist invented for this template. Every flash design is an SVG ' +
  'drawn in the page and every number on the body map lives in src/data/config.ts — replace the ' +
  'zones with your own numbers and the map, the tables, the flash captions and the booking form all ' +
  'follow, because none of it is typed twice.';
