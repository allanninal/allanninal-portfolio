import { test, expect } from '@playwright/test';

test.describe('Fenn Motion — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Fenn Motion/);
    await expect(page.locator('h1')).toContainText('the other twenty-seven');
  });

  test('handles the schema.org video-production gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q1762059');
  });

  // ── The calendar ────────────────────────────────────────────────────────
  test('the headline totals are summed from the table, not typed', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#calendar tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(10);
    let total = 0, wait = 0;
    for (const r of await rows.all()) {
      const d = Number(((await r.locator('.cal-days').textContent()) || '').replace('d', ''));
      expect(Number.isFinite(d)).toBe(true);
      total += d;
      if (await r.evaluate((el) => el.classList.contains('is-wait'))) wait += d;
    }
    const h2 = page.locator('#calendar h2');
    await expect(h2).toContainText(`${total} working days`);
    await expect(h2).toContainText(`${wait} of them are us waiting`);
  });

  // The distinction the whole section rests on must survive without colour.
  test('waiting rows are marked in words and in texture, not only in hue', async ({ page }) => {
    await page.goto('/');
    const waits = page.locator('#calendar tr.is-wait');
    expect(await waits.count()).toBeGreaterThanOrEqual(2);
    for (const w of await waits.all()) {
      await expect(w.locator('.cal-flag')).toHaveText('Waiting');
      const bg = await w.locator('.cal-bar').evaluate((el) => getComputedStyle(el).backgroundImage);
      expect(bg).toContain('repeating-linear-gradient');
    }
    // and the working rows carry neither
    const work = page.locator('#calendar tbody tr:not(.is-wait)');
    expect(await work.locator('.cal-flag').count()).toBe(0);
  });

  test('the bars are drawn in proportion to the day counts', async ({ page }) => {
    await page.goto('/');
    const pairs = await page.locator('#calendar tbody tr').evaluateAll((rows) =>
      rows.map((r) => [
        Number((r.querySelector('.cal-days')?.textContent || '').replace('d', '')),
        parseFloat((r.querySelector('.cal-bar') as HTMLElement)?.style.width || '0'),
      ]));
    const max = Math.max(...pairs.map((p) => p[0]));
    for (const [days, pct] of pairs) {
      expect(Math.abs(pct - (days / max) * 100)).toBeLessThan(0.2);
    }
  });

  // ── Deliverables ────────────────────────────────────────────────────────
  test('every deliverable carries a ratio, a length and its edit hours', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#deliverables table.deliv tbody tr');
    expect(await rows.count()).toBeGreaterThan(5);
    let hours = 0;
    for (const r of await rows.all()) {
      const cells = r.locator('td.num');
      expect(await cells.count()).toBe(3);
      hours += Number((await cells.nth(2).textContent()) || '0');
    }
    await expect(page.locator('#deliverables')).toContainText(`${hours} edit hours`);
  });

  // One photograph, shown twice. The duplicate must not be announced twice.
  test('the reframe pair is one image and only one of them is announced', async ({ page }) => {
    await page.goto('/');
    const imgs = page.locator('.reframe img');
    expect(await imgs.count()).toBe(2);
    const srcs = await imgs.evaluateAll((els) => els.map((e) => e.getAttribute('src')));
    expect(srcs[0]).toBe(srcs[1]);
    expect(((await imgs.nth(0).getAttribute('alt')) || '').length).toBeGreaterThan(40);
    expect(await imgs.nth(1).getAttribute('alt')).toBe('');
    await expect(imgs.nth(1)).toHaveAttribute('aria-hidden', 'true');
    // The point lives in the caption, not in the picture.
    await expect(page.locator('.reframe .cropped figcaption')).toContainText(/just crop it/i);
  });

  test('all images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  // ── Revisions ───────────────────────────────────────────────────────────
  test('two rounds are included and the third is priced in days as well as money', async ({ page }) => {
    await page.goto('/');
    const arts = page.locator('#rounds article.round');
    expect(await arts.count()).toBe(3);
    await expect(arts.nth(0)).toContainText('Included');
    await expect(arts.nth(1)).toContainText('Included');
    await expect(arts.nth(2)).toContainText('$');
    for (const a of await arts.all()) await expect(a).toContainText(/days? of calendar/);
  });

  test('the studio says a committee is the real cost', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#rounds')).toContainText(/one named decision-maker/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the enquiry form asks who signs off and marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#approver']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    await expect(page.locator('label[for="approver"]')).toContainText(/signs off/i);
  });

  test('no trace of the day-101 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['halden rask', 'shot list', 'hillside', 'anamorphic', 'q222344', 'league gothic']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro delivery schedule is absent from the free build', async ({ page }) => {
    const res = await page.goto('/delivery-schedule/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
