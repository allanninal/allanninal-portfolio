// Marisol Fenn — Knoxville, TN.
//
// The roadmap line for day 102 says "reel-led, services, packages". Day 101
// already refused to be reel-led and repeating that refusal would have made
// this a re-skin of yesterday. The axis here is the thing that actually
// separates a videographer from a cinematographer: a videographer is the whole
// pipeline for a client who has no production, so the client's real question
// is not "how good is your camerawork" but "when do I get it, and what am I
// actually getting". Nobody answers that on their website.

export const site = {
  name:        'Fenn Motion',
  shortName:   'Fenn Motion',
  title:       'Fenn Motion — Video production, Knoxville',
  tagline:     'The shoot is one day. You are paying for the other twenty-seven.',
  owner:       'Marisol Fenn',
  ownerRole:   'Videographer and editor',
  credential:  'Shooting, cutting and delivering since 2016',
  city:        'Knoxville',
  state:       'TN',
  language:    'en',
  phoneDisplay: '(865) 555-0142',
  phoneHref:   '+18655550142',
  email:       'marisol@fennmotion.example',
  streetAddress: '1122 Sevier Ave',
  postalCode:  '37920',
  hours:       'Mon–Fri 9–6 · shoot days as scheduled',
  bookingWindow: 'Booking shoots from the second week of next month.',
  description:
    'A one-person video studio in Knoxville. Every page in this trade sells the shoot, ' +
    'which is the one day of the six weeks you already understand. This one shows you the ' +
    'other twenty-seven — including the two longest stretches, which are us waiting on you.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Six weeks',    href: '#calendar' },
  { label: 'What you get', href: '#deliverables' },
  { label: 'Revisions',    href: '#rounds' },
  { label: 'Rates',        href: '#rates' },
  { label: 'Start',        href: '#start' },
];

// ── The calendar ──────────────────────────────────────────────────────────
// Working days on a real corporate brand film, start to delivery. `who` is
// load-bearing: the two longest phases belong to the client.

export const calendar = {
  title: 'Brand film, 90 seconds — pre-production to final delivery',
  phases: [
    { phase: 'Scoping call and quote',   who: 'Both',   days: 2,  wait: false, note: 'Two calls and a written scope. Skipping this is how a project acquires a second deliverable in week five.' },
    { phase: 'Script and shot plan',     who: 'Us',     days: 2,  wait: false, note: 'Written before anything is booked, because the plan decides how many shoot days there are.' },
    { phase: 'Your approval of the script', who: 'You', days: 3,  wait: true,  note: 'The first place a project quietly loses a week. Nothing can be booked until this comes back.' },
    { phase: 'Scheduling and logistics', who: 'Us',     days: 1,  wait: false, note: 'Locations, permissions, people, kit. Mostly email.' },
    { phase: 'Shoot',                    who: 'Both',   days: 1,  wait: false, note: 'One day. The part everybody pictures when they say "making a video", and the shortest phase on this list.' },
    { phase: 'Ingest, backup, transcode', who: 'Us',    days: 1,  wait: false, note: 'Two copies on separate drives before anything else happens. The only irreplaceable step on this list.' },
    { phase: 'Assembly cut',             who: 'Us',     days: 3,  wait: false, note: 'Structure only, no polish. Sent long and rough on purpose, so notes land on the shape rather than on the typography.' },
    { phase: 'Your notes, round one',    who: 'You',    days: 5,  wait: true,  note: 'The longest single stretch of the project. A working week is what it takes when three people have to agree and one of them travels.' },
    { phase: 'Cut two',                  who: 'Us',     days: 3,  wait: false, note: 'Where the film actually gets made. Round one notes are almost always structural.' },
    { phase: 'Your notes, round two',    who: 'You',    days: 3,  wait: true,  note: 'Shorter, because the argument has already happened. Still longer than the cut it is reviewing.' },
    { phase: 'Colour, sound, graphics',  who: 'Us',     days: 2,  wait: false, note: 'Locked picture only. Grading a cut that can still change is work thrown away.' },
    { phase: 'Captions and versioning',  who: 'Us',     days: 1,  wait: false, note: 'Every ratio and length in the deliverable set below, plus burned and sidecar captions.' },
    { phase: 'Delivery and archive',     who: 'Us',     days: 1,  wait: false, note: 'Files, not a streaming link. Plus the archive terms — see the FAQ.' },
  ],
  // The totals in the copy are summed from `phases` at build time rather than
  // typed, so an edit to one row cannot leave the prose claiming something the
  // table no longer says. Day 88 shipped exactly that mistake.
  note:
    'That is not a complaint about clients — it is the only part of the schedule you actually ' +
    'control, which makes it the most useful number on this page. Every other row is ours to ' +
    'compress and most of them are already as short as they go.',
};

// ── Deliverables ──────────────────────────────────────────────────────────

export const deliverables = {
  intro:
    'You asked for "a video". What ships is a set — and the set is where both the price and the ' +
    'schedule live. A quote that says "1 × video" is hiding this table, not simplifying it.',
  rows: [
    { name: 'Hero cut',         ratio: '16:9',  len: '90s',  where: 'Site header, events, sales decks', hours: 22, note: 'The one everything else is cut down from. Everything below is cheap because this exists.' },
    { name: 'Short cut',        ratio: '16:9',  len: '30s',  where: 'Paid social, pre-roll',            hours: 4,  note: 'Not a trim. A 30 needs its own structure or it reads as a film with the end missing.' },
    { name: 'Vertical',         ratio: '9:16',  len: '30s',  where: 'Reels, Shorts, TikTok',            hours: 5,  note: 'The expensive one. Reframing every shot by hand is what the hours are, and it is why "just crop it" produces work nobody uses.' },
    { name: 'Square',           ratio: '1:1',   len: '30s',  where: 'Feed posts',                        hours: 2,  note: 'Cheap once the vertical exists, because the hard reframing decisions are already made.' },
    { name: 'Bumper',           ratio: '16:9',  len: '6s',   where: 'Pre-roll, loops',                   hours: 1,  note: 'Six seconds. Frequently the most-watched thing we make for a client.' },
    { name: 'Captions',         ratio: '—',     len: 'All',  where: 'Burned in and .srt sidecar',        hours: 3,  note: 'Both, always. Burned for social where sound is off; sidecar so your platform can index the words.' },
    { name: 'Stills',           ratio: '3:2',   len: '20 ×', where: 'Press, decks, site',                hours: 2,  note: 'Pulled from a stills camera on the day, not frame-grabbed. Frame grabs look like frame grabs.' },
    { name: 'Camera archive',   ratio: '—',     len: '~1 TB', where: 'Handed over on a drive',           hours: 1,  note: 'Yours. See the FAQ for how long we keep a copy and what happens after that.' },
  ],
};

// ── Revisions ─────────────────────────────────────────────────────────────

export const rounds = {
  intro:
    'Two rounds are included, and the number that surprises people is not the money — it is the ' +
    'calendar. A round of notes is not a day. It is a working week.',
  items: [
    { n: 'Round one',   cost: 'Included', days: '5 days', gets: 'Structure. Order, length, what stays and what goes.',
      why: 'Sent as a rough assembly on purpose. Notes on colour or type at this stage are notes on work that is about to be replaced.' },
    { n: 'Round two',   cost: 'Included', days: '3 days', gets: 'Refinement. Timing, music, the specific words on screen.',
      why: 'Picture is locked at the end of this round. Anything after it is a change to a graded, mixed, captioned film in eight versions.' },
    { n: 'Round three', cost: '$480',     days: '+4 days', gets: 'Anything, but it re-runs the whole finishing pass.',
      why: 'Not a penalty and not an upsell — it is the cost of redoing colour, sound, captions and every ratio in the set. Most projects never need it.' },
  ],
  honest:
    'One round of notes from one named decision-maker beats three rounds from a committee, every ' +
    'time and by a wide margin. If your notes have to be assembled from four people, tell us in ' +
    'the scoping call and we will build the schedule around it rather than discovering it in week four.',
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Brand film, the set above',  figure: '$6,400', note: 'One shoot day, the full calendar above, every deliverable in the table. The number this whole page is describing.' },
    { what: 'Additional shoot day',       figure: '$1,250', note: 'Adds roughly four working days downstream, not one. More footage is more edit.' },
    { what: 'Interview day, 2–4 people',  figure: '$2,900', note: 'Single location, two cameras, delivered as one cut plus per-person shorts.' },
    { what: 'Event coverage',             figure: '$1,850', note: 'Up to eight hours, one highlight cut inside a week. Different schedule entirely — see the FAQ.' },
    { what: 'Edit only, your footage',    figure: '$95/hr', note: 'Estimated in writing before we start, and I will tell you if the footage will not support the cut you want.' },
    { what: 'Extra deliverable version',  figure: 'Per the table', note: 'Priced from the hours column above rather than invented per quote.' },
  ],
};

export const said = [
  { text: 'The schedule was the pitch. Everyone else sent a reel and a number; Marisol sent the calendar and told us which weeks were ours. We hit the launch date because we knew in week one exactly when our notes were due.',
    who: 'Operations director, regional healthcare network' },
  { text: 'We were late on round one by eight days and the delivery moved by eight days. Nobody was annoyed, because it had been on the page from the start.',
    who: 'Marketing lead, outdoor equipment brand' },
];

export const faqs = [
  {
    q: 'Can we compress the six weeks?',
    a: 'Yes, and the only lever that actually works is your side of it. Eleven of the thirty-three days are us waiting. Name one decision-maker, block time for notes in advance, and a six-week project becomes a four-week one without anybody rushing the edit.',
  },
  {
    q: 'Why does the vertical cost more than the square?',
    a: 'Because every shot has to be reframed by hand for 9:16 — a composition built for a wide frame does not survive a crop. Once that work exists the square is nearly free, which is why the two sit so far apart in the hours column.',
  },
  {
    q: 'Do we own the footage?',
    a: 'Yes. The camera archive is handed over on a drive at delivery. I keep a copy for twelve months as insurance, tell you the month it is scheduled to be deleted, and will keep it longer for a storage fee if you ask.',
  },
  {
    q: 'What if we need a change after picture lock?',
    a: 'It becomes round three, which is $480 and about four extra days. That is not a penalty — a locked film has been graded, mixed, captioned and versioned eight ways, so a change to it is a change to eight files.',
  },
  {
    q: 'Is event coverage on this schedule too?',
    a: 'No, and it is worth saying so plainly: events are a different product. One highlight cut inside a week, one round of notes, no versioning set. If you want the full set from event footage it goes back onto the calendar above.',
  },
  {
    q: 'Do you deliver a link or files?',
    a: 'Files, over a transfer service, plus a review link during the edit. A streaming link is not a deliverable — it is a page that can be taken down, and you paid for the video rather than for access to it.',
  },
];
