import { test, expect } from '@playwright/test';
import { VIEWPORTS } from './helpers';

const THIRD_PARTY_NOISE = [
  /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i,
  /failed to load resource/i,
];

test.describe('Home page', () => {
  test('renders h1', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const text = await h1.textContent();
    expect(text).toBeTruthy();
  });

  test('treatments section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#treatments');
    await expect(section).toBeVisible();
  });

  test('before-after results section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#results');
    await expect(section).toBeVisible();
  });

  test('about section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#about');
    await expect(section).toBeVisible();
  });

  test('FAQ section is present and accordion works', async ({ page }) => {
    await page.goto('/');
    const faqSection = page.locator('#faq');
    await expect(faqSection).toBeVisible();

    // Test accordion toggle
    const firstTrigger = page.locator('.faq-trigger').first();
    await expect(firstTrigger).toHaveAttribute('aria-expanded', 'false');
    await firstTrigger.click();
    await expect(firstTrigger).toHaveAttribute('aria-expanded', 'true');
    const panel = page.locator('.faq-panel.is-open').first();
    await expect(panel).toBeVisible();
  });

  test('booking CTA links exist', async ({ page }) => {
    await page.goto('/');
    const bookLinks = page.locator('a[href*="vagaro"]');
    const count = await bookLinks.count();
    expect(count).toBeGreaterThan(0);
  });

  test('all images have alt text', async ({ page }) => {
    await page.goto('/');
    const images = page.locator('img');
    const count = await images.count();
    for (let i = 0; i < count; i++) {
      const alt = await images.nth(i).getAttribute('alt');
      expect(alt, `Image ${i} missing alt`).toBeTruthy();
    }
  });

  test('nav landmarks are present', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('header[role="banner"]')).toBeVisible();
    await expect(page.locator('main')).toBeVisible();
    await expect(page.locator('footer[role="contentinfo"]')).toBeVisible();
  });

  test('no console errors (excluding third-party)', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const text = msg.text();
        const isThirdParty = THIRD_PARTY_NOISE.some(re => re.test(text));
        if (!isThirdParty) errors.push(text);
      }
    });
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    expect(errors).toEqual([]);
  });

  for (const vp of VIEWPORTS) {
    test(`renders without overflow at ${vp.name} (${vp.width}px)`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto('/');
      await page.waitForLoadState('networkidle');
      const bodyWidth = await page.evaluate(() => document.body.scrollWidth);
      expect(bodyWidth).toBeLessThanOrEqual(vp.width + 2);
    });
  }
});
