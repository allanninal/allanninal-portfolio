import type { Page } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';

// Single-page template; the Pro edition adds the Treatment Plans & Memberships page.
export const ROUTES = isPro ? ['/', '/memberships/'] : ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(_page: Page, _theme: 'light' | 'dark') {
  // Esthetician Skincare is light-only; no theme toggle needed
}
