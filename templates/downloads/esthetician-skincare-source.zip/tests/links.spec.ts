import { test, expect } from '@playwright/test';

test('no broken internal links', async ({ page }) => {
  await page.goto('/');

  // Collect all internal anchor hrefs (skip external, tel, mailto)
  const hrefs = await page.evaluate(() => {
    return Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href]'))
      .map(a => a.getAttribute('href') ?? '')
      .filter(h => h.startsWith('#') || h.startsWith('/'));
  });

  // Hash links: verify the target element exists
  const hashLinks = hrefs.filter(h => h.startsWith('#'));
  for (const hash of hashLinks) {
    const id = hash.slice(1);
    if (!id) continue;
    const el = page.locator(`#${id}`);
    const count = await el.count();
    expect(count, `Missing element for hash link: ${hash}`).toBeGreaterThan(0);
  }
});
