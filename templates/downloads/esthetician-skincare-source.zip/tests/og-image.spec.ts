import { test } from '@playwright/test';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

test('generate og-image.png', async ({ page }) => {
  const svgPath = path.resolve(__dirname, '../public/og-image.svg');
  await page.goto(`file://${svgPath}`);
  await page.setViewportSize({ width: 1200, height: 630 });
  await page.screenshot({
    path: path.resolve(__dirname, '../public/og-image.png'),
    clip: { x: 0, y: 0, width: 1200, height: 630 },
  });
});
