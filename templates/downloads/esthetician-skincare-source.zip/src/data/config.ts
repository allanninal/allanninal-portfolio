export const esthetician = {
  name:        'Sofía Reyes, LE',
  businessName:'Sofía Reyes Skincare',
  tagline:     'Results-driven skincare rooted in science, delivered with care.',
  description:
    'Licensed Esthetician in Denver, CO with 7 years of experience specializing in transformative facials, chemical peels, microneedling, and advanced skincare treatments.',
  address:     '250 Fillmore St, Suite 305, Denver, CO 80206',
  phone:       '+1 (720) 555-0193',
  email:       'landix.ninal@gmail.com',
  instagram:   'https://www.instagram.com/',
  facebook:    'https://www.facebook.com/',
  linkedin:    'https://www.linkedin.com/in/allanninal/',
  kofi:        'https://ko-fi.com/allanninal',
  bookingUrl:  'https://vagaro.com/',
  credentials: [
    'Colorado State Licensed Esthetician #ES-58294',
    'CIDESCO International Diploma — Beauty & Skincare Therapy',
    'SkinPen Certified — Microneedling (Collagen Induction Therapy)',
    'PCA Skin Certified — Advanced Chemical Peels & Protocols',
    'Dermaplaning Certified — National Cosmetic Laser Schools',
  ],
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '9:00 am – 6:00 pm' },
    { day: 'Wednesday', open: '9:00 am – 7:00 pm' },
    { day: 'Thursday',  open: '10:00 am – 7:00 pm' },
    { day: 'Friday',    open: '9:00 am – 5:00 pm' },
    { day: 'Saturday',  open: '8:00 am – 4:00 pm' },
    { day: 'Sunday',    open: 'Closed' },
  ],
};

export const site = {
  title:         'Sofía Reyes Skincare — Licensed Esthetician, Denver CO',
  description:
    'Licensed Esthetician in Denver, CO. Facials, chemical peels, microneedling, dermaplaning, LED therapy & deep cleanse treatments. Book online via Vagaro.',
  language:      'en',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
};

export type Treatment = {
  id:          string;
  name:        string;
  tagline:     string;
  duration:    string;
  price:       string;
  description: string;
  benefits:    string[];
  highlight?:  boolean;
  icon:        string;
};

export const treatments: Treatment[] = [
  {
    id:        'classic-facial',
    name:      'Classic Custom Facial',
    tagline:   'The foundation of every great skincare routine',
    duration:  '60 min',
    price:     '$115',
    icon:      '◇',
    description:
      'A fully customized treatment beginning with a detailed skin analysis. Double cleanse, enzyme exfoliation, steam, manual extractions, targeted masking, and a finishing serum tailored to your Fitzpatrick skin type and current concerns.',
    benefits:  ['Deep pore cleansing', 'Manual extractions', 'Customized masking', 'Skin barrier repair'],
  },
  {
    id:        'chemical-peel',
    name:      'Chemical Peel',
    tagline:   'Reveal brighter, smoother skin in one session',
    duration:  '45 min',
    price:     '$145',
    icon:      '◈',
    highlight: true,
    description:
      'Medical-grade PCA Skin peels — ranging from superficial glycolic/lactic blends to mid-depth salicylic and TCA formulas — address hyperpigmentation, texture, active acne, and fine lines. Peel depth is determined after a skin consultation.',
    benefits:  ['Fades dark spots', 'Smooths texture', 'Controls active acne', 'Stimulates collagen'],
  },
  {
    id:        'microneedling',
    name:      'Microneedling',
    tagline:   'Collagen induction for visible anti-aging results',
    duration:  '75 min',
    price:     '$295',
    icon:      '◉',
    description:
      'FDA-cleared SkinPen creates controlled micro-channels to trigger the skin\'s natural healing cascade. Builds collagen and elastin over 4–6 weeks, dramatically reducing fine lines, acne scars, enlarged pores, and loss of firmness. Includes healing serum application and post-care kit.',
    benefits:  ['Reduces acne scars', 'Firms & tightens', 'Minimizes pores', 'Stimulates natural collagen'],
  },
  {
    id:        'dermaplaning',
    name:      'Dermaplaning',
    tagline:   'Instant glow, zero downtime',
    duration:  '45 min',
    price:     '$95',
    icon:      '✦',
    description:
      'A surgical-grade scalpel gently removes the top layer of dead skin cells and vellus hair ("peach fuzz"). Instantly reveals a smoother, brighter surface and allows serums and makeup to absorb more effectively. Safe for all skin types except active breakouts.',
    benefits:  ['Removes vellus hair', 'Instant luminosity', 'Product penetration +40%', 'Zero recovery time'],
  },
  {
    id:        'led-therapy',
    name:      'LED Light Therapy',
    tagline:   'Science-backed light for skin renewal',
    duration:  '30 min',
    price:     '$65',
    icon:      '◯',
    description:
      'NASA-developed wavelength technology using red (630nm) and near-infrared (830nm) light to stimulate fibroblast activity, reduce inflammation, and accelerate healing. Ideal as a standalone treatment or add-on to any service. A series of 6–8 sessions recommended for maximum results.',
    benefits:  ['Accelerates healing', 'Reduces redness', 'Boosts collagen synthesis', 'Safe for all skin types'],
  },
  {
    id:        'deep-cleanse',
    name:      'Advanced Deep Cleanse',
    tagline:   'Congested skin\'s best friend',
    duration:  '75 min',
    price:     '$155',
    icon:      '⊕',
    description:
      'A multi-step deep-pore protocol combining hydra-exfoliation, high-frequency treatment, and an enzyme mask designed for congested, oily, or acne-prone skin. Leaves pores visibly smaller and skin deeply cleared without the irritation of harsh scrubs.',
    benefits:  ['Deep pore extraction', 'High-frequency sterilization', 'Sebum regulation', 'Minimizes blackheads'],
  },
];

export type AddOn = {
  name:        string;
  price:       string;
  description: string;
};

export const addOns: AddOn[] = [
  { name: 'Nano Infusion Add-on',   price: '+$45', description: 'Delivers active serums 40x deeper via nano-needle channel technology. Boosts any facial result.' },
  { name: 'Collagen Eye Treatment', price: '+$35', description: 'Hydrogel collagen patches + peptide serum for dark circles, puffiness, and crow\'s feet.' },
  { name: 'Lip Plump & Hydrate',    price: '+$25', description: 'Hyaluronic acid lip treatment for definition and moisture — no filler needed.' },
  { name: 'Gua Sha Lymphatic Lift', price: '+$30', description: 'Facial massage with rose quartz tools to drain lymph, depuff, and sculpt the jaw.' },
];

export type BeforeAfter = {
  id:          string;
  treatment:   string;
  sessions:    string;
  result:      string;
  clientNote:  string;
};

export const beforeAfters: BeforeAfter[] = [
  {
    id:         'hyperpigmentation',
    treatment:  'Chemical Peel Series (4 sessions)',
    sessions:   '4 sessions over 8 weeks',
    result:     'Visible fading of post-inflammatory hyperpigmentation and sun damage',
    clientNote: '"My dark spots from years of sun exposure faded by about 70% after the peel series. I stopped wearing heavy foundation for the first time in a decade." — Amara T.',
  },
  {
    id:         'acne-scars',
    treatment:  'Microneedling (3 sessions)',
    sessions:   '3 sessions over 12 weeks',
    result:     'Significant reduction in rolling and boxcar acne scars; improved skin texture',
    clientNote: '"The microneedling changed everything for me. My scars that I\'d had for 8 years are almost invisible now." — Jordan M.',
  },
  {
    id:         'anti-aging',
    treatment:  'Microneedling + LED Therapy Combo',
    sessions:   '4 sessions over 10 weeks',
    result:     'Measurable improvement in skin firmness, fine line reduction, and overall radiance',
    clientNote: '"People keep asking if I\'ve had work done. I\'ve only had four sessions with Sofía." — Priya R.',
  },
];

export const testimonials = [
  {
    quote:   'Sofía has completely transformed my skin. I came in with cystic acne and hyperpigmentation and left every session with a plan, not just a product pitch. My skin has never looked this good in my adult life.',
    author:  'Camille D.',
    service: 'Classic Facial + Peel Series',
    rating:  5,
  },
  {
    quote:   'The microneedling was scary to me at first but Sofía walked me through every step. Three sessions in and the scarring from teenage acne is genuinely fading. I cry happy tears at my skin now.',
    author:  'Tayla M.',
    service: 'Microneedling Series',
    rating:  5,
  },
  {
    quote:   'I used Sofía for my bridal skincare for 4 months before my wedding. My skin was literally glowing on the day. My photographer said she barely had to retouch anything. Worth every single dollar.',
    author:  'Elena K.',
    service: 'Bridal Skincare Package',
    rating:  5,
  },
  {
    quote:   'The dermaplaning felt like magic — I couldn\'t believe how much product my serums absorbed differently afterward. I am never going a month without this treatment again.',
    author:  'Bri P.',
    service: 'Dermaplaning',
    rating:  5,
  },
  {
    quote:   'I\'ve been to a lot of estheticians. Sofía is different — she actually listens, explains the science behind what she\'s recommending, and doesn\'t oversell. My skin has been on a 6-month streak of looking great.',
    author:  'Marcus O.',
    service: 'Classic Facial — monthly',
    rating:  5,
  },
];

export const faqs = [
  {
    q: 'How do I know which treatment is right for my skin?',
    a: "Every new client begins with a complimentary skin consultation (15 minutes, in-person or video). I assess your skin type, Fitzpatrick phototype, current concerns, and skincare history before recommending a starting treatment. You\'ll never be upsold to something your skin doesn\'t need.",
  },
  {
    q: 'What should I do to prepare for my appointment?',
    a: 'Come with a clean, makeup-free face if possible. Avoid retinoids (tretinoin, retinol) for 48–72 hours before any facial or peel. If you\'re booked for a chemical peel or microneedling, avoid active sun exposure for 5–7 days prior and notify me of any recent skincare changes or active breakouts.',
  },
  {
    q: 'Is there downtime after a chemical peel or microneedling?',
    a: 'Chemical peels: superficial peels have minimal downtime (some flaking days 2–4). Mid-depth peels may cause 3–5 days of visible peeling — plan around social events. Microneedling: skin is pink for 12–24 hours and slightly dry for 2–3 days. Makeup is fine 24 hours post-treatment. Full results emerge 4–6 weeks after microneedling as collagen remodels.',
  },
  {
    q: 'How often should I get a facial?',
    a: 'For most skin types, a facial every 4–6 weeks aligns with your skin\'s natural cell turnover cycle. If you\'re targeting a specific concern (acne, hyperpigmentation, aging), I\'ll recommend a more intensive series schedule — typically 4–6 treatments spaced 2–4 weeks apart.',
  },
  {
    q: 'Can I get a chemical peel if I have sensitive skin?',
    a: 'Absolutely. Peel selection is always customized to your sensitivity level. I use lactic acid and enzyme peels for sensitive skin — these are gentle exfoliators that deliver results without harsh side effects. We discuss your skin\'s history before any peel is applied.',
  },
  {
    q: 'Do you offer bridal skincare packages?',
    a: 'Yes — bridal skincare is one of my specialties. I recommend starting at least 3–4 months before your wedding date to allow time for a targeted treatment series. I offer custom bridal consultation packages that build a timeline around your event. Inquire via the booking link or phone.',
  },
  {
    q: 'What products do you use and retail?',
    a: 'I use and retail PCA Skin, iS Clinical, and Eminence Organics — professional-grade lines chosen for their clinical efficacy and ingredient transparency. I\'ll recommend a simplified home-care routine that complements your in-studio treatments without overwhelming your bathroom shelf.',
  },
  {
    q: 'What is your cancellation and rescheduling policy?',
    a: 'Please cancel or reschedule at least 24 hours before your appointment via Vagaro to avoid a 50% late-cancel fee. For microneedling appointments (which require a prep protocol), I ask for 48 hours notice. Same-day cancellations for reasons outside your control are handled case by case — always call or text rather than emailing.',
  },
];

export const stats = [
  { value: '7+',    label: 'Years of Experience' },
  { value: '1,800+', label: 'Clients Treated' },
  { value: '4.97★', label: 'Average Rating' },
  { value: '6',     label: 'Signature Treatments' },
];

export const trustPoints = [
  {
    icon: '◇',
    title: 'Colorado State Licensed',
    body:  'License #ES-58294, current and in good standing. CIDESCO internationally certified — the gold standard in global esthetics.',
  },
  {
    icon: '◈',
    title: 'Medical-Grade Technology',
    body:  'FDA-cleared SkinPen for microneedling. PCA Skin advanced peel protocols used in dermatologist offices. No gimmicks — only clinically validated tools.',
  },
  {
    icon: '✦',
    title: 'Ingredient-First Philosophy',
    body:  'Every recommendation is grounded in ingredient science, not brand loyalty. I\'ll explain the "why" behind every product and treatment step.',
  },
  {
    icon: '◉',
    title: 'Private Studio Experience',
    body:  'A calm, unhurried private suite in Cherry Creek North. One client at a time — you\'re never rushed out for the next appointment.',
  },
];

export const studioAmenities = [
  'Private heated treatment table',
  'Medical-grade sterilization protocols',
  'Complimentary robe and slippers',
  'Organic herbal tea & water bar',
  'Complimentary skincare consultation',
  'Retail product corner',
];
