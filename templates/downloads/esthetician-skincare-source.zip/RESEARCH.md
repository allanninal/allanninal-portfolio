# Day 56 — Esthetician / Skincare: Niche Research

## Slug
`esthetician-skincare`

## Differentiation from Days 1–55

### Visual register audit (wellness / beauty days)
| Day | Palette family | Fonts |
|-----|---------------|-------|
| 55 tattoo-studio | ink-black / bone-white / amber-gold | Bebas Neue + Barlow |
| 54 massage-therapist | deep-ocean-teal / warm-sand / linen | Libre Baskerville + Source Sans 3 |
| 53 day-spa | sage / stone / pearl cream | Crimson Pro + Raleway |
| 52 nail-salon | coral / rose-gold / plum | Italiana + Plus Jakarta Sans |
| 51 barbershop | near-black / oxblood / brass | Teko + Hind |
| 50 hair-salon | mauve / champagne / ivory | Bellefair + Questrial |

### Day 56 distinct visual register
- **Palette**: Blush Ivory (#FDF8F4) + Warm Clay (#C2705A) + Forest Green (#2D5016) as accent + Parchment (#EFE6DC)
  - No sage (day 53), no teal (day 54), no coral (day 52), no mauve (day 50)
  - Forest green is a deep, rich botanical green — completely distinct from sage's muted grey-green
  - Warm Clay replaces the warm-sand/sand of day 54 with a terracotta-warm skin-tone hue
  - Blush ivory is a step warmer/pinker than linen — feels more skin-adjacent
  - Very light background with rich accents: clean, clinical, luxe
- **Typography**: DM Serif Display (display headings — editorial, feminine, refined) + DM Sans (body — clean, modern)
  - Neither used in any prior day
  - DM Serif Display is the ideal pairing for boutique skincare — editorial without fuss
  - DM Sans is highly legible for treatment descriptions and pricing
- **Density**: Airy, photo-driven — results sell esthetics, so before/after + treatment imagery lead

## Persona
**Sofía Reyes, LE** — Licensed Esthetician, Denver CO (Cherry Creek)
- Credentials: Colorado State Licensed Esthetician, CIDESCO diploma, advanced peel certified (PCA Skin), dermaplaning certified, microneedling (SkinPen)
- Niche: Results-driven skincare for hyperpigmentation, anti-aging, and acne scars; bridal skincare a specialty
- Tone: warm, knowledgeable, evidence-based ("ingredient-first") — clinical authority meets personal care
- Booking platform: Vagaro (common for solo estheticians)
- Location: private studio suite, Cherry Creek North, Denver CO
- 7 years in practice, formerly at a medical spa

## Sections (single-page)
1. **Hero** — split-panel: copy left, treatment/glowing-skin photo right, name + license badge, Book CTA
2. **Stats band** — 4 key numbers (years exp, clients served, 5-star reviews, treatments offered)
3. **Treatments Menu** — 6 treatments with duration + price cards (Classic Facial, Chemical Peel, Microneedling, Dermaplaning, LED Therapy, Hydrafacial-style Deep Cleanse)
4. **Before/After Results** — tasteful 3-pairing layout with treatment label + client note
5. **About Sofía** — bio, credentials, philosophy headshot section
6. **Studio** — brief "the space" callout with studio image + amenity list
7. **Testimonials** — 5 client quotes
8. **FAQ** — 8 skincare-specific questions (accordion)
9. **Hours & Booking** — schedule table + Vagaro booking CTA
10. **Footer** — links, address, social handles

## Schema.org
- `HealthAndBeautyBusiness` + `LocalBusiness`
- `Person` (the esthetician)
- `Service` + `Offer` for each treatment
- `FAQPage` for the FAQ section

## Color contrast checks (CRITICAL — skincare palettes skew pale)
- Forest Green (#2D5016) on Blush Ivory (#FDF8F4): contrast ratio ≈ 9.8:1 — AAA ✓
- Warm Clay (#C2705A): on Blush Ivory ≈ 3.3:1 — FAILS for text
  → Darken to #8B3F2A for body text use: on #FDF8F4 ≈ 5.9:1 — AA ✓
  → Warm Clay (#C2705A) used ONLY for decorative accents/borders, not text
- Text on Forest Green buttons: white (#FFFFFF) on #2D5016 = 9.8:1 — AAA ✓
- Muted text: #5C3D2E on #FDF8F4 = ≈ 5.5:1 — AA ✓
- Subtle text: #7A5142 on #FDF8F4 = ≈ 4.5:1 — AA ✓ (borderline — verify)
- White on dark footer (#1C2B0E): ≈ 14:1 — AAA ✓

## Image plan
5 Unsplash photos — all unique, non-duplicating registry entries:
1. hero.jpg — facial treatment, woman receiving skincare, bright studio
2. about.jpg — esthetician portrait / skincare professional headshot  
3. studio.jpg — clean esthetics studio interior, treatment table
4. before-after-texture.jpg — close-up skin texture (glowing, clear skin result shot)
5. treatment-peel.jpg — facial treatment / chemical peel application close-up

## Key differentiators from day-spa (Day 53) and massage-therapist (Day 54)
1. **Before/after results section** — unique to this template; sells transformations
2. **Treatment menu with medical aesthetics** (microneedling, chemical peels) vs massage modalities
3. **Dermaplaning, LED, Hydrafacial** — esthetics-specific treatments, not spa services
4. **Cherry Creek Denver** — different geography from Portland OR (massage), not a generic spa city
5. **Ingredient-first / results language** — clinical skincare language, not wellness/relaxation
6. **Vagaro** booking vs Jane App (massage)
7. **Forest green + clay palette** — completely distinct from sage/teal/mauve registers used in prior wellness days
