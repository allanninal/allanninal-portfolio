import { test, expect } from '@playwright/test';

test.describe('Second Room — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Second Room/);
    await expect(page.locator('h1')).toContainText('happens once');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The run of show ─────────────────────────────────────────────────────
  test('every slot is marked in words, not by colour', async ({ page }) => {
    await page.goto('/');
    const marks = await page.locator('#run .slot-mark').allTextContents();
    expect(marks.length).toBe(10);
    for (const m of marks) {
      expect(['Once only', 'Repeatable', 'Stageable after']).toContain(m.trim());
    }
  });

  test('the headline count is derived from the run', async ({ page }) => {
    await page.goto('/');
    const marks = (await page.locator('#run .slot-mark').allTextContents()).map((s) => s.trim());
    const once = marks.filter((m) => m === 'Once only').length;
    await expect(page.locator('h1 ~ p').first())
      .toContainText(`${once} of the ${marks.length} moments below cannot be photographed twice`);
  });

  test('slots run in chronological order', async ({ page }) => {
    await page.goto('/');
    const times = await page.locator('#run .slot-time').allTextContents();
    const mins = times.map((t) => { const [h, m] = t.trim().split(':').map(Number); return h * 60 + m; });
    for (let i = 1; i < mins.length; i++) expect(mins[i]).toBeGreaterThanOrEqual(mins[i - 1]);
  });

  // The evidence sits in the slot it illustrates, not in a gallery elsewhere.
  test('photographs sit inside the slots they illustrate', async ({ page }) => {
    await page.goto('/');
    const shots = page.locator('#run li.slot figure.slot-shot img');
    expect(await shots.count()).toBe(4);
    for (const s of await shots.all()) {
      const alt = (await s.getAttribute('alt')) || '';
      expect(alt.length).toBeGreaterThan(30);
      expect(await s.getAttribute('width')).toBeTruthy();
    }
    // And there is no separate gallery repeating them.
    expect(await page.locator('#moments').count()).toBe(0);
  });

  test('all images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  // The rail duplicates the list, so it must not be announced.
  test('the time axis is decorative and the list is the text equivalent', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#run figure.rail svg')).toHaveAttribute('aria-hidden', 'true');
    expect(await page.locator('#run figure.rail svg line').count()).toBeGreaterThan(15);
    await expect(page.locator('#run .rail-scale')).toContainText(/do not come round again/i);
  });

  test('the clashes sit inside the run they conflict within', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#run article.clash').count()).toBe(3);
    await expect(page.locator('#run')).toContainText(/Not an upsell|arithmetic/i);
    // And the studio says a second camera is often unnecessary.
    await expect(page.locator('#run')).toContainText(/Frequently it can/i);
  });

  test('organisers say what a previous photographer missed', async ({ page }) => {
    await page.goto('/');
    const q = page.locator('#need blockquote.missed');
    expect(await q.count()).toBe(2);
    for (const one of await q.all()) {
      await expect(one.locator('cite')).toHaveCount(1);
    }
  });

  test('same-night delivery is included rather than an extra', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#rates');
    await expect(r).toContainText(/decays inside 48 hours/i);
    const row = r.locator('.term', { hasText: 'Same-night delivery' });
    await expect(row).toContainText('Included');
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-99 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['good dog', 'missoula', 'black coat', 'spotter', 'old standard']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro run of show is absent from the free build', async ({ page }) => {
    const res = await page.goto('/run-of-show/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
