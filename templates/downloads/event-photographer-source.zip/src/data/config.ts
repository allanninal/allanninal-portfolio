// Second Room — Omaha, NE.
//
// Tenth photography template, tenth axis: what you cannot get back.
//
// Every other page in this run photographs something that will still be there
// tomorrow — a room, a product, a person, a dish. An event will not be, and
// that changes what the CLIENT has to do rather than what the photographer does.

export const site = {
  name:        'Second Room',
  shortName:   'Second Room',
  title:       'Second Room — Event Photography in Omaha, NE',
  tagline:     'An event happens once.',
  owner:       'Marguerite Adeyemi',
  ownerRole:   'Event photographer',
  credential:  'Conferences, awards and launches · Omaha',
  license:     'Event photography, working since 2015',
  city:        'Omaha',
  state:       'NE',
  language:    'en',
  phoneDisplay: '(402) 555-0193',
  phoneHref:   '+14025550193',
  email:       'book@secondroom.example',
  streetAddress: '1105 Jones St',
  postalCode:  '68102',
  hours:       'Weekdays and weekends · same-night delivery as standard',
  bookingWindow: 'Booking eight weeks out. Late enquiries answered the same day.',
  description:
    'Event photography in Omaha. Half of what you are paying for is the thirty seconds ' +
    'nobody can schedule twice — so this page marks a real run of show with which moments ' +
    'are recoverable and which are gone the moment they happen.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The run of show', href: '#run' },
  { label: 'What we need',    href: '#need' },
  { label: 'Rates',           href: '#rates' },
  { label: 'Book',            href: '#book' },
];

// ── The run of show ───────────────────────────────────────────────────────
// mark: 'once' | 'rep' | 'stage'

export const run = [
  { time: '08:30', what: 'Room empty, branding up',      mark: 'rep',
    note: 'Shot before anyone arrives and re-shootable all morning. Worth ten minutes because it is the only time the room is clean.' },
  { time: '09:00', what: 'Registration and arrivals',    mark: 'rep',
    note: 'A steady stream for forty minutes. Missing the first face costs nothing.' },
  { time: '09:20', what: 'The room filling',             mark: 'once', file: 'e04.jpg',
    alt: 'A packed auditorium of red seats photographed from a high side balcony',
    note: 'A ten-minute window between two-thirds full and everyone seated. After that it is a photograph of the backs of heads.' },
  { time: '09:30', what: 'Opening remarks',              mark: 'rep', file: 'e03.jpg',
    alt: 'A speaker gesturing mid-sentence in a bright room with another panellist seated behind',
    note: 'Twenty minutes of a person at a lectern. Four usable angles exist and all four are available throughout.' },
  { time: '09:45', what: 'The announcement, and the room reacting', mark: 'once', file: 'e02.jpg',
    alt: 'A crowd silhouetted against stage lights and haze, arms raised toward the stage',
    note: 'The single most valuable frame of the day and it lasts about four seconds. It is why the second camera is pointed at the audience, not the stage.' },
  { time: '10:30', what: 'Coffee, people talking',       mark: 'rep',
    note: 'The bulk of any event. Genuinely useful for next year’s marketing and genuinely repeatable.' },
  { time: '12:00', what: 'Award handshake',              mark: 'once',
    note: 'On stage, once, from one position. If two are given simultaneously one of them will not be photographed.' },
  { time: '12:05', what: 'Award portrait',               mark: 'stage',
    note: 'Five minutes later in the corridor, against a clean wall, both people looking at the camera. Almost always better than the handshake and nobody thinks to ask for it.' },
  { time: '13:30', what: 'Panel discussion',             mark: 'rep', file: 'e01.jpg',
    alt: 'A panellist holding a handheld microphone at a table of open laptops during a session',
    note: 'Forty minutes, four people, all reachable. Long enough to get every one of them mid-sentence rather than mid-blink.' },
  { time: '17:00', what: 'Close, and the room emptying', mark: 'once',
    note: 'Nobody books this and it is frequently the best frame of the day.' },
];

export const runNote =
  'This is the organiser’s own document with the photographic reality written on it. ' +
  'Everything marked repeatable can be fixed later in the day. Everything marked once ' +
  'is a decision about where a camera is standing at a particular minute, and those ' +
  'decisions are the job.';

// ── Two cameras — the arithmetic ──────────────────────────────────────────

export const clashes = {
  intro:
    'A second photographer is not an upsell, it is arithmetic. If two things you care about ' +
    'happen at the same minute, one camera photographs one of them. These are the three ' +
    'clashes that occur at almost every event.',
  rows: [
    { clash: 'Stage and reaction',   why: 'The announcement is on stage and the value is in the audience. One camera has to choose, and it will choose wrong about half the time.' },
    { clash: 'Two simultaneous awards', why: 'Common at any ceremony with categories. Two stages, or two people called at once, and a single camera simply misses one.' },
    { clash: 'Speaker and sponsor',  why: 'While the keynote runs, the sponsor stand is at its busiest and its most photogenic. Both matter to somebody who is paying.' },
  ],
  closing:
    'Tell us which two things clash and we will tell you honestly whether one camera can cover ' +
    'it. Frequently it can, and we will say so rather than sell you a second.',
};

// ── Moments ───────────────────────────────────────────────────────────────
// Alt strings written from the files.

export const moments = [
  { file: 'e01.jpg', cap: 'Panel, mid-sentence · repeatable',
    alt: 'A panellist holding a handheld microphone at a table of open laptops during a session' },
  { file: 'e02.jpg', cap: 'The room reacting · once only',
    alt: 'A crowd silhouetted against stage lights and haze, arms raised toward the stage' },
  { file: 'e03.jpg', cap: 'Speaker mid-gesture · repeatable',
    alt: 'A speaker gesturing mid-sentence in a bright room with another panellist seated behind' },
  { file: 'e04.jpg', cap: 'Room at capacity · ten-minute window',
    alt: 'A packed auditorium of red seats photographed from a high side balcony' },
];

// ── What we need from you ─────────────────────────────────────────────────

// Organisers, on what a previous photographer did not get. The whole argument
// of this page in two sentences that are not ours.
export const missed = [
  { said: 'We have four hundred photographs of a man at a lectern and none of the room when the number went up.',
    who: 'Head of communications, a trade body' },
  { said: 'The awards are fine. Nobody photographed the winner\'s face before she reached the stage.',
    who: 'Events lead, a professional institute' },
];

export const need = {
  intro:
    'Not a mood board. Four things, and the second one is the one nobody sends.',
  rows: [
    { item: 'A run of show with times',  why: 'Even a rough one. Everything on this page depends on knowing what happens when, and it is the difference between covering the day and following it around.' },
    { item: 'Four names, with faces',    why: 'Who must be in pictures. "Get the CEO with the award winner" is impossible if nobody can point at the CEO — send photographs or send a person who can.' },
    { item: 'Where the images go',       why: 'Same-night social, a press release, next year’s brochure, or an internal deck. Each wants a different set and we shoot accordingly.' },
    { item: 'One contact on the day',    why: 'Reachable by phone, not chairing a session. Ten seconds of "she is the one in green" saves a frame that cannot be retaken.' },
  ],
};

export const delivery = {
  headline: 'Most of the value decays inside 48 hours.',
  rows: [
    { what: 'Same night',   figure: '20–30', note: 'Culled, corrected and sent before midnight for the social team. This is the deliverable that matters most and it is included.' },
    { what: 'Next morning', figure: '60–80', note: 'The full working set, sized for press and web.' },
    { what: 'Within a week', figure: 'Everything', note: 'The complete take, colour-matched, with the award portraits named by recipient.' },
  ],
};

export const rates = {
  rows: [
    { what: 'Half day, up to 4 hours',  figure: '$740',  note: 'One photographer. Same-night set included.' },
    { what: 'Full day, up to 9 hours',  figure: '$1,290', note: 'One photographer. Most conferences fit here.' },
    { what: 'Second photographer',      figure: '$620',  note: 'Priced per day. Only worth it if you have a genuine clash — we will tell you.' },
    { what: 'Same-night delivery',      figure: 'Included', note: 'Not an extra. An event set that arrives in a week has already missed its moment.' },
    { what: 'Licence',                  figure: 'Included', note: 'Perpetual, all your own channels, press included.' },
    { what: 'Travel beyond 60 miles',   figure: 'At cost', note: 'Agreed before, itemised after.' },
  ],
};

export const faqs = [
  {
    q: 'Do we really need two photographers?',
    a: 'Only if two things you care about happen at the same minute. Send the run of show and we will tell you honestly — most single-track conferences do not, and most award ceremonies do.',
  },
  {
    q: 'What is the most important thing we can send you?',
    a: 'The run of show with times, and four names with faces attached. Almost nobody sends the second one and it is the difference between getting your chief executive in the pictures and getting somebody who looks a bit like them.',
  },
  {
    q: 'Can you re-shoot the keynote if we do not like it?',
    a: 'During the keynote, yes — it runs twenty minutes and there are four angles. Afterwards, no. That is the distinction this whole page is built on and it is worth reading the run of show for.',
  },
  {
    q: 'When do we get the pictures?',
    a: 'Twenty to thirty before midnight the same night, included as standard. The full set the next morning and everything within a week. An event gallery that arrives seven days later has missed the thing it was for.',
  },
  {
    q: 'What about the award photographs?',
    a: 'The handshake is once and we will get it. The portrait we stage five minutes later in a corridor is usually the one that gets used, and almost nobody thinks to ask for it — so we do it anyway.',
  },
  {
    q: 'Our event is next week. Too late?',
    a: 'Ask. Late enquiries get answered the same day and there is often a gap. What we cannot do at short notice is invent a second photographer for a Saturday.',
  },
];
