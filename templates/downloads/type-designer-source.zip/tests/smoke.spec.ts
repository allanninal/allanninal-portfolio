import { test, expect } from '@playwright/test';

const int = (s: string) => Number((s.match(/\d+/) || ['0'])[0]);

test.describe('Aldermann Type — smoke tests', () => {
  test('homepage renders with the foundry in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Aldermann Type/);
    await expect(page.locator('h1')).toContainText(/A typeface is \d+ glyphs/);
  });

  // The headline number is the largest family's real glyph count.
  test('the headline glyph count comes from the family data', async ({ page }) => {
    await page.goto('/');
    const counts = (await page.locator('#families .meta').allTextContents())
      .map((t) => Number((t.match(/(\d+)\s*glyphs/) || [])[1]));
    expect(counts.length).toBe(4);
    const h1 = int((await page.locator('h1').textContent()) || '');
    expect(h1).toBe(Math.max(...counts));
  });

  // An Organization plus one Product per family — not day 124's
  // ProfessionalService, not day 123's CreativeWork.
  test('each family is a Product with its glyph count', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const graph = JSON.parse(blocks.find((b) => b.includes('"@graph"'))!)['@graph'];
    expect(graph.length).toBe(4);
    for (const p of graph) {
      expect(p['@type']).toBe('Product');
      expect(p.additionalProperty.find((a: any) => a.name === 'Glyphs').value).toBeGreaterThan(100);
    }
    const all = blocks.join('');
    expect(all).toContain('"Organization"');
    expect(all).not.toContain('ProfessionalService');
    expect(all).not.toContain('creativeWorkStatus');
    expect(all).not.toContain('"offers"');
    expect(all).not.toContain('aggregateRating');
  });

  // The strict rule: only Full coverage reaches inLanguage.
  test('inLanguage lists only the language groups marked Full', async ({ page }) => {
    await page.goto('/');
    const graph = JSON.parse((await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('"@graph"'))!)))['@graph'];
    const langs: string[] = graph[0].inLanguage;
    expect(langs.length).toBeGreaterThan(4);
    // Every language named in a Partial or None row must be absent.
    const rows = await page.locator('#coverage tbody tr').evaluateAll((trs) =>
      trs.map((tr) => ({
        langs: (tr.querySelector('th')!.textContent || '').split(',').map((s) => s.trim()),
        state: (tr.querySelector('.state')!.textContent || '').trim(),
      })));
    for (const r of rows) {
      for (const l of r.langs) {
        if (r.state === 'Full') expect(langs).toContain(l);
        else expect(langs).not.toContain(l);
      }
    }
  });

  // ── Coverage ────────────────────────────────────────────────────────────
  test('every Partial row names the characters that are missing', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#coverage tbody tr');
    expect(await rows.count()).toBeGreaterThan(7);
    let partial = 0;
    for (const r of await rows.all()) {
      const state = ((await r.locator('.state').textContent()) || '').trim();
      const miss = ((await r.locator('.miss').textContent()) || '').trim();
      if (state === 'Partial') {
        partial++;
        expect(miss.length).toBeGreaterThan(12);
        expect(miss).not.toBe('—');
      }
      if (state === 'Full') expect(miss).toBe('—');
    }
    expect(partial).toBeGreaterThan(1);
    await expect(page.locator('#coverage .eyebrow')).toContainText(`${partial} partial`);
  });

  test('three coverage states, each a word plus a glyph plus a colour', async ({ page }) => {
    await page.goto('/');
    const st = page.locator('#coverage .state');
    for (const el of await st.all()) {
      expect(((await el.textContent()) || '').trim()).toMatch(/^(Full|Partial|None)$/);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    const colours = await st.evaluateAll((els) => [...new Set(els.map((e) => getComputedStyle(e).color))]);
    expect(colours.length).toBe(3);
  });

  test('the page admits what it does not draw at all', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#coverage')).toContainText('Cyrillic');
    await expect(page.locator('#coverage')).toContainText(/Not drawn/);
    await expect(page.locator('#coverage')).toContainText(/worse than nothing/i);
  });

  // ── The glyphs ──────────────────────────────────────────────────────────
  test('the twelve glyphs are selectable text, not images', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#glyphs .glyph');
    expect(await cards.count()).toBe(12);
    expect(await page.locator('#glyphs img, #glyphs svg').count()).toBe(0);
    for (const c of await cards.all()) {
      const g = ((await c.locator('.g').textContent()) || '').trim();
      expect(g.length).toBeGreaterThan(0);
      expect(((await c.locator('.why').textContent()) || '').length).toBeGreaterThan(30);
    }
    // The characters the page argues about are actually present.
    const all = (await page.locator('#glyphs').textContent()) || '';
    for (const ch of ['ș', 'ł', 'ế', 'ﬁ', 'İ', '«»', '¿']) expect(all).toContain(ch);
  });

  // ── Two forms ───────────────────────────────────────────────────────────
  test('there are two forms and they ask different things', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('form').count()).toBe(2);
    await expect(page.locator('#trial-email')).toHaveAttribute('required', '');
    expect(await page.locator('#trial select').count()).toBe(1);
    // The commission form asks about languages and reading size; the trial does not.
    for (const id of ['#name', '#email', '#langs', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#trial #langs').count()).toBe(0);
  });

  // ── The specimen page ───────────────────────────────────────────────────
  test('the specimen page exists and argues against itself', async ({ page }) => {
    const res = await page.goto('/specimen/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).not.toContain('refresh');
    await expect(page.locator('h1')).toContainText(/tells you almost nothing/);
    const sizes = await page.locator('.waterfall p').evaluateAll((ps) =>
      ps.map((p) => parseFloat((p as HTMLElement).style.fontSize)));
    expect(sizes.length).toBeGreaterThan(5);
    for (let i = 1; i < sizes.length; i++) expect(sizes[i]).toBeLessThan(sizes[i - 1]);
  });

  test('the demo says plainly which fonts the specimens are set in', async ({ page }) => {
    for (const p of ['/', '/specimen/']) {
      await page.goto(p);
      await expect(page.locator('.note-box')).toContainText(/template’s own typefaces/);
      await expect(page.locator('.note-box')).toContainText(/@font-face/);
    }
    await page.goto('/');
    await expect(page.locator('#faq')).toContainText(/set in the template’s own faces/);
  });

  test('the FAQ is an accordion', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('no trace of the day-124 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['tobias renner', 'milwaukee', 'knockout search', 'clearance', 'uspto']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro character set is absent from the free build', async ({ page }) => {
    const res = await page.goto('/charset/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
