// Wren Aldermann — Providence, RI. Fictional foundry, fictional families.
//
// The organising idea: a specimen shows the same ninety characters every
// foundry site shows, and the purchase decision is made on the other four
// hundred. Coverage is published here as three states, and the Partial state
// names the exact characters that are missing — which is the honest one and
// the one nobody publishes.
//
// The demo sets its specimens in this template's own faces. A buyer drops
// their own @font-face into global.css and the page becomes their family.

export const site = {
  name:        'Aldermann Type',
  shortName:   'Aldermann Type',
  title:       'Aldermann Type — a small foundry in Providence',
  tagline:     'A typeface is 480 glyphs.',
  owner:       'Wren Aldermann',
  ownerRole:   'Type designer',
  credential:  'Four families · trials for everything · coverage published',
  city:        'Providence',
  state:       'RI',
  language:    'en',
  phoneDisplay: '(401) 555-0129',
  phoneHref:   '+14015550129',
  email:       'wren@aldermanntype.example',
  streetAddress: '135 Westminster St',
  postalCode:  '02903',
  hours:       'Trials sent within a day · commissions booked a season ahead',
  bookingWindow: 'Trials are free and unlimited · a custom family is six to nine months',
  description:
    'Every foundry site is a specimen, and every specimen shows the same ninety characters. The ' +
    'decision is made on the other four hundred: the Romanian comma-below, the Polish ł, stacked ' +
    'Vietnamese diacritics, tabular figures that line up, and the fi ligature. All of it is ' +
    'published below, including the languages these families only partly support.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Coverage',  href: '#coverage' },
  { label: 'The twelve', href: '#glyphs' },
  { label: 'Families',  href: '#families' },
  { label: 'Specimen',  href: 'specimen/' },
];

export const specimenNote =
  'The specimens on this page are set in the template’s own typefaces. Drop your own ' +
  '@font-face into src/styles/global.css and every waterfall, grid and paragraph here becomes ' +
  'your family — which is the entire point of a specimen page you can edit rather than one you ' +
  'export as a PNG.';

// ── The families ──────────────────────────────────────────────────────────

export const families = [
  { k: 'Halvard Text',    weights: 6, glyphs: 486, styles: 'Roman and italic, 6 weights',
    n: 'A workhorse for long reading at 9 to 12 pt. Drawn against newsprint first, which is why it holds up on a screen at 300% and looks slightly dull in a specimen.' },
  { k: 'Halvard Display', weights: 3, glyphs: 312, styles: 'Roman only, 3 weights',
    n: 'The same skeleton, tightened and sharpened for 40 pt and above. Smaller character set on purpose: a display face used for a Vietnamese paragraph is being used wrong.' },
  { k: 'Quire Mono',      weights: 4, glyphs: 441, styles: 'Roman and oblique, 4 weights',
    n: 'For code and for tables. Zero is slashed, one has a foot, l has a tail, and the ambiguity budget was spent before anything else was drawn.' },
  { k: 'Bellrope Sans',   weights: 8, glyphs: 502, styles: 'Roman and italic, 8 weights',
    n: 'The largest set here and the only one with full Vietnamese. Eight weights because it was drawn for an interface, and an interface needs a 450 that a print family never does.' },
];

// ── Coverage ──────────────────────────────────────────────────────────────
// `state` is 'full' | 'partial' | 'none'. Partial ALWAYS names the exact
// characters that are missing — a partial state without specifics is a
// marketing claim.

export const coverage = [
  { k: 'English, German, Dutch, Italian', state: 'full',    miss: '—',
    n: 'Latin-1 and then some. If a family cannot do this it is not a family yet.' },
  { k: 'French, Spanish, Portuguese',     state: 'full',    miss: '—',
    n: 'Including œ, the Spanish opening marks and guillemets drawn rather than borrowed from a system fallback.' },
  { k: 'Polish, Czech, Hungarian',        state: 'full',    miss: '—',
    n: 'ł is a separate drawing, not an l with a line through it. The Hungarian double acute is at a different angle from the Czech, which is the kind of thing that only matters to Hungarians and therefore matters.' },
  { k: 'Romanian',                        state: 'partial', miss: 'ș ț with comma below (cedilla forms present)',
    n: 'The commonest quiet failure in this trade. Romanian wants a comma below and most fonts ship a cedilla, which is a different character that renders and is wrong. Halvard Text and Bellrope have both; the display and mono faces have only the cedilla.' },
  { k: 'Vietnamese',                      state: 'partial', miss: 'ế ữ ợ and 128 other stacked forms, in three of four families',
    n: 'Only Bellrope Sans is complete. Vietnamese stacks a tone mark on a vowel that already has a mark, and it is roughly 130 extra drawings per weight rather than a handful.' },
  { k: 'Turkish, Azerbaijani',            state: 'full',    miss: '—',
    n: 'Dotless ı and dotted İ, with the locl feature so a Turkish i does not lose its dot when set in caps.' },
  { k: 'Greek',                           state: 'partial', miss: 'Polytonic accents; monotonic complete',
    n: 'Modern Greek works. Classical Greek does not, and the gap is about 200 drawings that no client has yet paid for.' },
  { k: 'Cyrillic',                        state: 'none',    miss: 'Not drawn',
    n: 'Not attempted rather than half-attempted. A Cyrillic that has not been reviewed by somebody who reads it is worse than nothing, and I do not.' },
  { k: 'Arabic, Hebrew, Devanagari',      state: 'none',    miss: 'Not drawn',
    n: 'Different writing systems, different training, different designers. Anybody claiming all of these from a four-family foundry is reselling somebody else’s work.' },
];

export const coverageNote =
  'Three of the nine rows say Partial, and each one names the characters. A foundry that ships ' +
  'a checklist of language names with ticks beside them is claiming Romanian while shipping a ' +
  'cedilla, which is a real font rendering a real character that is the wrong one. Nobody ever ' +
  'complains — they just stop using it.';

// ── The twelve glyphs ─────────────────────────────────────────────────────
// Rendered live on the page. `why` is what it decides.

export const glyphs = [
  { g: 'ș',  k: 'S comma below',   why: 'Romanian. The cedilla version renders and is the wrong character.' },
  { g: 'ł',  k: 'L with stroke',   why: 'Polish. A separate drawing; an overlaid line collides at bold.' },
  { g: 'ế',  k: 'E circumflex acute', why: 'Vietnamese. Two marks stacked, and about 130 more like it.' },
  { g: 'ﬁ',  k: 'fi ligature',     why: 'Without it, every fi in the family collides at text sizes.' },
  { g: 'İ',  k: 'Dotted capital I', why: 'Turkish, with locl so a lowercase i keeps its dot in caps.' },
  { g: '«»', k: 'Guillemets',      why: 'French, Swiss and Russian quotes. Absent from most display faces.' },
  { g: '¿',  k: 'Inverted question', why: 'Spanish. Needs its own drawing at display weights, not a rotation.' },
  { g: '–—', k: 'En and em dash',  why: 'Two widths, drawn separately. One dash used for both is a tell.' },
  { g: '0',  k: 'Slashed zero',    why: 'Quire Mono only. In a text face a slashed zero is a mistake.' },
  { g: '½',  k: 'True fraction',   why: 'Drawn, not two figures and a slash scaled down.' },
  { g: '(H)', k: 'Case-sensitive forms', why: 'Parentheses and hyphens sit too low beside capitals unless there is an alternate.' },
  { g: '1234', k: 'Tabular figures', why: 'Equal widths so a column of numbers lines up. Four figure sets ship in every family.' },
];

export const glyphNote =
  'Twelve characters, rendered as text in this page rather than exported as an image. Select ' +
  'them, copy them, paste them into your own document — which is the only test that means ' +
  'anything and the one a PNG specimen quietly prevents.';

// ── How a family gets drawn ──────────────────────────────────────────────

export const process = [
  { k: 'n and o, for a month',   n: 'Everything else is derived from these two. A month sounds absurd and it is the reason the other 478 glyphs take six rather than twenty.' },
  { k: 'The control characters', n: 'H O n o and a few more, spaced properly, at the size the family is actually for. Spacing before drawing, always — a beautifully drawn face with bad spacing is unusable and the reverse is merely plain.' },
  { k: 'Lowercase, then caps',   n: 'In that order, because the lowercase carries the texture and the caps have to fit into it rather than the other way round.' },
  { k: 'Figures, four sets',     n: 'Lining, oldstyle, tabular and proportional. Two hundred and forty drawings before a single accented character exists.' },
  { k: 'Diacritics and the extended set', n: 'Where the glyph count actually goes. Polish, Czech, Turkish, Romanian, and the decision about Vietnamese, which is a hundred and thirty more per weight.' },
  { k: 'Interpolation and testing', n: 'Weights generated between the extremes, then every one of them checked by hand, because an interpolated 450 is wrong in a different way from an interpolated 700.' },
];

// ── Licence and commission ───────────────────────────────────────────────
// Deliberately short. Day 118 owns the usage-licensing argument in this
// library and re-running it here would be a re-skin of a different day.

export const licence = [
  { t: 'Desktop, per seat, perpetual',
    d: 'Counted by people who open the font, not by machines. A five-person studio buys five, forever, and nobody audits anything.' },
  { t: 'Web, by page view band, annual',
    d: 'The band is on the invoice and it is renewed annually because the traffic changes. Self-hosted files, no tracking script, no phone-home.' },
];

export const commission = [
  { t: 'A custom family is six to nine months',
    d: 'Two of those months are the first two characters. Delivery is the full set plus the sources, so nobody is locked to me for a future weight.' },
  { t: 'Exclusive, or exclusive for a term',
    d: 'Both exist and the second is cheaper. An identity that needs a face nobody else has for three years does not need it forever, and pricing it forever is how a commission stops happening.' },
];

export const said = {
  text: 'The coverage table said Romanian was partial and named the two characters, which is the first time a foundry has told me something was missing before I found it in production. We bought the family that had it and the trial took ten minutes to prove it.',
  who: 'Design lead, multilingual publisher — 2026',
};

export const faqs = [
  {
    q: 'Why publish what the fonts cannot do?',
    a: 'Because the alternative is a checklist of language names with ticks beside them, which is how a font ends up claiming Romanian while shipping a cedilla instead of a comma-below. It renders, it is the wrong character, nobody complains, and they quietly stop using the family. Naming the two missing glyphs costs a line and saves the relationship.',
  },
  {
    q: 'Can I try the fonts?',
    a: 'Yes, free and unlimited, and the trial form on this page is separate from the commission form for exactly that reason. Trials are watermark-free and unlicensed for publication — they exist so you can set your own text, in your own language, and find out in ten minutes what a specimen cannot tell you.',
  },
  {
    q: 'What is actually in the download?',
    a: 'The static instances, the variable file where there is one, and the full character set as a PDF that lists every glyph rather than showing a pangram. No installer, no font manager, no account.',
  },
  {
    q: 'Why is Vietnamese only in one family?',
    a: 'Because it is roughly 130 extra drawings per weight, and in a four-family foundry that is a real decision rather than a checkbox. Bellrope Sans has it because it was drawn for an interface that needed it. Saying so is more useful than a tick in a table.',
  },
  {
    q: 'Do you draw Cyrillic?',
    a: 'No. A Cyrillic that has not been reviewed by somebody who reads Cyrillic is worse than no Cyrillic, and I do not read it. If a commission needs it I will bring in somebody who does and say so on the invoice.',
  },
  {
    q: 'Are the specimens on this site set in your fonts?',
    a: 'On this demo they are set in the template’s own faces, and this answer is here rather than buried because a foundry site that is coy about that is doing something worse. In the real thing you drop your own @font-face into the stylesheet and every waterfall and grid on the page becomes your family.',
  },
];
