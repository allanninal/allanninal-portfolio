import { test, expect } from '@playwright/test';

test.describe('Cascade Wash Co. — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Cascade Wash Co\./);
    await expect(page.locator('h1')).toContainText('singles');
  });

  test('uses AutoWash, which is literally what this business is', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"AutoWash"');
    expect(json).not.toContain('AutoRepair');
    expect(json).not.toContain('AutoBodyShop');
  });

  // Days 77-89 each had a named certified individual. A tunnel is a machine and
  // a queue, so inventing one here would be a false signal — in the markup too.
  test('claims no expert Person, because there is not one', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).not.toContain('"Person"');
    expect(json).not.toContain('EducationalOccupationalCredential');
  });

  // ── The tariff board ────────────────────────────────────────────────────
  test('the board prices four tiers on two axes', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#tariff table.tariff');
    expect(await t.locator('thead th[scope="col"]').count()).toBe(4);
    expect(await t.locator('tbody th[scope="row"]').count()).toBe(4);
  });

  // The one number a tunnel does not normally print, and it must be arithmetic.
  test('every break-even equals ceil(monthly / single)', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#tariff tbody tr').evaluateAll((trs) =>
      trs.map((tr) => {
        const cells = tr.querySelectorAll('td');
        const num = (el: Element | null) => Number((el?.textContent || '').replace(/[^0-9.]/g, ''));
        return {
          single: num(cells[0]),
          monthly: num(cells[1]),
          be: Number((cells[2]?.textContent || '').match(/\d+/)?.[0]),
        };
      }),
    );
    expect(rows.length).toBe(4);
    for (const r of rows) {
      expect(r.single).toBeGreaterThan(0);
      expect(r.monthly).toBeGreaterThan(0);
      expect(r.be).toBe(Math.ceil(r.monthly / r.single));
    }
  });

  test('the hero range is derived from the board, not typed', async ({ page }) => {
    await page.goto('/');
    const bes = await page.locator('#tariff .be').evaluateAll((els) =>
      els.map((e) => Number((e.textContent || '').match(/\d+/)?.[0])),
    );
    const lo = Math.min(...bes), hi = Math.max(...bes);
    await expect(page.locator('h1')).toContainText(`${lo} and ${hi} washes a month`);
  });

  // The page's central honesty claim.
  test('membership section names when NOT to be a member', async ({ page }) => {
    await page.goto('/');
    const m = page.locator('#membership');
    await expect(m).toContainText(/should not be a member/i);
    await expect(m).toContainText(/Buy singles/);
    // Cancellation must be described as a link, not a phone call.
    await expect(m).toContainText(/link on this site, not a phone number/i);
  });

  // ── The tunnel sequence ─────────────────────────────────────────────────
  test('the stage dwell times sum to the headline duration', async ({ page }) => {
    await page.goto('/');
    const secs = await page.locator('#tunnel .stage-secs').allTextContents();
    expect(secs.length).toBe(8);
    const total = secs.reduce((n, s) => n + Number(s.replace(/[^0-9]/g, '')), 0);
    const minutes = Math.round((total / 60) * 10) / 10;
    await expect(page.locator('#tunnel h2')).toContainText(`${minutes} minutes`);
  });

  test('exactly one stage touches the car, and it is marked', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#tunnel li.stage').count()).toBe(8);
    expect(await page.locator('#tunnel li.stage--contact').count()).toBe(1);
    await expect(page.locator('#tunnel li.stage--contact')).toContainText('wrap');
    await expect(page.locator('#tunnel h2')).toContainText('one of them touches the car');
  });

  // The diagram is to scale, and it must not duplicate the list to a reader.
  test('the tunnel diagram is decorative and the list carries the content', async ({ page }) => {
    await page.goto('/');
    const svg = page.locator('#tunnel figure svg');
    await expect(svg).toHaveAttribute('aria-hidden', 'true');
    await expect(page.locator('#tunnel figcaption')).toContainText('dwell time');
  });

  test('the wash admits it is not scratch-free and points at the alternative', async ({ page }) => {
    await page.goto('/');
    const m = page.locator('#method');
    await expect(m).toContainText('not scratch-free');
    await expect(m).toContainText(/touch-free/i);
    await expect(m).toContainText(/hand wash/i);
    expect(await m.locator('tbody tr').count()).toBe(5);
  });

  test('the refusal list is published in full', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#refuse ol.refuse li');
    expect(await items.count()).toBe(6);
    await expect(page.locator('#refuse')).toContainText('Convertible soft tops');
    // Every refusal must give a reason, not just a rule.
    for (const w of await items.locator('.why').allTextContents()) {
      expect(w.trim().length).toBeGreaterThan(30);
    }
  });

  test('FAQ leads with how to cancel', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await expect(first.locator('summary')).toContainText(/cancel/i);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the contact form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 89.
  test('no trace of the day-89 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['meridian', 'boulder', 'ilinca', 'clear coat', 'micron', 'gantari']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('the board scrolls inside its own container on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const scrollable = await page.locator('#tariff .tariff-wrap').evaluate(
      (e) => e.scrollWidth > e.clientWidth,
    );
    expect(scrollable).toBe(true);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro calculator is absent from the free build', async ({ page }) => {
    const res = await page.goto('/break-even/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Seasonal');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
