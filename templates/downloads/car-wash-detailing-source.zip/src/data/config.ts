// Cascade Wash Co. — Tacoma, WA.
//
// Day 89 was a hand studio that measures paint and declines work. Shipping
// "car wash and detailing" the next day as packages-gallery-booking would have
// been that template with different prices, which is the exact failure the
// divergence work exists to prevent. So the niche is split instead: this is the
// opposite business — a high-volume express tunnel on a monthly membership.
//
// There is deliberately no named owner-expert. Days 77-89 all had one. A tunnel
// is a machine and a queue, and giving it a certified artisan would be the
// wrong voice.

export const site = {
  name:        'Cascade Wash Co.',
  shortName:   'Cascade',
  title:       'Cascade Wash Co. — Express Car Wash in Tacoma, WA',
  tagline:     'The membership pays at three washes a month.',
  city:        'Tacoma',
  state:       'WA',
  language:    'en',
  phoneDisplay: '(253) 555-0148',
  phoneHref:   '+12535550148',
  email:       'hello@cascadewash.example',
  streetAddress: '3711 S Pine St',
  postalCode:  '98409',
  hours:       'Open daily 7am–8pm · last car through at 7:45pm',
  bays:        'Four-bay express tunnel · 3 minutes end to end',
  bookingWindow: 'No appointment. Drive in.',
  // Deliberately a link, not a phone number. See `membership.cancel`.
  cancelNote:  'Cancel online in about thirty seconds. No call, no retention script.',
  description:
    'A four-bay express tunnel in Tacoma with an unlimited monthly plan. This page ' +
    'publishes the break-even for every tier, tells you when you are washing too ' +
    'little to justify it, and links straight to cancellation.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The board',   href: '#tariff' },
  { label: 'Membership',  href: '#membership' },
  { label: 'The tunnel',  href: '#tunnel' },
  { label: 'Cloth or not', href: '#method' },
  { label: 'We refuse',   href: '#refuse' },
  { label: 'Find us',     href: '#areas' },
  { label: 'FAQ',         href: '#faq' },
];

// ── The tariff board ──────────────────────────────────────────────────────
// Break-even is COMPUTED from single/monthly in the page, never typed here.

export const tiers = [
  { id: 'basic',   name: 'Basic',    single: 12, monthly: 25,
    includes: 'Wash, spot-free rinse, blowers.' },
  { id: 'wheels',  name: 'Wheels',   single: 16, monthly: 32,
    includes: 'Basic plus wheel cleaner, tyre shine, underbody rinse.' },
  { id: 'shield',  name: 'Shield',   single: 21, monthly: 39,
    includes: 'Wheels plus ceramic-infused sealant and a hot wax pass.' },
  { id: 'works',   name: 'The Works', single: 26, monthly: 45,
    includes: 'Shield plus bug prep, triple foam and a rain-repellent screen pass.' },
];

export const tariffNote =
  'The right-hand column is arithmetic, not marketing. It is the two prices ' +
  'beside it divided, rounded up. Most express tunnels do not print it because ' +
  'the business depends on members washing less often than they expected to.';

// ── Membership, honestly ──────────────────────────────────────────────────

export const membership = {
  headline: 'When you should not be a member.',
  body:
    'If you wash less than the break-even for your tier, the plan costs you money ' +
    'and single washes are cheaper. We would rather you paid per wash and kept ' +
    'coming than paid a subscription you resent.',
  points: [
    { when: 'You wash once a month',       say: 'Buy singles. On every tier that is cheaper, on some by half.' },
    { when: 'You wash twice a month',      say: 'Basic and Wheels still favour singles. Shield and Works are close enough to be a coin toss.' },
    { when: 'You wash weekly',             say: 'Membership, clearly, on any tier.' },
    { when: 'You have two cars',           say: 'Plans are per vehicle — they are read off the plate. Two cars is two plans, and we will not pretend otherwise.' },
  ],
  cancel:
    'Cancellation is a link on this site, not a phone number. It takes about ' +
    'thirty seconds and there is no retention script at the end of it. A plan ' +
    'that is hard to leave is a plan that knows it is not worth keeping.',
};

// ── The three minutes ─────────────────────────────────────────────────────
// An express tunnel is a sequence, and the sequence is the product. Every
// stage is a real piece of equipment with a real dwell time; they sum to the
// three minutes on the sign, and the page checks that they do.

export const tunnel = {
  intro:
    'A tunnel is a conveyor and eight pieces of equipment in a fixed order. Nothing ' +
    'about it is mysterious, so here it is stage by stage with how long your car ' +
    'spends in each. The times add up to the number on the sign.',
  stages: [
    { n: 1, name: 'Prep arch',        seconds: 15, does: 'Low-pressure pre-soak over the whole car. Starts lifting road film before anything touches it.' },
    { n: 2, name: 'Bug and wheel',    seconds: 20, does: 'Targeted chemistry on the front clip and wheels, which are the two dirtiest areas on any car.' },
    { n: 3, name: 'Triple foam',      seconds: 20, does: 'Lubricating foam. Its job is to reduce friction before the cloth, not to clean — the colour is theatre and we will say so.' },
    { n: 4, name: 'Top and side wrap', seconds: 35, does: 'Closed-cell foam cloth. This is the contact stage, and the one that does most of the cleaning.' },
    { n: 5, name: 'Rocker blasters',  seconds: 15, does: 'High-pressure jets along the sills and underbody. No contact, and where road salt actually collects.' },
    { n: 6, name: 'Rinse arch',       seconds: 20, does: 'Fresh-water rinse to carry the chemistry off before it can dry on the paint.' },
    { n: 7, name: 'Sealant arch',     seconds: 20, does: 'Only on Shield and above. A thin ceramic-infused layer applied wet.' },
    { n: 8, name: 'Spot-free and dry', seconds: 35, does: 'Reverse-osmosis final rinse so nothing is left to spot, then the blowers.' },
  ],
  note:
    'Stage four is the only one that touches the car. If you would rather nothing ' +
    'did, bay four skips it and runs stages one, two, five, six and eight at higher ' +
    'chemistry — which is the trade-off set out below.',
};

// ── Cloth or touch-free ───────────────────────────────────────────────────

export const method = {
  intro:
    'A tunnel wash is not scratch-free and nobody in this trade says so. Modern ' +
    'closed-cell foam and cloth is far gentler than the nylon brushes it replaced, ' +
    'but any contact wash imparts fine marring over time. Here is the trade-off, ' +
    'including the case for our cheaper bay.',
  rows: [
    { what: 'Cleaning power on road film', cloth: 'Better. Contact is what removes bonded grime.', touchless: 'Weaker. Relies on chemistry alone.' },
    { what: 'Effect on paint over years',  cloth: 'Fine marring accumulates. Visible in direct sun on dark paint.', touchless: 'No contact, so no marring from the wash itself.' },
    { what: 'Chemistry strength',          cloth: 'Milder detergents.', touchless: 'Stronger, higher and lower pH. Harder on trim and old sealant.' },
    { what: 'Time through',                cloth: '3 minutes.', touchless: '4 minutes.' },
    { what: 'What we suggest',             cloth: 'Most cars, most of the time.', touchless: 'Dark paint you care about, or anything freshly corrected or coated.' },
  ],
  closing:
    'If the paint on your car is genuinely a priority, the honest answer is a hand ' +
    'wash — ours or anyone else’s. We would rather say that than sell you a plan ' +
    'you will be unhappy with.',
};

// ── What the tunnel will not take ─────────────────────────────────────────

export const refuse = [
  { what: 'Convertible soft tops',        why: 'Seams and rear windows do not survive tunnel pressure and the drying pass. No exceptions, including for fabric in good condition.' },
  { what: 'Roof racks with crossbars',    why: 'They foul the top brush arm. Remove the bars and you are fine; the base rails alone are not a problem.' },
  { what: 'Aftermarket spoilers and lips', why: 'Anything bonded rather than bolted comes off in a tunnel eventually. We will not gamble with it.' },
  { what: 'Existing clear-coat failure',   why: 'Peeling or flaking clear will spread under any wash. A tunnel accelerates it and you would rightly blame us.' },
  { what: 'Open truck beds with loose cargo', why: 'It ends up in the equipment and then in the car behind you.' },
  { what: 'Vehicles over 84 inches tall',  why: 'That is the tunnel opening. It is a measurement, not a policy.' },
];

export const areas = [
  { zone: 'Tacoma',    towns: 'South Tacoma, Lincoln District, Hilltop, Proctor' },
  { zone: 'North',     towns: 'Federal Way, Fife, Milton, Edgewood' },
  { zone: 'South',     towns: 'Lakewood, Parkland, Spanaway, DuPont' },
  { zone: 'East',      towns: 'Puyallup, Sumner, Bonney Lake, Graham' },
];

export const reviews = [
  { name: 'Marguerite Okpara', town: 'Proctor',      text: 'The board tells you when the plan is a bad deal for you. I did the arithmetic and it was right, so I buy singles and I still come here.' },
  { name: 'Yusuf Brannigan',   town: 'Lakewood',     text: 'Cancelled online in under a minute when I moved away, then resubscribed six months later. That is the whole reason I resubscribed.' },
  { name: 'Priya Vandermeer',  town: 'Puyallup',     text: 'Asked whether the tunnel would scratch my black paint. Got a straight yes-a-little and a pointer to the touch-free bay.' },
  { name: 'Osric Nakamura',    town: 'Fife',         text: 'Turned my truck away because of the roof bars, explained why, and told me to take them off and come back. I did.' },
];

export const faqs = [
  {
    q: 'How do I cancel?',
    a: 'There is a link on this page. It takes about thirty seconds, there is no phone call and nobody tries to talk you out of it. If a wash company makes cancelling hard, that tells you what it thinks of the plan.',
  },
  {
    q: 'Will the tunnel scratch my paint?',
    a: 'A little, over years. Any contact wash does. Modern cloth is far gentler than the nylon brushes it replaced, but it is not scratch-free and we are not going to claim it is. Use the touch-free bay if that matters to you.',
  },
  {
    q: 'Is the membership per car or per person?',
    a: 'Per vehicle. It is read off the plate at the gate. A household with two cars needs two plans, and there is no family rate that quietly is not one.',
  },
  {
    q: 'What is the break-even?',
    a: 'Between two and three washes a month depending on the tier, and it is printed on the board above. Below that, singles are cheaper and you should buy singles.',
  },
  {
    q: 'Do you do interior cleaning?',
    a: 'Free vacuums in the twelve bays past the exit, and that is all. We are a tunnel. There are people in Tacoma who do interiors properly and we are not them.',
  },
  {
    q: 'Why do you turn some vehicles away?',
    a: 'Six categories, published in full above. Every one of them is something the tunnel would damage, and taking your money first and arguing afterwards is not a business we want.',
  },
];
