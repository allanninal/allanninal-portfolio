module.exports = {
  ci: {
    collect: {
      staticDistDir: './dist',
      url: ['http://localhost/index.html'],
      numberOfRuns: 3,
      settings: {
        // Prevent AdSense from tanking Best Practices
        blockedUrlPatterns: [
          '*googlesyndication*',
          '*doubleclick*',
          '*pagead2*',
          '*googletagmanager*',
        ],
      },
    },
    assert: {
      assertions: {
        'categories:performance':    ['error', { minScore: 0.95 }],
        'categories:accessibility':  ['error', { minScore: 0.95 }],
        'categories:best-practices': ['error', { minScore: 0.95 }],
        'categories:seo':            ['error', { minScore: 0.95 }],
      },
    },
    upload: {
      target: 'temporary-public-storage',
    },
  },
};
