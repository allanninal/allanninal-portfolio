import { test, expect } from '@playwright/test';
import { ROUTES, setTheme, blockAnalytics } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${route} renders in ${theme} mode`, async ({ page }) => {
      await blockAnalytics(page);
      // emulateMedia before goto so the theme init script picks up system pref
      await page.emulateMedia({ colorScheme: theme });
      await page.goto(route);
      // Now set localStorage after page has loaded
      await setTheme(page, theme);

      const dataTheme = await page.evaluate(() =>
        document.documentElement.getAttribute('data-theme')
      );
      expect(dataTheme).toBe(theme);

      await expect(page.locator('h1').first()).toBeVisible();
      await expect(page.locator('footer').first()).toBeVisible();
    });
  }
}

test('dark mode applies correct background token', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
  });

  const bgColor = await page.evaluate(() =>
    getComputedStyle(document.documentElement).getPropertyValue('--color-bg').trim()
  );
  expect(bgColor).toBe('#161210');
});

test('light mode applies correct background token', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
  });

  const bgColor = await page.evaluate(() =>
    getComputedStyle(document.documentElement).getPropertyValue('--color-bg').trim()
  );
  expect(bgColor).toBe('#FAF7F2');
});

test('theme persists on reload (dark)', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
  });

  await page.reload();
  await blockAnalytics(page);

  const theme = await page.evaluate(() =>
    document.documentElement.getAttribute('data-theme')
  );
  expect(theme).toBe('dark');
});
