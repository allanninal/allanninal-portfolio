import { test, expect } from '@playwright/test';
import { ROUTES, blockAnalytics } from './helpers';

for (const route of ROUTES) {
  test(`page ${route} renders`, async ({ page }) => {
    const errors: string[] = [];

    await blockAnalytics(page);

    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => {
      if (m.type() === 'error') {
        const text = m.text();
        if (text.includes('net::ERR_ABORTED') || text.includes('Failed to load resource')) return;
        errors.push(text);
      }
    });

    const res = await page.goto(route);
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}: ${errors.join('\n')}`).toEqual([]);
  });
}

test('index page has Mira Kovač h1', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const h1 = page.locator('h1').first();
  await expect(h1).toContainText('Mira Kovač');
});

test('index page shows bio text', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  await expect(page.getByText('Berlin-based engineer')).toBeVisible();
});

test('index page has filter bar', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const filterBar = page.locator('nav[aria-label="Filter projects"]');
  await expect(filterBar).toBeVisible();
});

test('index page has projects.json link', async ({ page }) => {
  await blockAnalytics(page);
  const res = await page.goto('/projects.json');
  expect(res?.status()).toBe(200);
  const body = await res?.text();
  expect(body).toContain('Mira Kovač');
  expect(body).toContain('shuttlr');
});

test('index page has all 10 project cards', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  // Count articles with data-status attribute
  const cards = page.locator('article[data-status]');
  const count = await cards.count();
  // There are 10 projects each appearing in both sections = 20 articles
  // featured cards + all-projects grid both render all featured projects in their respective sections
  // Actually featured are in top section (3), all 10 in bottom grid
  expect(count).toBeGreaterThanOrEqual(10);
});

test('all projects have permalink anchor ids', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const slugs = ['shuttlr', 'notevault', 'logpilot', 'taskline', 'planify', 'mirrorcast', 'flashform', 'gobench', 'crontab-dev', 'pg-jobs'];
  for (const slug of slugs) {
    const el = page.locator(`#${slug}`).first();
    await expect(el).toBeAttached();
  }
});

test('TemplateInfo bar renders with hub URL set', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  // Edition-aware: the Pro build swaps the bar for a "Pro edition" strip.
  const isPro = process.env.PUBLIC_EDITION === 'pro';
  const label = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';
  const bar = page.locator(`aside[aria-label="${label}"]`);
  await expect(bar).toBeVisible();
  await expect(bar.getByText(isPro ? 'live preview' : 'Day 30 of 365')).toBeVisible();
});

test('projects.json endpoint returns valid JSON', async ({ page }) => {
  const res = await page.goto('/projects.json');
  expect(res?.status()).toBe(200);
  const body = await res?.text();
  const data = JSON.parse(body!);
  expect(data.maker.name).toBe('Mira Kovač');
  expect(data.projects).toHaveLength(10);
});
