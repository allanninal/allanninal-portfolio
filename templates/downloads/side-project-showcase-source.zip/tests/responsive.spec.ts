import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS, blockAnalytics } from './helpers';

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}px) has no horizontal scroll`, async ({ page }) => {
      await blockAnalytics(page);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(overflow, `Horizontal scroll at ${vp.name}`).toBe(false);
    });

    test(`${route} @ ${vp.name} (${vp.width}px) renders h1 and footer`, async ({ page }) => {
      await blockAnalytics(page);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await expect(page.locator('h1').first()).toBeVisible();
      await expect(page.locator('footer').first()).toBeVisible();
    });
  }
}

test('filter bar is sticky on scroll', async ({ page }) => {
  await blockAnalytics(page);
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto('/');

  // Scroll down past the header. The site sets `scroll-behavior: smooth`, so
  // jump instantly and wait for the scroll position to actually settle —
  // otherwise we'd measure the sticky bar mid-animation (a system-Chrome flake).
  await page.evaluate(() => window.scrollTo({ top: 400, behavior: 'instant' as ScrollBehavior }));
  await page.waitForFunction(() => window.scrollY >= 380);

  const filterBar = page.locator('nav[aria-label="Filter projects"]');
  const boundingBox = await filterBar.boundingBox();
  // The filter bar should be visible near the top of the viewport (sticky)
  expect(boundingBox?.y).toBeLessThanOrEqual(5);
});

test('project grid switches to 1-col on mobile', async ({ page }) => {
  await blockAnalytics(page);
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');

  // Cards should stack vertically at mobile
  const cards = page.locator('#projects-grid article');
  const first = await cards.nth(0).boundingBox();
  const second = await cards.nth(1).boundingBox();

  // On mobile, second card should be below the first (not beside it)
  if (first && second) {
    expect(second.y).toBeGreaterThan(first.y + first.height - 10);
  }
});
