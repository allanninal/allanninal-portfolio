import { test, expect } from '@playwright/test';
import { blockAnalytics } from './helpers';

// Edition-aware: the Pro build swaps the free download bar for a "Pro edition —
// live preview" strip (locked Get-Pro link + Download-free button).
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';
const barSel = `aside[aria-label="${barLabel}"]`;

test('TemplateInfo bar is visible with hub URL set', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  await expect(page.locator(barSel)).toBeVisible();
});

test('TemplateInfo bar has correct static ZIP href', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  // Free: "Download static"; Pro: "Download free" — both point at the static zip.
  const staticLink = page.locator(`${barSel} a[download][href*="static.zip"]`);
  await expect(staticLink).toHaveAttribute(
    'href',
    'https://templates.allanninal.dev/downloads/side-project-showcase-static.zip'
  );
});

test('TemplateInfo bar source ZIP href (free only)', async ({ page }) => {
  test.skip(isPro, 'Pro bar has no source-zip link');
  await blockAnalytics(page);
  await page.goto('/');
  const sourceLink = page.locator(`${barSel} a[download][href*="source.zip"]`);
  await expect(sourceLink).toHaveAttribute(
    'href',
    'https://templates.allanninal.dev/downloads/side-project-showcase-source.zip'
  );
});

test('TemplateInfo bar has gallery link', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const galleryLink = page.locator(`${barSel} a[href="https://templates.allanninal.dev"]`);
  await expect(galleryLink).toBeVisible();
  await expect(galleryLink).toContainText('All 365');
});

test('TemplateInfo bar has the LinkedIn CTA', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  // Free: "Build with me →"; Pro: locked "Get Pro static →" — both point at LinkedIn.
  const cta = page.locator(`${barSel} a[href*="linkedin.com/in/allanninal"]`);
  await expect(cta).toBeVisible();
  await expect(cta).toContainText(isPro ? 'Get Pro static' : 'Build with me');
});

test('TemplateInfo bar has exactly zero github.com links inside', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const githubLinks = page.locator(`${barSel} a[href*="github.com"]`);
  await expect(githubLinks).toHaveCount(0);
});

test('no github.com/allanninal/templates deep-links on entire page', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const privateLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  await expect(privateLinks).toHaveCount(0);
});
