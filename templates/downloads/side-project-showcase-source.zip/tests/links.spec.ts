import { test, expect } from '@playwright/test';
import { blockAnalytics } from './helpers';

test('no broken internal links on index page', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  // Collect all internal links
  const links = await page.locator('a[href]').all();
  const internalLinks: string[] = [];

  for (const link of links) {
    const href = await link.getAttribute('href');
    if (!href) continue;
    // Internal: starts with / or # (not http/https)
    if (href.startsWith('/') && !href.startsWith('//')) {
      internalLinks.push(href);
    }
    // Anchor links
    if (href.startsWith('#')) {
      const id = href.slice(1);
      if (id) {
        const target = page.locator(`#${id}`).first();
        const exists = await target.count() > 0;
        expect(exists, `Anchor target #${id} not found`).toBe(true);
      }
    }
  }

  // Check each internal link returns 200
  for (const href of internalLinks) {
    // Skip anchors within the path (handled above)
    if (href.includes('#')) continue;
    const res = await page.goto(href);
    expect(res?.status(), `Link ${href} returned ${res?.status()}`).toBeLessThan(400);
    await page.goto('/');
  }
});

test('external links have rel="noopener noreferrer" with target="_blank"', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const externalLinks = page.locator('a[target="_blank"]');
  const count = await externalLinks.count();
  expect(count).toBeGreaterThan(0);

  for (let i = 0; i < count; i++) {
    const rel = await externalLinks.nth(i).getAttribute('rel');
    const href = await externalLinks.nth(i).getAttribute('href');
    expect(rel, `External link ${href} missing rel`).toContain('noopener');
    expect(rel, `External link ${href} missing noreferrer`).toContain('noreferrer');
  }
});

test('projects.json feed is accessible', async ({ page }) => {
  const res = await page.goto('/projects.json');
  expect(res?.status()).toBe(200);
});

test('sitemap is accessible', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is accessible', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});
