import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES, setTheme, blockAnalytics } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`a11y ${route} (${theme})`, async ({ page }) => {
      await blockAnalytics(page);
      // emulateMedia before goto so theme init script reads system pref correctly
      await page.emulateMedia({ colorScheme: theme });
      await page.goto(route);
      // Set localStorage theme after page has loaded
      await setTheme(page, theme);

      // Wait for JS to initialize
      await page.waitForTimeout(500);

      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        // Exclude third-party iframes from axe (none expected, but safeguard)
        .exclude('iframe')
        .analyze();

      if (results.violations.length > 0) {
        console.error('Axe violations:', JSON.stringify(results.violations, null, 2));
      }

      expect(results.violations).toEqual([]);
    });
  }
}
