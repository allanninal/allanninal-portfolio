import type { Page } from '@playwright/test';

// Single source of truth for routes — keep in sync with src/pages/.
// The Pro edition (PUBLIC_EDITION=pro) adds the /uses/ page; the free build
// redirects it, so it's only a real route under Pro.
export const ROUTES = [
  '/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/uses/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  // Note: localStorage must be set AFTER navigation (after goto).
  // This function is safe to call either before or after goto;
  // if called before, only emulateMedia takes effect (which is sufficient
  // for the theme init script to read the system preference).
  try {
    await page.evaluate((t) => {
      localStorage.setItem('theme', t);
      document.documentElement.setAttribute('data-theme', t);
    }, theme);
  } catch {
    // localStorage may not be accessible before navigation; ignore.
  }
}

/** Block external analytics/ad scripts to avoid 403 console errors in tests */
export async function blockAnalytics(page: Page) {
  await page.route(/googletagmanager|googlesyndication|doubleclick|google-analytics|pagead2/, (route) => {
    route.abort();
  });
}
