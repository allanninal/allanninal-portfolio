import { test, expect } from '@playwright/test';
import { blockAnalytics } from './helpers';

// Edition-aware: the Pro build swaps the free download bar for a "Pro edition"
// live-preview strip (different aria-label; no source-zip link).
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';

test('theme toggle switches from light to dark', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  // Start in light mode
  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
  });
  const toggle = page.getByRole('button', { name: /toggle light\/dark theme/i });
  await toggle.click();
  const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(theme).toBe('dark');
});

test('theme toggle persists across reload', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const toggle = page.getByRole('button', { name: /toggle light\/dark theme/i });
  await toggle.click();
  const themeBefore = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  await page.reload();
  await blockAnalytics(page);
  const themeAfter = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(themeAfter).toBe(themeBefore);
});

test('status chip "Live" filters to show only Live projects', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const liveChip = page.locator('[data-status-filter="Live"]');
  await liveChip.click();
  await expect(liveChip).toHaveAttribute('aria-pressed', 'true');

  // All visible cards should have data-status="Live"
  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);

  for (let i = 0; i < count; i++) {
    const status = await visibleCards.nth(i).getAttribute('data-status');
    expect(status).toBe('Live');
  }
});

test('status chip "OSS" filters correctly', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.locator('[data-status-filter="OSS"]').click();

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);

  for (let i = 0; i < count; i++) {
    const status = await visibleCards.nth(i).getAttribute('data-status');
    expect(status).toBe('OSS');
  }
});

test('status chip "Sold" filters correctly', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.locator('[data-status-filter="Sold"]').click();

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);

  for (let i = 0; i < count; i++) {
    const status = await visibleCards.nth(i).getAttribute('data-status');
    expect(status).toBe('Sold');
  }
});

test('status chip "All" shows all projects', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  // First filter to Live
  await page.locator('[data-status-filter="Live"]').click();
  // Then reset to All
  await page.locator('[data-status-filter="All"]').click();

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  // All 13 articles (3 featured + 10 in grid)
  expect(count).toBeGreaterThanOrEqual(10);
});

test('stack dropdown filters correctly', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const select = page.locator('#stack-filter');
  await select.selectOption('Go');

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);

  for (let i = 0; i < count; i++) {
    const stack = await visibleCards.nth(i).getAttribute('data-stack');
    expect(stack).toContain('Go');
  }
});

test('text search filters by project name', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const searchInput = page.locator('#search-input');
  await searchInput.fill('notevault');

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);

  const firstCard = visibleCards.first();
  const name = await firstCard.getAttribute('data-name');
  expect(name).toContain('notevault');
});

test('text search filters by description', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const searchInput = page.locator('#search-input');
  await searchInput.fill('kanban');

  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThan(0);
});

test('/ keyboard shortcut focuses search input', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  // Click elsewhere first to ensure focus is not already on input
  await page.locator('h1').click();
  await page.keyboard.press('/');

  const searchInput = page.locator('#search-input');
  await expect(searchInput).toBeFocused();
});

test('clear filters button appears when filter is active', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const clearBtn = page.locator('#clear-filters');
  await expect(clearBtn).toBeHidden();

  await page.locator('[data-status-filter="Live"]').click();
  await expect(clearBtn).toBeVisible();
});

test('clear filters button resets all filters', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  // Apply filters
  await page.locator('[data-status-filter="WIP"]').click();
  await page.locator('#stack-filter').selectOption('Go');
  await page.locator('#search-input').fill('bench');

  const clearBtn = page.locator('#clear-filters');
  await clearBtn.click();

  // All chip should be pressed
  await expect(page.locator('[data-status-filter="All"]')).toHaveAttribute('aria-pressed', 'true');
  await expect(page.locator('#stack-filter')).toHaveValue('');
  await expect(page.locator('#search-input')).toHaveValue('');

  // All cards visible
  const visibleCards = page.locator('article[data-status]:not([hidden])');
  const count = await visibleCards.count();
  expect(count).toBeGreaterThanOrEqual(10);
});

test('results count updates when filtering', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const resultsCount = page.locator('#results-count');
  const initialText = await resultsCount.textContent();
  // 3 featured cards + 10 in the grid = 13 total article elements
  expect(initialText).toContain('13');

  await page.locator('[data-status-filter="WIP"]').click();
  const filteredText = await resultsCount.textContent();
  expect(filteredText).not.toBe(initialText);
});

test('empty state shows when no results match', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const emptyState = page.locator('#empty-state');
  await expect(emptyState).toBeHidden();

  // Search for something that doesn't exist
  await page.locator('#search-input').fill('xyznonexistentproject');
  await expect(emptyState).toBeVisible();
});

test('empty state clear button resets filters', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  await page.locator('#search-input').fill('xyznonexistentproject');
  const emptyState = page.locator('#empty-state');
  await expect(emptyState).toBeVisible();

  await page.locator('#clear-filters-empty').click();
  await expect(emptyState).toBeHidden();
});

test('footer donate link renders with env URL set', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');
  const donateLink = page.locator('footer a[href*="ko-fi.com"]');
  await expect(donateLink).toBeVisible();
});

test('TemplateInfo bar has correct download links', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const bar = page.locator(`aside[aria-label="${barLabel}"]`);
  await expect(bar).toBeVisible();

  // Static ZIP — free "Download static" / Pro "Download free", both point here.
  const staticLink = bar.locator('a[download][href*="static.zip"]');
  await expect(staticLink).toBeVisible();
  await expect(staticLink).toHaveAttribute('href', /side-project-showcase-static\.zip/);

  // Source ZIP — free edition only (the Pro bar has no source-zip link).
  if (!isPro) {
    const sourceLink = bar.locator('a[download][href*="source.zip"]');
    await expect(sourceLink).toBeVisible();
    await expect(sourceLink).toHaveAttribute('href', /side-project-showcase-source\.zip/);
  }

  // Gallery link
  const galleryLink = bar.locator('a[href="https://templates.allanninal.dev"]');
  await expect(galleryLink).toBeVisible();

  // LinkedIn CTA — free "Build with me" / Pro locked "Get Pro".
  const hireLink = bar.locator('a[href*="linkedin.com"]');
  await expect(hireLink).toBeVisible();
});

test('TemplateInfo bar has zero github.com links inside', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const bar = page.locator(`aside[aria-label="${barLabel}"]`);
  const githubLinks = bar.locator('a[href*="github.com"]');
  await expect(githubLinks).toHaveCount(0);
});

test('no github.com/allanninal/templates links anywhere on page', async ({ page }) => {
  await blockAnalytics(page);
  await page.goto('/');

  const privateRepoLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  await expect(privateRepoLinks).toHaveCount(0);
});
