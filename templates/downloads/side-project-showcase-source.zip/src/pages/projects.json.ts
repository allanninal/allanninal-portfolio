import type { APIRoute } from 'astro';
import { projects, PERSONA } from '../data/projects';

export const GET: APIRoute = () => {
  const feed = {
    maker: {
      name: PERSONA.name,
      title: PERSONA.title,
      bio: PERSONA.bio,
      github: PERSONA.github,
      twitter: PERSONA.twitter,
      linkedin: PERSONA.linkedin,
      lastUpdated: PERSONA.lastUpdated,
    },
    projects: projects.map((p) => ({
      slug: p.slug,
      name: p.name,
      description: p.description,
      status: p.status,
      stack: p.stack,
      yearStart: p.yearStart,
      yearEnd: p.yearEnd,
      ...(p.url ? { url: p.url } : {}),
      ...(p.metric ? { metric: p.metric } : {}),
      ...(p.featured ? { featured: true } : {}),
    })),
  };

  return new Response(JSON.stringify(feed, null, 2), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
    },
  });
};
