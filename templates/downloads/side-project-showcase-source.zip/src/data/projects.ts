export type ProjectStatus = 'Live' | 'Archived' | 'Sold' | 'WIP' | 'OSS';

export type Project = {
  slug: string;
  name: string;
  description: string;       // ≤ 100 chars
  status: ProjectStatus;
  stack: string[];           // 3-5 entries
  yearStart: number;
  yearEnd: number | 'ongoing';
  url?: string;
  source?: string;           // optional source repo URL (generic, not github.com/allanninal)
  metric?: string;
  featured?: boolean;
  icon?: string;             // emoji or initial letter
};

export const PERSONA = {
  name: 'Mira Kovač',
  title: 'Berlin-based engineer & musician',
  bio: 'Go, Postgres, occasional Svelte',
  github: 'https://github.com/mirakovac',
  twitter: 'https://x.com/mirakovac',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  email: 'landix.ninal@gmail.com',
  lastUpdated: 'April 2026',
} as const;

export const projects: Project[] = [
  {
    slug: 'shuttlr',
    name: 'Shuttlr',
    description: 'Background job queue for Postgres — no Redis needed, zero infrastructure overhead.',
    status: 'OSS',
    stack: ['Go', 'Postgres', 'Docker'],
    yearStart: 2021,
    yearEnd: 'ongoing',
    url: 'https://shuttlr.dev',
    metric: '4.2k GitHub stars',
    featured: true,
    icon: '⚡',
  },
  {
    slug: 'notevault',
    name: 'NoteVault',
    description: 'End-to-end encrypted notes sync — self-hosted, AES-256, no third-party cloud.',
    status: 'Sold',
    stack: ['Go', 'AES-256', 'SQLite'],
    yearStart: 2023,
    yearEnd: 2024,
    metric: 'Acquired for $6k',
    featured: true,
    icon: '🔐',
  },
  {
    slug: 'logpilot',
    name: 'Logpilot',
    description: 'Tail and search logs from multiple servers in one terminal window.',
    status: 'Live',
    stack: ['Go', 'SSH', 'TUI'],
    yearStart: 2022,
    yearEnd: 'ongoing',
    url: 'https://logpilot.sh',
    metric: '1.1k active installs',
    featured: true,
    icon: '📋',
  },
  {
    slug: 'taskline',
    name: 'Taskline',
    description: 'Minimal Kanban board that runs entirely from a single SQLite file.',
    status: 'Live',
    stack: ['Go', 'HTMX', 'SQLite'],
    yearStart: 2023,
    yearEnd: 'ongoing',
    url: 'https://taskline.app',
    metric: '~320 users',
    icon: '📌',
  },
  {
    slug: 'planify',
    name: 'Planify',
    description: 'Team standup scheduler with Slack and email digest integrations.',
    status: 'Sold',
    stack: ['Go', 'Postgres', 'Slack API'],
    yearStart: 2022,
    yearEnd: 2023,
    metric: 'Sold for $3.2k on Acquire.com',
    icon: '📅',
  },
  {
    slug: 'mirrorcast',
    name: 'Mirrorcast',
    description: 'Self-hosted P2P screen-share over WebRTC — no signalling server needed.',
    status: 'Archived',
    stack: ['TypeScript', 'WebRTC'],
    yearStart: 2022,
    yearEnd: 2023,
    metric: 'Worked well, not maintained',
    icon: '🪞',
  },
  {
    slug: 'flashform',
    name: 'Flashform',
    description: 'Opinionated form builder for Go HTTP servers — one import, zero config.',
    status: 'Archived',
    stack: ['Go', 'HTML'],
    yearStart: 2021,
    yearEnd: 2022,
    metric: 'Superseded by Huma / Chi patterns',
    icon: '📝',
  },
  {
    slug: 'gobench',
    name: 'GoBench',
    description: 'Micro-benchmarking harness for Go HTTP handlers — CI-friendly output.',
    status: 'WIP',
    stack: ['Go'],
    yearStart: 2024,
    yearEnd: 'ongoing',
    metric: 'Early dev, no release yet',
    icon: '🏎️',
  },
  {
    slug: 'crontab-dev',
    name: 'Crontab.dev',
    description: 'Visual cron expression builder and tester — paste a cron, see human dates.',
    status: 'WIP',
    stack: ['TypeScript', 'Astro'],
    yearStart: 2024,
    yearEnd: 'ongoing',
    url: 'https://crontab.dev',
    metric: 'Beta — feedback welcome',
    icon: '⏰',
  },
  {
    slug: 'pg-jobs',
    name: 'pg-jobs',
    description: 'Lightweight job queue library for Go and Postgres. MIT licensed.',
    status: 'OSS',
    stack: ['Go', 'Postgres'],
    yearStart: 2023,
    yearEnd: 'ongoing',
    metric: '780 GitHub stars',
    icon: '📦',
  },
];

export const featuredProjects = projects.filter((p) => p.featured);
export const otherProjects = projects.filter((p) => !p.featured);
