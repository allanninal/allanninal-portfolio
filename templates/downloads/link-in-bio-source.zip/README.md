# link-in-bio

A free, MIT-licensed single-page **link-in-bio** template for creators, indie founders, musicians, and freelancers. Built with Astro 4 + Tailwind CSS.

**Light. Warm. Three theme presets. Click-analytics-ready. No platform lock-in.**

![Preview](./preview.png)

**Live demo:** [templates.allanninal.dev/link-in-bio/](https://templates.allanninal.dev/link-in-bio/)

---

## Features

- **Single-column, 480px-max layout** — designed for the way this page is actually viewed (a phone, after tapping "link in bio" on TikTok or Instagram).
- **Three theme presets** — `coral`, `sage`, `slate`. Pick one with `PUBLIC_THEME=...` and ship. All three pass WCAG AA. No runtime toggle (a personal page picks one mood, not three).
- **Featured content card** — one elevated slot above the link list: latest video, latest post, or a product CTA. Set `featured.type` to `video | post | product | none` in `src/data/site.ts`.
- **Link list with primary highlight** — 4–8 stacked pill buttons with optional emoji + meta line. One link can be `highlighted` so the primary CTA stands out in the accent color.
- **Inline newsletter capture** — Buttondown or Mailchimp via env var. Opens in a new tab, validates client-side, falls back to a friendly inline success state on the demo build.
- **Click analytics built in** — every outbound `<a>` carries `data-link-id="..."`. A 12-line inline dispatcher fires a `Link Click` event into Plausible OR Umami if either is on the page. Drop in a `PUBLIC_ANALYTICS_SRC` script URL — that's the entire setup.
- **Schema.org `Person` + `sameAs[]`** — `sameAs` is auto-derived from your social entries, so the structured data and the visible icon row never go out of sync.
- **Configurable in `src/data/`** — three flat TypeScript files: `site.ts` (identity + featured + newsletter copy), `links.ts` (the link list), `social.ts` (the icon row). No JSX edits required for personalization.
- **Mobile-first responsive** — verified at 375 / 768 / 1280 / 1920 px with no horizontal overflow at any width. Every link button meets the 44px iOS tap target. Icons meet 40px.
- **Full test suite** — 49 Playwright tests: page rendering, all three theme presets, link list integrity, newsletter validation + success state, click-event dispatch into Plausible/Umami, axe-clean a11y across all three themes, responsive checks at 4 viewports, Lighthouse ≥ 95 on Performance / Accessibility / Best Practices / SEO.

## Stack

- **Framework:** Astro 4 (static output)
- **Styles:** Tailwind CSS, CSS custom properties for the theme tokens (no JS swap)
- **Fonts:** DM Sans (display + body, self-hosted via @fontsource)
- **Forms:** Buttondown / Mailchimp (configurable via env)
- **Analytics:** Plausible / Umami compatible, no SDK bundled
- **Testing:** Playwright, @axe-core/playwright, Lighthouse CI, linkinator

## Quick start

```bash
# 1. Download from templates.allanninal.dev/link-in-bio/, or grab the source ZIP.
unzip link-in-bio-source.zip -d my-bio
cd my-bio

# 2. Install dependencies
npm install

# 3. Copy env file and fill in your values
cp .env.example .env

# 4. Start the dev server
npm run dev

# 5. Build for production
npm run build
```

## Customize

### 1. Identity, featured card, newsletter copy

Edit `src/data/site.ts`. This is the single source of truth for everything that isn't a link or a social profile:

```ts
person: {
  name: 'Your Name',
  handle: '@yourhandle',
  tagline: 'One line that says what you do.',
  location: 'City, Country',
  avatarSrc: '/images/avatar.jpg', // or '' for the warm CSS monogram
  description: 'A 2–3 sentence bio for SEO and the og:description meta tag.',
},
featured: {
  type: 'video',                        // 'video' | 'post' | 'product' | 'none'
  eyebrow: 'New this week',
  title: 'Your headline goes here',
  href: 'https://www.youtube.com/watch?v=...',
  thumbnail: 'https://img.youtube.com/vi/VIDEO_ID/hqdefault.jpg',
  duration: '12:04',
  badge: 'YouTube',
},
```

If you set `featured.type: 'none'`, the card disappears and the link list moves up — useful if you don't have a single piece of content to elevate.

### 2. The link list

Edit `src/data/links.ts`. Order is the order shown on page. Each link gets a stable `id` used as `data-link-id` for analytics:

```ts
{
  id: 'free-cookbook',
  label: 'Free 30-recipe weeknight cookbook (PDF)',
  href: 'https://example.com/cookbook',
  emoji: '📘',
  meta: 'Free download · 2 MB PDF',
  highlighted: true,            // exactly one link should be highlighted
},
```

### 3. Social icon row

Edit `src/data/social.ts`. The `key` field selects the SVG icon (`linkedin`, `instagram`, `tiktok`, `youtube`, `spotify`, `github`, `x`, `threads`, `substack`, `email`). Order matters — left to right. **LinkedIn is listed first** per the project's contact-priority convention (LinkedIn primary, email secondary).

```ts
{ key: 'linkedin',  label: 'LinkedIn',  href: 'https://www.linkedin.com/in/...' },
```

### 4. Theme preset (`coral` / `sage` / `slate`)

Set `PUBLIC_THEME` in `.env`:

```bash
PUBLIC_THEME=coral   # default — warm terracotta on cream
# PUBLIC_THEME=sage  # deep sage on warm grey
# PUBLIC_THEME=slate # deep slate-blue on cool grey
```

The Astro layout renders `<html data-theme="...">` once at build time. CSS custom properties in `src/styles/global.css` resolve to the right token set. Want a fourth theme? Add a `:root[data-theme='yours']` block — copy any of the three existing ones as a starting point.

> **Why no runtime toggle?** A personal bio page has one identity. The user lands, scans, taps one link, and leaves. A theme switcher would add weight, complexity, and confusion without a use case.

### 5. Newsletter provider

Set `PUBLIC_NEWSLETTER_PROVIDER` to one of:

| Provider | Setup |
|---|---|
| `buttondown` | Set `PUBLIC_BUTTONDOWN_USERNAME=yourhandle`. Free tier: 100 subscribers. |
| `mailchimp` | Set `PUBLIC_MAILCHIMP_ACTION=https://...mailchimp.com/subscribe/post?u=...&id=...`. Free tier: 500 subscribers. |
| `none` | Hides the newsletter section entirely. |

The form opens in a new tab on submit; nothing else changes about the rest of the page.

### 6. Click analytics

Drop your privacy-friendly analytics tag into `.env`:

```bash
PUBLIC_ANALYTICS_SRC=https://plausible.io/js/script.js
PUBLIC_ANALYTICS_DOMAIN=yourdomain.com
```

The base layout injects the script tag for you. Every outbound link already carries `data-link-id`, and a 12-line dispatcher in `Base.astro` forwards each click as a `Link Click` event with the link id as a property. Plausible: shows up under **Goals → Custom Events**. Umami: shows up under **Events**.

If you don't set `PUBLIC_ANALYTICS_SRC`, the dispatcher is a silent no-op. Zero tracking, zero requests.

GA4 works with the same dispatcher pattern but is not the default — see [Plausible docs](https://plausible.io/docs/custom-event-goals) or [Umami docs](https://umami.is/docs/track-events) for either.

### 7. Avatar photo

Place your headshot in `public/images/` and set `person.avatarSrc: '/images/avatar.jpg'`. Recommended: square JPG/PNG, at least 256×256, optimized to under 30 KB. Leave `avatarSrc` blank to render the warm CSS monogram (initials in the accent color) — useful if you want a textual brand.

---

## Deploy to GitHub Pages (3 steps)

> The source repo is private — there is no Fork button. Download the source ZIP from [templates.allanninal.dev/link-in-bio/](https://templates.allanninal.dev/link-in-bio/) and follow these steps.

1. **Unzip** and initialize a Git repo:

   ```bash
   unzip link-in-bio-source.zip -d my-bio
   cd my-bio
   git init && git add . && git commit -m "init from link-in-bio template"
   ```

2. **Push** to a new GitHub repository:

   ```bash
   git remote add origin https://github.com/<you>/<your-repo>.git
   git push -u origin main
   ```

3. **Enable Pages:** Settings → Pages → Source: GitHub Actions. The included `pages.yml` workflow builds + deploys on every push to `main`.

Your site will be live at `https://<you>.github.io/<your-repo>/`.

### Custom domain

1. Add a `CNAME` file in `public/` with your domain.
2. In repo Settings → Variables → Actions, set:
   - `PUBLIC_SITE_URL` = `https://your-domain.com`
   - `PUBLIC_BASE_PATH` = `/`
3. Push to redeploy.

---

## Alternate deploys

### Vercel

```bash
npm install -g vercel
vercel --prod
```

### Netlify

Drag the `dist/` folder to [app.netlify.com/drop](https://app.netlify.com/drop), or connect the repo. Build: `npm run build`. Publish: `dist/`.

### Cloudflare Pages

Connect the repo. Build: `npm run build`. Output: `dist/`.

---

## Testing

### Run all tests

```bash
npm run test:all
# = npm run build && npm run test && npm run test:links && npm run test:lighthouse
```

### Individual suites

```bash
npm run test           # All Playwright tests (49 tests)
npm run test:a11y      # Axe accessibility only — runs across all 3 themes
npm run test:links     # Linkinator crawl (zero broken links)
npm run test:lighthouse # Lighthouse CI (≥95 all four categories)
npm run test:ui        # Playwright UI mode (interactive debugging)
```

### What each suite covers

| File | What it tests |
|---|---|
| `tests/pages.spec.ts` | Renders, h1 + footer present, no console errors; meta description, OG image + `og:type=profile`, canonical, sitemap, robots.txt, `Person` JSON-LD with non-empty `sameAs` |
| `tests/interactions.spec.ts` | Identity block (avatar + name); link list (≥4 pills, every pill has `data-link-id`, exactly one highlighted, externals safely targeted); featured card; newsletter (invalid → error, fix → clears, valid → success); newsletter provider-aware action; click analytics dispatcher (Plausible event, Umami event, silent no-op when neither defined); donate link; social row (≥6, every has aria-label); LinkedIn-first ordering |
| `tests/responsive.spec.ts` | No horizontal scroll at 375/768/1280/1920px; mobile identity above the fold; desktop 1440x900 highlighted link above the fold; centered single-column ≤480px on desktop; 44px tap targets for pills + Subscribe; 40px for social icons |
| `tests/theme.spec.ts` | All three presets render every section without breakage and resolve the `--color-accent` token; default build is `coral`; no runtime theme toggle present; `color-scheme: light` across all presets |
| `tests/a11y.spec.ts` | Zero axe violations on every theme preset (catches accent-token contrast regressions early) |
| `tests/links.spec.ts` | All external links use `rel="noopener noreferrer"`; internal links resolve; hash anchors point to existing IDs; mailto links are well-formed |

---

## Support and donations

This template is **free and MIT-licensed**. Use it for personal, commercial, or client work — no permission or attribution required.

If it saved you time, a small tip keeps this project going:
[**Ko-fi — ko-fi.com/allanninal**](https://ko-fi.com/allanninal)

### For cloning users

- The GitHub "Sponsor" button on your fork is driven by `.github/FUNDING.yml`. Edit `ko_fi: allanninal` to point at your own handle, or delete the file to hide the button.
- The small footer "Support the maker" Ko-fi link is driven by `PUBLIC_AUTHOR_DONATE_URL`. Set it blank to hide it.

---

## License

MIT — see [LICENSE](./LICENSE).

Part of the [365-template series](https://templates.allanninal.dev/) — Day 4 of 365 free, MIT-licensed static website templates.
