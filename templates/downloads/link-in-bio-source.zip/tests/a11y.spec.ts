import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES, THEMES, setTheme } from './helpers';

// Run axe across every theme preset — color-contrast is the most common
// regression when accent tokens change.

for (const route of ROUTES) {
  for (const theme of THEMES) {
    test(`a11y: ${route} (${theme}) — zero violations`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);

      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .analyze();

      const violations = results.violations.map((v) => ({
        id: v.id,
        impact: v.impact,
        description: v.description,
        nodes: v.nodes.length,
        help: v.helpUrl,
      }));

      expect(
        violations,
        `Axe violations on ${route} (${theme}):\n${JSON.stringify(violations, null, 2)}`
      ).toEqual([]);
    });
  }
}
