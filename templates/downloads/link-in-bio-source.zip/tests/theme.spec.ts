import { test, expect } from '@playwright/test';
import { ROUTES, THEMES, setTheme } from './helpers';

// ── Theme presets — every preset renders all sections without breakage ──────

for (const route of ROUTES) {
  for (const theme of THEMES) {
    test(`${route} renders correctly in ${theme} theme`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);

      // data-theme attribute present
      const dataTheme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
      expect(dataTheme).toBe(theme);

      // Core sections still visible after theme swap
      await expect(page.locator('h1').first()).toBeVisible();
      // Link pills + social row exist only on the link-in-bio home; the Pro
      // /media-kit/ page is a different layout.
      if (route === '/') {
        await expect(page.locator('.link-pill').first()).toBeVisible();
        await expect(page.locator('a.social-icon').first()).toBeVisible();
      }

      // Token wires through — accent should be a non-empty CSS variable
      const accent = await page.evaluate(() =>
        getComputedStyle(document.documentElement).getPropertyValue('--color-accent').trim()
      );
      expect(accent).toBeTruthy();
    });
  }
}

// ── Default build is coral ──────────────────────────────────────────────────

test('default build ships with data-theme="coral"', async ({ page }) => {
  await page.goto('/');
  const dataTheme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(dataTheme).toBe('coral');
});

// ── No runtime theme toggle (by design) ─────────────────────────────────────

test('there is no theme toggle button in the page', async ({ page }) => {
  await page.goto('/');
  // Toggling a theme is a build-time choice for this template.
  const toggleByLabel = page.getByRole('button', { name: /toggle theme/i });
  expect(await toggleByLabel.count()).toBe(0);
});

// ── No prefers-color-scheme dark inversion (single-light template) ──────────

test('color-scheme stays light across all three presets', async ({ page }) => {
  await page.goto('/');
  for (const theme of THEMES) {
    await setTheme(page, theme);
    const cs = await page.evaluate(() =>
      getComputedStyle(document.documentElement).getPropertyValue('color-scheme').trim()
    );
    expect(cs).toContain('light');
  }
});
