import type { Page } from '@playwright/test';

// The Pro edition (PUBLIC_EDITION=pro) adds the /media-kit/ page; the free
// build redirects it, so it's only a real route under Pro.
export const ROUTES = [
  '/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/media-kit/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export const THEMES = ['coral', 'sage', 'slate'] as const;
export type Theme = (typeof THEMES)[number];

export async function setTheme(page: Page, theme: Theme) {
  // The theme is normally a build-time choice, but we can flip it on the
  // already-built page to verify CSS tokens render correctly under each
  // preset. This mimics what changing PUBLIC_THEME and re-building would do
  // because no theme-dependent JS branches off the attribute.
  await page.evaluate((t) => {
    document.documentElement.setAttribute('data-theme', t);
  }, theme);
}
