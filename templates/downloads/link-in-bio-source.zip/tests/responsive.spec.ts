import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

// ── No horizontal scroll at any viewport ─────────────────────────────────────

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}x${vp.height}) has no horizontal scroll`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await page.locator('h1').first().waitFor();

      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(overflow).toBe(false);
    });
  }
}

// ── Above-the-fold spec for link-in-bio ─────────────────────────────────────
// Mobile (375x667 — the dominant viewport for this page type): identity must
// land above the fold. Featured + first link can fall below — link-in-bio is
// a vertical scroll experience, not a single-screen waitlist.

test('mobile 375x667: identity (avatar + name + tagline) visible above the fold', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  await page.locator('h1').first().waitFor();

  await expect(page.locator('h1')).toBeInViewport();
  // Avatar (mono or photo) must also be in the initial viewport
  const avatar = page.locator('.avatar-mono, img.avatar-photo').first();
  await expect(avatar).toBeInViewport();
});

// Larger desktop (1440x900): the highlighted primary CTA must land above
// the fold. 1280x720 is intentionally not asserted — the featured card +
// identity block fills that height and links live below.

test('desktop 1440x900: highlighted (primary) link visible without scroll', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('/');
  await page.locator('h1').first().waitFor();

  await expect(page.locator('.link-pill.is-highlighted')).toBeInViewport();
});

test('desktop 1280x720: page is centered single-column ≤480px', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.goto('/');

  const main = page.locator('main');
  const box = await main.boundingBox();
  expect(box).not.toBeNull();
  // max-w-bio = 30rem = 480px
  expect(box!.width).toBeLessThanOrEqual(481);

  // Centered horizontally — left margin should be ≥ (1280 - 480) / 2 - 16 (some padding tolerance)
  expect(box!.x).toBeGreaterThanOrEqual(380);
});

// ── Tap target sizes ────────────────────────────────────────────────────────

test('every link-pill meets 44px minimum tap target height', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');

  const pills = await page.locator('.link-pill').all();
  for (const p of pills) {
    const box = await p.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.height).toBeGreaterThanOrEqual(44);
  }
});

test('subscribe button meets 44px minimum tap target', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');

  const btn = page.getByRole('button', { name: /subscribe/i });
  const box = await btn.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.height).toBeGreaterThanOrEqual(44);
});

test('every social-icon meets 40px minimum tap target', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');

  const icons = await page.locator('a.social-icon').all();
  for (const i of icons) {
    const box = await i.boundingBox();
    expect(box).not.toBeNull();
    // Social icons render at 2.5rem = 40px (close to mobile minimum)
    expect(box!.height).toBeGreaterThanOrEqual(40);
    expect(box!.width).toBeGreaterThanOrEqual(40);
  }
});
