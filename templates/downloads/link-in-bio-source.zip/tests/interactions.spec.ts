import { test, expect } from '@playwright/test';

// ── Identity ─────────────────────────────────────────────────────────────────

test('identity block shows name, tagline, and avatar', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toBeVisible();
  // Avatar is either an <img> or the monogram <div>
  const monogram = page.locator('.avatar-mono');
  const photo = page.locator('img.avatar-photo');
  expect((await monogram.count()) + (await photo.count())).toBeGreaterThan(0);
});

// ── Link list ────────────────────────────────────────────────────────────────

test('link list renders ≥4 stacked link buttons', async ({ page }) => {
  await page.goto('/');
  const pills = page.locator('.link-pill');
  const count = await pills.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('every link in the list has a data-link-id', async ({ page }) => {
  await page.goto('/');
  const pills = await page.locator('.link-pill').all();
  for (const p of pills) {
    const id = await p.getAttribute('data-link-id');
    expect(id, 'link-pill missing data-link-id').toBeTruthy();
  }
});

test('exactly one link is highlighted (primary CTA)', async ({ page }) => {
  await page.goto('/');
  const highlighted = page.locator('.link-pill.is-highlighted');
  expect(await highlighted.count()).toBe(1);
});

test('external link pills open in a new tab with rel=noopener noreferrer', async ({ page }) => {
  await page.goto('/');
  const externalPills = page.locator('.link-pill[target="_blank"]');
  const count = await externalPills.count();
  expect(count).toBeGreaterThan(0);
  for (let i = 0; i < count; i++) {
    const rel = await externalPills.nth(i).getAttribute('rel');
    expect(rel).toContain('noopener');
    expect(rel).toContain('noreferrer');
  }
});

// ── Featured ────────────────────────────────────────────────────────────────

test('featured card renders with data-link-id="featured"', async ({ page }) => {
  await page.goto('/');
  const featured = page.locator('a.featured-card[data-link-id="featured"]');
  await expect(featured).toBeVisible();
});

// ── Newsletter form ─────────────────────────────────────────────────────────

test('newsletter form shows error on invalid email', async ({ page }) => {
  await page.goto('/');
  await page.locator('#newsletter-email').fill('notanemail');
  await page.getByRole('button', { name: /subscribe/i }).click();
  await expect(page.locator('#newsletter-error')).toBeVisible();
});

test('newsletter form clears error when user types valid email', async ({ page }) => {
  await page.goto('/');
  await page.locator('#newsletter-email').fill('bad');
  await page.getByRole('button', { name: /subscribe/i }).click();
  await expect(page.locator('#newsletter-error')).toBeVisible();

  await page.locator('#newsletter-email').fill('valid@example.com');
  await page.locator('#newsletter-email').dispatchEvent('input');
  await expect(page.locator('#newsletter-error')).toBeHidden();
});

test('newsletter form shows success state on valid demo submit', async ({ page }) => {
  await page.goto('/');
  await page.locator('#newsletter-email').fill('tester@example.com');
  await page.getByRole('button', { name: /subscribe/i }).click();
  await expect(page.locator('#newsletter-success')).toBeVisible({ timeout: 5000 });
});

test('newsletter form has provider-aware action attribute', async ({ page }) => {
  await page.goto('/');
  const action = await page.locator('#newsletter-form').getAttribute('action');
  // Default provider is buttondown
  expect(action).toContain('buttondown.email');
});

test('newsletter email input has correct type and autocomplete', async ({ page }) => {
  await page.goto('/');
  const input = page.locator('#newsletter-email');
  expect(await input.getAttribute('type')).toBe('email');
  expect(await input.getAttribute('autocomplete')).toBe('email');
  expect(await input.getAttribute('autocapitalize')).toBe('off');
});

test('newsletter email label is associated with input', async ({ page }) => {
  await page.goto('/');
  const label = page.locator('label[for="newsletter-email"]');
  await expect(label).toBeAttached();
});

// ── Click analytics dispatcher ──────────────────────────────────────────────

test('clicking a link dispatches a Plausible event when available', async ({ page }) => {
  await page.goto('/');

  // Inject a mock plausible function that records calls
  await page.evaluate(() => {
    (window as any).__events = [];
    (window as any).plausible = (event: string, options: any) => {
      (window as any).__events.push({ event, options });
    };
  });

  // Prevent the new-tab navigation so the listener has time to run.
  await page.evaluate(() => {
    document.querySelectorAll('a.link-pill').forEach((a) => a.removeAttribute('target'));
    document.querySelectorAll('a.link-pill').forEach((a) => a.setAttribute('href', '#'));
  });

  await page.locator('.link-pill').first().click();
  const events = await page.evaluate(() => (window as any).__events);
  expect(events.length).toBeGreaterThan(0);
  expect(events[0].event).toBe('Link Click');
  expect(events[0].options.props.id).toBeTruthy();
});

test('clicking a link dispatches an Umami event when available', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => {
    (window as any).__events = [];
    (window as any).umami = {
      track: (event: string, props: any) => {
        (window as any).__events.push({ event, props });
      },
    };
  });
  await page.evaluate(() => {
    document.querySelectorAll('a.social-icon').forEach((a) => a.removeAttribute('target'));
    document.querySelectorAll('a.social-icon').forEach((a) => a.setAttribute('href', '#'));
  });

  await page.locator('.social-icon').first().click();
  const events = await page.evaluate(() => (window as any).__events);
  expect(events.length).toBeGreaterThan(0);
  expect(events[0].event).toBe('link-click');
  expect(events[0].props.id).toContain('social-');
});

test('clicking a link with neither analytics defined is a silent no-op', async ({ page }) => {
  await page.goto('/');
  // Ensure neither is defined
  await page.evaluate(() => {
    delete (window as any).plausible;
    delete (window as any).umami;
  });
  await page.evaluate(() => {
    document.querySelectorAll('a.link-pill').forEach((a) => a.removeAttribute('target'));
    document.querySelectorAll('a.link-pill').forEach((a) => a.setAttribute('href', '#'));
  });

  let pageErrored = false;
  page.on('pageerror', () => { pageErrored = true; });
  await page.locator('.link-pill').first().click();
  expect(pageErrored).toBe(false);
});

// ── Donate button ────────────────────────────────────────────────────────────

test('footer donate link points to ko-fi when env var is set', async ({ page }) => {
  await page.goto('/');
  const donate = page.locator('[data-donate-url]').first();
  const count = await donate.count();
  if (count > 0) {
    const href = await donate.getAttribute('href');
    expect(href).toBeTruthy();
    expect(href).toContain('ko-fi.com');
  }
});

// ── Social row ──────────────────────────────────────────────────────────────

test('social row renders ≥6 icons each with aria-label', async ({ page }) => {
  await page.goto('/');
  const icons = page.locator('a.social-icon');
  const count = await icons.count();
  expect(count).toBeGreaterThanOrEqual(6);
  for (let i = 0; i < count; i++) {
    const label = await icons.nth(i).getAttribute('aria-label');
    expect(label, 'social-icon missing aria-label').toBeTruthy();
  }
});

// ── LinkedIn-primary contact-priority convention ────────────────────────────

test('LinkedIn appears first in the social row', async ({ page }) => {
  await page.goto('/');
  const firstHref = await page.locator('a.social-icon').first().getAttribute('href');
  expect(firstHref).toContain('linkedin.com');
});
