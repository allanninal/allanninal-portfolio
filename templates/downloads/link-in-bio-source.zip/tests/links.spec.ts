import { test, expect } from '@playwright/test';
import { ROUTES } from './helpers';

// ── External links must open safely ────────────────────────────────────────

test('all external links open safely (noopener noreferrer)', async ({ page }) => {
  await page.goto('/');

  const extLinks = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];

  for (const link of extLinks) {
    const rel = await link.getAttribute('rel');
    const href = await link.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — missing noopener/noreferrer (rel="${rel}")`);
    }
  }

  expect(unsafe, `Unsafe external links:\n${unsafe.join('\n')}`).toEqual([]);
});

// ── Internal pathlinks resolve ─────────────────────────────────────────────

test('all internal links on home page resolve successfully', async ({ page }) => {
  await page.goto('/');

  const links = await page.locator('a[href]').all();
  const broken: string[] = [];

  for (const link of links) {
    const href = await link.getAttribute('href');
    if (!href) continue;
    if (href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) continue;
    if (href.startsWith('http') && !href.includes('localhost')) continue;
    if (href.startsWith('/') || !href.startsWith('http')) {
      try {
        const res = await page.request.get(href.startsWith('/') ? `http://localhost:4321${href}` : href);
        if (!res.ok()) broken.push(`${href} → ${res.status()}`);
      } catch {
        broken.push(`${href} → failed to fetch`);
      }
    }
  }

  expect(broken, `Broken internal links:\n${broken.join('\n')}`).toEqual([]);
});

// ── Hash anchors point to real IDs ─────────────────────────────────────────

test('all hash anchor links point to existing IDs on the page', async ({ page }) => {
  await page.goto('/');

  const anchorLinks = await page.locator('a[href^="#"]').all();
  const missing: string[] = [];

  for (const link of anchorLinks) {
    const href = await link.getAttribute('href');
    if (!href || href === '#') continue;
    const id = href.slice(1);
    const exists = await page.locator(`#${CSS.escape(id)}`).count();
    if (exists === 0) missing.push(`${href} — no element with id="${id}"`);
  }

  expect(missing, `Hash links with no matching ID:\n${missing.join('\n')}`).toEqual([]);
});

// ── Mailto/email links are present and correctly formatted ─────────────────

test('mailto links use a valid email format', async ({ page }) => {
  await page.goto('/');
  const mailtos = await page.locator('a[href^="mailto:"]').all();
  for (const m of mailtos) {
    const href = await m.getAttribute('href');
    expect(href).toMatch(/^mailto:[^\s@]+@[^\s@]+\.[^\s@]+/);
  }
});
