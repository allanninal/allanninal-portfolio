/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />

interface ImportMetaEnv {
  readonly PUBLIC_SITE_URL: string;
  readonly PUBLIC_BASE_PATH: string;
  readonly PUBLIC_THEME: 'coral' | 'sage' | 'slate' | string;
  readonly PUBLIC_NEWSLETTER_PROVIDER: 'buttondown' | 'mailchimp' | 'none' | string;
  readonly PUBLIC_BUTTONDOWN_USERNAME: string;
  readonly PUBLIC_MAILCHIMP_ACTION: string;
  readonly PUBLIC_ANALYTICS_SRC: string;
  readonly PUBLIC_ANALYTICS_DOMAIN: string;
  readonly PUBLIC_AUTHOR_DONATE_URL: string;
  readonly PUBLIC_TEMPLATE_HUB_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

interface Window {
  plausible?: (event: string, options?: { props?: Record<string, unknown> }) => void;
  umami?: { track?: (event: string, props?: Record<string, unknown>) => void };
}
