// Base-path-aware URL helper. Always use this for internal links so the site
// works at both site root (custom domain) and a subpath (GitHub Pages, showcase).

const BASE = import.meta.env.BASE_URL;

export function url(path: string): string {
  const trimmedBase = BASE.endsWith('/') ? BASE.slice(0, -1) : BASE;
  if (!path || path === '/') return BASE;
  if (path.startsWith('#')) return path;
  const trimmedPath = path.startsWith('/') ? path : `/${path}`;
  return `${trimmedBase}${trimmedPath}`;
}
