// The link list — the heart of this template.
// Order is the order shown on page. Each link gets a stable `id` used as
// `data-link-id` for analytics events.

export type LinkItem = {
  id: string;
  label: string;
  href: string;
  // Leading symbol shown on the left edge of the pill button. Emoji is
  // intentional: it renders without a font request, scales with the user's
  // emoji renderer, and respects accent colors via the OS.
  emoji?: string;
  // Optional small line under the label (e.g. "Free", "Updated weekly").
  meta?: string;
  // Highlight a single link with the accent color (used for the primary CTA).
  highlighted?: boolean;
};

export const links: LinkItem[] = [
  {
    id: 'free-cookbook',
    label: 'Free 30-recipe weeknight cookbook (PDF)',
    href: 'https://example.com/cookbook',
    emoji: '📘',
    meta: 'Free download · 2 MB PDF',
    highlighted: true,
  },
  {
    id: 'newsletter',
    label: 'Sunday newsletter — short and warm',
    href: 'https://buttondown.email/allanninal',
    emoji: '✉️',
    meta: '4,200 readers',
  },
  {
    id: 'youtube',
    label: 'Latest recipe videos',
    href: 'https://www.youtube.com/@allanninal',
    emoji: '▶️',
    meta: 'New every Wednesday',
  },
  {
    id: 'instagram-reels',
    label: 'Quick reels — under 60 seconds',
    href: 'https://www.instagram.com/allanninal/',
    emoji: '🎞️',
  },
  {
    id: 'shop-merch',
    label: 'Apron, tote, and the wooden spoon',
    href: 'https://example.com/shop',
    emoji: '🛍️',
    meta: 'Made in small batches',
  },
  {
    id: 'collab',
    label: 'Brand collabs & private dinners',
    href: 'mailto:landix.ninal@gmail.com',
    emoji: '🤝',
  },
];
