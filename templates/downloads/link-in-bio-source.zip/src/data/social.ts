// Social icon row — bottom of page, icon-only links.
// `key` chooses the icon SVG (see SocialIcon.astro). `label` is the
// accessible name (aria-label). Order matters — left to right.
//
// LinkedIn is listed FIRST per the project's contact-priority convention.

export type SocialItem = {
  key: 'linkedin' | 'instagram' | 'tiktok' | 'youtube' | 'spotify' | 'github' | 'x' | 'threads' | 'substack' | 'email';
  label: string;
  href: string;
};

export const socials: SocialItem[] = [
  { key: 'linkedin',  label: 'LinkedIn',  href: '#' },
  { key: 'instagram', label: 'Instagram', href: '#' },
  { key: 'youtube',   label: 'YouTube',   href: '#' },
  { key: 'tiktok',    label: 'TikTok',    href: '#' },
  { key: 'substack',  label: 'Substack',  href: 'https://buttondown.email/allanninal' },
  { key: 'x',         label: 'X / Twitter', href: '#' },
  { key: 'github',    label: 'GitHub',    href: '#' },
  { key: 'email',     label: 'Email',     href: 'mailto:hello@rinacastillo.com' },
];
