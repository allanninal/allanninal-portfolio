// Single source of truth for this link-in-bio page.
// Cloning users edit this file — and src/data/links.ts and src/data/social.ts —
// to make the site theirs. No code changes required.

export const site = {
  // Persona / identity block — top of page.
  person: {
    name: 'Rina Castillo',
    handle: '@example',
    tagline: 'Recipes for people who don\'t have time to hate cooking.',
    location: 'Toronto, ON',
    avatarSrc: '', // leave blank to render the warm CSS monogram avatar
    avatarAlt: 'Rina Castillo',
    description:
      'Indie food creator. Quick weeknight recipes, long-form newsletter on Sunday, and the occasional cookbook. Keep it simple, keep it warm.',
  },

  // Featured highlight — one elevated card above the link list.
  // type: 'video' | 'post' | 'product' | 'none'
  featured: {
    type: 'video' as 'video' | 'post' | 'product' | 'none',
    eyebrow: 'New this week',
    title: 'Garlic noodles in 15 minutes (and a confession about MSG)',
    href: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    // YouTube thumbnail CDN — public, stable. Pattern:
    //   https://img.youtube.com/vi/{VIDEO_ID}/hqdefault.jpg
    thumbnail: '', // blank → render gradient placeholder
    duration: '12:04',
    badge: 'YouTube',
  },

  // Footer — copyright line + optional pronouns/timezone.
  footer: {
    pronouns: 'he/him',
    timezone: 'EST · GMT-5',
    copyrightHolder: 'Rina Castillo',
  },

  // Newsletter capture — provider chosen via PUBLIC_NEWSLETTER_PROVIDER env var.
  // Operator UX: drop a Buttondown username OR a Mailchimp embed URL — that's it.
  newsletter: {
    enabled: true,
    eyebrow: 'Sundays only',
    headline: 'One short letter. Always Sunday morning.',
    subhead: 'Recipes I cooked this week, what worked, what didn\'t. No ads, no upsells.',
    placeholder: 'you@example.com',
    submitLabel: 'Subscribe',
    submitAriaLabel: 'Subscribe to the Sunday newsletter',
    successMessage: 'Got it — confirm your email and you\'re in.',
    errorMessage: 'Please enter a valid email address.',
  },
};

export type Site = typeof site;
