# Link-in-Bio Template — Research Brief

> **Persona assumption:** An **indie food creator** — someone who posts recipes on Instagram/TikTok, runs a Substack newsletter, sells a digital cookbook, and has a YouTube channel. This persona is chosen because food creators represent the broadest overlap of the three target audiences (musician, freelancer, creator): they need social links, a featured content block, a newsletter capture, and a shop link — all at once. Placeholder copy and photo direction are grounded to this persona. Builder note: the persona is a cosmetic layer; the underlying section structure applies equally to a musician, a fitness coach, or an indie hacker.

---

## Audience & primary CTA
- **Who visits:** A follower who tapped the Instagram/TikTok "link in bio" button. They have ~5 seconds of intent. They want to find one specific thing (the recipe, the newsletter, the shop) without hunting.
- **Primary CTA:** Click a curated outbound link — whichever the creator has pinned first (e.g., "Get the free cookbook" or "Watch latest video").
- **Secondary CTAs:** Subscribe to newsletter (inline email capture), follow on a second platform not currently open, visit the shop.

---

## Reference sites (real businesses)
- https://www.minimalistbaker.com — custom branded landing page, not Linktree; tells brand story via hero video then leads to recipes and courses. Warm earthy tones, dense but scannable.
- https://linkfire.com/link-in-bio — musician-focused: avatar + name, streaming service buttons, tour dates link, social row. Shows the "link buttons stacked vertically" as the dominant pattern for music creators.
- https://beacons.ai/linktree — Beacons' own page; product card layout, featured YouTube embed, newsletter block, clean white background. Demonstrates how featured content elevates above a plain link list.
- https://yoga_with_kassandra (via linktr.ee) — fitness creator, 170K followers; avatar, short bio tagline, direct link to video membership platform. Sparse, high-contrast, no noise.
- https://taplink.at/en/blog/link-tree-examples.html — aggregates 15 real creator pages; confirms the recurring pattern: circular avatar top-center, name, one-line tagline, stacked pill/card links, icon row at bottom.
- https://solo.to — simpler product but shows warm pastel color schemes are the dominant aesthetic in the space; gradient backgrounds (peach-to-rose, lavender-to-blue) are everywhere.
- https://digitalsynopsis.com/tools/link-in-bio-page-designs/ — Jessica Hische: bright orange CTAs on soft pink bg; Lauren Hom: playful, vibrant, personality-first; Timothy Goodman: pastel blue bg, stacked vertical sections. All three confirm soft/warm palette as the default register for creative personal brands.

---

## Existing templates surveyed
- https://github.com/JPerez00/astrolinks — Astro v5 + Tailwind, GH Pages deploy wired, dark/light toggle, typewriter effect. **Strength:** modern stack, auto-deploy. **Weakness:** zero theming story, no analytics hooks, no featured content block, no newsletter capture, generic.
- https://github.com/treefarmstudio/linked-up — Astro, minimalist. **Strength:** lean (72% Astro). **Weakness:** no docs, no config-driven links, no theming, no social icons.
- https://github.com/flamrdevs/astrolinkt — Astro + React + Tailwind. **Weakness:** React dependency for a bio page is over-engineered; no analytics, no themes.
- **Saturated pattern:** centered avatar → plain stacked `<a>` buttons → icon row. Every free template does exactly this. None ship with (a) `data-theme` presets, (b) analytics event attributes, (c) a featured content block, or (d) a newsletter capture built in.
- **Missing:** A config-driven (`links.json`) link-in-bio template with 3 pre-built `data-theme` presets, a featured card slot, an inline newsletter embed, `data-link-id` on every outbound link for event tracking, and schema.org `Person` + `sameAs[]`. No existing free Astro template ships all of this.

---

## Must-have sections (in order)
1. **Identity block** — circular avatar (120–140px), display-weight name, one-line tagline ("Recipes for people who don't have time to hate cooking"), optional location badge.
2. **Featured highlight** — a single elevated card (larger than links below it): latest video thumbnail + title, OR latest newsletter issue + excerpt, OR product/book CTA. Config-driven: set `featured.type` to `video | post | product | none`. This is what separates the page from a plain Linktree.
3. **Link list** — 4–8 stacked pill buttons, each with an optional leading emoji/icon and a label. Order is config-driven via `links.json`. Each `<a>` carries `data-link-id="[slug]"` for analytics.
4. **Newsletter capture** — inline single-field email form (Buttondown or Mailchimp embed URL, one-line config). Below the links, above the social row. Can be hidden via `newsletter.enabled: false`.
5. **Social icon row** — icon-only links (Instagram, TikTok, YouTube, Spotify, GitHub, X, etc.) sourced from `social.json`. No labels.
6. **Footer** — copyright line, "Built with [template name]" (removable), optional pronouns/timezone.

**Omitted (not justified for static):** real-time "now playing" Spotify widget (requires OAuth), live YouTube subscriber count (embed the static channel link instead), tip jar (embed Ko-fi button in the link list, not a native block).

---

## Design conventions
- **Typography:** Display-soft humanist sans for name/headline — **DM Sans** (weight 700, tracking -0.02em) or **Plus Jakarta Sans**. Body and link labels: DM Sans 400/500. No mono. No geometric grotesque (that's Day 1 + Day 2 territory). Soft, rounded letterforms match the warm-palette energy.
- **Color palette tendency:** Soft warm — not dark, not violet, not lime, not amber. Default theme: `#FFF5F0` (warm off-white) base, `#FF6B4A` (terracotta/coral) accent, `#1A1A1A` text. Feels personal, warm, approachable. Contrast with every prior day in the sprint. Two additional `data-theme` presets ship out of the box: `theme-sage` (sage green + cream) and `theme-slate` (cool slate + white, near-neutral). All three pass WCAG AA.
- **Imagery:** Creator avatar photo is the sole image. Full-bleed background is flat color or a very subtle CSS grain texture (no stock photos, no gradients that require image files). The featured card may include a thumbnail (user-supplied URL).
- **Density:** Single narrow column, max-width 480px, centered. Mobile-first — this page is viewed on a phone 95% of the time. Generous vertical rhythm. No grid, no columns, no bento.

---

## Trust signals to include
- **Avatar + real name** — identity is the #1 trust signal on a personal page.
- **Platform follower count badge** (optional, config-driven static number, not live): "142K on TikTok". Operators set this manually in `config.json`; no API call.
- **Featured content** — showing a real recent video/post title signals the creator is active, not abandoned.
- **Link button hover state** — subtle lift/shadow on hover; shows the page is live and cared-for.
- **Social icon row** — multiple verified platforms imply real, multi-channel presence.

---

## SEO / schema.org
- **Type:** `Person` (not `ProfilePage` — `ProfilePage` was introduced but has low crawler adoption; `Person` with `sameAs[]` is the established, widely-supported pattern and directly serves the use case).
- **Required properties:** `Person.name`, `Person.url`, `Person.image`, `Person.description` (the one-line tagline), `Person.sameAs[]` (one entry per social platform in `social.json` — auto-generated from the same config).
- **Suggested OG image direction:** Square 1:1 (Instagram-friendly), creator avatar centered on accent-color background, name in display weight, tagline below. Committed as a static PNG at `public/og.png`. No build-time generation required.

---

## Theming story
Three `data-theme` presets defined as CSS custom property blocks on `:root[data-theme="X"]`. A `theme` key in `config.json` (`"coral"` | `"sage"` | `"slate"`) sets the `data-theme` attribute at build time via a one-liner in the Astro layout. No runtime JS needed for theme switching — this is a deploy-time setting, not a user-facing toggle. (A user-facing toggle makes no sense for a personal page — the creator picks their theme once and ships it.) Token set per theme: `--color-bg`, `--color-surface`, `--color-accent`, `--color-accent-text`, `--color-text`, `--color-text-muted`, `--radius-card`.

---

## Click analytics — what "ready" means concretely
Every outbound `<a>` in the link list and the featured card receives two attributes:
1. `data-link-id="[slug-from-config]"` — stable identifier set in `links.json`.
2. A small inline script (~10 lines) fires `plausible('Link Click', {props: {id: linkId}})` or `umami.track('link-click', {id: linkId})` on click, depending on which analytics snippet is present. If neither is found the handler is a no-op — no errors.

The operator drops their Plausible or Umami `<script>` tag into `config.json` under `analytics.scriptSrc`. That's the only setup required. GA4 is not the default recommendation (cookie consent overhead, GDPR friction) but the event dispatch pattern is compatible — document in README. No third-party analytics SDK is bundled.

---

## Static-only fit
No concerns. Every dynamic-feeling feature resolves to a static substitute:
- **Newsletter capture:** HTTP POST to Buttondown (`https://api.buttondown.email/v1/subscribers`) or a Mailchimp embed `<form>` URL — no SSR.
- **Featured video thumbnail:** User supplies a static `thumbnail` URL in config (YouTube thumbnail CDN URL is public and stable).
- **Follower counts:** Static numbers in `config.json`; operator updates manually.
- **"Now playing" Spotify:** Out of scope — requires OAuth. Recommend embedding a static "Listen on Spotify" link button instead.

---

## Differentiation — what we'll do better
- **Own your URL:** `yourname.com/links` or `yourname.github.io` — not `linktr.ee/yourname`. Platform lock-in eliminated.
- **No platform fee, ever:** Linktree charges for custom domains, analytics, and theming. This template: MIT, free, forever.
- **Themeable in code:** Three `data-theme` presets, CSS token architecture, swap or extend without touching HTML. Linktree's theme picker is locked behind Pro tier ($9/mo).
- **Analytics without tracker bloat:** `data-link-id` + Plausible/Umami = per-link click events, no cookies, GDPR-clean. Linktree's link analytics: Pro tier only.
- **Featured content block:** No free Linktree tier, no existing free static template includes an elevated featured card slot. This is the visible differentiator on first visit.
- **Config-driven, not code-driven:** Non-technical creators edit one `config.json` — name, tagline, links, theme, social handles — and redeploy. No JSX, no component edits.
- **Lighthouse 95+ on mobile:** Single-column, no JS framework, no web font reflow (DM Sans via `font-display: swap`), no tracking scripts by default, sub-5KB page weight excluding avatar.
- **GH Pages one-click:** Deploy wired into root `pages.yml` following the project's established CI pattern.
- **Accessibility:** Link buttons have `:focus-visible` rings, social icons have `aria-label`, avatar has meaningful `alt`, color contrast verified at AA for all three themes.
