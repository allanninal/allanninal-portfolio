/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // No `darkMode` — this template is intentionally single-theme per deploy.
  // Theme variant is selected at build time via `data-theme` (coral|sage|slate).
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        display: ['DM Sans', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'xs':  ['0.8rem',   { lineHeight: '1.5' }],
        'sm':  ['0.875rem', { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.6' }],
        'lg':  ['1.125rem', { lineHeight: '1.55' }],
        'xl':  ['1.25rem',  { lineHeight: '1.45' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.25rem',  { lineHeight: '1.1' }],
      },
      maxWidth: {
        bio: '30rem', // 480px — single-column page width
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease forwards',
      },
      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0', transform: 'translateY(4px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
};
