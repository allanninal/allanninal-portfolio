import { test, expect } from '@playwright/test';

test.describe('Lowtide — smoke tests', () => {
  test('homepage renders with the game name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Lowtide/);
    await expect(page.locator('h1')).toContainText('Keep the light');
  });

  // First product page in the sprint, so the first time schema.org actually fits.
  test('is marked up as a VideoGame with a real offer', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"VideoGame"');
    expect(json).toContain('"Offer"');
    expect(json).toContain('"priceCurrency":"USD"');
    // Days 103-108 settled for Person; this one should not.
    expect(json).not.toContain('"Person"');
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const fit = page.locator('#fit .fit');
    await expect(fit).toBeVisible();
    const box = await fit.boundingBox();
    expect(box!.height).toBeGreaterThan(300);
  });

  // ── The three facts ─────────────────────────────────────────────────────
  test('length, price and post-launch plans are in the hero', async ({ page }) => {
    await page.goto('/');
    const facts = page.locator('dl.facts > div');
    expect(await facts.count()).toBe(3);
    const text = (await facts.allTextContents()).join(' ');
    expect(text).toMatch(/\d+ hours/);
    expect(text).toMatch(/\$\d+/);
    expect(text.toLowerCase()).toContain('no dlc');
  });

  // ── Is it for you ───────────────────────────────────────────────────────
  test('the page publishes reasons to skip the game', async ({ page }) => {
    await page.goto('/');
    const no = page.locator('#fit .fit--no li');
    const yes = page.locator('#fit .fit--yes li');
    expect(await no.count()).toBeGreaterThanOrEqual(4);
    expect(await no.count()).toBe(await yes.count());
    await expect(page.locator('#fit .fit--no h3')).toHaveText('Skip it if');
    await expect(page.locator('#fit .fit--yes h3')).toHaveText('Buy it if');
    await expect(page.locator('#fit')).toContainText(/highest-converting thing on this page/i);
  });

  test('fit and support colours are not the accent', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--state-yes', '--state-no', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  // ── Accessibility table ─────────────────────────────────────────────────
  test('the accessibility list keeps its partials and its no', async ({ page }) => {
    await page.goto('/');
    const sups = (await page.locator('#access .sup').allTextContents()).map((s) => s.trim());
    expect(sups.length).toBeGreaterThan(6);
    for (const s of sups) expect(['Yes', 'Partial', 'Not yet']).toContain(s);
    const yes = sups.filter((s) => s === 'Yes').length;
    const rest = sups.length - yes;
    expect(rest).toBeGreaterThan(0);
    await expect(page.locator('#access h2')).toHaveText(`${yes} supported. ${rest} not, and they are listed too.`);
  });

  test('every support state carries a glyph as well as a word', async ({ page }) => {
    await page.goto('/');
    for (const s of await page.locator('#access .sup').all()) {
      expect(await s.getAttribute('data-glyph')).toBeTruthy();
    }
  });

  // ── Screens ─────────────────────────────────────────────────────────────
  test('the screenshot slots are drawn placeholders, not fabricated captures', async ({ page }) => {
    await page.goto('/');
    const raster = await page.locator('img').evaluateAll((imgs) =>
      imgs.map((i) => i.getAttribute('src') || '').filter((s) => /\.(jpe?g|png|webp|avif)$/i.test(s)));
    expect(raster).toEqual([]);
    const figs = page.locator('#screens figure');
    const n = await figs.count();
    expect(n).toBe(4);
    for (const f of await figs.all()) {
      await expect(f.locator('svg')).toHaveAttribute('aria-hidden', 'true');
      await expect(f.locator('figcaption b')).toContainText('16:9');
    }
    await expect(page.locator('#screens h2')).toContainText(`${n} slots`);
    await expect(page.locator('#faq')).toContainText(/Lowtide is fictional/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the wishlist form asks only for an email', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#email')).toHaveAttribute('required', '');
    // A landing page that demands a name to join a mailing list converts worse.
    expect(await page.locator('#wishlist input[required]').count()).toBe(1);
    await expect(page.locator('#wishlist')).toContainText(/Two emails, ever/i);
  });

  test('no trace of the day-108 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['casper lind', 'ann arbor', 'cut list', 'dev-week', 'graveyard', 'q1350189']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro store page kit is absent from the free build', async ({ page }) => {
    const res = await page.goto('/store-page-kit/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
