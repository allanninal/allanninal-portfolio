// Lowtide — a fictional game by Hollow Pine Games, Bellingham WA.
//
// A product page, not a portfolio. Days 101-108 were all "here is what I do
// and here is the uncomfortable part", and eight of those in a row is itself a
// house style — which is the convergence trap this project keeps documenting.
// A landing page has a job: it has to sell the thing. So this one is shaped
// like a store page, and the honesty lives in the content.

export const site = {
  name:        'Lowtide',
  shortName:   'Lowtide',
  title:       'Lowtide — a quiet game about a lighthouse and a rising sea',
  tagline:     'Keep the light. The water is not going to stop.',
  owner:       'Hollow Pine Games',
  ownerRole:   'Two people in Bellingham',
  credential:  'Second game · PC, Mac and Steam Deck',
  city:        'Bellingham',
  state:       'WA',
  language:    'en',
  phoneDisplay: '(360) 555-0107',
  phoneHref:   '+13605550107',
  email:       'hello@hollowpine.example',
  streetAddress: '1201 Cornwall Ave',
  postalCode:  '98225',
  hours:       'Two people, one inbox, usually within a day',
  bookingWindow: 'Wishlist now · demo during Next Fest',
  description:
    'A slow, single-player game about keeping a lighthouse lit through one winter as the sea ' +
    'takes the island back. Eleven hours, $19, no combat and no fail state. If that last ' +
    'sentence sounds like a warning rather than a pitch, this page will tell you plainly.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'What it is',   href: '#what' },
  { label: 'Screens',      href: '#screens' },
  { label: 'Is it for you', href: '#fit' },
  { label: 'Accessibility', href: '#access' },
  { label: 'Wishlist',     href: '#wishlist' },
];

// ── The three facts ───────────────────────────────────────────────────────
// In the hero, not in an FAQ. These are the questions every store page makes
// you hunt for.

export const facts = [
  { label: 'How long',  value: '11 hours', note: 'One winter, start to finish. Some people take fourteen; nobody has taken thirty.' },
  { label: 'How much',  value: '$19',      note: 'Launch price. There will be a sale eventually and it will not be in the first month.' },
  { label: 'After launch', value: 'Nothing', note: 'No DLC, no season pass, no microtransactions, no live service. Patches, and then we make something else.' },
];

// ── What it is ────────────────────────────────────────────────────────────

export const pillars = [
  {
    head: 'One island, one winter',
    body: 'You are the keeper. The light has to be lit every night from October to March, and every day the sea takes a little more of the path you used to walk to get there. Nothing chases you. The route just stops working.',
  },
  {
    head: 'The tide is the clock',
    body: 'There is no timer on screen and no stamina bar. There is a tide table, and it is accurate, and if you have not read it you will be on the wrong side of the causeway when it closes. Learning to read it is most of the game.',
  },
  {
    head: 'Nobody arrives to explain it',
    body: 'The story is in the logbook, the supply manifests and what is missing from them. There are no cutscenes and no voice-over. Some players finish without piecing it together, and that is a legitimate way to finish.',
  },
];

// ── Screens ───────────────────────────────────────────────────────────────
// Drawn placeholders. The game is fictional; fabricating footage of it would
// be the one dishonest thing on this page.

export const screens = [
  { slot: 'Hero capsule',  ratio: '16:9', what: 'The single image that has to work as a thumbnail. Readable at 292×136 or it is the wrong image.' },
  { slot: 'Gameplay, wide', ratio: '16:9', what: 'What the player is actually looking at for eleven hours. Not the prettiest frame — the most typical one.' },
  { slot: 'A mechanic',    ratio: '16:9', what: 'The tide table, mid-decision. A screenshot that shows a choice beats a screenshot that shows a view.' },
  { slot: 'A moment',      ratio: '16:9', what: 'The one image people will post. Every game has one; it is rarely the one the developer expects.' },
];

export const screensNote =
  'These four slots are drawn, not photographed. The game on this page is fictional, and ' +
  'inventing screenshots of it would be the single dishonest thing on a page whose most useful ' +
  'section is a list of reasons to skip the game. If you are using this template, this is where ' +
  'your real captures go — the labels are the brief.';

// ── Is it for you ─────────────────────────────────────────────────────────
// The section almost no store page has, and the highest-converting thing here.

export const fit = {
  yes: [
    'You liked a game where the map was the puzzle.',
    'You want something you can finish over a fortnight of evenings.',
    'You read the notes and the labels in games, and you are annoyed when there are none.',
    'You are happy for a game to be quiet for twenty minutes at a stretch.',
    'You want to be able to save and stop at any moment, because you have a life.',
  ],
  no: [
    'You want combat. There is none, at all, and no amount of playing unlocks any.',
    'You want to be told what to do next. There is no quest marker and there will not be a patch that adds one.',
    'You bounce off games without a fail state. Nothing here can kill you and nothing can be lost permanently.',
    'You need eighty hours for your money. This is eleven, deliberately, and the price reflects it.',
    'You play mainly for multiplayer. It is single-player only, forever, and that is a design decision rather than a budget one.',
  ],
  note:
    'Publishing the right-hand column is the highest-converting thing on this page, which sounds ' +
    'backwards and is not. It raises conversion among the people it does fit, it cuts refunds ' +
    'among the people it does not, and it is the clearest signal a developer can give that they ' +
    'know what they made.',
};

// ── Accessibility ─────────────────────────────────────────────────────────
// Players search for these and almost no indie page lists them. The "no" rows
// stay in.

export const access = {
  rows: [
    { feature: 'Full subtitles, resizable',        state: 'yes',  note: 'Three sizes, with an optional background box. Default is larger than most games ship.' },
    { feature: 'Colourblind modes',                state: 'yes',  note: 'Deuteranopia, protanopia and tritanopia. Nothing in the game is signalled by colour alone regardless.' },
    { feature: 'Save anywhere, single button',     state: 'yes',  note: 'Including mid-crossing. Stopping is never punished.' },
    { feature: 'No fail state',                    state: 'yes',  note: 'Not an option — the design. You cannot die and nothing is permanently missable.' },
    { feature: 'Full remapping, keyboard and pad', state: 'yes',  note: 'Every action, including the ones on modifiers.' },
    { feature: 'Hold-to-press instead of hold',    state: 'yes',  note: 'Every hold interaction has a toggle alternative.' },
    { feature: 'Screen-reader support in menus',   state: 'part', note: 'Menus and the logbook are read; in-world labels are not yet. This is the one we are least happy about.' },
    { feature: 'One-handed play',                  state: 'part', note: 'Possible on a pad with remapping, awkward on keyboard. We have not tested it properly and will not claim it until we have.' },
    { feature: 'Reduced motion',                   state: 'no',   note: 'The camera sway during crossings cannot currently be turned off. It is on the list, and until it ships this row says no.' },
  ],
  note:
    'Two partials and a no. Leaving them in is the point — a support list with nothing but ticks ' +
    'on it tells a player who needs one of these nothing at all, because they cannot tell the ' +
    'difference between "supported" and "never checked".',
};

export const STATE = {
  yes:  { label: 'Yes',       glyph: '✓' },
  part: { label: 'Partial',   glyph: '~' },
  no:   { label: 'Not yet',   glyph: '✕' },
} as const;

// ── Press ─────────────────────────────────────────────────────────────────

export const press = [
  { text: 'It is the first game in years that trusted me to read a table and work it out. Nothing on screen tells you the causeway is about to close. The water does.',
    who: 'Coastwise Review' },
  { text: 'Slow, and I mean that as the compliment the developers clearly intend. The store page warns you it has no combat. Believe it, and then decide.',
    who: 'Threadbare Weekly' },
];

// ── Specs ─────────────────────────────────────────────────────────────────

export const specs = [
  { k: 'Platforms',   v: 'PC, Mac, Steam Deck Verified' },
  { k: 'Players',     v: 'Single-player only' },
  { k: 'Languages',   v: 'English, French, German, Spanish, Japanese — text' },
  { k: 'Controller',  v: 'Full support, fully remappable' },
  { k: 'Install size', v: '4.2 GB' },
  { k: 'Minimum spec', v: 'Anything from 2018 onward. It is a small game and it is meant to run on a laptop.' },
];

export const faqs = [
  {
    q: 'Is there a demo?',
    a: 'Yes, during Next Fest, and it is the first two in-game weeks rather than a bespoke slice. If the demo bores you the full game will too, which is exactly what a demo is for.',
  },
  {
    q: 'Why are there no screenshots on this page?',
    a: 'Because this is a website template and Lowtide is fictional. The four slots are drawn placeholders labelled with the ratio and the job each image has to do. If you are using this template, put your real captures there.',
  },
  {
    q: 'Eleven hours for $19?',
    a: 'Yes, and we would rather say so on the store page than have you find out after buying. An eleven-hour game you finish is worth more than an eighty-hour game you abandon at hour nine, but you are entitled to disagree before paying rather than after.',
  },
  {
    q: 'Will it come to consoles?',
    a: 'We would like it to and we have not signed anything, so the honest answer is that we do not know. We will not put a console logo on this page until a build exists.',
  },
  {
    q: 'Is it scary?',
    a: 'No, and it is not trying to be. It is a game about weather and being alone with a job to do. There is no threat and nothing jumps out.',
  },
  {
    q: 'What does a wishlist actually do?',
    a: 'It tells the store to show the game to more people at launch, and it emails you when it is out or on sale. That is all it does, it costs nothing, and it is genuinely the most useful thing you can do for a two-person studio.',
  },
];
