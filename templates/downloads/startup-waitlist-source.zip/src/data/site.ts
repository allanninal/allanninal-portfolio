// Single source of truth for this waitlist page.
// Cloning users edit this file to make the site theirs.

export const site = {
  // Product identity — the thing you're building pre-launch.
  product: {
    name: 'Nexus',
    tagline: 'The AI workspace that thinks with you.',
    description:
      'Nexus connects your notes, docs, and conversations into a single intelligent layer. Stop searching — start knowing.',
    // Used in schema.org, OG meta, and the hero badge.
    foundingDate: '2026',
  },

  // Primary CTA — the one thing the hero asks visitors to do.
  cta: {
    label: 'Join the waitlist',
    placeholder: 'you@example.com',
    buttonAriaLabel: 'Submit your email to join the waitlist',
  },

  // Waitlist counter — sourced from src/data/waitlist-count.json at build time.
  // Shown as "X,XXX people waiting" in the hero badge.

  // Countdown target — overridden by PUBLIC_LAUNCH_DATE env var.
  // Default: 2026-09-01T12:00:00Z (ISO 8601, UTC)
  defaultLaunchDate: '2026-09-01T12:00:00Z',

  // Founder card (shown in the below-fold section).
  // Swap photo, name, role, and credential to your own.
  founder: {
    name: 'Nexus',
    role: 'Founder & CEO',
    credential: 'Previously at Notion · YC S25',
    // Photo: CSS avatar placeholder — swap with a real headshot in public/images/
    photoSrc: '', // leave blank to render the CSS monogram avatar
    photoAlt: 'Allan Niñal, Founder & CEO of Nexus',
    // Social links for the founder card
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    x: 'https://x.com/allannin',
  },

  // Backers / angels — short credibility line below founder.
  backers: [
    { name: 'Mia Chen', credential: 'ex-Figma' },
    { name: 'Daniel Park', credential: 'ex-Linear, angel' },
  ],

  // Footer social links — LinkedIn primary, per contact-priority convention.
  socials: {
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    x: 'https://x.com/allannin',
    github: 'https://github.com/allanninal',
    kofi: 'https://ko-fi.com/allanninal',
  },
  contactEmail: 'hello@nexus.com',
};

export type Site = typeof site;
