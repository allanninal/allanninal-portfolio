/// <reference path="../.astro/types.d.ts" />

interface ImportMetaEnv {
  readonly PUBLIC_SITE_URL: string;
  readonly PUBLIC_BASE_PATH: string;
  readonly PUBLIC_WAITLIST_PROVIDER: string;
  readonly PUBLIC_FORMSPREE_ID: string;
  readonly PUBLIC_BUTTONDOWN_USERNAME: string;
  readonly PUBLIC_CONVERTKIT_FORM_ID: string;
  readonly PUBLIC_LAUNCH_DATE: string;
  readonly PUBLIC_AUTHOR_DONATE_URL: string;
  readonly PUBLIC_USER_DONATE_URL: string;
  readonly PUBLIC_TEMPLATE_HUB_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
