# Startup Waitlist Template — Research Brief

> **Assumption:** Pre-launch single-page email capture for a software/AI/hardware startup — product not yet shipped, goal is building a list before launch day. Not a general SaaS marketing page; no pricing, no nav, no features deep-dive.

## Audience & primary CTA
- **Who visits:** Early-adopter techies arriving from a Product Hunt "upcoming" post, a founder tweet, a press mention, or word-of-mouth. Decision time: under 20 seconds.
- **Primary CTA:** *Join the waitlist* — one email field, one button. That is it.
- **Secondary CTAs:** Follow on X/Twitter (below the fold), share referral link (confirmation page only — not on this page).

## Reference sites (real businesses)
- https://linear.app (early access era) — dark minimal, opinionated headline ("The issue tracker you'll enjoy using"), single email field above the fold, product screenshot as sole visual. No nav, no pricing. Gold standard for restraint.
- https://arc.net (pre-1.0 waitlist era) — invite-only framing; used a 20-second silent product video as the entire hero. Exclusivity language ("request access") over generic "sign up". Drove 10k+ organic waitlist via FOMO.
- https://superhuman.com (pre-launch) — "The fastest email experience ever made." Charged $30/month from day one; 180k-person waitlist. Shows that bold, polarizing value prop converts better than hedged copy.
- https://cron.com (pre-Notion acquisition waitlist) — animated keyboard shortcut in hero communicated "power tool for power users" without a word. Proof that a micro-interaction can replace a paragraph of copy.
- https://www.granola.ai — minimal centered hero, green accent on near-black background, single-sentence product description, email field. No feature list, no pricing. Current live example of the exact format we're building.
- https://www.rabbit.tech (r1 preorder) — bold product visual as full-bleed hero, hard countdown to shipping date, preorder counter shown publicly ("50,000 units ordered"). Hardware but the pattern is identical.
- https://midday.ai (pre-launch) — dark fintech, Instrument Sans, neumorphic hero + email capture, no scroll required on desktop. Shows single-screen-no-scroll is viable when copy is tight enough.

## Existing templates surveyed
- https://www.framer.com/marketplace/templates/waitlister/ — clean but Framer-locked, no static export, no GH Pages deploy.
- https://supplystore.framer.website/template/waitlista — dark aesthetic, good vibes, Framer-only, paid.
- https://github.com/surjithctly/astroship — covers SaaS broadly; no waitlist-specific variant; too many sections for the use case.
- **Saturated pattern:** centered card + gradient blob + generic tagline + email input + "We'll let you know" microcopy. No countdown, no live counter, no referral hook, no founder signal.
- **Missing:** dark-default waitlist template in Astro/HTML that is GH Pages deployable, has a real countdown (JS, target date via config), shows a live signup counter (static JSON + build-time inject), and ships with Formspree/Buttondown env-var config out of the box.

## Must-have sections (in order)
1. **Full-bleed hero (above the fold, entire viewport)** — product name, one-line outcome tagline, email input + CTA button, live waitlist counter badge ("2,847 people waiting"), and a launch countdown clock. Nothing below the fold is required; this section must convert alone.
2. **One-paragraph "what is this"** — 2–3 sentences max. No bullets, no feature grid. Plain language. Shown on first scroll, not in the hero.
3. **Founder / team signal** — headshot(s), 1-line bio, notable credential (YC, prior exit, press mention). Answers "who's building this?"
4. **Social proof strip** — press logos OR named angels/backers OR "backed by" line. For a zero-user product: placeholder slots (e.g., "Backed by [Angel Name], ex-[Company]").
5. **Footer** — social links, email, legal (privacy policy link). No full nav.

## Design conventions
- **Typography:** Display-weight variable sans — **Geist** or **Cabinet Grotesk** for headline (tracking -0.04em, weight 700–800), Inter for body. No serif. No mono accent (that's already Day 1 and Day 2 territory). Single type family, two weights.
- **Color palette:** **Dark-default** (`#09090B` near-black base) with **one bold accent** — pick **electric lime / chartreuse** (`#BFFF00` or `#C8FF00`). Not violet (Day 2). Not amber (Day 1). Lime reads as "new, alive, launch energy" and is rare in template libraries. Text: `#FAFAFA` primary, `#71717A` secondary.
- **Imagery:** Zero stock photography. The hero is pure typography + form + countdown numbers. Optional: an abstract noise/grain texture overlay on the dark background (CSS, no image file) for tactile depth.
- **Density:** Intentionally sparse. One screen does all the conversion work. Subsequent sections are very short (one text block, one card row). Anti-bento, anti-feature-grid.

## Trust signals to include
- **Live waitlist counter** — static number injected at build time from `waitlist-count.json` in the repo; updated by the operator manually or via a CI webhook. Shows on hero badge.
- **Launch countdown** — JS `setInterval` against a `LAUNCH_DATE` env var / data attribute. Concrete date = credibility. Vague "coming soon" = not credible.
- **Founder card** — name, photo, one-sentence credential ("Previously at Stripe", "YC W23", "exited [Co] to [Acquirer]"). Humans trust humans.
- **Named backer / angel** — even one recognizable name with permission. Placeholder: "Backed by [Name], ex-[Co]".
- **Press logo(s)** — even a single TechCrunch / The Verge / HN front-page mention. Placeholder slot included in template.
- **Position confirmation** — after submit: "You're #3,041 on the list. Share to move up." (Confirmation page / inline state change.)

## SEO / schema.org
- **Type:** `WebSite` + `Organization`. Justification: the product has no shipping offer yet, so `SoftwareApplication` with `Offer` is premature and inaccurate. `Organization` covers the founding team's credibility signal; `WebSite` covers `potentialAction: SearchAction` and provides the `sameAs` social links. Add `description` and `foundingDate` on `Organization`. When product ships, builder upgrades to `SoftwareApplication`.
- **Required properties:** `Organization.name`, `Organization.url`, `Organization.description`, `Organization.foundingDate`, `Organization.sameAs[]` (Twitter/X, LinkedIn, GitHub). `WebSite.name`, `WebSite.url`.
- **Suggested OG image:** Product name in display-weight lime on near-black, tagline below in white, launch date badge bottom-right. Build-time generated via `satori` or a committed static PNG.

## Static-only fit
No concerns. All dynamic-feeling elements are achievable statically:
- **Countdown:** client-side JS from a `data-launch-date` attribute set at build time via env var — no SSR.
- **Waitlist counter:** `waitlist-count.json` committed to repo; operator bumps the number manually or via a GH Actions workflow that fetches from their email platform's API at build time.
- **Form submission:** HTTP POST to one of three supported providers, selected via env var `WAITLIST_PROVIDER`:
  - `formspree` → `https://formspree.io/f/{FORM_ID}` (free tier: 50 submissions/mo)
  - `buttondown` → `https://api.buttondown.email/v1/subscribers` (REST, free tier: 100 subscribers)
  - `convertkit` → `https://api.convertkit.com/v3/forms/{FORM_ID}/subscribe` (free tier: 10k subscribers)
- No SSR, no serverless function required. Provider is a one-line config change.

## Differentiation — what we'll do better
- **Day 2 contrast:** Dark-default (Day 2 is light-default), lime accent (Day 2 is violet/indigo), single-screen minimal (Day 2 is dense bento), no product UI mock (Day 2 hero is HTML/CSS dashboard mock), no pricing/features/FAQ.
- **Day 1 contrast:** No code/type focus, no amber, no prose density. Day 3 is visual-silence — the countdown and counter do the talking.
- **Countdown as visual anchor:** The four countdown blocks (DD / HH / MM / SS) are the largest typographic element after the product name — they replace an image entirely and create urgency that static pages never have.
- **Provider-agnostic form config:** One env var swaps Formspree / Buttondown / ConvertKit. No other free Astro/HTML waitlist template does this.
- **Honest pre-launch trust signals:** Founder card + backer line + counter — designed for zero-user products. No fake testimonials, no placeholder logos.
- **GH Pages one-click:** No Vercel, no Netlify required. Base path config included out of the box.
- **Accessibility:** Form label association, countdown `aria-live` region, high-contrast lime on near-black passes WCAG AA at display sizes.
