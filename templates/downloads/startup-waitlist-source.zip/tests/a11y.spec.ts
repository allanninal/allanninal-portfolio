import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES, setTheme } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`a11y: ${route} (${theme}) — zero violations`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);
      // Let the 0.2s theme color-transition settle before axe samples colors,
      // otherwise it can catch an intermediate (still-fading) value and report
      // a spurious color-contrast violation under worker contention.
      await page.waitForTimeout(300);

      // Wait for countdown to populate so the aria-live region has content.
      // The countdown only exists on the home page; /vision/ has no #cd-days,
      // so scope the wait to '/' (and bound it) to avoid a 30s hang elsewhere.
      if (route === '/') {
        await page.waitForFunction(() => {
          const el = document.getElementById('cd-days');
          return el && el.textContent !== '--';
        }, undefined, { timeout: 5000 }).catch(() => { /* countdown may have passed — that's fine */ });
      }

      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .analyze();

      // Report violations in a readable format
      const violations = results.violations.map((v) => ({
        id: v.id,
        impact: v.impact,
        description: v.description,
        nodes: v.nodes.length,
        help: v.helpUrl,
      }));

      expect(
        violations,
        `Axe violations on ${route} (${theme}):\n${JSON.stringify(violations, null, 2)}`
      ).toEqual([]);
    });
  }
}
