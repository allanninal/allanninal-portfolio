import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

// ── No horizontal scroll at any viewport ─────────────────────────────────────

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}x${vp.height}) has no horizontal scroll`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await page.locator('h1').first().waitFor();

      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(overflow).toBe(false);
    });
  }
}

// ── Single-screen hero: all conversion elements visible without scroll ────────
// This is the NON-NEGOTIABLE spec: on 1280x720, everything fits above the fold.

test('hero: all conversion elements visible without scroll at 1280x720', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.goto('/');

  // Wait for countdown to populate
  await page.waitForFunction(() => {
    const el = document.getElementById('cd-days');
    return el && el.textContent !== '--';
  });

  // Product name
  await expect(page.locator('h1').first()).toBeInViewport();

  // Email input
  await expect(page.locator('#email-input')).toBeInViewport();

  // CTA button
  await expect(page.getByRole('button', { name: /join the waitlist/i })).toBeInViewport();

  // Counter badge
  await expect(page.locator('#counter-display')).toBeInViewport();

  // Countdown wrapper
  await expect(page.locator('#countdown-wrapper')).toBeInViewport();
});

// ── Additional key viewports for single-screen check ─────────────────────────

for (const vp of [
  { name: '1440x900',  width: 1440, height: 900 },
  { name: '1920x1080', width: 1920, height: 1080 },
]) {
  test(`hero conversion elements visible without scroll at ${vp.name}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.goto('/');
    await page.waitForFunction(() => {
      const el = document.getElementById('cd-days');
      return el && el.textContent !== '--';
    });
    await expect(page.locator('h1').first()).toBeInViewport();
    await expect(page.locator('#email-input')).toBeInViewport();
    await expect(page.getByRole('button', { name: /join the waitlist/i })).toBeInViewport();
  });
}

// ── Mobile (375x667): no horizontal overflow, form stacks correctly ───────────

test('mobile 375x667: content stacks without overflow', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  await page.locator('h1').first().waitFor();

  // No horizontal overflow
  const overflow = await page.evaluate(() =>
    document.documentElement.scrollWidth > document.documentElement.clientWidth
  );
  expect(overflow).toBe(false);

  // Form elements are present and visible
  await expect(page.locator('#email-input')).toBeVisible();
  await expect(page.getByRole('button', { name: /join the waitlist/i })).toBeVisible();
});

// ── Tap target sizes ──────────────────────────────────────────────────────────

test('CTA button meets 44px minimum tap target height', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');

  const btn = page.getByRole('button', { name: /join the waitlist/i });
  const box = await btn.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.height).toBeGreaterThanOrEqual(44);
  expect(box!.width).toBeGreaterThanOrEqual(44);
});
