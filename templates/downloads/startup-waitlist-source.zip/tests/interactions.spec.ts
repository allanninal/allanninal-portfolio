import { test, expect } from '@playwright/test';

// ── Theme toggle ─────────────────────────────────────────────────────────────

test('theme toggle swaps dark/light class and persists across reload', async ({ page }) => {
  await page.goto('/');

  // Default is dark — html should have class 'dark'
  const initialDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark')
  );
  expect(initialDark).toBe(true);

  // Click the toggle — should switch to light
  await page.getByRole('button', { name: /toggle theme/i }).click();

  const afterLight = await page.evaluate(() =>
    document.documentElement.classList.contains('light')
  );
  expect(afterLight).toBe(true);

  const stored = await page.evaluate(() => localStorage.getItem('theme'));
  expect(stored).toBe('light');

  const dataTheme = await page.evaluate(() => document.documentElement.dataset.theme);
  expect(dataTheme).toBe('light');

  // Reload — should persist
  await page.reload();
  const reloadedTheme = await page.evaluate(() => document.documentElement.dataset.theme);
  expect(reloadedTheme).toBe('light');
});

test('theme toggle back to dark from light', async ({ page }) => {
  // Start in light
  await page.goto('/');
  await page.evaluate(() => {
    document.documentElement.classList.remove('dark');
    document.documentElement.classList.add('light');
    document.documentElement.dataset.theme = 'light';
    localStorage.setItem('theme', 'light');
  });

  await page.getByRole('button', { name: /toggle theme/i }).click();

  const nowDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark')
  );
  expect(nowDark).toBe(true);
  expect(await page.evaluate(() => localStorage.getItem('theme'))).toBe('dark');
});

// ── Waitlist form ─────────────────────────────────────────────────────────────

test('waitlist form shows error on empty submit', async ({ page }) => {
  await page.goto('/');

  // Submit without filling in email
  await page.evaluate(() => {
    const input = document.getElementById('email-input') as HTMLInputElement;
    if (input) input.value = '';
  });

  await page.getByRole('button', { name: /join the waitlist/i }).click();

  const errMsg = page.locator('#form-error');
  await expect(errMsg).toBeVisible();
  await expect(errMsg).toHaveText(/valid email/i);
});

test('waitlist form shows error on invalid email', async ({ page }) => {
  await page.goto('/');

  await page.locator('#email-input').fill('notanemail');
  await page.getByRole('button', { name: /join the waitlist/i }).click();

  await expect(page.locator('#form-error')).toBeVisible();
});

test('waitlist form clears error when user types valid email', async ({ page }) => {
  await page.goto('/');

  // Trigger error first
  await page.getByRole('button', { name: /join the waitlist/i }).click();
  await expect(page.locator('#form-error')).toBeVisible();

  // Type a valid email — error should clear
  await page.locator('#email-input').fill('valid@example.com');
  await page.locator('#email-input').dispatchEvent('input');
  await expect(page.locator('#form-error')).toBeHidden();
});

test('waitlist form shows success state on valid demo submit', async ({ page }) => {
  // Route formspree requests so the form doesn't navigate away
  await page.route('**/formspree.io/**', (route) =>
    route.fulfill({ status: 200, body: '{}', headers: { 'Content-Type': 'application/json' } })
  );

  await page.goto('/');

  // Fill a valid email
  await page.locator('#email-input').fill('tester@example.com');

  // Submit via the button click
  await page.getByRole('button', { name: /join the waitlist/i }).click();

  // The demo JS intercepts (placeholder formspree ID), hides the form, shows success
  // Success element is now outside the form so it stays visible
  await expect(page.locator('#form-success')).toBeVisible({ timeout: 5000 });
});

test('waitlist form has correct action attribute', async ({ page }) => {
  await page.goto('/');
  const action = await page.locator('#waitlist-form').getAttribute('action');
  // Default provider is formspree — action should contain formspree.io
  expect(action).toContain('formspree.io');
});

test('waitlist form has correct method attribute', async ({ page }) => {
  await page.goto('/');
  const method = await page.locator('#waitlist-form').getAttribute('method');
  expect(method?.toLowerCase()).toBe('post');
});

test('waitlist email input has correct type and autocomplete', async ({ page }) => {
  await page.goto('/');
  const input = page.locator('#email-input');
  expect(await input.getAttribute('type')).toBe('email');
  expect(await input.getAttribute('autocomplete')).toBe('email');
  expect(await input.getAttribute('autocapitalize')).toBe('off');
});

test('waitlist email label is associated with input', async ({ page }) => {
  await page.goto('/');
  // The label[for="email-input"] must exist
  const label = page.locator('label[for="email-input"]');
  await expect(label).toBeAttached();
});

// ── Donate button ─────────────────────────────────────────────────────────────

test('footer donate link points to ko-fi when env var is set', async ({ page }) => {
  await page.goto('/');
  // The default env in playwright config sets PUBLIC_AUTHOR_DONATE_URL via
  // the build. The built demo has it baked in.
  const donateLink = page.locator('[data-donate-url]').first();
  // Only assert if it exists (env may not be set in all builds)
  const count = await donateLink.count();
  if (count > 0) {
    const href = await donateLink.getAttribute('href');
    expect(href).toBeTruthy();
    expect(href).toContain('ko-fi.com');
  }
});

// ── Countdown ─────────────────────────────────────────────────────────────────

test('countdown renders four blocks with numeric values', async ({ page }) => {
  await page.goto('/');

  const days  = page.locator('#cd-days');
  const hours = page.locator('#cd-hours');
  const mins  = page.locator('#cd-mins');
  const secs  = page.locator('#cd-secs');

  await expect(days).toBeVisible();
  await expect(hours).toBeVisible();
  await expect(mins).toBeVisible();
  await expect(secs).toBeVisible();

  // All should show numeric content (not "--" after JS runs)
  await page.waitForFunction(() => {
    const el = document.getElementById('cd-days');
    return el && el.textContent !== '--';
  });

  const daysText = await days.textContent();
  // Days can be 1-3 digits depending on how far away the launch date is
  expect(daysText).toMatch(/^\d+$/);
});

test('countdown ticks — seconds change within 3 seconds', async ({ page }) => {
  await page.goto('/');

  // Wait for countdown to initialize
  await page.waitForFunction(() => {
    const el = document.getElementById('cd-secs');
    return el && el.textContent !== '--';
  });

  const sec1 = await page.locator('#cd-secs').textContent();
  await page.waitForTimeout(2100);
  const sec2 = await page.locator('#cd-secs').textContent();

  // Seconds should have changed (or rolled over)
  expect(sec1).not.toBe(sec2);
});

test('countdown wrapper has aria-live attribute', async ({ page }) => {
  await page.goto('/');
  const wrapper = page.locator('#countdown-wrapper');
  expect(await wrapper.getAttribute('aria-live')).toBe('polite');
});

// ── Waitlist counter ──────────────────────────────────────────────────────────

test('waitlist counter badge renders formatted count', async ({ page }) => {
  await page.goto('/');
  const badge = page.locator('#counter-display');
  await expect(badge).toBeVisible();
  const text = await badge.textContent();
  // Should contain a formatted number like "2,847"
  expect(text).toMatch(/\d{1,3}(,\d{3})* people waiting/);
});
