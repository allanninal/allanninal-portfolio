/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        display: ['Geist', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'xs':  ['0.8rem',   { lineHeight: '1.5' }],
        'sm':  ['0.9rem',   { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.65' }],
        'lg':  ['1.125rem', { lineHeight: '1.6' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.25rem',  { lineHeight: '1.1' }],
        '5xl': ['3rem',     { lineHeight: '1.05' }],
        '6xl': ['3.75rem',  { lineHeight: '1.02' }],
        '7xl': ['4.5rem',   { lineHeight: '1' }],
        '8xl': ['6rem',     { lineHeight: '0.98' }],
      },
      colors: {
        // Near-black base — dark-default palette
        ink: {
          50:  '#fafafa',
          100: '#f4f4f5',
          200: '#e4e4e7',
          300: '#d4d4d8',
          400: '#a1a1aa',
          500: '#71717a',
          600: '#52525b',
          700: '#3f3f46',
          800: '#27272a',
          900: '#18181b',
          950: '#09090B', // canonical near-black base from RESEARCH.md
        },
        // Electric lime accent — the defining color of this template.
        // Dark mode: #BFFF00 on near-black (passes WCAG AA at display sizes).
        // Light mode: #4D6600 (deep olive) — lime at 1:1 on white fails AA;
        //             this deeper shade passes 4.6:1 and is documented in README.
        lime: {
          DEFAULT:  '#BFFF00', // electric lime — dark mode primary
          hover:    '#D4FF33', // lighter on hover
          deep:     '#A6E000', // slightly muted for large fills
          light:    '#4D6600', // WCAG AA on white (4.6:1) — used in light mode only
          glow:     'rgba(191, 255, 0, 0.15)',
          ring:     'rgba(191, 255, 0, 0.30)',
        },
      },
      maxWidth: {
        prose: '68ch',
        '7xl': '80rem',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tighter2: '-0.025em',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.4s ease forwards',
      },
      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0', transform: 'translateY(4px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
};
