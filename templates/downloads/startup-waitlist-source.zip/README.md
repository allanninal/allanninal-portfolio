# startup-waitlist

A free, MIT-licensed pre-launch email capture template for software, AI, and hardware startups. Built with Astro 4 + Tailwind CSS.

**Dark-default. Electric lime accent. Zero lorem ipsum.**

![Preview](./preview.png)

**Live demo:** [templates.allanninal.dev/startup-waitlist/](https://templates.allanninal.dev/startup-waitlist/)

---

## Features

- **Single-screen hero** — product name, tagline, email form, waitlist counter badge, and live countdown all fit above the fold at 1280x720. No scrolling required to convert.
- **Live countdown clock** — client-side JS, ticks every second, target date from `PUBLIC_LAUNCH_DATE` env var. Shows DD / HH / MM / SS with `aria-live="polite"`. Swaps to a "We're live →" CTA when the date passes.
- **Waitlist counter** — build-time injection from `src/data/waitlist-count.json`. Update the number and redeploy. Displays formatted (e.g. "2,847 people waiting").
- **Provider-agnostic form** — one env var (`PUBLIC_WAITLIST_PROVIDER`) selects Formspree, Buttondown, or ConvertKit. No backend required.
- **Dark-default theme** — `#09090B` near-black base, electric lime `#BFFF00` accent. Theme toggle persists via `localStorage`. Light mode uses a deep olive accent (`#4D6600`) that passes WCAG AA on white.
- **Below-fold sections** — "What is this" paragraph, founder card with avatar, backer/angel line.
- **SEO** — `WebSite` + `Organization` schema.org JSON-LD, OG/Twitter cards, sitemap, robots.txt, canonical URLs.
- **GitHub Pages one-click** — base path resolved from `GITHUB_REPOSITORY` env var automatically.
- **Full test suite** — 41 Playwright tests: page rendering, single-screen spec, countdown ticking, form validation, theme toggle, responsive (4 viewports), axe-clean a11y (both themes), Lighthouse ≥ 95.

## Stack

- **Framework:** Astro 4 (static output)
- **Styles:** Tailwind CSS (class-based dark mode), CSS custom properties for theming
- **Fonts:** Geist (display, self-hosted via @fontsource) + Inter (body)
- **Forms:** Formspree / Buttondown / ConvertKit (configurable via env)
- **Testing:** Playwright, @axe-core/playwright, Lighthouse CI, linkinator

## Quick start

```bash
# 1. Download from templates.allanninal.dev/startup-waitlist/ and unzip, or
#    use the source ZIP to get the full Astro project.

# 2. Install dependencies
npm install

# 3. Copy env file and fill in your values
cp .env.example .env

# 4. Start the dev server
npm run dev

# 5. Build for production
npm run build

# 6. Preview the production build locally
npm run preview
```

## Customize

### Product name, tagline, description

Edit `src/data/site.ts`. This is the single source of truth:

```ts
product: {
  name: 'Nexus',
  tagline: 'The AI workspace that thinks with you.',
  description: '...',
}
```

### Launch date

Set `PUBLIC_LAUNCH_DATE` in `.env` (ISO 8601, UTC):

```bash
PUBLIC_LAUNCH_DATE=2026-09-01T12:00:00Z
```

The countdown clock reads this value at build time and bakes it into the page as a `data-launch-date` attribute. Change the date and redeploy.

### Waitlist counter

Edit `src/data/waitlist-count.json`:

```json
{ "count": 2847 }
```

Rebuild and redeploy. You can automate this with a GitHub Actions step that fetches the subscriber count from your email platform's API before each build.

### Form provider

Set `PUBLIC_WAITLIST_PROVIDER` in `.env` to one of:

| Provider | Free tier | Setup |
|---|---|---|
| `formspree` | 50 submissions / mo | Get a form ID at [formspree.io](https://formspree.io). Set `PUBLIC_FORMSPREE_ID=your-id`. |
| `buttondown` | 100 subscribers | Set `PUBLIC_BUTTONDOWN_USERNAME=your-username`. |
| `convertkit` | 10,000 subscribers | Set `PUBLIC_CONVERTKIT_FORM_ID=your-form-id`. |

The form `action` and `method` are set at build time from these env vars. No code changes needed to switch providers.

### Founder card

Edit `src/data/site.ts`:

```ts
founder: {
  name: 'Your Name',
  role: 'Founder & CEO',
  credential: 'Previously at Stripe · YC W24',
  photoSrc: '/images/founder.jpg', // leave blank for CSS monogram avatar
  photoAlt: 'Your Name, Founder',
  linkedin: 'https://linkedin.com/in/yourhandle',
  x: 'https://x.com/yourhandle',
}
```

Place your headshot in `public/images/` and set `photoSrc` to the path.

### Accent color

The lime accent is defined as CSS variables in `src/styles/global.css`:

```css
:root {
  --color-accent: #BFFF00;       /* dark mode — electric lime */
}
html.light {
  --color-accent: #4D6600;       /* light mode — deep olive, passes WCAG AA */
}
```

If you change the dark mode accent, verify it passes WCAG AA at your target sizes against `#09090B`. A contrast checker: [webaim.org/resources/contrastchecker](https://webaim.org/resources/contrastchecker/).

### Social links and contact

Edit the `socials` and `contactEmail` fields in `src/data/site.ts`. LinkedIn is listed first in the footer per best-practice for founders.

### Fonts

Font imports are in `src/styles/global.css`. To swap Geist for another display font, install via `@fontsource/<font-name>` and update the import and `font-family` values.

---

## Deploy to GitHub Pages (3 steps)

> The source repo is private — there is no Fork button. Download the source ZIP from [templates.allanninal.dev/startup-waitlist/](https://templates.allanninal.dev/startup-waitlist/) and follow these steps.

1. **Unzip** the source into a new folder and initialize a Git repo:

   ```bash
   unzip startup-waitlist-source.zip -d my-waitlist
   cd my-waitlist
   git init
   git add .
   git commit -m "init from startup-waitlist template"
   ```

2. **Push** to a new GitHub repository (create one at github.com/new):

   ```bash
   git remote add origin https://github.com/<you>/<your-repo>.git
   git push -u origin main
   ```

3. **Enable Pages:** Go to **Settings → Pages → Source: GitHub Actions**. The included `pages.yml` workflow builds and deploys automatically on every push to `main`.

Your site will be live at `https://<you>.github.io/<your-repo>/`.

### Custom domain

1. Add a `CNAME` file in `public/` with your domain.
2. Set two repo variables (Settings → Variables → Actions):
   - `PUBLIC_SITE_URL` = `https://your-domain.com`
   - `PUBLIC_BASE_PATH` = `/`
3. Push to trigger a redeploy.

---

## Alternate deploys

### Vercel

```bash
npm install -g vercel
vercel --prod
```

Set `PUBLIC_SITE_URL` and `PUBLIC_BASE_PATH=/` in the Vercel project environment variables.

### Netlify

Drag the `dist/` folder to [app.netlify.com](https://app.netlify.com/drop), or connect the repo. Set the build command to `npm run build` and publish directory to `dist/`.

### Cloudflare Pages

Connect your repo in Cloudflare Pages. Build command: `npm run build`. Output directory: `dist/`.

---

## Testing

### Run all tests

```bash
npm run test:all
# Equivalent to:
npm run build && npm run test && npm run test:links && npm run test:lighthouse
```

### Individual suites

```bash
npm run test           # All Playwright tests (41 tests)
npm run test:a11y      # Axe accessibility only
npm run test:links     # Linkinator crawl (zero broken links)
npm run test:lighthouse # Lighthouse CI (≥95 all four categories)
npm run test:ui        # Playwright UI mode (interactive debugging)
```

### What each suite covers

| File | What it tests |
|---|---|
| `tests/pages.spec.ts` | Home page renders with h1, footer, no console errors; meta/OG/canonical; sitemap; robots.txt; JSON-LD schema |
| `tests/interactions.spec.ts` | Theme toggle (persists across reload); form validation (empty, invalid, valid); form success state; form action/method attrs; email input type/autocomplete; countdown (4 blocks, ticks, aria-live); waitlist counter format; donate button URL |
| `tests/responsive.spec.ts` | No horizontal scroll at 375/768/1280/1920px; single-screen spec at 1280×720, 1440×900, 1920×1080 (all conversion elements in viewport); mobile content stacking; CTA button ≥44px tap target |
| `tests/theme.spec.ts` | Light and dark render correctly; dark-default on fresh load; toggle changes class and data-theme attribute |
| `tests/a11y.spec.ts` | Zero axe violations on every route in both light and dark themes |
| `tests/links.spec.ts` | No broken internal links; external links have `rel="noopener noreferrer"`; hash anchors point to real IDs |

### Adding a test when you add a page or interaction

- New **page** (`src/pages/foo.astro`): add a route `/foo` to `ROUTES` in `tests/helpers.ts`, and add a test block in `tests/pages.spec.ts`.
- New **interactive element**: add a test in `tests/interactions.spec.ts`.
- New **viewport** to verify: add to `VIEWPORTS` in `tests/helpers.ts`.

---

## Support and donations

This template is **free and MIT-licensed**. Use it for personal, commercial, or client work — no permission or attribution required.

If it saved you time, a small tip keeps this project going:
[**Ko-fi — ko-fi.com/allanninal**](https://ko-fi.com/allanninal)

### For cloning users

- The GitHub "Sponsor" button on your fork is driven by `.github/FUNDING.yml`. Edit `ko_fi: allanninal` to point at your own handle, or delete the file to hide the button.
- The small footer "Support the maker" Ko-fi link is driven by `PUBLIC_AUTHOR_DONATE_URL` in `.env`. Set it blank to hide it.
- To add your own prominent donate button (e.g. for a non-profit project), set `PUBLIC_USER_DONATE_URL` in `.env`.
- Both donate buttons are in `src/components/DonateButton.astro`.

---

## License

MIT — see [LICENSE](./LICENSE).

Part of the [365-template series](https://templates.allanninal.dev/) — Day 3 of 365 free, MIT-licensed static website templates.
