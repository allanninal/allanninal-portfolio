import { test, expect } from '@playwright/test';

test.describe('Ferrous & Pale — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Ferrous & Pale/);
    await expect(page.locator('h1')).toContainText('does not exist');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The stack ───────────────────────────────────────────────────────────
  // The headline number must be the sum of the passes, or the page is a claim
  // rather than a demonstration.
  test('the exposure count is summed from the passes', async ({ page }) => {
    await page.goto('/');
    const counts = (await page.locator('#stack .pass-x').allTextContents())
      .map((s) => Number(s.replace(/[^0-9]/g, '')));
    expect(counts.length).toBeGreaterThan(5);
    const total = counts.reduce((a, b) => a + b, 0);
    await expect(page.locator('h1 ~ p.figure-lead').first()).toContainText(`It is ${total} exposures`);
    await expect(page.locator('#stack .figure-lead'))
      .toContainText(`${counts.length} passes, ${total} exposures`);
    // And the caption on the same image must agree.
    await expect(page.locator('#stack .stack-final figcaption')).toContainText(`${total} exposures`);
  });

  test('the named largest pass really is the largest', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#stack li.pass').evaluateAll((els) =>
      els.map((e) => ({
        name: e.querySelector('.pass-name')?.textContent?.trim().toLowerCase(),
        n: Number((e.querySelector('.pass-x')?.textContent || '').replace(/[^0-9]/g, '')),
      })));
    const max = rows.reduce((a, b) => (a.n > b.n ? a : b));
    await expect(page.locator('#stack .figure-lead'))
      .toContainText(`largest is the ${max.name} at ${max.n}`);
  });

  test('passes are an ordered list, because they are shot in order', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#stack ol.passes > li.pass').count()).toBe(9);
    const ns = (await page.locator('#stack .pass-n').allTextContents()).map((s) => Number(s));
    expect(ns).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });

  // The distinction the page rests on.
  test('it states plainly that the product is not altered', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#stack')).toContainText(/Nothing about the product is altered/i);
    await expect(page.locator('#faq')).toContainText(/same object on the same table/i);
  });

  test('hero and packshot are priced as different products', async ({ page }) => {
    await page.goto('/');
    const kinds = page.locator('#two article.kind');
    expect(await kinds.count()).toBe(2);
    await expect(kinds.nth(0)).toContainText('Hero');
    await expect(kinds.nth(1)).toContainText('Packshot');
    await expect(kinds.nth(0)).toContainText('per image');
    await expect(kinds.nth(1)).toContainText('per SKU');
  });

  test('every image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('img').evaluateAll((els) =>
      els.filter((e) => (e.getAttribute('src') || '').includes('images/passes/'))
         .map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })));
    expect(imgs.length).toBeGreaterThanOrEqual(4);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.w).toBeTruthy();
      expect(i.h).toBeTruthy();
    }
  });

  test('all images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('work is captioned with its build cost', async ({ page }) => {
    await page.goto('/');
    const caps = await page.locator('#work figcaption').allTextContents();
    expect(caps.length).toBe(4);
    for (const c of caps) expect(c).toMatch(/exposures?/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the brief form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-95 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['bramble', 'louisville', 'gelato', 'shot clock', 'goulash']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro build sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/build-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
