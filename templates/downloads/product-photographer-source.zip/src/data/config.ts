// Ferrous & Pale — Cleveland, OH.
//
// Sixth photography template, sixth axis: how the picture is made. Day 93
// already took licensing, so this one takes the build — a product hero is a
// composite of dozens of exposures and almost nobody outside the trade knows.

export const site = {
  name:        'Ferrous & Pale',
  shortName:   'Ferrous & Pale',
  title:       'Ferrous & Pale — Product Photography in Cleveland, OH',
  tagline:     'This photograph does not exist.',
  owner:       'Ingrid Falk',
  ownerRole:   'Still-life photographer',
  credential:  'Hero stills and volume packshots · Cleveland',
  license:     'Still-life studio, working since 2018',
  city:        'Cleveland',
  state:       'OH',
  language:    'en',
  phoneDisplay: '(216) 555-0159',
  phoneHref:   '+12165550159',
  email:       'studio@ferrousandpale.example',
  streetAddress: '3110 Detroit Ave',
  postalCode:  '44113',
  hours:       'Studio Mon–Fri · hero days and packshot days are booked separately',
  bookingWindow: 'Hero work booking four weeks out. Packshot slots most weeks.',
  description:
    'A still-life studio in Cleveland. A product hero is not one photograph — it is a ' +
    'stack of exposures blended into one frame, and this page takes one apart pass by ' +
    'pass so you can see what four hours actually buys.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The stack',   href: '#stack' },
  { label: 'Two products', href: '#two' },
  { label: 'Work',        href: '#work' },
  { label: 'Rates',       href: '#rates' },
  { label: 'Brief',       href: '#brief' },
];

// ── The stack ─────────────────────────────────────────────────────────────
// `frames` is the number of exposures each pass takes. The headline sums them.

export const stack = {
  subject: 'Glass dispenser, chrome pump, white fill',
  file: 'p01.jpg',
  alt: 'A frosted glass soap dispenser with a chrome pump, filled with white liquid',
  passes: [
    { name: 'Background',      frames: 1,  why: 'Shot empty, first, so the sweep is clean before anything is placed on it.' },
    { name: 'Focus stack',     frames: 14, why: 'Fourteen slices from the nearest edge of the glass to the back of the pump. No single aperture holds all of it.' },
    { name: 'Key light',       frames: 3,  why: 'A large source through diffusion. Three heights, because the one that flatters the glass flattens the chrome.' },
    { name: 'Fill',            frames: 2,  why: 'A white card bounce, and the same frame without it. The blend decides how dark the shadow side goes.' },
    { name: 'Rim',             frames: 4,  why: 'Strips either side to draw the edge of the bottle out of the background. Four positions, one kept.' },
    { name: 'Chrome pass',     frames: 5,  why: 'The pump reflects the room, so the room is built one card at a time and photographed as it goes.' },
    { name: 'Liquid and fill line', frames: 2, why: 'The white fill photographs flat under the key. It gets its own light and is blended back.' },
    { name: 'Reflection',      frames: 2,  why: 'The surface reflection, shot separately so its strength is a decision rather than an accident.' },
    { name: 'Shadow',          frames: 1,  why: 'A single hard source with everything else off. Contact shadow is what stops the object floating.' },
  ],
  note:
    'Nothing about the product is altered in any of that. Every pass is the same bottle on ' +
    'the same table; what changes is which light is on. The blend is how you get an object ' +
    'sharp front to back and correctly lit on glass, chrome and matte at once, which no ' +
    'single exposure can do.',
};

// ── Two products ──────────────────────────────────────────────────────────

export const two = [
  {
    kind: 'Hero', big: '4 hours', per: 'per image',
    rows: [
      ['Exposures', 'Thirty to forty, blended'],
      ['Per day', 'Two, sometimes three'],
      ['Used for', 'Campaign, packaging, the top of a landing page'],
      ['Rate', '$1,400 per image'],
    ],
    note: 'Priced per image because that is what it is — one image, built.',
  },
  {
    kind: 'Packshot', big: '9 minutes', per: 'per SKU',
    rows: [
      ['Exposures', 'One, occasionally a three-slice stack'],
      ['Per day', 'Fifty to sixty'],
      ['Used for', 'E-commerce grids, marketplace listings, catalogues'],
      ['Rate', '$2,400 per day, up to 55 SKUs'],
    ],
    note: 'Priced per day because the set never changes. The whole point is that it does not.',
  },
];

export const twoNote =
  'These are different products with different machinery, and the common expensive mistake ' +
  'is buying one when you needed the other. Hero-grade work for an e-commerce grid is money ' +
  'spent on a thumbnail; packshot work at the top of a campaign page looks like what it is.';

// ── Work ──────────────────────────────────────────────────────────────────
// Alt strings written from the files.

export const work = [
  { file: 'p01.jpg', cap: 'Hero · 34 exposures',
    alt: 'A frosted glass soap dispenser with a chrome pump, filled with white liquid' },
  { file: 'p02.jpg', cap: 'Hero · 21 exposures',
    alt: 'A lavender soap bar with moulded lettering and flecks of dried flower, on white' },
  { file: 'p03.jpg', cap: 'Hero · 28 exposures',
    alt: 'A small glass bottle of golden oil with white blossom behind it' },
  { file: 'p04.jpg', cap: 'Packshot · 1 exposure',
    alt: 'A stack of pale handmade soap bars arranged on a white surface' },
];

export const rates = {
  rows: [
    { what: 'Hero image',              figure: '$1,400', note: 'Per image. Two to three a day is the honest ceiling.' },
    { what: 'Packshot day',            figure: '$2,400', note: 'Up to 55 SKUs on a fixed set.' },
    { what: 'Additional angle, packshot', figure: '$14',  note: 'Per SKU. Cheap because the set is already built.' },
    { what: 'Ghost mannequin / cut-out', figure: '$26',  note: 'Per SKU, including the composite.' },
    { what: 'Retouch beyond the build', figure: '$95',   note: 'Per hour. The build itself is in the image price.' },
    { what: 'Licence',                 figure: 'Included', note: 'Perpetual for your own channels and listings. Paid media quoted separately.' },
  ],
  supply: [
    'Send the actual product, not a prototype. A hero built on a sample that changes is a hero shot twice.',
    'Two of everything reflective. Fingerprints on chrome are a retouching bill you can avoid for the price of a second unit.',
    'Say which face is the front before the day, in writing. It is the single most common reshoot.',
    'For packshots, a spreadsheet with the SKU codes in shooting order. Naming 55 files afterwards from memory is nobody’s idea of a day.',
  ],
};

export const faqs = [
  {
    q: 'Is compositing the same as faking it?',
    a: 'No, and the difference is worth stating. Nothing about the product changes — every pass is the same object on the same table, and only the lighting differs. It is how you get glass, chrome and matte all correct in one frame, which one exposure cannot do.',
  },
  {
    q: 'Why is a hero image more than a day rate divided by twelve?',
    a: 'Because two or three is what a day holds. Thirty-odd exposures, a set built one card at a time, and a blend that takes as long as the shooting did. The arithmetic is on this page rather than behind a quote.',
  },
  {
    q: 'Can you do hero quality at packshot prices?',
    a: 'No, and you almost never need to. A product grid at 400 pixels does not show what a hero build buys. Spend the hero budget on the four images people actually look at.',
  },
  {
    q: 'Do you need the physical product?',
    a: 'Always, and the real one. Renders are a different service and a different studio. If the packaging is not final, wait — a hero built on a sample that changes gets built twice.',
  },
  {
    q: 'What about white backgrounds for marketplaces?',
    a: 'That is packshot work and we shoot to the marketplace spec, including the pure-white requirement and the margin rules. Ask for the spec name and we will match it exactly.',
  },
  {
    q: 'Who owns the files?',
    a: 'You get a perpetual licence for your own channels and listings, included. Copyright stays here unless assigned in writing, which is the standard everywhere and is worth knowing rather than discovering.',
  },
];
