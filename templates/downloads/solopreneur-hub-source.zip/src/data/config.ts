export const maker = {
  name: 'Devin Cole',
  handle: '@allanninal',
  role: 'Solopreneur & Full-Stack Builder',
  tagline: 'I build products solo — from idea to revenue.',
  bio: "I'm a full-stack developer who ships SaaS products, developer tools, and digital resources on my own. No investors, no team — just fast iteration, direct customer relationships, and compounding revenue.",
  bioLong: "After years in product engineering, I started building solo. The freedom to pick problems, ship fast, and own 100% of the outcome is hard to give up. Today I run multiple products that generate recurring revenue — and I document everything publicly.",
  location: 'Remote (PH)',
  avatar: '',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  email: 'hello@devincole.com',
  kofi: 'https://ko-fi.com/allanninal',
};

export const site = {
  title: 'Devin Cole — Solopreneur Hub',
  description: 'Builder of indie SaaS products, developer tools, and digital resources. Public revenue dashboard, active projects, newsletter, and contact.',
  url: 'https://www.allanninal.dev/templates/solopreneur-hub/',
  ogImage: '/og-image.png',
  language: 'en',
};

export type ProjectStatus = 'live' | 'building' | 'paused';

export type Project = {
  name: string;
  tagline: string;
  description: string;
  status: ProjectStatus;
  url: string;
  tags: string[];
  mrr?: number;   // monthly recurring revenue in USD
  users?: number;
  launchedAt?: string;
};

export const projects: Project[] = [
  {
    name: 'DevToolkit Pro',
    tagline: 'The Swiss-army knife for backend developers',
    description: 'A collection of 40+ CLI tools and browser utilities for backend devs — JSON formatters, regex testers, cron builders, JWT decoders, and more. Self-hostable, privacy-first.',
    status: 'live',
    url: '#',
    tags: ['Developer Tools', 'SaaS'],
    mrr: 2840,
    users: 1200,
    launchedAt: '2024-03',
  },
  {
    name: 'SoloLaunch',
    tagline: 'Ship your SaaS in 72 hours, not 72 days',
    description: "An Astro + Supabase + Stripe starter kit pre-wired with auth, billing, email, and a polished landing page. Every solopreneur's shortcut to revenue.",
    status: 'live',
    url: '#',
    tags: ['Boilerplate', 'SaaS'],
    mrr: 1180,
    users: 340,
    launchedAt: '2024-08',
  },
  {
    name: 'MicroDoc',
    tagline: 'Lightweight docs for micro-SaaS products',
    description: 'Publish beautiful product documentation from a single Markdown folder. Instant search, versioning, custom domain — no CMS needed.',
    status: 'building',
    url: '#',
    tags: ['Developer Tools', 'Documentation'],
    launchedAt: '2025-01',
  },
  {
    name: 'RetroMetrics',
    tagline: 'Public revenue tracker for indie makers',
    description: 'A public dashboard template for sharing MRR, churn, and subscriber growth in real-time. Builds trust and accountability with your audience.',
    status: 'paused',
    url: '#',
    tags: ['Analytics', 'Open Source'],
    launchedAt: '2023-11',
  },
];

export type RevenueMetric = {
  label: string;
  value: string;
  sublabel?: string;
  trend?: 'up' | 'down' | 'flat';
};

export const revenueMetrics: RevenueMetric[] = [
  { label: 'MRR',        value: '$4,020',   sublabel: '+18% last 30d',  trend: 'up' },
  { label: 'ARR Run Rate', value: '$48,240', sublabel: 'across 2 products', trend: 'up' },
  { label: 'Active Users', value: '1,540',   sublabel: 'paying customers', trend: 'up' },
  { label: 'Churn Rate',  value: '2.1%',    sublabel: 'last 90d avg',   trend: 'flat' },
];

// ─────────────────────────────────────────────────────────────────────────
// Pro edition data — drives the standalone /build-log/ build-in-public report.
// Free edition redirects /build-log/ → /#revenue, so this is unused there.
// ─────────────────────────────────────────────────────────────────────────

export type BuildLogEntry = {
  month: string;        // e.g. 'Jan 2025'
  mrr: number;          // combined MRR at month end, USD
  delta: number;        // change vs previous month, USD (can be negative)
  note: string;         // the one thing that defined the month
};

// Most-recent month first.
export const buildLog: BuildLogEntry[] = [
  { month: 'Jun 2025', mrr: 4020, delta: 610, note: 'SoloLaunch crossed 340 customers after a Product Hunt feature. Best month yet.' },
  { month: 'May 2025', mrr: 3410, delta: 180, note: 'Shipped MicroDoc private beta to 20 SoloLaunch customers; no revenue yet but strong signal.' },
  { month: 'Apr 2025', mrr: 3230, delta: -90,  note: 'Churned two annual DevToolkit accounts. Painful, but it forced a long-overdue onboarding rewrite.' },
  { month: 'Mar 2025', mrr: 3320, delta: 240, note: 'Raised DevToolkit Pro pricing 20%. Expected backlash never came — nobody cancelled.' },
  { month: 'Feb 2025', mrr: 3080, delta: 150, note: 'A single SEO post ("self-hosted JWT decoder") started ranking and now drives ~30% of signups.' },
  { month: 'Jan 2025', mrr: 2930, delta: 410, note: 'New-year SaaS budgets unlocked. Annual plans I added in December finally paid off.' },
];

export type ProductPnl = {
  product: string;
  mrr: number;
  costs: number;        // monthly infra + tooling, USD
  margin: number;       // percent
  channel: string;      // primary acquisition channel
};

export const productPnl: ProductPnl[] = [
  { product: 'DevToolkit Pro', mrr: 2840, costs: 190, margin: 93, channel: 'Organic SEO + word of mouth' },
  { product: 'SoloLaunch',     mrr: 1180, costs: 95,  margin: 92, channel: 'Product Hunt + Twitter/X' },
  { product: 'MicroDoc',       mrr: 0,    costs: 40,  margin: 0,  channel: 'Closed beta (no pricing yet)' },
];

export type StackItem = { layer: string; tool: string; why: string };

export const stack: StackItem[] = [
  { layer: 'Framework',  tool: 'Astro + React islands', why: 'Static-first, fast, and cheap to host. JS only where it earns its weight.' },
  { layer: 'Backend',    tool: 'Supabase',              why: 'Postgres, auth, and storage without running a server. Generous free tier.' },
  { layer: 'Payments',   tool: 'Stripe + Stripe Billing', why: 'Subscriptions, proration, and dunning handled. Never building this myself.' },
  { layer: 'Email',      tool: 'Resend + Buttondown',   why: 'Resend for transactional, Buttondown for the newsletter. Both founder-friendly.' },
  { layer: 'Analytics',  tool: 'Plausible',             why: 'Privacy-first, no cookie banner, lightweight script. Owns its own narrative.' },
  { layer: 'Hosting',    tool: 'Cloudflare Pages + Workers', why: 'Edge static + serverless functions. The free tier outlasts most side projects.' },
];

export const lessons: string[] = [
  'Charge more, sooner. Every price increase I delayed cost me months of compounding revenue.',
  'One SEO article that ranks beats ten that don\'t. Write fewer, deeper, more specific posts.',
  'Churn is feedback, not failure. The two accounts I lost in April rewrote my onboarding for the better.',
  'Ship the boring boilerplate once (SoloLaunch) and reuse it forever. Your second product should take days, not months.',
  'Build in public before you have numbers worth showing. The audience compounds slower than the revenue.',
];
