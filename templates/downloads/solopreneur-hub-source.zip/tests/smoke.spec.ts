import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Allan Ninal/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('projects grid has project cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#projects-grid article');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('revenue section is visible', async ({ page }) => {
  await page.goto('/');
  const revenueSection = page.locator('#revenue');
  await expect(revenueSection).toBeVisible();
});

test('revenue heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#revenue-heading')).toBeVisible();
});

test('newsletter section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#newsletter')).toBeVisible();
});

test('newsletter form has email input', async ({ page }) => {
  await page.goto('/');
  const emailInput = page.locator('#newsletter-email');
  await expect(emailInput).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('contact section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#contact')).toBeVisible();
});

test('LinkedIn contact link is present', async ({ page }) => {
  await page.goto('/');
  const contactSection = page.locator('#contact');
  const linkedinLink = contactSection.locator('a[href*="linkedin.com"]');
  await expect(linkedinLink).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  // Edition-aware: the Pro build swaps the bar for a "Pro edition" live-preview strip.
  const label = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${label}"]`);
  await expect(templateInfo).toBeVisible();
});

test('theme toggle switches from dark to light', async ({ page }) => {
  await page.goto('/');
  // Force dark theme first
  await page.evaluate(() => {
    localStorage.setItem('theme', 'dark');
    document.documentElement.setAttribute('data-theme', 'dark');
  });
  const toggle = page.locator('#theme-toggle');
  await toggle.click();
  const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(theme).toBe('light');
});

test('theme persists across reload', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => {
    localStorage.setItem('theme', 'light');
    document.documentElement.setAttribute('data-theme', 'light');
  });
  await page.reload();
  const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  expect(theme).toBe('light');
});

test('building section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#building')).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav');
  await expect(nav).toBeVisible();
});

const isPro = process.env.PUBLIC_EDITION === 'pro';

test.describe('Pro edition — Build Log', () => {
  test.skip(!isPro, 'Pro-only page');

  test('Build Log nav link points at /build-log/', async ({ page }) => {
    await page.goto('/');
    const link = page.locator('header nav a', { hasText: 'Build Log' });
    await expect(link).toBeVisible();
    await expect(link).toHaveAttribute('href', /\/build-log\/?$/);
  });

  test('Build Log page renders the report sections', async ({ page }) => {
    await page.goto('/build-log/');
    await expect(page.locator('#bl-heading')).toBeVisible();
    await expect(page.locator('#bl-timeline-heading')).toBeVisible();
    await expect(page.locator('#bl-pnl-heading')).toBeVisible();
    await expect(page.locator('#bl-stack-heading')).toBeVisible();
    await expect(page.locator('#bl-lessons-heading')).toBeVisible();
  });
});
