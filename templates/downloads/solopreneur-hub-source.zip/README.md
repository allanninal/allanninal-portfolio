# Solopreneur Hub — Day 31 of 365

A polished personal hub for solopreneurs, indie makers, and bootstrapped builders. Ships with dark-first design, public revenue metrics, project portfolio, newsletter signup, and contact — all in a single-page Astro template.

**Live demo:** https://templates.allanninal.dev/solopreneur-hub/

## Sections

- **Hero** — name, positioning statement, live MRR badge, dual CTAs
- **What I'm building** — project grid with status badges (Live / Building / Paused), tag chips, and per-project MRR + user count badges
- **Public revenue dashboard** — 4-metric band (MRR, ARR, Users, Churn) with teal accent
- **Newsletter** — Buttondown signup form with social proof counter
- **About** — extended bio with credential list and by-the-numbers card
- **Contact** — LinkedIn (primary) + email (secondary) + Ko-fi

## Design

| Token | Value |
|-------|-------|
| Palette | Deep charcoal `#0B1120` (dark default) / chalk `#F8FAFC` (light) |
| Accent | Teal `#0D9488` / `#2DD4BF` |
| Display font | Epilogue Variable |
| Body font | DM Sans |
| Mode | Dark-default with light/dark toggle |

## Quick start

```bash
npm install
npm run dev
```

## Environment variables

Copy `.env.example` to `.env`:

```
PUBLIC_BASE_PATH=/solopreneur-hub/
PUBLIC_SITE_URL=https://yourdomain.com
PUBLIC_AUTHOR_DONATE_URL=https://ko-fi.com/yourname
```

Leave `PUBLIC_TEMPLATE_HUB_URL` blank — analytics/ads only render on the author's deploy.

## Customise

1. Edit `src/data/config.ts` — update `maker` (name, bio, socials) and `projects` / `revenueMetrics`
2. Swap the newsletter form `action` URL to your Buttondown, Mailchimp, or ConvertKit endpoint
3. Update `src/styles/global.css` CSS vars to change palette
4. Replace `public/og-image.svg` with your own OG graphic

## License

MIT — free to use, clone, and ship.
