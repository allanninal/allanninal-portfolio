import { test, expect } from '@playwright/test';

test.describe('Meridian Line — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Meridian Line/);
    await expect(page.locator('h1')).toContainText('Twenty-four millimetres');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The plan ────────────────────────────────────────────────────────────
  // The drawing and its list render from one array, so they must agree.
  test('the plan drawing and the position list describe the same set', async ({ page }) => {
    await page.goto('/');
    const markers = await page.locator('#plan svg circle').count();
    const listed = await page.locator('#plan ol.positions > li.pos').count();
    expect(markers).toBe(listed);
    expect(listed).toBe(8);
    const ns = (await page.locator('#plan .pos-n').allTextContents()).map(Number);
    expect(ns).toEqual([1, 2, 3, 4, 5, 6, 7, 8]);
  });

  // The drawing carries no information the list does not, so it must not be
  // announced — otherwise a screen reader hears an unlabelled diagram.
  test('the plan is aria-hidden and the list is its text equivalent', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#plan svg.plan')).toHaveAttribute('aria-hidden', 'true');
    for (const t of await page.locator('#plan .pos-room').allTextContents()) {
      expect(t).toMatch(/\d+mm/);
    }
    for (const w of await page.locator('#plan .pos-why').allTextContents()) {
      expect(w.trim().length).toBeGreaterThan(40);
    }
  });

  test('the per-room tally is derived from the positions', async ({ page }) => {
    await page.goto('/');
    const roomsOf = (await page.locator('#plan .pos-room').allTextContents())
      .map((s) => s.split('·')[0].trim());
    const counts: Record<string, number> = {};
    for (const r of roomsOf) counts[r] = (counts[r] || 0) + 1;
    const line = await page.locator('#plan .figure-lead').textContent();
    expect(line).toContain(`${roomsOf.length} positions across ${Object.keys(counts).length} rooms`);
    for (const [room, n] of Object.entries(counts)) expect(line).toContain(`${room} ${n}`);
  });

  // The claim the whole page rests on.
  test('nothing on the page is shot wider than 20mm, and 14mm is refused', async ({ page }) => {
    await page.goto('/');
    const mms = (await page.locator('#plan .pos-room').allTextContents())
      .map((s) => Number(s.match(/(\d+)mm/)![1]));
    const widest = Math.min(...mms);
    expect(widest).toBeGreaterThanOrEqual(20);
    await expect(page.locator('h1 ~ p.figure-lead').first())
      .toContainText(`Widest lens on this set: ${widest}mm`);
    // 14mm must appear only as something declined.
    const row = page.locator('#rules tbody tr', { hasText: '14mm' });
    await expect(row).toContainText(/Nothing we deliver/i);
  });

  test('every room image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#rooms img').evaluateAll((els) =>
      els.map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })));
    expect(imgs.length).toBe(4);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.w).toBeTruthy(); expect(i.h).toBeTruthy();
    }
  });

  test('all room images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('rooms are captioned with the position and the lens', async ({ page }) => {
    await page.goto('/');
    const caps = await page.locator('#rooms figcaption').allTextContents();
    expect(caps.length).toBe(4);
    for (const c of caps) { expect(c).toMatch(/\d+mm/); expect(c).toMatch(/pos \d/); }
  });

  test('the refusals are published with reasons', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('#wont');
    expect(await s.locator('tbody tr').count()).toBe(5);
    await expect(s).toContainText(/Replace the sky/i);
    await expect(s).toContainText(/Widen a room in post/i);
    // Virtual staging must be described as needing a label, not refused outright.
    await expect(s).toContainText(/labelled/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-96 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['ferrous', 'cleveland', 'packshot', 'brygada', 'inconsolata']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro shoot spec is absent from the free build', async ({ page }) => {
    const res = await page.goto('/shoot-spec/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
