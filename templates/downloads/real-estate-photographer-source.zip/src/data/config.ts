// Meridian Line — Fort Collins, CO.
//
// Seventh photography template, seventh axis: where the camera stood. Real
// estate work is decided by position — corner, long axis, chest height — and a
// plan marked with those positions is the trade's real working document.

export const site = {
  name:        'Meridian Line',
  shortName:   'Meridian Line',
  title:       'Meridian Line — Real Estate Photography in Fort Collins, CO',
  tagline:     'Twenty-four millimetres, not fourteen.',
  owner:       'Sunniva Boateng',
  ownerRole:   'Real estate photographer',
  credential:  'Interiors, exteriors and floor plans · Fort Collins',
  license:     'Real estate photography, working since 2019',
  city:        'Fort Collins',
  state:       'CO',
  language:    'en',
  phoneDisplay: '(970) 555-0137',
  phoneHref:   '+19705550137',
  email:       'book@meridianline.example',
  streetAddress: '218 Linden St',
  postalCode:  '80524',
  hours:       'Shoots Mon–Sat · same-day slots when the light allows',
  bookingWindow: 'Next-day turnaround as standard. Twilight by arrangement.',
  description:
    'Real estate photography in Fort Collins. A wider lens does not photograph a bigger ' +
    'room, it photographs a lie about one — so this page shows the plan, the positions, ' +
    'and the focal length each frame was actually shot at.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The plan',   href: '#plan' },
  { label: 'Three rules', href: '#rules' },
  { label: 'Rooms',      href: '#rooms' },
  { label: 'What we will not do', href: '#wont' },
  { label: 'Rates',      href: '#rates' },
  { label: 'Book',       href: '#book' },
];

// ── The plan ──────────────────────────────────────────────────────────────
// One 4-room plan. Each position drives BOTH the SVG marker and the list, so
// the drawing and its text equivalent cannot drift apart.
//
// Plan coordinate space is 600 × 440. Rooms are drawn from `rooms`; camera
// positions sit at `x`/`y` and point toward `tx`/`ty`.

export const plan = {
  label: 'Two-bed single storey, 94 m²',
  rooms: [
    { name: 'Living',  x: 20,  y: 20,  w: 300, h: 220 },
    { name: 'Kitchen', x: 20,  y: 240, w: 300, h: 180 },
    { name: 'Bed 1',   x: 320, y: 20,  w: 260, h: 200 },
    { name: 'Bed 2',   x: 320, y: 220, w: 260, h: 200 },
  ],
  positions: [
    { n: 1, room: 'Living',  x: 44,  y: 44,  tx: 170, ty: 130, mm: 24,
      shot: 'The whole room, toward the window wall',
      why: 'The far corner from the window. Shooting toward daylight is what makes an interior look like a room rather than a cave.' },
    { n: 2, room: 'Living',  x: 296, y: 216, tx: 170, ty: 130, mm: 24,
      shot: 'The reverse, showing the fireplace wall',
      why: 'Two frames from opposite corners is how a buyer assembles the shape of a room. One frame is a rumour.' },
    { n: 3, room: 'Kitchen', x: 44,  y: 396, tx: 170, ty: 330, mm: 20,
      shot: 'Along the run, island in the foreground',
      why: 'Kitchens are the one room where 20mm earns its place — galley runs are genuinely long and narrow.' },
    { n: 4, room: 'Kitchen', x: 296, y: 264, tx: 170, ty: 330, mm: 28,
      shot: 'Back toward the garden doors',
      why: 'Longer, because this frame is about the light coming in rather than the size of the room.' },
    { n: 5, room: 'Bed 1',   x: 556, y: 44,  tx: 450, ty: 120, mm: 24,
      shot: 'Bed and window together',
      why: 'Corner opposite the door. A bedroom shot from the doorway is a photograph of a doorway.' },
    { n: 6, room: 'Bed 1',   x: 344, y: 196, tx: 450, ty: 120, mm: 35,
      shot: 'The view out, from the bed',
      why: '35mm because this is the view, not the room. A wide lens would shrink the thing being sold.' },
    { n: 7, room: 'Bed 2',   x: 556, y: 396, tx: 450, ty: 320, mm: 24,
      shot: 'Full room, door in frame',
      why: 'Small rooms are the ones people distrust. Include the door so the scale is checkable.' },
    { n: 8, room: 'Bed 2',   x: 344, y: 244, tx: 450, ty: 320, mm: 28,
      shot: 'Reverse, wardrobe wall',
      why: 'Storage sells second bedrooms. It is also the wall every other photographer leaves out.' },
  ],
};

export const planNote =
  'Every frame in a set has a position and a reason for it. Two frames per room from ' +
  'opposite corners, along the long axis, camera at about 1.4 metres. None of that is ' +
  'taste — it is how a buyer assembles the shape of a room from photographs.';

// ── The three rules ───────────────────────────────────────────────────────

export const rules = [
  { rule: 'Verticals vertical',
    body: 'A level on the tripod and a correction in post. Converging verticals make a house look like it is falling over, and it is the single biggest amateur tell.',
    tell: 'The tell: leaning walls' },
  { rule: 'Corner, along the long axis',
    body: 'A room photographed across its short axis reads as a corridor. From the corner you get two walls, the depth, and somewhere for the eye to go.',
    tell: 'The tell: rooms that read as corridors' },
  { rule: 'Chest height, about 1.4m',
    body: 'Eye height flattens a room and crops the ceiling. Floor height makes a show home for hobbits. 1.4m is where furniture reads at the size it is.',
    tell: 'The tell: worktops seen from above' },
];

// ── Focal length, honestly ────────────────────────────────────────────────

export const focal = {
  headline: 'What a wider lens actually does.',
  intro:
    'Ultra-wide is the defining dishonesty of this trade. The buyer arrives, the room is ' +
    'half what they expected, and the agent spends the viewing managing disappointment. ' +
    'These are the focal lengths we use and what each is for.',
  rows: [
    { mm: '35mm', use: 'Views out, detail, anything being sold on its own merits', note: 'Closest to how the room looks standing in it.' },
    { mm: '28mm', use: 'Reverse angles, bedrooms, bathrooms',                        note: 'Honest in a small room. Most of a set sits here or at 24.' },
    { mm: '24mm', use: 'The default for a full room',                                note: 'Wide enough to show the shape, narrow enough to keep it truthful.' },
    { mm: '20mm', use: 'Long galley kitchens, narrow halls',                          note: 'Used deliberately and sparingly, and we will say when.' },
    { mm: '14mm', use: 'Nothing we deliver',                                          note: 'It does not photograph a bigger room. It photographs a different one.' },
  ],
};

// ── Rooms ─────────────────────────────────────────────────────────────────
// Alt strings written from the files.

export const rooms = [
  { file: 'r01.jpg', cap: 'Hall through to salon · 24mm · pos 1',
    alt: 'A dark wood-panelled hallway looking through open double doors into a parquet-floored room' },
  { file: 'r02.jpg', cap: 'Kitchen, along the run · 20mm · pos 3',
    alt: 'A bright white kitchen with an island, pendant lights and open shelving beside garden doors' },
  { file: 'r03.jpg', cap: 'Bed 1, the view out · 35mm · pos 6',
    alt: 'A coastal bedroom with a wicker chair beside a window looking onto dunes and sea' },
  { file: 'r04.jpg', cap: 'Living, reverse · 24mm · pos 2',
    alt: 'A living room with an exposed concrete wall, leather sofa, wooden floor and a bicycle' },
];

// ── What we will not do ───────────────────────────────────────────────────

export const wont = {
  intro:
    'Each of these is a complaint waiting for the agent, and the agent is the one standing ' +
    'in the room when it arrives.',
  rows: [
    { thing: 'Replace the sky with a different season',  why: 'A February listing with a July sky is a lie the buyer notices from the driveway. We will brighten a flat sky; we will not change the weather.' },
    { thing: 'Remove a neighbouring building',           why: 'It is still there when they visit. So is the pylon, the extension and the road.' },
    { thing: 'Widen a room in post',                     why: 'It is the ultra-wide problem with extra steps, and it is the one thing here that could get an agent in genuine trouble.' },
    { thing: 'Composite in furniture that is not there', why: 'Virtual staging is a legitimate separate service, and it must be labelled as such on the listing. Unlabelled, it is a misrepresentation.' },
    { thing: 'Shoot a property that is not ready',       why: 'We will reschedule rather than photograph a house mid-move. It costs a day and saves a reshoot.' },
  ],
};

export const rates = {
  rows: [
    { what: 'Up to 1,500 sq ft',   figure: '$245', note: '20–25 finished frames, next-day delivery.' },
    { what: '1,500 – 3,000 sq ft', figure: '$325', note: '30–35 frames.' },
    { what: 'Over 3,000 sq ft',    figure: 'Quoted', note: 'Priced on the plan, not on the postcode.' },
    { what: 'Twilight set',        figure: '$150', note: 'Adds a second visit inside a 25-minute window. Book it or do not — it cannot be squeezed in.' },
    { what: 'Floor plan',          figure: '$95',  note: 'Measured on site. The thing buyers actually save.' },
    { what: 'Drone exterior',      figure: '$140', note: 'Part 107 certificated. Weather-dependent and rescheduled free.' },
  ],
  prep: [
    'All lights on, all blinds open, before we arrive. Mixed lighting is the slowest thing to fix.',
    'Cars off the driveway, bins out of shot, and the hose coiled. Ten minutes of work, three frames saved.',
    'Worktops clear apart from one deliberate thing. Empty reads as staged; cluttered reads as small.',
    'Toilet seats down, mats straight, towels matching. Every photographer says this and every listing still needs it.',
    'Tell us which room is the selling point. We will spend the extra fifteen minutes there.',
  ],
};

export const faqs = [
  {
    q: 'Why not use a wider lens? Other photographers do.',
    a: 'Because it does not photograph a bigger room, it photographs a different one. The buyer arrives, the room is half what they expected, and you spend the viewing managing that. 24mm shows the shape without the lie.',
  },
  {
    q: 'What is flambient?',
    a: 'Flash and ambient blended: one frame exposed for the window view, one or more flash frames for the room, combined so the window is not blown out and the interior is not orange. It is the current standard and it is why a set takes longer than people expect.',
  },
  {
    q: 'Will you photoshop the sky?',
    a: 'We will lift a flat grey sky. We will not put a July sky on a February listing — that is visible from the driveway and it is your credibility, not ours, that pays for it.',
  },
  {
    q: 'How fast is delivery?',
    a: 'Next day as standard, before noon. If you need same-day for a launch, say so when booking and we will shoot you first.',
  },
  {
    q: 'Do you do virtual staging?',
    a: 'Yes, as a separate service, and every staged image is labelled on the listing. Unlabelled virtual staging is a misrepresentation and it is the agent who answers for it.',
  },
  {
    q: 'What if the house is not ready?',
    a: 'We reschedule. Photographing a house mid-move costs you a reshoot and costs us the afternoon, and neither of us wants the pictures that come out of it.',
  },
];
