import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Foursquare Joinery — accessibility', () => {
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();

    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  // The maker strip is the element that has failed most often across the library:
  // 61 footers were "fixed" with a var() fallback chain that resolved to
  // currentColor and changed nothing. Both the paragraph and the link get their
  // own assertion, because repairing only the link leaves "Made by" failing.
  test('maker strip and credit contrast pass on the dark footer', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .include('footer')
      .withRules(['color-contrast'])
      .analyze();
    expect(results.violations).toEqual([]);

    const creditColour = await page.locator('p.maker-credit').evaluate(el => getComputedStyle(el).color);
    const linkColour   = await page.locator('p.maker-credit a').evaluate(el => getComputedStyle(el).color);
    // Explicit values, not inherited: #CFC8BA and #A3B86A.
    expect(creditColour).toBe('rgb(207, 200, 186)');
    expect(linkColour).toBe('rgb(163, 184, 106)');
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  test('heading hierarchy is logical', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('h1')).toHaveCount(1);
    // Ten h2s: the ten sections below the hero, in the brief's order.
    await expect(page.locator('h2')).toHaveCount(10);
  });

  test('project cards each carry the four-line spec block', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('.work-card');
    await expect(cards).toHaveCount(6);
    const specTerms = page.locator('.work-spec dt');
    await expect(specTerms).toHaveCount(24);   // 6 projects × 4 lines
  });

  test('piece cards are present with published ranges', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.piece-card')).toHaveCount(6);
    const ranges = await page.locator('.piece-range').allTextContents();
    expect(ranges.length).toBe(6);
    ranges.forEach(r => expect(r).toContain('$'));
  });

  test('the comparison section concedes to stock cabinets', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.compare-card')).toHaveCount(6);
    // If every card said "build it" the section would be an advert.
    const stockCards = page.locator('.compare-card--stock');
    expect(await stockCards.count()).toBeGreaterThanOrEqual(3);
  });

  test('review cards are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('.review-card').count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('area zones are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('.area-zone').count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('the lead-time bar replaces the emergency bar', async ({ page }) => {
    await page.goto('/');
    const bar = page.locator('.leadtime-bar');
    await expect(bar).toBeVisible();
    await expect(bar).toContainText('eight to ten weeks');
    // A carpenter has no emergency. There should be no emergency bar at all.
    await expect(page.locator('.emergency-bar')).toHaveCount(0);
  });

  test('design system page passes axe', async ({ page }) => {
    await page.goto('/design/');
    await page.waitForLoadState('networkidle');
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();
    if (results.violations.length > 0) {
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }
    expect(results.violations).toEqual([]);
  });
});
