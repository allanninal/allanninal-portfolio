import { test, expect } from '@playwright/test';

test.describe('Foursquare Joinery — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title names this business and this trade', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Foursquare Joinery');
    expect(title).toContain('Grand Rapids');
  });

  // Scaffold contamination is the most common defect in this library: a template
  // is built by copying its neighbour, and everything not explicitly rewritten
  // survives. This asserts the day-73 nouns are gone from the rendered page.
  test('no trace of the source template survives in the rendered page', async ({ page }) => {
    await page.goto('/');
    const body = (await page.locator('body').innerText()).toLowerCase();
    for (const stale of ['halden', 'providence', 'painter', 'painting', 'east bay', 'rhode island']) {
      expect(body).not.toContain(stale);
    }
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
    expect(description!.length).toBeLessThan(200);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
    expect(ogImage).toContain('og-image.png');
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of ['work', 'pieces', 'compare', 'wood', 'process', 'service-area', 'reviews', 'about', 'faq', 'contact']) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('every in-page nav link resolves to a real section', async ({ page }) => {
    await page.goto('/');
    const hrefs = await page.locator('a[href^="#"]').evaluateAll(
      els => els.map(el => el.getAttribute('href')!).filter(h => h.length > 1),
    );
    expect(hrefs.length).toBeGreaterThan(5);
    for (const href of [...new Set(hrefs)]) {
      await expect(page.locator(href)).toBeAttached();
    }
  });

  test('tel links are present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="tel:"]').count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('mailto link is present', async ({ page }) => {
    await page.goto('/');
    const count = await page.locator('a[href^="mailto:"]').count();
    expect(count).toBeGreaterThanOrEqual(1);
  });

  test('external links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const blanks = page.locator('a[target="_blank"]');
    const total = await blanks.count();
    expect(total).toBeGreaterThanOrEqual(2);
    const safe = await page.locator('a[target="_blank"][rel*="noopener"]').count();
    expect(safe).toBe(total);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  // schema.org has no `Carpenter`, `Cabinetmaker` or `Joiner` type — the strings
  // do not appear anywhere in the vocabulary. The correct fallback is the array
  // form, and GeneralContractor would be a false claim on a joinery shop.
  test('business schema uses HomeAndConstructionBusiness, not an invented type', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const parsed = blocks.map(b => JSON.parse(b));
    const business = parsed.find(b => Array.isArray(b['@type']));
    expect(business).toBeTruthy();
    expect(business['@type']).toEqual(['HomeAndConstructionBusiness', 'LocalBusiness']);
    expect(business.additionalType).toContain('Carpentry');
    expect(Array.isArray(business.makesOffer)).toBe(true);
    expect(business.makesOffer.length).toBe(6);
    expect(Array.isArray(business.knowsAbout)).toBe(true);
    expect(business.hasCredential[0].name).toContain('Maintenance & Alteration');
    const allTypes = JSON.stringify(parsed);
    expect(allTypes).not.toContain('"Carpenter"');
    expect(allTypes).not.toContain('"Cabinetmaker"');
    expect(allTypes).not.toContain('GeneralContractor');
  });

  test('FAQPage schema covers every question on the page', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.locator('script[type="application/ld+json"]').allTextContents();
    const faq = blocks.map(b => JSON.parse(b)).find(b => b['@type'] === 'FAQPage');
    expect(faq).toBeTruthy();
    const rendered = await page.locator('details summary').count();
    expect(faq.mainEntity.length).toBe(rendered);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('link[rel="icon"]')).toBeAttached();
  });

  test('six piece types with published ranges', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.piece-card').count()).toBe(6);
  });

  test('six built-ins in the gallery', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.work-card').count()).toBe(6);
  });

  test('six reviews', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.review-card').count()).toBe(6);
  });

  test('service area zones are all present', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.area-zone').count()).toBe(4);
  });

  test('about section is present with owner avatar', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#about')).toBeAttached();
    await expect(page.locator('.about-avatar')).toBeAttached();
  });

  test('cred chips are present in about section', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.cred-chip').count()).toBeGreaterThanOrEqual(4);
  });

  test('contact form is present with a labelled control for every input', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.contact-form')).toBeAttached();
    const controls = page.locator('.contact-form input, .contact-form select, .contact-form textarea');
    const total = await controls.count();
    expect(total).toBeGreaterThanOrEqual(5);
    for (let i = 0; i < total; i++) {
      const id = await controls.nth(i).getAttribute('id');
      expect(id).toBeTruthy();
      await expect(page.locator(`label[for="${id}"]`)).toHaveCount(1);
    }
  });

  test('FAQ section has ten items', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('details').count()).toBe(10);
  });

  test('the free edition does not ship the Pro wood-guide page', async ({ page }) => {
    // The build under test is the free one, so /wood-guide/ redirects home.
    const response = await page.goto('/wood-guide/');
    expect(response?.status()).toBeLessThan(400);
    await expect(page.locator('h1')).toContainText('Your walls');
  });

  test('the design system page loads and is noindexed', async ({ page }) => {
    const response = await page.goto('/design/');
    expect(response?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
  });
});
