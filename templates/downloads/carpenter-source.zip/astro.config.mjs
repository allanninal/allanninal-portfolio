import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
// Day 74 — carpenter. This slug is the single most-contaminated line in the
// scaffold: day 72 shipped with the previous template's slug still here and
// rendered with no CSS at all. If you fork this template, change it.
const BASE = process.env.PUBLIC_BASE_PATH || '/carpenter/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [
    tailwind({ applyBaseStyles: false }),
  ],
});
