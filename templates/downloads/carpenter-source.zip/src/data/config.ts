// Foursquare Joinery — configuration data
// Day 74 of the 365-template roadmap
//
// Design note: this is the one trade in the sprint that is not bought to fix a
// problem. Nobody's house stops working because it lacks a bookcase. So there is
// no emergency bar, no urgency and no red anywhere — the job of the page is not
// to be reached fastest, it is to prove the thing is worth wanting.
//
// The hook is `projects`. Every carpenter's site is a lightbox of finished
// woodwork, which is beautiful and useless, because a homeowner cannot see the
// hard part in a photograph. The hard part was that the wall leaned, the floor
// fell away an inch and the radiator could not move. So each project names what
// was out of square and the joinery decision that absorbed it. That is also the
// one thing a joiner will actually enjoy filling in: ask any of them what was
// interesting about a job and they will tell you what was wrong with the room.

export const carpenter = {
  name:        'Foursquare Joinery',
  tagline:     'Built-in cabinetry for Grand Rapids houses that were never square to begin with',
  description: 'Custom built-ins for Grand Rapids: alcove bookcases, window seats, mudroom lockers, pantries, media walls and under-stair storage. Scribed to the room you actually have, built in a two-bench shop, finished before it arrives.',
  phone:       '(616) 555-0148',
  phoneHref:   'tel:+16165550148',
  email:       'hello@foursquarejoinery.example',
  address:     '1412 Wealthy St SE',
  city:        'Grand Rapids',
  state:       'MI',
  zip:         '49506',
  license:     'Michigan Maintenance & Alteration Contractor #2102-555-0148, carpentry classification',
  licenseShort:'Michigan M&A Contractor, carpentry classification',
  licensed:    true,
  insured:     true,
  founded:     2013,
  yearsExperience: 13,
  // Lead time replaces the emergency line. It is honest, and for a shop worth
  // hiring it is also a soft flex.
  leadTime:    'Currently quoting installs eight to ten weeks out',
  leadTimeNote:'Drawings and the fixed number come first — nothing is cut until you have signed a template.',
  warrantyYears: 5,
  benchCount:  2,
  crewSize:    3,
  bookUrl:     '#',
  owner: {
    name:     'Ruth Vandenberg',
    title:    'Cabinetmaker & Owner',
    initials: 'RV',
    bio:      "I served my time in a millwork shop on the west side making store fixtures, which is where you learn that nothing on a job site is the dimension the drawing says it is. Foursquare is two benches and an installer. I draw every piece, I cut most of it, and I am there on install day for anything that has to be scribed — which is all of it, because Grand Rapids housing stock is 1900 to 1930 and there is not a plumb wall in Heritage Hill. The work I like best is the alcove nobody thinks can be used: the one beside the chimney breast that runs out five-eighths of an inch over nine feet and has a radiator pipe coming through the floor at the wrong end.",
  },
  instagram: '#',
  facebook:  '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Foursquare Joinery — Built-In Cabinetry, Grand Rapids MI',
  description:   'Custom built-ins in Grand Rapids: alcove bookcases, window seats, mudroom lockers and pantries, scribed to walls that are not plumb. Real price ranges published, five-year warranty on the joint.',
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

// ── The gallery ─────────────────────────────────────────────────────────────
// Six built-ins and what was out of square in each. The four-line spec block is
// the whole template: Room (what was wrong), Species & stock, Joint (the
// decision that absorbed it), Finish. The reader recognises the defect in their
// own house — everyone with a pre-war home knows one wall nothing fits against —
// and naming it is the only way to show craft in a medium where the craft is,
// by design, invisible once it is done.
export type Project = {
  slug: string;
  title: string;
  location: string;
  piece: string;
  room: string;
  species: string;
  joint: string;
  finish: string;
  price: string;
  // Two stock tones for the card's header band. Not a photograph: a template
  // ships without the buyer's job pictures, and an honest species swatch beats
  // somebody else's stock kitchen.
  stock: { hex: string; label: string }[];
};

export const projects: Project[] = [
  {
    slug:     'heritage-hill-alcoves',
    title:    'Two alcoves either side of a chimney breast, neither the same width',
    location: 'Heritage Hill · 1908 foursquare',
    piece:    'Paired alcove bookcases, 8\'2" tall',
    room:     'The two alcoves differed by 3⁄8" in width and the east wall was out of plumb 5⁄8" top to bottom. The plaster bellied out at picture-rail height on one side only.',
    species:  'Paint-grade poplar face frames, birch ply carcases, Michigan hard maple for the adjustable shelves.',
    joint:    'Face frames dominoed and built 3⁄8" narrow, then scribed to the plaster on site with a compass and a block plane. Carcases set plumb and independent of the frames; nothing nailed through the front.',
    finish:   'Sprayed in the shop — two coats of pigmented conversion varnish over a bonding primer. Site work was scribe stock and caulk only.',
    price:    'Built for $9,400',
    stock:    [{ hex: '#E8E4DC', label: 'Paint-grade poplar, sprayed' }, { hex: '#D9C7A3', label: 'Hard maple shelving' }],
  },
  {
    slug:     'eastown-window-seat',
    title:    'A window seat over a floor that fell away an inch to the bay',
    location: 'Eastown · 1921 bungalow',
    piece:    'Window seat with three drawers and a hinged lid',
    room:     'The floor dropped a full 1" from the room side to the bay over 62 inches, and the bay itself was 3⁄4" out of square corner to corner. Both original casings had to stay.',
    species:  'Quartersawn white oak, solid for the lid and the front rail, rift-sawn ply for the ends.',
    joint:    'Levelled off the high corner and the plinth scribed down to the floor, so the lid reads level and the taper hides in the base shadow line. Drawer boxes are half-blind dovetailed and hung on undermount slides that tolerate the racking.',
    finish:   'Hardwax oil, three coats, rubbed back between. Repairable in place by the owner, which matters on a lid people sit on.',
    price:    'Built for $6,800',
    stock:    [{ hex: '#C6A878', label: 'Quartersawn white oak' }, { hex: '#A88A5C', label: 'Oiled oak, three coats' }],
  },
  {
    slug:     'east-hills-mudroom',
    title:    'Mudroom lockers on a wall that leaned into the room',
    location: 'East Hills · 1913 Craftsman',
    piece:    'Four-bay lockers with a bench, hooks and a boot tray',
    room:     'The back wall leaned 7⁄8" into the room over 84 inches, and the return wall was 2° off ninety. An unmovable dryer vent came through 11 inches above the bench height.',
    species:  'Paint-grade poplar, birch ply carcases, solid hard maple bench top and hook rail.',
    joint:    'Built as four independent bays with 1" scribe stock on both stiles and a filler at the return, so the lean is absorbed across the run rather than dumped in one gap. The vent got a removable panel rather than a hole cut in a finished side.',
    finish:   'Conversion varnish on the casework; the maple bench top in hardwax oil so it can be sanded and re-oiled when the boots have had their way with it.',
    price:    'Built for $7,900',
    stock:    [{ hex: '#DFE3D6', label: 'Poplar, sprayed sage' }, { hex: '#D9C7A3', label: 'Hard maple bench' }],
  },
  {
    slug:     'ottawa-hills-pantry',
    title:    'A pantry in a room that had been three rooms',
    location: 'Ottawa Hills · 1926 foursquare',
    piece:    'Full-height pantry with pull-outs and a counter run',
    room:     'Three different plaster thicknesses along one 11-foot wall where two doorways had been closed up at different dates. Nothing was coplanar; the worst step was 1⁄2".',
    species:  'Cherry face frames and doors, birch ply carcases with cherry veneer where the interiors show.',
    joint:    'A shadow-gap reveal down the whole run instead of a scribed edge — when a wall changes plane three times, a scribe just chases the mess. The reveal is a deliberate 3⁄8" line and reads as design.',
    finish:   'Clear conversion varnish, satin. Cherry darkens for about eighteen months and then holds; the doors were kept out of the sun in the shop so it darkens evenly.',
    price:    'Built for $14,200',
    stock:    [{ hex: '#B4714A', label: 'Cherry, clear finish' }, { hex: '#8E5334', label: 'Cherry at 18 months' }],
  },
  {
    slug:     'cherry-hill-media-wall',
    title:    'A media wall around a chimney that was not centred on the room',
    location: 'Cherry Hill · 1917 four-square',
    piece:    'Media wall with flanking cabinets and floating shelves',
    room:     'The chimney breast sat 4 1⁄2" off the room centreline, which nobody notices until something symmetrical is built against it. Ceiling dropped 5⁄8" left to right.',
    species:  'Walnut floating shelves; paint-grade poplar and birch ply for the cabinetry below.',
    joint:    'Cabinets built to different widths so the openings match rather than the boxes — the eye reads the openings. Crown scribed to the falling ceiling and stopped short at both ends so the drop never meets a wall.',
    finish:   'Cabinets sprayed in conversion varnish; the walnut shelves in hardwax oil. Walnut was kept off the window wall on purpose — it fades in direct sun and nobody wants that surprise.',
    price:    'Built for $11,600',
    stock:    [{ hex: '#5C4433', label: 'American walnut' }, { hex: '#E8E4DC', label: 'Paint-grade, sprayed' }],
  },
  {
    slug:     'baxter-under-stair',
    title:    'Under-stair storage where the stringer was the only straight line',
    location: 'Baxter · 1911 worker cottage',
    piece:    'Three pull-out drawers and a hinged access door',
    room:     'A raking triangle with a 33.5° stringer, a wall that bowed 1⁄2" at mid-height and a stair carriage nobody was allowed to touch. Headroom ran out before the third drawer did.',
    species:  'Birch ply throughout, paint-grade poplar face frame, hard maple drawer runners.',
    joint:    'The face frame is a single scribed template taken off the actual rake with a profile gauge, not off a measurement. Drawers hang from the top so the bowed wall carries no load and the third one is deliberately shallower.',
    finish:   'Two coats of pigmented conversion varnish. Interiors left in clear-coated birch so the space reads bigger than it is.',
    price:    'Built for $4,300',
    stock:    [{ hex: '#E8E4DC', label: 'Paint-grade, sprayed' }, { hex: '#E3D3B4', label: 'Clear-coated birch ply' }],
  },
];

// ── What we build, and what it costs ────────────────────────────────────────
// Merged on purpose. Separating "services" from "pricing" is how trade sites end
// up with a pricing page that says "every job is unique". "Call for pricing" is
// the single biggest bounce on a custom-work site: a homeowner does not know
// whether an alcove bookcase is $1,200 or $12,000, and rather than guess, they
// leave. Publishing ranges disqualifies the wrong leads before they eat an hour
// of the shop's day.
export type Piece = {
  slug: string;
  name: string;
  range: string;
  basis: string;
  desc: string;
  movers: string[];
};

export const pieces: Piece[] = [
  {
    slug:  'alcove-bookcases',
    name:  'Alcove bookcases',
    range: '$3,800 – $11,000',
    basis: 'per alcove, supplied and installed',
    desc:  'The classic pre-war built-in: floor-to-ceiling or capped at the picture rail, in the recess beside a chimney breast. Almost always a pair, and almost never a matching pair, because the two recesses are rarely the same width.',
    movers: [
      'Paint-grade or stain-grade — the single biggest fork, two to three times over',
      'Doors or drawers in the base, versus an open plinth',
      'Height: stopping at the picture rail is materially cheaper than running to a coved ceiling',
      'How far out of plumb the alcove is — beyond about 3⁄4" the scribe stock has to be built in from the drawing',
    ],
  },
  {
    slug:  'window-seats',
    name:  'Window seats',
    range: '$4,200 – $9,500',
    basis: 'per bay, supplied and installed',
    desc:  'A bay or dormer converted into seating with storage under. Bays are the least square part of any old house — three walls, none of them at the angle the plan says — so this is a template job rather than a measurement job.',
    movers: [
      'Hinged lid versus drawers: drawers roughly double the box work',
      'Whether the existing casings, apron and stool stay',
      'Solid timber lid versus veneered ply',
      'How far the floor falls to the bay — an inch is common and it all has to hide in the plinth',
    ],
  },
  {
    slug:  'mudroom-lockers',
    name:  'Mudroom lockers',
    range: '$5,500 – $13,000',
    basis: 'for a typical three to five bay run',
    desc:  'Open lockers with a bench, hooks, a shelf over and something to put wet boots in. The most-used built-in in a Michigan house and the one that takes the most abuse, so the bench top and the finish schedule matter more than the joinery.',
    movers: [
      'Number of bays, and whether the run turns a corner',
      'Bench top: painted ply, solid maple, or stone',
      'Doors over the top cubbies, or left open',
      'Drawers or a boot tray in the base',
    ],
  },
  {
    slug:  'pantries',
    name:  'Pantries and larder units',
    range: '$7,000 – $18,000',
    basis: 'per unit, supplied and installed',
    desc:  'A full-height pantry, freestanding-looking or built in, with pull-outs, a worktop inside and doors that close on the whole thing. Usually the piece that makes a small pre-war kitchen work without moving a single wall.',
    movers: [
      'Pull-out hardware — good runners are a real line, not a rounding error',
      'Stain-grade hardwood versus paint-grade',
      'Interior worktop material',
      'Whether power has to come into the unit, which brings an electrician onto the job',
    ],
  },
  {
    slug:  'media-walls',
    name:  'Media walls',
    range: '$8,500 – $22,000',
    basis: 'per wall, supplied and installed',
    desc:  'Cabinetry and shelving around a fireplace or a television, usually the full width of a room. The largest thing we make and the one where being out of square shows most, because the eye reads a long horizontal line against the ceiling.',
    movers: [
      'Wall width, and whether it returns onto a second wall',
      'Floating shelves in a hardwood versus painted fixed shelves',
      'Cable management, venting and access panels',
      'Ceiling drop across the run — anything over 1⁄2" changes how the crown is detailed',
    ],
  },
  {
    slug:  'under-stair',
    name:  'Under-stair storage',
    range: '$2,800 – $7,500',
    basis: 'per staircase',
    desc:  'Pull-out drawers, a hinged access door, or a combination, in the raking triangle under a flight. The most-wasted space in a pre-war house and, per dollar, the built-in that changes daily life most.',
    movers: [
      'Pull-outs versus a simple door — pull-outs are most of the cost',
      'Whether the stair carriage can be touched at all',
      'How the rake is picked up: a scribed template rather than a measurement',
      'Finish inside, which people underestimate wanting until they see it',
    ],
  },
];

// ── Built-in, or bought-in ───────────────────────────────────────────────────
// The section must genuinely concede. If it lists three reasons custom wins and
// no case where it loses, it is an advert and the reader knows. For most jobs
// the real rival is a stock cabinet run plus trim at a third of the price, and
// pretending it does not exist is what makes a carpenter's site read as evasive.
export type Comparison = { situation: string; answer: 'custom' | 'stock'; because: string };

export const comparison: Comparison[] = [
  {
    situation: 'A recess that is out of plumb or out of square',
    answer:    'custom',
    because:   'This is the whole commercial reason the trade exists. A factory carcase is a rectangular prism; the recess is not. Stock boxes plus scribe trim in a leaning alcove give you a 1" wedge of painted filler at eye height and it is the only thing anyone will see.',
  },
  {
    situation: 'A straight run against a square wall',
    answer:    'stock',
    because:   'Buy the boxes. If the wall is flat and plumb and the run is uninterrupted, a stock carcase run with a decent face frame and good trim gets you 90% of the look for about a third of the money. We will tell you this on the survey rather than after the quote.',
  },
  {
    situation: 'A bay window or a dormer',
    answer:    'custom',
    because:   'Three walls, none of them at the angle on the plan, plus a floor that has usually settled toward the bay. There is no stock product for this shape and there never has been.',
  },
  {
    situation: 'A rental or a flip',
    answer:    'stock',
    because:   'A built-in is a fixture; you cannot take it with you and the next owner may not want it. On a property you are selling inside two years the money is better spent almost anywhere else.',
  },
  {
    situation: 'Non-standard heights: coved ceilings, picture rails, deep skirting',
    answer:    'custom',
    because:   'Stock carcases come in a few heights and none of them land on a 1918 picture rail. The filler panel above a stock run with a nine-foot-two ceiling is the tell that makes a whole kitchen look bought.',
  },
  {
    situation: 'A room you will re-do within five years',
    answer:    'stock',
    because:   'Custom joinery is priced on the assumption it stays. If the layout is provisional, keep it provisional and spend the difference when the layout is not.',
  },
];

// ── Wood, joints, and a Michigan winter ──────────────────────────────────────
export const woodNotes = [
  {
    title: 'Paint-grade or stain-grade',
    lede:  'The fork that moves the number two to three times over.',
    body:  'Paint-grade means poplar, birch ply and MDF: stable, cheap, sprays beautifully, and the grain is nobody’s business because it is under two coats of pigment. Stain-grade means the timber is the finish — every board is selected for figure and colour, offcuts you would happily use in paint-grade become firewood, and the yield drops. That yield is the cost. It is not a markup for prettiness.',
  },
  {
    title: 'Michigan hardwood, because it is a day’s drive away',
    lede:  'Hard maple, cherry, white oak and walnut, in that order of use.',
    body:  'Hard maple for shelving and bench tops because it takes a beating. Cherry when someone wants warmth and will accept that it darkens for eighteen months before it settles. Quartersawn white oak for anything in a Craftsman house, because it is what is already in the room. Walnut for a shelf or a lid, and never on a sunny window wall, because it fades toward grey in direct light and that surprise is not one we hand out.',
  },
  {
    title: 'What a Michigan winter does to a panel',
    lede:  '~65% relative humidity in August, ~25% in a heated house in January.',
    body:  'Across that swing a 12" solid panel moves about 1⁄8" across the grain, and nothing you do stops it. So panels float in their grooves rather than being glued in, face frames are engineered to take the movement at the joints, and a built-in installed in July gets scribed differently from one installed in January. This is ordinary shop knowledge; we state it because a gap that appears in February is a design decision, not a defect, and you should know which one you are looking at.',
  },
  {
    title: 'Solid, veneer and ply in the same piece',
    lede:  'A good built-in usually uses all three, deliberately.',
    body:  'Solid timber where it is seen edge-on and takes wear: face frames, lids, bench tops, shelf fronts. Veneered ply for wide flat panels, because a 24"-wide solid panel wants to move a quarter of an inch and ply does not. Plain birch ply for carcase backs and interiors nobody will see. A shop that uses solid everywhere is not being generous, it is building something that will crack.',
  },
  {
    title: 'The finish is a schedule, not a colour',
    lede:  'Conversion varnish, hardwax oil, and which one you can repair yourself.',
    body:  'Conversion varnish is sprayed in the shop, cures hard, and is what makes painted casework look factory rather than brushed. It cannot be spot-repaired at home. Hardwax oil is softer, feels like timber rather than plastic, and can be sanded and re-oiled in place by the owner with a rag — which is why bench tops and lids get it and cabinet doors do not. We spray in the shop rather than on site, so your house does not become a spray booth.',
  },
];

// ── Process ──────────────────────────────────────────────────────────────────
// Step 4 exists because it is the question every custom-work customer actually
// has and almost no trade site answers: at what point does the number stop moving?
export const process = [
  {
    step:  '1',
    title: 'A visit, and a straightedge',
    desc:  'An hour at the house. We measure, but more usefully we find out how far out the room is: a long level on the walls, a profile gauge on the rake, diagonals across the bay. That is the survey that decides whether this is a custom job at all.',
  },
  {
    step:  '2',
    title: 'A drawing and a range',
    desc:  'A dimensioned elevation and a price range, not a number. If a stock run plus trim would serve you better, this is where we say so, and we would rather say it now than after you have paid for drawings.',
  },
  {
    step:  '3',
    title: 'Species, finish and hardware chosen',
    desc:  'Paint-grade or stain-grade, the species, the finish schedule and the runners. These are the four decisions that move the price, and they all get made here rather than halfway through the build.',
  },
  {
    step:  '4',
    title: 'The number is fixed here',
    desc:  'You sign the drawing and the specification, and the price stops moving. After this point a change is a variation with its own number, in writing. Nothing is cut before this and everything is cut after it, which is exactly why the line sits where it does.',
  },
  {
    step:  '5',
    title: 'Built and finished in the shop',
    desc:  'Four to seven weeks on the bench depending on the piece. It is sprayed or oiled here, not in your living room, so what arrives on install day is finished work with only scribe stock left proud.',
  },
  {
    step:  '6',
    title: 'Install day, and the scribing',
    desc:  'One to three days on site. This is where the leaning wall gets dealt with: compass, block plane, a lot of offering up. Then caulk, touch-up, and we take the packaging away with us.',
  },
];

// ── Service area ─────────────────────────────────────────────────────────────
// Also does the job of saying no to the three-hour drive.
export const serviceArea = [
  {
    zone:          'Grand Rapids',
    neighborhoods: ['Heritage Hill', 'Eastown', 'East Hills', 'Cherry Hill', 'Ottawa Hills', 'Baxter'],
    zips:          ['49503', '49506', '49507', '49505', '49504', '49508'],
  },
  {
    zone:          'Kent County',
    neighborhoods: ['East Grand Rapids', 'Ada', 'Cascade', 'Lowell', 'Rockford', 'Grandville'],
    zips:          ['49506', '49301', '49546', '49331', '49341', '49418'],
  },
  {
    zone:          'Ottawa County',
    neighborhoods: ['Grand Haven', 'Holland', 'Hudsonville', 'Jenison', 'Zeeland', 'Spring Lake'],
    zips:          ['49417', '49423', '49426', '49428', '49464', '49456'],
  },
  {
    zone:          'Beyond that',
    neighborhoods: ['Kalamazoo', 'Muskegon', 'Lansing', 'Traverse City', 'Detroit side', 'Chicago side'],
    zips:          ['Ask first'],
  },
];

export const areaNote =
  'Kent and Ottawa counties, no travel charge. Beyond that we will still talk, but honestly: a two-hour drive each way on install day is a real cost and it lands in your quote, so unless the piece is large enough to justify it you are better served by a shop closer to you. We will happily name one.';

// ── Why us ───────────────────────────────────────────────────────────────────
// No awards, no counts, no "500+ projects". The trust here comes from the
// licence category, the employed shop, the finish schedule and the warranty on
// the joint — four things that are checkable rather than claimed.
export const whyUs = [
  {
    title:     'The number stops moving when you sign the drawing',
    stat:      'Step 4',
    statLabel: 'where the price is fixed',
    desc:      'Custom work has a reputation for open-ended invoices, and it is earned. Here the range comes with the drawing, the fixed number comes with the specification, and after that a change is a variation with its own price, in writing.',
  },
  {
    title:     'Sprayed in the shop, not in your house',
    stat:      '2 benches',
    statLabel: 'and one installer',
    desc:      'Conversion varnish goes on under extraction in the shop, which is both why it looks the way it does and why your living room is not a spray booth for three days. Site work is scribing, fixing and touch-up.',
  },
  {
    title:     'Licensed for the work, in the right category',
    stat:      'M&A',
    statLabel: 'carpentry classification',
    desc:      'Michigan Maintenance & Alteration Contractor with the carpentry classification — the licence that actually covers this work, not a general contractor registration used as a proxy for one.',
  },
  {
    title:     'Five years on the joint',
    stat:      '5 years',
    statLabel: 'on the joinery itself',
    desc:      'In writing, on the joinery and the fixings: a joint that opens, a door that drops, a drawer that stops running. Seasonal movement in a solid panel is not a defect and is explained on the wood guide rather than buried in a warranty exclusion.',
  },
];

// ── Reviews ──────────────────────────────────────────────────────────────────
export const reviews = [
  {
    name:   'Marta Kuiper',
    detail: 'Heritage Hill · Alcove bookcases',
    rating: 5,
    quote:  'Two carpenters told me the alcoves were "close enough" to build square. Ruth put a level on the wall, showed me five-eighths of an inch, and explained what would happen at the top of a nine-foot case. I have looked for that gap for three years and it is not there.',
  },
  {
    name:   'Devon Achterberg',
    detail: 'Eastown · Window seat',
    rating: 5,
    quote:  'She talked me out of the bigger version of what I asked for and the quote went down. That is not a sales technique I had encountered before.',
  },
  {
    name:   'Priya Raghunathan',
    detail: 'Ottawa Hills · Pantry',
    rating: 5,
    quote:  'The number I signed in March was the number I paid in June. We made two changes and both came back as their own line with their own price before anything happened.',
  },
  {
    name:   'Tom Brühl',
    detail: 'East Grand Rapids · Kitchen advice',
    rating: 5,
    quote:  'Foursquare quoted the job and then told me that for a straight run against a flat wall I would be better off with stock cabinets and good trim. She did not get the work. She got this review and both my neighbours.',
  },
  {
    name:   'Hannah Ludema',
    detail: 'Cherry Hill · Media wall',
    rating: 5,
    quote:  'The chimney is off-centre in that room and I never noticed until she pointed it out, then could not stop noticing. She built the boxes different widths so the openings line up. It reads dead symmetrical and it is not.',
  },
  {
    name:   'Greg Osterhaven',
    detail: 'Baxter · Under-stair drawers',
    rating: 5,
    quote:  'A gap appeared under one drawer front in February and I assumed the worst. She had already written it down in the handover notes with the humidity numbers. It closed up again in May exactly as described.',
  },
];

// ── FAQ ──────────────────────────────────────────────────────────────────────
export const faqs = [
  {
    q: 'What does an alcove bookcase actually cost?',
    a: 'Between about $3,800 and $11,000 per alcove, supplied and installed. The spread is real, not evasive: paint-grade poplar capped at the picture rail with an open plinth sits near the bottom, and stain-grade white oak running to a coved ceiling with doors and drawers in the base sits near the top. The four things that move it are paint-grade versus stain-grade, height, doors versus open, and how far out of plumb the recess is. We publish ranges because a homeowner who cannot tell whether this is a $1,200 job or a $12,000 job usually just leaves.',
  },
  {
    q: 'What is your lead time?',
    a: 'We are currently quoting installs eight to ten weeks out. That covers drawings and sign-off, four to seven weeks on the bench, and the finishing schedule, which cannot be rushed without it showing. If you need something for a specific date, tell us at the survey and we will say yes or no then rather than in week six.',
  },
  {
    q: 'Would stock cabinets do the same job for less?',
    a: 'Sometimes, and we would rather say so at the survey. For a straight run against a flat, plumb wall, a stock carcase run with a decent face frame and good trim gets you most of the look for about a third of the money. Custom earns its price where the room is out of square: alcoves, bays, rakes, non-standard heights, and any wall that leans. If your job is the first kind, we will tell you and give you the name of a good fitter.',
  },
  {
    q: 'How much deposit do you take?',
    a: 'A third on signing the drawing and specification, a third when the carcases are built, and the balance on completion of the install. The first payment is what puts materials on the bench; the last one is not due until you have walked the piece with us.',
  },
  {
    q: 'Will the install damage my plaster?',
    a: 'Some, honestly. Fixings go into studs, and a scribe against a bellied wall sometimes needs the high spot knocked back. We patch and make good what we disturb, but we do not redecorate the room, and on a lath-and-plaster wall over a hundred years old we will always agree the fixing positions with you before anything goes in.',
  },
  {
    q: 'A gap has appeared in a panel since the winter. Is that a fault?',
    a: 'Almost certainly not. Grand Rapids goes from around 65% relative humidity in August to about 25% inside a heated house in January, and across that swing a 12-inch solid panel moves roughly an eighth of an inch across the grain. Panels are built to float for exactly this reason, so what you are seeing is the design working. If a joint has opened, or a door has dropped, that is different and it is covered.',
  },
  {
    q: 'Do you need my house empty, and for how long?',
    a: 'No. The build happens at the shop. Install is one to three days depending on the piece, in one room, with dust sheets and a vacuum running. The only thing we ask is clear access to the wall and somewhere to set up a bench, ideally a garage.',
  },
  {
    q: 'Can you match the existing trim in an old house?',
    a: 'Usually. We take a profile gauge to your casing or skirting and cut a matching knife if the run justifies it, or find the closest stock profile and tell you honestly how close it is. On quartersawn oak in a Craftsman house, matching the ray fleck matters more than matching the profile, and that is a timber selection problem rather than a machining one.',
  },
  {
    q: 'Do you do kitchens, furniture, or trim carpentry?',
    a: 'Built-ins only. Freestanding furniture is a different discipline and a different shop; whole kitchens want a designer and a fitter as well as a cabinetmaker; trim carpentry is a subcontract relationship with builders rather than something a homeowner buys. Doing one thing is why the lead time is eight to ten weeks instead of six months.',
  },
  {
    q: 'What does the five-year warranty actually cover?',
    a: 'The joinery and the fixings: a joint that opens, a carcase that racks, a door that drops out of alignment, a drawer that stops running. It does not cover seasonal movement in a solid panel, which is normal and is described in the wood guide, and it does not cover finish damage from use. Hardware carries its own manufacturer warranty, which we register in your name.',
  },
];
