import { test, expect } from '@playwright/test';

test.describe('Ovist Studio — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Ovist Studio/);
    await expect(page.locator('h1')).toContainText('buying permission');
  });

  test('handles the schema.org gap and claims no service area', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
    // Licence territory is a contract term, not a service area.
    expect(json).not.toContain('areaServed');
  });

  // ── The licence builder ─────────────────────────────────────────────────
  test('every combination of the three variables is present', async ({ page }) => {
    await page.goto('/');
    const media = await page.locator('input[name="media"]').count();
    const term = await page.locator('input[name="term"]').count();
    const terr = await page.locator('input[name="territory"]').count();
    expect(media * term * terr).toBe(27);
    expect(await page.locator('#licence .quote').count()).toBe(27);
  });

  test('uses real fieldsets and legends, not styled divs', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#licence form fieldset').count()).toBe(3);
    const legends = await page.locator('#licence form fieldset legend').allTextContents();
    expect(legends.map((l) => l.trim())).toEqual(['Media', 'Duration', 'Territory']);
  });

  test('exactly one price is visible at a time', async ({ page }) => {
    await page.goto('/');
    const visible = await page.locator('#licence .quote:visible').count();
    expect(visible).toBe(1);
  });

  // The whole point: it computes with scripts blocked.
  test('the calculator works with JavaScript disabled', async ({ browser }) => {
    const ctx = await browser.newContext({ javaScriptEnabled: false });
    const p = await ctx.newPage();
    await p.goto('/');
    await expect(p.locator('#licence .quote:visible')).toHaveCount(1);
    // Cheapest combination is the default.
    await expect(p.locator('#licence .quote:visible .fig')).toHaveText('$900');
    // Change two variables by clicking their labels; the figure must follow.
    await p.locator('label[for="m3"]').click();
    await p.locator('label[for="t3"]').click();
    await expect(p.locator('#licence .quote:visible')).toHaveCount(1);
    await expect(p.locator('#licence .quote:visible .fig')).toHaveText('$6,900');
    await ctx.close();
  });

  test('the price it shows equals base × the three multipliers', async ({ page }) => {
    await page.goto('/');
    // all media (2.4) · perpetual (3.2) · worldwide (2.2) · base 900 → 15,206 → 15,200
    await page.locator('label[for="m3"]').click();
    await page.locator('label[for="t3"]').click();
    await page.locator('label[for="r3"]').click();
    await expect(page.locator('#licence .quote:visible .fig')).toHaveText('$15,200');
    await expect(page.locator('#licence .quote:visible .terms'))
      .toHaveText('All media · Perpetual · Worldwide');
  });

  test('the radios stay keyboard-reachable rather than display:none', async ({ page }) => {
    await page.goto('/');
    const hidden = await page.locator('#licence input[type="radio"]').evaluateAll((els) =>
      els.filter((e) => {
        const s = getComputedStyle(e);
        return s.display === 'none' || s.visibility === 'hidden';
      }).length,
    );
    expect(hidden).toBe(0);
    await page.locator('#m2').focus();
    expect(await page.evaluate(() => document.activeElement?.id)).toBe('m2');
  });

  test('the output is a live region so a change is announced', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#licence .out')).toHaveAttribute('aria-live', 'polite');
  });

  // ── The estimate ────────────────────────────────────────────────────────
  test('the estimate total and fee share are summed from the lines', async ({ page }) => {
    await page.goto('/');
    const amts = await page.locator('#estimate .spend .amt').allTextContents();
    const nums = amts.map((a) => Number(a.replace(/[^0-9]/g, '')));
    const total = nums.reduce((a, b) => a + b, 0);
    const fee = Number((await page.locator('#estimate .spend li.is-fee .amt').textContent())!.replace(/[^0-9]/g, ''));
    const share = Math.round((fee / total) * 100);
    const line = await page.locator('#estimate .figure-lead').textContent();
    expect(line).toContain(`$${total.toLocaleString('en-US')}`);
    expect(line).toContain(`${share}%`);
    // The claim only holds if the fee really is a minority.
    expect(fee / total).toBeLessThan(0.5);
  });

  test('work is captioned with the licence rather than a client name', async ({ page }) => {
    await page.goto('/');
    const caps = await page.locator('#work figcaption').allTextContents();
    expect(caps.length).toBe(4);
    for (const c of caps) expect(c).toMatch(/(yr|perpetual)/i);
  });

  test('every work image has substantive alt text', async ({ page }) => {
    await page.goto('/');
    const alts = await page.locator('#work img').evaluateAll((e) => e.map((i) => i.getAttribute('alt') || ''));
    expect(alts.length).toBe(4);
    for (const a of alts) expect(a.length).toBeGreaterThan(30);
  });

  test('terms state that copyright stays with the studio', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#terms')).toContainText('Copyright');
    await expect(page.locator('#terms')).toContainText(/Stays with us/i);
    expect(await page.locator('#terms tbody tr').count()).toBe(6);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the brief form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 92.
  test('no trace of the day-92 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['ferrier', 'blunt', 'hudson', 'gloock', 'petrona']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro estimate template is absent from the free build', async ({ page }) => {
    const res = await page.goto('/estimate-template/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html.toLowerCase()).toContain('refresh');
  });
});
