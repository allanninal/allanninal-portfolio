// Ovist Studio — Milwaukee, WI.
//
// Third photography template in a row, so the angle differs in kind rather
// than in styling. Day 91 was what you receive, day 92 was who you are; this
// is what you are actually buying, which in commercial work is a licence.
// So the page's spine is a working licence builder rather than a gallery.

export const site = {
  name:        'Ovist Studio',
  shortName:   'Ovist',
  title:       'Ovist Studio — Commercial Photography in Milwaukee, WI',
  tagline:     'You are not buying photographs. You are buying permission.',
  owner:       'Halina Ovist',
  ownerRole:   'Commercial photographer',
  credential:  'Stills for product, food and interiors · Milwaukee',
  license:     'Commercial stills studio, established 2016',
  city:        'Milwaukee',
  state:       'WI',
  language:    'en',
  phoneDisplay: '(414) 555-0198',
  phoneHref:   '+14145550198',
  email:       'studio@ovist.example',
  streetAddress: '1830 N Martin Luther King Jr Dr',
  postalCode:  '53212',
  hours:       'Studio Mon–Fri · shoot days booked, not dropped in on',
  bookingWindow: 'Estimating for Q4. Two shoot days a week.',
  description:
    'A two-person commercial stills studio in Milwaukee. Every quote in this trade is ' +
    'a licence, not a set of pictures — so the calculator below is the actual pricing ' +
    'model, with all twenty-seven combinations on the page.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The licence', href: '#licence' },
  { label: 'The estimate', href: '#estimate' },
  { label: 'Work',        href: '#work' },
  { label: 'Terms',       href: '#terms' },
  { label: 'Brief us',    href: '#brief' },
];

// ── The licence model ─────────────────────────────────────────────────────
// Three variables that MULTIPLY. That is the part clients are never told, and
// it is why "just add print, worldwide, forever" is not a small change.

export const licence = {
  base: 900,
  note:
    'A licence fee is separate from the shoot. It is calculated from three things and ' +
    'they multiply rather than add, which is why extending all three at once moves the ' +
    'number so far. Every combination below is a real quote we would honour.',
  media: [
    { id: 'm1', label: 'Web and social',   sub: 'Owned channels only',            mult: 1.0 },
    { id: 'm2', label: 'Web plus print',   sub: 'Adds packaging, POS, press',     mult: 1.6 },
    { id: 'm3', label: 'All media',        sub: 'Adds outdoor and paid placement', mult: 2.4 },
  ],
  term: [
    { id: 't1', label: 'One year',   sub: 'From first use',        mult: 1.0 },
    { id: 't2', label: 'Three years', sub: 'The common choice',    mult: 1.8 },
    { id: 't3', label: 'Perpetual',  sub: 'No end date',           mult: 3.2 },
  ],
  territory: [
    { id: 'r1', label: 'National',  sub: 'United States',          mult: 1.0 },
    { id: 'r2', label: 'Europe',    sub: 'Adds EU and UK',         mult: 1.5 },
    { id: 'r3', label: 'Worldwide', sub: 'Everywhere, all languages', mult: 2.2 },
  ],
  exclusivityNote:
    'Exclusivity is a fourth variable and it is not on this calculator, because it is ' +
    'priced per project. It stops us licensing the same frames to anyone else for the ' +
    'term, so it costs roughly what the rest of the licence costs again.',
};

// ── Where an estimate actually goes ───────────────────────────────────────
// Worked from one real shape of job so the shares are checkable.

export const estimate = {
  // Evergreen claim; the exact share is computed from `lines` in the page,
  // so editing a line item can never leave the headline stating a stale figure.
  headline: 'The day rate is not the job.',
  intro:
    'A client sees a day rate and expects the estimate to be the day rate. Here is a ' +
    'two-day product shoot, itemised, with the licence stripped out so the production ' +
    'costs stand on their own. The creative fee is the largest single line and it is ' +
    'still a minority of the total.',
  lines: [
    { item: 'Creative fee, 2 shoot days', amount: 4800, isFee: true, note: 'The part everybody pictures when they hear “day rate”.' },
    { item: 'Pre-production, 1.5 days',   amount: 1200, note: 'Treatment, shot list, sample wrangling, scheduling. Skipping it is how shoot days overrun.' },
    { item: 'Digital tech and assisting', amount: 1100, note: 'Two people. One shoots, one keeps the files alive and the set moving.' },
    { item: 'Studio hire, 2 days',        amount: 1400, note: 'Daylight studio with a cyc wall. Cheaper on location, and location has its own costs.' },
    { item: 'Kit and grip hire',          amount:  650, note: 'What we do not own. Honest line: some studios bury this in the day rate.' },
    { item: 'Props and surfaces',         amount:  480, note: 'Bought, and yours afterwards if you want them.' },
    { item: 'Retouching, 24 finals',      amount: 1900, note: 'Roughly 40 minutes a frame. This is the line clients cut and then regret.' },
  ],
  closing:
    'None of the above is a licence. The licence is the calculator above and it is quoted ' +
    'separately, every time, so you can see which half of the number you are moving.',
};

// ── Work ──────────────────────────────────────────────────────────────────
// Alt strings written from looking at each file. Two earlier candidates were
// dropped for legible brand marks their source pages claimed were absent.

export const work = [
  { file: 'w01.jpg', cap: 'Footwear · web + print, 3 yr, national',
    alt: 'A pair of black patent oxford shoes arranged on a white plinth against an ochre background' },
  { file: 'w02.jpg', cap: 'Natural product · web and social, 1 yr, national',
    alt: 'Bee pollen granules in a glass bowl beside a spoonful, on woven hessian cloth' },
  { file: 'w03.jpg', cap: 'Confectionery · all media, perpetual, worldwide',
    alt: 'A cocoa-dusted truffle sitting in a bed of loose cocoa powder' },
  { file: 'w04.jpg', cap: 'Interior · web and social, 3 yr, Europe',
    alt: 'A white ribbed architectural interior converging on a bright vertical slot of daylight' },
];

export const workNote =
  'Each caption is the licence that was actually bought, which is a more useful thing ' +
  'to show a prospective client than the client’s name.';

// ── Terms worth reading twice ─────────────────────────────────────────────

export const terms = [
  { term: 'Copyright',   plain: 'Stays with us unless it is assigned in writing. That is the default under US law and it is true of every photographer you will brief, whether or not they raise it.' },
  { term: 'Assignment',  plain: 'Buying the copyright outright is possible and is a separate transaction with its own price. Most clients do not need it and are quoted for it because they asked using the wrong word.' },
  { term: 'The term starts', plain: 'At first use, not at delivery. Sitting on the files for eight months does not shorten your licence.' },
  { term: 'Renewal',     plain: 'Quoted at the same rate as the original licence, not at a penalty. A renewal is not a hostage situation and we will remind you before it lapses.' },
  { term: 'Overrun',     plain: 'A shoot day is ten hours including set-up. Beyond that it is $340 an hour and we will tell you at hour nine, not on the invoice.' },
  { term: 'Cancellation', plain: 'Free up to 14 days out. Inside 14 days it is 50%, inside 48 hours it is 100% — because the studio, the crew and the day are already committed.' },
];

export const faqs = [
  {
    q: 'Why not just sell us the pictures?',
    a: 'We can — that is an assignment, and it is quoted separately. It is usually several times the licence, and in nine cases out of ten the client wanted a broad licence rather than ownership and used the word “buy” because it is the normal word.',
  },
  {
    q: 'The calculator gives a bigger number than I expected.',
    a: 'Then narrow a variable. The most common overspend in this trade is buying perpetual worldwide all-media for a campaign that runs for one season on a website. Buy what you will use and renew if you are wrong.',
  },
  {
    q: 'Can we use the outtakes?',
    a: 'Not under the licence, which covers delivered finals. If you want the wider selection licensed, say so before the shoot and it costs very little; asking afterwards costs more because the frames have to be finished.',
  },
  {
    q: 'Do you work to a client’s art direction?',
    a: 'Gladly, and it usually makes the shoot faster. Bring a deck, a layout or even a scribble. What slows a day down is not strong direction, it is no direction discovered at 10am.',
  },
  {
    q: 'Who owns the props and surfaces?',
    a: 'You do, if the estimate has a props line on it and you paid it. We will box them up. Studios that keep them are recharging you for the same marble slab every quarter.',
  },
  {
    q: 'What if we hate the results?',
    a: 'You will see frames on set as we go, so it should never get that far. If it does, we reshoot once at cost — you cover the studio and crew, we waive the creative fee.',
  },
];
