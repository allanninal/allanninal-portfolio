// Grainline Automotive — Des Moines, IA.
//
// The page is one car's service ledger. Days 86 and 87 both argued "here is
// how this trade misleads you"; a third would be a house style rather than a
// distinct template. So this one accuses nobody and publishes evidence
// instead — including the times we recommended work that turned out not to
// have been needed.

export const site = {
  name:        'Grainline Automotive',
  shortName:   'Grainline',
  title:       'Grainline Automotive — Independent Auto Repair in Des Moines, IA',
  tagline:     'One car, 148,300 miles, every entry.',
  owner:       'Teodoro Ferrante',
  ownerRole:   'ASE Master Technician',
  credential:  'ASE Master Technician A1–A8 · L1 Advanced Engine Performance',
  license:     'ASE Master Technician certification A1–A8 with L1',
  city:        'Des Moines',
  state:       'IA',
  language:    'en',
  phoneDisplay: '(515) 555-0139',
  phoneHref:   '+15155550139',
  email:       'shop@grainlineauto.example',
  streetAddress: '2418 SE 14th St',
  postalCode:  '50320',
  labourRate:  '$139 per hour',
  labourGuide: 'Mitchell 1 published book time',
  diagFee:     '$120, applied to the repair if you go ahead',
  hours:       'Mon–Fri 7:30am–5:30pm · closed weekends',
  description:
    'An independent shop in Des Moines. Instead of a services list, this page publishes ' +
    'one customer car in full — 148,300 miles of work, what we recommended, what was ' +
    'declined, and which of those declines we turned out to be wrong about.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The ledger', href: '#ledger' },
  { label: 'Declines',   href: '#declines' },
  { label: 'Rates',      href: '#rates' },
  { label: 'Codes',      href: '#codes' },
  { label: 'Areas',      href: '#areas' },
  { label: 'FAQ',        href: '#faq' },
];

export const vehicle = {
  what:  '2016 Subaru Outback 2.5i Premium',
  since: 61_040,
  now:   148_300,
  owner: 'One owner, second-hand at 61,040 miles, still driving it.',
};

// ── The ledger ────────────────────────────────────────────────────────────
// status: done | declined | back | open
//   done     — work carried out
//   declined — recommended, customer said no
//   back     — a declined item that returned and cost more. `refs` points at
//              the entry where we first recommended it.
//   open     — recommended, still outstanding

export const ledger = [
  { id: 'e01', odo: 61_040,  date: 'Mar 2019', status: 'done',     what: 'Intake inspection',              cost: 120,  note: 'Baseline before we touched anything. Photographed and filed.' },
  { id: 'e02', odo: 64_500,  date: 'Aug 2019', status: 'done',     what: 'Oil and filter, tyre rotation',   cost: 89,   note: 'Routine. Rear pads measured at 6mm.' },
  { id: 'e03', odo: 71_200,  date: 'Jun 2020', status: 'done',     what: 'Front brake pads and rotors',     cost: 486,  note: 'Pads at 2mm. Rotors below minimum thickness, so they went with them.' },
  { id: 'e04', odo: 71_200,  date: 'Jun 2020', status: 'declined', what: 'Rear differential fluid',         cost: 0,    note: 'We recommended it at the same visit. Customer declined. Fair call — the factory interval is severe-service only.' },
  { id: 'e05', odo: 78_900,  date: 'Apr 2021', status: 'done',     what: 'Battery',                         cost: 214,  note: 'Failed a load test. Replaced before it stranded anyone.' },
  { id: 'e06', odo: 84_100,  date: 'Nov 2021', status: 'declined', what: 'Valve cover gasket, small seep',   cost: 0,    note: 'A damp seam, no drips, nothing on the driveway. We flagged it and said it could wait.' },
  { id: 'e07', odo: 92_600,  date: 'Sep 2022', status: 'done',     what: 'CVT fluid service',               cost: 328,  note: 'On the factory schedule at 90,000. Not a flush — a drain and fill, which is what Subaru specifies.' },
  { id: 'e08', odo: 96_300,  date: 'Feb 2023', status: 'declined', what: 'Rear wheel bearing, early noise',  cost: 0,    note: 'A faint hum on left-hand curves. We recommended replacement. Customer wanted to wait and hear it develop.' },
  { id: 'e09', odo: 103_800, date: 'Oct 2023', status: 'back',     what: 'Rear wheel bearing and hub',      cost: 612,  refs: 'e08', note: 'It developed. By the time it came back the hub had scored, so the repair was larger than the one declined at 96,300.' },
  { id: 'e10', odo: 109_400, date: 'May 2024', status: 'done',     what: 'Spark plugs, all four',           cost: 268,  note: 'Factory interval. Two were at the wear limit, two had a season left.' },
  { id: 'e11', odo: 112_000, date: 'Jul 2024', status: 'declined', what: 'Front sway bar end links',         cost: 0,    note: 'A light knock over expansion joints. Customer declined. Still quiet three years on — we were early.' },
  { id: 'e12', odo: 121_500, date: 'Mar 2025', status: 'done',     what: 'Timing belt, water pump, tensioner', cost: 1_284, note: 'The big one. Done as a set because the labour overlaps almost entirely.' },
  { id: 'e13', odo: 121_500, date: 'Mar 2025', status: 'declined', what: 'Serpentine belt',                  cost: 0,    note: 'We had it apart and recommended doing it while we were in there. Declined. It is still fine.' },
  { id: 'e14', odo: 130_200, date: 'Nov 2025', status: 'back',     what: 'Valve cover gasket',               cost: 397,  refs: 'e06', note: 'The seep from 84,100 became a drip onto the exhaust. Same gasket, plus cleaning what it had cooked onto.' },
  { id: 'e15', odo: 141_700, date: 'Apr 2026', status: 'done',     what: 'Rear brake pads',                  cost: 291,  note: 'Rotors measured in spec, so pads only. Seventy thousand miles on the rears.' },
  { id: 'e16', odo: 148_300, date: 'Aug 2026', status: 'open',     what: 'Front struts, both sides',         cost: 0,    note: 'Bounce test fails at the front. Not a safety defect yet. Our recommendation is this winter.' },
];

// ── What the declines are actually worth ──────────────────────────────────
// The honest arithmetic, computed in the page rather than asserted here.

export const declineNote =
  'We are not calibrated perfectly and this is the evidence. Where we were early, ' +
  'the customer saved the money. Where we were right, waiting cost more than doing ' +
  'it would have. Both columns are on this page because a shop that only publishes ' +
  'the second one is selling, not reporting.';

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  intro:
    'Labour is billed from published book time, not from a stopwatch. If the guide ' +
    'says an operation is 2.4 hours, that is what the invoice says whether it took ' +
    'us 1.8 or 3.1. That is normal across the trade and almost never explained, so ' +
    'here it is in writing along with which guide we use.',
  rows: [
    { what: 'Labour rate',                   figure: '$139 / hour' },
    { what: 'Labour guide',                  figure: 'Mitchell 1' },
    { what: 'Diagnostic, first hour',        figure: '$120' },
    { what: 'Diagnostic applied to repair',  figure: 'Yes, in full' },
    { what: 'Shop supplies',                 figure: '3% capped at $25' },
    { what: 'Parts markup',                  figure: 'Listed on the invoice' },
  ],
};

// ── Codes ─────────────────────────────────────────────────────────────────

export const codes = {
  intro:
    'A scan tool reads a code in about ninety seconds and plenty of places will do it ' +
    'for nothing. That is worth exactly what it costs, because a code names a symptom ' +
    'or a circuit — never a part.',
  rows: [
    { code: 'P0420', says: 'Catalyst efficiency below threshold, bank 1',
      blamed: 'Catalytic converter, $1,100–$1,900',
      alsoIs: 'A lazy upstream oxygen sensor, an exhaust leak before the sensor, or a misfire cooking the converter' },
    { code: 'P0171', says: 'System too lean, bank 1',
      blamed: 'Mass airflow sensor, $290–$480',
      alsoIs: 'An intake leak, a weak fuel pump, or a dirty MAF that only needed cleaning' },
    { code: 'P0300', says: 'Random or multiple cylinder misfire',
      blamed: 'Coils and plugs, $400–$700',
      alsoIs: 'A vacuum leak, low fuel pressure, or one injector — the code will not tell you which' },
    { code: 'P0442', says: 'Small evaporative emission leak',
      blamed: 'Purge valve, $180–$320',
      alsoIs: 'The fuel cap, roughly a third of the time, at no cost at all' },
  ],
  closing:
    'Reading the code is free here too. Finding which of those it actually is takes ' +
    'a technician and a couple of hours, and that is what the diagnostic fee buys.',
};

export const areas = [
  { zone: 'South side', towns: 'Indianola Hills, Gray’s Lake, Southwestern Hills' },
  { zone: 'East',       towns: 'East Village, Capitol Park, Pleasant Hill' },
  { zone: 'North',      towns: 'Beaverdale, Merle Hay, Highland Park' },
  { zone: 'Metro',      towns: 'West Des Moines, Ankeny, Urbandale, Altoona' },
];

export const reviews = [
  { name: 'Rosalind Achebe', town: 'Beaverdale',      text: 'They talked me out of a repair twice. The third time they said do it now, so I did it now, and I did not argue.' },
  { name: 'Emeka Lindqvist', town: 'West Des Moines', text: 'The invoice listed the book hours next to the parts. First shop I have used where I could check the arithmetic myself.' },
  { name: 'Fern Adeyemi',    town: 'Ankeny',          text: 'Chain place told me catalytic converter, eighteen hundred dollars. Grainline found an exhaust leak ahead of the sensor. Three hundred and change.' },
  { name: 'Casimir Oduya',   town: 'East Village',    text: 'They keep the whole history. I asked what the car had had done in 2021 and got an answer in about four seconds.' },
];

export const faqs = [
  {
    q: 'Why publish a car where you were wrong?',
    a: 'Because a shop that only shows the times it was right is showing you an advert. Four of the seven things this customer declined were fine to decline. If we hid that, the two that were not fine would mean nothing.',
  },
  {
    q: 'Is book time fair?',
    a: 'It is the trade standard and it cuts both ways — you pay the same when a bolt shears and the job takes us an extra hour. What is not fair is not being told which guide is being used, so ours is on this page.',
  },
  {
    q: 'Why charge for a diagnosis when the code is free?',
    a: 'The code is not the diagnosis. P0420 is caused by the converter often enough that people replace it, and by three cheaper things often enough that replacing it first is how you spend the money twice. The fee buys the hours that tell those apart, and it comes off the repair.',
  },
  {
    q: 'Do you work on cars you did not sell parts for?',
    a: 'Yes. Bring your own parts if you want to — we will fit them, and we will say plainly that the warranty then covers our labour and not the part.',
  },
  {
    q: 'Will you tell me if something can wait?',
    a: 'Every recommendation we make comes with what happens if it does not get done, in words. Sixteen entries on this page and four of them are things we said could wait.',
  },
  {
    q: 'Do you do state inspections?',
    a: 'Iowa does not require periodic safety inspections for passenger vehicles, so there is nothing to sell you there. If you want a pre-purchase inspection on a car you are buying, that is $145 and takes about ninety minutes.',
  },
];
