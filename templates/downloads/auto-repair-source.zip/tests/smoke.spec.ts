import { test, expect } from '@playwright/test';

test.describe('Grainline Automotive — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Grainline Automotive/);
    await expect(page.locator('h1')).toContainText('wrong');
  });

  // Third day running where schema.org has the exact type.
  test('uses the real AutoRepair schema type, not a fallback', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"AutoRepair"');
    expect(json).not.toContain('HomeAndConstructionBusiness');
    // The shop sells neither cars nor parts; claiming either would be a false signal.
    expect(json).not.toContain('AutoDealer');
    expect(json).not.toContain('AutoPartsStore');
  });

  // ── The ledger ──────────────────────────────────────────────────────────
  test('the ledger is an ordered list, because the order is load-bearing', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#ledger ol.ledger').count()).toBe(1);
    expect(await page.locator('#ledger li.entry').count()).toBe(16);
  });

  test('the odometer axis only ever increases', async ({ page }) => {
    await page.goto('/');
    const odos = await page.locator('#ledger .odo').evaluateAll((els) =>
      els.map((e) => Number((e.childNodes[0]?.textContent || '').replace(/[^0-9]/g, ''))),
    );
    expect(odos.length).toBe(16);
    for (let i = 1; i < odos.length; i++) expect(odos[i]).toBeGreaterThanOrEqual(odos[i - 1]);
  });

  test('every entry states its status in words, not only colour', async ({ page }) => {
    await page.goto('/');
    const s = await page.locator('#ledger .status').allTextContents();
    expect(s.length).toBe(16);
    for (const v of s) expect(['Done', 'Declined', 'Came back', 'Open']).toContain(v.trim());
  });

  // The point of publishing the ledger at all.
  test('a consequence links back to the decline that caused it', async ({ page }) => {
    await page.goto('/');
    const backs = page.locator('#ledger li.entry--back');
    expect(await backs.count()).toBe(2);
    for (const link of await backs.locator('.refback a').all()) {
      const href = await link.getAttribute('href');
      expect(href).toMatch(/^#e\d+$/);
      // The anchor must resolve to a real earlier entry, and that entry must be a decline.
      const target = page.locator(href!);
      await expect(target).toHaveCount(1);
      await expect(target.locator('.status')).toHaveText('Declined');
    }
  });

  // The arithmetic must be derived, not asserted — a 'back' entry is the
  // consequence of a decline already counted, so adding both double-counts.
  test('the decline arithmetic adds up against the ledger itself', async ({ page }) => {
    await page.goto('/');
    const counts = await page.locator('#ledger .status').evaluateAll((els) => {
      const out: Record<string, number> = {};
      for (const e of els) {
        const k = (e.textContent || '').trim();
        out[k] = (out[k] || 0) + 1;
      }
      return out;
    });
    const headline = await page.locator('#declines h2').textContent();
    // Declines counted once each; the two that came back are a subset of them.
    expect(headline).toContain(`${counts['Declined']} recommendations declined`);
    expect(headline).toContain(`${counts['Came back']} of them came back`);

    const stats = await page.locator('#declines dt').allTextContents();
    expect(stats.map(Number)).toEqual([
      counts['Declined'] - counts['Came back'],
      counts['Came back'],
      counts['Open'],
    ]);
  });

  test('the shop publishes both directions — times it was early and times it was right', async ({ page }) => {
    await page.goto('/');
    const d = page.locator('#declines');
    await expect(d).toContainText('were fine');
    await expect(d).toContainText('Came back worse');
    await expect(d).toContainText('$1,009');
  });

  test('the labour guide is named, not just the rate', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#rates');
    await expect(r).toContainText('$139 / hour');
    await expect(r).toContainText('Mitchell 1');
    await expect(r).toContainText(/book time/i);
  });

  test('codes are presented as symptoms with alternative causes', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#codes tbody tr');
    expect(await rows.count()).toBe(4);
    await expect(page.locator('#codes')).toContainText('P0420');
    // Every code must carry a cheaper alternative cause, or the section makes no point.
    for (const r of await rows.all()) {
      const cells = await r.locator('td').allTextContents();
      expect(cells[2].trim().length).toBeGreaterThan(20);
    }
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 87.
  test('no trace of the day-87 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['redoubt', 'spokane', 'marisol', 'locksmith', 'deadbolt', 'brass']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro deferral guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/deferral-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Four answers');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
