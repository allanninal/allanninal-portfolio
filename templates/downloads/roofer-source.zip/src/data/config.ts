// Ridgeline Roofing Co. — configuration data
// Day 72 of the 365-template roadmap

export const roofer = {
  name:        'Ridgeline Roofing Co.',
  tagline:     "Oklahoma City's Storm-Damage Roofers — Free Inspections, Insurance Claims Handled",
  description: 'Registered, insured roofing contractor serving Oklahoma City and the metro. Roof replacement, hail and wind damage repair, free inspections, gutters, and commercial flat roofing. We handle the insurance claim with you.',
  phone:       '(405) 555-0182',
  phoneHref:   'tel:+14055550182',
  email:       'hello@ridgelineroofingco.com',
  address:     '1420 S Meridian Ave',
  city:        'Oklahoma City',
  state:       'OK',
  zip:         '73108',
  license:     'OK Roofing Contractor Registration #RC-80417',
  licensed:    true,
  insured:     true,
  bonded:      true,
  founded:     2009,
  yearsExperience: 16,
  bookUrl:     '#',
  // Roofing is sold on the roof you cannot see. Every number a homeowner is asked
  // to trust — the warranty, the crew, the claim rate — is stated here once and
  // reused, so the page never contradicts itself.
  warrantyYears: 10,
  crewSize: 12,
  roofsCompleted: 3800,
  owner: {
    name:     'Dale Whitaker',
    title:    'Owner & Lead Estimator',
    initials: 'DW',
    bio:      "I started Ridgeline in 2009, the spring after a hailstorm took out half the roofs in my own neighbourhood and brought a wave of out-of-state crews with it. Most were gone before the first winter, and the homeowners they left behind called people like me to fix work that was already failing. I built this company to be the opposite of that: local crews, a real office you can drive to, and a workmanship warranty from a company that will still be here to honour it. In sixteen years we have put on more than 3,800 roofs across the metro, and I still climb most of the inspections myself.",
  },
  instagram: '#',
  facebook:  '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Ridgeline Roofing Co. — Roofing Contractor, Oklahoma City',
  description:   'Registered, insured roofers in Oklahoma City. Roof replacement, hail and wind damage, free inspections, gutters and flat roofing. We handle the insurance claim.',
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

export const services = [
  {
    slug:     'roof-replacement',
    name:     'Roof Replacement',
    icon:     'shingle',
    tagline:  'Full tear-off, decking checked, roof on in a day or two.',
    desc:     'Complete tear-off and replacement on asphalt shingle, metal and tile. We strip to the deck rather than laying over, so rotten sheathing gets found and replaced instead of hidden under a new roof.',
    includes: [
      'Complete tear-off to the deck',
      'Decking replaced as needed, priced per sheet up front',
      'Ice-and-water shield at eaves and valleys',
      'Synthetic underlayment throughout',
      'Ridge ventilation sized to the attic',
    ],
  },
  {
    slug:     'storm-damage',
    name:     'Hail & Wind Damage',
    icon:     'storm',
    tagline:  'Free inspection, documented for the adjuster.',
    desc:     'Hail bruising rarely leaks on the day it happens, which is why so many claims are filed late and denied. We inspect, photograph and mark every strike on a diagram an adjuster can follow.',
    includes: [
      'Free inspection within 48 hours',
      'Test square chalked on every damaged slope',
      'Dated close-range photographs of each strike',
      'We meet your adjuster on the roof',
      'Supplements and re-inspections filed for you',
    ],
  },
  {
    slug:     'roof-repair',
    name:     'Roof Repair',
    icon:     'wrench',
    tagline:  'Leaks traced to the source, not just patched.',
    desc:     'Active leaks, missing shingles, failed flashing, cracked boots and valleys. Water rarely enters where it appears inside, so we trace it from the stain up before quoting anything.',
    includes: [
      'Leak traced from the stain to the entry point',
      'Flat-rate price quoted before we start',
      'Flashing, boot and valley repairs',
      'Repair credited against a replacement within 12 months',
      '2-year warranty on the repair itself',
    ],
  },
  {
    slug:     'inspections',
    name:     'Roof Inspections',
    icon:     'clipboard',
    tagline:  'Photographed, written up, no obligation.',
    desc:     'Shingles, flashing, penetrations, gutters, ventilation and attic decking, delivered as a written report. Standard before a sale, after a storm, or once a roof passes fifteen years.',
    includes: [
      'Full roof and attic check where accessible',
      'Photographs of everything flagged',
      'Written report emailed the same day',
      'An honest answer on remaining life',
      'Free, and yours to keep either way',
    ],
  },
  {
    slug:     'gutters',
    name:     'Gutters & Downspouts',
    icon:     'gutter',
    tagline:  'Seamless, sized to the roof, not to the truck.',
    desc:     'Seamless aluminium formed on site and sized to the actual roof area rather than a default five inch, with downspouts placed to move water away from the foundation.',
    includes: [
      'Seamless gutters formed on site',
      'Sized to the roof area, 5 or 6 inch',
      'Downspouts placed away from the foundation',
      'Guards available',
      'Best done during a roof replacement',
    ],
  },
  {
    slug:     'commercial-flat',
    name:     'Commercial & Flat Roofing',
    icon:     'building',
    tagline:  'TPO, EPDM and modified bitumen.',
    desc:     'Flat and low-slope roofing for small commercial buildings, restaurants and warehouses, including tapered insulation to fix ponding rather than sealing over it every year.',
    includes: [
      'TPO and EPDM single-ply membrane',
      'Modified bitumen systems',
      'Tapered insulation to correct ponding',
      'Scheduled maintenance programmes',
      'Low-slope sections on residential roofs',
    ],
  },
];

// Materials matter more to a roofing buyer than to almost any other trade: the
// choice sets the price, the lifespan and the insurance treatment all at once.
export const materials = [
  {
    name:     'Architectural asphalt shingle',
    life:     '25 to 30 years',
    best:     'Most homes in the metro',
    note:     'The default for good reason: impact-resistant Class 4 options can lower your premium, and repairs are cheap because every crew stocks the parts.',
  },
  {
    name:     'Standing-seam metal',
    life:     '40 to 70 years',
    best:     'Long-term owners, steep slopes',
    note:     'Costs roughly double asphalt and pays back over decades. Sheds hail well, but a dented panel is cosmetic rather than structural, and insurers treat it that way.',
  },
  {
    name:     'Concrete or clay tile',
    life:     '50+ years',
    best:     'Homes already framed for the weight',
    note:     'Beautiful and long-lived, but heavy. If a house was not built for tile the framing has to be checked first, and that is an engineer’s call rather than a roofer’s.',
  },
  {
    name:     'TPO or EPDM membrane',
    life:     '20 to 30 years',
    best:     'Flat and low-slope sections',
    note:     'Most homes in the area have at least one low-slope section over a porch or addition. It cannot take shingles, and putting them there anyway is a leak with a date on it.',
  },
];

export const whyUs = [
  {
    title:     'We meet your adjuster on the roof',
    stat:      '100%',
    statLabel: 'of claims attended',
    desc:      'A claim is paid from a scope written on the day the adjuster climbs up. If nobody who works for you is standing there when it is written, it gets written without you.',
  },
  {
    title:     'Local crews, not storm chasers',
    stat:      '16',
    statLabel: 'years in the metro',
    desc:      'Twelve people on staff, all local. After a big hail event the city fills with out-of-state trucks that will not be here when a warranty claim comes in three winters later.',
  },
  {
    title:     '10-year workmanship warranty',
    stat:      '10 yr',
    statLabel: 'on our installation',
    desc:      'Separate from the manufacturer warranty and issued in writing. Almost every roof that fails early fails on installation rather than on the shingle, and that is the part we stand behind.',
  },
  {
    title:     'We will tell you not to replace it',
    stat:      '3,800+',
    statLabel: 'roofs since 2009',
    desc:      'Plenty of roofs we inspect have five good years left. We say so, write it down, and come back when it is actually time. A free inspection that always finds a replacement is a sales call.',
  },
];

export const serviceArea = [
  {
    zone:          'Oklahoma City',
    neighborhoods: ['Downtown', 'Midtown', 'Nichols Hills', 'The Village', 'Warr Acres', 'Bethany'],
    zips:          ['73102', '73103', '73116', '73120', '73122', '73008'],
  },
  {
    zone:          'North Metro',
    neighborhoods: ['Edmond', 'Guthrie', 'Piedmont', 'Deer Creek', 'Arcadia', 'Luther'],
    zips:          ['73003', '73013', '73044', '73078', '73007', '73054'],
  },
  {
    zone:          'South Metro',
    neighborhoods: ['Moore', 'Norman', 'Newcastle', 'Blanchard', 'Noble', 'Washington'],
    zips:          ['73160', '73069', '73065', '73010', '73068', '73093'],
  },
  {
    zone:          'East & West',
    neighborhoods: ['Midwest City', 'Del City', 'Choctaw', 'Yukon', 'Mustang', 'El Reno'],
    zips:          ['73110', '73115', '73020', '73099', '73064', '73036'],
  },
];

// The gallery is the whole reason a homeowner stays on a roofing site. Each entry
// carries the problem, not just the picture, because a roof photograph on its own
// tells a homeowner nothing they can judge.
export const gallery = [
  {
    slug:     'edmond-hail-replacement',
    title:    'Full replacement after April hail',
    location: 'Edmond, OK',
    material: 'Class 4 architectural shingle',
    days:     '2 days',
    problem:  'Golf-ball hail bruised the entire south and west slopes. No leak yet, and the claim had eleven days left on it.',
    outcome:  'Full approval on the first adjuster meeting. Upgraded to Class 4 for a premium discount that paid the deductible back in four years.',
    tone:     'storm',
  },
  {
    slug:     'norman-valley-leak',
    title:    'A leak that was not where the stain was',
    location: 'Norman, OK',
    material: 'Repair, existing shingle',
    days:     'Half a day',
    problem:  'Ceiling stain over the dining room. Two previous crews had sealed the ceiling penetration directly above it. It kept coming back.',
    outcome:  'Water was entering nine feet uphill at a failed valley and running along a rafter. Valley rebuilt, stain never returned.',
    tone:     'repair',
  },
  {
    slug:     'okc-standing-seam',
    title:    'Standing seam over a 12/12 pitch',
    location: 'Oklahoma City, OK',
    material: 'Standing-seam metal, 24 gauge',
    days:     '5 days',
    problem:  'Owners on their third asphalt roof in twenty-two years on a steep, unshaded south face that cooked every shingle it was given.',
    outcome:  'Concealed-fastener standing seam with a high-temp underlayment. Expected to outlast the next two owners.',
    tone:     'replacement',
  },
  {
    slug:     'moore-decking',
    title:    'The part nobody sees until tear-off',
    location: 'Moore, OK',
    material: 'Architectural shingle, 14 sheets of decking',
    days:     '3 days',
    problem:  'Quoted by two companies as a straight lay-over. Tear-off found fourteen sheets of decking soft enough to step through.',
    outcome:  'Decking replaced before the new roof went on. This is the reason we do not quote lay-overs, and why our number is sometimes the higher one.',
    tone:     'replacement',
  },
  {
    slug:     'bethany-flat-tpo',
    title:    'Ponding fixed with slope, not sealant',
    location: 'Bethany, OK',
    material: 'TPO with tapered insulation',
    days:     '4 days',
    problem:  'A small restaurant with standing water on a flat roof after every rain, patched annually for six years.',
    outcome:  'Tapered insulation built the fall the roof never had, then a single-ply TPO membrane over it. Dry within an hour of rain stopping.',
    tone:     'commercial',
  },
  {
    slug:     'yukon-gutters',
    title:    'Gutters sized to the roof',
    location: 'Yukon, OK',
    material: 'Seamless 6-inch aluminium',
    days:     '1 day',
    problem:  'Five-inch gutters overflowing at every downpour and washing out a foundation bed on the north side.',
    outcome:  'Six-inch seamless with two added downspouts, discharging eight feet out. The flowerbed has stayed put through two springs.',
    tone:     'gutters',
  },
];

export const process = [
  {
    step:  '1',
    title: 'Free inspection',
    desc:  'We are on the roof within 48 hours, usually sooner after a storm. Photographs of everything we flag, and a written report whether or not you use us.',
  },
  {
    step:  '2',
    title: 'The honest number',
    desc:  'A written scope with the material, the underlayment, the ventilation and the decking allowance spelled out. If it is a repair rather than a replacement, that is what you get quoted.',
  },
  {
    step:  '3',
    title: 'Claim, if there is one',
    desc:  'We file with you, meet the adjuster on the roof, and hand over our own documentation. You pay your deductible; we do not offer to waive it, because that is insurance fraud.',
  },
  {
    step:  '4',
    title: 'The work',
    desc:  'Most residential roofs are one or two days. Magnetic sweep of the whole property every evening, and again on the last day. Your yard should look untouched.',
  },
  {
    step:  '5',
    title: 'Final walk and warranty',
    desc:  `We walk it with you, then issue the ${roofer.warrantyYears}-year workmanship warranty and register the manufacturer warranty in your name. Both arrive by email the same week.`,
  },
];

export const pricing = [
  {
    name:     'Roof Inspection',
    price:    'Free',
    period:   'no obligation',
    tag:      '',
    featured: false,
    cta:      'Book an Inspection',
    desc:     'A full roof, flashing and attic check, photographed and written up. We will tell you when a roof has years left in it.',
    includes: [
      'Full roof, flashing and penetration check',
      'Attic and decking check where accessible',
      'Photographs of everything flagged',
      'Written report, emailed the same day',
      'Yours to keep whether or not you use us',
    ],
  },
  {
    name:     'Roof Repair',
    price:    'From $385',
    period:   'flat rate per repair',
    tag:      'Most Common',
    featured: true,
    cta:      'Request a Repair',
    desc:     'Leaks traced to the source and quoted flat-rate before we start. Credited back if the roof turns out to need replacing within the year.',
    includes: [
      'Leak traced to source, not to the stain',
      'Flashing, boot and valley repairs',
      'Missing and wind-lifted shingle replacement',
      'Credited against a replacement within 12 months',
      '2-year warranty on the repair',
    ],
  },
  {
    name:     'Full Replacement',
    price:    'From $9,400',
    period:   'typical 2,000 sq ft roof',
    tag:      '',
    featured: false,
    cta:      'Get an Estimate',
    desc:     'Tear-off to the deck, decking priced per sheet up front, and two warranties in your name at the end of it.',
    includes: [
      'Complete tear-off to the deck',
      'Decking replaced as needed, priced per sheet',
      'Ice-and-water shield and synthetic underlayment',
      'Ridge ventilation sized to the attic',
      '10-year workmanship warranty in writing',
      'Manufacturer warranty registered to you',
    ],
  },
];

export const reviews = [
  {
    name:   'Marcy Ellison',
    detail: 'Edmond · Roof repair',
    rating: 5,
    quote:  'Two other companies told me I needed a full roof. Dale went up, came down, and said I had about six years left, and showed me the photographs. He fixed a boot for $340. I have never had a contractor talk himself out of a job before.',
  },
  {
    name:   'Ray Dominguez',
    detail: 'Moore · Full replacement',
    rating: 5,
    quote:  'They found fourteen sheets of bad decking after tear-off and had already told me what each sheet would cost, so there was no argument on the day. The final invoice matched the estimate plus the decking, to the dollar.',
  },
  {
    name:   'Priya Raghunathan',
    detail: 'Norman · Hail claim',
    rating: 5,
    quote:  'My claim was initially denied. Ridgeline came back out, re-documented the west slope, and met the second adjuster on the roof. Approved. I would not have known that was even an option.',
  },
  {
    name:   'Curtis Vaughn',
    detail: 'Oklahoma City · Full replacement',
    rating: 5,
    quote:  'Crew was here at seven and done by four the next day, and I could not find a single nail in the yard afterwards. They ran the magnet twice while I watched.',
  },
];

export const faqs = [
  {
    q: 'How do I know if I have hail damage? Nothing is leaking.',
    a: 'Most hail damage does not leak for a year or more. It bruises the mat under the granules, the granules wash off, and the shingle then ages several times faster. That is why claims get filed late and denied. If a storm dropped hail of any size on your street, get it looked at while the claim window is open.',
  },
  {
    q: 'How long do I have to file a hail claim?',
    a: 'In Oklahoma most policies give you one to two years from the date of the storm, but the practical limit is shorter: the older the damage, the harder it is to tie to a specific date, and insurers do deny on that. If you think you were hit, get it documented now even if you do not file.',
  },
  {
    q: 'Will you waive my deductible?',
    a: 'No, and you should walk away from anyone who offers to. It is insurance fraud in Oklahoma, it voids your claim, and it means the work is being funded by cutting something you cannot see from the ground.',
  },
  {
    q: 'Do I have to use the contractor my insurer recommends?',
    a: 'No. You choose the contractor. Your insurer decides what it will pay, which is a different question. A preferred-vendor list is a convenience, not a requirement.',
  },
  {
    q: 'Can you just go over the old shingles?',
    a: 'We do not. A lay-over hides the decking, which is exactly where the expensive surprises live, it voids most manufacturer warranties, and it adds weight to a structure that was designed for one layer. It is cheaper on the day and more expensive over the life of the roof.',
  },
  {
    q: 'How long does a replacement take?',
    a: 'A typical single-family roof is one to two days from tear-off to final sweep. Steep pitches, metal and tile take longer. We give you the number before we start, and we do not leave a roof open overnight.',
  },
  {
    q: 'What does the warranty actually cover?',
    a: `Two separate things. The manufacturer warranty covers the material and is registered in your name. Our ${roofer.warrantyYears}-year workmanship warranty covers installation: flashing, fastening, ventilation and anything we did. Nearly every early roof failure is workmanship, so that is the one that matters most.`,
  },
  {
    q: 'Do you do gutters at the same time?',
    a: 'Yes, and it is the right time to do it. Gutters have to come off for a proper tear-off anyway, so replacing them during the roof costs less than doing it as its own visit.',
  },
];
