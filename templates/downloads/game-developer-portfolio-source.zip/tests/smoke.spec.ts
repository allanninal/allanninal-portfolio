import { test, expect } from '@playwright/test';

test.describe('Casper Lind — smoke tests', () => {
  test('homepage renders with the developer name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Casper Lind/);
    await expect(page.locator('h1')).toContainText('The cut list is the portfolio');
  });

  test('is marked up as a Person, with no business-only fields', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q1350189');
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // Days 106-107 shipped a hidden spine and a silently-timing-out suite. Assert
  // the thing a reader would notice first: that the page is actually there.
  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const table = page.locator('#cuts table.cuts');
    await expect(table).toBeVisible();
    await expect(table.locator('tbody tr').first()).toBeVisible();
    const box = await table.boundingBox();
    expect(box!.height).toBeGreaterThan(400);
  });

  // ── The cut list ────────────────────────────────────────────────────────
  test('the tallies are computed from the table, not typed', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#cuts tbody tr');
    const cut = await rows.count();
    expect(cut).toBe(18);
    const weeks = (await page.locator('#cuts .weeks').allTextContents())
      .map((t) => Number(t.replace(' w', ''))).reduce((a, b) => a + b, 0);
    const tally = page.locator('#cuts dl.tally dd');
    const designed = Number(await tally.nth(0).textContent());
    await expect(tally.nth(1)).toHaveText(String(designed - cut));
    await expect(tally.nth(2)).toHaveText(String(cut));
    await expect(tally.nth(3)).toHaveText(String(weeks));
    await expect(page.locator('#cuts h2'))
      .toHaveText(`${designed} designed. ${designed - cut} shipped. ${cut} cut.`);
    await expect(page.locator('h1 ~ div a').first()).toContainText(`${cut} cuts`);
  });

  test('every cut row states a cost and an add-it-back answer', async ({ page }) => {
    await page.goto('/');
    for (const r of await page.locator('#cuts tbody tr').all()) {
      await expect(r.locator('.weeks')).toContainText(/^\d+ w$/);
      const back = ((await r.locator('.back').textContent()) || '').trim();
      expect(['Yes', 'No']).toContain(back);
    }
  });

  // The honest column: at least one row admits the cut was wrong.
  test('the developer names the cuts they would reverse', async ({ page }) => {
    await page.goto('/');
    const backs = (await page.locator('#cuts .back').allTextContents()).map((s) => s.trim());
    const yes = backs.filter((b) => b === 'Yes').length;
    expect(yes).toBeGreaterThan(0);
    await expect(page.locator('#cuts')).toContainText(`${yes} of ${backs.length} I would put back`);
  });

  test('state colours are not the accent', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--state-shipped', '--state-cut', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  // ── Frame budget ────────────────────────────────────────────────────────
  test('the frame budget uses real meter elements inside the target', async ({ page }) => {
    await page.goto('/');
    const meters = page.locator('#budget meter');
    const n = await meters.count();
    expect(n).toBeGreaterThan(5);
    let sum = 0;
    for (const m of await meters.all()) {
      const v = Number(await m.getAttribute('value'));
      const max = Number(await m.getAttribute('max'));
      expect(v).toBeGreaterThan(0);
      expect(v).toBeLessThan(max);
      sum += v;
    }
    const target = Number(await meters.first().getAttribute('max'));
    expect(sum).toBeLessThan(target);
    await expect(page.locator('#budget')).toContainText(`${sum.toFixed(1)} / ${target} ms`);
  });

  test('the headline frame times are summed from the list', async ({ page }) => {
    await page.goto('/');
    const cells = await page.locator('#budget .ms').allTextContents();
    let now = 0, was = 0;
    for (const c of cells) {
      const m = c.match(/([\d.]+) ms\s*·?\s*was ([\d.]+)/);
      expect(m).not.toBeNull();
      now += Number(m![1]); was += Number(m![2]);
    }
    await expect(page.locator('#budget h2'))
      .toHaveText(`${was.toFixed(1)} ms at first. ${now.toFixed(1)} at ship.`);
    expect(now).toBeLessThan(was);
  });

  // ── The graveyard ───────────────────────────────────────────────────────
  test('the abandoned projects outnumber the shipped ones and are named', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#graveyard tbody tr');
    const n = await rows.count();
    expect(n).toBe(5);
    // Count the state labels, not every occurrence of the word: one blurb reads
    // "Shipped on PC", and the first version of this test counted that too and
    // blamed the page for its own bad heuristic.
    const labels = (await rows.locator('.state-label').allTextContents()).map((s) => s.trim());
    expect(labels.length).toBe(n);
    const shipped = labels.filter((l) => l === 'Shipped').length;
    const abandoned = labels.filter((l) => l === 'Abandoned').length;
    expect(abandoned).toBeGreaterThan(shipped);
    await expect(page.locator('#graveyard h2')).toHaveText(`${n} projects. ${shipped} finished.`);
    // and every project says how long it ran, which is the number that matters
    for (const r of await rows.all()) {
      expect(await r.locator('td.weeks').count()).toBe(2);
    }
  });

  test('the devlog is collapsed on arrival and every entry is dated', async ({ page }) => {
    await page.goto('/');
    const entries = page.locator('#devlog details');
    const n = await entries.count();
    expect(n).toBeGreaterThan(4);
    await expect(page.locator('#devlog h2')).toContainText(`${n} entries`);
    for (const e of await entries.all()) {
      expect(await e.getAttribute('open')).toBeNull();
      const t = e.locator('time');
      await expect(t).toHaveAttribute('datetime', /^\d{4}-\d{2}-\d{2}$/);
    }
    const first = entries.first();
    await first.locator('summary').click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('there are no fabricated screenshots and the FAQ says why', async ({ page }) => {
    await page.goto('/');
    const raster = await page.locator('img').evaluateAll((imgs) =>
      imgs.map((i) => i.getAttribute('src') || '').filter((s) => /\.(jpe?g|png|webp|avif)$/i.test(s)));
    expect(raster).toEqual([]);
    await expect(page.locator('#faq')).toContainText(/the game is fictional/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the contact form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-107 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['idris falk', 'reno', 'compositor', 'greenscreen', 'rig removal', 'q1047162']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro scope sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/scope-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
