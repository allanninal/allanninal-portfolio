// Casper Lind — Ann Arbor, MI.
//
// Out of the reel cluster. Every indie developer's portfolio is screenshots of
// what exists; the thing that actually separates a developer who ships from
// one who does not is the cut list, and nobody publishes it — partly because
// it reads as failure and mostly because it is the most revealing document a
// developer has.
//
// Every total in the copy is computed from the arrays below.

export const site = {
  name:        'Casper Lind',
  shortName:   'Casper Lind',
  title:       'Casper Lind — Game developer, Ann Arbor',
  tagline:     'The cut list is the portfolio.',
  owner:       'Casper Lind',
  ownerRole:   'Gameplay and systems programmer',
  credential:  'Two shipped titles, three abandoned, since 2017',
  city:        'Ann Arbor',
  state:       'MI',
  language:    'en',
  phoneDisplay: '(734) 555-0151',
  phoneHref:   '+17345550151',
  email:       'casper@casperlind.example',
  streetAddress: '318 S Ashley St',
  postalCode:  '48104',
  hours:       'Mon–Fri · async, email or issue tracker',
  bookingWindow: 'Open to contract work from the middle of next month.',
  description:
    'A gameplay and systems programmer in Ann Arbor. Every portfolio in this trade shows what ' +
    'shipped. This one leads with what did not — the eighteen features cut from a finished ' +
    'game, what each would have cost, and the two I would put back today.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The cut list', href: '#cuts' },
  { label: 'Frame budget', href: '#budget' },
  { label: 'The graveyard', href: '#graveyard' },
  { label: 'Devlog',       href: '#devlog' },
  { label: 'Rates',        href: '#rates' },
  { label: 'Contact',      href: '#contact' },
];

// ── The cut list ──────────────────────────────────────────────────────────
// One shipped game. `shipped` is the count that stayed in; the rows below are
// the ones that did not. `back` is the honest column — two of them are 'yes'.

export const game = {
  title: 'Tidewrack',
  what: 'A single-player salvage sim. Eleven hours long, shipped on PC in 2025.',
  designed: 40,
  devWeeksSpent: 74,
};

export const cuts = [
  { feature: 'Multiplayer co-op',            why: 'Would have been the single largest system in the game and touched every other one.', weeks: 22, back: 'no' },
  { feature: 'Procedural wreck generation',  why: 'Twelve hand-built wrecks read better than a hundred generated ones, and the prototype proved it in a fortnight.', weeks: 9, back: 'no' },
  { feature: 'Base building',                why: 'A second game bolted to the first. Every playtester who asked for it stopped asking after being shown what it would replace.', weeks: 14, back: 'no' },
  { feature: 'Dynamic weather system',       why: 'Three weather states hand-authored per region did everything a simulation would have, at a twentieth of the cost.', weeks: 6, back: 'no' },
  { feature: 'Full voice acting',            why: 'Not a code problem. A budget and a rewrite-cost problem: every line change becomes a recording session.', weeks: 5, back: 'yes' },
  { feature: 'Crafting tree, tier 3+',       why: 'Playtests stalled at tier 2. The tree above it was content nobody reached and would have cost as much as the part they did.', weeks: 7, back: 'no' },
  { feature: 'Ship customisation, visual',   why: 'Pure cosmetics on a first-person game where you almost never see your own hull.', weeks: 4, back: 'no' },
  { feature: 'Photo mode',                   why: 'Cut for time, and it is the one that still stings — it is free marketing and players ask for it constantly.', weeks: 2, back: 'yes' },
  { feature: 'Localisation, 6 languages',    why: 'Deferred rather than cut. The strings were externalised from week one, which is why it was deferrable at all.', weeks: 5, back: 'no' },
  { feature: 'Achievements, full set',       why: 'Shipped with twelve rather than forty. Nobody has mentioned it once.', weeks: 2, back: 'no' },
  { feature: 'Underwater physics rewrite',   why: 'The existing one was wrong in ways only I could see, and I had to be told that twice.', weeks: 8, back: 'no' },
  { feature: 'NPC salvage rivals',           why: 'A genuinely good idea that needed AI, dialogue, an economy and a reputation system to work at all.', weeks: 16, back: 'no' },
  { feature: 'Mod support',                  why: 'A promise you cannot un-make. Better to ship without it than to ship a version that breaks every patch.', weeks: 6, back: 'no' },
  { feature: 'Steam Deck verification',      why: 'Deferred to a post-launch patch. It shipped nine weeks later and the delay cost nothing.', weeks: 3, back: 'no' },
  { feature: 'Companion drone',              why: 'Solved a problem the level design had already solved better.', weeks: 5, back: 'no' },
  { feature: 'Difficulty presets',           why: 'Replaced by four independent accessibility toggles, which turned out to be what people actually wanted.', weeks: 3, back: 'no' },
  { feature: 'Endgame prestige loop',        why: 'An eleven-hour game does not need a reason to play it for eighty.', weeks: 6, back: 'no' },
  { feature: 'In-engine cutscenes',          why: 'Replaced with static frames and audio. Cheaper, faster, and several reviewers named them as a strength.', weeks: 8, back: 'no' },
];

export const cutsNote =
  'Nobody publishes this, and the reason is that it reads as a list of failures. It is the ' +
  'opposite: it is the only evidence a developer can offer that they know how to finish ' +
  'something. Anybody can start forty features. The skill is in being able to say, in writing ' +
  'and in advance, which eighteen are not going to happen.';

// ── Frame budget ──────────────────────────────────────────────────────────
// 16.6 ms at 60 fps. `ms` is where it landed at ship; `was` is where it started.

export const frame = {
  target: 16.6,
  fps: 60,
  rows: [
    { sys: 'Rendering — opaque pass', ms: 4.1, was: 6.8, fix: 'Merged 340 draw calls into 41 with a static batcher. The single biggest win of the project and about two days of work.' },
    { sys: 'Rendering — water',       ms: 3.2, was: 5.9, fix: 'Half-resolution refraction buffer with a depth-aware upsample. Nobody has ever noticed.' },
    { sys: 'Physics',                 ms: 2.4, was: 2.6, fix: 'Barely moved. It was never the problem, which is why it is worth measuring before optimising.' },
    { sys: 'Gameplay and AI',         ms: 1.9, was: 4.2, fix: 'Salvage-node queries were running every frame for every actor. Now they run on a 200 ms timer and nothing feels different.' },
    { sys: 'UI',                      ms: 1.1, was: 3.4, fix: 'The inventory grid rebuilt its whole layout on every hover. This is embarrassing and it is also the most common bug of its kind.' },
    { sys: 'Audio',                   ms: 0.6, was: 0.7, fix: 'Left alone. Audio is almost never the frame problem and almost always blamed first.' },
    { sys: 'Everything else',         ms: 1.4, was: 2.1, fix: 'Garbage collection, mostly. Pooling the projectile and particle allocations removed the spikes.' },
  ],
  note:
    'A portfolio of screenshots cannot tell you whether somebody can find 2.3 ms in a UI layout ' +
    'pass. This is the document that can, and it is also a confession: every "was" column is a ' +
    'number I shipped in a build at some point before I measured it.',
};

// ── The graveyard ─────────────────────────────────────────────────────────

export const graveyard = [
  { name: 'Tidewrack',   year: '2025', state: 'shipped',   months: 17, why: 'Shipped on PC. The cut list above is this one.' },
  { name: 'Halfmoon Signal', year: '2021', state: 'shipped', months: 9, why: 'A two-hour narrative puzzle game. Made no money and taught me how to finish things, which was the more expensive lesson to skip.' },
  { name: 'Ferrous',     year: '2023', state: 'abandoned', months: 7,  why: 'The core loop was fun for eleven minutes and I could never find the twelfth. Stopped at month seven, which was about four months later than I should have.' },
  { name: 'Untitled roguelike', year: '2019', state: 'abandoned', months: 4, why: 'Abandoned because two better versions of it shipped while I was building mine. Correct decision, made too slowly.' },
  { name: 'Grove',       year: '2018', state: 'abandoned', months: 2,  why: 'A gardening sim I stopped because I did not want to play it. That is a legitimate reason and it took me years to believe it.' },
];

export const graveyardNote =
  'A developer with no abandoned projects has either not tried much or is not telling you about ' +
  'them. The interesting number is not how many stopped — it is how long each one took to stop, ' +
  'and that number has come down every time.';

// ── Devlog ────────────────────────────────────────────────────────────────
// Collapsed by default. A devlog that opens on arrival is a blog; a devlog
// that opens when you ask it to is a record.

export const devlog = [
  { date: '2026-07-14', title: 'The inventory grid was rebuilding on hover',
    body: 'Three point four milliseconds, every frame, for a layout that changed about twice a minute. Found it by profiling the UI pass on a hunch after a playtester said the game "felt heavy" — which is the vaguest useful bug report there is.' },
  { date: '2026-05-02', title: 'Cut base building, finally',
    body: 'Six weeks of arguing with myself. The thing that settled it was writing down what it would replace, which was nothing, and what it would cost, which was fourteen weeks. Both numbers had been in my head and neither had been on paper.' },
  { date: '2026-03-19', title: 'Externalised every string in week one',
    body: 'Not because localisation was planned — because it was cheap now and impossible later. It is the only decision on this list that cost nothing and saved a feature from being cut outright.' },
  { date: '2026-01-08', title: 'Static batching: 340 draw calls to 41',
    body: 'Two days, 2.7 ms. Every performance post says measure first and I still spent a week optimising physics before I did. Physics was 2.6 ms and had never been the problem.' },
  { date: '2025-11-23', title: 'Difficulty presets replaced with four toggles',
    body: 'Playtesters did not want "easy". They wanted the timer off, or the combat softer, or the reading larger. Four independent switches did more for accessibility than three presets ever would, and cost less.' },
  { date: '2025-09-30', title: 'Stopped Ferrous at month seven',
    body: 'The loop was fun for eleven minutes and I could not find the twelfth. Writing the post-mortem took an afternoon; admitting it took four months. That gap is the thing I am actually trying to shorten.' },
];

export const said = {
  text: 'The cut list was what got him the contract. Everyone sends a build and a trailer. He sent a spreadsheet of what he decided not to build and why, and it answered the only question we actually had.',
  who: 'Technical director, mid-size studio — on a contract hire',
};

export const rates = {
  rows: [
    { what: 'Contract, gameplay systems', figure: '$620 / day', note: 'Unity or Godot, gameplay and tools. Quoted against a scoped list of systems, never against a feature wish list.' },
    { what: 'Performance pass',           figure: 'From $4,800', note: 'Two weeks: profile, prioritise, fix, and hand back a document like the frame budget on this page so it stays fixed.' },
    { what: 'Scoping and pre-production', figure: '$2,400',     note: 'A week, and the deliverable is a cut list. The most useful thing I have ever sold and the hardest to persuade anybody to buy.' },
    { what: 'Code review, one-off',       figure: '$450',       note: 'For a small team without a senior engineer. Written, specific, and it will tell you what to ignore as well as what to fix.' },
    { what: 'Equity instead of rate',     figure: 'No',         note: 'Not a judgement on your project. I have taken that deal twice and neither time was good for either side.' },
  ],
};

export const faqs = [
  {
    q: 'Why is there no gameplay footage on this page?',
    a: 'Because this is a website template and the game is fictional. Fabricating screenshots of a game that does not exist would be the one dishonest thing on a page whose entire argument is about publishing what usually stays hidden. If you are using this template, put your real footage here.',
  },
  {
    q: 'Is a long cut list a bad sign?',
    a: 'It is the opposite, and that is the whole argument. Forty features designed and twenty-two shipped is a project that was steered. Forty designed and thirty-eight shipped is usually a project that is late.',
  },
  {
    q: 'Would you really put photo mode back?',
    a: 'Yes, and voice acting. Those are the two rows in the "add it back" column and they are there because players asked for the first constantly and because the second turned out to be a marketing cost rather than a feature cost.',
  },
  {
    q: 'Unity or Godot?',
    a: 'Both, and I will tell you honestly that the engine is rarely the reason a project succeeds or fails. Scope is. If an engine migration is on your roadmap, that is worth one hard conversation before it is worth six months.',
  },
  {
    q: 'Do you do art or audio?',
    a: 'No. Gameplay, systems, tools and performance. A programmer who claims all four disciplines is telling you something about their standards in at least three of them.',
  },
  {
    q: 'Will you sign an NDA?',
    a: 'Yes, routinely, and it does not change what is on this page — everything here is from a shipped title of my own. If you need the cut list of your own project kept private, that is the normal arrangement rather than the exception.',
  },
];
