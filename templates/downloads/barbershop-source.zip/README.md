# Day 51 — Barbershop Template

**Noble & Sharp** — a heritage barbershop website. Bold masculine hero, full services + price list (cuts/fades/beard/hot-towel-shave/grooming), barber team profiles, gallery, walk-in policy, booking CTA, hours, and about/heritage section.

**Live demo:** https://templates.allanninal.dev/barbershop/

---

## Design

| Token       | Value                                   |
|-------------|----------------------------------------|
| Palette     | Near-black `#0E0E0E` · Oxblood `#8B1A1A` · Cream `#F5F0E6` · Brass `#A67C00` |
| Display     | Teko 600 (condensed uppercase)          |
| Body        | Hind 400 / 600                          |
| Schema      | HairSalon + Service + Offer JSON-LD     |

Visually distinct from Day 50 (hair-salon) — oxblood/brass/near-black vs. mauve/champagne/ivory, Teko condensed vs. Bellefair serif, masculine heritage vs. chic feminine.

---

## Stack

- [Astro](https://astro.build/) 4.x — static output
- [Tailwind CSS](https://tailwindcss.com/) 3.x
- [Teko](https://fonts.google.com/specimen/Teko) + [Hind](https://fonts.google.com/specimen/Hind) via Fontsource
- [Playwright](https://playwright.dev/) — a11y, smoke, links, template-info tests
- [Lighthouse CI](https://github.com/GoogleChrome/lighthouse-ci) — ≥ 95 thresholds

---

## Quick start

```bash
git clone https://github.com/allanninal/templates.git
cd templates/templates/barbershop
npm install
npm run dev
```

Open http://localhost:4321/

---

## Customize

1. Edit `src/data/config.ts` — shop name, address, phone, hours, barbers, services, testimonials.
2. Update `public/og-image.svg` + generate `og-image.png`.
3. Replace gallery placeholders with real photography.
4. Set booking URL to your Booksy / Square / other booking platform.
5. Deploy: `npm run build` → upload `dist/` to any static host.

---

## Environment variables

| Variable                | Description                                        |
|------------------------|----------------------------------------------------|
| `PUBLIC_SITE_URL`       | Your deployed URL (no trailing slash)             |
| `PUBLIC_BASE_PATH`      | Base path (use `/` for root deploys)              |
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — enables analytics + download bar. Leave blank for forks. |

---

## Tests

```bash
npm run test:a11y       # axe-core WCAG 2.1 AA
npm run test:links      # broken links + rel checks
npm run test            # smoke tests (Playwright)
npm run test:lighthouse # Lighthouse ≥ 95
npm run test:all        # all of the above
```

---

## License

MIT — free to use, clone, and customize. Attribution appreciated but not required.

Template by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · [Ko-fi](https://ko-fi.com/allanninal)
