// Barbershop — Noble & Sharp Barbershop, Chicago
// Palette: Near-black · Oxblood · Cream · Brass/Amber
// Fonts: Teko (display) · Hind (body)

export const shop = {
  name: "Noble & Sharp",
  tagline: "Classic Craft. Sharp Results.",
  description:
    "A heritage barbershop in the heart of Chicago serving discerning gentlemen since 2009. Walk-ins welcome. Appointments recommended.",
  address: "412 North Wells Street, Chicago, IL 60654",
  phone: "+1 (312) 555-0187",
  email: "landix.ninal@gmail.com",
  instagram: "https://www.instagram.com/",
  facebook: "https://www.facebook.com/",
  bookingUrl: "https://booksy.com/",
  linkedin: "https://www.linkedin.com/in/allanninal/",
  kofi: "https://ko-fi.com/allanninal",
  walkInPolicy:
    "Walk-ins are always welcome based on barber availability. For guaranteed seating — especially on weekends — we recommend booking online at least 24 hours in advance.",
  hours: [
    { day: "Monday",    open: "9:00 am – 7:00 pm" },
    { day: "Tuesday",   open: "9:00 am – 7:00 pm" },
    { day: "Wednesday", open: "9:00 am – 7:00 pm" },
    { day: "Thursday",  open: "9:00 am – 8:00 pm" },
    { day: "Friday",    open: "8:00 am – 8:00 pm" },
    { day: "Saturday",  open: "8:00 am – 7:00 pm" },
    { day: "Sunday",    open: "10:00 am – 5:00 pm" },
  ],
};

export const site = {
  title: "Noble & Sharp Barbershop — Chicago, IL",
  description:
    "Noble & Sharp is a heritage barbershop in Chicago offering precision haircuts, fades, beard grooming, and hot-towel shaves. Walk-ins welcome. Book online.",
  language: "en",
  ogImage: "/og-image.png",
  twitterHandle: "@allanninal",
};

export const services = [
  {
    id: "cuts",
    category: "Haircuts",
    icon: "✂",
    items: [
      {
        name: "Classic Cut",
        price: "$35",
        duration: "45 min",
        description: "Scissor or clipper cut, finished with a hot towel and styling product.",
      },
      {
        name: "Fade",
        price: "$38",
        duration: "45 min",
        description: "Skin, low, mid, or high — tailored to your head shape and style.",
      },
      {
        name: "Crew Cut",
        price: "$32",
        duration: "35 min",
        description: "A timeless military-inspired cut, clean and sharp every time.",
      },
      {
        name: "Executive Cut",
        price: "$42",
        duration: "50 min",
        description: "Business-ready cut with scissor finish, styling, and a classic part.",
      },
      {
        name: "Kids' Cut (under 12)",
        price: "$25",
        duration: "30 min",
        description: "Patient, friendly service for young gentlemen.",
      },
    ],
  },
  {
    id: "beard",
    category: "Beard & Grooming",
    icon: "◆",
    items: [
      {
        name: "Beard Trim & Shape",
        price: "$22",
        duration: "25 min",
        description: "Detailed sculpting of beard lines, cheeks, and neckline.",
      },
      {
        name: "Full Beard Styling",
        price: "$30",
        duration: "35 min",
        description: "Conditioning treatment, shaping, and precision edge-up.",
      },
      {
        name: "Beard & Cut Combo",
        price: "$55",
        duration: "65 min",
        description: "Full haircut plus beard trim and shape — our most popular service.",
      },
      {
        name: "Mustache Trim",
        price: "$15",
        duration: "15 min",
        description: "Clean shaping and length control for the upper lip.",
      },
    ],
  },
  {
    id: "shave",
    category: "Shaves",
    icon: "◇",
    items: [
      {
        name: "Hot-Towel Straight Razor Shave",
        price: "$45",
        duration: "45 min",
        description:
          "Pre-shave hot towel, premium lather, open-razor shave, cold-towel close, moisturiser finish.",
      },
      {
        name: "Express Shave",
        price: "$28",
        duration: "25 min",
        description: "Hot towel, safety-razor shave, and moisturiser — quick and smooth.",
      },
      {
        name: "Head Shave",
        price: "$40",
        duration: "40 min",
        description: "Full scalp shave with hot towels, lather, straight razor, and balm.",
      },
    ],
  },
  {
    id: "grooming",
    category: "Finishing & Grooming",
    icon: "◯",
    items: [
      {
        name: "Edge-Up / Line-Up",
        price: "$18",
        duration: "20 min",
        description: "Precision hairline, temple, and neckline clean-up.",
      },
      {
        name: "Eyebrow Shaping",
        price: "$12",
        duration: "15 min",
        description: "Defined, masculine shaping with razor and scissors.",
      },
      {
        name: "Scalp Treatment",
        price: "$30",
        duration: "30 min",
        description: "Deep-cleansing scalp massage with nourishing oil treatment.",
      },
      {
        name: "Ear & Nose Wax",
        price: "$15",
        duration: "10 min",
        description: "Quick, precise grooming add-on.",
      },
    ],
  },
];

export const barbers = [
  {
    id: "marcus-hayes",
    name: "Marcus Hayes",
    title: "Master Barber & Founder",
    specialty: "Fades · Straight Razor Shaves",
    since: 2009,
    bio: "Marcus trained under legendary Chicago barber Leon Wright before opening Noble & Sharp in 2009. With 20+ years in the chair, he's known for fades so clean they look painted on and hot-towel shaves that feel like an hour at a spa.",
    instagram: "https://www.instagram.com/",
    avatar: null,
  },
  {
    id: "darnell-croft",
    name: "Darnell Croft",
    title: "Senior Barber",
    specialty: "Skin Fades · Beard Sculpting",
    since: 2014,
    bio: "Darnell is a Chicago South Side native who discovered barbering at 16 and never looked back. His skin fades are architectural — he approaches every cut like a sculptor reading the head before making a single move.",
    instagram: "https://www.instagram.com/",
    avatar: null,
  },
  {
    id: "tommy-reyes",
    name: "Tommy Reyes",
    title: "Barber",
    specialty: "Classic Cuts · Textured Styles",
    since: 2018,
    bio: "Tommy brings a love of vintage men's grooming to every appointment. He's obsessed with Brilliantine and Brooks Brothers but equally comfortable giving a modern textured crop. His executive cuts are a neighbourhood favourite.",
    instagram: "https://www.instagram.com/",
    avatar: null,
  },
  {
    id: "elijah-cross",
    name: "Elijah Cross",
    title: "Barber",
    specialty: "Creative Designs · Tapered Cuts",
    since: 2021,
    bio: "The youngest member of the team, Elijah arrived fresh from Pivot Point International with a passion for creative freehand design work. He blends old-school fundamentals with fresh barbering energy that keeps the younger clientele coming back.",
    instagram: "https://www.instagram.com/",
    avatar: null,
  },
];

export const testimonials = [
  {
    quote:
      "Marcus has been cutting my hair for 12 years. I've moved twice and crossed the city to stay with Noble & Sharp. The straight razor shave alone is worth the drive.",
    author: "James W.",
    service: "Classic Cut + Hot-Towel Shave",
  },
  {
    quote:
      "Darnell's skin fade is unreal. I've been to shops all over Chicago and nobody blends like he does. He reads your head shape before he makes one move. Truly gifted.",
    author: "DeShawn M.",
    service: "Skin Fade",
  },
  {
    quote:
      "I was skeptical about getting a straight razor shave for the first time. The hot towels, the lather, the whole ritual — I left feeling like a million dollars. I'm a convert.",
    author: "Patrick O.",
    service: "Hot-Towel Straight Razor Shave",
  },
  {
    quote:
      "Tommy gave me the best executive cut I've ever had. He asked the right questions, did a dry cut first, then refined it. My clients noticed the difference in my first meeting.",
    author: "Victor L.",
    service: "Executive Cut",
  },
  {
    quote:
      "The shop itself is beautiful — dark leather, brass details, old jazz on the record player. Noble & Sharp is the real thing. Barbershops like this are disappearing. Protect them.",
    author: "Robert D.",
    service: "Beard & Cut Combo",
  },
  {
    quote:
      "Elijah designed a fade pattern for me that I'd been looking for for years. Showed him a rough sketch, he improved it, and executed it perfectly. I'll never go anywhere else.",
    author: "Marcus T.",
    service: "Creative Fade Design",
  },
];

export const stats = [
  { value: "15+",   label: "Years in the Craft" },
  { value: "4",     label: "Master Barbers" },
  { value: "3,200+", label: "Regulars Served" },
  { value: "4.9★",  label: "Average Review" },
];

// `src` + `proLabel` drive the Pro edition's real barbering photography (free
// uses the CSS-gradient tile). proLabel sets the caption shown over the photo.
export const galleryImages = [
  { id: 1, label: "Skin Fade",          note: "Clean to the bone, blended up", src: "cut-01", proLabel: "Scissor Fade" },
  { id: 2, label: "Low Taper",          note: "Structured and versatile",      src: "cut-02", proLabel: "Skin Fade Detail" },
  { id: 3, label: "Classic Side Part",  note: "Old-school precision",          src: "cut-03", proLabel: "Crop & Comb" },
  { id: 4, label: "Beard Sculpt",       note: "Sharp lines, full shape",       src: "cut-04", proLabel: "Beard Sculpt" },
  { id: 5, label: "Crew Cut",           note: "Timeless and clean",            src: "cut-05", proLabel: "Classic Side Part" },
  { id: 6, label: "Hot-Towel Shave",    note: "The full ritual",               src: "cut-06", proLabel: "Hot-Towel Shave" },
  { id: 7, label: "Textured Crop",      note: "Modern, lived-in finish",       src: "cut-07", proLabel: "Beard & Pompadour" },
  { id: 8, label: "High Fade + Design", note: "Freehand artistry",             src: "cut-08", proLabel: "In the Chair" },
];
