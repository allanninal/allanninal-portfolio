import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Noble.*Sharp/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('services section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#services')).toBeVisible();
});

test('team section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#team')).toBeVisible();
});

test('team has barber cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#team article');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('hours section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('booking section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#booking')).toBeVisible();
});

test('booking section has booking link', async ({ page }) => {
  await page.goto('/');
  const bookingSection = page.locator('#booking');
  const bookingLink = bookingSection.locator('a[href*="booksy.com"]');
  await expect(bookingLink).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('service tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('.service-tab');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(2);

  // Click second tab
  if (count >= 2) {
    await tabs.nth(1).click();
    const secondTabSelected = await tabs.nth(1).getAttribute('aria-selected');
    expect(secondTabSelected).toBe('true');
  }
});

test('hours table is visible', async ({ page }) => {
  await page.goto('/');
  const hoursTable = page.locator('#hours table');
  await expect(hoursTable).toBeVisible();
});

test('phone link is present', async ({ page }) => {
  await page.goto('/');
  const phoneLink = page.locator('a[href^="tel:"]').first();
  await expect(phoneLink).toBeVisible();
});
