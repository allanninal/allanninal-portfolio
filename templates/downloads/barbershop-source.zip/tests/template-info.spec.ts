import { test, expect } from '@playwright/test';

// Edition-aware: the Pro edition swaps the free download bar for a
// "Pro edition — live preview" strip with a locked Get-Pro link.
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';

test('TemplateInfo bar is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(`[aria-label="${barLabel}"]`)).toBeVisible();
});

test('TemplateInfo has the static download button', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  const staticBtn = bar.locator('a[download]').first();
  await expect(staticBtn).toBeVisible();
  expect(await staticBtn.getAttribute('href')).toContain('barbershop-static.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  await expect(bar.locator('a', { hasText: 'All 365' })).toBeVisible();
});

test('Pro bar locks Get Pro static to LinkedIn; free offers source + Build with me', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  if (isPro) {
    const getPro = bar.locator('a', { hasText: 'Get Pro static' });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    return;
  }
  const sourceBtn = bar.locator('a[download]').nth(1);
  expect(await sourceBtn.getAttribute('href')).toContain('barbershop-source.zip');
  const hireLink = bar.locator('a', { hasText: 'Build with me' });
  expect(await hireLink.getAttribute('href')).toContain('linkedin.com');
});

test('no github.com/allanninal/templates deep-links in TemplateInfo', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  expect(await bar.locator('a[href*="github.com/allanninal/templates"]').count()).toBe(0);
});
