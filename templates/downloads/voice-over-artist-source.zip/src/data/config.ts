// Hollis Yeo — Louisville, KY. Fictional. The figures are mid-market non-union
// and are anchored to the published rate guides working artists actually cite
// (see RESEARCH.md), not to what anybody wishes they could charge.
//
// The organising idea: a voice-over fee is SESSION + USAGE, never an hourly
// rate. The session is the recording. The usage is permission for that
// recording to appear on named media, in a named territory, for a named term.
// The session fee barely moves. The usage is where the money is, and it is the
// half almost nobody publishes.

export const site = {
  name:        'Hollis Yeo',
  shortName:   'Hollis Yeo',
  title:       'Hollis Yeo — voice-over, licensed by usage',
  tagline:     'The read is the cheap part.',
  owner:       'Hollis Yeo',
  ownerRole:   'Voice-over artist',
  credential:  'Non-union · 11 years · own booth',
  city:        'Louisville',
  state:       'KY',
  language:    'en',
  phoneDisplay: '(502) 555-0147',
  phoneHref:   '+15025550147',
  email:       'hollis@hollisyeo.example',
  streetAddress: '812 E Market St',
  postalCode:  '40206',
  hours:       'Sessions 9–5 Eastern · same-day for anything under 3 minutes',
  bookingWindow: 'Quotes back the same day · licence terms in writing before the session',
  description:
    'Every quote on this page is a session fee plus a usage licence, and the licence is the part ' +
    'that moves. The same forty-five seconds of finished audio is worth a few hundred dollars ' +
    'inside a company and several thousand on national television, because those are different ' +
    'permissions rather than different reads.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'One script, three prices', href: '#quotes' },
  { label: 'Usage matrix',             href: '#matrix' },
  { label: 'Term',                     href: '#term' },
  { label: 'Get a quote',              href: '#quote' },
];

// ── The spine: one script, three licences ─────────────────────────────────
// Transposed on purpose. Line items down the side, scenarios across the top,
// so the identical session fee sits on a single row and the licence does all
// the diverging underneath it.

export const script = {
  seconds: 45,
  words: 118,
  text:
    'One forty-five-second read, 118 words, recorded once. Three buyers, three licences, ' +
    'three invoices. The recording is byte-for-byte the same file in all three.',
};

export const quotes = {
  columns: [
    { id: 'internal', buyer: 'Manufacturer, internal use',
      what: 'Onboarding module, intranet only' },
    { id: 'regional', buyer: 'Regional grocery chain',
      what: 'Radio, Louisville metro' },
    { id: 'national', buyer: 'National insurer',
      what: 'TV and streaming, North America' },
  ],
  // Every row is a dollar figure except the last two, which are the reason for
  // the figures above them.
  rows: [
    { k: 'Session fee',   note: 'The recording. Direction, edit, one round of pickups. Identical in all three.',
      v: [275, 275, 275] },
    { k: 'Media licence', note: 'What it may appear on. Internal video, broadcast radio, broadcast TV plus streaming.',
      v: [0, 450, 1850] },
    { k: 'Territory',     note: 'One building, one metro, one continent.',
      v: [0, 0, 900] },
    { k: 'Term',          note: 'Perpetual internal use is cheap. Twelve months of paid media is not.',
      v: [180, 120, 640] },
    { k: 'Total',         note: 'Same forty-five seconds. Same file.', total: true,
      v: [455, 845, 3665] },
  ],
  terms: ['Perpetual, internal only', '13 weeks, one market', '12 months, North America'],
};

export const quotesNote =
  'The session fee is the same $275 in all three columns because it is the same work: the same ' +
  'script, the same booth, the same afternoon. Everything else on the invoice is permission. ' +
  'A voice-over site that publishes only an hourly rate is publishing the one number that does ' +
  'not vary, and leaving the buyer to discover the rest after the recording exists.';

// ── The usage matrix ──────────────────────────────────────────────────────
// Media down the side, territory across the top, twelve-month licence fees in
// the cells. Session fee is NOT included and the table says so.

export const matrix = {
  territories: ['One market', 'National', 'Worldwide'],
  media: [
    { m: 'Internal / corporate',   c: [180, 180, 180],   n: 'Intranet, training, trade-show loop. Territory does not apply inside a company, so it is one price.' },
    { m: 'Web and owned social',   c: [340, 620, 1350],  n: 'Your own site and channels. Excludes paid placement, which is the line people cross without noticing.' },
    { m: 'Paid social / pre-roll', c: [520, 1100, 2600], n: 'Anything with money behind the impressions, including connected TV and short-form vertical.' },
    { m: 'Radio',                  c: [450, 1250, 2900], n: 'Broadcast and streaming audio. A market is a metro, not a station.' },
    { m: 'Television',             c: [850, 1850, 4400], n: 'Broadcast, cable and ad-supported streaming. The largest single line in the trade.' },
    { m: 'Cinema',                 c: [700, 1600, 3800], n: 'Priced against screens booked, not against seats sold.' },
  ],
};

export const matrixNote =
  'Twelve-month licences, session fee not included. Two media are two licences, not a discount — ' +
  'a radio spot that also runs as pre-roll is two lines, and pretending otherwise is how a ' +
  'campaign quietly outgrows what it paid for.';

// ── Term ──────────────────────────────────────────────────────────────────

export const term = {
  base: 'Twelve months from first air date',
  steps: [
    { k: '13 weeks',    x: '0.6×', n: 'A seasonal or test flight. Cheaper because it ends, and it has to actually end.' },
    { k: '12 months',   x: '1×',   n: 'The standard term everything on this page is priced against.' },
    { k: '24 months',   x: '1.7×', n: 'Not double: the second year is worth less than the first to almost every campaign.' },
    { k: 'Perpetuity',  x: '3.5×', n: 'Forever is a multiple, not a rounding. It also means the recording can outlive the product, the agency and me.' },
  ],
  renewal:
    'Month thirteen is agreed before the session, not discovered during it. Renewal is the same ' +
    'licence fee less 15%, quoted in the original confirmation, and it holds for sixty days after ' +
    'the term ends. This is the single most common dispute in the trade and it is entirely ' +
    'avoidable by writing one sentence down in advance.',
};

// ── What "buy-out" means ──────────────────────────────────────────────────
// A definition list is the honest element here: these are four incompatible
// definitions of one word, and the ambiguity is never in the artist's favour.

export const buyout = [
  { t: 'All media, worldwide, in perpetuity',
    d: 'The maximum. Everything, everywhere, forever. Roughly ten times a single-medium national year, and it is the only reading of the word that genuinely buys the recording outright.' },
  { t: 'All media, one territory, fixed term',
    d: 'Common, reasonable, and about a third of the above. This is what most agencies actually mean when they write "full buy-out" into a brief.' },
  { t: 'One medium, unlimited term',
    d: 'Perpetual radio, say, and nothing else. Cheap now, and the reason a ten-year-old spot occasionally reappears with nobody left who remembers agreeing to it.' },
  { t: 'Whatever the client decides later',
    d: 'Not a licence. A brief that says "buy-out" without naming media, territory and term has named a price for an unspecified permission, and every unspecified permission resolves in one direction.' },
];

export const buyoutNote =
  'Four incompatible meanings of one word, all in current use, all written into briefs as though ' +
  'they were interchangeable. I quote against the first three and decline the fourth, which costs ' +
  'me a job every few months and has never once cost me an argument.';

// ── Demos ─────────────────────────────────────────────────────────────────
// Present, deliberately not the spine. Descriptions rather than an embedded
// player: this page is about what a read costs, and a wall of audio controls
// would say the opposite.

export const demos = [
  { k: 'Commercial',  len: '1:04', n: 'Six spots, warm and unhurried. The register most brands ask for and the one that dates fastest.' },
  { k: 'Narration',   len: '1:38', n: 'Long-form documentary and corporate. Paced for someone who is going to listen for forty minutes, not four seconds.' },
  { k: 'E-learning',  len: '2:10', n: 'Instructional, with the pauses left in. Compliance modules are the least glamorous and most reliable work in this trade.' },
  { k: 'Explainer',   len: '0:52', n: 'Faster, brighter, more consonant. Written to survive being played without sound and then replayed with it.' },
];

// ── Refusals ──────────────────────────────────────────────────────────────

export const decline = [
  { k: 'Synthetic voice training',
    n: 'No recording of mine is licensed as training data for a voice model, and every contract I sign says so in a sentence I wrote. This is the live question in the trade and a site that will not answer it has answered it.' },
  { k: 'Gambling and payday lending',
    n: 'A personal line rather than an industry one. Stated here so nobody spends an afternoon on a brief I am going to return.' },
  { k: 'Unnamed usage',
    n: 'A brief that will not say where the audio runs is asking for a price without a product. I will quote the moment media, territory and term exist.' },
];

export const said = {
  text: 'The quote came back as five lines with the licence broken out, and our legal team signed it in a day because there was nothing left to interpret. I have paid more for less clarity many times.',
  who: 'Producer, agency of record — 2025',
};

export const faqs = [
  {
    q: 'Why not just charge by the hour?',
    a: 'Because the hour is not what is being sold. A forty-five-second read takes about the same time to record whether it runs in one building or on national television, and an hourly rate prices those identically. It would mean charging the internal training buyer too much and the national campaign far too little.',
  },
  {
    q: 'What does the session fee actually cover?',
    a: 'The recording itself: direction, the read, editing, and one round of pickups if the script changes after the fact. Delivery is broadcast-ready WAV plus MP3. It does not cover permission for the recording to be used anywhere, which is the separate half of every quote on this page.',
  },
  {
    q: 'We only want a buy-out. What does that cost?',
    a: 'It depends entirely on which of the four things on this page you mean by the word. Name the media, the territory and the term, and the number is on the matrix. A brief that says "buy-out" and nothing else is asking me to guess at a permission and then be bound by the guess.',
  },
  {
    q: 'What happens in month thirteen?',
    a: 'The renewal figure is in your original confirmation email: the same licence less 15%, held for sixty days after the term ends. Nothing goes up because the campaign worked. The point of agreeing it before the session is that neither of us has to have that conversation while the spot is still on air.',
  },
  {
    q: 'Can we use the audio somewhere it was not licensed for?',
    a: 'Ask first and it is almost always a small addition to the existing licence rather than a new quote. The expensive version is the one discovered eighteen months later, because by then it is a rights conversation rather than an invoice.',
  },
  {
    q: 'Do you take direction live?',
    a: 'Source-Connect, Zoom or a phone patch, all included in the session fee. Most sessions do not need it. The ones that do are usually scripts where somebody has not yet decided what the line means, and that is worth twenty minutes of everyone being in the same room.',
  },
];
