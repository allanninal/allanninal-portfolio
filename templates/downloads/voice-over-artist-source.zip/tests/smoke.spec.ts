import { test, expect } from '@playwright/test';

const dollars = (s: string) => Number(s.replace(/[^\d]/g, ''));

test.describe('Hollis Yeo — smoke tests', () => {
  test('homepage renders with the artist in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Hollis Yeo/);
    await expect(page.locator('h1')).toContainText('The read is the cheap part');
  });

  // A Service with a catalogue of what can be licensed. Not day 117's
  // PodcastSeries, and not day 116's Person-with-hasOccupation.
  test('is a Service with an offer catalogue', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Service"');
    expect(json).toContain('"OfferCatalog"');
    expect(json).not.toContain('PodcastSeries');
    expect(json).not.toContain('hasOccupation');
  });

  // Schema's Offer carries one price. This page's argument is that there is
  // no such number, so the markup names what is licensed and nothing else.
  test('the markup publishes no price anywhere', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    for (const token of ['"price"', 'priceSpecification', '"Offer"', 'priceCurrency']) {
      expect(raw).not.toContain(token);
    }
    expect(raw).not.toContain('275');
    // But the catalogue does name every medium and every territory. The row
    // header holds the medium plus an explanatory <span>, so read the medium
    // out of the header's first child text rather than the whole cell.
    const media = await page.locator('#matrix tbody th').evaluateAll((ths) =>
      ths.map((th) => (th.childNodes[0].textContent || '').trim()));
    expect(media.length).toBeGreaterThan(4);
    for (const m of media) expect(raw).toContain(m);
    for (const t of await page.locator('#matrix thead th.fee').allTextContents()) {
      expect(raw).toContain(t.trim());
    }
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#quotes table.quotes');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(300);
  });

  // ── The three quotes ────────────────────────────────────────────────────
  test('the table is transposed: buyers are columns, line items are rows', async ({ page }) => {
    await page.goto('/');
    const cols = await page.locator('#quotes thead th').count();
    expect(cols).toBe(4); // line item + three buyers
    const rowHeads = page.locator('#quotes tbody th[scope="row"]');
    expect(await rowHeads.count()).toBe(5);
    expect((await rowHeads.first().textContent()) || '').toContain('Session fee');
  });

  test('the session fee is the same number in all three columns', async ({ page }) => {
    await page.goto('/');
    const fees = (await page.locator('#quotes tbody tr').first().locator('td').allTextContents())
      .map(dollars);
    expect(fees.length).toBe(3);
    expect(new Set(fees).size).toBe(1);
    expect(fees[0]).toBeGreaterThan(0);
    // And it is the only row marked as unchanging.
    expect(await page.locator('#quotes td.same').count()).toBe(3);
  });

  test('the totals rise across the columns, and the headline is computed from them', async ({ page }) => {
    await page.goto('/');
    const totals = (await page.locator('#quotes tr.tot td').allTextContents()).map(dollars);
    expect(totals.length).toBe(3);
    for (let i = 1; i < totals.length; i++) expect(totals[i]).toBeGreaterThan(totals[i - 1]);
    const h2 = (await page.locator('#quotes h2').textContent()) || '';
    expect(h2).toContain(String(totals[0]));
    expect(h2).toContain(totals[2].toLocaleString('en-US'));
    const spread = (totals[2] / totals[0]).toFixed(1);
    await expect(page.locator('#quotes')).toContainText(`${spread}×`);
  });

  test('every zero cell says in words that nothing was charged', async ({ page }) => {
    await page.goto('/');
    const dashes = page.locator('#quotes tbody td').filter({ hasText: '—' });
    const n = await dashes.count();
    expect(n).toBeGreaterThan(1);
    for (const d of await dashes.all()) {
      await expect(d.locator('.sr-only')).toHaveText(/not charged/);
    }
  });

  test('each column states the licence it actually grants', async ({ page }) => {
    await page.goto('/');
    const granted = await page.locator('#quotes tfoot td').allTextContents();
    expect(granted.length).toBe(3);
    for (const g of granted) expect(g.length).toBeGreaterThan(10);
    expect(granted.join(' ')).toMatch(/Perpetual/);
  });

  // ── The matrix ──────────────────────────────────────────────────────────
  test('the usage matrix rises with territory on every row', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#matrix tbody tr');
    expect(await rows.count()).toBeGreaterThan(4);
    let strictlyRising = 0;
    for (const r of await rows.all()) {
      const v = (await r.locator('td').allTextContents()).map(dollars);
      expect(v.length).toBe(3);
      for (let i = 1; i < v.length; i++) expect(v[i]).toBeGreaterThanOrEqual(v[i - 1]);
      if (v[2] > v[0]) strictlyRising++;
    }
    // The internal row is deliberately flat; every other row must move.
    expect(strictlyRising).toBe((await rows.count()) - 1);
  });

  test('the matrix says the session fee is not in it', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#matrix caption')).toContainText(/session fee.*charged once/i);
  });

  // ── Term ────────────────────────────────────────────────────────────────
  test('term is an ordered list and perpetuity is the largest multiplier', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#term ol.term')).toBeVisible();
    const mult = (await page.locator('#term .x').allTextContents()).map((s) => parseFloat(s));
    expect(mult.length).toBe(4);
    for (let i = 1; i < mult.length; i++) expect(mult[i]).toBeGreaterThan(mult[i - 1]);
    expect(mult[mult.length - 1]).toBeGreaterThan(2);
    await expect(page.locator('#renewal')).toContainText(/Month thirteen/);
  });

  // ── Buy-out ─────────────────────────────────────────────────────────────
  test('four incompatible meanings of buy-out, in a definition list', async ({ page }) => {
    await page.goto('/');
    const dl = page.locator('#buyout dl.defs');
    await expect(dl).toBeVisible();
    expect(await dl.locator('dt').count()).toBe(4);
    expect(await dl.locator('dd').count()).toBe(4);
    for (const d of await dl.locator('dd').allTextContents()) expect(d.length).toBeGreaterThan(80);
  });

  test('the page declines synthetic voice training in so many words', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#demos')).toContainText(/Synthetic voice training/);
    await expect(page.locator('#demos')).toContainText(/training data for a voice model/);
  });

  // Day 117 removed its accordion for a reason true of that page, not of this
  // one. Alternating the device is the point.
  test('the FAQ is an accordion again', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the quote form asks the two questions that change the number', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#quote select').count()).toBe(2);
    expect(await page.locator('#medium option').count()).toBeGreaterThan(5);
    expect(await page.locator('#territory option').count()).toBe(4);
  });

  test('no trace of the day-117 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['nell braithwaite', 'long way round', 'fargo', 'mid-roll', 'podcast']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro rate card is absent from the free build', async ({ page }) => {
    const res = await page.goto('/rate-card/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
