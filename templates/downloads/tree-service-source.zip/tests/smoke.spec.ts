import { test, expect } from '@playwright/test';

test.describe('Kestrel Tree Works — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Kestrel Tree Works/);
    await expect(page.locator('h1')).toContainText('written assessment');
  });

  // The page is styled as the document this trade produces, so it opens the
  // way an assessment opens: who wrote it, under what credential, on what basis.
  test('the report masthead names the assessor, credential and method', async ({ page }) => {
    await page.goto('/');
    const m = page.locator('.masthead');
    await expect(m).toBeVisible();
    expect(await m.locator('.masthead-cell').count()).toBe(4);
    await expect(m).toContainText('ISA Cert.');
    await expect(m).toContainText('TRAQ');
  });

  test('six findings each carry a reference, the three TRAQ inputs and a rating', async ({ page }) => {
    await page.goto('/');
    const f = page.locator('#findings .finding');
    expect(await f.count()).toBe(6);
    expect(await f.locator('.finding-ref').count()).toBe(6);
    expect(await f.locator('.rating').count()).toBe(6);
    // Failure, impact, consequence on every entry.
    expect(await f.locator('.traq dt').count()).toBe(18);
    expect(await f.locator('.traq dd').count()).toBe(18);
  });

  // The whole argument of this template: a removal is irreversible and the
  // industry's incentive runs one way, so the sample findings must include
  // recommendations to KEEP the tree.
  test('at least two findings recommend keeping the tree, and the copy says so', async ({ page }) => {
    await page.goto('/');
    const recs = await page.locator('#findings .finding-rec strong').allTextContents();
    const keeps = recs.filter((r) => /Retain|Monitor/.test(r.trim())).length;
    expect(keeps).toBeGreaterThanOrEqual(2);
    // The section intro quotes the count; assert they agree so copy and data
    // cannot drift apart.
    await expect(page.locator('#findings')).toContainText(`${keeps} of the six do not end in a removal`);
  });

  test('every rating prints its own name, not just a colour', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#findings .rating').allTextContents()) {
      expect(t.trim()).toMatch(/^(Low|Moderate|High|Extreme) risk$/);
    }
  });

  test('the rating scale is published with four levels', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#scale .rate-table tbody tr');
    expect(await rows.count()).toBe(4);
    await expect(page.locator('#scale')).toContainText('Today');
  });

  test('costs name the separately-quoted line items', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#costs .rate-table tbody tr');
    expect(await rows.count()).toBe(7);
    for (const t of await rows.allTextContents()) expect(t).toMatch(/\$\d/);
    expect(await page.locator('#costs ul li').count()).toBe(4);
  });

  // This trade genuinely has an emergency, unlike the four before it.
  test('the storm line is present and separate from the office number', async ({ page }) => {
    await page.goto('/');
    const emergency = page.locator('a[href="tel:+18285550199"]');
    expect(await emergency.count()).toBeGreaterThanOrEqual(1);
    await expect(page.locator('#storm')).toContainText(/25.50%/);
    expect(await page.locator('#storm dl > div').count()).toBe(4);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('request form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 81.
  test('no trace of the day-81 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['ashgrove', 'boise', 'wren halloran', 'dormant', 'irrigation']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro storm plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/storm-plan/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('The first hour, in order');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
