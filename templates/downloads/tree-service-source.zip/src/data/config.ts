/**
 * Kestrel Tree Works — every string the page renders.
 *
 * Business fictional; PRICES ARE REAL 2026 US figures and the rating scale
 * follows ISA's TRAQ structure (likelihood of failure × likelihood of impacting
 * a target × consequences). Sources in RESEARCH.md.
 */

export const site = {
  name: 'Kestrel Tree Works',
  shortName: 'Kestrel',
  tagline: 'Tree risk assessment, and the removals that follow from it.',
  description:
    'ISA Certified arborist in Asheville. Every job starts with a written assessment — and about a third of them end with a recommendation to keep the tree.',
  owner: 'Roman Adebayo',
  ownerRole: 'ISA Certified Arborist',
  credential: 'ISA Cert. #SO-8841A · TRAQ qualified',
  yearsExperience: 15,
  city: 'Asheville',
  state: 'NC',
  streetAddress: '212 Riverside Drive',
  postalCode: '28801',
  phoneDisplay: '(828) 555-0157',
  phoneHref: '+18285550157',
  emergencyDisplay: '(828) 555-0199',
  emergencyHref: '+18285550199',
  email: 'hello@kestreltreeworks.example',
  formAction: '#',
  hours: 'Mon–Fri 7am–4pm · Storm line answered 24/7',
  bookingWindow: 'Assessments within a week. Storm damage answered the same hour.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Kestrel Tree Works — Arborist & Tree Risk Assessment in Asheville, NC',
  license: 'NC pesticide licence #L-2214 · Fully insured, $2M liability',
  instagram: 'https://www.instagram.com/kestreltreeworks',
  facebook: 'https://www.facebook.com/kestreltreeworks',
};

export const nav = [
  { label: 'Findings', href: '#findings' },
  { label: 'Rating scale', href: '#scale' },
  { label: 'Costs', href: '#costs' },
  { label: 'Storm', href: '#storm' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * Sample findings, written as report entries.
 *
 * `rating` follows TRAQ's combined scale. `action` is the honest field: two of
 * the six recommend RETAINING the tree, which is the whole argument of this
 * template — a removal is irreversible and the industry's incentive runs one
 * way.
 */
export const findings = [
  {
    ref: 'A-1', species: 'White oak, 74 ft', site: 'Montford · rear boundary',
    failure: 'Possible', impact: 'High', consequence: 'Severe', rating: 'High',
    observed: 'Included bark union at 22 ft with a visible crack extending below it. Directly over a bedroom.',
    action: 'remove',
    recommendation: 'Removal. A codominant union with an open crack over an occupied structure is the textbook case, and no amount of cabling makes it acceptable here.',
  },
  {
    ref: 'A-2', species: 'Tulip poplar, 88 ft', site: 'Kenilworth · side yard',
    failure: 'Improbable', impact: 'Low', consequence: 'Minor', rating: 'Low',
    observed: 'Deadwood in the upper crown, no decay at the base, no lean change across two visits.',
    action: 'retain',
    recommendation: 'Retain. Crown clean to remove the deadwood — about a tenth of what removal would cost. This tree has decades left.',
  },
  {
    ref: 'A-3', species: 'Silver maple, 61 ft', site: 'West Asheville · street side',
    failure: 'Probable', impact: 'Medium', consequence: 'Significant', rating: 'Moderate',
    observed: 'Basal decay confirmed by resistance drilling; roughly 30% of cross-section compromised.',
    action: 'monitor',
    recommendation: 'Reduce the crown by 20% to lower the sail area, then reassess in twelve months. Not a removal yet, and it may never be.',
  },
  {
    ref: 'A-4', species: 'Eastern hemlock, 52 ft', site: 'North Asheville · driveway',
    failure: 'Imminent', impact: 'High', consequence: 'Severe', rating: 'Extreme',
    observed: 'Root plate lifting after saturation, soil cracking on the windward side, fresh lean of about 8 degrees.',
    action: 'remove',
    recommendation: 'Immediate removal, driveway closed until the crew arrives. This is the one rating that means today rather than this month.',
  },
  {
    ref: 'A-5', species: 'Red maple, 40 ft', site: 'Haw Creek · front lawn',
    failure: 'Improbable', impact: 'Medium', consequence: 'Minor', rating: 'Low',
    observed: 'Surface roots lifting a walkway. Structurally sound; the conflict is with the hardscape, not the tree.',
    action: 'retain',
    recommendation: 'Retain and move the walkway. Cutting those roots to save a path is how a sound tree becomes a hazard in five years.',
  },
  {
    ref: 'A-6', species: 'Bradford pear, 34 ft', site: 'Oakley · near power drop',
    failure: 'Probable', impact: 'High', consequence: 'Significant', rating: 'High',
    observed: 'Classic multi-stem union failure pattern, already split on the north side, over a service drop.',
    action: 'remove',
    recommendation: 'Removal, coordinated with the utility. The species fails this way as a rule rather than as an exception.',
  },
];

/** The scale, published — TRAQ's structure in plain words. */
export const scale = [
  { rating: 'Low', means: 'No action required. Reassess at the normal interval.', urgency: 'Routine' },
  { rating: 'Moderate', means: 'Mitigation worth considering — pruning, reduction, target removal.', urgency: 'This season' },
  { rating: 'High', means: 'Mitigation recommended. Often removal, sometimes not.', urgency: 'Weeks' },
  { rating: 'Extreme', means: 'Failure likely and consequences severe. Restrict the area now.', urgency: 'Today' },
];

/** Real 2026 US figures. */
export const costs = {
  rows: [
    { item: 'Small tree, 10–30 ft', price: '$100 – $400' },
    { item: 'Medium tree, 30–60 ft', price: '$300 – $1,000' },
    { item: 'Large tree, 60 ft+', price: '$1,500 – $3,600' },
    { item: 'Typical removal', price: '$400 – $1,200' },
    { item: 'Rule of thumb', price: '$9.50 – $14.50 per foot of height' },
    { item: 'Emergency / storm, same day', price: '$1,500 – $6,500' },
    { item: 'Crane-dependent hazardous', price: '$12,000+' },
  ],
  separate: [
    'Stump grinding — quoted per stump by diameter, not folded into the removal',
    'Haul-away and chipping — we can leave the chips if you want them',
    'Permits, where the tree is protected or in the right-of-way',
    'Utility coordination, when a service drop is involved',
  ],
  note: 'Those four are separate line items on our quotes because burying them is how a quote stops matching the invoice.',
};

export const storm = {
  surcharge: 'After-hours and storm response carries a 25–50% surcharge over the standard rate. We would rather print that than surprise you with it at 2am.',
  insurance: [
    'Most homeowner policies cover removal only when the tree hit something insured — a house, a fence, a car',
    'A tree that falls in the yard and hits nothing is usually not covered',
    'Typical sublimits run $500–$1,000 per tree, up to about $5,000 total',
    'Photograph everything before anything is cut, including the root plate',
    'We invoice in the format adjusters expect, and we will talk to yours',
  ],
  triage: [
    { when: 'Wires involved', do: 'Call the utility first, not us. We cannot legally touch a tree on a live conductor.' },
    { when: 'Tree on the structure', do: 'Leave the house if anything is creaking. Call us; we work these overnight.' },
    { when: 'Tree down, nothing hit', do: 'It can wait for daylight and a standard rate. That is worth several hundred dollars.' },
    { when: 'Leaning but standing', do: 'Rope off the drop zone at 1.5× the tree height and wait for an assessment.' },
  ],
};

export const areas = [
  { zone: 'Asheville', towns: 'Montford · North Asheville · West Asheville · Kenilworth · Oakley' },
  { zone: 'East', towns: 'Haw Creek · Swannanoa · Black Mountain · Fairview' },
  { zone: 'South', towns: 'Arden · Fletcher · Mills River · Biltmore Forest' },
  { zone: 'North & West', towns: 'Weaverville · Leicester · Candler · Woodfin' },
];

export const reviews = [
  { name: 'Bernice T.', town: 'Kenilworth', text: 'Two companies quoted removal on the poplar. Roman climbed it, wrote a report, and told me it needed deadwooding and nothing else. That was four years ago and it is still standing.' },
  { name: 'Hal W.', town: 'North Asheville', text: 'Hemlock lifted its root plate after the September rain. He looked at it that evening, closed the driveway, and had it down the next morning.' },
  { name: 'Simone A.', town: 'West Asheville', text: 'The report is what sold me. Actual measurements, actual photos, a rating, and a recommendation I could take to my insurer.' },
  { name: 'Devon C.', town: 'Fairview', text: 'Told me the maple roots lifting my path were not the tree\'s fault and that moving the path was cheaper than losing the tree. Nobody else said that.' },
];

export const faqs = [
  { q: 'Do I need an assessment, or can you just quote a removal?', a: 'We can quote a removal, but we will look at the tree properly first and tell you if it does not need to come down. Roughly a third of the trees we are called to assess get a recommendation to keep them. That is not generosity — it is what the assessment is for.' },
  { q: 'What does ISA Certified actually mean?', a: 'An exam, continuing education, and a code of ethics through the International Society of Arboriculture. TRAQ is a separate qualification specifically for risk assessment. Neither is a licence, and plenty of competent climbers hold neither — but if someone is telling you a tree is dangerous, it is fair to ask what training that judgement rests on.' },
  { q: 'Will insurance pay for this?', a: 'Usually only if the tree hit something insured. A tree down in the yard that hit nothing is typically your cost. Sublimits are commonly $500–$1,000 per tree and around $5,000 total, so a large removal often exceeds what the policy pays.' },
  { q: 'Why is storm work more expensive?', a: 'A 25–50% surcharge, because it is night work, in wind, often with the tree under load and next to something it has already damaged. It is the most dangerous work we do and it is priced accordingly.' },
  { q: 'Can you save a tree that is already leaning?', a: 'Sometimes. A tree that has always leaned is different from one that started last week — the second is a root failure and usually not salvageable. We look for soil cracking and a lifted root plate, which is why we ask when you first noticed.' },
  { q: 'Do you top trees?', a: 'No. Topping removes the crown\'s structure, forces weak regrowth, and creates the hazard you were trying to avoid. Any company willing to top a tree for you is telling you something about how they work.' },
];
