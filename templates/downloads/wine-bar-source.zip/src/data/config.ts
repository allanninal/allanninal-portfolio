// ============================================================
// Maison Velours — Day 43 · Wine Bar
// Intimate neighborhood wine bar: curated list, small plates, events, reservations
// Palette: Deep Velvet (#1A0A14) + Burgundy (#7B1D42) + Candlelight Gold (#C9965A) + Parchment (#F2E8DC)
// Fonts: Cinzel (display/headings) + Montserrat (body)
// ============================================================

export const wineBar = {
  name: 'Maison Velours',
  shortName: 'Maison Velours',
  tagline: 'A Wine Bar of Unhurried Pleasures.',
  shortTagline: 'An intimate wine bar in the West Village. Natural wines, small plates, and unhurried evenings.',
  description:
    "Maison Velours is an intimate wine bar in the West Village of New York City. We source small-production, farmer-direct wines from under-represented appellations — orange wines from Georgia, natural reds from the Jura, skin-contact whites from Friuli. Paired with a daily-changing small plates menu crafted around what's seasonal, and a room designed to slow the pace of the city.",
  address: '14 Grove Street, New York, NY 10014',
  phone: '+1 (212) 555-0148',
  email: 'hello@maisonvelours.com',
  reservationUrl: 'https://resy.com',
  instagram: 'https://instagram.com/maisonvelours',
  facebook: 'https://facebook.com/maisonvelours',
  estYear: '2019',
  mapsUrl: 'https://maps.google.com/?q=14+Grove+Street+New+York+NY',
  neighborhood: 'West Village, New York City',
};

// ─── Hours ───────────────────────────────────────────────────────────────────

export type HoursRow = {
  day: string;
  open: string;
  note?: string;
};

export const hours: HoursRow[] = [
  { day: 'Mon–Tue', open: 'Closed',              note: 'We rest, so we can be present for you the rest of the week.' },
  { day: 'Wed–Thu', open: '5:00 PM – 11:00 PM',  note: 'Walk-ins welcome. Reservations encouraged after 7 PM.' },
  { day: 'Friday',  open: '4:00 PM – 12:00 AM',  note: 'Extended service; late-night pours until midnight.' },
  { day: 'Saturday', open: '3:00 PM – 12:00 AM', note: 'Afternoon tastings from 3–5 PM. Evening à la carte from 5 PM.' },
  { day: 'Sunday',  open: '2:00 PM – 9:00 PM',   note: 'Sunday tasting sessions. Leisure pace. Brunch-adjacent plates.' },
];

// ─── Wine List ─────────────────────────────────────────────────────────────────

export type WineTag = 'natural' | 'biodynamic' | 'skin-contact' | 'pét-nat' | 'low-sulphur' | 'by-the-glass' | 'rare' | 'new-arrival';
export type WineCategory = 'red' | 'white' | 'sparkling' | 'orange';

export type Wine = {
  id: string;
  name: string;
  producer: string;
  region: string;
  country: string;
  vintage: string;
  grape: string;
  tastingNotes: string;
  glassPrice?: string;
  bottlePrice: string;
  tags: WineTag[];
  category: WineCategory;
  recommended?: boolean;
};

export type WineSection = {
  id: string;
  label: string;
  icon: string;
  description: string;
  wines: Wine[];
};

export const wineList: WineSection[] = [
  {
    id: 'red',
    label: 'Red',
    icon: '&#9679;',
    description: 'From cool-climate pinots to structured Jura blends — reds with presence but not aggression.',
    wines: [
      {
        id: 'jura-rouge',
        name: 'Les Singuliers Rouge',
        producer: 'Domaine Overnoy-Crinquand',
        region: 'Arbois, Jura',
        country: 'France',
        vintage: '2022',
        grape: 'Poulsard / Trousseau',
        tastingNotes: 'Translucent garnet. Wild strawberry, dried violet, iron filings. Gossamer tannins — almost weightless. A Jura classic for those who seek depth without density.',
        glassPrice: '$18',
        bottlePrice: '$88',
        tags: ['natural', 'low-sulphur', 'by-the-glass'],
        category: 'red',
        recommended: true,
      },
      {
        id: 'burgundy-pommard',
        name: 'Pommard 1er Cru "Les Pézerolles"',
        producer: 'Domaine Courbet',
        region: 'Côte de Beaune, Burgundy',
        country: 'France',
        vintage: '2020',
        grape: 'Pinot Noir',
        tastingNotes: 'Ruby-red with brick at the rim. Black cherry compote, forest floor, spice box. Fine but present tannins with a long, mineral finish. Bottle-only for contemplation.',
        bottlePrice: '$145',
        tags: ['biodynamic', 'rare'],
        category: 'red',
      },
      {
        id: 'ctm-nero',
        name: 'Terre Siciliane Nero d\'Avola',
        producer: 'COS Cerasuolo di Vittoria',
        region: 'Sicily',
        country: 'Italy',
        vintage: '2021',
        grape: 'Nero d\'Avola / Frappato',
        tastingNotes: 'Deep ruby. Cherry jam, sun-dried tomato, cocoa nib. Mediterranean herbs on the finish. Warm, generous, and endlessly food-friendly.',
        glassPrice: '$16',
        bottlePrice: '$74',
        tags: ['natural', 'by-the-glass'],
        category: 'red',
      },
      {
        id: 'loire-cab',
        name: 'Saumur-Champigny "Marginale"',
        producer: 'Thierry Germain / Domaine des Roches Neuves',
        region: 'Loire Valley',
        country: 'France',
        vintage: '2022',
        grape: 'Cabernet Franc',
        tastingNotes: 'Bright crimson. Violet, fresh raspberry, graphite, green pepper. Silky and precise — the ideal Cabernet Franc for warm evenings and cool conversation.',
        glassPrice: '$17',
        bottlePrice: '$82',
        tags: ['biodynamic', 'by-the-glass', 'new-arrival'],
        category: 'red',
      },
    ],
  },
  {
    id: 'white',
    label: 'White',
    icon: '&#9675;',
    description: 'Mineral, textural, alive. Whites chosen for complexity — not just refreshment.',
    wines: [
      {
        id: 'muscadet',
        name: 'Muscadet Sèvre et Maine Sur Lie "Clisson"',
        producer: 'Domaine de la Pepière',
        region: 'Loire Valley',
        country: 'France',
        vintage: '2021',
        grape: 'Melon de Bourgogne',
        tastingNotes: 'Pale gold. Saline, citrus zest, wet stone, brioche from extended lees aging. Lean yet layered — the oyster wine of choice.',
        glassPrice: '$15',
        bottlePrice: '$68',
        tags: ['natural', 'by-the-glass'],
        category: 'white',
        recommended: true,
      },
      {
        id: 'burgundy-white',
        name: 'Puligny-Montrachet "Les Charmes"',
        producer: 'Étienne Sauzet',
        region: 'Côte de Beaune, Burgundy',
        country: 'France',
        vintage: '2021',
        grape: 'Chardonnay',
        tastingNotes: 'Gold-tinged. Ripe pear, hazelnut, cream, white flowers, and a razor-sharp acidity that gives the wine incredible length. A Burgundy benchmark.',
        bottlePrice: '$178',
        tags: ['biodynamic', 'rare'],
        category: 'white',
      },
      {
        id: 'grüner',
        name: 'Grüner Veltliner Smaragd "Achleiten"',
        producer: 'Franz Hirtzberger',
        region: 'Wachau',
        country: 'Austria',
        vintage: '2022',
        grape: 'Grüner Veltliner',
        tastingNotes: 'Pale straw. White pepper, grapefruit, peach, mineral sheen. Full-bodied but never heavy. Smaragd ripeness with Austrian precision.',
        glassPrice: '$19',
        bottlePrice: '$92',
        tags: ['biodynamic', 'by-the-glass'],
        category: 'white',
      },
      {
        id: 'txakoli',
        name: 'Txakoli de Getaria',
        producer: 'Ameztoi',
        region: 'Basque Country',
        country: 'Spain',
        vintage: '2023',
        grape: 'Hondarrabi Zuri',
        tastingNotes: 'Nearly transparent. Tart green apple, saline spray, lemon verbena. Low alcohol, high refreshment. Serve slightly sparkling, very cold.',
        glassPrice: '$14',
        bottlePrice: '$58',
        tags: ['natural', 'by-the-glass', 'new-arrival'],
        category: 'white',
      },
    ],
  },
  {
    id: 'sparkling',
    label: 'Sparkling',
    icon: '&#10022;',
    description: 'Pét-nats, grower Champagnes, and everything the bubble world has been hiding from you.',
    wines: [
      {
        id: 'pet-nat-loire',
        name: 'Vouvray Pét-Nat "L\'Ancestrale"',
        producer: 'Domaine Huet',
        region: 'Loire Valley',
        country: 'France',
        vintage: '2022',
        grape: 'Chenin Blanc',
        tastingNotes: 'Hazy golden. Off-dry and alive with quince, fresh brioche, and a lively mousse. Ancestral method — one fermentation, lightly cloudy, honest.',
        glassPrice: '$16',
        bottlePrice: '$72',
        tags: ['biodynamic', 'pét-nat', 'by-the-glass'],
        category: 'sparkling',
        recommended: true,
      },
      {
        id: 'champagne-rm',
        name: 'Blanc de Blancs Extra Brut',
        producer: 'Pierre Péters — Récoltant-Manipulant',
        region: 'Le Mesnil-sur-Oger, Champagne',
        country: 'France',
        vintage: 'NV',
        grape: 'Chardonnay',
        tastingNotes: 'Bright gold, fine persistent bead. Chalk, green apple, Meyer lemon, almond. The definitive grower Champagne — mineral authority without compromise.',
        glassPrice: '$24',
        bottlePrice: '$118',
        tags: ['by-the-glass', 'rare'],
        category: 'sparkling',
      },
      {
        id: 'crémant',
        name: 'Crémant d\'Alsace Blanc de Blancs',
        producer: 'Domaine Valentin Zusslin',
        region: 'Alsace',
        country: 'France',
        vintage: 'NV',
        grape: 'Auxerrois / Pinot Blanc',
        tastingNotes: 'Pale straw. Apple blossom, pear, gentle brioche toast. Fine mousse, lingering. Great value entry into Alsatian terroir bubbles.',
        glassPrice: '$13',
        bottlePrice: '$52',
        tags: ['biodynamic', 'by-the-glass'],
        category: 'sparkling',
      },
    ],
  },
  {
    id: 'orange',
    label: 'Orange',
    icon: '&#11044;',
    description: 'Extended skin contact whites from the world\'s most adventurous winemakers. Amber, tannic, unforgettable.',
    wines: [
      {
        id: 'georgian-amber',
        name: 'Rkatsiteli Qvevri Amber',
        producer: 'Pheasant\'s Tears',
        region: 'Kakheti',
        country: 'Georgia',
        vintage: '2021',
        grape: 'Rkatsiteli',
        tastingNotes: 'Deep amber-gold. Dried apricot, beeswax, chamomile, tannic grip. Six months in qvevri clay — ancient method, modern revelation. The wine that started the orange wave.',
        glassPrice: '$20',
        bottlePrice: '$96',
        tags: ['natural', 'skin-contact', 'by-the-glass'],
        category: 'orange',
        recommended: true,
      },
      {
        id: 'friuli-ramato',
        name: 'Ramato "Vino del Borgo"',
        producer: 'Radikon',
        region: 'Friuli Colli Orientali',
        country: 'Italy',
        vintage: '2018',
        grape: 'Pinot Grigio',
        tastingNotes: 'Copper-amber. Dried orange peel, walnut skin, wild honey, earthy depth. Complex and evolving over hours in the glass. Not for the fainthearted.',
        bottlePrice: '$128',
        tags: ['natural', 'skin-contact', 'rare'],
        category: 'orange',
      },
      {
        id: 'slovenian-orange',
        name: 'Movia Lunar',
        producer: 'Movia',
        region: 'Brda',
        country: 'Slovenia',
        vintage: '2020',
        grape: 'Ribolla Gialla',
        tastingNotes: 'Burnished gold. Saffron, dried mango, dried rose, gentle tannic texture. Lunar refers to the biodynamic calendar used during vinification. A rare encounter.',
        glassPrice: '$18',
        bottlePrice: '$84',
        tags: ['biodynamic', 'skin-contact', 'by-the-glass', 'new-arrival'],
        category: 'orange',
      },
    ],
  },
];

// ─── Small Plates Menu ─────────────────────────────────────────────────────────

export type Dish = {
  id: string;
  name: string;
  description: string;
  price: string;
  tags?: string[];
  pairsWith?: string[];
};

export const smallPlates: Dish[] = [
  {
    id: 'burrata',
    name: 'Burrata with Roasted Tomato',
    description: 'Buffalo burrata, slow-roasted Calabrian tomatoes, Castelvetrano olives, grilled sourdough. Finishing oil from Leccino olives.',
    price: '$18',
    tags: ['vegetarian'],
    pairsWith: ['Txakoli de Getaria', 'Crémant d\'Alsace'],
  },
  {
    id: 'charcuterie',
    name: 'Charcuterie Selection',
    description: 'Three cured meats from our rotating sourcing — today featuring Ibérico lomo, duck rillettes, and Toscano salumi. House-pickled shallots, grain mustard, cornichons.',
    price: '$24',
    pairsWith: ['Saumur-Champigny', 'Pommard 1er Cru'],
  },
  {
    id: 'cheese',
    name: 'Artisan Cheese Board',
    description: 'A curated trio from our cheesemonger — always one aged, one bloomy, one washed. Honeycomb, fig mostarda, toasted walnuts, seeded crackers.',
    price: '$22',
    tags: ['vegetarian'],
    pairsWith: ['Vouvray Pét-Nat', 'Rkatsiteli Amber'],
  },
  {
    id: 'oysters',
    name: 'Oysters on Ice (Half Dozen)',
    description: 'Market oysters, daily selection from the East or West coast depending on availability. Mignonette, lemon, horseradish cream.',
    price: '$26',
    tags: ['gluten-free'],
    pairsWith: ['Muscadet Clisson', 'Blanc de Blancs'],
  },
  {
    id: 'crudite',
    name: 'Crudités & Whipped Fromage Blanc',
    description: 'Seasonal raw vegetables — endive, radish, fennel, cucumber. Whipped fromage blanc with lemon zest and fresh herbs. Light. Perfect opener.',
    price: '$14',
    tags: ['vegetarian', 'gluten-free'],
    pairsWith: ['Txakoli', 'Muscadet'],
  },
  {
    id: 'sardines',
    name: 'Tinned Sardines',
    description: 'José Gourmet Spiced Tomato Sardines on grilled country bread. Good butter, flaky salt. The world\'s most underrated wine pairing.',
    price: '$16',
    pairsWith: ['Les Singuliers Rouge', 'Txakoli'],
  },
  {
    id: 'mushroom-toast',
    name: 'Wild Mushroom Toast',
    description: 'Chanterelles, maitake, and hen-of-the-woods sautéed in brown butter with thyme. On thick-cut sourdough toast with a soft-cooked egg. Truffled pecorino finish.',
    price: '$19',
    tags: ['vegetarian'],
    pairsWith: ['Grüner Veltliner', 'Friuli Ramato'],
  },
  {
    id: 'anchovy-toast',
    name: 'Anchovy & Salsa Verde Toast',
    description: 'Cantabrian anchovies on toasted pain de campagne, bright salsa verde, shaved grana padano. Briny, punchy, essential.',
    price: '$15',
    pairsWith: ['Muscadet', 'Txakoli'],
  },
];

// ─── Events ───────────────────────────────────────────────────────────────────

export type WineEvent = {
  id: string;
  name: string;
  date: string;
  time: string;
  description: string;
  format: string;
  price?: string;
  ticketUrl?: string;
  free?: boolean;
  capacity?: number;
};

export const events: WineEvent[] = [
  {
    id: 'georgia-tasting',
    name: 'The Qvevri Session: Wines of Georgia',
    date: 'July 10, 2026',
    time: '6:30 PM – 9:00 PM',
    description: 'A guided evening through six wines from the South Caucasus — the birthplace of winemaking. Pheasant\'s Tears, Our Wine, and Teliani Valley pouring alongside co-founder Ghela Beridze, who will speak to the 8,000-year tradition of qvevri clay fermentation. Small plates included.',
    format: 'Guided tasting',
    price: '$85 per person',
    ticketUrl: '#events',
    capacity: 20,
  },
  {
    id: 'live-jazz',
    name: 'Late Friday Jazz & Pour',
    date: 'July 18, 2026',
    time: '8:00 PM – 11:00 PM',
    description: 'Resident jazz trio The West Village Collective plays their second Friday of the month residency. No cover. Come for the music, stay for the Pommard. Walk-ins welcome; reservations strongly advised.',
    format: 'Live music',
    free: true,
  },
  {
    id: 'natural-wine-101',
    name: 'Natural Wine 101: A Beginner\'s Evening',
    date: 'July 25, 2026',
    time: '5:00 PM – 7:00 PM',
    description: 'Our sommelier takes curious beginners through what "natural wine" actually means — no mysticism, just honest conversation about farming, sulphites, and why these wines taste different. Flight of four wines, printed tasting cards, no prior knowledge needed.',
    format: 'Educational tasting',
    price: '$60 per person',
    ticketUrl: '#events',
    capacity: 16,
  },
  {
    id: 'grower-dinner',
    name: 'Winemaker Dinner: Marie Courbet in Conversation',
    date: 'August 7, 2026',
    time: '7:00 PM – 10:30 PM',
    description: 'An intimate seated dinner with Marie Courbet, fifth-generation winemaker from the Côte de Beaune. Five wines across two Burgundy appellations, paired with a four-course menu from our kitchen. Twenty seats only. A rare evening.',
    format: 'Seated dinner',
    price: '$185 per person',
    ticketUrl: '#events',
    capacity: 20,
  },
];

// ─── Our Story ────────────────────────────────────────────────────────────────

export const story = {
  headline: 'Built for the Wine That Doesn\'t Make It to Lists.',
  founderName: 'Céleste Dubois',
  founderTitle: 'Co-Founder & Wine Director',
  bio: [
    'Céleste Dubois spent eight years working cellars and bars across Lyon, Dijon, and eventually a small natural wine bar in the 11th arrondissement of Paris before moving to New York in 2017 with two bags and a list of winemakers nobody in the city was importing yet.',
    'Maison Velours opened in 2019 in a former watchmaker\'s shop on Grove Street — seventeen stools, a narrow zinc bar, and a wine list that fit on one page. It still does. The room is small by design. The wines are chosen because they\'re honest: made by people who farm without shortcuts and bottle without correction.',
    'Today Maison Velours pours around 80 wines by the glass and bottle, rotateing quarterly and chasing the vintage wherever it\'s most alive. The kitchen changes its small plates list weekly around what\'s in season at the Union Square market, two blocks away.',
  ],
  stats: [
    { label: 'Wines on the list', value: '80+' },
    { label: 'Countries represented', value: '14' },
    { label: 'Tables (by design)', value: '17' },
    { label: 'Opened', value: '2019' },
  ],
};

// ─── Gallery ──────────────────────────────────────────────────────────────────

export const gallery = [
  { alt: 'The narrow zinc bar of Maison Velours lit by warm candlelight, rows of wine bottles on dark wooden shelving behind', label: 'The zinc bar', src: 'bar' },
  { alt: 'A deep amber glass of orange wine glowing against dark velvet banquette seating, candlelit table in background', label: 'Rkatsiteli Amber', src: 'amber' },
  { alt: 'Close-up of a sommelier pouring a translucent red wine from a decanter, hands and bottle in soft gold light', label: 'The pour', src: 'pour' },
  { alt: 'Artisan cheese & charcuterie board — cheeses, honeycomb, figs, toasted walnuts and crackers, backlit by candles', label: 'Cheese board', src: 'cheese' },
  { alt: 'Wine cellar with stone walls and old wooden wine racks receding into warm amber light, bottles resting horizontal', label: 'The cellar corridor', src: 'cellar' },
  { alt: 'Exterior of Maison Velours at dusk — warm window glow, lit signage, on a quiet Grove Street corner', label: 'Grove Street at dusk', src: 'exterior' },
];

// ─── Maker ────────────────────────────────────────────────────────────────────

export const maker = {
  name: 'Maison Velours',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  email: 'hello@maisonvelours.com',
  kofi: 'https://ko-fi.com/allanninal',
};

// ─── Site Meta ────────────────────────────────────────────────────────────────

export const site = {
  title: 'Maison Velours — Wine Bar, West Village NYC',
  description:
    'An intimate natural wine bar in the West Village, New York. Curated small-production wines by the glass and bottle, seasonal small plates, and regular tastings. Reservations via Resy.',
  url: 'https://www.allanninal.dev/templates/wine-bar/',
  ogImage: '/og-image.png',
  language: 'en',
};
