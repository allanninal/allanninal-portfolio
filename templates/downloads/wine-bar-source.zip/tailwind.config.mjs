/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Cinzel', 'Georgia', 'serif'],
        body: ['Montserrat', 'system-ui', 'sans-serif'],
      },
      colors: {
        velvet:   '#1A0A14',
        burgundy: '#7B1D42',
        wine:     '#5C1530',
        gold:     '#C9965A',
        'gold-light': '#DDB07A',
        parchment: '#F2E8DC',
        'parchment-dim': '#D8C9BA',
        muted:    '#9A7B8A',
      },
    },
  },
  plugins: [],
};
