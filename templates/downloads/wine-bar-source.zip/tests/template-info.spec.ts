import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo renders download and gallery links', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(BAR);
  await expect(templateInfo).toBeVisible();

  // Static download link (both editions point at the static zip).
  const staticLink = templateInfo.locator('a[download]').first();
  await expect(staticLink).toBeVisible();
  expect(await staticLink.getAttribute('href')).toContain('wine-bar-static.zip');

  if (isPro) {
    // Pro swaps the source download for a locked "Get Pro static".
    const getPro = templateInfo.locator('a', { hasText: /Get Pro static/ });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
  } else {
    const sourceLink = templateInfo.locator('a[download]').nth(1);
    await expect(sourceLink).toBeVisible();
    expect(await sourceLink.getAttribute('href')).toContain('wine-bar-source.zip');
  }

  // All 365 link
  await expect(templateInfo.locator('a', { hasText: /All 365/ })).toBeVisible();

  // LinkedIn link — "Build with me" (free) / "Get Pro static" (pro)
  const linkedin = templateInfo.locator('a', { hasText: isPro ? /Get Pro static/ : /Build with me/ });
  await expect(linkedin).toBeVisible();
  expect(await linkedin.getAttribute('href')).toContain('linkedin.com');
});

test('TemplateInfo has no github.com/allanninal/templates deep-links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`${BAR} a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});
