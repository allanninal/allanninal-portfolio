import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Maison Velours/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('wine list section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#wine-list')).toBeVisible();
});

test('wine list heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#wine-list-heading')).toBeVisible();
});

test('wine cards are rendered', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.wine-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('category tabs are rendered', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = await page.locator('[role="tab"]').all();
  if (tabs.length >= 2) {
    await tabs[1].click();
    const selected = await tabs[1].getAttribute('aria-selected');
    expect(selected).toBe('true');
  }
});

test('small plates section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#small-plates')).toBeVisible();
});

test('dish cards are rendered', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.dish-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('events section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#events')).toBeVisible();
});

test('event cards are rendered', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.event-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('visit section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#visit')).toBeVisible();
});

test('contact section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#contact')).toBeVisible();
});

test('newsletter email input is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#newsletter-email')).toBeVisible();
});

test('LinkedIn contact link is present', async ({ page }) => {
  await page.goto('/');
  const linkedinLink = page.locator('a[href*="linkedin.com"]');
  await expect(linkedinLink.first()).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav');
  await expect(nav.first()).toBeVisible();
});

test('skip-nav link is in the DOM', async ({ page }) => {
  await page.goto('/');
  const skipNav = page.locator('.skip-nav');
  await expect(skipNav).toHaveCount(1);
});

test('reservations section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#reservations')).toBeVisible();
});

test('Reserve buttons link to Resy', async ({ page }) => {
  await page.goto('/');
  const resyLinks = page.locator('a[href*="resy.com"]');
  const count = await resyLinks.count();
  expect(count).toBeGreaterThanOrEqual(1);
});
