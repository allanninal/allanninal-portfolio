import type { Page } from '@playwright/test';

// Single-page template; the Pro edition adds a standalone /menu (wine list) page.
export const ROUTES =
  process.env.PUBLIC_EDITION === 'pro' ? ['/', '/menu/'] : ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// No theme toggle on this template — it's always dark velvet
export async function setTheme(page: Page, _theme: 'light' | 'dark') {
  // Wine bar is a single dark theme — this is a no-op
  void page;
}
