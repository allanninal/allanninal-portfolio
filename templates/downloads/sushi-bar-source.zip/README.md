# Sushi Bar — Day 33 of 365

**Hana Omakase** — an elegant Japanese sushi bar / omakase site. Minimalist washi-paper aesthetic, sumi-ink typography, deep-indigo accent, Cormorant Garamond display serif + Noto Sans JP body.

**Live demo:** https://example.com/

---

## What's inside

- **Hero** — full-height dark panel with large kanji character, stat strip (rating / seats / courses)
- **Omakase section** — tasting menu overview, 12-course description, sake pairing, what-to-expect guide
- **À La Carte Menu** — tabbed (Nigiri / Sashimi / Hand Rolls & Maki / Sake & Beverages) with Japanese name annotations and prices
- **Chef story** — narrative bio, philosophy quote, credential panel
- **Reservations** — Tock placeholder CTA, private-event email contact
- **Hours & Location** — full weekly schedule, address, phone, email, Google Maps link
- **Schema.org JSON-LD** — `Restaurant` + `Menu` + `Person` (chef)
- **TemplateInfo bar** — 3-button download bar (static zip, source zip, gallery), gated on `PUBLIC_TEMPLATE_HUB_URL`
- **Analytics** — Google Analytics + AdSense via `AnalyticsHead`, hub-gated

## Palette & Fonts

| Role | Value |
|---|---|
| Background | `#F7F5F0` (washi off-white) |
| Text | `#0F0E0B` (sumi-ink black) |
| Accent | `#3730A3` (deep indigo) — 7.14:1 on bg (AAA) |
| Display font | Cormorant Garamond (400/500/600/700) |
| Body font | Noto Sans JP (300/400/500/700) |

## Quick start

```bash
# Clone / download source
cd sushi-bar
npm install
npm run dev        # http://localhost:4321

# Build for production
npm run build      # → dist/

# Run tests
npm test           # Playwright smoke + a11y + links
npm run test:lighthouse
```

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `PUBLIC_SITE_URL` | `https://example.com` | Canonical site URL |
| `PUBLIC_BASE_PATH` | `/sushi-bar/` | Base path (set to `/` for standalone deploy) |
| `PUBLIC_TEMPLATE_HUB_URL` | _(blank)_ | Set only by the author — enables download bar & analytics |

## License

MIT — free for commercial and personal use. No attribution required.

