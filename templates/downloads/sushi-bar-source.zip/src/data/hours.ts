export interface HoursEntry {
  days: string;
  hours: string;
  note?: string;
}

export const hoursDisplay: HoursEntry[] = [
  { days: 'Monday',          hours: 'Closed' },
  { days: 'Tuesday',         hours: 'Closed' },
  { days: 'Wednesday',       hours: '6:00 pm – 10:00 pm' },
  { days: 'Thursday',        hours: '6:00 pm – 10:00 pm' },
  { days: 'Friday',          hours: '5:30 pm – 10:30 pm' },
  { days: 'Saturday',        hours: '5:00 pm – 10:30 pm' },
  { days: 'Sunday',          hours: '5:00 pm – 9:30 pm',  note: 'Early seating only' },
];

export interface OpeningHoursSpec {
  dayOfWeek: string[];
  opens: string;
  closes: string;
}

export const openingHoursSpec: OpeningHoursSpec[] = [
  { dayOfWeek: ['Wednesday', 'Thursday'], opens: '18:00', closes: '22:00' },
  { dayOfWeek: ['Friday', 'Saturday'],    opens: '17:30', closes: '22:30' },
  { dayOfWeek: ['Sunday'],               opens: '17:00', closes: '21:30' },
];

export const reservationNote =
  'Reservations open 30 days in advance via Tock. Walk-ins at the bar when space permits.';
