export const site = {
  name: 'Hana Omakase',
  kanji: '花',
  tagline: 'Omakase & Sushi Bar',
  neighborhood: 'West Village, New York',
  description:
    'Hana Omakase offers an intimate omakase experience in the West Village. Chef Kenji Matsuda sources single-origin fish from Toyosu Market and local day-boat fishermen, presenting each course with quiet precision.',
  cuisine: 'Japanese, Sushi, Omakase',
  priceRange: '$$$',
  phone: '(212) 555-0183',
  phoneDisplay: '(212) 555-0183',
  email: 'reservations@hanaomakase.com',
  address: {
    street: '83 Bleecker Street',
    city: 'New York',
    state: 'NY',
    zip: '10012',
    full: '83 Bleecker Street, West Village, New York, NY 10012',
    country: 'US',
  },
  geo: {
    lat: 40.7289,
    lng: -74.0022,
  },
  mapUrl: 'https://maps.google.com/?q=83+Bleecker+Street+New+York+NY+10012',
  reservationUrl: 'https://www.exploretock.com',
  instagram: '@hanaomakasenyc',
  instagramUrl: 'https://instagram.com/hanaomakasenyc',
  rating: {
    value: 4.9,
    count: 386,
    max: 5,
  },
  estYear: 2018,
  seats: 12,
  og: {
    alt: 'Hana Omakase — Intimate Omakase & Sushi Bar in West Village, New York',
  },
};

export const chef = {
  name: 'Kenji Matsuda',
  title: 'Executive Chef & Owner',
  origin: 'Kanazawa, Japan',
  bio: `Chef Kenji Matsuda grew up along the Sea of Japan in Kanazawa, a city revered for its seafood culture and quiet refinement. He trained under a master itamae in Kyoto for seven years before moving to New York in 2012.

After stints at two Michelin-starred restaurants in Manhattan, Kenji opened Hana in 2018 with a single intention: twelve seats, one chef, total presence. Every piece served reflects the season, the source, and a stillness that is rare in a city this loud.

He believes omakase is not a meal but a conversation — between the guest's palate, the day's fish, and the chef's instinct.`,
  philosophy:
    'Omakase means "I leave it to you." I take that trust seriously every single night.',
};
