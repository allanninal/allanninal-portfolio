export type MenuCategory = 'omakase' | 'nigiri' | 'sashimi' | 'rolls' | 'sake';

export interface MenuItem {
  name: string;
  nameJa?: string;
  description: string;
  price: string;
  badge?: string;
}

export interface MenuSection {
  id: MenuCategory;
  label: string;
  labelJa: string;
  description: string;
  items: MenuItem[];
}

export const menuSections: MenuSection[] = [
  {
    id: 'omakase',
    label: 'Omakase',
    labelJa: 'おまかせ',
    description: "Chef's tasting — all courses selected by Chef Matsuda based on today's market. Reservations required.",
    items: [
      {
        name: 'Seasonal Omakase',
        nameJa: '季節のおまかせ',
        description: '12 courses: seasonal tsukidashi, 6–7 nigiri pieces, one hand roll, miso, and dessert. Market-sourced daily.',
        price: '$185 per guest',
        badge: 'Signature',
      },
      {
        name: 'Sake Pairing',
        nameJa: '日本酒ペアリング',
        description: 'Four curated pours — junmai daiginjo, kimoto, sparkling nigori — selected to complement each course.',
        price: '+$65 per guest',
      },
    ],
  },
  {
    id: 'nigiri',
    label: 'À La Carte Nigiri',
    labelJa: '握り',
    description: 'Two pieces per order. Fish sourced from Toyosu Market (Tokyo) and day-boat vessels on the East End.',
    items: [
      {
        name: 'Bluefin Tuna — Akami',
        nameJa: '本鮪 赤身',
        description: 'Atlantic bluefin, lean cut. Soy-marinated, served with Hana\'s aged shiso salt.',
        price: '$12',
      },
      {
        name: 'Bluefin Tuna — Chutoro',
        nameJa: '本鮪 中トロ',
        description: 'Medium-fatty belly. Brushed lightly with nikiri, sea salt finish.',
        price: '$18',
        badge: 'Market',
      },
      {
        name: 'Hokkaido Scallop',
        nameJa: 'ホタテ',
        description: 'Plump, sweet, sea-fresh. Yuzu zest, a drop of house ponzu.',
        price: '$10',
      },
      {
        name: 'Wild Salmon',
        nameJa: '鮭',
        description: 'Day-boat sockeye. Cedar-smoked kombu cure, sesame oil.',
        price: '$9',
      },
      {
        name: 'Kampachi',
        nameJa: 'カンパチ',
        description: 'Amberjack from Kagoshima. Clean, bright, lightly pressed.',
        price: '$11',
      },
      {
        name: 'Uni — Santa Barbara',
        nameJa: 'うに',
        description: 'Creamy, oceanic, impossibly fresh. Served on warm shari with gold leaf.',
        price: '$22',
        badge: 'Seasonal',
      },
      {
        name: 'Ikura',
        nameJa: 'いくら',
        description: 'Salmon roe cured in-house with sake and soy. Burst of brine and richness.',
        price: '$10',
      },
      {
        name: 'Sweet Shrimp — Amaebi',
        nameJa: '甘えび',
        description: 'Raw Spot prawn. The head is fried crisp and served on the side.',
        price: '$14',
      },
    ],
  },
  {
    id: 'sashimi',
    label: 'Sashimi',
    labelJa: '刺身',
    description: "Three pieces per order, sliced to order. Served with house wasabi and Hana's aged soy.",
    items: [
      {
        name: 'Hamachi Sashimi',
        nameJa: 'ハマチ刺身',
        description: 'Yellowtail from Kagoshima prefecture. Silky, buttery, gentle sweetness.',
        price: '$16',
      },
      {
        name: 'Salmon Sashimi',
        nameJa: '鮭刺身',
        description: 'Wild Alaskan sockeye. Deep color, clean fat, bright finish.',
        price: '$14',
      },
      {
        name: 'Tuna Sashimi Assortment',
        nameJa: '鮪盛り合わせ',
        description: "Three cuts of bluefin — akami, chutoro, otoro — each treated separately. Chef's recommended progression.",
        price: '$38',
        badge: 'Chef Pick',
      },
      {
        name: 'Seasonal Sashimi Plate',
        nameJa: '季節の刺身',
        description: "Chef's selection of five seasonal fish. Composition changes with the market.",
        price: '$42',
        badge: 'Market',
      },
    ],
  },
  {
    id: 'rolls',
    label: 'Hand Rolls & Maki',
    labelJa: '手巻き・巻き',
    description: 'Classic preparations. Shari made fresh throughout service.',
    items: [
      {
        name: 'Spicy Tuna Hand Roll',
        nameJa: '辛口まぐろ手巻き',
        description: 'Chopped bluefin, togarashi aioli, micro shiso, toasted nori cone.',
        price: '$14',
      },
      {
        name: 'Salmon Avocado Roll',
        nameJa: 'サーモンアボカド巻き',
        description: 'Wild salmon, ripe avocado, cucumber, sesame, rice-paper wrapped.',
        price: '$16',
      },
      {
        name: 'Hana Dragon Roll',
        nameJa: '花ドラゴン巻き',
        description: 'Shrimp tempura inside, hamachi and avocado draped over. Eel sauce, tobiko, radish sprouts.',
        price: '$22',
        badge: 'House Special',
      },
      {
        name: 'Vegetable Kappa Roll',
        nameJa: '野菜かっぱ巻き',
        description: 'Crisp cucumber, pickled daikon, shiso, toasted sesame. Vegan.',
        price: '$10',
      },
    ],
  },
  {
    id: 'sake',
    label: 'Sake & Beverages',
    labelJa: '日本酒・飲み物',
    description: 'Curated selection of premium sake and complementary beverages.',
    items: [
      {
        name: 'Dassai 45 Junmai Daiginjo',
        nameJa: '獺祭 磨き四割五分',
        description: 'Yamaguchi prefecture. Elegant stone fruit, clean minerality. 16% ABV.',
        price: '$18 / glass · $72 / bottle',
      },
      {
        name: 'Born Gold Junmai Daiginjo',
        nameJa: '梵 ゴールド 純米大吟醸',
        description: 'Fukui prefecture. Ultra-premium, long finish, notes of pear and white flower.',
        price: '$26 / glass · $105 / bottle',
        badge: 'Premium',
      },
      {
        name: 'Tamagawa Kimoto Junmai',
        nameJa: '玉川 生酛純米',
        description: 'Kyoto, Kinoshita Brewery. Earthy, umami-rich, traditional slow ferment. Exceptional with fatty fish.',
        price: '$14 / glass · $58 / bottle',
      },
      {
        name: 'Sparkling Nigori',
        nameJa: 'にごり酒 スパークリング',
        description: 'Unfiltered, lightly sweet, effervescent. Excellent as an aperitif or with uni.',
        price: '$16 / glass',
      },
      {
        name: 'Sencha — Hot or Cold',
        nameJa: '煎茶',
        description: 'First-flush Uji green tea, brewed to order. Non-alcoholic.',
        price: '$6',
      },
      {
        name: 'Yuzu Lemonade',
        nameJa: 'ゆずレモネード',
        description: 'House-made, lightly sweetened with kinako honey. Non-alcoholic.',
        price: '$8',
      },
    ],
  },
];
