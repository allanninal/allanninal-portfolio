/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Washi off-white
        bg:         '#F7F5F0',
        surface:    '#FDFCF9',
        'surface-2': '#EEE9DF',
        // Sumi-ink
        text:       '#0F0E0B',
        'text-body': '#2A2825',
        'text-muted': '#5C5852',
        'text-faint': '#9A948C',
        // Deep indigo accent
        accent:     '#3730A3',
        'accent-dark': '#312E81',
        'accent-light': '#E0E7FF',
        // Border
        border:     '#D6D0C8',
        'border-light': '#EAE6DF',
      },
      fontFamily: {
        display: ['Cormorant Garamond', 'Georgia', 'serif'],
        sans: ['Noto Sans JP', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      maxWidth: {
        content: '72rem',
      },
    },
  },
  plugins: [],
};
