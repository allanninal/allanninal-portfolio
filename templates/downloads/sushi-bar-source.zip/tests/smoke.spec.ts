import { test, expect } from '@playwright/test';

test.describe('Sushi Bar — smoke tests', () => {
  test('home page loads with restaurant name', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Hana Omakase/i);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Hana');
  });

  test('navigation links are present', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Main navigation' });
    await expect(nav.getByRole('link', { name: /Omakase/i })).toBeVisible();
    await expect(nav.getByRole('link', { name: 'Menu', exact: true })).toBeVisible();
  });

  test('omakase section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#omakase');
    await expect(section).toBeVisible();
    await expect(section.locator('#omakase-heading')).toBeVisible();
    await expect(section.getByText('Seasonal Omakase')).toBeVisible();
  });

  test('menu tabs are present and switchable', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('tab', { name: /À La Carte Nigiri/i })).toBeVisible();
    await expect(page.getByRole('tab', { name: /Sashimi/i })).toBeVisible();
    await expect(page.getByRole('tab', { name: /Sake/i })).toBeVisible();

    // Default panel shows nigiri (first panel is not hidden)
    const nigiriPanel = page.locator('#tab-panel-nigiri');
    await expect(nigiriPanel).toBeVisible();
    await expect(nigiriPanel.getByText('Bluefin Tuna — Akami')).toBeVisible();

    // Click Sashimi tab
    await page.getByRole('tab', { name: /Sashimi/i }).click();
    const sashimiPanel = page.locator('#tab-panel-sashimi');
    await expect(sashimiPanel).toBeVisible();
    await expect(sashimiPanel.getByText('Hamachi')).toBeVisible();
  });

  test('chef section shows chef name', async ({ page }) => {
    await page.goto('/');
    const chefSection = page.locator('#chef');
    await expect(chefSection).toBeVisible();
    await expect(chefSection.getByRole('heading', { name: /Kenji Matsuda/i })).toBeVisible();
    await expect(chefSection.locator('blockquote footer')).toContainText('Kenji Matsuda');
  });

  test('reserve section has Tock link', async ({ page }) => {
    await page.goto('/');
    const reserveSection = page.locator('#reserve');
    await expect(reserveSection).toBeVisible();
    await expect(reserveSection.getByRole('heading', { name: /Book Your Seat/i })).toBeVisible();
    await expect(reserveSection.getByRole('link', { name: /Reserve on Tock/i })).toBeVisible();
  });

  test('hours section shows closed on Monday', async ({ page }) => {
    await page.goto('/');
    const hoursSection = page.locator('#hours');
    await expect(hoursSection).toBeVisible();
    await expect(hoursSection.locator('#hours-heading')).toBeVisible();
    await expect(hoursSection.getByText('Monday')).toBeVisible();
    await expect(hoursSection.getByText('Closed').first()).toBeVisible();
  });

  test('location section shows address', async ({ page }) => {
    await page.goto('/');
    const locationSection = page.locator('#location');
    await expect(locationSection).toBeVisible();
    await expect(locationSection.locator('address')).toContainText('83 Bleecker Street');
    await expect(locationSection.locator('address')).toContainText('New York');
  });

  test('JSON-LD Restaurant schema is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasRestaurant = false;
    let hasOpeningHours = false;
    let hasRating = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('"Restaurant"')) hasRestaurant = true;
      if (content && content.includes('openingHoursSpecification')) hasOpeningHours = true;
      if (content && content.includes('AggregateRating')) hasRating = true;
    }
    expect(hasRestaurant).toBe(true);
    expect(hasOpeningHours).toBe(true);
    expect(hasRating).toBe(true);
  });

  test('JSON-LD has servesCuisine, Menu and Person chef', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasCuisine = false;
    let hasMenu = false;
    let hasPerson = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('servesCuisine')) hasCuisine = true;
      if (content && content.includes('"Menu"')) hasMenu = true;
      if (content && content.includes('"Person"')) hasPerson = true;
    }
    expect(hasCuisine).toBe(true);
    expect(hasMenu).toBe(true);
    expect(hasPerson).toBe(true);
  });

  test('no github.com deep-links in page source', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const deepLinks = html.match(/github\.com\/allanninal\/templates[^"'\s]*/g);
    expect(deepLinks).toBeNull();
  });

  test('hero section is visible and has stat strip', async ({ page }) => {
    await page.goto('/');
    const hero = page.locator('#hero');
    await expect(hero).toBeVisible();
    // Check rating is shown
    await expect(hero.getByText('4.9')).toBeVisible();
  });
});
