/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,mdx}'],
  theme: {
    extend: {
      colors: {
        // Charcoal — 404 page background
        charcoal: {
          950: '#0A0A0A',
          900: '#1A1A1A',
          800: '#2A2A2A',
          700: '#3A3A3A',
          600: '#4A4A4A',
          400: '#888888',
          200: '#CCCCCC',
          100: '#E8E8E8',
        },
        // Amber — 404 accent
        amber: {
          600: '#D97706',
          500: '#EAB308',
          400: '#FDE047',
          300: '#FEF08A',
          100: '#FEF9C3',
        },
        // Cream — 500 page background
        cream: {
          50:  '#FAF8F5',
          100: '#F0EBE3',
          200: '#E2D9CF',
          300: '#CFC5BB',
        },
        // Terracotta — 500 accent
        brick: {
          700: '#8B2E16',
          600: '#B94A2C',
          500: '#CC5D3E',
          400: '#D97A5F',
          100: '#F5D5CB',
          50:  '#FBF0ED',
        },
        // Slate — maintenance page
        slate: {
          900: '#0F172A',
          800: '#1E293B',
          700: '#334155',
          600: '#475569',
          500: '#64748B',
          400: '#94A3B8',
          200: '#E2E8F0',
          100: '#F1F5F9',
          50:  '#F8FAFC',
        },
        // Blue — maintenance CTA
        blue: {
          700: '#1D4ED8',
          600: '#2563EB',
          500: '#3B82F6',
          400: '#60A5FA',
          100: '#DBEAFE',
          50:  '#EFF6FF',
        },
        // Parchment — offline page background
        parchment: {
          50:  '#FAF7F2',
          100: '#F5F0E8',
          200: '#E8E0D0',
          300: '#D6CAB5',
        },
        // Warm grey — offline accents/text
        stone: {
          900: '#1C1917',
          800: '#292524',
          700: '#44403C',
          600: '#57534E',
          500: '#78716C',
          400: '#A8A29E',
          300: '#D6D3D1',
          200: '#E7E5E4',
          100: '#F5F5F4',
        },
        // Ink — universal text
        ink: {
          900: '#111111',
          800: '#1C1C1C',
          700: '#3A3A3A',
          600: '#555555',
          500: '#6B6B6B',
          400: '#8A8A8A',
          300: '#AAAAAA',
          200: '#CCCCCC',
          100: '#E5E5E5',
          50:  '#F9F9F9',
        },
      },
      fontFamily: {
        display: ['Outfit', 'system-ui', 'sans-serif'],
        sans: ['system-ui', '-apple-system', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
