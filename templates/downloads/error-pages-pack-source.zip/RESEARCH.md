# Day 26 — Error Pages Pack — Niche Research

## Concept

**Error Pages Pack** — a free set of 4 production-ready error pages (404, 500, Maintenance, Offline) for Astro, Next.js, Remix, SvelteKit, and any static host. The pack ships as a collection of standalone `.astro` files that developers drop into their existing project.

**Conversion goal:** Not commercial. The goal is *designed minimalism* — each error state makes a frustrated user feel acknowledged and offers one clear, calm path forward.

---

## Visual Differentiation from Days 1–25

### Prior palettes (summary)

| Day | Template | Display Font | Accent | BG Register |
|-----|----------|-------------|--------|-------------|
| 1 | developer-portfolio | Inter | Amber `#FFB020` | Dark |
| 2 | saas-landing | Geist/Inter | Violet/cyan | Light |
| 3 | startup-waitlist | Geist | Electric lime | Dark |
| 4 | link-in-bio | DM Sans | Coral `#FF6B4A` | Light warm |
| 5 | personal-blog | Newsreader | Forest green | Light |
| 6 | documentation-site | IBM Plex | Cobalt `#2563EB` | Light/dark |
| 7 | mobile-app-landing | Manrope | Magenta | Light |
| 8 | agency-studio | custom | Burnt orange `#C2410C` | Warm off-white |
| 9 | resume-cv | Source Serif 4 | -- | Pure white |
| 10 | open-source-project | Outfit | Teal | Dark |
| 11 | newsletter-landing | Lora | Oxblood | Cream |
| 12 | coming-soon | Fraunces | Aubergine | Warm white |
| 13 | ai-startup-landing | Bricolage Grotesque | Amber `#D97706` | Dark |
| 14 | indie-hacker-portfolio | Plus Jakarta Sans | Electric blue | Light paper |
| 15 | designer-portfolio | Archivo Black | Terracotta | Light |
| 16 | photographer-portfolio | DM Sans | Slate-indigo | Pure white |
| 17 | writer-author-site | Playfair Display | Prussian blue | Ivory |
| 18 | course-cohort-landing | Spectral | Deep teal | Warm cream |
| 19 | podcast-site | -- | -- | Dark studio |
| 20 | conference-event | Syne | Emerald `#10B981` | Near-black |
| 21 | wedding-invitation-modern | Cormorant Garamond | Blush/rosé `#C4847A` | Warm ivory |
| 22 | restaurant-general | Libre Baskerville | Olive-gold | Dark olive-charcoal |
| 23 | coffee-shop | Fraunces | Terracotta-rust `#C9531F` | Parchment |
| 24 | non-profit | IBM Plex Serif | Civic navy `#1E3A5F` | Cool off-white |
| 25 | coach-consultant | Raleway | Sage-grey `#4A6741` | Warm linen |

### Day 26 picks — **Outfit** display font + per-page accent variety

**Outfit** is a modern geometric sans-serif by Google Fonts. At large sizes it reads warm and friendly (helpful for error states). It is still untaken in the pack. Body text uses system-ui fallback for lightweight shipping — pack pages load fast.

---

## Per-page Visual Treatment

### 404 Not Found — "Friendly, slightly playful"
- Background: charcoal `#1A1A1A` (near-black, dark mode feel)
- Big number: warm amber `#EAB308` (yellow)
- Headline/body: white `#FFFFFF` / `#D1D5DB`
- Accent buttons: amber on charcoal
- **WCAG check:** amber `#EAB308` on `#1A1A1A` → contrast ratio ~10.5:1 ✓ (large text), body text white on charcoal ✓
- Vibe: playful, grounded, not panicked

### 500 Internal Server Error — "Calm, non-alarming"
- Background: warm cream `#FAF8F5`
- Big number: deep terracotta `#B94A2C` (brick, not blood red)
- Headline/body: charcoal `#1C1C1C` / `#5C5C5C`
- Accent buttons: terracotta outline + fill
- **WCAG check:** terracotta `#B94A2C` on cream `#FAF8F5` → contrast ~5.5:1 ✓ (AA for large text, near-AA for body — used only for number)
- Body text `#1C1C1C` on `#FAF8F5` → ~17:1 ✓
- Vibe: calm engineer, "we're on it"

### Maintenance — "Cool, reassuring"
- Background: white `#FFFFFF`
- Big number/icon: slate `#475569`
- Headline/body: dark slate `#1E293B` / `#475569`
- Accent: slate-blue `#3B82F6` for CTA
- **WCAG check:** slate-blue button with white text → `#3B82F6` on white for text is ~3.1:1 (use for large button text only); button text white `#FFFFFF` on `#3B82F6` bg → ~3.1:1 (WCAG AA for UI components/large text ✓, use 16px+ font); body text `#1E293B` on `#FFFFFF` → ~16:1 ✓
- Vibe: professional, "scheduled downtime"

### Offline — "Dim, warm, low-contrast battery-friendly"
- Background: parchment `#F5F0E8`
- Big number/icon: warm grey `#57534E`
- Headline/body: `#292524` / `#57534E`
- Accent: warm brown `#78716C` for secondary button; primary is subtle
- **WCAG check:** `#292524` on `#F5F0E8` → ~14:1 ✓; `#57534E` on `#F5F0E8` → ~6.8:1 ✓ (AA for all text)
- Vibe: dim screen, calm, "you'll reconnect soon"

---

## Pack Index Page
- 2×2 grid of preview tiles (one per error state)
- Each tile shows: big number, short title, page link
- "How to wire" snippet for Astro + Next.js
- Header: "Drop these in your project. Replace the home/back URLs. Done."
- Light neutral background, Outfit font, clean grid

---

## Schema.org
- Each error page: `WebPage` with `name` + `description`
- 404: also `mainEntity` Action "GoHome"
- Index page: `BreadcrumbList`
- Every page: `<meta name="robots" content="noindex">` (error states shouldn't be indexed)

---

## Key Design Decisions

1. **Outfit** (Google Fonts) — untaken display font, geometric but warm at large sizes
2. System-ui body fallback — keeps pack lightweight, no extra font load for body text
3. Each error page is visually distinct — per-page accent color, per-page bg register
4. Pack still coheres because: all use Outfit for the big number + Outfit for headings, same layout skeleton, same TemplateInfo bar
5. Dark 404, light 500, light-neutral Maintenance, warm-parchment Offline — four different registers across one pack
6. NO Tailwind opacity modifiers on text — all colors fully opaque
