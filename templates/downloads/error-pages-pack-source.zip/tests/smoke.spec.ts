import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';

// Smoke tests for all 5 routes: index + 4 error pages

test.describe('Error Pages Pack — smoke tests', () => {

  // Index page
  test('index page loads with h1 "Error Pages Pack"', async ({ page }) => {
    await page.goto('/');
    const heading = page.getByRole('heading', { level: 1, name: /Error Pages Pack/i });
    await expect(heading).toBeVisible();
  });

  test('index page renders 2×2 preview grid with 4 articles', async ({ page }) => {
    await page.goto('/');
    const grid = page.locator('#pages-grid .grid');
    const tiles = grid.locator('article');
    await expect(tiles).toHaveCount(4);
  });

  test('index page has links to all 4 error pages', async ({ page }) => {
    await page.goto('/');
    const links = [
      page.getByRole('link', { name: /View this page/i }).nth(0),
      page.getByRole('link', { name: /View this page/i }).nth(1),
      page.getByRole('link', { name: /View this page/i }).nth(2),
      page.getByRole('link', { name: /View this page/i }).nth(3),
    ];
    for (const link of links) {
      await expect(link).toBeVisible();
    }
  });

  test('index page has "How to wire" section', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#how-to-wire');
    await expect(section).toBeVisible();
    const h2 = section.getByRole('heading', { level: 2 });
    await expect(h2).toBeVisible();
  });

  // 404 page
  test('404 page loads with correct h1', async ({ page }) => {
    await page.goto('/404/');
    const main = page.locator('#error-404');
    await expect(main).toBeVisible();
    const heading = main.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText(/doesn't exist|not found/i);
  });

  test('404 page has large "404" visual anchor', async ({ page }) => {
    await page.goto('/404/');
    const main = page.locator('#error-404');
    const numEl = main.locator('span').filter({ hasText: '404' }).first();
    await expect(numEl).toBeVisible();
  });

  test('404 page has Go home and Contact support CTAs', async ({ page }) => {
    await page.goto('/404/');
    const main = page.locator('#error-404');
    const goHome = main.getByRole('link', { name: /Go home/i });
    const contact = main.getByRole('link', { name: /Contact support/i });
    await expect(goHome).toBeVisible();
    await expect(contact).toBeVisible();
  });

  test('404 page title is "404 — Page not found"', async ({ page }) => {
    await page.goto('/404/');
    await expect(page).toHaveTitle(/404.*page not found/i);
  });

  // 500 page
  test('500 page loads with correct h1', async ({ page }) => {
    await page.goto('/500/');
    const main = page.locator('#error-500');
    await expect(main).toBeVisible();
    const heading = main.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText(/went wrong|server error/i);
  });

  test('500 page has large "500" visual anchor', async ({ page }) => {
    await page.goto('/500/');
    const main = page.locator('#error-500');
    const numEl = main.locator('span').filter({ hasText: '500' }).first();
    await expect(numEl).toBeVisible();
  });

  test('500 page has Go home and Try again CTAs', async ({ page }) => {
    await page.goto('/500/');
    const main = page.locator('#error-500');
    const goHome = main.getByRole('link', { name: /Go home/i });
    const tryAgain = main.getByRole('button', { name: /Try again/i });
    await expect(goHome).toBeVisible();
    await expect(tryAgain).toBeVisible();
  });

  test('500 page title is "500 — Internal server error"', async ({ page }) => {
    await page.goto('/500/');
    await expect(page).toHaveTitle(/500.*server error/i);
  });

  // Maintenance page
  test('maintenance page loads with correct h1', async ({ page }) => {
    await page.goto('/maintenance/');
    const main = page.locator('#error-maintenance');
    await expect(main).toBeVisible();
    const heading = main.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText(/updating|maintenance/i);
  });

  test('maintenance page has Check status and Contact support CTAs', async ({ page }) => {
    await page.goto('/maintenance/');
    const main = page.locator('#error-maintenance');
    const statusBtn = main.getByRole('link', { name: /Check status/i });
    const contactBtn = main.getByRole('link', { name: /Contact support/i });
    await expect(statusBtn).toBeVisible();
    await expect(contactBtn).toBeVisible();
  });

  test('maintenance page title includes "Maintenance"', async ({ page }) => {
    await page.goto('/maintenance/');
    await expect(page).toHaveTitle(/maintenance/i);
  });

  // Offline page
  test('offline page loads with correct h1', async ({ page }) => {
    await page.goto('/offline/');
    const main = page.locator('#error-offline');
    await expect(main).toBeVisible();
    const heading = main.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText(/offline/i);
  });

  test('offline page has Refresh and Go home CTAs', async ({ page }) => {
    await page.goto('/offline/');
    const main = page.locator('#error-offline');
    const refreshBtn = main.getByRole('button', { name: /Refresh/i });
    const goHome = main.getByRole('link', { name: /Go home/i });
    await expect(refreshBtn).toBeVisible();
    await expect(goHome).toBeVisible();
  });

  test('offline page title includes "Offline"', async ({ page }) => {
    await page.goto('/offline/');
    await expect(page).toHaveTitle(/offline/i);
  });

  // Cross-page: noindex on error pages
  test('404 page has noindex meta', async ({ page }) => {
    await page.goto('/404/');
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
  });

  test('500 page has noindex meta', async ({ page }) => {
    await page.goto('/500/');
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
  });

  // Responsive: no horizontal overflow on mobile
  test('index page has no horizontal overflow on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const docWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const vp = await page.evaluate(() => window.innerWidth);
    expect(docWidth).toBeLessThanOrEqual(vp + 1);
  });

  test('404 page has no horizontal overflow on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/404/');
    const docWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const vp = await page.evaluate(() => window.innerWidth);
    expect(docWidth).toBeLessThanOrEqual(vp + 1);
  });

  // Footer: back to pack index link present on all error pages
  test('404 footer has back to pack index link', async ({ page }) => {
    await page.goto('/404/');
    const footer = page.getByRole('contentinfo');
    await expect(footer).toBeVisible();
    const packLink = footer.getByRole('link', { name: /Back to pack index/i });
    await expect(packLink).toBeVisible();
  });

  // No github.com/allanninal/templates deep-links on any page
  test('no github.com/allanninal/templates links on index', async ({ page }) => {
    await page.goto('/');
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) => h.includes('github.com/allanninal/templates'));
    expect(deepLinks).toEqual([]);
  });

  test('no github.com/allanninal/templates links on 404 page', async ({ page }) => {
    await page.goto('/404/');
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) => h.includes('github.com/allanninal/templates'));
    expect(deepLinks).toEqual([]);
  });
});

// ── Edition-aware: the Pro pack adds /status/ and /403/ ──────────────────
test.describe('Error Pages Pack — Pro pages', () => {
  if (isPro) {
    test('index surfaces the Pro pack section with 2 page links', async ({ page }) => {
      await page.goto('/');
      const section = page.locator('#pro-pages');
      await expect(section).toBeVisible();
      const links = section.getByRole('link', { name: /View this page/i });
      await expect(links).toHaveCount(2);
    });

    test('status page loads with overall-status h1 and component list', async ({ page }) => {
      await page.goto('/status/');
      const main = page.locator('#error-status');
      await expect(main).toBeVisible();
      const heading = main.getByRole('heading', { level: 1 });
      await expect(heading).toBeVisible();
      await expect(heading).toContainText(/operational|degraded/i);
      const components = main.locator('#components-heading');
      await expect(components).toBeVisible();
    });

    test('status page title includes "Status"', async ({ page }) => {
      await page.goto('/status/');
      await expect(page).toHaveTitle(/status/i);
    });

    test('403 page loads with Access Denied h1 and visual anchor', async ({ page }) => {
      await page.goto('/403/');
      const main = page.locator('#error-403');
      await expect(main).toBeVisible();
      const heading = main.getByRole('heading', { level: 1 });
      await expect(heading).toBeVisible();
      await expect(heading).toContainText(/access/i);
      const numEl = main.locator('span').filter({ hasText: '403' }).first();
      await expect(numEl).toBeVisible();
    });

    test('403 page has Go home and Contact support CTAs', async ({ page }) => {
      await page.goto('/403/');
      const main = page.locator('#error-403');
      await expect(main.getByRole('link', { name: /Go home/i })).toBeVisible();
      await expect(main.getByRole('link', { name: /Contact support/i })).toBeVisible();
    });

    test('Pro pages carry noindex meta', async ({ page }) => {
      await page.goto('/status/');
      expect(await page.locator('meta[name="robots"]').getAttribute('content')).toContain('noindex');
      await page.goto('/403/');
      expect(await page.locator('meta[name="robots"]').getAttribute('content')).toContain('noindex');
    });
  } else {
    test('free edition has no Pro pack section on index', async ({ page }) => {
      await page.goto('/');
      await expect(page.locator('#pro-pages')).toHaveCount(0);
    });

    test('free edition redirects /status/ to the pack index', async ({ page }) => {
      await page.goto('/status/');
      await expect(page.locator('#error-status')).toHaveCount(0);
      await expect(page.getByRole('heading', { level: 1, name: /Error Pages Pack/i })).toBeVisible();
    });

    test('free edition redirects /403/ to the pack index', async ({ page }) => {
      await page.goto('/403/');
      await expect(page.locator('#error-403')).toHaveCount(0);
      await expect(page.getByRole('heading', { level: 1, name: /Error Pages Pack/i })).toBeVisible();
    });
  }
});
