# Error Pages Pack — Day 26 of 365

A free set of 4 production-ready error pages for Astro, Next.js, Remix, SvelteKit, and any static host.

**Live demo:** https://templates.allanninal.dev/error-pages-pack/

---

## What's included

| Page | Route | Vibe |
|------|-------|------|
| Index / Gallery | `/` | Pack contents, preview tiles, wiring guide |
| 404 Not Found | `/404/` | Amber-on-charcoal, friendly + playful |
| 500 Server Error | `/500/` | Brick-on-cream, calm + non-alarming |
| Maintenance | `/maintenance/` | Slate-on-white, cool + reassuring |
| Offline | `/offline/` | Stone-on-parchment, dim + battery-friendly |

Each page is a standalone `.astro` file. No shared state, no JS required for the page content.

---

## Quick start

```bash
cd templates/error-pages-pack
npm install
npm run dev
```

Copy the error page(s) you need into your project and replace the "Go home" URL.

---

## How to wire

### Astro
Copy `src/pages/404.astro` into your project's `src/pages/` directory. Astro automatically serves `404.astro` for unmatched routes on static deploys.

### Next.js (App Router)
Port to `app/not-found.tsx` (404) or `app/error.tsx` (500).

### Next.js (Pages Router)
Port to `pages/404.tsx` and `pages/500.tsx`.

### Static hosts (Netlify / Vercel / Cloudflare Pages)
Run `npm run build`, then copy the rendered `dist/404/index.html` into your host's custom error page slot. For Netlify: rename to `404.html` at the publish root.

### Offline page (Service Worker)
Pre-cache the built `offline/index.html` in your service worker install step. On fetch failure, serve the cached offline page.

---

## Design tokens

- **Font:** Outfit (Google Fonts) for headings and numbers; system-ui for body text
- **404:** Amber `#EAB308` on charcoal `#1A1A1A`
- **500:** Brick `#B94A2C` on cream `#FAF8F5`
- **Maintenance:** Slate `#475569` on white `#FFFFFF`, blue `#3B82F6` for CTA
- **Offline:** Stone `#57534E` on parchment `#F5F0E8`

---

## Env vars

| Variable | Description | Default |
|----------|-------------|---------|
| `PUBLIC_SITE_URL` | Used for canonical + OG image URLs | `https://templates.allanninal.dev` |
| `PUBLIC_BASE_PATH` | Base path for sub-path deploys | `/error-pages-pack/` |
| `PUBLIC_TEMPLATE_HUB_URL` | Controls TemplateInfo download bar (blank = bar hidden) | _(blank)_ |

---

## Tech stack

- [Astro](https://astro.build) v4
- [Tailwind CSS](https://tailwindcss.com) v3
- [Outfit](https://fonts.google.com/specimen/Outfit) via @fontsource
- [Playwright](https://playwright.dev) for tests

---

## License

MIT — free to use, modify, and deploy. No attribution required (though appreciated).

Built by [Allan Ninal](https://www.linkedin.com/in/allanninal/) · Part of the [365 Templates](https://templates.allanninal.dev) project.
