/**
 * Post-build script: moves dist/404.html → dist/404/index.html
 * and dist/500.html → dist/500/index.html
 *
 * Why: Astro v4 treats 404.astro/500.astro as special error pages
 * and emits them as flat files even when build.format = 'directory'.
 * The TemplateInfo nav links to /404/ and /500/ as directory routes,
 * so we normalize the output to match the trailingSlash: 'always' convention.
 */
import { mkdirSync, renameSync, existsSync } from 'fs';
import { join } from 'path';

const distDir = new URL('../dist/', import.meta.url).pathname;

for (const code of ['404', '500']) {
  const flatFile = join(distDir, `${code}.html`);
  const targetDir = join(distDir, code);
  const targetFile = join(targetDir, 'index.html');

  if (existsSync(flatFile)) {
    mkdirSync(targetDir, { recursive: true });
    renameSync(flatFile, targetFile);
    console.log(`[fix-error-dirs] moved dist/${code}.html → dist/${code}/index.html`);
  }
}
