// Halden & Co. Painters — configuration data
// Day 73 of the 365-template roadmap
//
// Design note: colour is the product here, so the site chrome is deliberately
// near-monochrome. Every saturated colour on the page comes from `projects`, which
// carries the real paint used on each job. If you re-skin this template, keep the
// chrome quiet — the moment the furniture competes with the swatches, the gallery
// stops working.

export const painter = {
  name:        'Halden & Co. Painters',
  tagline:     'Interior and exterior painting in Providence, with the colour work included',
  description: 'Interior and exterior house painting across Providence and the East Bay. Surface preparation, colour consultation, and a written two-year workmanship warranty. We show you the colour on your own wall before you commit to it.',
  phone:       '(401) 555-0164',
  phoneHref:   'tel:+14015550164',
  email:       'hello@haldenandco.com',
  address:     '88 Valley St, Studio 3',
  city:        'Providence',
  state:       'RI',
  zip:         '02909',
  license:     'RI Contractor Registration #48122',
  licensed:    true,
  insured:     true,
  bonded:      true,
  founded:     2014,
  yearsExperience: 11,
  bookUrl:     '#',
  warrantyYears: 2,
  crewSize: 7,
  homesPainted: 620,
  owner: {
    name:     'Mira Halden',
    title:    'Owner & Colour Consultant',
    initials: 'MH',
    bio:      "I trained as a scenic painter for theatre before I ever painted a house, which is where I learned that colour is a lighting problem more than a taste problem. A grey that reads soft in a showroom goes green in a north-facing room at four in the afternoon. That is the single most common reason people end up hating a colour they chose carefully, and it is why we paint large samples on your actual walls and leave them up for two days before anyone opens a real tin. Eleven years, seven people, and I still do the colour consultations myself.",
  },
  instagram: '#',
  facebook:  '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Halden & Co. Painters — Interior & Exterior, Providence RI',
  description:   'Interior and exterior house painting in Providence. Proper surface prep, colour consultation on your own walls, and a written two-year workmanship warranty.',
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

export const services = [
  {
    slug:     'interior',
    name:     'Interior Painting',
    icon:     'roller',
    tagline:  'Walls, ceilings, trim and doors.',
    desc:     'Full interior repainting, room by room or whole house. Furniture moved and covered, floors protected, holes and cracks filled and sanded before a single coat goes on. Most of the work in a good interior job happens before the paint does.',
    includes: [
      'Furniture moved, floors and fittings covered',
      'Holes, cracks and nail pops filled and sanded',
      'Water stains sealed so they do not bleed back',
      'Two finish coats, cut in by hand at every edge',
      'Site cleaned and put back each evening',
    ],
  },
  {
    slug:     'exterior',
    name:     'Exterior Painting',
    icon:     'house',
    tagline:  'Prep is most of the job on a New England exterior.',
    desc:     'Clapboard, shingle, trim and porches. Washed, scraped, sanded and spot-primed before anything else. New England exteriors fail from moisture and sun on the south face, so those elevations get the extra attention rather than the same treatment as the rest.',
    includes: [
      'Low-pressure wash and full dry-out',
      'Scraped, sanded and spot-primed bare wood',
      'Failed caulk cut out and replaced, not painted over',
      'Rotten trim repaired or replaced before painting',
      'Two coats of 100% acrylic exterior finish',
    ],
  },
  {
    slug:     'colour',
    name:     'Colour Consultation',
    icon:     'swatch',
    tagline:  'Large samples, on your walls, for two days.',
    desc:     'A chip under a shop light tells you almost nothing. We paint large samples on your actual walls, on more than one elevation, and leave them up across two days so you see them in morning light, in afternoon light and under your own lamps.',
    includes: [
      'A visit to look at the light, not just the rooms',
      'Three to five candidates per space, narrowed with you',
      'Large samples painted on your own walls',
      'Seen across two days and under your own lighting',
      'Final schedule written up room by room',
    ],
  },
  {
    slug:     'cabinets',
    name:     'Cabinet Refinishing',
    icon:     'cabinet',
    tagline:  'Sprayed, not brushed. The difference is the finish.',
    desc:     'Kitchen and built-in cabinetry, degreased, sanded, primed and sprayed with a cabinet-grade finish. A fraction of the cost of replacement, and the reason it looks like replacement rather than like painted cabinets is entirely in the preparation.',
    includes: [
      'Doors and drawers removed, labelled and sprayed off-site',
      'Boxes degreased and hand-sanded in place',
      'Bonding primer over factory finishes',
      'Cabinet-grade lacquer, sprayed not brushed',
      'Rehung and adjusted, hardware reinstalled',
    ],
  },
  {
    slug:     'wallpaper',
    name:     'Wallpaper Removal',
    icon:     'peel',
    tagline:  'Off, repaired, and a wall you can actually paint.',
    desc:     'Steam removal, adhesive washed off, and the plaster or board underneath repaired properly. Painting over wallpaper is the shortcut that shows within a year, and stripping it badly leaves a wall that no amount of paint will flatten.',
    includes: [
      'Steamed off in full, including the backing paper',
      'Adhesive residue washed rather than sanded in',
      'Torn drywall paper sealed before filling',
      'Skim coat where the surface needs it',
      'Primed and ready for finish coats',
    ],
  },
  {
    slug:     'commercial',
    name:     'Small Commercial',
    icon:     'store',
    tagline:  'Out of hours, so you do not close.',
    desc:     'Shops, cafés, offices and lobbies, scheduled evenings and weekends so the space keeps trading. Low-odour, fast-cure products where the room has to be back in use the next morning.',
    includes: [
      'Evening and weekend scheduling',
      'Low-VOC, low-odour, fast-cure products',
      'Phased so the space stays open',
      'Clean and clear before you reopen',
      'Certificate of insurance to your landlord',
    ],
  },
];

// ── The gallery ─────────────────────────────────────────────────────────────
// This is the page. Each project carries the ACTUAL paint used, as named swatches
// with their codes, because "we painted this room" is not information and
// "Farrow & Ball Railings on the panelling, Wevet above" is.
export const projects = [
  {
    slug:     'benefit-street-parlour',
    title:    'A north-facing parlour that kept going grey',
    location: 'Benefit Street, Providence',
    scope:    'Interior · two rooms',
    days:     '4 days',
    before:   'Painted a warm off-white two years earlier that read distinctly green from noon onward. The owners had repainted once already trying to fix it.',
    after:    'The problem was the north light, not the colour. We went deliberately warmer than looked right on the chip, and put a deep blue on the panelling so the eye had somewhere else to go.',
    colours: [
      { name: 'Setting Plaster',  code: '231',  hex: '#E5C6B7', use: 'Walls' },
      { name: 'Railings',         code: '31',   hex: '#43474C', use: 'Panelling and trim' },
      { name: 'Wevet',            code: '273',  hex: '#F0EEE9', use: 'Ceiling' },
    ],
  },
  {
    slug:     'east-side-victorian',
    title:    'Three colours on a Victorian, without the theme park',
    location: 'East Side, Providence',
    scope:    'Exterior · full repaint',
    days:     '11 days',
    before:   'Failing paint on the south and west elevations, bare wood on the porch columns, and forty years of caulk that had been painted over rather than replaced.',
    after:    'Body, trim and sash in three tones from the same family rather than three contrasting colours, which is what stops a period exterior looking costumed.',
    colours: [
      { name: 'Hardwick White',   code: '5',    hex: '#C4C2B4', use: 'Clapboard body' },
      { name: 'Off-Black',        code: '57',   hex: '#393A38', use: 'Sash and shutters' },
      { name: 'Slipper Satin',    code: '2004', hex: '#EDE8DC', use: 'Trim and columns' },
    ],
  },
  {
    slug:     'fox-point-kitchen',
    title: 'Cabinets that were replaced without being replaced',
    location: 'Fox Point, Providence',
    scope:    'Cabinet refinishing · 34 doors',
    days:     '6 days',
    before:   'Honey oak from the nineties, structurally perfect. A replacement quote came in at nineteen thousand dollars.',
    after:    'Doors sprayed off-site, boxes done in place, hardware upgraded. Came in under a fifth of the replacement quote and reads as new cabinetry rather than as painted oak.',
    colours: [
      { name: 'Cornforth White',  code: '228',  hex: '#D5D2CB', use: 'Upper cabinets' },
      { name: 'Down Pipe',        code: '26',   hex: '#5C6265', use: 'Lower cabinets and island' },
    ],
  },
  {
    slug:     'wayland-square-shop',
    title:    'A shop repainted without closing for a day',
    location: 'Wayland Square, Providence',
    scope:    'Commercial · 1,400 sq ft',
    days:     '3 nights',
    before:   'A café that could not close, with scuffed walls and a ceiling that had never been painted since the fit-out.',
    after:    'Three consecutive nights, low-odour products, everything back in place before the seven a.m. open. They never lost a trading day.',
    colours: [
      { name: 'Ammonite',         code: '274',  hex: '#D3CFC6', use: 'Walls' },
      { name: 'Studio Green',     code: '93',   hex: '#31403A', use: 'Counter front and shelving' },
    ],
  },
  {
    slug:     'armory-district-stair',
    title:    'Wallpaper off, and the wall underneath fixed',
    location: 'Armory District, Providence',
    scope:    'Interior · stairwell',
    days:     '5 days',
    before:   'Three layers of paper in a two-storey stairwell, the top layer already painted over. Torn drywall paper wherever anyone had tried to pull it.',
    after:    'Steamed off in full, torn facing sealed, then a skim coat over the whole stairwell so the light running down it does not pick out every repair.',
    colours: [
      { name: 'Shaded White',     code: '201',  hex: '#DDD8CB', use: 'Stairwell walls' },
      { name: 'Pitch Black',      code: '256',  hex: '#2B2A29', use: 'Handrail and balusters' },
    ],
  },
  {
    slug:     'blackstone-porch',
    title:    'The porch floor that stopped peeling',
    location: 'Blackstone, Providence',
    scope:    'Exterior · porch and decking',
    days:     '4 days',
    before:   'Repainted every second summer and peeling by the following spring, because each coat went over the last without the failed layers coming off.',
    after:    'Stripped back to bare, primed with an oil-based floor primer, then two coats of porch enamel. Four winters in and still sound.',
    colours: [
      { name: 'Mole’s Breath', code: '276', hex: '#807C77', use: 'Porch floor' },
      { name: 'Wimborne White',   code: '239',  hex: '#EFE9DC', use: 'Ceiling and beadboard' },
    ],
  },
];

export const whyUs = [
  {
    title:     'The colour is tested on your wall',
    stat:      '2 days',
    statLabel: 'samples stay up',
    desc:      'A chip under a shop light tells you nothing about a north-facing room at four in the afternoon. Large samples, on your own walls, seen across two days and under your own lamps.',
  },
  {
    title:     'Preparation is most of the invoice',
    stat:      '60%',
    statLabel: 'of our hours, typically',
    desc:      'Filling, sanding, caulk replacement and priming are where a paint job lasts or fails. A quote that is cheap is almost always cheap here, and you find out in the second winter.',
  },
  {
    title:     'The same crew, start to finish',
    stat:      '7',
    statLabel: 'people, no subs',
    desc:      'Seven of us, all employed. Nobody gets handed to a subcontractor halfway through, and the person who prepped your walls is the person who paints them.',
  },
  {
    title:     'Two-year workmanship warranty',
    stat:      '620+',
    statLabel: 'homes since 2014',
    desc:      'In writing, and separate from the paint manufacturer’s warranty. Peeling, flaking or blistering from how it was applied is ours to put right.',
  },
];

export const serviceArea = [
  {
    zone:          'Providence',
    neighborhoods: ['East Side', 'Fox Point', 'Federal Hill', 'Armory District', 'Blackstone', 'Wayland Square'],
    zips:          ['02906', '02903', '02909', '02908', '02907', '02912'],
  },
  {
    zone:          'East Bay',
    neighborhoods: ['Barrington', 'Bristol', 'Warren', 'Riverside', 'East Providence', 'Rumford'],
    zips:          ['02806', '02809', '02885', '02915', '02914', '02916'],
  },
  {
    zone:          'North',
    neighborhoods: ['Pawtucket', 'Lincoln', 'Cumberland', 'Smithfield', 'North Providence', 'Central Falls'],
    zips:          ['02860', '02865', '02864', '02917', '02911', '02863'],
  },
  {
    zone:          'South & West',
    neighborhoods: ['Cranston', 'Warwick', 'East Greenwich', 'Johnston', 'West Warwick', 'Coventry'],
    zips:          ['02910', '02886', '02818', '02919', '02893', '02816'],
  },
];

export const process = [
  {
    step:  '1',
    title: 'We come and look at the light',
    desc:  'Not just the rooms. Which way they face, what time you use them, and what is already in there. Colour behaves differently in every one of those, and this is the visit that prevents the expensive mistake.',
  },
  {
    step:  '2',
    title: 'Samples on your walls',
    desc:  'Three to five candidates per space, painted large on more than one elevation and left up for two days. You live with them before anyone opens a real tin.',
  },
  {
    step:  '3',
    title: 'A quote that itemises the prep',
    desc:  'Filling, sanding, caulk replacement, priming and any repairs, priced as their own lines. If a cheaper quote exists, this is the section it left out.',
  },
  {
    step:  '4',
    title: 'The work, and the evenings',
    desc:  'Furniture moved and covered, floors protected, and the site put back every evening. You should be able to use the rooms we are not in.',
  },
  {
    step:  '5',
    title: 'Walk it in daylight',
    desc:  `We walk the job with you in daylight rather than under work lamps, snag anything either of us finds, then issue the ${'2'}-year workmanship warranty in writing.`,
  },
];

export const pricing = [
  {
    name:     'Colour Consultation',
    price:    '$285',
    period:   'credited against the work',
    tag:      '',
    featured: false,
    cta:      'Book a Consultation',
    desc:     'A visit, a light assessment, and large samples painted on your own walls. Credited in full if you go ahead with the painting.',
    includes: [
      'Full walk-through, light and orientation noted',
      'Three to five candidates per space',
      'Large samples painted on your own walls',
      'Left up across two days',
      'Written schedule, room by room',
      'Credited in full against the work',
    ],
  },
  {
    name:     'Interior, per room',
    price:    'From $780',
    period:   'walls, ceiling and trim',
    tag:      'Most Booked',
    featured: true,
    cta:      'Get a Quote',
    desc:     'A typical bedroom, fully prepped, with walls, ceiling and trim in two finish coats. Prep itemised separately so you can see what you are paying for.',
    includes: [
      'Furniture moved and everything covered',
      'Filling, sanding and spot-priming',
      'Water stains sealed against bleed-back',
      'Two finish coats, edges cut in by hand',
      'Trim and doors included',
      '2-year workmanship warranty',
    ],
  },
  {
    name:     'Exterior, full house',
    price:    'From $9,800',
    period:   'typical 2,200 sq ft home',
    tag:      '',
    featured: false,
    cta:      'Book a Survey',
    desc:     'Washed, scraped, sanded and spot-primed, with failed caulk cut out rather than painted over, then two coats of acrylic.',
    includes: [
      'Low-pressure wash and full dry-out',
      'Scraping, sanding and spot-priming',
      'Failed caulk cut out and replaced',
      'Rotten trim repaired before painting',
      'Two coats 100% acrylic exterior',
      '2-year workmanship warranty',
    ],
  },
];

export const reviews = [
  {
    name:   'Dana Whitcomb',
    detail: 'East Side · Interior',
    rating: 5,
    quote:  'We had already repainted the front room once trying to stop it going green. Mira looked at it for about a minute and said the problem was the north light, not the colour. She was right. Third time was the charm and it was her charm.',
  },
  {
    name:   'Peter Oyelaran',
    detail: 'Barrington · Exterior',
    rating: 5,
    quote:  'Two other quotes were four thousand dollars cheaper. Both of them had one line that said "prep". Halden’s quote had nine lines and I could see exactly what the difference was. Four winters, no peeling.',
  },
  {
    name:   'Susanna Reyes',
    detail: 'Fox Point · Cabinets',
    rating: 5,
    quote:  'A replacement quote was nineteen thousand. This came in under four and people ask me where I got the cabinets. Not where I got them painted.',
  },
  {
    name:   'Martin Ek',
    detail: 'Wayland Square · Commercial',
    rating: 5,
    quote:  'Three nights, and we opened at seven every morning as usual. I did not lose a single day of trade and the staff barely noticed it happening.',
  },
];

export const faqs = [
  {
    q: 'How do I stop choosing a colour I end up hating?',
    a: 'Stop choosing from chips. A chip is two inches square, viewed under shop lighting, next to fifty other colours — three things that all distort it. Paint large samples on the actual wall, on more than one elevation, and look at them at the times of day you actually use the room. Almost every colour regret we get called about was chosen from a chip.',
  },
  {
    q: 'Why is one quote thousands cheaper than another?',
    a: 'Almost always the preparation. Filling, sanding, caulk replacement and priming are invisible in the finished job and account for most of the hours. A quote with one line that says "prep" and a quote with nine lines are describing different jobs, and you find out which in the second winter.',
  },
  {
    q: 'Can you paint over wallpaper?',
    a: 'We do not. The paint re-wets the adhesive, the seams telegraph through, and bubbles appear within a year. Removing it properly costs more up front and less over any period longer than about eighteen months.',
  },
  {
    q: 'Do I need to move out?',
    a: 'No. We work room by room, cover everything, and put the site back each evening, so you keep the rooms we are not in. Cabinet spraying is the exception — the kitchen is out of use for a few days.',
  },
  {
    q: 'What is the best time of year for exterior work in Rhode Island?',
    a: 'Late spring through early autumn. Modern acrylics go down to about 50°F, but the surface has to be dry through, and after a wet spell that takes longer than people expect. We would rather push a week than paint over damp clapboard.',
  },
  {
    q: 'How long does it take?',
    a: 'A single room is usually two to three days including prep and drying. A full interior runs one to two weeks. A full exterior on a typical house is two weeks, weather permitting, and weather is the variable we cannot promise around.',
  },
  {
    q: 'Do you use the paint I have already bought?',
    a: 'Yes, though we will tell you honestly if it is the wrong product for the surface. Using a wall paint on trim, or an interior product outside, is a job that fails early no matter how well it goes on.',
  },
  {
    q: 'What does the warranty cover?',
    a: 'Two years on our workmanship: peeling, flaking, blistering or failure caused by how it was applied or prepared. Fading and the paint’s own performance sit under the manufacturer’s warranty, which we register in your name.',
  },
];
