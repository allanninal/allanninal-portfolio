import { defineConfig } from 'astro/config';
import stripProAssets from '../../scripts/strip-pro-assets.mjs';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';

const SITE = process.env.PUBLIC_SITE_URL || 'https://templates.allanninal.dev';
const BASE = process.env.PUBLIC_BASE_PATH || '/photographer-portfolio/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [stripProAssets(), tailwind({ applyBaseStyles: false }), sitemap()],
});
