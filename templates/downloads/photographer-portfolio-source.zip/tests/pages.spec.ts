import { test, expect } from '@playwright/test';

test.describe('Photographer Portfolio — page structure', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('page has correct title', async ({ page }) => {
    await expect(page).toHaveTitle(/Allan Ninal.*Photo/i);
  });

  test('page has meta description', async ({ page }) => {
    const desc = await page.getAttribute('meta[name="description"]', 'content');
    expect(desc).toBeTruthy();
    expect(desc!.length).toBeGreaterThan(20);
  });

  test('page has canonical link', async ({ page }) => {
    const canonical = await page.getAttribute('link[rel="canonical"]', 'href');
    expect(canonical).toBeTruthy();
  });

  test('page has OG image meta', async ({ page }) => {
    const ogImage = await page.getAttribute('meta[property="og:image"]', 'content');
    expect(ogImage).toBeTruthy();
    expect(ogImage).toContain('og-image.png');
  });

  test('page has twitter card meta', async ({ page }) => {
    const card = await page.getAttribute('meta[name="twitter:card"]', 'content');
    expect(card).toBe('summary_large_image');
  });

  test('page has JSON-LD Person schema', async ({ page }) => {
    const ldJson = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
      return scripts.map((s) => JSON.parse(s.textContent || '{}'));
    });
    const graph = ldJson.find((s) => s['@graph']);
    expect(graph).toBeTruthy();
    const person = graph['@graph'].find((n: { '@type': string }) => n['@type'] === 'Person');
    expect(person).toBeTruthy();
    expect(person.name).toBe('Allan Ninal');
  });

  test('favicon is present', async ({ page }) => {
    const favicon = await page.getAttribute('link[rel="icon"]', 'href');
    expect(favicon).toContain('favicon.svg');
  });
});

test.describe('Photographer Portfolio — sections', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('hero section is visible with photographer name', async ({ page }) => {
    await expect(page.locator('h1')).toContainText('Allan Ninal');
  });

  test('hero has a full-bleed background image', async ({ page }) => {
    const heroImg = page.locator('#hero img').first();
    await expect(heroImg).toBeVisible();
    const src = await heroImg.getAttribute('src');
    expect(src).toContain('unsplash');
  });

  test('gallery section is visible', async ({ page }) => {
    await expect(page.locator('#work')).toBeVisible();
  });

  test('gallery has 16 photos', async ({ page }) => {
    const photos = page.locator('#gallery-grid [data-lightbox-src]');
    await expect(photos).toHaveCount(16);
  });

  test('stories section is visible', async ({ page }) => {
    await expect(page.locator('#stories')).toBeVisible();
  });

  test('stories section shows 3 collection cards', async ({ page }) => {
    const cards = page.locator('#stories a[href*="stories/"]');
    await expect(cards).toHaveCount(3);
  });

  test('about section is visible', async ({ page }) => {
    await expect(page.locator('#about')).toBeVisible();
  });

  test('services section is visible', async ({ page }) => {
    await expect(page.locator('#services')).toBeVisible();
  });

  test('availability band is visible', async ({ page }) => {
    await expect(page.locator('#availability')).toBeVisible();
    await expect(page.locator('#availability')).toContainText('Available');
  });

  test('contact section is visible', async ({ page }) => {
    await expect(page.locator('#contact')).toBeVisible();
  });

  test('contact section has email link', async ({ page }) => {
    const emailLink = page.locator('a[href^="mailto:"]').first();
    await expect(emailLink).toBeVisible();
  });

  test('contact section has LinkedIn link as primary CTA', async ({ page }) => {
    const linkedInLink = page.locator('#contact a[href*="linkedin"]').first();
    await expect(linkedInLink).toBeVisible();
  });
});

test.describe('Photographer Portfolio — lightbox', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('lightbox opens when clicking a gallery photo', async ({ page }) => {
    // Wait for gallery to load
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await expect(firstTrigger).toBeVisible();

    const lightbox = page.locator('#lightbox');
    await expect(lightbox).not.toHaveClass(/is-open/);

    await firstTrigger.click();
    await expect(lightbox).toHaveClass(/is-open/);
  });

  test('lightbox shows photo after clicking trigger', async ({ page }) => {
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await firstTrigger.click();

    const lightboxImg = page.locator('#lightbox-img');
    await expect(lightboxImg).toBeVisible();
    const src = await lightboxImg.getAttribute('src');
    expect(src).toBeTruthy();
    expect(src).not.toBe('');
  });

  test('lightbox closes when pressing Escape', async ({ page }) => {
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await firstTrigger.click();

    const lightbox = page.locator('#lightbox');
    await expect(lightbox).toHaveClass(/is-open/);

    await page.keyboard.press('Escape');
    await expect(lightbox).not.toHaveClass(/is-open/);
  });

  test('lightbox closes when clicking close button', async ({ page }) => {
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await firstTrigger.click();

    const lightbox = page.locator('#lightbox');
    await expect(lightbox).toHaveClass(/is-open/);

    const closeBtn = page.locator('#lightbox-close');
    await closeBtn.click();
    await expect(lightbox).not.toHaveClass(/is-open/);
  });

  test('lightbox navigates to next photo with ArrowRight', async ({ page }) => {
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await firstTrigger.click();

    const lightboxImg = page.locator('#lightbox-img');
    const initialSrc = await lightboxImg.getAttribute('src');

    await page.keyboard.press('ArrowRight');

    const newSrc = await lightboxImg.getAttribute('src');
    expect(newSrc).not.toBe(initialSrc);
  });

  test('lightbox navigates to prev photo with ArrowLeft', async ({ page }) => {
    // Open second photo
    const triggers = page.locator('.lightbox-trigger');
    await triggers.nth(1).click();

    const lightboxImg = page.locator('#lightbox-img');
    const initialSrc = await lightboxImg.getAttribute('src');

    await page.keyboard.press('ArrowLeft');

    const newSrc = await lightboxImg.getAttribute('src');
    expect(newSrc).not.toBe(initialSrc);
  });

  test('lightbox close button has aria-label', async ({ page }) => {
    const closeBtn = page.locator('#lightbox-close');
    const ariaLabel = await closeBtn.getAttribute('aria-label');
    expect(ariaLabel).toBe('Close lightbox');
  });

  test('lightbox prev/next buttons have aria-labels', async ({ page }) => {
    const prevLabel = await page.locator('#lightbox-prev').getAttribute('aria-label');
    const nextLabel = await page.locator('#lightbox-next').getAttribute('aria-label');
    expect(prevLabel).toBe('Previous photo');
    expect(nextLabel).toBe('Next photo');
  });

  test('lightbox has role=dialog and aria-modal', async ({ page }) => {
    const lightbox = page.locator('#lightbox');
    expect(await lightbox.getAttribute('role')).toBe('dialog');
    expect(await lightbox.getAttribute('aria-modal')).toBe('true');
  });

  test('lightbox focus trap — close button receives focus on open', async ({ page }) => {
    const firstTrigger = page.locator('.lightbox-trigger').first();
    await firstTrigger.click();

    const closeBtn = page.locator('#lightbox-close');
    await expect(closeBtn).toBeFocused();
  });
});

test.describe('Photographer Portfolio — stories pages', () => {
  test('stories index renders', async ({ page }) => {
    const res = await page.goto('/stories/');
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1')).toContainText('Photo Stories');
  });

  test('stories index shows 3 collections', async ({ page }) => {
    await page.goto('/stories/');
    const cards = page.locator('a[href*="/stories/"][href$="/"]').filter({ hasText: /photograph/ });
    await expect(cards).toHaveCount(3);
  });

  const stories = ['ascona-coast', 'tokyo-light-studies', 'rivers-of-borneo'];
  for (const slug of stories) {
    test(`/stories/${slug}/ renders with h1 and lightbox triggers`, async ({ page }) => {
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
      page.on('console', (m) => {
        if (m.type() === 'error') errors.push(`console.error: ${m.text()}`);
      });

      const res = await page.goto(`/stories/${slug}/`);
      expect(res?.status()).toBe(200);
      await expect(page.locator('h1').first()).toBeVisible();

      const triggers = page.locator('.lightbox-trigger');
      await expect(triggers).toHaveCount(3);
      expect(errors).toEqual([]);
    });

    test(`/stories/${slug}/ has ImageGallery JSON-LD`, async ({ page }) => {
      await page.goto(`/stories/${slug}/`);
      const ldJson = await page.evaluate(() => {
        const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
        return scripts.map((s) => JSON.parse(s.textContent || '{}'));
      });
      const gallery = ldJson.find((s: { '@type': string }) => s['@type'] === 'ImageGallery');
      expect(gallery).toBeTruthy();
    });
  }
});

test.describe('Photographer Portfolio — 404 page', () => {
  test('404 page renders', async ({ page }) => {
    const res = await page.goto('/404/');
    expect(res?.status()).toBe(200);
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('h1')).toContainText('404');
  });
});

test.describe('Photographer Portfolio — gallery filter tabs', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('filter tabs are present', async ({ page }) => {
    const tabs = page.locator('.gallery-filter-btn');
    await expect(tabs).toHaveCount(5); // All + 3 collections + Other
  });

  test('clicking a collection filter tab marks it as selected', async ({ page }) => {
    const asconaTab = page.locator('.gallery-filter-btn[data-filter="ascona-coast"]');
    await asconaTab.click();
    expect(await asconaTab.getAttribute('aria-selected')).toBe('true');
  });
});
