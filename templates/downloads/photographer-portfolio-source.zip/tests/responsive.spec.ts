import { test, expect } from '@playwright/test';

const viewports = [
  { name: 'mobile', width: 375, height: 812 },
  { name: 'tablet', width: 768, height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
];

for (const vp of viewports) {
  test.describe(`Photographer Portfolio — responsive @ ${vp.name}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test('homepage renders without horizontal overflow', async ({ page }) => {
      await page.goto('/');
      const overflow = await page.evaluate(() => {
        return document.body.scrollWidth > window.innerWidth;
      });
      expect(overflow).toBe(false);
    });

    test('hero section is visible', async ({ page }) => {
      await page.goto('/');
      await expect(page.locator('#hero')).toBeVisible();
    });

    test('gallery grid is visible', async ({ page }) => {
      await page.goto('/');
      await expect(page.locator('#gallery-grid')).toBeVisible();
    });

    test('header is visible', async ({ page }) => {
      await page.goto('/');
      await expect(page.locator('#site-header')).toBeVisible();
    });
  });
}
