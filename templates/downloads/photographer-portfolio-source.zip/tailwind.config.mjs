/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        accent: {
          DEFAULT: '#3B5BDB',
          dark: '#2F4AC7',
          light: '#EEF2FF',
        },
        ink: {
          DEFAULT: '#0D0D0D',
          secondary: '#6B7280',
          muted: '#9CA3AF',
        },
      },
      letterSpacing: {
        label: '0.12em',
      },
    },
  },
  plugins: [],
};
