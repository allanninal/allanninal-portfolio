export const SITE = {
  name: 'Elena Marchetti',
  role: 'Travel & Documentary Photographer',
  location: 'Southeast Asia',
  tagline: 'Looking through the lens — travel, landscape, and documentary photography.',
  description:
    'A travel and documentary photographer based in Southeast Asia. Available for editorial assignments, commercial licensing and exhibition prints.',
  email: 'hello@elenamarchetti.com',
  url: 'https://example.com/',
  socials: {
    instagram: '#',
    linkedin: '#',
    github: '#',
    kofi: '#',
  },
  availability: 'Available for assignments — 2025',
} as const;

export const SERVICES = [
  {
    id: 'travel',
    label: 'Travel & Landscape',
    description:
      'Long-form travel photography for editorial and commercial clients. Magazine spreads, destination campaigns, and tourism boards. Asia-Pacific specialist.',
  },
  {
    id: 'editorial',
    label: 'Editorial & Portrait',
    description:
      'Portrait sessions and editorial photography for publications, profiles, and brand identity. Studio and location.',
  },
  {
    id: 'commercial',
    label: 'Commercial & Brand',
    description:
      'Brand photography for product, hospitality, and lifestyle clients. Campaigns, lookbooks, and social content.',
  },
  {
    id: 'prints',
    label: 'Prints & Licensing',
    description:
      'Limited edition fine art prints available for purchase. Image licensing for editorial, commercial, and personal use. Inquire for rates.',
  },
] as const;
