export const SITE = {
  name: 'Allan Ninal',
  role: 'Travel & Documentary Photographer',
  location: 'Southeast Asia',
  tagline: 'Looking through the lens — travel, landscape, and documentary photography.',
  description:
    'Allan Ninal is a travel and documentary photographer based in Southeast Asia. Available for editorial assignments, commercial licensing, and exhibition prints.',
  email: 'landix.ninal@gmail.com',
  url: 'https://templates.allanninal.dev/photographer-portfolio/',
  socials: {
    instagram: 'https://www.instagram.com/allanninal',
    linkedin: 'https://www.linkedin.com/in/allanninal',
    github: 'https://github.com/allanninal',
    kofi: 'https://ko-fi.com/allanninal',
  },
  availability: 'Available for assignments — 2025',
} as const;

export const SERVICES = [
  {
    id: 'travel',
    label: 'Travel & Landscape',
    description:
      'Long-form travel photography for editorial and commercial clients. Magazine spreads, destination campaigns, and tourism boards. Asia-Pacific specialist.',
  },
  {
    id: 'editorial',
    label: 'Editorial & Portrait',
    description:
      'Portrait sessions and editorial photography for publications, profiles, and brand identity. Studio and location.',
  },
  {
    id: 'commercial',
    label: 'Commercial & Brand',
    description:
      'Brand photography for product, hospitality, and lifestyle clients. Campaigns, lookbooks, and social content.',
  },
  {
    id: 'prints',
    label: 'Prints & Licensing',
    description:
      'Limited edition fine art prints available for purchase. Image licensing for editorial, commercial, and personal use. Inquire for rates.',
  },
] as const;
