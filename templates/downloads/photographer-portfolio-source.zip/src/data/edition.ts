// Edition flag — turns the free template into its Pro build.
// Free (default): PUBLIC_EDITION unset → isPro false. Pro: PUBLIC_EDITION=pro.
// Built by scripts/zip-pro-templates.mjs (downloads) and the deploy's Pro live
// overlay (demos). See docs/PRO_PLATFORM_PLAN.md.
export const EDITION = import.meta.env.PUBLIC_EDITION === 'pro' ? 'pro' : 'free';
export const isPro = EDITION === 'pro';
