export type Photo = {
  id: string;
  src: string;
  alt: string;
  width: number;
  height: number;
  collection: string | null;
  caption?: string;
};

export type Collection = {
  slug: string;
  title: string;
  year: string;
  location: string;
  description: string;
  heroPhotoId: string;
  photoIds: string[];
};

export const PHOTOS: Photo[] = [
  // Hero
  {
    id: 'hero',
    src: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1600&h=900&fit=crop&q=80',
    alt: 'Mountain lake reflecting golden sunset clouds — signature image',
    width: 1600,
    height: 900,
    collection: null,
  },

  // Collection 1 — Ascona Coast 2024
  {
    id: 'ascona-01',
    src: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=900&h=600&fit=crop&q=80',
    alt: 'Coastal cliffs meeting the turquoise sea at midday, Ascona',
    width: 900,
    height: 600,
    collection: 'ascona-coast',
    caption: 'Ascona Coast, 2024 — midday light on limestone',
  },
  {
    id: 'ascona-02',
    src: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=900&h=1200&fit=crop&q=80',
    alt: 'Narrow cobblestone lane in an old fishing village at dusk',
    width: 900,
    height: 1200,
    collection: 'ascona-coast',
    caption: 'Ascona Coast, 2024 — the village at last light',
  },
  {
    id: 'ascona-03',
    src: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1200&h=800&fit=crop&q=80',
    alt: 'Empty coastal road curving into the hills at sunrise',
    width: 1200,
    height: 800,
    collection: 'ascona-coast',
    caption: 'Ascona Coast, 2024 — the road before the world wakes',
  },

  // Collection 2 — Tokyo Light Studies 2024
  {
    id: 'tokyo-01',
    src: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=1200&h=800&fit=crop&q=80',
    alt: 'Tokyo skyline at night, towers reflecting in the bay',
    width: 1200,
    height: 800,
    collection: 'tokyo-light-studies',
    caption: 'Tokyo Light Studies, 2024 — skyline at midnight',
  },
  {
    id: 'tokyo-02',
    src: 'https://images.unsplash.com/photo-1513407030348-c983a97b98d8?w=900&h=1200&fit=crop&q=80',
    alt: 'Neon signs reflected in wet asphalt after rainfall, Shinjuku',
    width: 900,
    height: 1200,
    collection: 'tokyo-light-studies',
    caption: 'Tokyo Light Studies, 2024 — rain on Shinjuku',
  },
  {
    id: 'tokyo-03',
    src: 'https://images.unsplash.com/photo-1547981609-4b6bfe67ca0b?w=1200&h=800&fit=crop&q=80',
    alt: 'Early morning cherry blossom alley, soft mist, empty street',
    width: 1200,
    height: 800,
    collection: 'tokyo-light-studies',
    caption: 'Tokyo Light Studies, 2024 — sakura before the crowd',
  },

  // Collection 3 — Rivers of Borneo 2023
  {
    id: 'borneo-01',
    src: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=1200&h=800&fit=crop&q=80',
    alt: 'Wide jungle river at dawn, mist rising from the water',
    width: 1200,
    height: 800,
    collection: 'rivers-of-borneo',
    caption: 'Rivers of Borneo, 2023 — the Kinabatangan at first light',
  },
  {
    id: 'borneo-02',
    src: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=900&h=1200&fit=crop&q=80',
    alt: 'Crystal forest stream running over smooth rocks, dappled light',
    width: 900,
    height: 1200,
    collection: 'rivers-of-borneo',
    caption: 'Rivers of Borneo, 2023 — headwaters, Sabah interior',
  },
  {
    id: 'borneo-03',
    src: 'https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?w=1200&h=800&fit=crop&q=80',
    alt: 'Rainforest canopy emerging from morning mist, aerial perspective',
    width: 1200,
    height: 800,
    collection: 'rivers-of-borneo',
    caption: 'Rivers of Borneo, 2023 — canopy in the mist',
  },

  // Additional gallery photos (no collection)
  {
    id: 'extra-01',
    src: 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=1200&h=800&fit=crop&q=80',
    alt: 'Aerial view of turquoise coastline and sandbar from above',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Philippine Sea, 2023',
  },
  {
    id: 'extra-02',
    src: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1200&h=800&fit=crop&q=80',
    alt: 'Mountain range reflected perfectly in a still alpine lake',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Dolomites, Italy, 2023',
  },
  {
    id: 'extra-03',
    src: 'https://images.unsplash.com/photo-1454391304352-2bf4678b1a7a?w=1200&h=800&fit=crop&q=80',
    alt: 'Snow-capped peaks above a glassy mountain lake at golden hour',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Canadian Rockies, 2022',
  },
  {
    id: 'extra-04',
    src: 'https://images.unsplash.com/photo-1493558103817-58b2924bce98?w=1200&h=800&fit=crop&q=80',
    alt: 'Dramatic granite peaks rising above forest in afternoon light',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Patagonia, Chile, 2022',
  },
  {
    id: 'extra-05',
    src: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&h=800&fit=crop&q=80',
    alt: 'Low cloud spilling over a green highland escarpment at sunrise',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Isle of Skye, Scotland, 2021',
  },
  {
    id: 'extra-06',
    src: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=1200&h=800&fit=crop&q=80',
    alt: 'Aerial view of terraced rice paddies in late afternoon',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Banaue, Philippines, 2023',
  },
  {
    id: 'extra-07',
    src: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=1200&h=800&fit=crop&q=80',
    alt: 'Coastal cliffs at sunset, orange sky, calm sea',
    width: 1200,
    height: 800,
    collection: null,
    caption: 'Pacific Coast, 2024',
  },
];

export const COLLECTIONS: Collection[] = [
  {
    slug: 'ascona-coast',
    title: 'Ascona Coast',
    year: '2024',
    location: 'Ticino, Switzerland',
    description:
      'Three days on the northern shore of Lago Maggiore. The light here arrives at an angle I hadn\'t seen before — low, golden, almost horizontal, turning every whitewashed wall into a painting. These are the quiet hours: before breakfast, after dinner, in the seam between tourist and local.',
    heroPhotoId: 'ascona-01',
    photoIds: ['ascona-01', 'ascona-02', 'ascona-03'],
  },
  {
    slug: 'tokyo-light-studies',
    title: 'Tokyo Light Studies',
    year: '2024',
    location: 'Tokyo, Japan',
    description:
      'A week studying how Tokyo handles darkness. The city doesn\'t go dark — it changes frequencies. Neon dissolves into rain; office towers become mirrors; the subway\'s fluorescent hum bleeds onto the platform. I came for the daytime; I stayed for the nights.',
    heroPhotoId: 'tokyo-01',
    photoIds: ['tokyo-01', 'tokyo-02', 'tokyo-03'],
  },
  {
    slug: 'rivers-of-borneo',
    title: 'Rivers of Borneo',
    year: '2023',
    location: 'Sabah, Malaysia',
    description:
      'The Kinabatangan River is the pulse of Sabah\'s interior. You don\'t go to see the jungle — the jungle comes to the river\'s edge. I followed the water for five days, starting in darkness, finding the light as the mist lifted. These photographs are about patience.',
    heroPhotoId: 'borneo-01',
    photoIds: ['borneo-01', 'borneo-02', 'borneo-03'],
  },
];

export const GALLERY_PHOTOS = PHOTOS.filter((p) => p.id !== 'hero');
