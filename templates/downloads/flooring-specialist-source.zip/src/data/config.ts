/**
 * Underfoot Flooring Co. — every string the page renders.
 *
 * The business is fictional. The PRICES ARE NOT: the per-square-foot ranges in
 * `materials` and `pricing` are real 2026 US installed figures (materials +
 * labour) taken from the sources listed in RESEARCH.md. They were left real
 * because an invented number is the one thing a flooring buyer will notice
 * immediately, and because a template whose pricing section is nonsense cannot
 * be adapted — the owner would have to redo the research anyway.
 *
 * Replace every contact detail before you ship this for a real business.
 */

export const site = {
  name: 'Underfoot Flooring Co.',
  shortName: 'Underfoot',
  tagline: 'Hardwood, vinyl plank and tile for Providence homes.',
  description:
    'Owner-installed hardwood, LVP, tile and carpet across greater Providence. Written square-foot pricing before demo day, and a subfloor we test rather than guess at.',
  owner: 'Marisol Tavares',
  ownerRole: 'Owner-installer',
  yearsExperience: 14,
  city: 'Providence',
  state: 'RI',
  region: 'Rhode Island',
  streetAddress: '118 Dexter Street',
  postalCode: '02907',
  phoneDisplay: '(401) 555-0164',
  phoneHref: '+14015550164',
  email: 'hello@underfootflooring.example',
  /* Formspree/Basin/your own endpoint. The demo posts nowhere. */
  formAction: '#',
  hours: 'Mon–Fri 7:30am–5pm · Saturday by appointment',
  schedulingWindow: 'Currently booking installs about three weeks out.',

  /* Head / social */
  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Underfoot Flooring Co. — Hardwood, LVP & Tile Installation in Providence, RI',
  license: 'RI Contractor Registration #CR-40218',
  instagram: 'https://www.instagram.com/underfootflooring',
  facebook: 'https://www.facebook.com/underfootflooring',
};

/** Nav — anchors on this page, so the header works without JS. */
export const nav = [
  { label: 'Materials', href: '#materials' },
  { label: 'Which floor', href: '#compare' },
  { label: 'Subfloor', href: '#subfloor' },
  { label: 'Work', href: '#work' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The four materials. `low`/`high` are installed dollars per square foot,
 * materials + labour + basic prep.
 */
export const materials = [
  {
    id: 'hardwood',
    name: 'Solid & engineered hardwood',
    swatch: '#B07B4F',
    low: 6,
    high: 25,
    typical: '$10–$16 is where most Providence jobs land',
    blurb:
      'Refinishable, and the only floor that adds to an appraisal in this housing stock. Species, grade and plank width move the number more than labour does.',
    bestFor: 'Living rooms, dining rooms, bedrooms, main stairs',
  },
  {
    id: 'lvp',
    name: 'Luxury vinyl plank',
    swatch: '#8C7A6B',
    low: 4.5,
    high: 12,
    typical: 'The honest answer for most basements and baths',
    blurb:
      'Waterproof wear layer, floats over most flat substrates, and the good ones no longer look like a rental. Cannot be refinished — when it wears, it is replaced.',
    bestFor: 'Basements, kitchens, bathrooms, rentals, homes with big dogs',
  },
  {
    id: 'tile',
    name: 'Porcelain & ceramic tile',
    swatch: '#7E8A8C',
    low: 10,
    high: 31,
    typical: 'Averages about $18 installed',
    blurb:
      'The most durable thing we install and the most expensive to remove later. Layout and substrate drive the price far more than the tile you pick.',
    bestFor: 'Bathrooms, mudrooms, entryways, radiant-heat rooms',
  },
  {
    id: 'carpet',
    name: 'Carpet & runners',
    swatch: '#9A9086',
    low: 3,
    high: 11,
    typical: 'Cheapest per foot, shortest life',
    blurb:
      'Quiet, warm and forgiving underfoot. It is not a moral failure in a bedroom, whatever the renovation shows have told you.',
    bestFor: 'Bedrooms, finished attics, stair runners, home offices',
  },
];

/**
 * The comparison. `against: true` marks a row where we recommend AGAINST our
 * own more expensive option — the section is worthless if every row sells.
 */
export const comparison = [
  {
    room: 'Below grade — basements',
    pick: 'LVP',
    against: true,
    reason:
      'Do not let anyone sell you solid hardwood below grade. Slab moisture will cup it inside two heating seasons no matter how good the install is.',
  },
  {
    room: 'Kitchens',
    pick: 'LVP or tile',
    against: true,
    reason:
      'Engineered hardwood survives a kitchen, but a dishwasher line lets go once and you have replaced a floor. We would rather sell you the cheaper material here.',
  },
  {
    room: 'Full bathrooms',
    pick: 'Tile',
    against: false,
    reason:
      'The one room where the expensive answer is also the right one. Sheet vinyl seams fail at the tub, and they fail where you cannot see them.',
  },
  {
    room: 'Living & dining rooms',
    pick: 'Hardwood',
    against: false,
    reason:
      'Refinishable three or four times over its life, and the floor buyers in this market expect to see on the main level.',
  },
  {
    room: 'Bedrooms',
    pick: 'Carpet or hardwood',
    against: true,
    reason:
      'If the budget is tight, carpet the bedrooms and put the money into the main level. Nobody photographs a bedroom floor.',
  },
  {
    room: 'Entry & mudroom',
    pick: 'Tile',
    against: false,
    reason:
      'Rhode Island road salt and February slush. Tile with a sealed grout is the only thing that shrugs it off.',
  },
];

/** The subfloor section — the invisible work. */
export const subfloorSteps = [
  {
    title: 'Moisture, measured',
    body:
      'Concrete gets an in-situ relative-humidity probe; wood subfloors get a pin meter. We record the numbers and give them to you. Manufacturers void warranties over exactly this, and "it looked dry" is not a reading.',
  },
  {
    title: 'Acclimation',
    body:
      'Wood sits in your house, in the room it will live in, until its moisture content matches the space. Rushing this is the most common cause of gaps in January.',
  },
  {
    title: 'Flatness',
    body:
      'Most manufacturers want 3/16" over 10 feet. Older Providence floors rarely start there, so the quote includes what levelling we can see — and says plainly what we cannot see until the old floor is up.',
  },
  {
    title: 'The old floor comes up',
    body:
      'Carpet, tack strip, staples, and any layers a previous owner floated over. Homes here often have three generations of flooring stacked up. Disposal is in the number.',
  },
];

export const process = [
  { step: 1, title: 'Measure', body: 'We measure the actual rooms, not a sketch. Half an hour, no charge, no pitch.' },
  { step: 2, title: 'Samples in your light', body: 'Three or four boards left at the house for a few days. Flooring never looks the same in a showroom as it does in your hallway.' },
  { step: 3, title: 'Written price', body: 'A fixed square-foot number with the prep itemised, and the specific conditions that would change it spelled out. You have this before anything is torn up.' },
  { step: 4, title: 'Demo and prep', body: 'Old floor out, subfloor tested and levelled. This is where a surprise, if there is one, shows up — and you hear about it that day, with a price.' },
  { step: 5, title: 'Install and finish', body: 'One crew, one job, start to finish. Trim, transitions and thresholds included. We take the debris with us.' },
];

export const projects = [
  { room: 'Federal Hill triple-decker, second floor', problem: 'Carpet over 1920s pine that three owners had painted around.', solution: 'Original pine sanded and refinished; 620 sq ft.', material: 'Refinish' },
  { room: 'Cranston ranch, whole main level', problem: 'Four rooms, four different floors, four different heights.', solution: 'One engineered oak throughout, thresholds gone.', material: 'Hardwood' },
  { room: 'Pawtucket mill loft', problem: 'Concrete slab reading 84% RH — hardwood was off the table.', solution: 'Floating LVP over a vapour barrier, 1,100 sq ft.', material: 'LVP' },
  { room: 'East Side bathroom', problem: 'Sheet vinyl lifting at the tub, subfloor soft underneath.', solution: 'Subfloor section replaced, porcelain hex laid.', material: 'Tile' },
  { room: 'Barrington bedrooms', problem: 'Budget would not stretch to hardwood upstairs.', solution: 'Wool-blend carpet in three bedrooms; the hallway got oak.', material: 'Carpet' },
  { room: 'Providence two-family, stairs', problem: 'Treads worn through at the nose, landlord-grade paint.', solution: 'Treads capped in white oak, runner over the top.', material: 'Hardwood' },
];

export const serviceArea = [
  { zone: 'Providence', towns: 'Federal Hill · East Side · Elmhurst · Olneyville · Mount Pleasant' },
  { zone: 'East Bay', towns: 'Barrington · Warren · Bristol · East Providence · Riverside' },
  { zone: 'South & West', towns: 'Cranston · Warwick · Johnston · West Warwick · North Kingstown' },
  { zone: 'Blackstone Valley', towns: 'Pawtucket · Central Falls · Lincoln · Cumberland · Woonsocket' },
];

/** What the square-foot number does and does not carry. */
export const pricing = {
  included: [
    'Removal and disposal of the existing floor',
    'Moisture testing, with the readings written down',
    'Levelling up to 1/4" over 10 feet',
    'Trim, transitions, thresholds and shoe moulding',
    'Moving ordinary furniture — we do the lifting',
    'Daily clean-up, and the dumpster',
  ],
  extra: [
    'Structural subfloor repair found after demo — quoted that day, in writing, before we continue',
    'Asbestos-backed sheet vinyl (common here pre-1985) — abatement is a licensed trade, not us',
    'Levelling beyond 1/4" over 10 feet',
    'Stair work, which is priced per tread rather than per foot',
    'Moving a piano, a safe, or a full-wall aquarium',
  ],
  reference: 'For scale: a 500 sq ft space runs roughly $1,529–$4,860 installed nationally, averaging about $3,160 — near $12.50 a square foot blended across materials.',
};

export const reviews = [
  { name: 'Danielle R.', town: 'Cranston', text: 'Marisol talked us out of hardwood in the basement and into vinyl, which cost her money. Two winters later the floor is flat and I understand why she did it.' },
  { name: 'Anthony P.', town: 'Pawtucket', text: 'She found rot under the old tile on day one, sent a photo and a price the same afternoon, and it did not move after that. That is the whole thing, really.' },
  { name: 'Hyun-woo K.', town: 'East Providence', text: 'The pine under our carpet was in worse shape than anyone thought. They saved it anyway. It looks a hundred years old, which is the point.' },
  { name: 'Grace M.', town: 'Barrington', text: 'Quoted three companies. Underfoot was the only one who measured the rooms and the only one who mentioned moisture at all.' },
];

export const faqs = [
  { q: 'Do you sell the flooring, or just install it?', a: 'Both. We buy at trade pricing and pass the invoice through at cost, with our labour priced separately — so you can see what the material actually cost. You are also welcome to supply your own; the labour rate does not change.' },
  { q: 'Can I put hardwood in my basement?', a: 'Not solid hardwood, no. Below grade, slab moisture moves through concrete year-round and will cup solid wood within a couple of heating seasons. Engineered wood is sometimes viable over a tested slab with a vapour barrier; LVP nearly always is. We will test before answering.' },
  { q: 'How long does a floor take?', a: 'A single room is usually a day or two. A main level runs three to five days, plus acclimation time before we start — typically three to five days for solid wood. Refinishing adds drying time between coats and you will want to be out of the house for it.' },
  { q: 'What is the mess like?', a: 'Demo is loud and dusty. Sanding is worse, though we run dust containment and it is far better than it was ten years ago. We seal off the rooms we are not working in, and we clean daily rather than at the end.' },
  { q: 'My house is from 1910 and nothing is level. Is that a problem?', a: 'It is normal here, and it is the reason the quote has a levelling line in it. We measure the deflection before quoting, so the allowance is based on your floor rather than an average. What we cannot promise is what is under the old floor until it is up.' },
  { q: 'Do you do stairs?', a: 'Yes, priced per tread rather than per square foot — a staircase is joinery, not flooring, and pretending otherwise is how people end up with a change order.' },
  { q: 'Is there a warranty?', a: 'Two years on our labour. Material warranties come from the manufacturer and most of them hinge on documented moisture readings and acclimation, which is exactly why we record ours and hand them to you.' },
  { q: 'Do you take on small jobs?', a: 'A single room, a closet, a landing — yes. There is a minimum that covers a day on site, and we will tell you what it is on the phone rather than after the visit.' },
];
