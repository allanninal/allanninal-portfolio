import { test, expect } from '@playwright/test';

test.describe('Underfoot Flooring — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Underfoot Flooring Co\./);
    await expect(page.locator('h1')).toContainText('Providence');
  });

  test('all four materials render with an installed price range', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#materials article');
    await expect(cards).toHaveCount(4);
    for (const text of await cards.allTextContents()) {
      expect(text).toMatch(/\$\d/);
      expect(text).toContain('sq ft installed');
    }
  });

  // The comparison section is the template's whole argument. If every row
  // recommended the pricier material it would be an advert, so at least three
  // must concede.
  test('the comparison concedes on at least three rows', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#compare article')).toHaveCount(6);
    const conceding = page.locator('#compare .compare-card--against');
    expect(await conceding.count()).toBeGreaterThanOrEqual(3);
  });

  test('the subfloor section is present with four steps', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#subfloor');
    await expect(section.getByRole('heading', { level: 2 })).toBeVisible();
    await expect(section.locator('h3')).toHaveCount(4);
  });

  test('six projects, each led by the problem', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#work article')).toHaveCount(6);
    await expect(page.locator('#work').getByText('Problem').first()).toBeVisible();
  });

  test('pricing splits what is included from what is extra', async ({ page }) => {
    await page.goto('/');
    const pricing = page.locator('#pricing');
    await expect(pricing.getByRole('heading', { name: /In the square-foot price/i })).toBeVisible();
    await expect(pricing.getByRole('heading', { name: /Priced separately/i })).toBeVisible();
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('quote form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('the scheduling strip replaces the sibling templates emergency bar', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText(/Currently booking installs/i)).toBeVisible();
    // A flooring job is never an emergency. There should be no 24/7 band at all.
    await expect(page.getByText(/24\/7|emergency/i)).toHaveCount(0);
  });

  // Scaffold contamination is the most common defect in this library: a template
  // is built by copying its neighbour and everything not rewritten survives.
  test('no trace of the day-74 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    // Only distinctive nouns. "joinery" and "carpenter" are ordinary trade words
    // that appear legitimately in this template's own FAQ copy, so matching them
    // would fail on correct content.
    for (const noun of ['Foursquare', 'Grand Rapids', 'cabinetmaker', 'Ridgeline', 'Oklahoma City']) {
      expect(html.toLowerCase()).not.toContain(noun.toLowerCase());
    }
  });

  test('no horizontal scroll at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    expect(overflow).toBe(false);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro subfloor report is absent from the free build', async ({ page }) => {
    const res = await page.goto('/subfloor-report/');
    expect(res?.status()).toBeLessThan(400);
    // A static build cannot issue a 302: Astro.redirect emits a meta-refresh
    // stub at the URL instead, so the address does not change. What must be
    // true is that no Pro content shipped and the stub points home.
    const html = await page.content();
    expect(html).not.toContain('Pre-install checklist');
    expect(html).not.toContain('ASTM F2170');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
