import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const isPro = process.env.PUBLIC_EDITION === 'pro';

async function violationsFor(page, route) {
  await page.goto(route);
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  return results.violations.map((v) => ({
    id: v.id, impact: v.impact, description: v.description, nodes: v.nodes.length, help: v.helpUrl,
  }));
}

test('a11y: / — zero violations', async ({ page }) => {
  const violations = await violationsFor(page, '/');
  expect(
    violations,
    `Axe violations on /:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});

test('a11y: Pro /sponsor/ — zero violations', async ({ page }) => {
  test.skip(!isPro, 'The /sponsor/ page only exists in the Pro edition');
  const violations = await violationsFor(page, '/sponsor/');
  expect(
    violations,
    `Axe violations on /sponsor/:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});
