// Single source of truth for the newsletter. Cloning users edit this file.
//
// To swap the subscribe form provider:
//   - Buttondown (default): set provider: 'buttondown' + buttondown.slug
//   - Mailchimp:            set provider: 'mailchimp' + mailchimp.action
//   - ConvertKit:           set provider: 'convertkit' + convertkit.formId
//   - Substack fallback:    set useSubstackFallback: true — replaces the
//                           inline form with an external CTA to your
//                           Substack publication.

export const newsletter = {
  name: 'Marginalia',
  // One-sentence positioning — what is this newsletter, and for whom.
  tagline: 'A weekly letter on the overlooked corners of book history.',
  // Long description for meta + JSON-LD.
  description:
    'Marginalia is a weekly newsletter about used bookstores, ephemeral printed objects, and the small histories that live in the margins. Sent every Sunday since 2022 — sometimes 600 words, sometimes 1,200, never an unread.',
  // Cadence + count for the hero subline + counter band.
  cadence: 'Every Sunday',
  foundingYear: 2022,
  // Static fields — refresh manually or via a build-time script (see README).
  issueCount: 84,
  subscriberCount: 4200,
  subscriberCountLabel: '4,200',
  averageReadMinutes: 6,
  language: 'en',
  // ISSN: optional. Leave blank-safe — only register if you've requested
  // one from your country's national library (free for most newsletters).
  issn: '',
  // Public archive URL — links to the newsletter's hosted issue index
  // (Buttondown's archive page or Substack's home).
  archiveUrl: 'https://buttondown.email/marginalia/archive/',
  // Slug used for the favicon mark / monogram.
  monogram: 'M',
};

// ── Subscribe-form configuration ────────────────────────────────────────
//
// Pick exactly ONE provider. The Hero + FinalSubscribe components read
// `provider` and render the matching form. If `useSubstackFallback` is
// true, both form-rendering components instead show an external CTA
// linking to `substackUrl`.
export const subscribe = {
  // 'buttondown' | 'mailchimp' | 'convertkit'
  provider: 'buttondown' as 'buttondown' | 'mailchimp' | 'convertkit',
  useSubstackFallback: false,
  substackUrl: 'https://marginalia.substack.com/',
  // Buttondown: free tier, free embed, public archive included.
  buttondown: {
    slug: 'marginalia',
    actionUrl: 'https://buttondown.email/api/emails/embed-subscribe/marginalia',
  },
  // Mailchimp: paste the form action URL from your audience's signup form.
  mailchimp: {
    action: 'https://YOUR-DC.list-manage.com/subscribe/post?u=USERID&id=LISTID',
    // Hidden bot-trap input name (Mailchimp ships one per list).
    botTrapName: 'b_USERID_LISTID',
  },
  // ConvertKit: paste the form's data-uid + action URL.
  convertkit: {
    action: 'https://app.convertkit.com/forms/FORMID/subscriptions',
    formUid: 'FORMID',
  },
};

// ── What you get — three-item value prop ────────────────────────────────
export const whatYouGet = [
  {
    eyebrow: 'Topics',
    title: 'Bookplates, broadsheets, and the lives of objects.',
    body: 'Each letter takes one small piece of printed history — a marginal note in a 1782 prayer book, the back-room of a London used bookshop, a forgotten typesetter — and follows it where it leads.',
  },
  {
    eyebrow: 'Format',
    title: '600–1,200 words. Footnotes when needed.',
    body: 'No listicles. No "5 things." One subject per issue, treated with care. Written in plain English with citations linked at the bottom.',
  },
  {
    eyebrow: 'Cadence',
    title: 'Every Sunday morning. ~6 minutes to read.',
    body: 'Lands in your inbox before lunch. Skip a week without guilt — every issue stays in the public archive.',
  },
];

// ── Sample issues (the conversion engine) ──────────────────────────────
//
// Each card links to the public archive permalink. `slug` is used for the
// `Article` JSON-LD URL only — the link itself uses `archiveUrl`.
export const issues = [
  {
    slug: 'lighthouse-keepers-margin',
    title: 'The lighthouse keeper who annotated everything.',
    date: '2026-04-26',
    readMinutes: 7,
    teaser:
      'For thirty-two years, James Mathers ran the light at Skerryvore — and read his way through the keeper\'s library twice over. The marginalia survives in pencil, in three different hands, on every page.',
    archiveUrl: 'https://buttondown.email/marginalia/archive/the-lighthouse-keeper/',
  },
  {
    slug: 'penny-bloods-and-paper-stock',
    title: 'Penny bloods and the economics of bad paper.',
    date: '2026-04-19',
    readMinutes: 6,
    teaser:
      'Why the cheapest Victorian fiction was printed on the worst possible stock — and what survived anyway. A short essay on acid, alkaline reserves, and an accidental archive in a Birmingham basement.',
    archiveUrl: 'https://buttondown.email/marginalia/archive/penny-bloods/',
  },
  {
    slug: 'the-back-room-at-skoob',
    title: 'The back room at Skoob.',
    date: '2026-04-12',
    readMinutes: 5,
    teaser:
      'One of London\'s last serious second-hand bookshops keeps its rarities behind a curtain. I went looking for a specific 1903 edition and came back with notes on the geometry of unsorted stock.',
    archiveUrl: 'https://buttondown.email/marginalia/archive/skoob-back-room/',
  },
  {
    slug: 'a-history-of-ticket-stubs',
    title: 'A small history of ticket stubs.',
    date: '2026-04-05',
    readMinutes: 8,
    teaser:
      'They were never meant to be kept. Which is why the ones that survive — wedged into novels, taped into journals, slipped between letters — say more about a life than the things designed to remember.',
    archiveUrl: 'https://buttondown.email/marginalia/archive/ticket-stubs/',
  },
];

// ── Reader quotes ──────────────────────────────────────────────────────
export const quotes = [
  {
    body: 'The only newsletter I read on the day it lands. Slow, careful writing about things I didn\'t know I cared about until I did.',
    attribution: 'A reader in Berlin',
  },
  {
    body: 'Marginalia is what email used to be — a letter from someone who has been thinking, sent to people who want to think too.',
    attribution: 'A bookseller, Edinburgh',
  },
  {
    body: 'I forwarded the bookplate issue to four people and three of them subscribed. The other one already had.',
    attribution: 'A reader in Brooklyn',
  },
];

// ── Author / About ─────────────────────────────────────────────────────
export const author = {
  name: 'Marginalia',
  handle: 'allanninal',
  email: 'hello@marginalia.com',
  // Two-sentence bio, displayed in the About section.
  bio: 'I read in libraries and write in cafés. Marginalia started as an excuse to spend Sundays in archives; four years on, it\'s the longest-running thing I\'ve made.',
  location: 'London, UK',
  socials: {
    linkedin: '#',
    github: '#',
    x: '#',
    mastodon: 'https://mastodon.social/@example',
    bluesky: 'https://bsky.app/profile/allanninal.bsky.social',
    site: 'https://example.com',
  },
};
