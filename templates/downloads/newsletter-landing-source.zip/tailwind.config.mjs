/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Light-default — paper-and-ink editorial register. No dark toggle.
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Work Sans Variable"', '"Work Sans"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Lora Variable"', 'Lora', 'ui-serif', 'Georgia', 'Cambria', 'Times', 'serif'],
        serif: ['"Lora Variable"', 'Lora', 'ui-serif', 'Georgia', 'serif'],
      },
      fontSize: {
        'xs':  ['0.75rem',  { lineHeight: '1.6' }],
        'sm':  ['0.875rem', { lineHeight: '1.65' }],
        'base':['1rem',     { lineHeight: '1.75' }],
        'lg':  ['1.125rem', { lineHeight: '1.65' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.5rem',   { lineHeight: '1.1' }],
        '5xl': ['3.5rem',   { lineHeight: '1.05' }],
        '6xl': ['4.5rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '70rem',
        prose: '64ch',
        column: '42rem', // narrow editorial column
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.015em',
      },
    },
  },
};
