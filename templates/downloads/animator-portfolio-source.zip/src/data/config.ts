// Perry Adisa — Athens, GA.
//
// Fourth reel-adjacent niche in a row. Day 101 refused to be reel-led, day 104
// priced a change by stage, day 105 asked for the wireframe under the render.
// So this one takes the problem that belongs to animation and to none of the
// others: the client sees the worst version first, and reacting to it is what
// breaks the schedule.
//
// Every number the copy quotes is computed from the arrays below.

export const site = {
  name:        'Perry Adisa',
  shortName:   'Perry Adisa',
  title:       'Perry Adisa — Animator, Athens',
  tagline:     'You will see the worst version first.',
  owner:       'Perry Adisa',
  ownerRole:   'Character animator',
  credential:  '2D and 3D character animation since 2015',
  city:        'Athens',
  state:       'GA',
  language:    'en',
  phoneDisplay: '(706) 555-0173',
  phoneHref:   '+17065550173',
  email:       'perry@perryadisa.example',
  streetAddress: '291 W Broad St',
  postalCode:  '30601',
  hours:       'Mon–Fri · animating, so email beats calling',
  bookingWindow: 'Booking shot work from early next month.',
  description:
    'A character animator in Athens. Blocking looks like a puppet having a seizure, splining ' +
    'looks like soup, and only polish looks like animation. Every animator knows that and almost ' +
    'no client does — so this page is about what a note may and may not be about, at each stage.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'What to judge', href: '#matrix' },
  { label: 'Spacing',       href: '#spacing' },
  { label: 'The arithmetic', href: '#arithmetic' },
  { label: 'Rates',         href: '#rates' },
  { label: 'Brief',         href: '#brief' },
];

// ── The permission matrix ─────────────────────────────────────────────────
// Four stages. `now` is what a note may be about; `not` is what is supposed to
// look wrong and cannot be fixed yet without discarding the pass that fixes it.

export const stages = [
  {
    stage: 'Blocking',
    share: 30,
    looks: 'Stepped keys with no inbetweens. The character snaps between poses like a slideshow, holds too long, and reads as a puppet having a seizure.',
    now: 'Staging, silhouette, acting choices, the order of the beats, whether the idea works at all. This is the cheapest moment in the whole shot to change any of them.',
    not: 'Smoothness, weight, overlap, timing between poses. All four are literally not present yet. A note about them here is a note about the next pass.',
  },
  {
    stage: 'Splining',
    share: 25,
    looks: 'The computer has filled the gaps and everything floats. Limbs drift, contact points slide, the whole thing reads as soup. It is almost always worse than the blocking.',
    now: 'Whether a pose survived the transition, and any staging note you did not raise at blocking — grudgingly, and knowing it costs more now.',
    not: 'Floatiness, drift, sliding feet. Those are the definition of this stage and the entire purpose of the next one. This is the stage clients panic at.',
  },
  {
    stage: 'Polish',
    share: 30,
    looks: 'Recognisably animation. Weight, overlap, offset and settle are in. It will look 90% finished, which is a dangerous number.',
    now: 'Timing, weight, personality, the read of every beat. This is the pass those notes were always for, and they land cleanly here.',
    not: 'Staging or acting choices. Changing what the character does at polish means throwing away polish, and the shot goes back three weeks.',
  },
  {
    stage: 'Final',
    share: 15,
    looks: 'Finished. Contact points locked, arcs cleaned, the last 10% that takes as long as it sounds.',
    now: 'Errors. A foot through the floor, a pop, an intersection.',
    not: 'Anything else. At this point a change is a new shot with a discount, and it is more honest to call it that.',
  },
];

export const matrixNote =
  'None of this is a rule about clients being wrong. The notes that arrive early are almost ' +
  'always accurate — the animation IS stiff at blocking, it IS floaty at spline. The problem is ' +
  'only that acting on an accurate note about a deliberately unfinished state means discarding ' +
  'the pass whose entire job was to fix it. Say the note anyway; I will tell you which stage it ' +
  'belongs to and we will both save a week.';

// ── Spacing ───────────────────────────────────────────────────────────────
// Positions along a 100-unit span. Same number of marks; different distribution.
// Eased = ease-in-out, which is what "spacing" means in one picture.

export const spacing = {
  even: [0.0, 8.3, 16.7, 25.0, 33.3, 41.7, 50.0, 58.3, 66.7, 75.0, 83.3, 91.7, 100.0],
  // A true cosine ease-in-out, not hand-typed: (1 - cos(pi * i / (n-1))) / 2.
  // The first draft was typed by eye and was not symmetric — it bunched at the
  // start and coasted into the end, which is a different thing entirely.
  eased: [0.0, 1.7, 6.7, 14.6, 25.0, 37.1, 50.0, 62.9, 75.0, 85.4, 93.3, 98.3, 100.0],
  note:
    'Thirteen drawings in both rows, occupying the same twelve frames and travelling the same ' +
    'distance. The top row is spaced evenly and reads mechanical; the bottom row is bunched at ' +
    'each end and reads as something with weight deciding to move. Nothing else about them is ' +
    'different. That is the whole craft, and it is the one thing in animation a still image can ' +
    'actually show you — which is why it is the only picture on this page.',
};

// ── The arithmetic ────────────────────────────────────────────────────────
// A worked calculation. `val` is the running figure at each line.

export const arithmetic = {
  scene: 'One twelve-second hand-drawn scene',
  lines: [
    { op: '12 seconds × 24 frames',           val: '288 frames',   why: 'The unit clients think in is seconds. The unit the work happens in is frames, and this is the last line where the two agree.' },
    { op: 'Animated on twos',                 val: '144 drawings', why: 'One drawing held for two frames — standard for most character work, and it halves the count without anybody noticing.' },
    { op: '× 3 passes: rough, clean-up, colour', val: '432 drawings', why: 'Roughs decide the acting, clean-up decides the line, colour decides nothing and still has to be done 144 times.' },
    { op: '÷ 18 finished drawings a day',     val: '24 days',      why: 'A realistic sustained rate for one animator on character work. Faster is possible in bursts and not for a month.' },
    { op: 'Twelve seconds',                   val: '≈ 5 weeks',    why: 'For one person, one scene. This is the number worth having before the first conversation about a deadline, and it is the number nobody puts on a portfolio.' },
  ],
  note:
    'Every one of those lines is negotiable and I will happily argue any of them with you — ones ' +
    'instead of twos, a limited palette, fewer passes, a smaller cast. What is not negotiable is ' +
    'that the arithmetic exists. A quote that skips it is a guess wearing a number.',
};

// ── Notes, quoted ─────────────────────────────────────────────────────────

export const said = [
  {
    kind: 'now',
    text: 'At blocking: "I do not believe he decided to stand up — he just is standing up. Can the decision happen before the movement?" That is an acting note at the only stage where it is nearly free, and it made the shot.',
    who: 'The most useful note I have ever received',
  },
  {
    kind: 'not',
    text: 'At spline: "This looks unfinished and floaty, can we get it looking polished before the next review?" Entirely accurate, and it moved the shot to polish a pass early. We lost a week putting the spline pass back.',
    who: 'The most expensive note I have ever received',
  },
];

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: '3D character animation',   figure: '$95 / second', note: 'Quoted per finished second of screen time against a shot list, never against a running time. A dialogue shot and a walk cycle are different jobs.' },
    { what: '2D, on twos, full colour', figure: '$140 / second', note: 'See the arithmetic. The number is high because the drawing count is, and the drawing count is not an opinion.' },
    { what: 'Rough / animatic pass only', figure: '$40 / second', note: 'Frequently the right answer. A pitch does not need clean-up and paying for it is money spent on nothing.' },
    { what: 'Day rate, in a studio pipeline', figure: '$640', note: 'For teams who need somebody inside their own review structure rather than delivering shots.' },
    { what: 'Revisions',                figure: 'Per the matrix', note: 'Notes at the right stage are included, always and without counting. Notes that move a shot backwards are quoted, because that is what they cost.' },
  ],
};

export const faqs = [
  {
    q: 'Is this page telling me my notes are wrong?',
    a: 'The opposite. Early notes are usually correct — it really is stiff at blocking. The point is that acting on a correct note about a deliberately unfinished stage throws away the pass that was about to fix it. Send every note you have; part of my job is knowing which pass each one belongs to.',
  },
  {
    q: 'Can I see a reel?',
    a: 'Yes, in the first email. It will show you finished shots, which is the one state this whole page is arguing you should not judge the process by. Watch it, and then read the matrix — the second one tells you more about working together.',
  },
  {
    q: 'Why does animation cost so much per second?',
    a: 'Read the arithmetic section. Twelve seconds of hand-drawn work is 432 drawings and about five weeks for one person. Nothing about that is inflated, and every line of it is negotiable if you want a cheaper film — but the negotiation has to be about the lines, not about the total.',
  },
  {
    q: 'Do you work on twos or ones?',
    a: 'Twos for most character work, ones where something moves fast enough to strobe, and threes for slow holds. Mixing them within a shot is normal and is a craft decision rather than a budget one, though it does have budget consequences.',
  },
  {
    q: 'Can you match our existing style?',
    a: 'Usually, and I will ask for the rig or the model sheet before quoting rather than after. A style that looks simple frequently costs more, because simple lines show every error.',
  },
  {
    q: 'Do you take on very short jobs?',
    a: 'Yes — a single shot, a loop, a test. Short jobs are how most working relationships in this trade actually start, and I would rather do one shot well than take a whole sequence on trust.',
  },
];
