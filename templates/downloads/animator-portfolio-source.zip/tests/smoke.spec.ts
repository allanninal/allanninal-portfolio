import { test, expect } from '@playwright/test';

test.describe('Perry Adisa — smoke tests', () => {
  test('homepage renders with the animator name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Perry Adisa/);
    await expect(page.locator('h1')).toContainText('worst version first');
  });

  test('is marked up as a Person, with no business-only fields', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q266569');
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // ── The permission matrix ───────────────────────────────────────────────
  test('every stage carries both permissions, and the shares total 100', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#matrix > div > dl.matrix > div, #matrix dl.matrix > div');
    const n = await rows.count();
    expect(n).toBe(4);
    let share = 0;
    for (const r of await rows.all()) {
      await expect(r.locator('.perm--now')).toHaveCount(1);
      await expect(r.locator('.perm--not')).toHaveCount(1);
      const dt = (await r.locator('dt').textContent()) || '';
      share += Number((dt.match(/(\d+)% of the shot/) || [])[1] || 0);
    }
    expect(share).toBe(100);
    await expect(page.locator('#matrix .eyebrow')).toContainText(`${n} stages · ${share}%`);
  });

  // The entire content is two states, so hue must be the last signal, not the first.
  test('both permissions are words and glyphs before they are colours', async ({ page }) => {
    await page.goto('/');
    const labels = await page.locator('#matrix .perm b').allTextContents();
    expect(labels.length).toBe(8);
    for (const l of labels) expect(['Judge this now', 'Not yet']).toContain(l.trim());
    for (const b of await page.locator('#matrix .perm b').all()) {
      expect(await b.getAttribute('data-glyph')).toBeTruthy();
    }
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--note-now', '--note-not', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  test('the spine is a definition list, not a table', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#matrix dl.matrix').count()).toBe(1);
    expect(await page.locator('#matrix table').count()).toBe(0);
  });

  test('the page does not blame the client for early notes', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#matrix')).toContainText(/notes that arrive early are almost\s+always accurate/i);
  });

  // ── Spacing ─────────────────────────────────────────────────────────────
  test('both spacing rows hold the same number of marks over the same distance', async ({ page }) => {
    await page.goto('/');
    const xs = await page.locator('#spacing svg circle').evaluateAll((cs) =>
      cs.map((c) => ({ x: Number(c.getAttribute('cx')), y: Number(c.getAttribute('cy')) })));
    const top = xs.filter((p) => p.y === 11).map((p) => p.x);
    const bot = xs.filter((p) => p.y === 25).map((p) => p.x);
    expect(top.length).toBe(bot.length);
    expect(top.length).toBeGreaterThan(10);
    expect(top[0]).toBeCloseTo(bot[0], 1);
    expect(top[top.length - 1]).toBeCloseTo(bot[bot.length - 1], 1);
    await expect(page.locator('#spacing h2')).toContainText(`Same ${top.length} drawings`);
  });

  test('the top row is evenly spaced and the bottom row eases at both ends', async ({ page }) => {
    await page.goto('/');
    const xs = await page.locator('#spacing svg circle').evaluateAll((cs) =>
      cs.map((c) => ({ x: Number(c.getAttribute('cx')), y: Number(c.getAttribute('cy')) })));
    const gaps = (row: number[]) => row.slice(1).map((v, i) => v - row[i]);
    const top = gaps(xs.filter((p) => p.y === 11).map((p) => p.x));
    const bot = gaps(xs.filter((p) => p.y === 25).map((p) => p.x));
    // even: every gap the same
    expect(Math.max(...top) - Math.min(...top)).toBeLessThan(0.2);
    // eased: middle gap is the largest, and the two end gaps are the smallest
    const mid = bot[Math.floor(bot.length / 2)];
    expect(mid).toBeCloseTo(Math.max(...bot), 1);
    expect(bot[0]).toBeCloseTo(bot[bot.length - 1], 1);
    expect(bot[0]).toBeLessThan(mid / 2);
  });

  test('the only picture is drawn, decorative, and named in the caption', async ({ page }) => {
    await page.goto('/');
    const raster = await page.locator('img').evaluateAll((imgs) =>
      imgs.map((i) => i.getAttribute('src') || '').filter((s) => /\.(jpe?g|png|webp|avif)$/i.test(s)));
    expect(raster).toEqual([]);
    await expect(page.locator('#spacing svg')).toHaveAttribute('aria-hidden', 'true');
    const cap = page.locator('#spacing figcaption');
    await expect(cap).toContainText(/Top row, even spacing/);
    await expect(cap).toContainText(/Bottom row, eased spacing/);
  });

  // ── The arithmetic ──────────────────────────────────────────────────────
  test('the arithmetic is worked line by line and the headline is its last value', async ({ page }) => {
    await page.goto('/');
    const vals = await page.locator('#arithmetic .sum .val').allTextContents();
    expect(vals.length).toBeGreaterThan(4);
    expect(vals[0]).toContain('288 frames');
    const last = vals[vals.length - 1].replace('≈ ', '').trim();
    await expect(page.locator('#arithmetic h2')).toContainText(last);
    await expect(page.locator('h1 ~ div a').nth(1)).toContainText(last);
  });

  test('two notes are quoted, one useful and one expensive', async ({ page }) => {
    await page.goto('/');
    const q = page.locator('blockquote.said');
    expect(await q.count()).toBe(2);
    await expect(q.nth(0)).toContainText(/most useful note/i);
    await expect(q.nth(1)).toContainText(/most expensive note/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the brief form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-105 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    // Not the font name: "Anybody" is also an ordinary English word and this
    // page uses it in prose. Font names live in the bundled CSS anyway, not here.
    for (const noun of ['noor haddad', 'tulsa', 'wireframe', 'topology', 'texel', 'q1417684']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro exposure sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/exposure-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
