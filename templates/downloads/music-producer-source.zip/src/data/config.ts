// Roan Whitfield — Memphis, TN.
//
// First of the music sprint. "Produced by" is four different jobs — writing,
// producing, engineering and mixing — and an artist asking for "a producer"
// might mean any of them. The mismatch is normally discovered after the money
// is agreed, so this page states which job was done on every record.

export const site = {
  name:        'Roan Whitfield',
  shortName:   'Roan Whitfield',
  title:       'Roan Whitfield — producer and mix engineer, Memphis',
  tagline:     '“Produced by” is four different jobs.',
  owner:       'Roan Whitfield',
  ownerRole:   'Producer, engineer, mixer',
  credential:  'Records since 2013 · Memphis',
  city:        'Memphis',
  state:       'TN',
  language:    'en',
  phoneDisplay: '(901) 555-0164',
  phoneHref:   '+19015550164',
  email:       'roan@roanwhitfield.example',
  streetAddress: '452 S Main St',
  postalCode:  '38103',
  hours:       'Tracking days weekdays · mixing whenever it is quiet',
  bookingWindow: 'Mix slots from three weeks out · tracking days sooner',
  description:
    'A producer and mix engineer in Memphis. The credit “produced by” covers everything from ' +
    'choosing a take to writing the song, so every record below says which of the four jobs I ' +
    'actually did — and the rate card charges for them separately, because they are separate work.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The four jobs', href: '#jobs' },
  { label: 'Discography',   href: '#disco' },
  { label: 'Points',        href: '#points' },
  { label: 'Send stems',    href: '#stems' },
  { label: 'Book',          href: '#book' },
];

// ── The four jobs ─────────────────────────────────────────────────────────

export const jobs = [
  {
    key: 'Wrote',
    head: 'Writing',
    body: 'Melody, lyrics, chord changes — the song itself. This is the only one of the four that comes with a share of the publishing, and the only one where the credit follows the song forever rather than the recording.',
    rate: 'Split, not a fee',
  },
  {
    key: 'Produced',
    head: 'Producing',
    body: 'Arrangement, tempo, key, who plays, which take, what gets cut. The decisions about what the record IS. It is the job people mean least often and pay for most vaguely.',
    rate: 'Per song or per day',
  },
  {
    key: 'Engineered',
    head: 'Engineering',
    body: 'Mic choice and placement, gain, the routing, the headphone mixes, and keeping the session running so nobody is waiting on a cable. Invisible when it works.',
    rate: 'Per day',
  },
  {
    key: 'Mixed',
    head: 'Mixing',
    body: 'Balance, space, tone and automation across the finished multitrack. A separate craft with a separate ear, and the one most often bought as a standalone service.',
    rate: 'Per song',
  },
];

export const jobsNote =
  'An artist saying "I need a producer" means one of these four about as often as it means all ' +
  'of them. Working out which, before a rate is agreed, saves both sides the conversation where ' +
  'somebody expected a co-write and somebody else quoted for a mix.';

// ── Discography ───────────────────────────────────────────────────────────
// `roles` is the honest column. Nineteen of twenty-three say "Produced";
// eleven say "Wrote". Both numbers are computed on the page.

export const disco = [
  { title: 'Cold Room Gospel',  artist: 'Hattie Lowe',        year: 2025, kind: 'Album',  roles: ['Produced', 'Engineered', 'Mixed'] },
  { title: 'Ninth & Vance',     artist: 'The Bellwether Four', year: 2025, kind: 'Album',  roles: ['Produced', 'Engineered'] },
  { title: 'Sawgrass',          artist: 'Ondine Ruiz',        year: 2025, kind: 'Single', roles: ['Mixed'] },
  { title: 'What the River Took', artist: 'Hattie Lowe',      year: 2024, kind: 'Single', roles: ['Wrote', 'Produced', 'Engineered', 'Mixed'] },
  { title: 'Paper Streets',     artist: 'Emory Bell',         year: 2024, kind: 'Album',  roles: ['Produced', 'Mixed'] },
  { title: 'Slow Handed',       artist: 'The Bellwether Four', year: 2024, kind: 'EP',     roles: ['Produced', 'Engineered'] },
  { title: 'Marrow',            artist: 'Vess Okoro',         year: 2024, kind: 'Album',  roles: ['Mixed'] },
  { title: 'Two Rivers',        artist: 'Callum Reyes',       year: 2023, kind: 'Single', roles: ['Wrote', 'Produced'] },
  { title: 'The Longer Way',    artist: 'Ondine Ruiz',        year: 2023, kind: 'Album',  roles: ['Produced', 'Engineered', 'Mixed'] },
  { title: 'Hollow Bones',      artist: 'Emory Bell',         year: 2023, kind: 'Single', roles: ['Wrote', 'Produced', 'Mixed'] },
  { title: 'Tinderbox',         artist: 'Junie Marchetti',    year: 2023, kind: 'EP',     roles: ['Engineered'] },
  { title: 'Fever Dream Radio', artist: 'The Bellwether Four', year: 2022, kind: 'Album',  roles: ['Produced', 'Engineered', 'Mixed'] },
  { title: 'Quarry Light',      artist: 'Vess Okoro',         year: 2022, kind: 'Single', roles: ['Wrote', 'Produced', 'Engineered'] },
  { title: 'Salt of It',        artist: 'Hattie Lowe',        year: 2022, kind: 'EP',     roles: ['Produced', 'Mixed'] },
  { title: 'Undertow',          artist: 'Callum Reyes',       year: 2021, kind: 'Album',  roles: ['Wrote', 'Produced', 'Engineered', 'Mixed'] },
  { title: 'Beulah Street',     artist: 'Junie Marchetti',    year: 2021, kind: 'Single', roles: ['Produced'] },
  { title: 'Iron Season',       artist: 'Emory Bell',         year: 2020, kind: 'Album',  roles: ['Wrote', 'Produced', 'Engineered'] },
  { title: 'Low Water Mark',    artist: 'Ondine Ruiz',        year: 2020, kind: 'Single', roles: ['Engineered', 'Mixed'] },
  { title: 'Kindling',          artist: 'Vess Okoro',         year: 2019, kind: 'EP',     roles: ['Wrote', 'Produced'] },
  { title: 'Dryland',           artist: 'Callum Reyes',       year: 2018, kind: 'Album',  roles: ['Engineered'] },
  { title: 'Every Third Sunday', artist: 'Hattie Lowe',       year: 2017, kind: 'Single', roles: ['Wrote', 'Produced', 'Engineered'] },
  { title: 'Cane Break',        artist: 'Junie Marchetti',    year: 2015, kind: 'Album',  roles: ['Engineered'] },
  { title: 'First Position',    artist: 'Emory Bell',         year: 2013, kind: 'EP',     roles: ['Wrote', 'Engineered'] },
];

export const discoNote =
  'No album covers on this page. A wall of artwork tells you who I have been in a room with; ' +
  'the column on the right tells you what I did once I was there, and it is the only part of a ' +
  'discography anybody hiring should actually care about.';

// ── Points, worked ────────────────────────────────────────────────────────

export const points = {
  premise: 'Three points on one song, two hundred thousand streams',
  lines: [
    { op: '200,000 streams × $0.0035', val: '$700',   why: 'A mid-band per-stream rate. It varies by platform and by country and it is never the number in a press release.' },
    { op: 'Master share to the label', val: '−$385',  why: 'The recording side, before anybody downstream is paid. This split is the deal, not a law.' },
    { op: 'Artist share of the rest',  val: '−$220',  why: 'The artist is paid before the producer, out of the same pool. That order is normal and worth knowing.' },
    { op: 'Producer pool remaining',   val: '$95',    why: 'Everything the producer points are calculated against, for the whole song, for that year.' },
    { op: '3 points of the pool',      val: '$2.85',  why: 'Not a typo, and not an unusual outcome for a song with two hundred thousand streams.' },
  ],
  note:
    'Points are worth taking when a record has a real chance of being big and worth nothing when ' +
    'it does not, which is most records including good ones. I take fees. If you would rather pay ' +
    'in points I will still do the work, at a reduced fee plus points, and I will show you this ' +
    'arithmetic first so that neither of us is confused later about what was agreed.',
};

// ── Stems ─────────────────────────────────────────────────────────────────

export const stems = {
  intro:
    'The most common week of wasted work in this trade is a mix engineer waiting on a re-export. ' +
    'Six lines, and none of them takes longer than the email asking about them would.',
  rows: [
    { k: 'Sample rate and depth', v: '48 kHz / 24-bit', n: 'Whatever you tracked at, not converted. Send me the session rate and I will match it.' },
    { k: 'Start point',           v: 'Bar 1, all files',  n: 'Every stem the same length from the same zero. Consolidated, not trimmed to where the part happens to enter.' },
    { k: 'Headroom',              v: '−6 dB peak',        n: 'Not because it sounds better, but because a stem clipped at export cannot be un-clipped at mix.' },
    { k: 'Master bus',            v: 'Bypassed',          n: 'No limiter, no bus compression, no "just a little" of anything. Send the mix bus chain as a note instead and I will listen to it.' },
    { k: 'Naming',                v: '01_Kick_In.wav',    n: 'Number, source, mic or DI. Twenty files called Audio 1 through Audio 20 is an hour of somebody guessing.' },
    { k: 'Reference',             v: 'One rough mix',     n: 'Your rough, however bad. It tells me what you were hearing, which is information no stem carries.' },
  ],
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Mixing, per song',      figure: '$650',   note: 'Two revision passes included. Stems to the spec above, or an hour of prep is added and I will tell you before it is.' },
    { what: 'Tracking day',          figure: '$540',   note: 'Ten hours including setup. Engineering only; producing on the same day is the line below.' },
    { what: 'Producing, per song',   figure: 'From $900', note: 'Pre-production, arrangement and the decisions. Quoted after hearing a demo, never before.' },
    { what: 'Producing, per day',    figure: '$780',   note: 'For records where the shape is already known and it is a question of getting through the material.' },
    { what: 'Writing',               figure: 'A split',  note: 'Never a fee. If I write on it I take a share of the publishing and we agree it in writing on the day, not after the release.' },
    { what: 'Revisions past two',    figure: '$120',   note: 'Recalls are cheap for two weeks and expensive after that, which is a fact about session files rather than a policy.' },
  ],
};

export const said = {
  text: 'He sent the rate card back with our request split into three lines and asked which one we actually wanted. We had been about to pay producer rates for what turned out to be two tracking days and a mix.',
  who: 'Manager, independent label — on the first email',
};

export const faqs = [
  {
    q: 'Why break the credit into four?',
    a: 'Because they are four crafts with four rates and an artist saying "I need a producer" means one of them about as often as all of them. Splitting it before a number is agreed prevents the conversation where one side expected a co-write and the other quoted for a mix.',
  },
  {
    q: 'Would you take points instead of a fee?',
    a: 'At a reduced fee plus points, yes. Instead of a fee, no — and the arithmetic on this page is why. Three points on two hundred thousand streams is under three dollars, and I would rather show you that up front than have it discovered eighteen months later.',
  },
  {
    q: 'Do you master as well?',
    a: 'No. I will recommend two people and I will happily be wrong about which of them suits your record. A mix engineer mastering their own mix loses the second pair of ears that is the entire point of the stage.',
  },
  {
    q: 'What if my stems are not to spec?',
    a: 'I will still take them, add an hour of prep, and tell you before I start rather than after. The spec exists to save you that hour, not to refuse work.',
  },
  {
    q: 'Can you work remotely?',
    a: 'For mixing, always — most of it is remote. For tracking and producing, at least the first day in the room, because the decisions that matter get made by people looking at each other.',
  },
  {
    q: 'Do you have a house sound?',
    a: 'Yes, and you should listen for it before hiring me rather than after. The discography is deliberately not sorted by how well the records did; it is sorted by year, which makes the pattern easier to hear.',
  },
];
