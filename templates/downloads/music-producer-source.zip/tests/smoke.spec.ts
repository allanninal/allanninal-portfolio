import { test, expect } from '@playwright/test';

const JOBS = ['Wrote', 'Produced', 'Engineered', 'Mixed'];

test.describe('Roan Whitfield — smoke tests', () => {
  test('homepage renders with the producer name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Roan Whitfield/);
    await expect(page.locator('h1')).toContainText('four different jobs');
  });

  // Fourth schema mapping in four days: Person+additionalType (103-108),
  // VideoGame (109), Organization (110), Person+hasOccupation here.
  test('is a Person with an occupation, and carries nothing from day 110', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('hasOccupation');
    expect(json).not.toContain('"Organization"');
    expect(json).not.toContain('numberOfEmployees');
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#disco table.disco');
    await expect(t).toBeVisible();
    const box = await t.boundingBox();
    expect(box!.height).toBeGreaterThan(400);
  });

  // ── Discography ─────────────────────────────────────────────────────────
  test('every release credits at least one of the four jobs', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#disco tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(15);
    for (const r of await rows.all()) {
      const chips = (await r.locator('.chip').allTextContents()).map((s) => s.trim());
      expect(chips.length).toBeGreaterThan(0);
      for (const c of chips) expect(JOBS).toContain(c);
    }
    await expect(page.locator('#disco h2')).toContainText(`${n} records`);
  });

  test('the four tallies are counted from the table, not typed', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#disco tbody tr');
    const n = await rows.count();
    const counts: Record<string, number> = { Wrote: 0, Produced: 0, Engineered: 0, Mixed: 0 };
    for (const r of await rows.all()) {
      for (const c of await r.locator('.chip').allTextContents()) counts[c.trim()]++;
    }
    const cells = page.locator('#disco dl.tally > div');
    expect(await cells.count()).toBe(4);
    for (const cell of await cells.all()) {
      const label = ((await cell.locator('dt').textContent()) || '').trim();
      const dd = ((await cell.locator('dd').textContent()) || '').trim();
      expect(dd.startsWith(String(counts[label]))).toBe(true);
      expect(dd).toContain(`of ${n} records`);
    }
    // The claim only means something if the roles are not all equal.
    expect(new Set(Object.values(counts)).size).toBeGreaterThan(1);
  });

  test('there is no album artwork, and the page says why', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#disco img').count()).toBe(0);
    await expect(page.locator('#disco')).toContainText(/No album covers on this page/i);
  });

  // ── Points ──────────────────────────────────────────────────────────────
  test('the points arithmetic is worked and ends in the headline', async ({ page }) => {
    await page.goto('/');
    const vals = (await page.locator('#points .val').allTextContents()).map((s) => s.trim());
    expect(vals.length).toBeGreaterThan(3);
    const last = vals[vals.length - 1];
    await expect(page.locator('#points h2')).toContainText(last);
    // The whole argument is that the final figure is small.
    expect(Number(last.replace(/[$,]/g, ''))).toBeLessThan(20);
  });

  // ── Stems ───────────────────────────────────────────────────────────────
  test('the stems spec states a value and a reason for every line', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#stems dl.spec > div');
    const n = await rows.count();
    expect(n).toBeGreaterThan(4);
    for (const r of await rows.all()) {
      await expect(r.locator('dd.v')).not.toBeEmpty();
      expect(((await r.locator('dd.n').textContent()) || '').length).toBeGreaterThan(30);
    }
    await expect(page.locator('#stems h2')).toContainText(`${n} lines`);
    await expect(page.locator('#stems')).toContainText(/Bypassed/);
  });

  // ── Photographs ─────────────────────────────────────────────────────────
  test('both photographs load and describe what is visible', async ({ page }) => {
    await page.goto('/');
    const imgs = page.locator('figure.rooms img');
    expect(await imgs.count()).toBe(2);
    for (const i of await imgs.all()) {
      expect(((await i.getAttribute('alt')) || '').length).toBeGreaterThan(40);
      expect(await i.getAttribute('width')).toBeTruthy();
    }
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((all) =>
      all.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
         .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('the rate card charges the four jobs separately', async ({ page }) => {
    await page.goto('/');
    const text = (await page.locator('#rates').textContent()) || '';
    expect(text).toMatch(/Mixing, per song/);
    expect(text).toMatch(/Tracking day/);
    expect(text).toMatch(/Producing/);
    expect(text).toMatch(/Writing/);
    // Writing is never a fee — that is the point of the four-way split.
    await expect(page.locator('#rates')).toContainText(/A split/);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-110 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['slate harbour', 'lawrence', 'salary band', 'crunch', 'q1350189']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro session sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/session-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
