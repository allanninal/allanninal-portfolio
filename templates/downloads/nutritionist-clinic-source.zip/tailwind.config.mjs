/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Josefin Sans"', 'system-ui', 'sans-serif'],
        body:    ['"Bitter"', 'Georgia', 'serif'],
      },
      colors: {
        herb: {
          50:  '#EEF6F1',
          100: '#D4EBDB',
          200: '#AADABB',
          300: '#7AC49B',
          400: '#4BAD7B',
          500: '#1F7A54',
          600: '#186142',
          700: '#124930',
          800: '#0C3120',
          900: '#061810',
        },
        honey: {
          50:  '#FEF7E8',
          100: '#FDECC8',
          200: '#FAD890',
          300: '#F7C258',
          400: '#F0A820',
          500: '#C57A0A',
          600: '#A0620A',
          700: '#7A4A08',
          800: '#543306',
          900: '#2D1B03',
        },
        cream: {
          50:  '#FAFAF8',
          100: '#F3F1EC',
          200: '#E8E4DB',
          300: '#D8D2C5',
          400: '#C2BAA8',
          500: '#A89D87',
        },
      },
    },
  },
  plugins: [],
};
