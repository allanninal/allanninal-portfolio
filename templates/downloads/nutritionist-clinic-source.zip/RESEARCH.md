# Day 59 — Nutritionist Clinic: Niche Research

## Slug
`nutritionist-clinic`

## Differentiation from Days 1–58

### Visual register audit (recent days)
| Day | Palette family | Fonts |
|-----|---------------|-------|
| 58 eyelash-studio | espresso-dark #1C1410 / dusty-rose #C9857A / warm cream | Playfair Display + DM Sans |
| 57 makeup-artist | deep-plum #4A1860 / champagne-gold | Cormorant Garamond + Nunito Sans |
| 56 esthetician-skincare | blush-ivory / warm-clay #C2705A / forest-green #2D5016 | DM Serif Display + DM Sans |
| 55 tattoo-studio | ink-black / bone-white / amber-gold #E8A020 | Bebas Neue + Barlow |
| 54 massage-therapist | deep-ocean-teal #1A4A5A / warm-sand / linen | Libre Baskerville + Source Sans 3 |
| 53 day-spa | sage-green #3A6047 / stone / pearl-cream | Crimson Pro + Raleway |
| 52 nail-salon | coral / rose-gold / plum | Italiana + Plus Jakarta Sans |
| 51 barbershop | near-black / oxblood / brass | Teko + Hind |
| 50 hair-salon | mauve / champagne / ivory | Bellefair + Questrial |
| 49 personal-chef | aubergine / champagne-blush | Tenor Sans + Albert Sans |
| 48 catering-company | midnight-navy / champagne-gold | Marcellus + Mulish |
| 47 food-truck | — | — |
| 46 brunch-spot | sunny-yellow / coral / sky-blue | Gabarito + Poppins |
| 45 tea-room | parchment / celadon | Cardo + Figtree |
| 44 cocktail-lounge | noir-black / emerald-neon | Bodoni Moda + IBM Plex Mono |
| 43 wine-bar | deep-velvet / burgundy / candlelight-gold | Cinzel + Montserrat |
| 42 brewery | slate-charcoal / copper-amber | Oswald + Work Sans |
| 41 juice-bar | citrus-orange / leafy-green | Urbanist Variable + Geist |
| 25 coach-consultant | sage-linen / green | Raleway + Nunito |

### Day 59 distinct visual register

- **Palette**: Crisp White (#FAFAF8) + Herb Green (#1F7A54) + Warm Honey (#C57A0A) + Soft Fern (#EEF6F1)
  - Herb green (#1F7A54): vivid mid-range botanical green — completely distinct from:
    - sage grey-green (day 53, 25), forest-green deep (#2D5016 day 56), deep-ocean-teal (#1A4A5A day 54)
    - citrus leafy-green of juice-bar (a lighter, warmer yellow-green)
  - Warm honey (#C57A0A): a darker amber-ochre, distinct from the amber-gold on dark (#E8A020 day 55)
    - Used only on white backgrounds where it achieves 4.5:1+ contrast; decorative use only on cream
  - Crisp white + Soft Fern (#EEF6F1) background sections: clinical cleanliness vs. lush herbal warmth
  - This is a **light-primary template** but with vivid, confident accent color — not soft/pastel
- **Typography**: Josefin Sans (clean geometric sans, headings — clinical precision meets warmth) + Bitter (workhorse reading serif for body text — evidence-based, credible)
  - Neither Josefin Sans nor Bitter has been used in days 1–58
  - Josefin Sans conveys a clean, modern clinic — precise, trustworthy
  - Bitter is optimized for sustained screen reading — ideal for service/program descriptions
- **Density**: Mid-density — structured and scan-friendly (healthcare users want clarity), with program cards, service grid, and a substantive FAQ section

### Color contrast checks (WCAG AA 4.5:1 minimum for body text)
- Herb-green (#1F7A54) on crisp-white (#FAFAF8): contrast ratio ≈ 6.2:1 — AA ✓ (links, nav)
- Dark text (#1A2118) on crisp-white (#FAFAF8): ≈ 18:1 — AAA ✓
- Warm honey (#C57A0A) on crisp-white (#FAFAF8): ≈ 4.6:1 — AA ✓ (only for large text/icons; use darker #A0620A for small text)
- White (#FFFFFF) on herb-green (#1F7A54): ≈ 6.2:1 — AA ✓ (button text)
- Herb-green (#1F7A54) on soft-fern (#EEF6F1): ≈ 5.9:1 — AA ✓
- Do NOT use warm honey on fern background for text — contrast is only ~3.2:1

## Persona
**Dr. Maya Patel, RDN, LD** — Registered Dietitian Nutritionist, Private Practice
- Location: Seattle, WA (Capitol Hill neighborhood)
- Credentials: Registered Dietitian Nutritionist (RDN), Licensed Dietitian (LD), Certified Intuitive Eating Counselor, MS in Nutrition Sciences (University of Washington)
- Practice name: **Nourish Well Nutrition** (the business entity)
- Niche: Evidence-based nutrition for gut health, hormonal balance, and sustainable weight management — not fad diets, functional food-first approach
- Tone: warm, science-backed, empowering, destigmatizing — clinical authority with genuine empathy
- Booking platform: Jane App (widely used by health practitioners in the US/Canada)
- Fee structure: initial 75-min consult ($195), follow-up 45-min ($110), monthly program ($395)
- Insurance: accepts select PPO plans; offers superbill for OON reimbursement

## Sections (single-page)
1. **Header** — sticky, logo (Nourish Well Nutrition), nav links, "Book a Call" CTA button
2. **Hero** — split layout (left: headline + tagline + 2 CTAs, right: dietitian headshot); credential ribbon beneath
3. **Stats band** — 4 numbers: 12+ Years · 1,800+ Clients · 4.9 ★ Rating · Evidence-Based Care
4. **Services** — 6 service cards with icon, title, duration, price, short description:
   - Initial Nutrition Consult (75 min · $195)
   - Follow-Up Session (45 min · $110)
   - Meal Planning Package (personalized 2-week plan · $145)
   - Gut Health Program (8-week guided · $395/mo)
   - Hormonal Balance Program (12-week · $395/mo)
   - Corporate Wellness (groups — custom pricing)
5. **Philosophy section** — 3 pillars: "Food Is Information" · "No Foods Are Off-Limits" · "Sustainable, Not Perfect"
6. **About Dr. Patel** — bio, credentials list, education, philosophy quote, professional headshot area
7. **Testimonials** — 5 client quotes (gut health, weight neutral, pregnancy nutrition, corporate)
8. **FAQ accordion** — 8 questions: insurance/superbill, first appointment, virtual vs in-person, supplements, fad diets, gut health timeline, cancellation, evidence-based approach
9. **Booking CTA band** — herb-green background, white text, Jane App booking link
10. **Hours & Contact** — office hours table, address, email, phone, telehealth note
11. **Footer** — nav, social handles, HIPAA note, Allan's maker-bio links

## Schema.org Types
- `MedicalBusiness` (or `Physician` subtype — but `MedicalBusiness` + `HealthAndBeautyBusiness` is more broadly supported)
- Use: `MedicalBusiness` + `LocalBusiness` for the practice
- `Person` + `MedicalBusiness` for Dr. Patel (dietitian, not physician)
- `Service` with `Offer` for each service
- `FAQPage` for the FAQ section
- `MedicalSpecialty` → DietNutrition (as additionalType on the Person)

## Image strategy
- Hero: professional healthcare provider at desk or light consultation room (not food imagery)
- Service section: minimal herb-green icons (SVG only, no external images)
- About: professional headshot placeholder (placeholder bg with initials)
- Testimonial section: no photos required (text-only cards with star ratings)
- No food photography (avoids overlap with days 32–49 food templates)

## Key differentiators from adjacent templates
- **vs. coach-consultant (day 25)**: medical/clinical framing (RDN credentials, HIPAA, insurance), not generic coaching; different palette entirely
- **vs. day-spa (day 53)**: clinical nutrition ≠ spa relaxation; herb-green replaces sage; Josefin Sans/Bitter replaces Crimson Pro/Raleway
- **vs. massage-therapist (day 54)**: different service type, different city, different palette (herb-green vs. deep-ocean-teal)
- **vs. juice-bar (day 41)**: private healthcare practice vs. retail food establishment; clinical tone vs. casual consumer tone
