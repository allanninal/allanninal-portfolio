export const practitioner = {
  name:        'Dr. Maya Patel',
  title:       'Registered Dietitian Nutritionist',
  credentials: ['RDN', 'LD', 'MS Nutrition Sciences'],
  practiceName:'Nourish Well Nutrition',
  tagline:     'Evidence-based nutrition for a life you love — no fad diets, no quick fixes.',
  description: 'Board-certified Registered Dietitian Nutritionist specializing in gut health, hormonal balance, and sustainable weight management in Seattle, WA.',
  phone:       '(206) 555-0183',
  email:       'hello@nourishwellnutrition.com',
  address:     '1214 E Pike St, Suite 205',
  city:        'Seattle',
  state:       'WA',
  zip:         '98122',
  instagram:   'https://instagram.com/nourishwellnutrition',
  facebook:    'https://facebook.com/nourishwellnutrition',
  linkedin:    'https://linkedin.com/in/maya-patel-rdn',
  bookingUrl:  'https://jane.app/booking/nourish-well-nutrition',
  makerBio: {
    name:      'Dr. Maya Patel',
    url:       'https://example.com',
    linkedin:  '#',
    twitter:   '#',
    github:    '#',
  },
};

export const site = {
  title:         'Nourish Well Nutrition | Registered Dietitian Nutritionist Seattle WA',
  description:   'Board-certified Registered Dietitian Nutritionist in Seattle, WA. Evidence-based nutrition counseling for gut health, hormonal balance, and sustainable weight management. Book a consult with Dr. Maya Patel, RDN.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
