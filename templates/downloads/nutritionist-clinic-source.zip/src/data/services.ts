export type Service = {
  id: string;
  title: string;
  duration: string;
  price: string;
  description: string;
  icon: string;
  featured?: boolean;
};

export const SERVICES: Service[] = [
  {
    id: 'initial-consult',
    title: 'Initial Nutrition Consult',
    duration: '75 min',
    price: '$195',
    description: 'A comprehensive deep-dive into your health history, goals, lab work, and eating patterns. You\'ll leave with a personalized roadmap and immediate action steps.',
    icon: 'clipboard',
    featured: true,
  },
  {
    id: 'follow-up',
    title: 'Follow-Up Session',
    duration: '45 min',
    price: '$110',
    description: 'Track progress, troubleshoot obstacles, and refine your plan. Recommended every 2–4 weeks during active change phases.',
    icon: 'refresh',
  },
  {
    id: 'meal-planning',
    title: 'Meal Planning Package',
    duration: 'Async delivery',
    price: '$145',
    description: 'A fully customized 2-week meal plan with recipes, a shopping list, and meal-prep guidance tailored to your tastes, budget, and nutrition goals.',
    icon: 'calendar',
  },
  {
    id: 'gut-health',
    title: 'Gut Health Program',
    duration: '8 weeks',
    price: '$395/mo',
    description: 'Structured protocol for IBS, bloating, food sensitivities, and gut microbiome restoration. Includes bi-weekly sessions, meal plans, and a symptom tracker.',
    icon: 'leaf',
    featured: true,
  },
  {
    id: 'hormonal-balance',
    title: 'Hormonal Balance Program',
    duration: '12 weeks',
    price: '$395/mo',
    description: 'Nutrition-first support for PCOS, thyroid conditions, perimenopause, and adrenal health — backed by lab interpretation and evidence-based protocols.',
    icon: 'chart',
  },
  {
    id: 'corporate-wellness',
    title: 'Corporate Wellness',
    duration: 'Groups · Custom',
    price: 'Custom quote',
    description: 'Workshops, lunch-and-learns, and team nutrition programs that reduce absenteeism and boost workplace energy. Serving Seattle-area companies of all sizes.',
    icon: 'people',
  },
];

export type Program = {
  id: string;
  name: string;
  duration: string;
  price: string;
  forWho: string;
  includes: string[];
  accent: string;
};

export const PROGRAMS: Program[] = [
  {
    id: 'kickstart',
    name: 'Nutrition Kickstart',
    duration: '4 weeks',
    price: '$450',
    forWho: 'New to working with a dietitian or want a focused reset.',
    includes: [
      'Initial consult (75 min)',
      '1 follow-up session',
      'Custom 2-week meal plan',
      'Email support (48-hr response)',
    ],
    accent: 'herb',
  },
  {
    id: 'transform',
    name: 'Lifestyle Transformation',
    duration: '12 weeks',
    price: '$995',
    forWho: 'Ready for lasting behavior change with dedicated support.',
    includes: [
      'Initial consult (75 min)',
      '5 follow-up sessions',
      '2 meal plans (updated monthly)',
      'Lab review + interpretation',
      'Unlimited email support',
      'Supplement protocol review',
    ],
    accent: 'honey',
  },
  {
    id: 'fertility',
    name: 'Fertility Nutrition',
    duration: '16 weeks',
    price: '$1,495',
    forWho: 'Preparing for conception, pregnancy, or navigating fertility treatment.',
    includes: [
      'Initial consult (75 min)',
      '7 follow-up sessions',
      'Trimester-specific meal plans',
      'Supplement guidance (prenatal, folate, DHA)',
      'Partner nutrition consult (1 session)',
      'Priority email support',
    ],
    accent: 'herb',
  },
];

export type Testimonial = {
  quote: string;
  name: string;
  context: string;
};

export const TESTIMONIALS: Testimonial[] = [
  {
    quote: 'I\'d tried every diet out there. Maya helped me understand WHY my body was holding on to weight — it was my cortisol, not my willpower. Six months later, I\'ve lost 28 pounds and I\'m not counting a single calorie.',
    name: 'Sarah K.',
    context: 'Hormonal Balance Program',
  },
  {
    quote: 'My gastroenterologist sent me to Dr. Patel after three years of unexplained IBS. Eight weeks into the gut health protocol and my bloating has gone from daily to almost never. Worth every penny.',
    name: 'Marcus T.',
    context: 'Gut Health Program',
  },
  {
    quote: 'As a nurse, I was skeptical about hiring a dietitian — I thought I knew enough. I was wrong. Maya\'s lab interpretation changed how I eat and sleep. My thyroid numbers are the best they\'ve been in a decade.',
    name: 'Priya N.',
    context: 'Lifestyle Transformation Program',
  },
  {
    quote: 'We hired Dr. Patel for our company wellness series. Attendance was through the roof, and the feedback was the most positive we\'ve ever received. She makes nutrition approachable — no shame, no rules.',
    name: 'Jordan L.',
    context: 'Corporate Wellness, Tech Company · Seattle',
  },
  {
    quote: 'I started seeing Maya while going through IVF. Her fertility nutrition protocol helped me feel like I was actually doing something proactive. We conceived on our third transfer. I\'ll never know what the variable was, but I\'m glad she was in our corner.',
    name: 'Amelia R.',
    context: 'Fertility Nutrition Program',
  },
];

export type FAQ = {
  q: string;
  a: string;
};

export const FAQS: FAQ[] = [
  {
    q: 'Do you accept insurance?',
    a: 'Yes — I accept select PPO insurance plans, including Premera, Regence, and Aetna. A superbill is provided for all other plans so you can seek out-of-network reimbursement. Many clients recover 60–80% of session costs through their HSA or FSA.',
  },
  {
    q: 'What happens in the first appointment?',
    a: 'The initial 75-minute consult covers your full health history, current eating patterns, lab results (bring any recent bloodwork), lifestyle factors, and primary goals. You leave with a written action plan and at least 3 immediate next steps. No homework ahead of time — just bring yourself.',
  },
  {
    q: 'Are sessions in-person or virtual?',
    a: 'Both. In-person sessions are available at our Capitol Hill studio (1214 E Pike St, Suite 205, Seattle WA). Telehealth is available to residents of Washington, Oregon, California, and New York via secure HIPAA-compliant video.',
  },
  {
    q: 'Do you prescribe supplements?',
    a: 'I review current supplements and can make evidence-based recommendations, but I don\'t prescribe medications. I partner with your medical provider to ensure any supplementation complements your care plan. Food-first is always the goal — supplements fill genuine gaps, not marketing.',
  },
  {
    q: 'Will you put me on a restrictive diet?',
    a: 'No. My approach is non-diet and weight-inclusive. We work on building sustainable habits, improving your relationship with food, and addressing the root causes of your symptoms — not restriction, elimination, or calorie counting (unless that\'s a specific, short-term clinical goal we agree on together).',
  },
  {
    q: 'How long until I see results with the gut health program?',
    a: 'Most clients notice meaningful symptom improvement within 3–5 weeks. Full gut microbiome shifts take 8–12 weeks of consistent protocol adherence. Your timeline depends on the root cause — bacterial overgrowth responds differently than food sensitivities, for example. We track symptom severity weekly so you always have data, not just feelings.',
  },
  {
    q: 'What is your cancellation policy?',
    a: 'Please cancel at least 24 hours before your appointment to avoid a 50% late-cancellation fee. Cancellations within 2 hours of the appointment are charged the full session fee. You can cancel or reschedule directly in the Jane App portal — no need to call.',
  },
  {
    q: 'How is evidence-based nutrition different from what I read online?',
    a: 'Evidence-based means my recommendations are grounded in peer-reviewed research, not sponsored content, influencer trends, or anecdote. I stay current with clinical nutrition literature and apply findings to your individual context — because a study average doesn\'t tell us what works for your genetics, microbiome, and life.',
  },
];
