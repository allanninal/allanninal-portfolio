/**
 * Haulaway Bros. — every string the page renders.
 *
 * Business fictional. PRICES AND DIVERSION FIGURES ARE REAL 2026 numbers,
 * including the national 32.1% municipal recycling rate the page uses as a
 * benchmark against its own claim. Sources in RESEARCH.md.
 */

export const site = {
  name: 'Haulaway Bros.',
  shortName: 'Haulaway',
  tagline: 'Priced by the fraction. Sorted before it leaves.',
  description:
    'Junk removal across Baltimore, priced by how much of the truck you fill. We publish where it actually goes, by material — including the categories that end up in landfill no matter who takes them.',
  owner: 'Teo and Marisol Ruiz',
  ownerRole: 'Owners',
  yearsExperience: 7,
  city: 'Baltimore',
  state: 'MD',
  streetAddress: '2900 Sisson Street',
  postalCode: '21211',
  phoneDisplay: '(410) 555-0147',
  phoneHref: '+14105550147',
  email: 'hello@haulawaybros.example',
  formAction: '#',
  hours: 'Mon–Sat 7am–5pm',
  bookingWindow: 'Same-week pickups. Next-day when the truck has room.',
  diversion: 61,

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Haulaway Bros. — Junk Removal in Baltimore, MD',
  license: 'MD hauler permit #H-9042 · Fully insured',
  instagram: 'https://www.instagram.com/haulawaybros',
  facebook: 'https://www.facebook.com/haulawaybros',
};

export const nav = [
  { label: 'Load sizes', href: '#loads' },
  { label: 'Where it goes', href: '#diversion' },
  { label: 'What we refuse', href: '#refuse' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * Load fractions — the page's spine, set at enormous scale.
 * `fill` drives the CSS truck-fill bar. Prices are real 2026 US figures.
 */
export const loads = [
  { frac: '1/8', fill: 12, name: 'Minimum load', price: '$100 – $175',
    fits: 'A mattress and a bed frame. Or about six garbage bags and a chair.',
    note: 'Our minimum. If your pile is smaller than this, a bulk-trash pickup from the city is free and you should use it.' },
  { frac: '1/4', fill: 25, name: 'Quarter load', price: '$150 – $300',
    fits: 'A small room cleared — sofa, coffee table, a few boxes.',
    note: 'The most common single-trip job we do.' },
  { frac: '1/2', fill: 50, name: 'Half load', price: '$250 – $550',
    fits: 'A garage, a finished basement, or a full apartment of furniture.',
    note: 'Where the per-item price starts working in your favour.' },
  { frac: 'FULL', fill: 100, name: 'Full truckload', price: '$550 – $1,000',
    fits: 'A rowhouse cleanout, an estate, or a small construction tear-out.',
    note: 'Two people, most of a day. We will tell you on the phone if it is going to be two trips.' },
];

/** Where it actually goes. The national rate is the benchmark, not our claim. */
export const diversion = {
  claim: 61,
  national: 32.1,
  materials: [
    { material: 'Metal and appliances', rate: 95, where: 'Scrap yard. This is the easy one and every hauler does it, because metal pays.' },
    { material: 'Cardboard and paper', rate: 90, where: 'Single-stream recycling. Flattened on the truck, not at the tip.' },
    { material: 'Furniture in usable condition', rate: 70, where: 'Habitat ReStore and two local shelters. Usable means someone would take it home, not that it technically still stands up.' },
    { material: 'Electronics', rate: 85, where: 'Certified e-waste processor. Maryland restricts what can be landfilled here anyway.' },
    { material: 'Mattresses', rate: 60, where: 'Mattress recycler. Steel, foam and fibre separated. Twenty states now ban them from landfill outright.' },
    { material: 'Yard waste and clean wood', rate: 80, where: 'Composting and mulch.' },
    { material: 'Mixed construction debris', rate: 25, where: 'Mostly landfill. Sorted where it is worth sorting, and we will not pretend otherwise.' },
    { material: 'Upholstered items that are wet, mouldy or infested', rate: 0, where: 'Landfill. Always. No charity will take them and no recycler will process them — anyone telling you different is telling you what you want to hear.' },
  ],
  honesty: 'Our rate is roughly double the national municipal average, which is exactly the kind of claim you should be sceptical of. Ask any hauler for the breakdown by material rather than the headline number, and ask which yard or charity actually receives it.',
};

/** The refusal list. */
export const refuse = [
  { item: 'Hazardous waste', why: 'Paint, solvents, pesticides, pool chemicals. It needs a household hazardous waste day, which Baltimore runs free.' },
  { item: 'Asbestos and anything suspected of it', why: 'Licensed abatement, not a hauler. Pre-1985 floor tile and pipe wrap in particular.' },
  { item: 'Medical and sharps', why: 'Regulated stream. Pharmacies and hospitals take these back.' },
  { item: 'Full fuel tanks, propane, batteries over car size', why: 'Explosion risk in a compacting truck. Empty and separate them and we will take the shells.' },
  { item: 'Anything still attached to the building', why: 'We are haulers, not demolition. Once it is loose, it is ours.' },
];

export const areas = [
  { zone: 'Baltimore City', towns: 'Hampden · Canton · Federal Hill · Charles Village · Remington' },
  { zone: 'North county', towns: 'Towson · Lutherville · Timonium · Cockeysville' },
  { zone: 'East & south', towns: 'Dundalk · Essex · Glen Burnie · Brooklyn Park' },
  { zone: 'West', towns: 'Catonsville · Ellicott City · Woodlawn · Arbutus' },
];

export const reviews = [
  { name: 'Nadine K.', town: 'Hampden', text: 'They told me the pile was under their minimum and that city bulk pickup would take it free. Then they came back a month later for the actual cleanout.' },
  { name: 'Errol B.', town: 'Towson', text: 'Full estate. They separated the metal, took two loads of furniture to ReStore and gave me the receipt for the tax deduction.' },
  { name: 'Shanice W.', town: 'Canton', text: 'Straight answer on the mouldy basement couch — landfill, no way around it. I would rather be told that than have it dressed up.' },
  { name: 'Paul D.', town: 'Catonsville', text: 'Quoted a half load on the phone, filled a bit over, and charged the half load anyway. That is the whole review.' },
];

export const faqs = [
  { q: 'How do I know what fraction my pile is?', a: 'You mostly cannot, and that is fine. Send a photo and we will tell you before we arrive. The truck bed is 16 feet by 8 feet by 5 feet tall, so a full load is about 640 cubic feet — but nobody thinks in cubic feet, which is why we price in quarters.' },
  { q: 'Is your 61% diversion rate real?', a: 'It is our own measured figure across last year, and you should be sceptical: the national municipal recycling rate is 32.1%, so we are claiming nearly double. That is why the breakdown by material is on this page. The metal and cardboard numbers do most of the work; mixed construction debris drags it down.' },
  { q: 'Will you donate my furniture?', a: 'If it is genuinely usable. The test is whether you would take it into your own home. A sofa with a torn cushion is donatable; a sofa that has been in a damp basement is not, and charities are quite firm about that because they pay to dispose of what they cannot use.' },
  { q: 'Can I just use city bulk pickup?', a: 'For a few items, yes, and it is free. We will say so on the phone. Where we earn the money is volume, stairs, heavy items and same-week timing.' },
  { q: 'Do you charge by weight?', a: 'No, by volume. Weight matters to us at the tip but it is not something you can estimate, and a per-pound price is how a $200 job becomes a $600 invoice.' },
  { q: 'What if it is more than you quoted?', a: 'We tell you before we load, not after. If the pile is bigger than the photo suggested, you get the new number and can decide. Nobody gets a surprise on the invoice.' },
];
