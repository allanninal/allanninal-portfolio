import { test, expect } from '@playwright/test';

test.describe('Haulaway Bros. — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Haulaway Bros\./);
    await expect(page.locator('h1')).toContainText('fraction');
  });

  // Brutalist is committed structurally, not as a coat of paint. The two
  // assertions that make that real: a saturated page ground, and no cards.
  test('the page ground is saturated, not near-white or near-black', async ({ page }) => {
    await page.goto('/');
    const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const [r, g, b] = bg.match(/\d+/g)!.map(Number);
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    // Saturation as chroma spread: every other template in the library sits
    // near 0 here because its ground is a neutral.
    expect(max - min).toBeGreaterThan(120);
  });

  test('there is no card grid anywhere on the page', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('.card').count()).toBe(0);
    // Structure is expressed as a shared rule grid instead.
    expect(await page.locator('.rules').count()).toBeGreaterThanOrEqual(3);
  });

  test('the four load fractions are the spine, at large scale', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 900 });
    await page.goto('/');
    const fracs = page.locator('#loads .load-frac');
    expect(await fracs.count()).toBe(4);
    expect(await fracs.allTextContents()).toEqual(['1/8', '1/4', '1/2', 'FULL']);
    const size = await fracs.first().evaluate((e) => parseFloat(getComputedStyle(e).fontSize));
    expect(size).toBeGreaterThan(56);
  });

  test('every load states a real price and what fits', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#loads .load').allTextContents()) {
      expect(t).toMatch(/\$\d/);
      expect(t.length).toBeGreaterThan(80);
    }
  });

  test('each fill bar carries a text label, not just a width', async ({ page }) => {
    await page.goto('/');
    const bars = page.locator('#loads .fill');
    expect(await bars.count()).toBe(4);
    for (let i = 0; i < 4; i++) {
      await expect(bars.nth(i)).toHaveAttribute('aria-label', /percent full/);
    }
  });

  // The uncomfortable half: the page benchmarks its own claim against the
  // national rate and publishes the categories that reach landfill.
  test('diversion is stated against the national rate, with the bad rows shown', async ({ page }) => {
    await page.goto('/');
    const d = page.locator('#diversion');
    await expect(d).toContainText('61%');
    await expect(d).toContainText('32.1%');
    await expect(d).toContainText(/sceptical/i);
    // At least one material must be at or near zero diversion.
    await expect(d).toContainText(/Landfill\. Always\./);
    expect(await page.locator('#diversion .div-rate').count()).toBe(8);
  });

  test('the refusal list gives a reason for each item', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#refuse dl > div');
    expect(await items.count()).toBe(5);
    for (const t of await items.allTextContents()) expect(t.length).toBeGreaterThan(60);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 84.
  test('no trace of the day-84 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['rampart', 'chattanooga', 'soft wash', 'dell marchetti', 'psi']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro cleanout plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/cleanout-plan/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('What charities actually take');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
