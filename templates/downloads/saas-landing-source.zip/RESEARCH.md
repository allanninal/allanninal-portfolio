# SaaS Landing Template — Research Brief

> **Assumption:** Single-product marketing site for indie / early-stage SaaS — dev tools, AI apps, B2B startups, micro-SaaS. One funnel: trial signup or waitlist.

## Audience & primary CTA
- **Who visits:** devs evaluating tools (60s scan + pricing), startup buyers comparing options, AI users hitting a waitlist.
- **Primary CTA:** *Start free* / *Get started*. Variants via config: `Join the waitlist` (AI/pre-launch), `npm install <pkg>` (dev tools), `Book a demo` (B2B).
- **Secondary CTAs:** view docs, view pricing, live demo, GitHub repo.

## Reference sites (real businesses)
- https://linear.app — bento grid using REAL product UI (no icons), 25k-team line, named OpenAI/Ramp quotes. Gold standard.
- https://resend.com — light-default, mono accents, dev-first ("install" as primary CTA).
- https://cal.com — testimonial carousel of recognizable founders, 3-step "how it works".
- https://posthog.com — playful tone, transparent pricing, "98% use it free", customer logos (YC, Supabase, ElevenLabs).
- https://supabase.com — dark emerald, "Build in a weekend. Scale to millions" outcome hero, SOC2 + open-source trust.
- https://plausible.io — light-default teal, stats triplet (17k subs / 260B pageviews / 99.99%), bootstrapped/EU positioning.
- https://vercel.com — animated gradient hero, code snippets next to product UI, dense logo wall.

## Existing templates surveyed
- **Astroship** (1.9k, Astro+Tailwind) — most popular; weak type, no dark mode free, generic Streamline illustrations.
- **saas-landing-template** (158, Next+shadcn) — locked to shadcn aesthetic, Vercel-only.
- **next-saas-lp** (72) — Framer Motion heavy, Next-only, light-only.
- **Astro-idol / astrobrew** (~60 each, Skeleton CSS) — dated.
- **Vercel SaaS templates** — Next-only, Vercel-locked.
- **Saturated:** shadcn-skinned hero + 3-up feature grid + 3-tier pricing + faceless testimonial. **Missing:** real-product-UI bento, HTML/CSS UI mocks (not images), dual-mode polish, MDX-driven content.

## Must-have sections (in order)
1. **Hero** — outcome headline, subhead, dual CTA, product UI mock (HTML/CSS, not stock).
2. **Logo wall** — "Trusted by teams at" — 5–8 grayscale logos.
3. **Feature bento** — 4–6 tiles, each with mini product UI mock or chart, not generic icons.
4. **How it works** — 3-step numbered flow, code snippet on one step.
5. **Pricing** — 3 tiers, MDX-driven, monthly/annual toggle, feature checkmarks.
6. **Testimonials** — 3 quote cards with name + role + company.
7. **FAQ** — 6–8 accordion items (Astro `<details>`, no JS).
8. **Final CTA band** + footer (status, changelog, docs links).

## Design conventions
- **Typography:** Geometric sans display (Geist / Satoshi / Inter Tight) for hero (large, tight tracking). Inter body. Mono accent (Geist Mono) for code, badges, pricing numbers.
- **Color:** **Light-default** (vs Day 1 dark). Accent **violet/indigo** (`#7C3AED` / `#6366F1`) — NOT amber, NOT teal. Dark mode `#0A0A0B` with same violet, subtle violet-to-cyan gradient on hero/CTA bands.
- **Imagery:** Zero stock. Product UI mocked in HTML/CSS as fake dashboard (status pills, chart bars, table rows, code block). Optional radial gradient hero backdrop.
- **Density:** Denser than Day 1 — bento, pricing table, logo wall, FAQ accordion all on one page. Card-heavy, badge-heavy, intentional gutters.

## Trust signals to include
- Customer logo wall (grayscale, mono-row).
- Quantified stat triplet ("10k+ teams", "99.99% uptime", "SOC2 ready").
- Named testimonials with role + company.
- Security badges (SOC2, GDPR, GitHub stars).
- Changelog / "shipped this week" footer link.

## SEO / schema.org
- **Type:** `SoftwareApplication` with nested `Offer` per pricing tier + `AggregateRating` slot.
- **Required:** `name`, `applicationCategory`, `operatingSystem` ("Web"), `offers[]` with `price`/`priceCurrency`/`url`, `description`.
- **OG image:** build-time — product name + tagline on light violet-gradient; dark variant for dark previews.

## Static-only fit
No concerns. Pricing, features, testimonials, FAQ all in MDX/JSON collections. CTAs are external links (Stripe/Tally/Buttondown). Status via embedded badge. No SSR.

## Differentiation — what we'll do better
- **Day 1 contrast:** light-default (Day 1 dark), violet-indigo accent (Day 1 amber), Geist/Satoshi display (Day 1 Inter+Mono type-led), card+bento density (Day 1 sparse prose).
- **Real product UI mocks** in HTML/CSS — believable dashboard, not stock or icons.
- **MDX-driven** feature/pricing/FAQ collections — edit content, not JSX.
- **Both modes equally polished** — light-first design, dark designed alongside (not auto-inverted).
- **CTA variant config** — frontmatter flag swaps trial / waitlist / npm-install / demo without touching components.
- **`SoftwareApplication` schema with per-tier offers** out of the box.
- **Zero shadcn dependency** — opinionated tokens, not the same components as every other SaaS template.
