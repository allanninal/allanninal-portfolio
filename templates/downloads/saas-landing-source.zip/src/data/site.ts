// Single source of truth for the SaaS product behind this template.
// Cloning users edit this file to make the site theirs.

export const site = {
  // Product identity
  product: {
    name: 'Stratus',
    domain: 'stratus.app', // used in display only — placeholder
    tagline: 'Ship product analytics your team will actually use.',
    description:
      'Stratus is a privacy-first product analytics platform built for engineering teams. Type-safe events, instant funnels, no SQL required.',
    category: 'BusinessApplication',
    operatingSystem: 'Web',
  },
  // Primary CTA — product action, not personal contact (per SaaS niche).
  // For waitlist / npm-install / book-a-demo variants, swap label + href here.
  cta: {
    primaryLabel: 'Start free — no card',
    primaryHref: 'https://example.com/templates/',
    secondaryLabel: 'View live demo',
    secondaryHref: '#features',
  },
  // Social proof line under hero.
  socialProof: 'Used by 1,200+ product teams · Free for solo founders',
  // Stats triplet (rendered in hero or under logo wall).
  stats: [
    { value: '12k+', label: 'Active teams' },
    { value: '2.4B', label: 'Events / month' },
    { value: '99.99%', label: 'Uptime SLO' },
  ],
  // Logo-wall fake brands (shown in monochrome).
  logoBrands: [
    { name: 'Northwind', mark: 'NW' },
    { name: 'Lumen Labs', mark: 'LL' },
    { name: 'Atlas Systems', mark: 'AS' },
    { name: 'Field & Pine', mark: 'FP' },
    { name: 'Hexcraft', mark: 'HX' },
    { name: 'Caldera', mark: 'CA' },
  ],
  // 3-step "how it works".
  steps: [
    {
      number: 1,
      title: 'Drop in the SDK',
      body: 'A single typed import. No build step, no proxy, no agent. Works in any modern JS runtime.',
      kind: 'code',
    },
    {
      number: 2,
      title: 'Define events as types',
      body: 'Events are first-class TypeScript types. Refactor renames the event everywhere — no orphaned strings.',
      kind: 'types',
    },
    {
      number: 3,
      title: 'Query without SQL',
      body: 'Build funnels, retention, and cohorts visually. Export the underlying SQL when you need it.',
      kind: 'funnel',
    },
  ],
  // Footer link sections.
  footerNav: {
    Product: [
      { label: 'Features', href: '#features' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Changelog', href: 'https://example.com/templates/' },
      { label: 'Status', href: 'https://example.com/templates/' },
    ],
    Resources: [
      { label: 'Docs', href: 'https://example.com/templates/' },
      { label: 'API reference', href: 'https://example.com/templates/' },
      { label: 'Guides', href: 'https://example.com/templates/' },
      { label: 'Customer stories', href: 'https://example.com/templates/' },
    ],
    Company: [
      { label: 'About', href: 'https://example.com/templates/' },
      { label: 'Contact', href: 'mailto:hello@stratus.com' },
      { label: 'Security', href: 'https://example.com/templates/' },
      { label: 'Careers', href: 'https://example.com/templates/' },
    ],
    Legal: [
      { label: 'Privacy', href: 'https://example.com/templates/' },
      { label: 'Terms', href: 'https://example.com/templates/' },
      { label: 'Cookies', href: 'https://example.com/templates/' },
      { label: 'DPA', href: 'https://example.com/templates/' },
    ],
  },
  // Maker / contact (used only in footer "About" / contact link, NOT hero CTA).
  // These default to the demo author's real handles. Cloning users SHOULD
  // replace them with their own product socials + contact.
  socials: {
    github: '#',
    linkedin: '#',
    x: '#',
    facebook: '#',
    threads: '#',
    instagram: '#',
  },
  contactEmail: 'hello@stratus.com',
};

export type Site = typeof site;
