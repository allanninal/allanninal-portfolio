import { defineCollection, z } from 'astro:content';

const features = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    summary: z.string(),
    /** Which HTML/CSS mock surface to render inside the bento tile. */
    mock: z.enum(['chart', 'pipeline', 'code', 'table', 'guard']),
    /** Bento tile size — drives grid placement. */
    size: z.enum(['lg', 'md', 'sm']),
    order: z.number().default(100),
  }),
});

const pricing = defineCollection({
  type: 'content',
  schema: z.object({
    name: z.string(),
    tagline: z.string(),
    monthlyPrice: z.number(),
    annualPrice: z.number(),
    currency: z.string().default('USD'),
    badge: z.string().optional(),
    ctaLabel: z.string(),
    ctaHref: z.string(),
    featured: z.boolean().default(false),
    features: z.array(z.string()),
    order: z.number().default(100),
  }),
});

const faq = defineCollection({
  type: 'content',
  schema: z.object({
    question: z.string(),
    order: z.number().default(100),
  }),
});

const testimonials = defineCollection({
  type: 'content',
  schema: z.object({
    quote: z.string(),
    author: z.string(),
    role: z.string(),
    company: z.string(),
    /** short, medium, or long — used to tune card layout / span. */
    length: z.enum(['short', 'medium', 'long']),
    order: z.number().default(100),
    /** Pro edition: filename (no extension) of the headshot in
     *  public/images/pro/testimonials/. Free shows initials. */
    avatar: z.string().optional(),
  }),
});

export const collections = { features, pricing, faq, testimonials };
