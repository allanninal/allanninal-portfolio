/// <reference path="../.astro/types.d.ts" />

interface ImportMetaEnv {
  readonly PUBLIC_SITE_URL: string;
  readonly PUBLIC_BASE_PATH: string;
  readonly PUBLIC_AUTHOR_DONATE_URL: string;
  readonly PUBLIC_USER_DONATE_URL: string;
  readonly PUBLIC_TEMPLATE_HUB_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
