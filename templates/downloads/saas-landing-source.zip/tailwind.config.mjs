/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        display: ['Geist', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['Geist Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      fontSize: {
        // Modular scale 1.25 (major third) anchored at 16px body
        'xs':  ['0.8rem',   { lineHeight: '1.5' }],
        'sm':  ['0.9rem',   { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.65' }],
        'lg':  ['1.125rem', { lineHeight: '1.6' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.25rem',  { lineHeight: '1.1' }],
        '5xl': ['3rem',     { lineHeight: '1.05' }],
        '6xl': ['3.75rem',  { lineHeight: '1.02' }],
        '7xl': ['4.5rem',   { lineHeight: '1' }],
        '8xl': ['6rem',     { lineHeight: '0.98' }],
      },
      colors: {
        // Near-white / near-black neutral, light-default
        ink: {
          50:  '#fafafa',
          100: '#f4f4f5',
          200: '#e4e4e7',
          300: '#d4d4d8',
          400: '#676772',
          500: '#71717a',
          600: '#52525b',
          700: '#3f3f46',
          800: '#27272a',
          900: '#18181b',
          950: '#0a0a0b',
        },
        // Violet/indigo accent — distinct from Day 1 amber
        accent: {
          DEFAULT: '#7C3AED', // violet-600
          soft:    '#A78BFA', // violet-400
          deep:    '#5B21B6', // violet-800
          indigo:  '#6366F1', // indigo-500
          cyan:    '#06B6D4', // cyan-500 — used for gradient endpoint
        },
      },
      maxWidth: {
        prose: '68ch',
        '7xl': '80rem',
        '8xl': '88rem',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tighter2: '-0.025em',
      },
      backgroundImage: {
        'violet-cyan': 'linear-gradient(120deg, #7C3AED 0%, #6366F1 45%, #06B6D4 100%)',
        'violet-cyan-soft': 'linear-gradient(120deg, rgba(124,58,237,0.12) 0%, rgba(99,102,241,0.08) 50%, rgba(6,182,212,0.10) 100%)',
        'grid-light': 'linear-gradient(to right, rgba(0,0,0,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.04) 1px, transparent 1px)',
        'grid-dark': 'linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)',
      },
      backgroundSize: {
        'grid-cell': '40px 40px',
      },
    },
  },
};
