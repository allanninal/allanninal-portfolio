# SaaS Landing

A free, MIT-licensed, mobile-first SaaS marketing template built with Astro + Tailwind + MDX. Light by default, with a polished dark mode and a violet-to-cyan accent. Designed for indie / early-stage SaaS — dev tools, AI apps, B2B startups, micro-SaaS — that want a single high-converting funnel: trial signup, waitlist, or `npm install`.

> Live demo: `https://example.com/`

![Preview](./preview.png)

## Features

- Hero with HTML/CSS product UI mock (no stock photos), violet-to-cyan gradient
- Logo wall with monochrome fake brands and a stats triplet
- **Bento feature grid** — 5 features at varied tile sizes, each with a real-looking product mock (chart, code block, table, pipeline, guardrails)
- 3-step "How it works" with mini illustrations (CSS only)
- **Pricing table** — 3 tiers driven by MDX, monthly/annual toggle that swaps prices, "Most popular" badge
- 3 testimonials at mixed lengths (short / medium / long)
- FAQ accordion using native `<details>` (works without JS)
- Final CTA band on a violet-to-cyan gradient
- **Light + dark mode end-to-end** with `prefers-color-scheme` respect, a manual toggle, and persistence
- **`SoftwareApplication` schema.org JSON-LD** with one `Offer` per pricing tier
- Self-hosted Geist + Geist Mono + Inter via `@fontsource/*`
- Configurable footer donate button (Ko-fi by default, any URL works — or hide it entirely)
- One-click GitHub Pages deploy. No Vercel lock-in.
- One-command Playwright smoke tests

## Stack

- [Astro 4](https://astro.build/) (`output: 'static'`, `trailingSlash: 'always'`)
- [Tailwind CSS 3](https://tailwindcss.com/) with violet (`#7C3AED`) → indigo (`#6366F1`) → cyan (`#06B6D4`) tokens
- [`@astrojs/mdx`](https://docs.astro.build/en/guides/integrations-guide/mdx/) for content collections (features / pricing / testimonials / FAQ)
- [`@fontsource/geist-sans`](https://fontsource.org/fonts/geist-sans) + [`@fontsource/geist-mono`](https://fontsource.org/fonts/geist-mono) + [`@fontsource/inter`](https://fontsource.org/fonts/inter)
- [Playwright](https://playwright.dev/) for smoke tests

## Quick start

```bash
# 1. Download the source ZIP from example.com
unzip saas-landing-source.zip
cd saas-landing

# 2. Install
npm install

# 3. Develop
npm run dev    # http://localhost:4321/saas-landing/

# 4. Build
npm run build

# 5. Preview the production build
npm run preview
```

## Deploy to GitHub Pages

This template ships designed to deploy to `https://<username>.github.io/<repo>/`.

1. **Download the source ZIP** from `example.com`. Unzip it into a fresh folder and `git init`. Push to a new repo of your own.
2. **Repo Settings → Pages → Source: GitHub Actions.**
3. Add a workflow at `.github/workflows/pages.yml` (or copy this snippet):

   ```yaml
   - run: npm ci
   - run: npm run build
     env:
       PUBLIC_SITE_URL: https://<username>.github.io
       PUBLIC_BASE_PATH: /<repo-name>/
   ```

### Surface as your own site

If you want this template at the *root* of a custom domain (e.g. `stratus.app`):

```bash
PUBLIC_SITE_URL=https://stratus.app
PUBLIC_BASE_PATH=/
```

Set both as repo variables. The build resolves them at compile time. No code edits required.

## Customize

This template is intentionally small. Most edits happen in three places.

| What you want to change | File |
|---|---|
| Product name, tagline, description, primary CTA copy | `src/data/site.ts` |
| Logo wall brands + stats triplet | `src/data/site.ts` (`logoBrands`, `stats`) |
| Footer nav sections | `src/data/site.ts` (`footerNav`) |
| Social / contact email | `src/data/site.ts` (`socials`, `contactEmail`) |
| Add / edit a feature tile | Drop a new `*.mdx` into `src/content/features/` (set `mock`, `size`, `order`) |
| Add / edit a pricing tier | Drop a new `*.mdx` into `src/content/pricing/` |
| Add / edit a testimonial | Drop a new `*.mdx` into `src/content/testimonials/` (`length` controls span) |
| Add / edit a FAQ item | Drop a new `*.mdx` into `src/content/faq/` |
| Color accent | `tailwind.config.mjs` → `colors.accent` (default violet `#7C3AED`) |
| Fonts | Replace `@fontsource/*` imports in `src/styles/global.css` |
| Site URL / base path | `.env` (or repo variables) — `PUBLIC_SITE_URL`, `PUBLIC_BASE_PATH` |
| OG image | Replace `public/og.svg` (1200 × 630) |
| Favicon | `public/favicon.svg` |
| Footer donate button | `.env` — `PUBLIC_AUTHOR_DONATE_URL` (blank to hide) |
| Optional in-page donate button | `.env` — `PUBLIC_USER_DONATE_URL` (blank by default) |
| **Hide "free template" download bar** | `.env` — `PUBLIC_TEMPLATE_HUB_URL` must be **blank** (the demo deploy's flag; leave empty on your fork) |

### Feature tile mock surfaces

Each feature `mdx` carries a `mock` field, which selects which HTML/CSS mock surface renders inside the tile:

- `chart` — bar chart with live counter
- `code` — typed event SDK call
- `table` — cohort retention grid
- `pipeline` — release deltas
- `guard` — compliance / privacy guardrails

To add a new mock kind, drop a component into `src/components/mocks/` and register it in `FeatureBento.astro` and the `features` schema in `src/content/config.ts`.

### Pricing toggle

`src/components/Pricing.astro` ships a CSS + tiny inline JS monthly/annual toggle. Each tier MDX exposes `monthlyPrice` and `annualPrice`. To extend (e.g., quarterly), add a button + a new `data-billing-target`, an extra price field, and the matching JS branch.

## Testing

```bash
npx playwright install --with-deps chromium  # first time only
npm run test
```

Day 2 ships a Playwright **smoke suite** (`tests/smoke.spec.ts`) that covers:

- The home route returns 200, renders an `<h1>`, and produces no console errors
- Home @ 375 × 667 has no horizontal scroll
- Theme toggle swaps `class="dark"` and `data-theme`, and persists across reload
- Pricing monthly/annual toggle swaps the visible price values
- An FAQ `<details>` opens when its summary is clicked

The fuller test kit (axe a11y, full responsive matrix, Lighthouse CI, linkinator) lives in `.claude/skills/template-testing/SKILL.md` and will be added to this template in a follow-up.

When you add a new page or interactive widget, add a row to `tests/smoke.spec.ts`.

## Alternate deploys

The build output in `dist/` is plain static HTML/CSS/JS — drop it on any static host.

- **Vercel:** import the repo, framework preset Astro, set `PUBLIC_SITE_URL` + `PUBLIC_BASE_PATH=/` as env vars
- **Netlify:** same, with build command `npm run build`, publish directory `dist`
- **Cloudflare Pages:** same, build command `npm run build`, output `dist`

## Support / donations

This template is **MIT-licensed** and free. Use it personally, commercially, for client work — no permission needed, no attribution required (though appreciated).


The repo's "Sponsor" button is driven by the repo-root `.github/FUNDING.yml` (Ko-fi handle). Edit or delete that file in your fork to repoint or hide it.

The footer Ko-fi attribution is rendered by `<DonateButton>` (`src/components/DonateButton.astro`) and reads from `PUBLIC_AUTHOR_DONATE_URL`. Leave that env var blank to hide the link entirely.

## License

MIT. See [LICENSE](./LICENSE).

Built and maintained by [@example](#). Live at [example.com](https://example.com/templates).
