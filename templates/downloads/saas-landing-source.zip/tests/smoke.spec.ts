import { test, expect, type ConsoleMessage } from '@playwright/test';

const ROUTES = ['/'];

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // scripts can 403 under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead/i;
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() !== 'error') return;
      const text = m.text();
      const u = m.location()?.url || '';
      if (THIRD_PARTY.test(text) || THIRD_PARTY.test(u)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(`console.error: ${text}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home @ 375x667 has no horizontal scroll', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  await page.locator('h1').first().waitFor();
  const overflow = await page.evaluate(() => {
    const html = document.documentElement;
    return html.scrollWidth > html.clientWidth;
  });
  expect(overflow).toBe(false);
});

test('theme toggle swaps class and persists across reload', async ({ page }) => {
  await page.goto('/');
  const initialDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );

  await page.getByRole('button', { name: /toggle theme/i }).click();

  const afterDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );
  expect(afterDark).toBe(!initialDark);

  const stored = await page.evaluate(() => localStorage.getItem('theme'));
  expect(stored).toBe(afterDark ? 'dark' : 'light');

  await page.reload();
  const reloadedDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );
  expect(reloadedDark).toBe(afterDark);

  const dataTheme = await page.evaluate(() => document.documentElement.dataset.theme);
  expect(dataTheme).toBe(reloadedDark ? 'dark' : 'light');
});

test('pricing toggle flips visible monthly/annual prices', async ({ page }) => {
  await page.goto('/');
  // Scroll the pricing section into view so the buttons are interactive.
  await page.locator('#pricing').scrollIntoViewIfNeeded();

  const proPrice = page.locator(
    '#pricing-root [data-price-monthly][data-price-annual]',
  ).nth(1); // second tier = Pro

  const monthlyText = (await proPrice.textContent())?.trim();
  expect(monthlyText, 'monthly price text').toMatch(/\$\d+/);

  await page.getByRole('button', { name: /^Annual/ }).click();
  await expect(proPrice).not.toHaveText(monthlyText ?? '');

  // Verify the displayed price actually equals the data-price-annual attribute.
  const annualText = (await proPrice.textContent())?.trim();
  const annualAttr = await proPrice.getAttribute('data-price-annual');
  expect(annualText).toBe(`$${annualAttr}`);

  // And toggling back to monthly restores the monthly value.
  await page.getByRole('button', { name: /^Monthly/ }).click();
  await expect(proPrice).toHaveText(monthlyText ?? '');
});

test('FAQ details opens when summary is clicked', async ({ page }) => {
  await page.goto('/');
  const firstFaq = page.locator('#faq details').first();
  await firstFaq.scrollIntoViewIfNeeded();

  expect(await firstFaq.evaluate((el) => (el as HTMLDetailsElement).open)).toBe(false);
  await firstFaq.locator('summary').click();
  expect(await firstFaq.evaluate((el) => (el as HTMLDetailsElement).open)).toBe(true);
});
