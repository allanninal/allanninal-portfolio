import { defineConfig } from 'astro/config';
import stripProAssets from '../../scripts/strip-pro-assets.mjs';
import mdx from '@astrojs/mdx';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://www.allanninal.dev';
const BASE = process.env.PUBLIC_BASE_PATH || '/saas-landing/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [stripProAssets(), tailwind({ applyBaseStyles: false }), mdx()],
});
