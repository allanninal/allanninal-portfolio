import { test, expect } from '@playwright/test';

// Edition is read from the environment, not imported from src/data/edition.ts:
// that module uses import.meta.env, which does not exist in the Playwright
// (node) context and throws before any test runs.
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barName = isPro ? /Pro edition — live preview/i : /Free template — download or fork/i;

test.describe('TemplateInfo download bar', () => {
  test('renders the canonical links with correct hrefs', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', { name: barName });
    await expect(bar).toBeVisible();

    const slug = 'calligrapher';
    await expect(bar.getByRole('link', { name: /All 365/i })).toHaveAttribute(
      'href',
      /www\.allanninal\.dev\/templates/
    );
    await expect(bar.getByRole('link', { name: /Free Static HTML/i })).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-static\\.zip$`)
    );
    await expect(bar.getByRole('link', { name: /Free Astro/i })).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-source\\.zip$`)
    );
    // The Pro slot points at the Pro catalogue, never at LinkedIn.
    await expect(bar.getByRole('link', { name: /Get Pro|Pro Static HTML/i }).first()).toHaveAttribute(
      'href',
      /www\.allanninal\.dev\/templates\/pro\//
    );
  });

  test('contains zero github.com links', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', { name: barName });
    expect(await bar.locator('a[href*="github.com"]').count()).toBe(0);
  });
});
