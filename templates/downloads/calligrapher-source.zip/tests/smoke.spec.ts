import { test, expect } from '@playwright/test';

test.describe('Tessa Wardlow — smoke tests', () => {
  test('the page leads with the hands', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Tessa Wardlow/);
    await expect(page.locator('h1')).toContainText(/tool at an angle/i);
    const ids = await page.locator('main section[id]').evaluateAll((s) => s.map((x) => x.id));
    expect(ids.slice(0, 2)).toEqual(['hands', 'ductus']);
  });

  // ── The pen model ───────────────────────────────────────────────────────
  // The claim is that the letters are written by the pen rather than drawn as
  // outlines: one skeleton per letter, swept by each hand's nib. So the same
  // letter in two hands must be a DIFFERENT polygon, and no letter may be an
  // image.
  test('every letter is generated, and no two hands generate the same shape', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('img, picture').count()).toBe(0);

    const bands = page.locator('#hands .specimen');
    const n = await bands.count();
    expect(n).toBe(5);

    // The letter "n" in every hand, as its rendered path data.
    const firstOfEach = await bands.evaluateAll((els) =>
      els.map((el) => el.querySelector('svg path')?.getAttribute('d') ?? ''));
    expect(firstOfEach.every((d) => d.startsWith('M'))).toBe(true);
    expect(new Set(firstOfEach).size).toBe(n);
  });

  // A broad nib does not rotate in the hand, so its offset is a constant
  // vector; a pointed nib swells on the pull, so its offset is perpendicular to
  // travel. The two produce measurably different geometry, and the page says
  // which hand is which — so the drawing and the table have to agree.
  test('the pointed hand is the one the table says has no nib width', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#hands .hand').evaluateAll((els) =>
      els.map((el) => ({
        id: el.id,
        sized: el.querySelector('.hand-nums dd')?.textContent?.trim() ?? '',
        angle: el.querySelectorAll('.hand-nums dd')[1]?.textContent?.trim() ?? '',
      })));
    const pointed = rows.filter((r) => /ratio/i.test(r.sized));
    expect(pointed.length).toBe(1);
    expect(pointed[0].id).toBe('hand-copperplate');
    // …and it is the only one that declines to state a pen angle.
    expect(pointed[0].angle).toMatch(/pressure/i);
    for (const r of rows.filter((r) => !/ratio/i.test(r.sized))) {
      expect(r.sized).toMatch(/nib widths/);
      expect(r.angle).toMatch(/^\d+°$/);
    }
  });

  test('each hand ships its own ladder and angle diagram', async ({ page }) => {
    await page.goto('/');
    const hands = page.locator('#hands .hand');
    const count = await hands.count();
    expect(await page.locator('#hands .diagrams figure').count()).toBe(count * 2);
    // The ladder for a 4-nib-width hand has more steps than a 3.5 one.
    const steps = await page.locator('#hands .hand .diagrams figure:first-child svg').evaluateAll(
      (svgs) => svgs.map((s) => s.querySelectorAll('rect').length));
    expect(Math.max(...steps)).toBeGreaterThan(Math.min(...steps));
  });

  // ── The ductus ──────────────────────────────────────────────────────────
  test('stroke order is an ordered list, one per letter, with the skeleton shown', async ({ page }) => {
    await page.goto('/');
    const figs = page.locator('#ductus figure');
    expect(await figs.count()).toBe(4);
    expect(await page.locator('#ductus ol').count()).toBe(4);
    // Every ductus drawing exposes the skeleton it was swept from.
    expect(await page.locator('#ductus svg polyline').count()).toBeGreaterThanOrEqual(4);
    // The single-stroke letter has exactly one step; the others have more.
    const steps = await figs.evaluateAll((f) => f.map((x) => x.querySelectorAll('ol li').length));
    expect(Math.min(...steps)).toBe(1);
    expect(Math.max(...steps)).toBeGreaterThan(1);
  });

  // ── Schema ──────────────────────────────────────────────────────────────
  // The opposite call to day 128, on the same rule: a per-envelope rate IS
  // settled, so it is asserted as a UnitPriceSpecification. What is withheld is
  // any claim that a six-week evening class awards a credential.
  test('prices are asserted where settled and credentials never are', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));

    const service = JSON.parse(blocks.find((b) => b.includes('"Service"') && b.includes('OfferCatalog'))!);
    const offers = service.hasOfferCatalog.itemListElement;
    const priced = offers.filter((o: any) => o.priceSpecification);
    expect(priced.length).toBeGreaterThan(0);
    for (const o of priced) {
      expect(o.priceSpecification['@type']).toBe('UnitPriceSpecification');
      expect(o.priceSpecification.unitText).toBeTruthy();
      expect(typeof o.priceSpecification.price).toBe('number');
    }
    // A "from" rate is a floor, not a price, so it carries no specification.
    expect(offers.length).toBeGreaterThan(priced.length);

    const courses = blocks.filter((b) => b.includes('"Course"')).map((b) => JSON.parse(b));
    expect(courses.length).toBe(await page.locator('#classes tbody tr').count());
    for (const c of courses) {
      expect(c.hasCourseInstance.maximumAttendeeCapacity).toBeGreaterThan(0);
      expect(c.coursePrerequisites).toBeTruthy();
      expect(c.educationalCredentialAwarded).toBeUndefined();
      expect(c.numberOfCredits).toBeUndefined();
    }

    const all = blocks.join('');
    expect(all).not.toContain('aggregateRating');
    expect(all).not.toContain('"image"');
    // Day 128's type must not have survived the scaffold.
    expect(all).not.toContain('suggestedMinAge');
  });

  // ── Content ─────────────────────────────────────────────────────────────
  test('the spares rule is stated everywhere it matters', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#services .note-box')).toContainText(/fifteen per cent/i);
    await expect(page.locator('label[for="count"] .hint')).toContainText(/15%/);
  });

  test('the seats in the table are the seats in the markup', async ({ page }) => {
    await page.goto('/');
    const seats = await page.locator('#classes tbody td:nth-child(2)').allTextContents();
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const caps = blocks.filter((b) => b.includes('"Course"'))
      .map((b) => JSON.parse(b).hasCourseInstance.maximumAttendeeCapacity);
    expect(caps).toEqual(seats.map((s) => Number(s.trim())));
  });

  test('the guide sheets are free and ruled from the same numbers', async ({ page }) => {
    await page.goto('/');
    await page.locator('#stock a', { hasText: /guide sheets/i }).first().click();
    await expect(page).toHaveURL(/\/guide-sheets\/$/);
    await expect(page.locator('h1')).toContainText('Guide sheets');
    await expect(page.locator('button', { hasText: /Print/i })).toBeVisible();
    // One ruled sheet per hand, and the slanted hands carry slant lines.
    expect(await page.locator('main figure svg').count()).toBeGreaterThanOrEqual(5);
  });

  test('the Pro envelope brief is absent from the free build', async ({ page }) => {
    const res = await page.goto('/envelope-brief/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });

  test('the enquiry form asks for the stock, not just the number', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#work', '#count', '#when']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#work option').count()).toBeGreaterThan(8);
    await expect(page.locator('#count')).toHaveAttribute('placeholder', /stock matters more/i);
  });

  // ── Hygiene ─────────────────────────────────────────────────────────────
  test('no trace of the day-128 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['petrakis', 'tattoo', 'louisville', 'stencil', 'blowout', 'aftercare']) {
      expect(html, `day-128 copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('the ruling never sits behind body text', async ({ page }) => {
    await page.goto('/');
    // .ruled-x is the guide-sheet ruling. It is allowed under specimens only.
    const ruled = await page.locator('.ruled-x').evaluateAll((els) =>
      els.map((el) => (el.textContent || '').trim().length));
    expect(ruled.length).toBeGreaterThan(0);
    expect(Math.max(...ruled, 0)).toBe(0);
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });
});
