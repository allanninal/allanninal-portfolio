// Tessa Wardlow — Charleston, SC. Fictional.
//
// The organising idea: a calligraphic hand is not a font and not a style. It is
// a tool held at an angle, a letter height measured in nib widths, and a fixed
// order of strokes. Give three people the same skeleton and the same nib at the
// same angle and you get the same letter; change the angle by fifteen degrees
// and every thick and thin in it moves.
//
// So the letters on this page are generated rather than drawn — swept from one
// set of skeletons by the pen each hand specifies (src/data/skeletons.ts). The
// specimen is therefore an argument, not a decoration: it cannot disagree with
// the table beside it, because the table is what produced it.

import type { Pen } from '~/data/skeletons';

export const site = {
  name:        'Tessa Wardlow',
  shortName:   'Tessa Wardlow',
  title:       'Tessa Wardlow — calligrapher, Charleston, South Carolina',
  tagline:     'A hand is a tool at an angle, not a font.',
  owner:       'Tessa Wardlow',
  ownerRole:   'Calligrapher',
  credential:  'Fourteen years · broad edge and pointed pen · teaching since 2018',
  city:        'Charleston',
  state:       'SC',
  language:    'en',
  phoneDisplay: '(843) 555-0129',
  phoneHref:   '+18435550129',
  email:       'tessa@wardlowletters.example',
  streetAddress: '54 Cannon St',
  postalCode:  '29403',
  hours:       'Studio Tuesday to Friday · classes on Thursday evenings',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'Calligraphy in Charleston: envelopes, certificates and vows in five hands, plus evening ' +
    'classes. Every specimen here is written by the pen, not set in a font.',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The hands',  href: '#hands' },
  { label: 'Stroke order', href: '#ductus' },
  { label: 'Commissions', href: '#services' },
  { label: 'What the stock does', href: '#stock' },
  { label: 'Classes',    href: '#classes' },
];

export const intro =
  'Everything on this page was written by a pen rather than set in a typeface. The letters below ' +
  'are swept from one set of skeletons by the nib each hand specifies — same skeleton, five hands, ' +
  'five alphabets — so the specimen cannot quietly disagree with the numbers next to it. Change the ' +
  'pen angle in the table and the letters change on the page, exactly as they would on paper.';

// ── The five hands ────────────────────────────────────────────────────────
// `pen` drives the drawing; the rest is what a copybook actually specifies.

export type Hand = {
  id: string;
  k: string;
  pen: Pen;
  tool: string;
  sized: string;
  speed: string;
  used: string;
  n: string;
};

export const hands: Hand[] = [
  {
    id: 'foundational', k: 'Foundational',
    pen: { mode: 'broad', nibWidths: 4, angle: 30, slant: 0 },
    tool: 'Broad edge, 2.4 mm',
    sized: '4 nib widths',
    speed: '14 envelopes an hour',
    used: 'Certificates, teaching',
    n: 'Edward Johnston reconstructed it from a tenth-century English manuscript, and every course here starts on it because the pen angle never changes and the letters are built on a circle. Learn to hold 30° for an hour and every other hand gets easier.',
  },
  {
    id: 'italic', k: 'Italic',
    pen: { mode: 'broad', nibWidths: 5, angle: 42, slant: 8 },
    tool: 'Broad edge, 1.9 mm',
    sized: '5 nib widths',
    speed: '18 envelopes an hour',
    used: 'Envelopes, place cards',
    n: 'The workhorse of this studio. Narrower letters and a steeper pen than Foundational, so it fits a long name on a short envelope, and it is fast — most of the addressing that leaves here is Italic whatever the couple thinks they asked for.',
  },
  {
    id: 'uncial', k: 'Uncial',
    pen: { mode: 'broad', nibWidths: 3.5, angle: 20, slant: 0 },
    tool: 'Broad edge, 3.0 mm',
    sized: '3.5 nib widths',
    speed: '9 envelopes an hour',
    used: 'Certificates, awards',
    n: 'Wide, round and majuscule — there are no capitals because every letter is one. The flat 20° pen puts the weight at the bottom of the curve, which is why it reads as old rather than as merely round.',
  },
  {
    id: 'textura', k: 'Textura',
    pen: { mode: 'broad', nibWidths: 5, angle: 40, slant: 0 },
    tool: 'Broad edge, 2.0 mm',
    sized: '5 nib widths',
    speed: '7 envelopes an hour',
    used: 'Diplomas, one word at a time',
    n: 'Blackletter. Compressed to the point where the space between two stems equals a stem, which is what makes a page of it look like woven cloth and a single word of it look like a heavy metal album. I will do a name; I will talk you out of a paragraph.',
  },
  {
    id: 'copperplate', k: 'Copperplate',
    pen: { mode: 'pointed', nibWidths: 0, angle: 0, slant: 30 },
    tool: 'Pointed nib in an oblique holder',
    sized: 'By ratio, not nib widths',
    speed: '10 envelopes an hour',
    used: 'Wedding envelopes, vows',
    n: 'The one people mean when they say calligraphy. A pointed nib has no width — the tines spread under pressure on the pull, so the thick strokes are pressure and the thins are the absence of it. That is why it is sized by ratio and why it cannot be measured in nib widths at all.',
  },
];

export const handsNote =
  'Nib widths are how a broad edge is measured: you step the corner of the nib up the page, four ' +
  'or five times, and that is the x-height. It is a unit defined by the tool, which is why a hand ' +
  'written with a 2.4 mm nib and one written with a 0.9 mm nib are the same hand at different ' +
  'sizes. Copperplate is the exception and the table says so rather than inventing a number for it.';

// ── The ductus ────────────────────────────────────────────────────────────
// Stroke order, as an ordered list, because it is one. Getting it wrong does
// not produce a slightly different letter — it produces a letter that does not
// join to the next one.

export const ductus: Record<string, string[]> = {
  o: [
    'Start at the top, just right of centre, and pull left and down in one curve to the baseline.',
    'Return to the top and take the right side down to meet it. Two strokes, one shape, and the join is at six o’clock where nobody looks.',
  ],
  n: [
    'Pull the stem straight down from the x-line to the baseline.',
    'From a third of the way up the stem, push out and over the arch, then down to the baseline. The arch leaves the stem below the top — a branch, not a corner.',
  ],
  a: [
    'Start at the x-line, curve left and down, round the bottom and back up: the bowl.',
    'Bring the stem down the right, touching the bowl top and bottom. On a serif hand it exits into the next letter.',
  ],
  i: [
    'One stroke, top to baseline. It is the whole of the first evening of a beginners’ course, and it is not a joke: a straight, evenly weighted, correctly angled stem is the hardest easy thing in the alphabet.',
  ],
};

export const ductusNote =
  'Every letter above is drawn from these skeletons by the pen in the table — the same path, swept ' +
  'by a different nib. Stroke order is not calligraphic etiquette: an arch that starts at the top ' +
  'of the stem instead of a third of the way down makes a letter that will not join, and you find ' +
  'out at the end of the word rather than at the start.';

// ── Commissions ───────────────────────────────────────────────────────────

export const services = [
  { k: 'Envelope addressing', rate: '$4.50 each', unit: 'envelope',
    n: 'Italic or Foundational, guest list in a spreadsheet with one column per line as it should appear. I retype nothing — what is in the cell is what goes on the envelope, misspellings included, because guessing at a surname is worse than copying one.' },
  { k: 'Envelope addressing, Copperplate', rate: '$6.50 each', unit: 'envelope',
    n: 'Slower by a third and worth it on a heavy cotton stock. Same guest-list rule. Return addresses are $2.00 and are done at the same time or not at all — setting up twice costs more than the addresses do.' },
  { k: 'Place and escort cards', rate: '$3.00 each', unit: 'card',
    n: 'First name and surname, or table number, on card you supply. Ten spares minimum, because the seating chart changes on the Thursday and it always changes on the Thursday.' },
  { k: 'Vows, readings, a poem', rate: 'From $180', unit: 'piece',
    n: 'One piece on handmade paper, ruled and written by hand, with the text agreed in writing first. Two rounds of layout, then it is written — there is no undo on the ninth line of a page.' },
  { k: 'Certificates and awards', rate: 'From $65', unit: 'piece',
    n: 'Uncial or Foundational, names filled by hand on your printed blanks or written whole. Volume rate over twenty.' },
  { k: 'Live event calligraphy', rate: '$220 an hour', unit: 'hour',
    n: 'On-site, about eighteen pieces an hour once set up. I need a table, a chair, my own light and forty minutes before doors — a calligrapher stood at a cocktail table with a phone torch is a decoration, not a service.' },
];

export const sparesRule =
  'Order fifteen per cent more envelopes than you have guests. Not because I make fifteen per cent ' +
  'mistakes — because envelopes arrive creased, the list grows twice, and a single re-write needs a ' +
  'spare that the stationer takes three weeks to reprint. Every studio asks for this and the couples ' +
  'who ignore it are the couples who lose a week.';

// ── What the stock does ───────────────────────────────────────────────────

export const stock = [
  { k: 'Laser-printed or coated envelopes', does: 'Ink beads and will not dry',
    fix: 'Gouache, or a different envelope. The toner is plastic and nothing water-based sticks to it.' },
  { k: 'Cotton and handmade paper', does: 'Feathers along the fibre',
    fix: 'A less free-flowing ink, a finer nib, and a test on the spare sheet before the first real one. Beautiful stock, and it is the reason spares exist.' },
  { k: 'Dark or black stock', does: 'Ink disappears into it',
    fix: 'White gouache mixed to single cream, remixed every twenty minutes because it settles. Costs about a third more in time and I quote it that way.' },
  { k: 'Vellum, glassine, translucent', does: 'Rejects water-based ink entirely',
    fix: 'Gouache again, or an entirely different plan. Test first — this is the one that surprises people who have chosen a beautiful vellum wrap.' },
  { k: 'Metallic and pearlescent finishes', does: 'Ink sits on the coating and rubs off',
    fix: 'Sand the coating (no), or accept a slightly heavier gouache line. Always tested, never assumed.' },
];

export const stockNote =
  'Send me one envelope before you order two hundred. A five-minute test on the actual stock is the ' +
  'single cheapest thing in this entire process, and skipping it is how a box of beautiful ' +
  'letterpress envelopes turns into a box of beautiful smudged envelopes.';

// ── Classes ───────────────────────────────────────────────────────────────

export const classes = [
  { k: 'Foundational, six weeks', seats: 8, length: '6 × 2 hours, Thursday evenings', price: '$340',
    kit: 'Nib, holder, ink, layout pad, guide sheets',
    pre: 'None. This is the one to start with.',
    n: 'Two hours a week on one hand, at one pen angle. By week three you will be able to see your own pen angle drifting, which is the entire skill and the reason a weekend course cannot teach it.' },
  { k: 'Italic, one day', seats: 10, length: '1 × 6 hours, Saturday', price: '$180',
    kit: 'Nib, holder, ink, paper',
    pre: 'None, though Foundational first makes it easier',
    n: 'A whole hand in a day, honestly presented as an introduction rather than a qualification. You leave able to write a legible envelope slowly.' },
  { k: 'Copperplate, weekend', seats: 6, length: '2 × 5 hours', price: '$395',
    kit: 'Oblique holder, three nibs, ink, gum arabic',
    pre: 'One broad-edge course, or equivalent practice',
    n: 'Pointed pen is pressure control, and pressure control is a different skill from angle control. Six seats because I have to stand behind every one of you and watch the pull.' },
  { k: 'Private lesson', seats: 1, length: '2 hours', price: '$150',
    kit: 'Whatever your hand needs',
    pre: 'None',
    n: 'Usually booked by somebody who has been practising alone for a year from a book and cannot see why it is not working. It is almost always the pen angle. It is almost never talent.' },
];

export const classNote =
  'Every class includes the kit, and the kit is yours to keep — a course that sends you home ' +
  'without a nib has taught you nothing you can practise. Seats are firm numbers rather than ' +
  'guidance: eight is how many people I can stand behind in two hours.';

// ── The commission, in order ──────────────────────────────────────────────

export const commission = [
  { k: 'You send the stock and the list', n: 'One envelope for testing and the guest list in a spreadsheet, one column per line as it should appear. Both before a date is held.' },
  { k: 'I test the stock and quote', n: 'Ink and nib on your actual paper, within two days. The quote names the hand, the per-piece rate and the spares I need.' },
  { k: 'Fifty per cent, and the date is yours', n: 'Balance on completion. Wedding season books eight to ten weeks out and Charleston in April is not a week to be optimistic about.' },
  { k: 'Ruling up', n: 'Every sheet is ruled by hand before a letter is written — baseline, x-line, slant. This is the invisible half of the job and it is a third of the hours.' },
  { k: 'Writing, in one sitting per batch', n: 'A batch is written in one session because a hand changes between sittings. Two hundred envelopes is three sessions and they will not be identical; they will be closer than three separate weeks would make them.' },
  { k: 'Delivered flat, with the spares', n: 'Unused spares come back to you. Photographed under daylight, never under a filter — the ink is black and the paper is the colour it actually is.' },
];

export const said = {
  text: 'She asked for one envelope before we ordered them, tested it, and told us the coating would never take ink. That one email saved us two hundred envelopes and about a month.',
  who: 'Wedding client, Mount Pleasant — 2025',
};

export const faqs = [
  { q: 'What is a nib width, and why is my x-height measured in them?',
    a: 'You step the corner of the broad nib up the page in a little staircase — four squares for Foundational, five for Italic — and where the staircase ends is the top of your small letters. It is a unit defined by the tool, so the same hand written with a 2.4 mm nib and a 0.9 mm nib is the same hand at two sizes, with every proportion intact. It is the most useful idea in the craft and it takes ten minutes to learn.' },
  { q: 'Why can Copperplate not be measured that way?',
    a: 'Because a pointed nib has no width. The line is thin until you press, and the tines spread on the pull — so thicks are pressure and thins are its absence. Copperplate is specified by ratio and slant instead, and any chart that gives it a nib-width number is copying a broad-edge chart without thinking.' },
  { q: 'How many envelopes should I order?',
    a: 'Fifteen per cent more than your guest count. Envelopes arrive creased, the list grows twice, and one re-write with no spare means a three-week reprint. This is the single most common reason a stationery timeline slips and it costs about nine dollars to avoid.' },
  { q: 'Can you match the font on our invitation?',
    a: 'Complement it, not match it. A typeface is a set of finished shapes; a hand is a tool at an angle making shapes as it goes, and the two do not converge. What I can do is take the invitation’s weight, slant and spacing and choose the hand that sits with it — usually Italic, occasionally Copperplate, almost never Textura.' },
  { q: 'How far ahead do you book?',
    a: 'Eight to ten weeks in spring, three to four the rest of the year. A date is held by the deposit and by the stock test, not by an email — I have held two Saturdays for envelopes that never arrived and I do not do that any more.' },
  { q: 'Is the writing on this page real?',
    a: 'The letters are generated by the pen model in src/data/skeletons.ts — one set of skeletons swept by each hand’s nib at its own angle. That is real in the sense that matters here: change the angle in the table and the letters change on the page the way they would on paper. It is not a photograph of my writing, and for a template that is the honest choice.' },
];

export const templateNote =
  'Tessa Wardlow is a fictional calligrapher invented for this template. Every letterform on the ' +
  'page is generated from four skeletons and the pen each hand specifies — no images, no icon font, ' +
  'no photographs. Swap the skeletons or the pens in src/data/ and the specimens, the ductus ' +
  'diagrams and the guide sheets all follow.';
