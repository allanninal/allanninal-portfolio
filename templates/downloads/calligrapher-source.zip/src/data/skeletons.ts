// The pen model.
//
// A calligraphic letter is not a shape somebody drew. It is a skeleton — the
// path the hand travels — swept by a nib held at a fixed angle. Change the
// angle and every thick and thin in the letter moves, without the skeleton
// changing at all. That is the single fact this whole template is built on, so
// the letters on the page are generated that way rather than drawn as outlines:
// one skeleton, five hands, five different alphabets.
//
// Broad edge: the nib is a straight edge of fixed width held at a constant
// angle, so the offset from the skeleton is a CONSTANT vector. Strokes running
// along the pen angle come out hairline; strokes across it come out full width.
//
// Pointed nib: there is no width. The tines spread under pressure, which
// happens on the pull, so the offset is PERPENDICULAR to travel and its size
// depends on how close the stroke is to the pull direction. Copperplate is
// therefore not measured in nib widths at all — a fact the page states, because
// it is the commonest thing people get wrong when they buy their first pen.

export type Pt = [number, number];
export type Stroke = Pt[];

/** Skeletons in a 100 × 100 box, x-height 0–100, drawn as polylines that a
 *  hand could actually travel. Ascenders and descenders run outside the box. */
export const SKELETONS: Record<string, Stroke[]> = {
  // o — two arcs, anticlockwise then clockwise, the way it is written.
  o: [
    [[50, 0], [26, 12], [18, 38], [22, 68], [38, 92], [56, 98]],
    [[50, 0], [72, 10], [82, 38], [78, 70], [62, 92], [56, 98]],
  ],
  // n — the stem, then the arch and the second leg.
  n: [
    [[16, 0], [14, 40], [13, 78], [13, 98]],
    [[14, 22], [26, 4], [48, 0], [66, 10], [72, 34], [72, 66], [72, 98]],
  ],
  // a — the bowl, then the stem.
  a: [
    [[66, 8], [46, 0], [26, 10], [18, 40], [24, 74], [44, 92], [66, 84]],
    [[70, 0], [69, 40], [68, 74], [70, 98]],
  ],
  // i — one stroke, which is what makes it the letter every course starts on.
  i: [
    [[24, 2], [23, 40], [22, 74], [26, 96]],
  ],
};

/** The five hands, as they are actually specified in a copybook. `nib` is the
 *  nib width as a fraction of x-height — the inverse of the "x-height in N nib
 *  widths" a calligrapher writes down — and `angle` is the pen angle in degrees
 *  measured from the horizontal. */
export type Pen = {
  mode: 'broad' | 'pointed';
  nibWidths: number;   // x-height, in nib widths. 0 for a pointed nib.
  angle: number;       // pen angle, degrees. Meaningless for a pointed nib.
  slant: number;       // degrees off vertical.
};

/** Catmull-Rom resample. The skeletons are written as six or seven points
 *  because that is a readable way to state a curve; sweeping them directly
 *  produces a faceted letter, since every offset polygon is only as smooth as
 *  the path it came from. Interpolating to ~14 points per segment first costs
 *  nothing and is the difference between a written letter and a chamfered one. */
function smooth(stroke: Stroke, per = 14): Stroke {
  if (stroke.length < 3) return stroke;
  const pt = (i: number) => stroke[Math.max(0, Math.min(stroke.length - 1, i))];
  const out: Stroke = [];
  for (let i = 0; i < stroke.length - 1; i += 1) {
    const [p0, p1, p2, p3] = [pt(i - 1), pt(i), pt(i + 1), pt(i + 2)];
    for (let j = 0; j < per; j += 1) {
      const t = j / per;
      const t2 = t * t;
      const t3 = t2 * t;
      out.push([
        0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
        0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
      ]);
    }
  }
  out.push(stroke[stroke.length - 1]);
  return out;
}

/** Sweep a nib along one skeleton stroke and return the outline as a polygon.
 *
 *  Broad edge: offset every point by ±(nib/2) along the pen-angle vector, then
 *  walk out along one side and back along the other. That IS the nib — a line
 *  segment of fixed length and fixed direction, dragged.
 *
 *  Pointed: offset perpendicular to travel, scaled by how much of the stroke is
 *  a pull. `MIN` keeps an upstroke a hairline rather than nothing, which is
 *  what a real tine does.
 */
export function sweep(rawStroke: Stroke, pen: Pen, xHeight: number): string {
  const stroke = smooth(rawStroke);
  const half = pen.mode === 'broad'
    ? (xHeight / pen.nibWidths) / 2
    : (xHeight / 14) / 2;                    // pointed: the widest a shade gets
  const rad = (pen.angle * Math.PI) / 180;
  const MIN = 0.16;                          // hairline, as a fraction of `half`

  const left: Pt[] = [];
  const right: Pt[] = [];

  stroke.forEach(([x, y], i) => {
    let dx: number, dy: number;
    if (pen.mode === 'broad') {
      // Constant vector: the nib never rotates in the hand.
      dx = Math.cos(-rad) * half;
      dy = Math.sin(-rad) * half;
    } else {
      const p = stroke[Math.max(0, i - 1)];
      const n = stroke[Math.min(stroke.length - 1, i + 1)];
      const tx = n[0] - p[0];
      const ty = n[1] - p[1];
      const len = Math.hypot(tx, ty) || 1;
      // How much of this movement is a pull downward: 1 straight down, 0 up.
      const pull = Math.max(0, ty / len);
      const w = half * (MIN + (1 - MIN) * pull);
      dx = (-ty / len) * w;
      dy = (tx / len) * w;
    }
    left.push([x + dx, y + dy]);
    right.push([x - dx, y - dy]);
  });

  const pts = [...left, ...right.reverse()];
  return `M${pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' L')} Z`;
}
