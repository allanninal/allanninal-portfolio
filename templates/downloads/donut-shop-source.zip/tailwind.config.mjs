/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Fredoka', 'system-ui', 'sans-serif'],
        body: ['Nunito Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        'donut-pink':    '#D6265B',
        'donut-sky':     '#0E7AC4',
        'donut-cream':   '#FFF8F0',
        'donut-sugar':   '#FFE4CC',
        'donut-sprinkle-yellow': '#F5C842',
        'donut-sprinkle-mint':   '#4ABFA0',
        'donut-sprinkle-purple': '#9B6FD4',
      },
    },
  },
  plugins: [],
};
