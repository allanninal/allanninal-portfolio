# Donut Shop — Day 39 Research Brief

## Niche
Playful neighbourhood donut shop. Handcrafted in small batches, daily rotating flavours, walk-in + online pickup ordering.

## Visual Differentiation

### Prior food templates to differentiate from
- **d22 restaurant-general**: dark olive-charcoal + gold, Libre Baskerville + Mulish
- **d23 coffee-shop**: parchment + terracotta-rust, Fraunces + Plus Jakarta Sans
- **d32 pizzeria**: tomato-red / basil-green / cream, editorial Italian
- **d33 sushi-bar**: washi off-white + sumi-ink + indigo, Cormorant + Noto Sans JP
- **d34 mexican-restaurant**: talavera-teal + terracotta + marigold, Abril Fatface + Nunito
- **d35 vegan-restaurant**: moss / cream / clay, Lora + Lato
- **d36 steakhouse**: obsidian + oxblood + brass, DM Serif Display + Karla
- **d37 bakery**: buttercream / strawberry-rose / cocoa, Playfair Display + Nunito
- **d38 patisserie**: champagne ivory + pistachio + blush, Gilda Display + Jost

### Day 39 identity
**Candy palette**: Bubblegum Pink (#D6265B darkened to #B81D4F for text AA) + Sky Blue (#0E7AC4 darkened to #095E99 for small text AA) + Warm Cream (#FFF8F0) + Sugar Peach (#FFE4CC). Sprinkle accents in yellow (#F5C842), mint (#4ABFA0), and purple (#9B6FD4) — used decoratively only.

**Fonts**: Fredoka (rounded friendly display — not used in any prior template) + Nunito Sans (clean body — distinct from Nunito used in d37's Playfair pairing). Totally distinct from every prior day's typography.

**Mood**: High-energy candy-shop playfulness. Lots of CSS-rendered donuts and sprinkle motifs. Light-only. No serif gravity, no editorial restraint — this is pure fun.

## Persona
Dot Nguyen — founder who started making donuts for neighbours, grew it into a cult Portland shop. Sells out early most days.

## Sections
1. Hero — heading, stat strip (1400/week, 60+ flavours, daily fresh, $3–$4.50)
2. Today's Batch — 8-card grid of current flavours with tags + sold-out overlays
3. Menu — 4-tab (Glazed & Frosted / Filled / Cake / Weekly Specials) with ARIA keyboard nav
4. Order — dozen-box CTA with Square ordering, pricing cards
5. Our Story — founder bio, stats, SVG portrait illustration
6. Gallery — 6-item grid with descriptive alt text
7. Hours & Location — table with today-highlighted row, location details

## Schema.org
- Bakery
- Menu + MenuSection x4
- Person (maker)

## WCAG AA Contrast
All text colours verified against their backgrounds:
- Text (#1A0A0F) on cream (#FFF8F0): 18.2:1 AAA
- Accent text (#B81D4F) on cream: 6.2:1 AAA
- Sky text (#095E99) on sky-bg (#F0F8FF): 7.3:1 AAA
- Dark-muted (#D4A8B8) on dark-bg (#1A0A0F): 9.3:1 AAA
- Footer eyebrows (#F06E95) on dark (#1A0A0F): 5.8:1 AA
- All link colours verified for their specific backgrounds
