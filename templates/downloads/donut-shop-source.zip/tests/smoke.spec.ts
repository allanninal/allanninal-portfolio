import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Dot's Donuts/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero heading contains donut/shop reference', async ({ page }) => {
  await page.goto('/');
  const heading = await page.locator('#hero-heading').textContent();
  expect(heading?.toLowerCase()).toMatch(/glazed|donut|good/i);
});

test("today's batch section is visible", async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#todays-batch')).toBeVisible();
});

test("today's batch heading is present", async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#batch-heading')).toBeVisible();
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu tabs exist and are interactive', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  const filledTab = page.locator('[role="tab"]', { hasText: /filled/i });
  await filledTab.click();
  expect(await filledTab.getAttribute('aria-selected')).toBe('true');

  const filledPanel = page.locator('[data-panel="filled"]');
  await expect(filledPanel).toBeVisible();
});

test('order section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order')).toBeVisible();
});

test('order heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order-heading')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('story heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story-heading')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('gallery heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery-heading')).toBeVisible();
});

test('hours section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('hours heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours-heading')).toBeVisible();
});

test("shop name appears in page", async ({ page }) => {
  await page.goto('/');
  const content = await page.content();
  expect(content).toContain("Dot's Donuts");
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('a[href="#main-content"]');
  await expect(skipLink).toBeAttached();
});

test('navigation has accessible label', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('footer nav has accessible label', async ({ page }) => {
  await page.goto('/');
  const footerNav = page.locator('nav[aria-label="Footer navigation"]');
  await expect(footerNav).toBeVisible();
});

test('order CTA button is present in header', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('header a[href*="order"]').first();
  await expect(cta).toBeAttached();
});
