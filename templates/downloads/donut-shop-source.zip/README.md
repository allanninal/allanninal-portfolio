# Dot's Donuts — Donut Shop Template

**Day 39 of the [365 Astro Templates](https://templates.allanninal.dev) roadmap.**

A playful, candy-coloured donut shop template built with Astro + Tailwind CSS. Features a daily rotating flavour board with "today's batch" and sold-out indicators, a 4-tab accessible menu, dozen-box order CTA, founder story, photo gallery, and hours/location — all in a bubblegum-pink/sky-blue palette that's visually distinct from every prior food template.

[Live Demo](https://templates.allanninal.dev/donut-shop/) &middot; [All 365 Templates](https://templates.allanninal.dev)

---

## Features

- **Today's Batch** — 8-card grid of current flavours with Classic / Seasonal / Vegan / New / Fan Fave / Sold Out tags
- **4-tab Menu** — Glazed & Frosted / Filled Donuts / Cake Donuts / Weekly Specials with full ARIA keyboard navigation (arrow keys + Home/End)
- **Dozen-Box Order CTA** — Square ordering integration placeholder, half-dozen + full dozen pricing
- **Founder Story** — SVG illustration, bio paragraphs, stat grid
- **Gallery** — 6-item grid with descriptive alt text on every tile
- **Hours & Location** — table with today's row highlighted, full address, phone, email, Google Maps link
- **schema.org Bakery + Menu + Person JSON-LD** for rich search results
- **WCAG 2.1 AA** across all colour combinations (verified with axe-core)
- **Lighthouse 100** across Performance / Accessibility / Best Practices / SEO

## Tech stack

| Tool | Version |
|------|---------|
| Astro | ^4.16 |
| Tailwind CSS | ^3.4 |
| Fredoka (display) | @fontsource |
| Nunito Sans (body) | @fontsource |

## Getting started

```bash
npm install
npm run dev
```

Copy `.env.example` to `.env` and adjust:

```env
PUBLIC_SITE_URL=https://your-domain.com
PUBLIC_BASE_PATH=/
PUBLIC_TEMPLATE_HUB_URL=   # leave blank — Allan's deploy only
PUBLIC_AUTHOR_DONATE_URL=https://ko-fi.com/allanninal
```

## Deploy to GitHub Pages

```bash
PUBLIC_BASE_PATH=/your-repo-name/ npm run build
```

## License

MIT — free to use, modify, and deploy. Attribution appreciated but not required.

---

Built by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · Support on [Ko-fi](https://ko-fi.com/allanninal)
