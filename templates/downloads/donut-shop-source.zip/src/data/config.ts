export const shop = {
  name: "Dot's Donuts",
  tagline: "Freshly glazed. Ridiculously good.",
  shortTagline: "Handcrafted donuts baked in small batches, all day long.",
  description:
    "Dot's Donuts is a playful neighbourhood donut shop in Portland, Oregon. We hand-craft every ring, twist, and filled donut in small batches throughout the day — so they're always fresh. Stop in for today's batch, build your own dozen, or order online for pickup.",
  address: "742 NW Donut Row, Portland, OR 97209",
  phone: "+1 (503) 555-0184",
  email: "hello@dotsdonuts.com",
  orderUrl: "#order",
  instagram: "https://instagram.com/dotsdonuts",
  facebook: "https://facebook.com/dotsdonuts",
  tiktok: "https://tiktok.com/@dotsdonuts",
  estYear: "2019",
  mapsUrl: "https://maps.google.com/?q=742+NW+Donut+Row+Portland+OR",
};

export const hours = [
  { day: "Monday",    open: "7:00 AM – 2:00 PM",  note: "" },
  { day: "Tuesday",   open: "7:00 AM – 2:00 PM",  note: "" },
  { day: "Wednesday", open: "7:00 AM – 2:00 PM",  note: "" },
  { day: "Thursday",  open: "7:00 AM – 2:00 PM",  note: "" },
  { day: "Friday",    open: "7:00 AM – 3:00 PM",  note: "Late Friday batch at 11 AM" },
  { day: "Saturday",  open: "8:00 AM – 4:00 PM",  note: "Weekend specials drop at 9 AM" },
  { day: "Sunday",    open: "8:00 AM – 1:00 PM",  note: "Sells out early — come before noon!" },
];

export type DonutTag = "classic" | "seasonal" | "vegan" | "gluten-free" | "sold-out" | "new" | "fan-fave";

export type DonutItem = {
  id: string;
  name: string;
  description: string;
  price: string;
  tags?: DonutTag[];
  note?: string;
  soldOut?: boolean;
};

export type DonutCategory = {
  id: string;
  label: string;
  emoji: string;
  description: string;
  items: DonutItem[];
};

export const todaysBatch: DonutItem[] = [
  {
    id: "strawberry-sprinkle",
    name: "Strawberry Sprinkle",
    description: "Strawberry glaze, rainbow nonpareils, a hint of vanilla. Our #1 seller — every single day.",
    price: "$3.50",
    tags: ["classic", "fan-fave"],
  },
  {
    id: "maple-bacon-twist",
    name: "Maple Bacon Twist",
    description: "Yeast-raised twist, pure maple glaze, house-cured candied bacon crumble. Sweet-salty perfection.",
    price: "$4.50",
    tags: ["classic", "fan-fave"],
  },
  {
    id: "blueberry-birthday-cake",
    name: "Blueberry Birthday Cake",
    description: "Blueberry-glazed ring loaded with birthday cake sprinkles and a vanilla cream swirl. Tastes like a party.",
    price: "$4.00",
    tags: ["new", "seasonal"],
  },
  {
    id: "matcha-coconut",
    name: "Matcha Coconut",
    description: "Ceremonial grade matcha glaze, toasted coconut flakes, white chocolate drizzle. Bright and earthy.",
    price: "$4.25",
    tags: ["seasonal", "vegan"],
  },
  {
    id: "lemon-poppy",
    name: "Lemon Poppy",
    description: "Lemon curd-filled, poppy seed crumble, bright yellow glaze. Sunday special sold every day this week.",
    price: "$4.00",
    tags: ["seasonal"],
  },
  {
    id: "boston-cream",
    name: "Boston Cream",
    description: "Vanilla pastry cream-filled, dark chocolate ganache, one little candle on top (kidding — but we'd put one on there).",
    price: "$4.25",
    tags: ["classic"],
  },
  {
    id: "cinnamon-sugar",
    name: "Cinnamon Sugar Old Fashioned",
    description: "Dense, crisp-edged cake donut tossed in cinnamon sugar. The original. The legend. The one your grandpa eats.",
    price: "$3.00",
    tags: ["classic"],
  },
  {
    id: "hot-honey-glazed",
    name: "Hot Honey Glazed",
    description: "Warm wildflower honey glaze, pinch of Calabrian chilli, finishing flake salt. Surprisingly addictive.",
    price: "$4.00",
    tags: ["new"],
  },
];

export const menu: DonutCategory[] = [
  {
    id: "glazed",
    label: "Glazed & Frosted",
    emoji: "O",
    description: "Yeast-raised rings in our signature glazes. Light, pillowy, and glazed while still warm.",
    items: [
      {
        id: "classic-glaze",
        name: "Classic Glaze",
        description: "Our foundational ring: vanilla-tinged glaze, impossibly soft interior. The benchmark.",
        price: "$2.75",
        tags: ["classic"],
      },
      {
        id: "strawberry-sprinkle-menu",
        name: "Strawberry Sprinkle",
        description: "Pink strawberry glaze, rainbow nonpareils. The most photographed donut on the block.",
        price: "$3.50",
        tags: ["classic", "fan-fave"],
      },
      {
        id: "chocolate-frosted",
        name: "Chocolate Frosted",
        description: "Rich cocoa frosting, no sprinkles required (though we'll add them if you ask nicely).",
        price: "$3.25",
        tags: ["classic"],
      },
      {
        id: "maple-bar",
        name: "Maple Bar",
        description: "Pillow-soft bar, pure Grade A maple glaze. A Portland essential.",
        price: "$3.50",
        tags: ["classic", "fan-fave"],
      },
      {
        id: "blueberry-glazed",
        name: "Blueberry Glazed",
        description: "Fresh blueberry glaze from Oregon-grown berries. Floral and fruity.",
        price: "$3.75",
        tags: ["seasonal"],
      },
      {
        id: "matcha-coconut-menu",
        name: "Matcha Coconut",
        description: "Ceremonial matcha glaze, toasted coconut. Vegan-friendly.",
        price: "$4.25",
        tags: ["seasonal", "vegan"],
      },
    ],
  },
  {
    id: "filled",
    label: "Filled Donuts",
    emoji: "•",
    description: "Pillowy rounds stuffed to the brim. Every one is filled to order at the counter — no sad hollow bites.",
    items: [
      {
        id: "boston-cream-menu",
        name: "Boston Cream",
        description: "Vanilla custard, dark chocolate ganache top. A classic for a reason.",
        price: "$4.25",
        tags: ["classic"],
      },
      {
        id: "lemon-curd",
        name: "Lemon Curd",
        description: "House-made lemon curd, powdered sugar, lemon zest. Tart and sunshine-bright.",
        price: "$4.00",
        tags: ["classic"],
      },
      {
        id: "strawberry-jam",
        name: "Strawberry Jam",
        description: "Oregon strawberry jam, vanilla glaze, sprinkle finish. A childhood classic, upgraded.",
        price: "$3.75",
        tags: ["classic"],
      },
      {
        id: "nutella-hazelnut",
        name: "Nutella Hazelnut",
        description: "Loaded with Nutella, dusted in crushed hazelnuts and powdered sugar. Pure joy.",
        price: "$4.50",
        tags: ["fan-fave"],
      },
      {
        id: "pumpkin-spice-filled",
        name: "Pumpkin Spice Cream",
        description: "Spiced pumpkin pastry cream, cinnamon sugar exterior. Fall only — people literally cry when it's gone.",
        price: "$4.50",
        tags: ["seasonal", "sold-out"],
        soldOut: true,
        note: "Back in September",
      },
    ],
  },
  {
    id: "cake",
    label: "Cake Donuts",
    emoji: "◯",
    description: "Dense, tender, old-fashioned cake-style. Crisp edges, crumbly interior — the underrated hero of the donut world.",
    items: [
      {
        id: "cinnamon-sugar-menu",
        name: "Cinnamon Sugar",
        description: "Tossed hot in cinnamon sugar. The original. You cannot go wrong.",
        price: "$3.00",
        tags: ["classic"],
      },
      {
        id: "chocolate-cake",
        name: "Chocolate Cake",
        description: "Deep cocoa cake, chocolate glaze, optional sprinkles. Intensely satisfying.",
        price: "$3.25",
        tags: ["classic"],
      },
      {
        id: "buttermilk-old-fashioned",
        name: "Buttermilk Old Fashioned",
        description: "Tangy buttermilk batter, plain glaze, ruffled edges. The purists' pick.",
        price: "$3.00",
        tags: ["classic"],
      },
      {
        id: "funfetti",
        name: "Funfetti Cake",
        description: "Birthday cake batter with sprinkles baked in. Rainbow frosting on top. We believe every day is a birthday.",
        price: "$3.75",
        tags: ["fan-fave"],
      },
      {
        id: "apple-cider",
        name: "Apple Cider",
        description: "Reduced apple cider in the batter, cardamom sugar exterior. Autumn in every bite.",
        price: "$3.50",
        tags: ["seasonal"],
      },
    ],
  },
  {
    id: "specials",
    label: "Weekly Specials",
    emoji: "★",
    description: "Rotating specials that change every Monday. Follow us on Instagram to see what drops this week.",
    items: [
      {
        id: "hot-honey-menu",
        name: "Hot Honey Glazed",
        description: "Wildflower honey, Calabrian chilli, finishing salt. This week's special — gone Saturday.",
        price: "$4.00",
        tags: ["new"],
      },
      {
        id: "birthday-cake-menu",
        name: "Blueberry Birthday Cake",
        description: "Blueberry glaze, birthday sprinkles, vanilla cream drizzle. New this week.",
        price: "$4.00",
        tags: ["new", "seasonal"],
      },
      {
        id: "maple-bacon-menu",
        name: "Maple Bacon Twist",
        description: "Maple-glazed twist, house candied bacon crumble. A fan-favourite returning by popular demand.",
        price: "$4.50",
        tags: ["fan-fave"],
      },
    ],
  },
];

export const dozenBox = {
  headline: "Build Your Dozen",
  description:
    "Pick any 12 donuts from today's batch. Mix, match, and stack the box any way you like. Order online for same-day pickup (pre-orders close at noon).",
  price: "from $36",
  halfDozen: "from $18",
  orderNote: "Online orders close at 12:00 PM for same-day pickup. Walk-ins always welcome.",
  orderPlatform: "Square",
  orderUrl: "https://squareup.com/store/dotsdonuts",
};

export const story = {
  headline: "Born from a Saturday Experiment",
  founderName: "Dot Nguyen",
  founderTitle: "Founder & Head Donut Maker",
  bio: [
    "Dot started making donuts on Saturday mornings for her neighbours in 2017, armed with a secondhand fryer and a notebook full of ideas. By the fourth Saturday, there was a line around the block.",
    "In 2019, she opened the shop at 742 NW Donut Row — a tiny corner spot with a pink awning, a hand-lettered menu board, and room for exactly nine bar stools. She's been sold out by 1 PM most days since.",
    "Dot's philosophy: use real butter, real fruit, real cream — and make every donut something you'd genuinely be excited to eat. No tricks, no shortcuts, no sad day-old donuts.",
  ],
  stats: [
    { label: "Opened",           value: "2019" },
    { label: "Donuts / week",    value: "~1,400" },
    { label: "Flavours in rotation", value: "60+" },
    { label: "Seats",            value: "9 (intentionally)" },
  ],
};

export const gallery = [
  { alt: "A tray of strawberry-glazed donuts topped with rainbow sprinkles on a white marble counter", label: "Strawberry Sprinkle batch", src: "strawberry" },
  { alt: "A maple bacon twist donut on kraft paper with candied bacon crumble scattered around it", label: "Maple Bacon Twist", src: "maple-bacon" },
  { alt: "An open dozen box filled with a colourful mix of glazed, filled, and cake donuts", label: "Mixed Dozen", src: "dozen" },
  { alt: "Dot Nguyen piping lemon curd into fresh donuts behind the counter, smiling", label: "Filling station", src: "filling" },
  { alt: "Close-up of a matcha coconut donut with toasted coconut flakes on a green-glazed ring", label: "Matcha Coconut", src: "matcha" },
  { alt: "The exterior of Dot's Donuts with its pink awning and hand-lettered sign at morning light", label: "742 NW Donut Row", src: "exterior" },
];

export const maker = {
  name: 'Dot',
  linkedin: "https://www.linkedin.com/in/allanninal/",
  twitter: "https://twitter.com/allanninal",
  github: "https://github.com/allanninal",
  email: "hello@dot.com",
  kofi: "https://ko-fi.com/allanninal",
};

export const site = {
  title: "Dot's Donuts — Portland's Favourite Donut Shop",
  description:
    "Handcrafted donuts made fresh in small batches all day long. Daily flavours, dozen-box orders, and rotating specials. Find us at 742 NW Donut Row, Portland, OR.",
  url: "https://www.allanninal.dev/templates/donut-shop/",
  ogImage: "/og-image.png",
  language: "en",
};
