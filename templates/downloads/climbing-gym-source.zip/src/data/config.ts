export const gym = {
  name:        'Summit Climb Boulder',
  tagline:     'Find your line.',
  description: 'Boulder\'s premier indoor climbing facility — 150+ routes across bouldering, top-rope, and lead walls. Route grades V0 to V12 and 5.5 to 5.14. Day passes, punch cards, monthly memberships, and certified instruction for all levels.',
  phone:       '(720) 555-0218',
  email:       'hello@summitclimbboulder.com',
  address:     '2801 Wilderness Pl',
  city:        'Boulder',
  state:       'CO',
  zip:         '80301',
  instagram:   'https://instagram.com/summitclimbboulder',
  facebook:    'https://facebook.com/summitclimbboulder',
  youtube:     'https://youtube.com/@summitclimbboulder',
  bookUrl:     'https://app.summitclimbboulder.com/book',
  membershipUrl: 'https://app.summitclimbboulder.com/membership',
  headCoach: {
    name:  'Ryan Torres',
    title: 'Head Coach & Head Route Setter',
    certs: ['USAC Level 2 Certified Coach', 'Single Pitch Instructor (SPI)', '12 Years Teaching'],
  },
  makerBio: {
    name:     'Summit Climb Boulder',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Summit Climb Boulder — Indoor Climbing Gym in Boulder CO',
  description:   '150+ routes from V0 to V12 and 5.5 to 5.14. Bouldering, top-rope, lead, auto-belay and certified instruction. Day passes from $22. Boulder, CO.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
