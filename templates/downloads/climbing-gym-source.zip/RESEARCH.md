# Day 66 — Climbing Gym: Niche Research

## Slug
`climbing-gym`

## Visual differentiation from Days 60–65 (Sprint 3 fitness siblings)

### Taken palettes & fonts — Sprint 3 days 60–65
| Day | Template | Palette | Fonts | Default |
|-----|----------|---------|-------|---------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 | Dark |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira | Dark |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Red #EF4444 + Gold #C09030 | Black Ops One + Rubik | Dark |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 + Clay #A05540 | EB Garamond + Quicksand | Light |
| 64 | pilates-studio | Cool Stone #F5F4F1 + Deep Ocean Slate #2B5E7B | Prata + Fira Sans | Light |
| 65 | dance-studio | Deep Stage Ink #0C0E18 + Rose Crimson #C4315A + Champagne Gold #D4A054 | Josefin Sans + Nunito Sans | Dark |

### Day 66 distinct visual register

**LIGHT-DEFAULT template** — outdoor-adventure athletic aesthetic, distinct from all 65 prior days:
- NOT the dark industrial palettes of days 60–62, 65
- NOT yoga's warm earthy linen or pilates' cool stone precision
- NOT dance's theatrical velvet-and-crimson
- Instead: **chalk white + summit forest green + route ochre** — the world of rock climbing, chalk bags, colored holds, and mountain air

**Palette: Chalk & Summit Forest (Light default)**
- Background: `#F6F5F2` (Chalk — very warm off-white, like dried climbing chalk)
- Background alt: `#EDECE8` (warm light gray for section alternation)
- Surface: `#FFFFFF` (card surfaces)
- Surface 2: `#F0EEE9` (slightly warm tinted surface)
- Accent/CTA: `#1B6E3F` (Summit Forest — deep forest green; white on it = 5.62:1 AA ✓; completely distinct from all prior Sprint 3 accents)
- Accent hover: `#155A31`
- Accent light: `rgba(27, 110, 63, 0.10)`
- On-accent: `#FFFFFF`
- Gold/Eyebrow: `#6B4A1F` (Route Ochre — dark amber, like climbing chalk bags and tape; 7.22:1 AAA on chalk bg ✓)
- Text: `#1C1C19` (warm near-black, 15.6:1 AAA ✓)
- Text muted: `#5C5A52` (warm gray, 6.33:1 AA ✓)
- Text faint: `#636058` (5.25:1 on white AA ✓)
- Border: `#DDD9D0`
- Border strong: `#B5B0A5`
- Border accent: `#C3DFD0` (light green tint)

**Fonts: Barlow Condensed (display) + DM Sans (body)** — FIRST USE of both in the 365 library
- Barlow Condensed: Tall, athletic condensed sans-serif. Widely used in outdoor adventure and sport climbing brands. Feels like route names on a route board, strong gym signage, expedition gear labels. Completely distinct from all prior Sprint 3 display fonts (Anton is more compressed, Russo One is wider, Black Ops One is stencil, EB Garamond is serif, Prata is display serif, Josefin Sans is geometric tall).
- DM Sans: Clean, rounded geometric sans with excellent readability. More refined than Fira Sans, less rounded than Quicksand, less technical than Saira. Feels approachable and modern — perfect for a Boulder climbing gym with mixed audiences from absolute beginners to competition athletes.

**Visual distinctiveness:**
- Light palette (chalk bg) vs dark backgrounds of days 60, 61, 62, 65
- Forest green accent vs electric orange (60), volt yellow (61), championship red (62), rose crimson (65)
- Dark earthy ochre eyebrow vs champagne gold (65), dusty sage (63), ocean slate (64)
- Condensed athletic display font vs all prior typography choices
- Only template in the 365 library with a forest/mountain outdoor aesthetic

## Persona & Business Model

**Gym**: Summit Climb Boulder
**Tagline**: Find your line.
**Location**: 2801 Wilderness Pl, Boulder, CO 80301
**Founded**: 2018

**Audience**: All levels from absolute beginners (Learn to Climb clinic) to competition athletes (Youth Team, Advanced Movement Lab). Boulder's climbing community is unusually sophisticated — includes University of Colorado athletes, outdoor industry professionals, and weekend warriors who also climb outside at Eldorado Canyon and Rifle.

**Unique differentiator from Sprint 3 siblings**:
- Yoga/Pilates: mind-body wellness modalities
- Gym/CrossFit/Boxing: traditional fitness formats
- Dance: performing arts education
- Climbing gym: adventure sport with technical grade progression system (V-scale / YDS), a completely distinct culture

**Key sections unique to climbing gym**:
1. **Route Grades section** — visual display of bouldering (V0–V12) and roped (5.5–5.14) grade systems with color-coded grade bands, explaining what each level means. No other Sprint 3 template has anything like this.
2. **Day passes vs membership** pricing — climbing gyms have specific pass structures (day pass, punch card, unlimited monthly) distinct from fitness gym memberships
3. **Lead climbing certification** — a formal process that distinguishes climbing from other gym sports

**Disciplines / Walls**:
- Bouldering walls (3 caves, V0–V12)
- Top-rope walls (40ft, 5.5–5.12, plus auto-belay lanes)
- Lead walls (40ft, 5.9–5.14)

**Coaches** (3):
- Ryan Torres — Head Coach & Head Route Setter (USAC L2, SPI, 12yr teaching)
- Mei Chen — Youth Program Director (USAC L2 Youth, WFR, 9yr coaching)
- Jake Hartwell — Movement & Technique Coach (USAC L1, Movement Science CU Boulder, former national comp climber)

**Programs** (5):
1. Learn to Climb (2hr intro, all levels, belay card included)
2. Lead Climbing Certification (4-week course)
3. Youth Climbing Team (ages 8–17, competitive)
4. Technique Workshop (1.5hr, V2+/5.10+)
5. Advanced Movement Lab (2hr, V5+/5.12+)

**Pricing** (3 tiers):
- Day Pass: $22/visit
- 10-Punch Card: $180 (no expiry, $18/visit effective)
- Monthly Unlimited: $75/month

## Color Contrast Verification (WCAG AA)

All critical color combinations verified at ≥ 4.5:1 for normal text:

| Foreground | Background | Ratio | Use |
|------------|------------|-------|-----|
| `#1C1C19` (text) | `#F6F5F2` (chalk bg) | 15.6:1 AAA ✓ | Body text |
| `#5C5A52` (muted) | `#F6F5F2` (chalk bg) | 6.33:1 AA ✓ | Secondary text |
| `#5C5A52` (muted) | `#FFFFFF` (surface) | 6.65:1 AA ✓ | Card text |
| `#6B4A1F` (ochre) | `#F6F5F2` (chalk bg) | 7.22:1 AAA ✓ | Eyebrow labels |
| `#6B4A1F` (ochre) | `#FFFFFF` (surface) | 7.57:1 AAA ✓ | Card eyebrows |
| `#1B6E3F` (forest) | `#FFFFFF` (surface) | 5.62:1 AA ✓ | Link text, class CTA |
| `#FFFFFF` (white) | `#1B6E3F` (forest) | 5.62:1 AA ✓ | Button text, stat labels |
| `#636058` (faint) | `#FFFFFF` (surface) | 5.87:1 AA ✓ | Count labels, faint text |
| `#1C1C19` (text) | `#EDECE8` (bg-alt) | ~13:1 AAA ✓ | Alt section text |
| `#FFFFFF` | `#111410` (footer) | ~17:1 AAA ✓ | Footer text |
