# Day 66 — Climbing Gym Template

**Summit Climb Boulder** — an indoor climbing gym landing page with route grades, day passes, class schedule, and certified coaching bios.

Live demo: https://example.com/

Part of the [365 Astro Templates](https://example.com) project by [Allan Niñal](#).

## Features

- **Route Grades section** — visual V-scale and YDS grade display with color-coded difficulty bands (unique to this template)
- **Day passes & membership pricing** — 3-tier: day pass, punch card, monthly unlimited
- **Class schedule** with filter buttons (Beginner, Lead, Youth, Technique, Advanced)
- **5 coached programs** — Learn to Climb, Lead Certification, Youth Team, Technique Workshop, Advanced Movement Lab
- **3 coach profiles** with USAC credentials and bios
- **Testimonials** (4) with star ratings
- **FAQ** with accordion (8 questions)
- **Contact form** + gym hours
- **Light-default palette** — Chalk #F6F5F2 + Summit Forest #1B6E3F + Route Ochre #6B4A1F
- **Fonts** — Barlow Condensed (display) + DM Sans (body) — first use of both in the 365 library
- WCAG AA color contrast throughout
- Schema.org: SportsActivityLocation + LocalBusiness + Person + Service + FAQPage
- Responsive (mobile-first), sticky header, mobile nav
- Analytics + AdSense hub-gated via `AnalyticsHead`
- MIT license — free to use and modify

## Stack

- [Astro](https://astro.build) 4.x — static output
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [@fontsource/barlow-condensed](https://fontsource.org) + [@fontsource/dm-sans](https://fontsource.org)
- Playwright (a11y + links + Lighthouse tests)

## Quick start

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Environment variables

Copy `.env.example` to `.env.local`. All vars are optional for local development.

| Variable | Purpose |
|----------|---------|
| `PUBLIC_TEMPLATE_HUB_URL` | Enables the TemplateInfo download bar on live deploy |
| `PUBLIC_SHOP_URL` | Points "Get Pro" link to the shop |
| `PUBLIC_EDITION` | Set to `pro` to preview Pro edition |
| `PUBLIC_SITE_URL` | Astro site URL (defaults to example.com) |
| `PUBLIC_BASE_PATH` | Base path (defaults to `/climbing-gym/`) |

## License

MIT — see [LICENSE](./LICENSE)
