/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Barlow Condensed"', 'system-ui', 'sans-serif'],
        body:    ['"DM Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        chalk: {
          50:  '#FFFFFF',
          100: '#F6F5F2',
          200: '#EDECE8',
          300: '#E4E2DC',
          400: '#DDD9D0',
          500: '#B5B0A5',
          600: '#8A8478',
          700: '#5C5A52',
          800: '#3A3830',
          900: '#1C1C19',
        },
        forest: {
          50:  '#EAF4EE',
          100: '#C3DFD0',
          200: '#8FC4A8',
          300: '#5BA880',
          400: '#2D9E5B',
          500: '#1B6E3F',
          600: '#155A31',
          700: '#0E4524',
          800: '#083018',
          900: '#031A0C',
        },
        ochre: {
          50:  '#FDF5EB',
          100: '#F7E4C4',
          200: '#ECC88A',
          300: '#DFA952',
          400: '#C28030',
          500: '#8B6332',
          600: '#6B4A1F',
          700: '#4A3212',
          800: '#2E1E09',
          900: '#150D03',
        },
      },
    },
  },
  plugins: [],
};
