import { test, expect } from '@playwright/test';

const secs = (s: string) => {
  const t = s.trim();
  const n = Number(t.replace(/[^0-9]/g, ''));
  return /sec/.test(t) ? n : n * 60;
};

test.describe('Bramble & Rind — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Bramble & Rind/);
    await expect(page.locator('h1')).toContainText('edible');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The shot clock ──────────────────────────────────────────────────────
  test('the clock is an ordered list of articles, one per dish', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#clock ol.clock > li').count()).toBe(6);
    expect(await page.locator('#clock article.dish').count()).toBe(6);
  });

  // The day is built backwards from the shortest window, so the page must be too.
  test('dishes run longest window first, shortest last', async ({ page }) => {
    await page.goto('/');
    const windows = (await page.locator('#clock .window').allTextContents()).map(secs);
    expect(windows.length).toBe(6);
    for (let i = 1; i < windows.length; i++) {
      expect(windows[i]).toBeLessThanOrEqual(windows[i - 1]);
    }
    // And the hero must name the real shortest one.
    await expect(page.locator('h1 ~ p.figure-lead, .figure-lead').first())
      .toContainText(`${windows[windows.length - 1]} sec`);
  });

  test('every dish states what ends it and what is done about it', async ({ page }) => {
    await page.goto('/');
    for (const d of await page.locator('#clock article.dish').all()) {
      const dts = await d.locator('.dish-ends dt').allTextContents();
      expect(dts.map((s) => s.trim())).toEqual(['What ends it', 'What we do']);
      for (const dd of await d.locator('.dish-ends dd').allTextContents()) {
        expect(dd.trim().length).toBeGreaterThan(30);
      }
    }
  });

  // The bar duplicates information already given in words and figures.
  test('the window bars are hidden from assistive tech', async ({ page }) => {
    await page.goto('/');
    const bars = page.locator('#clock .window-bar');
    expect(await bars.count()).toBe(6);
    for (const b of await bars.all()) {
      await expect(b).toHaveAttribute('aria-hidden', 'true');
    }
  });

  test('every dish image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#clock img').evaluateAll((els) =>
      els.map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })),
    );
    expect(imgs.length).toBe(6);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.w).toBeTruthy();
      expect(i.h).toBeTruthy();
    }
  });

  test('all six dish images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')),
    );
    expect(broken).toEqual([]);
  });

  // ── The arithmetic ──────────────────────────────────────────────────────
  // The headline number must equal the day divided by the summed steps, and it
  // must agree with the rates table two sections below.
  test('throughput is derived from the steps and agrees with the rates table', async ({ page }) => {
    await page.goto('/');
    const mins = (await page.locator('#arithmetic .arith .m').allTextContents())
      .map((s) => Number(s.replace(/[^0-9]/g, '')));
    const perDish = mins.reduce((a, b) => a + b, 0);
    const lead = await page.locator('#arithmetic .figure-lead').textContent();
    const m = lead!.match(/(\d+) minutes a dish\. A (\d+)-hour day holds (\d+)/)!;
    expect(Number(m[1])).toBe(perDish);
    expect(Number(m[3])).toBe(Math.floor((Number(m[2]) * 60) / perDish));
    await expect(page.locator('#arithmetic h2')).toContainText(`We can do ${m[3]}`);
    // The claim the rates table makes must be the same number.
    await expect(page.locator('#rates')).toContainText(`Up to ${m[3]} dishes`);
  });

  // ── The myths ───────────────────────────────────────────────────────────
  test('the myths section corrects rather than repeats the folklore', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('#myths');
    await expect(s).toContainText('Glue instead of milk');
    await expect(s).toContainText(/Milk\./);
    expect(await s.locator('tbody tr').count()).toBe(6);
    // And it must own the cases where the folklore is true.
    await expect(s).toContainText(/Sometimes true/);
    await expect(s).toContainText(/must leave it edible/);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 94.
  test('no trace of the day-94 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['auberge', 'savannah', 'oxblood', 'imbue', 'cousine', 'manicure']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro shoot day plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/shoot-day/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
