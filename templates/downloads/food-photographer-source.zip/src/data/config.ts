// Bramble & Rind — Louisville, KY.
//
// Fifth and last photography template in this run, and a fifth axis:
// 91 what you receive, 92 who you are, 93 what you are buying,
// 94 who made it, 95 how long you have.
//
// Time is food photography's organising constraint and no other trade in this
// library has that. The shot clock is both the argument and the portfolio.

export const site = {
  name:        'Bramble & Rind',
  shortName:   'Bramble & Rind',
  title:       'Bramble & Rind — Food Photography in Louisville, KY',
  tagline:     'Everything in these pictures is edible.',
  owner:       'Thandiwe Marchetti',
  ownerRole:   'Food photographer',
  credential:  'Restaurants, producers and editorial · Louisville',
  license:     'Food photography studio, working since 2017',
  city:        'Louisville',
  state:       'KY',
  language:    'en',
  phoneDisplay: '(502) 555-0171',
  phoneHref:   '+15025550171',
  email:       'studio@brambleandrind.example',
  streetAddress: '1042 E Washington St',
  postalCode:  '40206',
  hours:       'Shoot days Tue–Thu · kitchen access from 8am',
  bookingWindow: 'Two shoot days a week. Booking six weeks out.',
  description:
    'Food photography in Louisville. The tricks you have heard about are mostly forty ' +
    'years out of date and several are illegal — the real constraint is time, and this ' +
    'page is built on how long each dish actually has.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The shot clock', href: '#clock' },
  { label: 'The arithmetic', href: '#arithmetic' },
  { label: 'What we do not do', href: '#myths' },
  { label: 'Rates',      href: '#rates' },
  { label: 'Book',       href: '#book' },
];

// ── The shot clock ────────────────────────────────────────────────────────
// `seconds` is the photogenic window from plated to unusable. The bar widths
// and every claim about ordering are computed from this array.
//
// Alt strings written from the files.

export const dishes = [
  { id: 'd01', file: 'd01.jpg', name: 'Gelato, three scoops', seconds: 90,
    ends: 'The edges go glassy, then the scoop slumps and loses its ridges.',
    doing: 'Shot last, on a chilled plate, with the light set and focus locked on a stand-in scoop. One plating, one chance.',
    alt: 'Scoops of vanilla, chocolate and berry gelato in a white bowl with fresh berries and cherries' },
  { id: 'd02', file: 'd02.jpg', name: 'Pancakes with honey', seconds: 240,
    ends: 'The honey soaks in and the highlight along the pour disappears.',
    doing: 'Poured on the take, not before it. The stack is built and lit first; the honey is the last thing that happens.',
    alt: 'A tall stack of pancakes with honey being poured over the top against a white background' },
  { id: 'd03', file: 'd03.jpg', name: 'Pizza, spinach and olive', seconds: 360,
    ends: 'The cheese sets and goes matte, and the crust stops steaming.',
    doing: 'Undercooked by two minutes so it finishes on the way to the set. Nothing is added that you could not eat.',
    alt: 'A whole pizza topped with spinach and olives on a white plate over a red gingham cloth' },
  { id: 'd04', file: 'd04.jpg', name: 'Linguine, above', seconds: 480,
    ends: 'The surface dries, the sheen goes, and the nest relaxes out of shape.',
    doing: 'Twirled onto a fork off-camera and set down as one piece. A brush of the cooking oil brings the sheen back, which is oil that was already on it.',
    alt: 'A nest of green linguine on a turquoise plate with a fork, shot from above on dark slate' },
  { id: 'd05', file: 'd05.jpg', name: 'Caprese', seconds: 900,
    ends: 'The tomato weeps and the pesto bleeds into the plate.',
    doing: 'Sliced at the set, salted after the first frame. Salting early is what makes tomato weep, so we simply do it later.',
    alt: 'Sliced tomato and mozzarella dressed with pesto on a wooden platter' },
  { id: 'd06', file: 'd06.jpg', name: 'Goulash and dumplings', seconds: 1500,
    ends: 'The sauce skins over and the dumplings go dull.',
    doing: 'The easiest thing on this page, which is why it is shot first while the light is still being trimmed.',
    alt: 'Beef goulash in a dark sauce with bread dumplings and a sprig of rosemary' },
];

export const clockNote =
  'Every dish has a window between leaving the pass and being unusable. The day is ' +
  'built backwards from the shortest one: long-window dishes go first while the light ' +
  'is still being trimmed, and the ninety-second dish is plated when everything else ' +
  'on set is already finished.';

// ── The arithmetic ────────────────────────────────────────────────────────

export const arithmetic = {
  headline: 'You want forty dishes. We can do fourteen.',
  intro:
    'This is the single most common disagreement in restaurant work, and it is arithmetic ' +
    'rather than opinion. One dish is not one photograph — it is this, every time:',
  steps: [
    { step: 'Kitchen plates it',        minutes: 7,  why: 'Two or three attempts, because the first plate is a rehearsal for everybody.' },
    { step: 'Styling to camera',        minutes: 6,  why: 'Turning the plate, moving one olive, deciding which side is the front.' },
    { step: 'Trim the light',           minutes: 7,  why: 'Every dish has a different height and a different shine. This is the part clients do not see.' },
    { step: 'Shoot',                    minutes: 5,  why: 'The actual photography. The shortest part of the process by a distance.' },
    { step: 'Reset the set',            minutes: 5,  why: 'Clear, wipe, new surface, new props. Skipping it is how the tenth dish looks like the first.' },
  ],
  dayMinutes: 420,
  closing:
    'What you get for that is forty photographs which all look like the same plate under ' +
    'the same lamp, because there was no time to move the lamp.',
};

// ── The myths ─────────────────────────────────────────────────────────────

export const myths = {
  intro:
    'The folklore is universal and almost entirely obsolete. Two things changed: advertising ' +
    'rules make misrepresenting the product itself unlawful, and digital made it cheaper to ' +
    'shoot the real thing fast than to build a fake one slowly.',
  rows: [
    { said: 'Glue instead of milk',       real: 'Milk. It photographs fine in the four minutes a cereal shot takes, and substituting the product in a product photograph is exactly what advertising rules prohibit.' },
    { said: 'Motor oil for syrup',        real: 'Syrup, poured on the take. Warmed slightly if it is a thick one, which is a thing you would do at your own table.' },
    { said: 'Shaving foam for cream',     real: 'Cream, whipped a little stiffer than you would eat and kept cold until the second before.' },
    { said: 'Cardboard between the layers', real: 'Nothing between the layers. A cake is chilled so it slices cleanly, which is what a pastry chef would tell you anyway.' },
    { said: 'A blowtorch on the meat',     real: 'Sometimes true, and legitimate — it is the same browning a pan does, done faster and more evenly. The meat is cooked and edible afterwards.' },
    { said: 'Fake steam',                  real: 'Usually true and usually fine, because steam is not the product. Hot water on a cotton ball behind the plate. Nothing is added to the food.' },
  ],
  line:
    'The rule we work to: anything done to the food must leave it edible, and the product ' +
    'in the picture must be the product. Everything else — the light, the props, the steam ' +
    'behind the plate — is staging, and staging is the job.',
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Shoot day, in our studio',   figure: '$1,850', note: 'Up to 14 dishes. Kitchen and prep are yours.' },
    { what: 'Shoot day, your kitchen',    figure: '$2,150', note: 'We bring surfaces, props and lighting. You bring the pass.' },
    { what: 'Half day',                   figure: '$1,100', note: 'Up to 6 dishes. Worth it for a seasonal refresh, not for a full menu.' },
    { what: 'Food styling, if you want it', figure: '$650', note: 'A stylist changes what is possible more than another lens does.' },
    { what: 'Licence, web and menu',      figure: 'Included', note: 'Perpetual for your own channels, menus and windows.' },
    { what: 'Licence, paid advertising',  figure: 'Quoted',  note: 'Separate, by media and term. Ask before the shoot, not after.' },
  ],
  prep: [
    'Send the dish list a week out, in the order you want them shot. We will reorder it by window and send it back.',
    'Have every garnish prepped in duplicate. The second plate is the one that gets photographed.',
    'One person from the kitchen for the whole day. Not the head chef at the pass mid-service.',
    'Tell us which dishes are on the menu next season. Shooting a dish you are about to cut is the most expensive thing on this page.',
  ],
};

export const faqs = [
  {
    q: 'Is the food really edible afterwards?',
    a: 'Yes, and it usually gets eaten. That is the rule we work to: anything done to the food leaves it edible, and the product in the picture is the product. The staging around the plate is a different question and staging is the job.',
  },
  {
    q: 'Can you shoot our whole menu in a day?',
    a: 'Not if the menu has forty dishes on it. Fourteen is what a day holds at a standard worth paying for, and the arithmetic for that is on this page rather than hidden behind a quote.',
  },
  {
    q: 'Do we need a food stylist?',
    a: 'For a menu shoot, usually not — your kitchen plates it better than a stylist would guess. For packaging or advertising, yes, and it changes what is possible more than another lens does.',
  },
  {
    q: 'What about ice cream?',
    a: 'Ninety seconds from bowl to slump. It is shot last, on a chilled plate, with the light already set and focus locked on a stand-in scoop. One plating, one chance, and we will have practised on three before the real one.',
  },
  {
    q: 'Can we use the pictures in an advert?',
    a: 'Your rate includes your own channels, menus and windows in perpetuity. Paid advertising is a separate licence by media and term — cheap to agree before the shoot and awkward to agree afterwards.',
  },
  {
    q: 'What if a dish does not photograph?',
    a: 'Some do not, and brown food in a brown sauce is the usual culprit. We will tell you on the day and suggest a different plate, a different surface or a different dish rather than spend an hour losing.',
  },
];
