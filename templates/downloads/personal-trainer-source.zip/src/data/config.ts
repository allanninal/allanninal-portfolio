export const trainer = {
  name:        'Alex Rivera',
  tagline:     'Strength. Results. Accountability.',
  description: 'Austin\'s results-driven personal trainer — NSCA-CSCS certified, specializing in body composition and athletic performance for busy professionals. 1:1 in-person, small-group, and online coaching programs.',
  phone:       '(512) 555-0194',
  email:       'hello@alexriverafitness.com',
  city:        'Austin',
  state:       'TX',
  instagram:   'https://instagram.com/alexriverafitness',
  facebook:    'https://facebook.com/alexriverafitness',
  youtube:     'https://youtube.com/@alexriverafitness',
  bookUrl:     'https://calendly.com/alexriverafitness/free-consult',
  address:     '3420 S Congress Ave',
  zip:         '78704',
  certs:       ['NSCA-CSCS', 'ACSM-CPT', 'Precision Nutrition Level 2', 'ACE Group Fitness Instructor'],
  makerBio: {
    name:     'Allan Ninal',
    url:      'https://allanninal.dev',
    linkedin: 'https://linkedin.com/in/allanninal',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'Alex Rivera Fitness | Personal Trainer Austin TX — 1:1 & Small-Group Coaching',
  description:   'Alex Rivera — NSCA-CSCS certified personal trainer in Austin TX. Specializing in body composition and athletic performance. 1:1 training, small-group coaching, and online programs. Book a free consultation.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
