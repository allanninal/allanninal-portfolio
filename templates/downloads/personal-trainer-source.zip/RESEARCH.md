# Day 68 — Personal Trainer: Niche Research

## Slug
`personal-trainer`

## Differentiation from Days 1–67

### Sprint 3 fitness template visual register (days 60–67 — all taken)

| Day | Template | Palette | Fonts | Mode |
|-----|----------|---------|-------|------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 | dark |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira | dark |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Championship Red #EF4444 + Gold | Black Ops One + Rubik | dark |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 + Warm Clay #A05540 | EB Garamond + Quicksand | light |
| 64 | pilates-studio | Cool Stone #F5F4F1 + Deep Ocean Slate #2B5E7B | Prata + Fira Sans | light |
| 65 | dance-studio | Deep Stage Ink #0C0E18 + Rose Crimson #C4315A + Gold #D4A054 | Josefin Sans + Nunito Sans | dark |
| 66 | climbing-gym | Chalk #F6F5F2 + Summit Forest #1B6E3F + Route Ochre #6B4A1F | Barlow Condensed + DM Sans | light |
| 67 | martial-arts-dojo | Iron Night #090A12 + Tournament Blue #1C58E0 + Gold #D4AF37 | Oswald + Inter | dark |

### Why personal-trainer is distinct

**Day 68 (personal-trainer)** is fundamentally different from all 67 prior templates:

1. **Personal brand, not a facility** — One person (Alex Rivera), not a gym, box, studio, or dojo. The design must convey warmth, approachability, and individual expertise — not institutional or facility-oriented.

2. **Unique section: The Method** — A 3-phase Assess → Program → Transform visual framework. No prior Sprint 3 template has a numbered process/methodology section with markers. This is the trainer's intellectual property presentation.

3. **Unique section: Client Results** — Transformation metric cards with hard numbers (weight lost, body fat %, strength PRs, health markers). Different from testimonials — these are quantified outcomes with client data. No prior template has this.

4. **Light-default** — Balances the recent dark-heavy run (days 65, 67 both dark). Also appropriate for the personal brand persona — cleaner, more approachable.

5. **Violet accent** — `#7C3AED` (Violet-700) has NOT been used as a primary accent in Sprint 3. Prior Sprint 3 accents: Orange, Volt Yellow, Red, Sage/Clay, Teal-Navy, Rose Crimson, Forest Green, Tournament Blue. Violet is fresh for both Sprint 3 and for the athletic space generally (connotes aspiration, premium, transformation).

## Design decisions

### Palette: Violet Power (light-default)

- **Background:** `#FAFAFA` — Near-White. Cleanest/brightest of all prior light defaults (yoga warm linen #F8F4EE, pilates cool stone #F5F4F1, climbing chalk #F6F5F2 are all slightly off-white; this pure near-white is distinct and gives the freshest canvas).
- **Surface alt:** `#F5F0FF` — Pale Violet. Unique section alternation that ties to the accent color.
- **Accent:** `#7C3AED` — Violet-700. FIRST USE in Sprint 3. White on violet = 9.72:1 AAA ✓.
- **Accent text (on light):** `#6D28D9` — Violet-800. 8.22:1 AAA on #FAFAFA ✓.
- **Dark hero/CTA bg:** `#0F0A1E` — Deep Purple-Black. Distinct from all prior darks (Iron Night #090A12, Steel Night #0E1520, Ring Mat #1C1108, Deep Stage Ink #0C0E18).
- **On-dark text:** `#F5F0FF` — 18.7:1 AAA ✓.
- **On-dark muted:** `#C4B5FD` — violet-300. 7.9:1 AAA on #0F0A1E ✓.
- **Main text:** `#18112E` — Near-black with violet undertone. 19:1 on #FAFAFA AAA ✓.
- **Muted text:** `#4B4B6E` — 7.1:1 AA ✓ on #FAFAFA.
- **Faint text:** `#6B6B8A` — 4.95:1 AA ✓ on #FAFAFA.

All color combinations verified WCAG AA or higher. No accent-tinted text below 4.5:1.

### Fonts: Both FIRST USE in 365 library

- **Display: Syne** (`@fontsource/syne`) — geometric variable sans designed for art, fashion, and brand identities. Bold personality, modern proportions, excellent for large-scale headings. Distinct from all prior Sprint 3 display fonts.
- **Body: Lexend** (`@fontsource/lexend`) — designed specifically for high readability across all reading proficiency levels. Humanist proportions, slight letterform openness that improves clarity at body sizes. Completely fresh to the 365 library.

### Persona: Alex Rivera, Austin TX

- NSCA-CSCS (gold standard strength & conditioning cert)
- ACSM-CPT (general personal training certification)
- Precision Nutrition Level 2 (clinical-level nutrition coaching)
- ACE Group Fitness Instructor
- 8 years coaching, 200+ clients
- Specializes in: busy professionals, body composition, athletic performance
- Services: 1:1 in-person ($175/session), small-group 2-4 ($110/session/person), online coaching ($299/month)

### Unique sections

1. **The Method** (3-phase framework):
   - Assess: 90-min Kickoff Assessment, InBody scan, FMS screening, goal clarity
   - Program: 12-week periodized mesocycle, schedule-fit, evidence-based nutrition
   - Transform: Execute, track, 4-week adjustment cycles, monthly re-scan

2. **Client Results** (transformation metric cards):
   - Marcus T.: 38 lbs lost, 27% → 17% body fat, deadlift 135 → 305 lbs
   - Jordan K.: +11 lbs lean muscle, 95 → 185 lb squat
   - Priya M.: 29 lbs lost, first marathon 4:38, online coaching client in Chicago
   - Derek O.: +18 lbs muscle, blood pressure normalization, bench 115 → 225 lbs (age 51)

### Schema.org types

- `Person` + `LocalBusiness` (solo trainer)
- `Service` (personal training offerings)
- `WebSite`
- `FAQPage` (8 questions)
