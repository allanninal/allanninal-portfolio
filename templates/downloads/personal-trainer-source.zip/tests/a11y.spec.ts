import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('Personal Trainer — accessibility', () => {
  test('homepage passes axe WCAG AA audit', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .exclude('script[type="application/ld+json"]')
      .analyze();

    if (results.violations.length > 0) {
      console.log('Axe violations:');
      results.violations.forEach(v => {
        console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
        v.nodes.forEach(n => console.log(`    → ${n.html}`));
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withTags(['cat.aria'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('color contrast passes for all text', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page })
      .withRules(['color-contrast'])
      .analyze();

    if (results.violations.length > 0) {
      console.log('Color contrast violations:');
      results.violations.forEach(v => {
        v.nodes.forEach(n => {
          console.log(`  ${n.html}`);
          n.any.forEach((a: any) => console.log(`    Data: ${JSON.stringify(a.data)}`));
        });
      });
    }

    expect(results.violations).toEqual([]);
  });

  test('skip link is present in DOM', async ({ page }) => {
    await page.goto('/');
    const skipLink = page.locator('.skip-link');
    await expect(skipLink).toBeAttached();
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    const mobileNav = page.locator('#mobile-nav');
    await expect(mobileNav).not.toHaveAttribute('hidden', '');
    await toggle.click();
    await expect(mobileNav).toHaveAttribute('hidden', '');
  });

  test('FAQ accordions expand on click', async ({ page }) => {
    await page.goto('/');
    const firstDetails = page.locator('details').first();
    await expect(firstDetails).toBeAttached();
    await firstDetails.click();
    await expect(firstDetails).toHaveAttribute('open', '');
  });

  test('heading hierarchy is logical', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toHaveCount(1);
  });

  test('service cards are present', async ({ page }) => {
    await page.goto('/');
    const serviceCards = page.locator('.service-card');
    const count = await serviceCards.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('method steps are present', async ({ page }) => {
    await page.goto('/');
    const methodSteps = page.locator('.method-step');
    const count = await methodSteps.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('result cards are present', async ({ page }) => {
    await page.goto('/');
    const resultCards = page.locator('.result-card');
    const count = await resultCards.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('pricing cards are present', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });
});
