import { test, expect } from '@playwright/test';

test.describe('Personal Trainer — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title is set correctly', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('Alex Rivera');
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of ['about', 'services', 'method', 'results', 'pricing', 'testimonials', 'faq', 'contact']) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('booking links are present', async ({ page }) => {
    await page.goto('/');
    const bookLinks = page.locator('a[href*="calendly"]');
    const count = await bookLinks.count();
    expect(count).toBeGreaterThan(0);
  });

  test('tel and mailto links are present', async ({ page }) => {
    await page.goto('/');
    const telLinks  = page.locator('a[href^="tel:"]');
    const mailLinks = page.locator('a[href^="mailto:"]');
    const telCount  = await telLinks.count();
    const mailCount = await mailLinks.count();
    expect(telCount + mailCount).toBeGreaterThanOrEqual(2);
  });

  test('social links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const socialLinks = page.locator('a[target="_blank"][rel*="noopener"]');
    const count = await socialLinks.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    const favicon = page.locator('link[rel="icon"]');
    await expect(favicon).toBeAttached();
  });

  test('pricing section has three tiers', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBe(3);
  });

  test('service cards show all 3 services', async ({ page }) => {
    await page.goto('/');
    const serviceCards = page.locator('.service-card');
    const count = await serviceCards.count();
    expect(count).toBe(3);
  });

  test('method steps show 3-phase approach', async ({ page }) => {
    await page.goto('/');
    const methodSteps = page.locator('.method-step');
    const count = await methodSteps.count();
    expect(count).toBe(3);
  });

  test('client result cards are present', async ({ page }) => {
    await page.goto('/');
    const resultCards = page.locator('.result-card');
    const count = await resultCards.count();
    expect(count).toBe(4);
  });

  test('testimonial cards are present', async ({ page }) => {
    await page.goto('/');
    const testimonialCards = page.locator('.testimonial-card');
    const count = await testimonialCards.count();
    expect(count).toBe(4);
  });

  test('about section is present with bio', async ({ page }) => {
    await page.goto('/');
    const aboutSection = page.locator('#about');
    await expect(aboutSection).toBeAttached();
    const avatar = page.locator('.about-avatar');
    await expect(avatar).toBeAttached();
  });

  test('cert chips are present in about section', async ({ page }) => {
    await page.goto('/');
    const certChips = page.locator('.cert-chip');
    const count = await certChips.count();
    expect(count).toBeGreaterThanOrEqual(4);
  });

  test('metric chips are present in results section', async ({ page }) => {
    await page.goto('/');
    const metricChips = page.locator('.metric-chip');
    const count = await metricChips.count();
    expect(count).toBeGreaterThanOrEqual(8);
  });
});
