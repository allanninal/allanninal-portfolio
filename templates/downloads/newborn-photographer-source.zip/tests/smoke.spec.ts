import { test, expect } from '@playwright/test';

test.describe('Halló Studio — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Halló Studio/);
    await expect(page.locator('h1')).toContainText('composite');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The poses ───────────────────────────────────────────────────────────
  test('every pose discloses what it looks like and what actually happens', async ({ page }) => {
    await page.goto('/');
    const poses = page.locator('#poses article.pose');
    expect(await poses.count()).toBe(6);
    for (const p of await poses.all()) {
      const dts = await p.locator('dl dt').allTextContents();
      expect(dts.map((s) => s.trim())).toEqual(['What it looks like', 'What actually happens']);
      const dds = await p.locator('dl dd').allTextContents();
      for (const d of dds) expect(d.trim().length).toBeGreaterThan(50);
    }
  });

  // The marker must be a word — a colour alone would be useless here.
  test('each pose carries its method as a word', async ({ page }) => {
    await page.goto('/');
    const marks = await page.locator('#poses .mark').allTextContents();
    expect(marks.length).toBe(6);
    for (const m of marks) {
      expect(['Composite', 'Supported', 'Not attempted']).toContain(m.trim());
    }
  });

  test('the headline counts are derived from the poses', async ({ page }) => {
    await page.goto('/');
    const marks = (await page.locator('#poses .mark').allTextContents()).map((s) => s.trim());
    const comp = marks.filter((m) => m === 'Composite').length;
    const sup = marks.filter((m) => m === 'Supported').length;
    const never = marks.filter((m) => m === 'Not attempted').length;
    await expect(page.locator('#poses h2')).toContainText(`${comp} of these are composites`);
    // The line wraps across source lines, so compare on normalised whitespace.
    const summary = ((await page.locator('#poses p.figure-lead').textContent()) || '')
      .replace(/\s+/g, ' ').trim();
    expect(summary).toBe(`${comp} composite · ${sup} supported · ${never} not attempted.`);
  });

  // The claim the page exists to make.
  test('it states that hands are edited out, and refuses unsupported poses', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('h1 ~ p').first()).toContainText('edited out, not removed');
    const never = page.locator('#poses article.pose').filter({
      has: page.locator('.mark--never'),
    });
    await expect(never).toContainText(/unsupported/i);
    await expect(never).toContainText(/Not attempted, not composited, not offered/i);
  });

  test('the composite poses say a spotter or hands are in every frame', async ({ page }) => {
    await page.goto('/');
    // Match the marker element, not the prose — the refused pose's copy contains
    // the word "composited" and would otherwise be counted as a composite.
    const comps = page.locator('#poses article.pose').filter({
      has: page.locator('.mark--composite'),
    });
    expect(await comps.count()).toBe(3);
    for (const c of await comps.all()) {
      const txt = ((await c.textContent()) || '').toLowerCase();
      expect(/hold|held|hand|support/.test(txt)).toBe(true);
    }
  });

  test('the room publishes its temperature and its spotter rule', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#room');
    expect(await r.locator('.cond').count()).toBe(6);
    await expect(r).toContainText('26–28°C');
    await expect(r).toContainText(/Spotter/);
    await expect(r).toContainText(/Always/);
  });

  // The counter-marketing claim.
  test('it tells late bookers they have not missed anything', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#timing')).toContainText(/Nobody has missed anything/i);
    await expect(page.locator('#rates')).toContainText(/Same price/i);
  });

  test('every session image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#sessions img').evaluateAll((els) =>
      els.map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })));
    expect(imgs.length).toBe(4);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      // Every image in this template shows a wrapped or clothed baby.
      expect(/swaddled|wrapped|romper|knit/i.test(i.alt)).toBe(true);
      expect(i.w).toBeTruthy(); expect(i.h).toBeTruthy();
    }
  });

  test('all session images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('sessions are captioned with how each frame was made', async ({ page }) => {
    await page.goto('/');
    const caps = await page.locator('#sessions figcaption').allTextContents();
    expect(caps.length).toBe(4);
    for (const c of caps) expect(/composite|supported/i.test(c)).toBe(true);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-97 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['meridian', 'fort collins', 'verticals', '24mm', 'sorts mill']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro safety protocol is absent from the free build', async ({ page }) => {
    const res = await page.goto('/safety-protocol/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
