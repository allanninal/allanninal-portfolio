// Halló Studio — Burlington, VT.
//
// Eighth photography template, eighth axis: how it is done safely.
//
// The famous newborn poses are composites — a spotter's hands are in every
// frame and are edited out afterwards. Almost no studio says so, and a parent
// choosing a photographer has no way to tell a careful one from a reckless one.
// This page says it plainly, which is both the honest thing and the clearest
// possible statement of competence.

export const site = {
  name:        'Halló Studio',
  shortName:   'Halló',
  title:       'Halló Studio — Newborn Photography in Burlington, VT',
  tagline:     'Every pose you have seen is a composite.',
  owner:       'Ingrid Marchetti',
  ownerRole:   'Newborn photographer',
  credential:  'Newborn-trained · infant CPR current · Burlington',
  license:     'Newborn photography studio, working since 2016',
  city:        'Burlington',
  state:       'VT',
  language:    'en',
  phoneDisplay: '(802) 555-0146',
  phoneHref:   '+18025550146',
  email:       'studio@hallostudio.example',
  streetAddress: '164 Pine St',
  postalCode:  '05401',
  hours:       'Sessions Tue–Sat, mornings · one a day',
  bookingWindow: 'Book while pregnant; we hold a fortnight, not a date.',
  description:
    'A newborn studio in Burlington. The poses you have seen online are composites — a ' +
    'second pair of hands is in every frame and edited out afterwards — and this page ' +
    'explains exactly how each one is done, because a parent booking anyone should know.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The poses',  href: '#poses' },
  { label: 'The room',   href: '#room' },
  { label: 'Timing',     href: '#timing' },
  { label: 'Sessions',   href: '#sessions' },
  { label: 'Rates',      href: '#rates' },
  { label: 'Book',       href: '#book' },
];

// ── The poses ─────────────────────────────────────────────────────────────
// how: 'composite' | 'supported' | 'never'

export const poses = [
  {
    name: 'Chin on hands — the "froggy"',
    how: 'composite',
    looks: 'The baby appears to be propping their own head up on both hands, elbows on the blanket.',
    truth: 'Two frames. In each one an adult holds the head and a wrist; the frames are blended so both pairs of hands disappear. A newborn cannot support their own head and never will in this position.',
    frames: 2,
  },
  {
    name: 'Hanging hammock',
    how: 'composite',
    looks: 'The baby appears suspended in a cloth sling between two branches or hooks.',
    truth: 'The baby is on a beanbag, at floor level, held throughout. The sling, the branch and the height are photographed separately and composited. Nothing is ever suspended.',
    frames: 3,
  },
  {
    name: 'In a bucket or crate',
    how: 'composite',
    looks: 'The baby sits upright inside a bucket, head above the rim.',
    truth: 'The bucket is weighted, padded and never more than a few centimetres off the floor, and a hand is inside it supporting the back and neck in every frame. The empty-bucket frame is shot afterwards and blended.',
    frames: 2,
  },
  {
    name: 'Curled on a beanbag',
    how: 'supported',
    looks: 'The baby is curled on their side or front on a soft surface, wrapped.',
    truth: 'A single frame, no compositing needed — but a spotter is still within arm’s reach for every one, and the baby is wrapped so the position is theirs rather than arranged.',
    frames: 1,
  },
  {
    name: 'In a parent’s hands',
    how: 'supported',
    looks: 'The baby held in cupped hands or against a shoulder.',
    truth: 'Exactly what it looks like, and the easiest safe frame in the book. The hands in this one stay in the picture, which is the point of it.',
    frames: 1,
  },
  {
    name: 'Balanced or unsupported anything',
    how: 'never',
    looks: 'Propped on a ledge, on a scale, in a hanging basket, on a parent’s outstretched palm.',
    truth: 'Not attempted, not composited, not offered. If a studio shows you one of these and cannot describe how the frames were built, that is the question to ask before you book.',
    frames: 0,
  },
];

export const posesNote =
  'Every one of the composites above is standard practice in a careful studio and is not a ' +
  'trick played on you — it is the only way those pictures can exist without putting a ' +
  'newborn in a position they cannot hold. What is unusual is saying so.';

// ── The room ──────────────────────────────────────────────────────────────

export const room = {
  intro:
    'A newborn out of a blanket cannot regulate their own temperature, so the studio runs ' +
    'warm enough to be uncomfortable for everybody else in it. These are the conditions on ' +
    'every session, and none of them are negotiable.',
  conditions: [
    { k: 'Room temperature', v: '26–28°C', n: 'Warm enough that adults notice. A cold baby will not settle and should not be unwrapped.' },
    { k: 'Session length',   v: '3 hours', n: 'It follows the baby. Feeding, settling and changing are the session, not interruptions to it.' },
    { k: 'Spotter',          v: 'Always',  n: 'Within arm’s reach for every frame that is not flat on a beanbag. Usually a parent, which is also the best way to see how it is done.' },
    { k: 'Hands and props',  v: 'Sanitised', n: 'Between every setup. Wraps are washed between families, not between sessions on the same day.' },
    { k: 'Illness',          v: 'Rebooked', n: 'Ours or yours. A cold is a reschedule, free, no conversation about it.' },
    { k: 'Feeding',          v: 'Whenever', n: 'There is a chair and a screen. A fed baby is the entire job.' },
  ],
};

// ── Timing ────────────────────────────────────────────────────────────────

export const timing = {
  headline: 'Five to fourteen days, and what happens after.',
  intro:
    'Newborns keep the curled-up position for roughly the first fortnight. That window is ' +
    'why studios press you to book early — but a session after it is not a worse session, ' +
    'it is a different one, and it costs the same here.',
  rows: [
    { when: 'Day 5 – 14',   what: 'Curled, sleepy, wrapped',        note: 'The classic session. Book while pregnant; we hold a fortnight rather than a date.' },
    { when: 'Day 15 – 28',  what: 'Less curl, more awake',           note: 'Still lovely and noticeably more alert. Fewer wrapped poses, more held ones.' },
    { when: '4 – 12 weeks', what: 'Awake, held, eye contact',        note: 'A genuinely different set of pictures and often the ones families print.' },
    { when: 'Any time',     what: 'Whatever the baby is doing',      note: 'Nobody has missed anything. The idea that you have is a marketing device.' },
  ],
};

// ── Sessions ──────────────────────────────────────────────────────────────
// Alt strings written from the files. Every image is a wrapped or clothed baby.

export const sessions = [
  { file: 'n01.jpg', cap: 'Wrapped, beanbag · supported · 1 frame',
    alt: 'A sleeping newborn swaddled in cream knit wearing a bonnet with small ears, a knitted bear beside them' },
  { file: 'n02.jpg', cap: 'Curled, hands under chin · composite · 2 frames',
    alt: 'A sleeping newborn in a cream knitted romper and eared bonnet, curled with hands beneath the chin' },
  { file: 'n03.jpg', cap: 'Lace wrap, arms free · supported · 1 frame',
    alt: 'A sleeping newborn wrapped in white lace with both arms free, on a pale blue surface' },
  { file: 'n04.jpg', cap: 'Colour wrap on fur · supported · 1 frame',
    alt: 'A sleeping newborn swaddled in deep red cloth on cream fur, with pale roses behind' },
];

export const rates = {
  rows: [
    { what: 'Newborn session',      figure: '$495', note: 'Three hours, one a day, 25–35 finished images.' },
    { what: 'Sibling or parents in', figure: 'Included', note: 'Not an upsell. They are usually the pictures that get framed.' },
    { what: 'Session after 4 weeks', figure: '$495', note: 'Same price. A later session is different, not lesser.' },
    { what: 'Print licence',        figure: 'Included', note: 'Perpetual, any size, anywhere. You will not be charged per print.' },
    { what: 'Album, 20 sides',      figure: '$340',  note: 'Optional, and genuinely optional — say no and nothing changes.' },
    { what: 'Reschedule',           figure: '$0',    note: 'For illness, early arrival, late arrival, or a bad week. Babies do not read calendars.' },
  ],
};

export const faqs = [
  {
    q: 'Is the froggy pose safe?',
    a: 'As a composite, yes — two frames, an adult holding the head and a wrist in each, blended afterwards. Attempted in a single frame it is not safe at all. If a studio shows you that pose and cannot tell you how it was built, ask again before you book.',
  },
  {
    q: 'Why is the studio so warm?',
    a: 'Because a newborn out of a blanket cannot regulate their own temperature. 26 to 28 degrees is uncomfortable for adults and correct for the baby. Wear a t-shirt.',
  },
  {
    q: 'Can I stay in the room?',
    a: 'Please do — you are usually the spotter. It is also the easiest way to see exactly how each frame is made, which is worth more than anything on this page.',
  },
  {
    q: 'We are past two weeks. Have we missed it?',
    a: 'No. The curled-up window is real and it is roughly a fortnight, but a four-week session is a different set of pictures rather than a worse one, and it costs the same. The urgency you have been reading is largely a marketing device.',
  },
  {
    q: 'What if the baby will not settle?',
    a: 'Then the session is three hours of feeding and settling and we book another morning at no charge. That happens perhaps twice a year and it has never once been a problem.',
  },
  {
    q: 'Do you retouch the babies?',
    a: 'Dry skin, a scratch, and the colour of newborn skin, which photographs redder than it looks. Never the shape of a face, never a birthmark. They will want to see that later.',
  },
];
