// Dara Okonkwo — Lincoln, NE.
//
// Roadmap line: "Reel + project breakdowns." Day 101 already refused to be
// reel-led and day 103 already published an unflattering record, so the axis
// here is the thing clients actually get wrong about motion work: a change
// request is priced by the stage it arrives in, not by how big it sounds.
//
// Every hour figure the copy quotes is summed or read from these arrays.

export const site = {
  name:        'Dara Okonkwo',
  shortName:   'Dara Okonkwo',
  title:       'Dara Okonkwo — Motion design, Lincoln',
  tagline:     'A change is not a change. It is a stage.',
  owner:       'Dara Okonkwo',
  ownerRole:   'Motion designer',
  credential:  'Design and animation for brand and broadcast since 2017',
  city:        'Lincoln',
  state:       'NE',
  language:    'en',
  phoneDisplay: '(402) 555-0188',
  phoneHref:   '+14025550188',
  email:       'dara@daraokonkwo.example',
  streetAddress: '233 N 8th St',
  postalCode:  '68508',
  hours:       'Mon–Fri · animating, so email beats calling',
  bookingWindow: 'Booking animation slots from three weeks out.',
  description:
    'Motion design in Lincoln. Every portfolio in this trade opens with a reel and the word ' +
    '“storytelling”. This one opens with the number nobody publishes: what the same change ' +
    'request costs at each of the six stages, from one hour to forty-eight.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The curve',   href: '#curve' },
  { label: 'Per second',  href: '#seconds' },
  { label: 'Giving notes', href: '#notes' },
  { label: 'Rates',       href: '#rates' },
  { label: 'Start',       href: '#start' },
];

// ── The change ────────────────────────────────────────────────────────────
// One specific, realistic request, priced at six moments.

export const theChange =
  'Move the logo reveal eight frames later, and make the type a sans instead of the serif.';

export const stages = [
  {
    stage: 'Brief and references', open: 'Everything',
    locked: 'Nothing',
    hours: 1, state: 'open',
    why: 'It is a sentence in a document. At this stage the request is not a change at all — it is the brief being written correctly the first time.',
  },
  {
    stage: 'Style frames', open: 'Type, colour, the whole look',
    locked: 'Roughly a day of exploration',
    hours: 2, state: 'open',
    why: 'Two or three static frames exist. Swapping a serif for a sans is a font menu and a re-export; the eight frames do not exist yet to move.',
  },
  {
    stage: 'Storyboard', open: 'Order, timing, what is on screen',
    locked: 'The look',
    hours: 4, state: 'open',
    why: 'Panels get redrawn and the timing column gets re-typed. This is the last stage where "move it eight frames" is a note rather than an operation.',
  },
  {
    stage: 'Animatic', open: 'Timing, within reason',
    locked: 'Structure and look',
    hours: 8, state: 'closing',
    why: 'Now the eight frames are real: everything downstream of the reveal shifts, and the sound design that was cut to the old timing has to move with it.',
  },
  {
    stage: 'Animation', open: 'Almost nothing, cheaply',
    locked: 'Timing, look, structure',
    hours: 20, state: 'paid',
    why: 'Every layer after the reveal is keyframed against it. Changing the typeface re-flows text that has been individually animated, character by character.',
  },
  {
    stage: 'Render and delivery', open: 'Nothing',
    locked: 'All of it, in eleven output files',
    hours: 48, state: 'paid',
    why: 'The change itself is still twenty hours. The other twenty-eight are re-rendering, re-grading, re-versioning every ratio and length, and re-doing QC on all of them.',
  },
];

export const curveNote =
  'Same sentence, same designer, same project file. The only variable is when it arrives. ' +
  'Nobody hides this on purpose — it simply never gets said until it has already happened to ' +
  'somebody, at which point it sounds like an excuse instead of a schedule.';

// ── Seconds are not a unit ────────────────────────────────────────────────

export const perSecond = {
  intro:
    'A thirty-second video is not a quantity of motion work. These are hours of animation per ' +
    'finished second, and the spread between the top and the bottom of this list is why two ' +
    '“thirty-second videos” can differ by a factor of thirty in price.',
  rows: [
    { shot: 'Held title card, simple fade',   rate: 0.4,  note: 'Fast, and genuinely fine for a lot of what people ask animation for.' },
    { shot: 'Kinetic type, one line',          rate: 1.5,  note: 'Every word individually timed. Reads as effortless, which is the trap.' },
    { shot: '2D character, walk cycle',        rate: 6,    note: 'Rig, then animate, then clean up. The rig is reusable and the first shot pays for it.' },
    { shot: 'Logo build, 3D with materials',   rate: 9,    note: 'Modelling, lighting and lookdev before a single keyframe. Then it renders overnight and you find out.' },
    { shot: 'Data visualisation, live figures', rate: 4,   note: 'The animation is the small half. Cleaning the data and agreeing what it says is the rest.' },
    { shot: 'Simulation — cloth, smoke, crowd', rate: 14,  note: 'You do not animate a simulation, you negotiate with it. Budget for three that fail.' },
  ],
};

// ── Giving notes ──────────────────────────────────────────────────────────

export const notes = [
  {
    head: 'Frame numbers, not adjectives.',
    body: '"It feels slow" costs an hour of guessing. "00:04:12 to 00:05:06 — this hold is too long" costs four minutes. Every review link has a frame counter on it and using it is the single biggest favour a client can do a motion designer.',
  },
  {
    head: 'Describe the read, not the keyframe.',
    body: '"Make the logo pop" is not a note; "the logo arrives before I have finished reading the line above it" is. The first one asks me to guess at a fix, the second one tells me what is actually wrong, and the fix is my job.',
  },
  {
    head: 'One pass, not three.',
    body: 'Three notes trickled over four days cost about twice one consolidated list, because each one restarts a render and re-opens a decision that was closed. If more people have to see it, wait for them.',
  },
];

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Day rate, design and animation', figure: '$720',   note: 'Ten hours. Most projects are quoted as a fixed price built from this and the per-second table above, not billed by the day.' },
    { what: 'Brand toolkit — 6 to 10 assets', figure: 'From $5,800', note: 'Lower thirds, transitions, endcard, logo build, delivered as editable project files as well as renders.' },
    { what: 'Explainer, 60–90 seconds',       figure: 'From $8,400', note: 'Priced from the shot list, per second, per type. A flat quote before the shot list exists is a guess with a number on it.' },
    { what: 'Change after picture lock',      figure: 'Quoted, always', note: 'See the curve. It is quoted rather than absorbed, because absorbing it silently is how a project runs 40% over and nobody can say when.' },
    { what: 'Editable project files',         figure: 'Included',  note: 'Yours at delivery, with the fonts named and the layers labelled. A tidy file is a deliverable, not a favour.' },
  ],
};

export const faqs = [
  {
    q: 'Can I see a reel?',
    a: 'Yes, and it will tell you what I can make rather than how a project with me runs. The curve on this page tells you the second thing, which is the one that decides whether you are happy in week six.',
  },
  {
    q: 'Why is there no work on this page?',
    a: 'Because there is no photograph of motion design, and a grid of stock laptops would be this page arguing against its own copy. The reel is a link, sent in the first email, at the resolution it was made for rather than compressed into a website.',
  },
  {
    q: 'What if we need a change after picture lock?',
    a: 'You get a quote for it, in hours, before anything moves — and quite often the honest answer is that the change is not worth what it costs and we should both say so. It is never silently absorbed; that is how a schedule stops meaning anything.',
  },
  {
    q: 'Do you work in After Effects or Blender?',
    a: 'Both, plus Cinema 4D when a client already has a pipeline in it. This matters far less than anyone outside the trade expects — the software is the least interesting decision on any project.',
  },
  {
    q: 'Can you animate our existing brand assets?',
    a: 'Usually, and I will tell you early if the logo is going to fight it. Marks built with fine hairlines or tight counters tend to break up in motion at small sizes, which is a real constraint and not a preference.',
  },
  {
    q: 'How long does a 60-second explainer take?',
    a: 'Five to seven weeks, and the two review windows are most of the difference between the two numbers. The shot list decides the rest — see the per-second table.',
  },
];
