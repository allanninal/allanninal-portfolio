import { test, expect } from '@playwright/test';

test.describe('Dara Okonkwo — smoke tests', () => {
  test('homepage renders with the designer name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Dara Okonkwo/);
    await expect(page.locator('h1')).toContainText('It is a stage');
  });

  test('is marked up as a Person, with no business-only fields', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q1058500');
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // ── The curve ───────────────────────────────────────────────────────────
  test('the headline hours are read from the stage table', async ({ page }) => {
    await page.goto('/');
    const hrs = (await page.locator('#curve tbody .hrs').allTextContents())
      .map((t) => Number(t.replace(' h', '')));
    expect(hrs.length).toBe(6);
    const h2 = page.locator('#curve h2');
    await expect(h2).toContainText(`${hrs[0]} hour`);
    await expect(h2).toContainText(`${hrs[hrs.length - 1]} after render`);
    await expect(page.locator('#curve')).toContainText(`${hrs[hrs.length - 1] / hrs[0]}× spread`);
  });

  test('the cost only ever climbs', async ({ page }) => {
    await page.goto('/');
    const hrs = (await page.locator('#curve tbody .hrs').allTextContents())
      .map((t) => Number(t.replace(' h', '')));
    for (let i = 1; i < hrs.length; i++) expect(hrs[i]).toBeGreaterThan(hrs[i - 1]);
  });

  // The section is about what a change costs, so "expensive" must never be
  // carried by hue alone.
  test('every stage states its cost state in words as well as colour', async ({ page }) => {
    await page.goto('/');
    const chips = await page.locator('#curve tbody .state').allTextContents();
    expect(chips.length).toBe(6);
    for (const c of chips) {
      expect(['Still open', 'Closing', 'Already paid for']).toContain(c.trim());
    }
    // and neither cost token is the accent
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--cost-cheap', '--cost-dear', '--color-accent'].map((n) => s.getPropertyValue(n).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  test('the chart is drawn from the table and is decorative', async ({ page }) => {
    await page.goto('/');
    const svg = page.locator('#curve figure.curve svg');
    await expect(svg).toHaveAttribute('aria-hidden', 'true');
    // one point per stage
    expect(await svg.locator('circle').count()).toBe(6);
    // the caption must say it is a log scale, or a reader will misread it
    await expect(page.locator('#curve figcaption')).toContainText(/log scale/i);
    // the polyline only ever goes up (y decreases left to right)
    const ys = await svg.locator('circle').evaluateAll((cs) => cs.map((c) => Number(c.getAttribute('cy'))));
    for (let i = 1; i < ys.length; i++) expect(ys[i]).toBeLessThan(ys[i - 1]);
  });

  test('the change request is quoted once and only once', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#curve')).toContainText(/eight frames later/);
  });

  // ── Per second ──────────────────────────────────────────────────────────
  test('the per-second spread is computed from the list', async ({ page }) => {
    await page.goto('/');
    const rates = (await page.locator('#seconds .persec .rate').allTextContents())
      .map((t) => parseFloat(t));
    expect(rates.length).toBeGreaterThan(4);
    const spread = Math.round(Math.max(...rates) / Math.min(...rates));
    await expect(page.locator('#seconds')).toContainText(`${spread}× spread`);
  });

  test('the frame ruler is decorative and marks each second', async ({ page }) => {
    await page.goto('/');
    const ruler = page.locator('#seconds .ruler');
    await expect(ruler).toHaveAttribute('aria-hidden', 'true');
    expect(await ruler.locator('span').count()).toBe(120);
    expect(await ruler.locator('span.sec').count()).toBe(5);
  });

  // ── No photographs, on purpose ──────────────────────────────────────────
  test('there are no photographs and the page says why', async ({ page }) => {
    await page.goto('/');
    const raster = await page.locator('img').evaluateAll((imgs) =>
      imgs.map((i) => i.getAttribute('src') || '').filter((s) => /\.(jpe?g|png|webp|avif)$/i.test(s)));
    expect(raster).toEqual([]);
    await expect(page.locator('#faq')).toContainText(/no photograph of motion design/i);
  });

  test('the shot-type select is built from the per-second list', async ({ page }) => {
    await page.goto('/');
    const shots = await page.locator('#seconds .persec .shot').allTextContents();
    const opts = await page.locator('#kind option').allTextContents();
    for (const s of shots) expect(opts).toContain(s);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the enquiry form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-103 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['wren sandoval', 'duluth', 'festival', 'laurel', 'q2526255', 'literata']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro change order is absent from the free build', async ({ page }) => {
    const res = await page.goto('/change-order/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
