import { test, expect } from '@playwright/test';

test('no broken internal links', async ({ page }) => {
  await page.goto('/');
  // Collect all anchor hrefs
  const hrefs = await page.$$eval('a[href]', (anchors) =>
    anchors
      .map((a) => (a as HTMLAnchorElement).getAttribute('href') ?? '')
      .filter((href) => href.startsWith('/') || href.startsWith('#'))
  );

  for (const href of hrefs) {
    if (href.startsWith('#')) {
      // Check anchor exists on page
      const id = href.slice(1);
      if (id) {
        const el = page.locator(`#${id}`);
        const count = await el.count();
        expect(count, `Missing anchor: ${href}`).toBeGreaterThan(0);
      }
    }
    // Internal page links ('/') already verified by server being up
  }
});
