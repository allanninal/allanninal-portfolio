import { test, expect } from '@playwright/test';
import { VIEWPORTS } from './helpers';

const THIRD_PARTY_NOISE = [
  /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i,
  /failed to load resource/i,
];

test.describe('Home page', () => {
  test('renders h1', async ({ page }) => {
    await page.goto('/');
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
    const text = await h1.textContent();
    expect(text).toBeTruthy();
  });

  test('portfolio section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#portfolio');
    await expect(section).toBeVisible();
  });

  test('services section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#services');
    await expect(section).toBeVisible();
  });

  test('about section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#about');
    await expect(section).toBeVisible();
  });

  test('testimonials section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#testimonials');
    await expect(section).toBeVisible();
  });

  test('FAQ section is present and accordion works', async ({ page }) => {
    await page.goto('/');
    const faqSection = page.locator('#faq');
    await expect(faqSection).toBeVisible();

    // Test accordion toggle
    const firstTrigger = page.locator('.faq-trigger').first();
    await expect(firstTrigger).toHaveAttribute('aria-expanded', 'false');
    await firstTrigger.click();
    await expect(firstTrigger).toHaveAttribute('aria-expanded', 'true');
    const panel = page.locator('.faq-panel.is-open').first();
    await expect(panel).toBeVisible();
  });

  test('contact section is present', async ({ page }) => {
    await page.goto('/');
    const section = page.locator('#contact');
    await expect(section).toBeVisible();
  });

  test('portfolio filter buttons work', async ({ page }) => {
    await page.goto('/');
    const bridalBtn = page.locator('.filter-btn[data-filter="bridal"]');
    await expect(bridalBtn).toBeVisible();
    await bridalBtn.click();
    await expect(bridalBtn).toHaveAttribute('aria-pressed', 'true');
  });

  test('booking CTA links exist', async ({ page }) => {
    await page.goto('/');
    const ctaLinks = page.locator('a[href*="calendly"], a[href*="booking"]');
    const count = await ctaLinks.count();
    expect(count).toBeGreaterThan(0);
  });

  test('contact form has labeled inputs', async ({ page }) => {
    await page.goto('/');
    const nameInput = page.locator('#name');
    await expect(nameInput).toBeVisible();
    const emailInput = page.locator('#email');
    await expect(emailInput).toBeVisible();
    const messageTextarea = page.locator('#message');
    await expect(messageTextarea).toBeVisible();
  });

  test('no unfiltered console errors', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const text = msg.text();
        const isNoise = THIRD_PARTY_NOISE.some(re => re.test(text));
        if (!isNoise) errors.push(text);
      }
    });
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    expect(errors, `Console errors: ${errors.join('\n')}`).toEqual([]);
  });

  test('images have explicit width and height', async ({ page }) => {
    await page.goto('/');
    const imgs = page.locator('img');
    const count = await imgs.count();
    for (let i = 0; i < count; i++) {
      const img = imgs.nth(i);
      const width  = await img.getAttribute('width');
      const height = await img.getAttribute('height');
      expect(width,  `img[${i}] missing width`).toBeTruthy();
      expect(height, `img[${i}] missing height`).toBeTruthy();
    }
  });
});

test.describe('Responsive layout', () => {
  for (const vp of VIEWPORTS) {
    test(`renders at ${vp.name} (${vp.width}×${vp.height})`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto('/');
      const h1 = page.locator('h1');
      await expect(h1).toBeVisible();
      // Check no horizontal overflow
      const bodyWidth  = await page.evaluate(() => document.body.scrollWidth);
      const innerWidth = await page.evaluate(() => window.innerWidth);
      expect(bodyWidth).toBeLessThanOrEqual(innerWidth + 2); // 2px tolerance
    });
  }
});
