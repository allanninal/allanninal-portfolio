# Day 57 — Makeup Artist Template

**Part of the [365 Astro Templates](https://templates.allanninal.dev) project.**

A complete freelance makeup artist portfolio — bridal, editorial, and special-occasion. Built with Astro + Tailwind CSS.

**Live demo:** https://templates.allanninal.dev/makeup-artist/

## Features

- **Portfolio gallery** — 8 photo cards (Bridal / Editorial / Glam / Special Occasion) with JS filter buttons and hover overlays
- **Services menu** — 6 services with pricing, duration, and includes lists (Bridal Trial, Wedding Day, Bridal Party, Editorial/Commercial, Special Occasion, Private Lesson)
- **Add-ons** — airbrush upgrade, individual lashes, glitter/body art, travel fee, after-midnight rate
- **Artist bio** — personal story, credentials (CA State License, MAC, NAIMIE's, Airbrush, Warner Bros.), kit brands
- **Trust band** — 4 differentiation cards (pro kit, camera-ready guarantee, sanitized/safe, on-time)
- **Testimonials** — 6 authentic client reviews with service context
- **FAQ accordion** — 8 Q&As covering trials, booking lead time, travel fees, timing, sensitive skin, airbrush, cancellation policy, hair referrals
- **Booking inquiry form** — name, email, phone, service selector, event date, message
- **Contact info panel** — direct phone, email, Calendly link, coverage area, availability schedule
- **Stats band** — 9+ years, 400+ brides, 80+ editorial credits, 5★ average
- **AnalyticsHead** — GA + AdSense, hub-gated (safe for cloning)
- **TemplateInfo** — canonical 3-button download bar (hub-gated)
- **Schema.org** — Person + HealthAndBeautyBusiness + Service/OfferCatalog
- **Full SEO** — OG, Twitter Card, canonical, robots, author meta

## Palette

Deep Plum `#4A1860` + Champagne Gold `#C8A46A` on Warm White `#FEF9F5`.
Typography: Cormorant Garamond (editorial luxury serif) + Nunito Sans Variable (approachable body).

Distinct from all days 50–56 in hue, temperature, and density.

## Tech stack

- [Astro](https://astro.build/) 4.x — static output
- [Tailwind CSS](https://tailwindcss.com/) 3.x
- Cormorant Garamond + Nunito Sans Variable via @fontsource
- Vanilla JS: portfolio filter + FAQ accordion
- Playwright + axe-core for testing

## Getting started

```bash
git clone https://github.com/allanninal/templates
cd templates/templates/makeup-artist
npm install
npm run dev
```

### Deploy wiring

Set these env vars at build time:

| Variable | Purpose |
|---|---|
| `PUBLIC_BASE_PATH` | Subdirectory prefix, e.g. `/makeup-artist/` |
| `PUBLIC_TEMPLATE_HUB_URL` | Author gallery URL — enables download bar + analytics |

## License

MIT — free to use, fork, and customize. Attribution appreciated.

Built by [Allan Niñal](https://www.linkedin.com/in/allanninal/) as part of the 365 Astro Templates project.
