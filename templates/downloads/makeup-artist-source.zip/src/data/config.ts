// ─── Artist persona ───────────────────────────────────────────────────────────
export const artist = {
  name:         'Camille Voss',
  title:        'Freelance Makeup Artist',
  location:     'Los Angeles, CA · Available Worldwide',
  tagline:      'Artistry that moves with you — bridal, editorial, and beyond.',
  description:
    'Freelance makeup artist based in Los Angeles with 9+ years creating bridal, editorial, and special-occasion looks. NAIMIE\'s and MAC-trained with a roster of luxury bridal clients, commercial shoots, and film sets.',
  address:     'Los Angeles, CA 90036',
  phone:       '+1 (323) 555-0174',
  email:       'landix.ninal@gmail.com',
  instagram:   'https://www.instagram.com/',
  pinterest:   'https://www.pinterest.com/',
  linkedin:    'https://www.linkedin.com/in/allanninal/',
  kofi:        'https://ko-fi.com/allanninal',
  bookingUrl:  'https://calendly.com/',
  coverageArea: 'Greater Los Angeles · Orange County · San Diego · Available to travel nationwide & internationally with client coverage of travel costs.',
  credentials: [
    'Cosmetology License — California State Board #CO-728493',
    'MAC Cosmetics Pro Artist Certified',
    'NAIMIE\'s Beauty Supply Master Class Graduate',
    'Airbrush Certified — Temptu & Dinair Pro Systems',
    'On-Set Film & Television Makeup — Warner Bros. Studio Training',
  ],
  brands: ['NARS', 'Charlotte Tilbury', 'MAC', 'Hourglass', 'Armani Beauty', 'Temptu Airbrush'],
  hours: [
    { day: 'Monday',    open: 'By appointment' },
    { day: 'Tuesday',   open: 'By appointment' },
    { day: 'Wednesday', open: 'By appointment' },
    { day: 'Thursday',  open: 'By appointment' },
    { day: 'Friday',    open: 'By appointment' },
    { day: 'Saturday',  open: 'By appointment' },
    { day: 'Sunday',    open: 'Limited availability' },
  ],
};

export const site = {
  title:         'Camille Voss — Makeup Artist Los Angeles',
  description:
    'Freelance makeup artist in Los Angeles specializing in bridal, editorial, and special-occasion glam. Book Camille for weddings, engagements, commercial shoots, and beauty sessions.',
  language:      'en',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
};

// ─── Stats ────────────────────────────────────────────────────────────────────
export const stats = [
  { value: '9+',    label: 'Years Experience' },
  { value: '400+',  label: 'Brides Beautified' },
  { value: '80+',   label: 'Editorial Credits' },
  { value: '5★',    label: 'Average Review' },
];

// ─── Portfolio gallery ────────────────────────────────────────────────────────
export type PortfolioItem = {
  id:       string;
  category: 'bridal' | 'editorial' | 'glam' | 'special-occasion';
  title:    string;
  caption:  string;
  imageAlt: string;
};

export const portfolio: PortfolioItem[] = [
  {
    id:       'bridal-01',
    category: 'bridal',
    title:    'Garden Bridal',
    caption:  'Soft-glow foundation, champagne lids, rosy nude lip — a romantic garden ceremony look.',
    imageAlt: 'Bride with soft dewy makeup, champagne eye shadow, and rosy nude lips, garden ceremony',
  },
  {
    id:       'bridal-02',
    category: 'bridal',
    title:    'Classic Timeless Bridal',
    caption:  'Porcelain base, sculpted brows, vintage-red lip. Timeless elegance for a Pasadena estate wedding.',
    imageAlt: 'Bride with classic timeless makeup, sculpted brows, and vintage red lips',
  },
  {
    id:       'editorial-01',
    category: 'editorial',
    title:    'High Fashion Editorial',
    caption:  'Graphic liner, metallic lids, bleached brow — published in Vogue Digital May 2024.',
    imageAlt: 'Editorial makeup look with graphic black liner, metallic silver eye shadow, and bleached brows',
  },
  {
    id:       'glam-01',
    category: 'glam',
    title:    'Red Carpet Glam',
    caption:  'Full sculpted contour, dramatic cut-crease, statement lip. SAG Awards pre-show.',
    imageAlt: 'Red carpet makeup with full sculpted contour, cut-crease eye and statement bold lip',
  },
  {
    id:       'bridal-03',
    category: 'bridal',
    title:    'Bohemian Bridal',
    caption:  'Sun-kissed glow, terracotta lids, freckle-enhancing sheer skin finish for a Malibu beach wedding.',
    imageAlt: 'Bohemian bridal makeup with sun-kissed glow, terracotta eye shadow, and natural freckles',
  },
  {
    id:       'editorial-02',
    category: 'editorial',
    title:    'Beauty Campaign',
    caption:  'Ultra-glow hyper-skin editorial for a luxury skincare brand launch campaign.',
    imageAlt: 'Beauty editorial close-up showing luminous glowing skin makeup for luxury skincare campaign',
  },
  {
    id:       'special-occasion-01',
    category: 'special-occasion',
    title:    'Quinceañera Glam',
    caption:  'Vibrant fuchsia eye, glass skin, and couture lashes for a Princess-themed celebration.',
    imageAlt: 'Special occasion makeup with vibrant fuchsia eye shadow, glass skin, and dramatic lashes',
  },
  {
    id:       'glam-02',
    category: 'glam',
    title:    'Night-Out Evening Look',
    caption:  'Smoky charcoal wing, bronzed skin, nude gloss. Hollywood premiere after-party.',
    imageAlt: 'Evening glam makeup with smoky charcoal winged eye, bronzed skin, and nude lip gloss',
  },
];

// ─── Services ─────────────────────────────────────────────────────────────────
export type Service = {
  id:          string;
  name:        string;
  tagline:     string;
  duration:    string;
  price:       string;
  description: string;
  includes:    string[];
  highlight?:  boolean;
};

export const services: Service[] = [
  {
    id:       'bridal-trial',
    name:     'Bridal Trial',
    tagline:  'Perfect your look before the big day.',
    duration: '90 min',
    price:    'From $195',
    description:
      'A dedicated pre-wedding session to design and test your bridal look. We discuss your vision, try styles, and photograph the results so you walk down the aisle with complete confidence.',
    includes: [
      'In-depth bridal consultation',
      'Full makeup application',
      'Photography to review look',
      'Product & touch-up kit recommendations',
      'Credit toward wedding day booking',
    ],
    highlight: false,
  },
  {
    id:       'bridal-day-of',
    name:     'Wedding Day Makeup',
    tagline:  'The most important day — flawlessly executed.',
    duration: '90 min',
    price:    'From $350',
    description:
      'On-location bridal makeup with a kit that\'s entirely professional-grade and camera-tested. Includes touch-up kit handoff and 15-minute look-check before ceremony.',
    includes: [
      'On-location service (travel fees may apply)',
      'Airbrush or traditional foundation',
      'Lash application',
      'Touch-up kit handoff',
      'Last-look ceremony check',
    ],
    highlight: true,
  },
  {
    id:       'bridal-party',
    name:     'Bridal Party Glam',
    tagline:  'Coordinated looks for your whole crew.',
    duration: '45–60 min per person',
    price:    'From $145/person',
    description:
      'Bridesmaids, mothers-of-the-bride, and flower girls. Each person gets a custom look that complements the bridal aesthetic. Minimum 3 guests required for party rate.',
    includes: [
      'Individual consultation per person',
      'Coordinated aesthetic direction',
      'Lash application',
      'Touch-up product for each guest',
    ],
    highlight: false,
  },
  {
    id:       'editorial-session',
    name:     'Editorial / Commercial',
    tagline:  'Portfolio, campaign, and on-set artistry.',
    duration: 'Half or full day',
    price:    'From $600/day',
    description:
      'Professional on-set makeup for fashion editorials, brand campaigns, product launches, and film. Day rate includes wardrobe-pull collaboration and unlimited looks within session.',
    includes: [
      'Pre-shoot concept call',
      'Unlimited looks per shoot',
      'On-set touch-ups throughout',
      'Usage rights consultation',
    ],
    highlight: false,
  },
  {
    id:       'special-occasion',
    name:     'Special Occasion Glam',
    tagline:  'Prom, gala, premiere, or any milestone.',
    duration: '60–75 min',
    price:    'From $175',
    description:
      'Studio or on-location glam for proms, galas, awards events, and life\'s biggest milestones. Includes lashes and a personalized look board.',
    includes: [
      'Look-board inspiration session',
      'Full glam application',
      'Strip or individual lash application',
      'Touch-up kit included',
    ],
    highlight: false,
  },
  {
    id:       'makeup-lesson',
    name:     'Private Makeup Lesson',
    tagline:  'Learn the pro tricks that change everything.',
    duration: '75 min',
    price:    'From $165',
    description:
      'One-on-one lesson tailored to your skill level — from beginner to beauty-enthusiast wanting to master advanced techniques. You leave with a written cheat-sheet of every step.',
    includes: [
      'Skin-prep & foundation matching',
      'Eyes: liner, blending, lash tips',
      'Contouring & highlighting basics',
      'Personalized written cheat-sheet',
    ],
    highlight: false,
  },
];

// ─── Add-ons ──────────────────────────────────────────────────────────────────
export type AddOn = { name: string; price: string; description: string; };

export const addOns: AddOn[] = [
  { name: 'Airbrush Upgrade',       price: '+$45',  description: 'Flawless, long-wearing airbrush foundation in place of traditional application.' },
  { name: 'Individual Lash Set',    price: '+$35',  description: 'Hand-applied individual lash clusters for a custom, natural-glam effect.' },
  { name: 'Glitter & Body Art',     price: '+$30',  description: 'Festival glitter, face gems, or body art detail — proms & themed events.' },
  { name: 'Travel (30+ mi radius)', price: '+$1.50/mi', description: 'Portal-to-portal mileage for on-location services beyond a 30-mile radius of LA.' },
  { name: 'After-Midnight Rate',    price: '+$75',  description: 'Services starting after 9 PM or finishing past midnight.' },
];

// ─── Testimonials ─────────────────────────────────────────────────────────────
export type Testimonial = {
  quote:   string;
  author:  string;
  service: string;
  rating:  number;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      'Camille made me look like the best version of myself — not overdone, not like someone else. I cried the second I looked in the mirror and my mascara didn\'t move an inch all day.',
    author:  'Sophia L.',
    service: 'Wedding Day Makeup — Santa Barbara',
    rating:  5,
  },
  {
    quote:
      'Working with Camille on our spring campaign was an absolute dream. She understood the creative brief immediately and delivered flawless looks that photographed beautifully under every light.',
    author:  'Marcus T., Creative Director',
    service: 'Commercial Editorial — LA Studio',
    rating:  5,
  },
  {
    quote:
      'I\'ve hired Camille for three events now — my engagement party, rehearsal dinner, and wedding. Every single look was perfection. She\'s the only artist I trust for the big moments.',
    author:  'Isabella R.',
    service: 'Bridal Suite — Recurring Client',
    rating:  5,
  },
  {
    quote:
      'The private lesson changed how I do my makeup every single day. I finally understand how to blend properly and my foundation actually matches my neck now. Life-changing, honestly.',
    author:  'Destiny K.',
    service: 'Private Makeup Lesson',
    rating:  5,
  },
  {
    quote:
      'She arrived on time, was so calm and professional, and my bridesmaids looked absolutely stunning. Multiple guests stopped to ask who did our makeup. 10/10.',
    author:  'Lauren M.',
    service: 'Bridal Party — 6 people, Malibu',
    rating:  5,
  },
  {
    quote:
      'I was nervous about my prom look but Camille listened to every detail I wanted and turned my mood board into reality. I felt like a celebrity. Absolutely worth every penny.',
    author:  'Jasmine W.',
    service: 'Special Occasion — Senior Prom',
    rating:  5,
  },
];

// ─── FAQ ─────────────────────────────────────────────────────────────────────
export type FAQ = { q: string; a: string; };

export const faqs: FAQ[] = [
  {
    q: 'Do I need a trial before my wedding?',
    a: 'A trial is strongly recommended and included in all bridal packages. It\'s an opportunity to test the look in real lighting, try different options, and ensure the final look photographs exactly how you envision. Most brides schedule their trial 4–8 weeks before the wedding date.',
  },
  {
    q: 'How far in advance should I book?',
    a: 'Wedding dates — especially Saturdays May through October — book out 6 to 12 months in advance. For editorial and commercial work, 3–4 weeks notice is typically sufficient. Special occasion bookings can often be accommodated within 1–2 weeks depending on calendar availability.',
  },
  {
    q: 'Do you travel to the venue or wedding location?',
    a: 'Yes. All bridal and event services are on-location — I come to your hotel, venue, or home. Travel within 30 miles of central Los Angeles is included. Beyond 30 miles, a travel fee of $1.50/mile (portal-to-portal) applies. For out-of-state weddings, travel and accommodation costs are covered by the client.',
  },
  {
    q: 'How long does bridal makeup take?',
    a: 'The bride\'s makeup typically takes 90 minutes. Bridesmaids and guests average 45–60 minutes each. When building your wedding morning timeline, I recommend scheduling the bride last, right before photography begins, to ensure the freshest possible look.',
  },
  {
    q: 'What products do you use? Can you accommodate sensitive skin?',
    a: 'My kit includes professional-grade products from NARS, Charlotte Tilbury, MAC, Hourglass, and Armani Beauty. For sensitive or reactive skin, please let me know during booking — I carry fragrance-free, mineral, and hypoallergenic alternatives for most steps and can tailor the application to your skin\'s needs.',
  },
  {
    q: 'Do you offer airbrush makeup?',
    a: 'Yes. Airbrush foundation is available as an add-on ($45) or is included in select premium packages. Airbrush is ideal for long-wear events, photography, and humid weather. It delivers an ultra-lightweight, transfer-resistant finish. I use Temptu and Dinair Pro systems.',
  },
  {
    q: 'What is your booking and cancellation policy?',
    a: 'A 30% non-refundable retainer secures your date. The remaining balance is due 72 hours before your appointment. Cancellations with less than 72 hours notice forfeit the full balance. Wedding date changes can typically be accommodated with advance notice and subject to availability.',
  },
  {
    q: 'Can you also do hair styling?',
    a: 'My specialty is makeup artistry. I work closely with a vetted network of bridal hairstylists in the LA area and am happy to coordinate referrals or co-book with a trusted stylist for your wedding day so you have a single seamless team.',
  },
];

// ─── Trust points ─────────────────────────────────────────────────────────────
export type TrustPoint = { icon: string; title: string; body: string; };

export const trustPoints: TrustPoint[] = [
  {
    icon:  '◆',
    title: 'Pro Kit Only',
    body:  'Every product in Camille\'s kit is professional-grade, camera-tested, and vetted for all skin tones and types — nothing drugstore, nothing expired.',
  },
  {
    icon:  '◇',
    title: 'Camera-Ready Guarantee',
    body:  'Whether you\'re in natural light, flash photography, or film lighting, your look is formulated to read beautifully in every frame.',
  },
  {
    icon:  '◈',
    title: 'Sanitized + Safe',
    body:  'Single-use applicators, sanitized brushes, and strict hygiene protocols — your skin\'s safety is as important as your look.',
  },
  {
    icon:  '◉',
    title: 'On-Time, Every Time',
    body:  '9 years of on-set and event work means Camille arrives prepared, sets up quickly, and keeps your morning timeline on track.',
  },
];
