import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir:   './tests',
  fullyParallel: false,
  reporter:  'list',
  use: {
    baseURL:       'http://localhost:4321',
    ...devices['Desktop Chrome'],
    channel:       'chrome',
  },
  webServer: {
    command:           'npm run preview',
    url:               'http://localhost:4321',
    reuseExistingServer: false,
    timeout:           30_000,
  },
});
