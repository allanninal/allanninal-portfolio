import { test, expect } from '@playwright/test';

test.describe('Adeyemi Studio — smoke tests', () => {
  test('the hero leads with the two-price claim, not a single price', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Adeyemi Studio/);
    await expect(page.locator('h1')).toContainText(/two honest prices/i);
  });

  test('primary nav is the page spine, not Home/About/Services', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Primary' });
    const links = await nav.getByRole('link').allTextContents();
    expect(links).toEqual([
      'How to read', 'Line sheet', 'Wholesale terms', 'Sizing', 'Fabric', 'Studio', 'Shop direct', 'Apply', 'FAQ',
    ]);
  });

  // ── Glossary ──────────────────────────────────────────────────────────────
  test('the glossary defines all six terms', async ({ page }) => {
    await page.goto('/');
    const terms = await page.locator('#glossary dl.glossary dt').allTextContents();
    expect(terms).toEqual(['MOQ', 'Colourway', 'Size run', 'Delivery window', 'Pre-book vs. at-once', 'Keystone']);
  });

  // ── The line sheet ───────────────────────────────────────────────────────
  test('the line sheet table lists all eight styles across two delivery groups', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#line-sheet-table tbody tr');
    // 2 group-header rows + 8 style rows
    await expect(rows).toHaveCount(10);
  });

  test('SRP is computed from wholesale at the stated keystone ratio, not typed twice', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#line-sheet-table').innerText();
    // AS-SS27-101: $185 wholesale -> $390 SRP (185 * 2.1 = 388.5, rounded to nearest $5)
    expect(text).toMatch(/\$185/);
    expect(text).toMatch(/\$390/);
    // AS-SS27-107: $240 wholesale -> $505 SRP
    expect(text).toMatch(/\$240/);
    expect(text).toMatch(/\$505/);
  });

  test('every line-sheet row carries a style number, colourway swatches and a delivery group', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#line-sheet-table').innerText();
    expect(text).toMatch(/AS-SS27-101/);
    expect(text).toMatch(/AS-SS27-210/);
    expect(text).toMatch(/Delivery 1/i);
    expect(text).toMatch(/Delivery 2/i);
    const swatches = page.locator('#line-sheet-table svg[role="img"]');
    expect(await swatches.count()).toBeGreaterThanOrEqual(16);
  });

  // ── Wholesale terms ───────────────────────────────────────────────────────
  test('wholesale terms states opening minimum, reorder minimum and payment terms', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#wholesale-terms').innerText();
    expect(text).toMatch(/\$750/);
    expect(text).toMatch(/\$350/);
    expect(text).toMatch(/net 30/i);
  });

  test('current stockists lists at least eight boutiques', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#wholesale-terms .stockist-grid li');
    expect(await items.count()).toBeGreaterThanOrEqual(8);
  });

  // ── Printable line sheet ──────────────────────────────────────────────────
  test('the printable line sheet iframe is same-origin, lazy-loaded and sized to avoid CLS', async ({ page }) => {
    await page.goto('/');
    const iframe = page.locator('#printable iframe');
    await expect(iframe).toHaveAttribute('src', /line-sheet\.html$/);
    await expect(iframe).toHaveAttribute('loading', 'lazy');
    await expect(iframe).toHaveAttribute('width');
    await expect(iframe).toHaveAttribute('height');
    await expect(iframe).toHaveAttribute('title', /.+/);
  });

  test('the printable line-sheet document itself renders both delivery groups', async ({ page }) => {
    const res = await page.goto('/line-sheet.html');
    expect(res?.status()).toBe(200);
    const text = await page.locator('body').innerText();
    expect(text).toMatch(/Delivery 1/i);
    expect(text).toMatch(/Delivery 2/i);
    expect(text).toMatch(/AS-SS27-101/);
  });

  // ── Sizing & grading ──────────────────────────────────────────────────────
  test('the size-grading table runs the full 00–16 size run at a 1-inch increment', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#sizing table.spec tbody tr');
    await expect(rows).toHaveCount(10);
    await expect(rows.first()).toContainText('32');
    await expect(rows.first()).toContainText('24');
    await expect(rows.first()).toContainText('34');
    await expect(rows.last()).toContainText('41');
    await expect(rows.last()).toContainText('33');
    await expect(rows.last()).toContainText('43');
  });

  // ── Fabric & sourcing ─────────────────────────────────────────────────────
  test('fabric & sourcing names composition, mill and care for all three fabrics', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#fabric').innerText();
    expect(text).toMatch(/78% wool/);
    expect(text).toMatch(/98% cotton/);
    expect(text).toMatch(/70% Tencel/);
    expect(text).toMatch(/Dry clean only/);
  });

  // ── Studio & making ───────────────────────────────────────────────────────
  test('studio & making shows the studio, the CMT contractor and construction detail figures', async ({ page }) => {
    await page.goto('/');
    const figures = page.locator('#studio figure.doc-figure');
    expect(await figures.count()).toBeGreaterThanOrEqual(4);
  });

  // ── Shop direct ───────────────────────────────────────────────────────────
  test('shop direct lists 6–8 fixed-price pieces, each with a price', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#shop .store-card');
    const count = await cards.count();
    expect(count).toBeGreaterThanOrEqual(6);
    expect(count).toBeLessThanOrEqual(8);
    for (let i = 0; i < count; i++) {
      await expect(cards.nth(i).locator('.price')).toContainText('$');
    }
  });

  // ── Wholesale account application ────────────────────────────────────────
  test('the wholesale application requires business name, resale number, buyer type and email', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#business-name', '#resale-number', '#buyer-type', '#contact-email']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    const options = await page.locator('#buyer-type option').allTextContents();
    expect(options).toEqual(['Choose one', 'Boutique', 'Department store', 'Online retailer', 'Showroom']);
  });

  test('the order-process ol lists all five steps in order', async ({ page }) => {
    await page.goto('/');
    const items = await page.locator('#apply ol.seq li .k').allTextContents();
    expect(items).toEqual([
      'Request access', 'Review the line sheet', 'Submit a PO', 'Confirm the deposit', 'Ship at the delivery window',
    ]);
  });

  // ── FAQ ───────────────────────────────────────────────────────────────────
  test('FAQ has three questions', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#faq details.faq-item')).toHaveCount(3);
  });

  // ── Schema ────────────────────────────────────────────────────────────────
  test('every style Product carries a settled retail Offer and a settled wholesale Offer', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const productBlock = blocks.find((b) => b.includes('"Product"'))!;
    const products = JSON.parse(productBlock)['@graph'];
    expect(products.length).toBe(8);
    for (const p of products) {
      expect(Array.isArray(p.offers)).toBe(true);
      expect(p.offers).toHaveLength(2);
      const [retail, wholesale] = p.offers;
      expect(typeof retail.price).toBe('number');
      expect(retail.availability).toBe('https://schema.org/InStock');
      expect(wholesale.eligibleCustomerType).toBe('https://schema.org/Business');
      expect(typeof wholesale.priceSpecification.price).toBe('number');
      expect(typeof wholesale.eligibleQuantity.value).toBe('number');
      expect(wholesale.availabilityStarts).toBeTruthy();
      expect(p.gtin).toBeUndefined();
      expect(p.mpn).toBeUndefined();
      expect(p.aggregateRating).toBeUndefined();
    }
  });

  test('no priceValidUntil is emitted anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    expect(html).not.toContain('priceValidUntil');
  });

  test('the Organization schema carries no LocalBusiness opening-hours claim', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const orgBlock = blocks.find((b) => b.includes('"Organization"'))!;
    const org = JSON.parse(orgBlock);
    expect(org.openingHoursSpecification).toBeUndefined();
    expect(org['@type']).toBe('Organization');
    expect(org.brand.name).toBe('Adeyemi Studio');
  });

  // ── Contact ───────────────────────────────────────────────────────────────
  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('.contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Hygiene ───────────────────────────────────────────────────────────────
  test('no trace of earlier-day source templates survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['imogen vasey', 'kelham', 'firescale', 'jewellery', 'ceramicist', 'kiln', 'iris calder']) {
      expect(html, `earlier-day copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('no couple, swim or lingerie framing appears anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['swimwear', 'lingerie', 'bikini']) {
      expect(html, `off-brief copy present: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1920, 1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/window-cleaning/i);
  });

  // The Full Tech Pack is Pro-only. In the free build it must not be reachable
  // as real content — Astro.redirect() renders it as a meta-refresh stub — and
  // it must not be linked from the homepage.
  test('the Pro Full Tech Pack is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="tech-pack"]').count()).toBe(0);

    const res = await page.goto('/tech-pack/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
