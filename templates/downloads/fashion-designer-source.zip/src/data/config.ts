// Amara Adeyemi — Adeyemi Studio. Fictional label, New York Garment
// District. Demo address below is a placeholder; replace it with your own
// before deploying (see README). Structured tailoring only — blazers,
// trousers, wrap coats — no swim, no lingerie, per house convention.
import { SEASON } from '~/data/lineSheet';

export const site = {
  name: 'Adeyemi Studio',
  title: 'Adeyemi Studio — Amara Adeyemi, ready-to-wear line sheet, NYC',
  tagline: `The same coat carries two honest prices — the ${SEASON} line sheet.`,
  owner: 'Amara Adeyemi',
  ownerRole: 'Founder & designer',
  studioName: 'Adeyemi Studio',
  addressLine: '250 W 39th St, Suite 4B',
  city: 'New York',
  state: 'NY',
  zip: '10018',
  country: 'US',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'A NYC structured-tailoring label publishing its wholesale line sheet in the open — style number, ' +
    'colourway, fabric, size run, wholesale price and SRP, side by side, not hidden behind a buyer login.',
  ogImage: '/og-image.png',
};

export const primaryNav = [
  { label: 'How to read', href: '#glossary' },
  { label: 'Line sheet', href: '#line-sheet' },
  { label: 'Wholesale terms', href: '#wholesale-terms' },
  { label: 'Sizing', href: '#sizing' },
  { label: 'Fabric', href: '#fabric' },
  { label: 'Studio', href: '#studio' },
  { label: 'Shop direct', href: '#shop' },
  { label: 'Apply', href: '#apply' },
  { label: 'FAQ', href: '#faq' },
];

export const glossary = [
  {
    term: 'MOQ',
    definition: 'Minimum order quantity — the smallest number of units you can order per colourway, per style. Below the table, that number is 2 or 3 depending on the style.',
  },
  {
    term: 'Colourway',
    definition: 'A style’s available colours for a given season. Two blazers in the same cut but different colourways are the same style number, not two styles.',
  },
  {
    term: 'Size run',
    definition: 'The full span of sizes a style ships in — 00 through 16 across this line sheet. A buyer orders the MOQ spread across the run, not the MOQ in one size.',
  },
  {
    term: 'Delivery window',
    definition: 'The season slot a style ships in. This line sheet has two: Delivery 1 and Delivery 2, each with its own order-cutoff date and ship date.',
  },
  {
    term: 'Pre-book vs. at-once',
    definition: 'A pre-book order is for goods still in production, placed against a future delivery window. An at-once order ships from stock already on hand. Every style below is a pre-book; reorders on the two carryover bestsellers (the Bellwether Blazer, the Cortlandt Trouser) ship at-once from Delivery 1 stock.',
  },
  {
    term: 'Keystone',
    definition: 'The standard 2.0–2.2× markup a retailer applies to a wholesale price to set their own shelf price. Adeyemi Studio publishes both numbers on this line sheet, computed from one keystone ratio — see the line sheet below.',
  },
];

export const wholesaleTerms = {
  openingMinimumUSD: 750,
  reorderMinimumUSD: 350,
  paymentTerms: '50% deposit due at order confirmation; balance invoiced net 30 from ship date.',
  markdownPolicy: 'No markdowns inside the first 90 days from ship date. After 90 days, markdown timing is the retailer’s call — Adeyemi Studio does not chargeback for it.',
  returnPolicy: 'Defective or mis-shipped goods only, reported within 14 days of receipt. No returns for slow sell-through.',
  shipFrom: 'New York, NY 10018 — FOB shipping point, buyer arranges freight.',
};

export const stockists = [
  { name: 'Bellwether & Rye', city: 'Brooklyn, NY' },
  { name: 'Maison Cole', city: 'Chicago, IL' },
  { name: 'The Fitting Room', city: 'Austin, TX' },
  { name: 'Percy Lane', city: 'Portland, OR' },
  { name: 'North & Bond', city: 'Nashville, TN' },
  { name: 'Cambridge & Vine', city: 'Boston, MA' },
  { name: 'Sable Row', city: 'Washington, DC' },
  { name: 'Larkspur Collective', city: 'Los Angeles, CA' },
  { name: 'Fern & Fold', city: 'Toronto, ON' },
  { name: 'Verve Studio', city: 'London, UK' },
];

export const orderProcess = [
  { step: 'Request access', detail: 'Submit the wholesale account application below — business name, resale number, buyer type.' },
  { step: 'Review the line sheet', detail: 'Once approved, you’re working from the same line sheet published on this page — nothing is re-typed or re-priced for you privately.' },
  { step: 'Submit a PO', detail: 'Style numbers, colourways and quantities at or above each style’s MOQ, spread across the size run.' },
  { step: 'Confirm the deposit', detail: '50% deposit due at order confirmation — see Wholesale terms above.' },
  { step: 'Ship at the delivery window', detail: 'Goods ship FOB New York at the delivery window stated on your PO — Delivery 1 or Delivery 2.' },
];

export const faq = [
  {
    q: 'Do you run sample sales?',
    a: 'Twice a year, timed to when each season’s samples come back from market appointments — announced by email to the wholesale list and on Amara’s LinkedIn, not a standing public sale.',
  },
  {
    q: 'Can I cancel or change a PO after it’s placed?',
    a: 'Before the delivery window’s order-cutoff date, yes — email or LinkedIn message Amara directly. After cutoff, goods are already cut against your quantities, so changes are limited to swapping colourways within the same style if fabric allows.',
  },
  {
    q: 'What’s the minimum to reorder a style already in my store?',
    a: `${wholesaleTerms.reorderMinimumUSD > 0 ? `$${wholesaleTerms.reorderMinimumUSD}` : ''} wholesale, same as any reorder — see Wholesale terms above. Reorders on the two carryover styles ship at-once; everything else is next season’s pre-book.`,
  },
];

export const quotes = {
  buyer: {
    text: '“Most line sheets I get are a PDF that goes stale between market week and the actual PO. Amara’s is the same page I can pull up the morning I’m writing the order — same numbers, no surprise when the invoice lands.”',
    cite: 'Dara Whitfield, buyer, Bellwether & Rye',
  },
  designer: {
    text: '“A wholesale price isn’t a discount off the real price. It’s the number a store needs to survive being a store — rent, staff, markdowns. Printing both numbers on the same page is just telling the truth about what a boutique actually pays for.”',
    cite: 'Amara Adeyemi',
  },
};
