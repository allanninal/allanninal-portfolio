// The single source of every style on this page. The line-sheet table, the
// shop-direct cards, the printable public/line-sheet.html document and the
// Product/Offer schema all read from this file — never a second,
// independently-typed copy of the same figures. See RESEARCH.md, "Static-
// only fit".
export type Category = 'Blazer' | 'Trouser' | 'Coat' | 'Vest' | 'Shirt-Jacket';
export type DeliveryWindow = 'Delivery 1' | 'Delivery 2';
export type FabricId = 'wool' | 'cotton-twill' | 'tencel-blend';
export type Colourway = { name: string; hex: string };

export type LineSheetStyle = {
  styleNumber: string;
  name: string;
  category: Category;
  colourways: Colourway[];
  fabricId: FabricId;
  sizeRun: string[];
  wholesaleUSD: number;
  moq: number;
  deliveryWindow: DeliveryWindow;
};

export type FabricInfo = { label: string; composition: string; mill: string; care: string };

// Colourways, named once and reused across styles — a real line-sheet
// convention: a season's colour story repeats across silhouettes rather
// than inventing a new name per garment.
const ECRU: Colourway = { name: 'Ecru', hex: '#E4DCC8' };
const INK_NAVY: Colourway = { name: 'Ink Navy', hex: '#232C3B' };
const ESPRESSO: Colourway = { name: 'Espresso', hex: '#3B2A20' };
const STONE: Colourway = { name: 'Stone', hex: '#C9BEA8' };
const CAMEL: Colourway = { name: 'Camel', hex: '#B9895A' };
const CHARCOAL: Colourway = { name: 'Charcoal', hex: '#3A3A3A' };

export const SIZE_RUN: string[] = ['00', '0', '2', '4', '6', '8', '10', '12', '14', '16'];

export const SEASON = 'Spring/Summer 2027';

export const DELIVERY_INFO: Record<DeliveryWindow, {
  shipStart: string; shipEnd: string; shipLabel: string; cutoff: string; cutoffLabel: string;
}> = {
  'Delivery 1': {
    shipStart: '2027-01-12',
    shipEnd: '2027-01-26',
    shipLabel: 'Ships mid-January 2027',
    cutoff: '2026-11-15',
    cutoffLabel: 'Order by November 15, 2026',
  },
  'Delivery 2': {
    shipStart: '2027-03-09',
    shipEnd: '2027-03-23',
    shipLabel: 'Ships mid-March 2027',
    cutoff: '2027-01-15',
    cutoffLabel: 'Order by January 15, 2027',
  },
};

export const FABRICS: Record<FabricId, FabricInfo> = {
  wool: {
    label: 'Deadstock wool',
    composition: '78% wool / 20% nylon / 2% elastane',
    mill: 'Originally milled in Biella, Italy — bought as mill overstock through a NYC textile jobber',
    care: 'Dry clean only',
  },
  'cotton-twill': {
    label: 'Deadstock cotton twill',
    composition: '98% cotton / 2% elastane',
    mill: 'North Carolina mill overstock, sourced through the same NYC jobber',
    care: 'Machine wash cold, tumble dry low',
  },
  'tencel-blend': {
    label: 'Deadstock Tencel-blend',
    composition: '70% Tencel (lyocell) / 30% cotton',
    mill: 'Portugal mill overstock',
    care: 'Machine wash cold, hang dry',
  },
};

export const LINE_SHEET_STYLES: LineSheetStyle[] = [
  {
    styleNumber: 'AS-SS27-101',
    name: 'The Bellwether Blazer',
    category: 'Blazer',
    colourways: [ECRU, INK_NAVY],
    fabricId: 'wool',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 185,
    moq: 3,
    deliveryWindow: 'Delivery 1',
  },
  {
    styleNumber: 'AS-SS27-104',
    name: 'The Cortlandt Trouser',
    category: 'Trouser',
    colourways: [STONE, INK_NAVY, ESPRESSO],
    fabricId: 'wool',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 98,
    moq: 3,
    deliveryWindow: 'Delivery 1',
  },
  {
    styleNumber: 'AS-SS27-107',
    name: 'The Mercer Wrap Coat',
    category: 'Coat',
    colourways: [CAMEL, CHARCOAL],
    fabricId: 'wool',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 240,
    moq: 2,
    deliveryWindow: 'Delivery 1',
  },
  {
    styleNumber: 'AS-SS27-110',
    name: 'The Ludlow Vest',
    category: 'Vest',
    colourways: [INK_NAVY, ECRU],
    fabricId: 'wool',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 76,
    moq: 3,
    deliveryWindow: 'Delivery 1',
  },
  {
    styleNumber: 'AS-SS27-201',
    name: 'The Delancey Cropped Blazer',
    category: 'Blazer',
    colourways: [ESPRESSO, STONE],
    fabricId: 'cotton-twill',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 172,
    moq: 3,
    deliveryWindow: 'Delivery 2',
  },
  {
    styleNumber: 'AS-SS27-204',
    name: 'The Orchard Wide-Leg Trouser',
    category: 'Trouser',
    colourways: [INK_NAVY, ECRU, CAMEL],
    fabricId: 'cotton-twill',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 104,
    moq: 3,
    deliveryWindow: 'Delivery 2',
  },
  {
    styleNumber: 'AS-SS27-207',
    name: 'The Rivington Wrap Coat',
    category: 'Coat',
    colourways: [CHARCOAL, CAMEL],
    fabricId: 'wool',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 228,
    moq: 2,
    deliveryWindow: 'Delivery 2',
  },
  {
    styleNumber: 'AS-SS27-210',
    name: 'The Essex Shirt-Jacket',
    category: 'Shirt-Jacket',
    colourways: [ECRU, STONE],
    fabricId: 'tencel-blend',
    sizeRun: SIZE_RUN,
    wholesaleUSD: 138,
    moq: 3,
    deliveryWindow: 'Delivery 2',
  },
];
