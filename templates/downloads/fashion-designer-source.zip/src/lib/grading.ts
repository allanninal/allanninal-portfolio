// Adeyemi Studio's own grading rule — a straight 1-inch increment per size
// step across bust, waist and hip, sizes 00–16. Real ready-to-wear grading
// practice varies by house; this is presented as this studio's own stated
// rule (same device as jewelry-designer's STUDIO_LABOUR_RATE_USD_PER_HOUR),
// not a universal industry constant. Base measurements are Amara's own
// size-00 block. Computed once here so the size-grading table on the page
// and the Pro Full Tech Pack (when built) can never disagree.
export const BASE_SIZE = '00';
export const BASE_MEASUREMENTS_IN = { bust: 32, waist: 24, hip: 34 };
export const INCREMENT_IN = 1;

export type GradedRow = { size: string; bust: number; waist: number; hip: number };

export function gradedMeasurements(sizeRun: string[]): GradedRow[] {
  return sizeRun.map((size, i) => ({
    size,
    bust: BASE_MEASUREMENTS_IN.bust + i * INCREMENT_IN,
    waist: BASE_MEASUREMENTS_IN.waist + i * INCREMENT_IN,
    hip: BASE_MEASUREMENTS_IN.hip + i * INCREMENT_IN,
  }));
}
