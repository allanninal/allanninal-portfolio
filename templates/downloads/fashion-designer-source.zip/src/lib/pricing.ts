// The single place the retail number is derived from the wholesale number.
// Every price on this page — the line-sheet table, the shop-direct cards,
// and the Product/Offer schema — reads from here, so the two prices this
// template's whole argument rests on can never quietly disagree with each
// other. See RESEARCH.md, "The axis".
//
// 2.1x is Adeyemi Studio's own stated keystone ratio, not an industry
// average pulled from a public source — same convention as jewelry-designer's
// STUDIO_LABOUR_RATE_USD_PER_HOUR (own rate) vs. GOLD_SPOT (a real, cited,
// third-party observation). Industry convention runs 2.0–2.2x (RepSpark,
// AIMS360, Wearview — see RESEARCH.md); 2.1 sits inside that band.
export const KEYSTONE_RATIO = 2.1;

/** Wholesale × keystone, rounded to the nearest $5 — a real apparel pricing
 *  convention (round-number retail price points), not an arbitrary rounding
 *  choice. */
export function computeSRP(wholesaleUSD: number): number {
  return Math.round((wholesaleUSD * KEYSTONE_RATIO) / 5) * 5;
}

export function formatUSD(n: number): string {
  return `$${n.toLocaleString('en-US')}`;
}
