import { test, expect } from '@playwright/test';

test.describe('Idris Falk — smoke tests', () => {
  test('homepage renders with the artist name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Idris Falk/);
    await expect(page.locator('h1')).toContainText('already seen my best work');
  });

  test('is marked up as a Person, with no business-only fields', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Q1047162');
    expect(json).not.toContain('openingHoursSpecification');
    expect(json).not.toContain('priceRange');
  });

  // ── The invisible ledger ────────────────────────────────────────────────
  test('every entry pairs what was seen against what was there', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#invisible ol.invisible > li');
    const n = await items.count();
    expect(n).toBe(9);
    for (const i of await items.all()) {
      await expect(i.locator('.inv-pair .saw b')).toHaveText('What you saw');
      await expect(i.locator('.inv-pair .was b')).toHaveText('What was there');
      await expect(i.locator('.inv-hours')).toContainText(/\d+ h · \d+ shots/);
    }
  });

  test('the totals are summed from the ledger, not typed', async ({ page }) => {
    await page.goto('/');
    const meta = await page.locator('#invisible .inv-hours').allTextContents();
    let hours = 0, shots = 0;
    for (const m of meta) {
      const g = m.match(/(\d+) h · (\d+) shots/)!;
      hours += Number(g[1]); shots += Number(g[2]);
    }
    const totals = page.locator('#invisible dl.total dd');
    await expect(totals.nth(0)).toHaveText(String(meta.length));
    await expect(totals.nth(1)).toHaveText(String(shots));
    await expect(totals.nth(2)).toHaveText(String(hours));
    // and the hero button reads from the same sum
    await expect(page.locator('h1 ~ div a').first()).toContainText(`${hours} hours`);
    await expect(page.locator('#invisible .eyebrow')).toContainText(`${shots} shots`);
  });

  // The absence of imagery is the argument, not an oversight.
  test('the page carries no images at all, and says why', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('img').count()).toBe(0);
    expect(await page.locator('main svg').count()).toBe(0);
    await expect(page.locator('#faq')).toContainText(/least honest document in this trade/i);
  });

  // ── The plate ───────────────────────────────────────────────────────────
  test('every plate row prints its multiplier as a number', async ({ page }) => {
    await page.goto('/');
    const mults = await page.locator('#plate tbody .mult').allTextContents();
    expect(mults.length).toBeGreaterThan(6);
    for (const m of mults) expect(m.trim()).toMatch(/^×\d+(\.\d+)?$/);
  });

  test('the spread is computed from the table', async ({ page }) => {
    await page.goto('/');
    const mults = (await page.locator('#plate tbody .mult').allTextContents())
      .map((m) => parseFloat(m.replace('×', '')));
    const factor = (Math.max(...mults) / Math.min(...mults)).toFixed(1);
    await expect(page.locator('#plate')).toContainText(`a factor of ${factor}`);
  });

  test('at least one plate condition makes a shot cheaper', async ({ page }) => {
    await page.goto('/');
    const mults = (await page.locator('#plate tbody .mult').allTextContents())
      .map((m) => parseFloat(m.replace('×', '')));
    expect(Math.min(...mults)).toBeLessThan(1);
    await expect(page.locator('#plate')).toContainText(/only row that makes a shot cheaper/i);
  });

  test('the page does not blame the camera department', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#plate')).toContainText(/None of this is a complaint about camera departments/i);
  });

  // ── Versions ────────────────────────────────────────────────────────────
  test('a high version number is presented as healthy', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#versions h2')).toContainText(/^v\d+ is a healthy shot\.$/);
    await expect(page.locator('#versions')).toContainText(/Six is a shot nobody looked at/i);
    expect(await page.locator('#versions ol > li').count()).toBe(4);
  });

  test('a producer is quoted on the budget that missed the invisible work', async ({ page }) => {
    await page.goto('/');
    const q = page.locator('blockquote.said');
    await expect(q).toContainText(/boom removal was a third of the post budget/i);
    await expect(q.locator('cite')).toHaveCount(1);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the brief form asks whether it has been shot yet', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#shot')).toHaveAttribute('required', '');
    await expect(page.locator('label[for="shot"]')).toContainText(/where is it up to/i);
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-106 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['perry adisa', 'athens', 'blocking', 'splining', 'inbetween', 'q266569']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro plate checklist is absent from the free build', async ({ page }) => {
    const res = await page.goto('/plate-checklist/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
