import { chromium } from '@playwright/test';
const b = await chromium.launch({ channel: 'chrome' });
const p = await b.newPage({ viewport: { width: 1280, height: 1100 } });
await p.goto('http://localhost:4399/', { waitUntil: 'networkidle' });
await p.locator('.reframe').scrollIntoViewIfNeeded();
await p.waitForLoadState('networkidle');
await p.waitForFunction(() => [...document.querySelectorAll('.reframe img')].every(i => i.complete && i.naturalWidth > 0));
await p.screenshot({ path: '/tmp/102-reframe2.png' });
await b.close();
