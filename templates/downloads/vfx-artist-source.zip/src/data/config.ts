// Idris Falk — Reno, NV.
//
// Fifth reel-adjacent niche in a row. Days 101, 104, 105 and 106 have each
// taken a different swing at "the reel is not the job", so this one uses the
// fact that is true of VFX and of nothing else in the sprint: when the work
// succeeds, nobody can tell it happened.
//
// Every total the copy quotes is summed from the arrays below.

export const site = {
  name:        'Idris Falk',
  shortName:   'Idris Falk',
  title:       'Idris Falk — VFX artist, Reno',
  tagline:     'You have already seen my best work.',
  owner:       'Idris Falk',
  ownerRole:   'VFX artist and compositor',
  credential:  'Compositing and clean-up for commercial and episodic since 2014',
  city:        'Reno',
  state:       'NV',
  language:    'en',
  phoneDisplay: '(775) 555-0139',
  phoneHref:   '+17755550139',
  email:       'idris@idrisfalk.example',
  streetAddress: '148 Vesta St',
  postalCode:  '89502',
  hours:       'Mon–Fri · compositing, so email beats calling',
  bookingWindow: 'Booking shot work from the last week of the month.',
  description:
    'A VFX artist in Reno. A reel in this trade is explosions, spaceships and a dragon. The ' +
    'working year is rig removal, sky replacement, set extension and a coffee cup that should ' +
    'not be in the shot — every one of them invisible when it works, which is the job.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Invisible work', href: '#invisible' },
  { label: 'The plate',      href: '#plate' },
  { label: 'Versions',       href: '#versions' },
  { label: 'Rates',          href: '#rates' },
  { label: 'Brief',          href: '#brief' },
];

// ── The invisible ledger ──────────────────────────────────────────────────
// Nine real categories of work, each as what an audience saw against what was
// in front of the camera. No images: the whole argument is that the before and
// after look identical, so showing them would demonstrate nothing.

export const invisible = [
  {
    title: 'Rig removal',   hours: 46, shots: 22,
    saw: 'An actor lands from a two-storey drop and walks away.',
    was: 'A stunt performer on eleven visible wires, a crash mat, and two crew members holding a descender in frame.',
    note: 'Wire paint is the single most common thing a compositor actually does, and the only evidence it happened is that you did not see any.',
  },
  {
    title: 'Sky replacement', hours: 31, shots: 14,
    saw: 'A clear evening sky over the hills behind the house.',
    was: 'Flat white overcast, blown out two stops, with a contrail across the top third.',
    note: 'Easy to do badly and very hard to do so nobody notices. The edges of hair and foliage are where it falls apart.',
  },
  {
    title: 'Set extension', hours: 58, shots: 9,
    saw: 'A warehouse forty metres deep with racking to the ceiling.',
    was: 'Nine metres of practical set, a black drape, and a taped line on the floor for eyelines.',
    note: 'The most expensive item on this list per shot, and the one clients are most often surprised to learn was there at all.',
  },
  {
    title: 'Screen inserts', hours: 27, shots: 31,
    saw: 'A phone showing an app, held and tilted.',
    was: 'A phone with a green card taped to it, reflecting the ceiling lights, and a thumb over the corner.',
    note: 'Sounds trivial and is not: the reflection, the moiré and the thumb are three separate problems.',
  },
  {
    title: 'Crowd tiling', hours: 34, shots: 6,
    saw: 'Four thousand people in a stand.',
    was: 'Forty extras moved through six positions, shot six times from a locked-off camera.',
    note: 'The work is not the duplication. It is making sure no two of the same person are ever visible in one frame.',
  },
  {
    title: 'Object removal', hours: 22, shots: 27,
    saw: 'A period street with nothing modern in it.',
    was: 'Yellow lines, three satellite dishes, a wheelie bin and a coffee cup somebody left on a windowsill.',
    note: 'The coffee cup is real and it happens on almost every job. Nobody is careless; a set is a busy place.',
  },
  {
    title: 'Beauty and clean-up', hours: 19, shots: 18,
    saw: 'A face in close-up, lit well.',
    was: 'The same face, plus a boom shadow across one cheek and a continuity mark from an earlier setup.',
    note: 'Kept deliberately conservative, and the line where it stops is a conversation worth having before the shoot rather than in the grade.',
  },
  {
    title: 'Split screens',   hours: 41, shots: 12,
    saw: 'Two characters in one continuous take, one of them played by the same actor.',
    was: 'Two passes on a motion-control move, with a lighting change between them nobody noticed on the day.',
    note: 'Almost always cheaper than the alternative, and almost never budgeted for because it does not look like an effect.',
  },
  {
    title: 'Stabilisation and retime', hours: 29, shots: 16,
    saw: 'A smooth push in, at the right speed.',
    was: 'A handheld take with a bump at frame 60, running about 15% too fast for the cut.',
    note: 'A retime is not a slider. Anything with motion blur has to be rebuilt, and that is where the hours go.',
  },
];

export const invisibleNote =
  'Not one of those shots is on a reel, mine or anybody else\'s, because there is nothing to ' +
  'show — the successful version of every line above is a shot that looks like it came out of ' +
  'the camera that way. That is the structural problem with judging this trade by a portfolio, ' +
  'and it is why the most useful thing I can put on a website is a list rather than a video.';

// ── The plate ─────────────────────────────────────────────────────────────
// Multipliers against the same shot. `state` drives the colour, and the number
// is always printed, so hue never carries the meaning alone.

export const plate = {
  intro:
    'The largest cost driver in visual effects is not the shot. It is what the camera department ' +
    'did or did not do on the day, and a client who reads this table before a shoot saves more ' +
    'money than any negotiation afterwards can recover.',
  rows: [
    { cond: 'Tracking markers, correctly placed',   mult: '×1.0',  state: 'cheap', why: 'The baseline. Twenty minutes of tape on the day, and the track solves itself.' },
    { cond: 'Locked-off camera, no markers',        mult: '×1.2',  state: 'cheap', why: 'Nothing to track. Still needs a clean plate, which is thirty seconds of rolling on an empty set.' },
    { cond: 'Clean plate shot',                     mult: '×0.7',  state: 'cheap', why: 'The only row that makes a shot cheaper. Roll the empty frame before or after the take and the removal work roughly halves.' },
    { cond: 'Lens and camera data recorded',        mult: '×0.9',  state: 'cheap', why: 'Focal length, focus distance, height and tilt. Written down, it is free; reverse-engineered, it is a day.' },
    { cond: 'Handheld, no markers',                 mult: '×4.0',  state: 'dear',  why: 'Every feature has to be hand-tracked frame by frame. This is the single most expensive omission on any set.' },
    { cond: 'Greenscreen lit unevenly',             mult: '×2.5',  state: 'dear',  why: 'A hot spot and a shadow mean two keys and a hand-drawn garbage matte per shot, per frame range.' },
    { cond: 'Hair or foliage against greenscreen',  mult: '×3.0',  state: 'dear',  why: 'Spill on fine detail. Nothing that happens in post fixes what a backlight would have fixed on the day.' },
    { cond: 'Motion blur through the removal area', mult: '×2.0',  state: 'dear',  why: 'The thing being removed is smeared across what stays. There is no clean edge to work to.' },
  ],
  closing:
    'None of this is a complaint about camera departments, who are solving a different set of ' +
    'problems under more pressure. It is an argument for having somebody from post in the room ' +
    'for one hour before the shoot, which is the cheapest hour on any production.',
};

// ── Versions ──────────────────────────────────────────────────────────────

export const versions = {
  typical: 40,
  breakdown: [
    { band: 'v1 – v8',   what: 'Technical. Track, roto, keys. Nothing anybody would show a client yet.' },
    { band: 'v9 – v20',  what: 'The shot exists and is wrong in interesting ways. Most client notes land here and most of them are right.' },
    { band: 'v21 – v34', what: 'Integration. Grain, edges, light wrap, the reasons a good composite stops looking like two images.' },
    { band: 'v35 – v40+', what: 'Notes from people who have now watched it two hundred times, and a final that differs from v35 in ways only the four of us can see.' },
  ],
  note:
    'A client who reads "v37" in a filename and hears thrashing will start asking for fewer ' +
    'iterations, and fewer iterations is the one thing guaranteed to make the shot worse. Forty ' +
    'versions on a hero shot is a healthy shot. Six is a shot nobody looked at.',
};

export const said = {
  text: 'We budgeted the dragon and forgot the ninety shots with a boom in them. The dragon came in on the number. The boom removal was a third of the post budget and none of it is on anybody\'s reel.',
  who: 'Line producer, six-part drama — on why the invisible list now goes in the budget first',
};

export const rates = {
  rows: [
    { what: 'Clean-up and removal',   figure: '$85 / hr',   note: 'Quoted per shot after seeing the plate, never per second. Two shots of identical length can differ by a factor of six — see the plate table.' },
    { what: 'Compositing, per shot',  figure: 'From $420',  note: 'For a straightforward green key or sky with a usable plate. The word "usable" is doing all the work in that sentence.' },
    { what: 'On-set supervision',     figure: '$780 / day', note: 'The cheapest line on this list by a wide margin, because it is the one that prevents the ×4.0 row from ever happening.' },
    { what: 'Bid from a shot list',   figure: 'Free',       note: 'Send the edit and the plates. You get a per-shot number and an honest note about which shots I think you do not need.' },
    { what: 'Rush',                   figure: 'No premium', note: 'I will either take it or say no. Charging more for a deadline I have already agreed to would be charging for my own scheduling.' },
  ],
};

export const faqs = [
  {
    q: 'Why is there no reel on this page?',
    a: 'There is one, and it goes out in the first email. It is also the least honest document in this trade — mine included — because it is necessarily made of the small fraction of the work that is allowed to be visible. The list on this page is the other 90%.',
  },
  {
    q: 'Can you fix it in post?',
    a: 'Usually yes, and the plate table is what it costs. The question worth asking is not whether it can be fixed but whether one hour of planning before the shoot would have made it free, and for most of that table the answer is yes.',
  },
  {
    q: 'How many versions should we expect?',
    a: 'Around forty on a hero shot, and that is a healthy number rather than a worrying one. Read the versions section — a shot that arrives at v6 is a shot nobody has really looked at.',
  },
  {
    q: 'Do you do CG, or only compositing?',
    a: 'Compositing, clean-up and integration, plus straightforward CG elements. For a creature or a full CG environment I will tell you that on the first call and point you somewhere better rather than learning on your budget.',
  },
  {
    q: 'What do you need from us on the day?',
    a: 'Markers, a clean plate, and the lens data written down. Those three things move most shots from the bottom half of the plate table to the top, and all three are free.',
  },
  {
    q: 'Can we see the before and after?',
    a: 'Yes, and it is genuinely the most persuasive thing I have — but only after the fact. Before you hire anybody, the useful comparison is not a breakdown video; it is whether they can tell you in advance what your plates are going to cost.',
  },
];
