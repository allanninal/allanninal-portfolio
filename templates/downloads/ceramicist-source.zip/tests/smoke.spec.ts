import { test, expect } from '@playwright/test';

test.describe('Calder Studio Pottery — smoke tests', () => {
  test('the hero leads with the firing claim, not a photo', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Calder Studio Pottery/);
    await expect(page.locator('h1')).toContainText(/Firing №47.*cone 6.*14 in.*12 out/i);
    expect(await page.locator('img, picture').count()).toBe(0);
  });

  // ── Navigation ───────────────────────────────────────────────────────────
  test('primary nav is firing numbers, not Home/About/Services', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Firing log' });
    const links = await nav.getByRole('link').allTextContents();
    expect(links).toEqual(['№44', '№45', '№46', '№47']);
  });

  // ── The log ──────────────────────────────────────────────────────────────
  test('four firing articles, each with a dl of parameters and a count table', async ({ page }) => {
    await page.goto('/');
    const articles = page.locator('article.firing-entry');
    expect(await articles.count()).toBe(4);
    for (let i = 0; i < 4; i++) {
      const article = articles.nth(i);
      const dl = article.locator('dl.params');
      const terms = await dl.locator('dt').allTextContents();
      expect(terms).toEqual(['Cone', 'Ramp', 'Atmosphere', 'Hold at peak']);
      expect(await article.locator('table').count()).toBe(1);
    }
  });

  test('every firing table sums count-in to count-out plus every named loss', async ({ page }) => {
    await page.goto('/');
    const expected = [
      { number: 44, in: 10, out: 9 },
      { number: 45, in: 9, out: 8 },
      { number: 46, in: 12, out: 11 },
      { number: 47, in: 14, out: 12 },
    ];
    for (const f of expected) {
      const article = page.locator(`#firing-${f.number}`);
      const rows = article.locator('table.spec tbody tr');
      const counts = (await rows.locator('td').allTextContents()).map((t) => parseInt(t, 10));
      const sum = counts.reduce((a, b) => a + b, 0);
      expect(sum, `firing ${f.number} count table does not sum to countIn`).toBe(f.in);
      expect(counts[0], `firing ${f.number} fired-successfully count`).toBe(f.out);
    }
  });

  test('the studio’s overall loss rate is computed, not restated, and lands near 1 in 9', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#the-log').innerText();
    expect(text).toMatch(/45 pieces/);
    expect(text).toMatch(/40 of them/);
    expect(text).toMatch(/5 lost/);
    expect(text).toMatch(/11\.1%/);
  });

  test('every survivor gets a shrinkage figure, and the total matches the Collection table', async ({ page }) => {
    await page.goto('/');
    const figures = page.locator('.firing-entry figure.shrink-figure');
    expect(await figures.count()).toBe(40);
    const rows = await page.locator('#collection table.spec tbody tr').count();
    expect(rows).toBe(40);
  });

  test('cone 6 heat-work chart states the real degree spread by ramp speed', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#the-log').innerText();
    expect(text).toMatch(/2165/);
    expect(text).toMatch(/2232/);
    expect(text).toMatch(/2269/);
  });

  // ── Collection / shop ────────────────────────────────────────────────────
  test('the collection lists all 40 finished pieces, sold ones stay listed', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#collection caption')).toContainText('40 finished pieces');
    const soldRows = page.locator('#collection table.spec tbody tr:has(td.status-sold-out)');
    expect(await soldRows.count()).toBeGreaterThan(0);
    const soldText = await soldRows.first().locator('td.status-sold-out').innerText();
    expect(soldText.trim()).toBe('Sold');
  });

  test('every thrown → fired dimension in the table is computed from the stated shrinkage rate', async ({ page }) => {
    await page.goto('/');
    const row = page.locator('#collection table.spec tbody tr#mug-1');
    await expect(row).toContainText('8.2 cm');
    await expect(row).toContainText('7.2 cm'); // 8.2 * (1 - 0.125), rounded to 1 decimal
  });

  test('in-stock pieces link to a real Buy target, sold pieces do not', async ({ page }) => {
    await page.goto('/');
    const buyLinks = page.locator('#collection a', { hasText: 'Buy' });
    expect(await buyLinks.count()).toBeGreaterThan(0);
    for (const href of await buyLinks.evaluateAll((as) => as.map((a) => a.getAttribute('href')))) {
      expect(href).toMatch(/^https:\/\//);
    }
  });

  test('a shrinkage figure links straight into its Collection row', async ({ page }) => {
    await page.goto('/');
    const figLink = page.locator('.firing-entry figcaption a').first();
    const href = await figLink.getAttribute('href');
    expect(href).toMatch(/#[\w-]+$/);
    const id = href!.split('#')[1];
    await expect(page.locator(`#${id}`)).toBeVisible();
  });

  // ── Cone & food-safety table ─────────────────────────────────────────────
  test('the food-safety table computes vitrification, and the hypothetical row fails on purpose', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#food-safety table.spec tbody tr');
    const count = await rows.count();
    expect(count).toBeGreaterThanOrEqual(6);
    const last = rows.nth(count - 1);
    await expect(last).toContainText('hypothetical');
    await expect(last.locator('td').nth(2)).toContainText(/No/);
    const first = rows.nth(0);
    await expect(first.locator('td').nth(2)).toContainText(/Yes/);
  });

  // ── Studio visit ─────────────────────────────────────────────────────────
  test('the studio-visit map is a same-origin iframe, not a third party', async ({ page }) => {
    await page.goto('/');
    const iframe = page.locator('#studio-visit iframe');
    await expect(iframe).toHaveCount(1);
    const src = await iframe.getAttribute('src');
    expect(src).toMatch(/studio-location\.html$/);
    expect(src).not.toMatch(/google|mapbox|openstreetmap/i);
    await expect(iframe).toHaveAttribute('title', /.+/);
    await expect(iframe).toHaveAttribute('loading', 'lazy');
    await expect(iframe).toHaveAttribute('width', /.+/);
    await expect(iframe).toHaveAttribute('height', /.+/);
  });

  // ── Schema ───────────────────────────────────────────────────────────────
  test('every catalogue Product carries a settled price and availability', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const productBlock = blocks.find((b) => b.includes('"Product"'))!;
    const products = JSON.parse(productBlock)['@graph'];
    expect(products.length).toBe(40);
    for (const p of products) {
      expect(typeof p.offers.price).toBe('number');
      expect(['https://schema.org/InStock', 'https://schema.org/SoldOut']).toContain(p.offers.availability);
    }
    const soldOut = products.filter((p: any) => p.offers.availability === 'https://schema.org/SoldOut');
    expect(soldOut.length).toBeGreaterThan(0);

    const all = blocks.join('');
    expect(all).not.toContain('aggregateRating');
  });

  test('LocalBusiness withholds priceRange and aggregateRating', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const lbBlock = blocks.find((b) => b.includes('"LocalBusiness"'))!;
    const lb = JSON.parse(lbBlock);
    expect(lb.priceRange).toBeUndefined();
    expect(lb.aggregateRating).toBeUndefined();
    expect(lb.address.streetAddress).toBeTruthy();
  });

  test('no Offer is emitted anywhere for a commission', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const all = blocks.join('');
    expect(all).not.toMatch(/[Cc]ommission.*Offer/);
  });

  // ── Commissions form ─────────────────────────────────────────────────────
  test('the commission form asks what kind of piece, and states the physics-driven lead time', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#body-or-form', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    const text = await page.locator('#commission').innerText();
    expect(text).toMatch(/3.{1,2}5 weeks/);
  });

  // ── Contact ──────────────────────────────────────────────────────────────
  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('.contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Hygiene ──────────────────────────────────────────────────────────────
  test('no trace of the day-130 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['teresa', 'ibarra', 'painting', 'varnish', 'linen', 'pigment']) {
      expect(html, `day-130 copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/general-contractor/i);
  });

  // The firing-record page is Pro-only. In the free build it must not be
  // reachable as real content — Astro.redirect() renders it as a meta-refresh
  // stub — and it must not be linked from the homepage.
  test('the Pro firing & glaze record is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="firing-record"]').count()).toBe(0);

    const res = await page.goto('/firing-record/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
