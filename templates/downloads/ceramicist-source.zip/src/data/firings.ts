// Every kiln load this studio has fired recently, with the honest count —
// loaded in, fired out — and the named reason for every loss. The loss rate
// shown anywhere on this page is (in − out) / in, computed in
// src/lib/ceramics.ts from the countIn/countOut pairs below, not a
// restated estimate: see totalLossRate() in that file for the aggregate
// across all four firings, which lands at "about 1 in 9, ~11%" — inside the
// 5–15% range MakerCost cites as typical even for an experienced potter
// (RESEARCH.md).
import type { ClayBodyId } from '~/data/clayBodies';
import type { RampId } from '~/lib/ceramics';

export type FailureReason =
  | 'S-crack'
  | 'Dunting'
  | 'Glaze crawl'
  | 'Glaze crawl (shiver)';

export type Failure = { reason: FailureReason; count: number; note: string };

export type Firing = {
  number: number;
  date: string;
  clayBodiesLoaded: ClayBodyId[];
  targetCone: '6';
  ramp: RampId;
  atmosphere: 'Oxidation';
  holdMinutes: number;
  countIn: number;
  countOut: number;
  failures: Failure[];
};

export const firings: Firing[] = [
  {
    number: 44,
    date: '2026-06-08',
    clayBodiesLoaded: ['stoneware'],
    targetCone: '6',
    ramp: 'standard',
    atmosphere: 'Oxidation',
    holdMinutes: 10,
    countIn: 10,
    countOut: 9,
    failures: [
      { reason: 'S-crack', count: 1, note: 'A trimmed mug base, dried too fast under the studio fan — the crack opened at bisque, not glaze.' },
    ],
  },
  {
    number: 45,
    date: '2026-07-01',
    clayBodiesLoaded: ['porcelain'],
    targetCone: '6',
    ramp: 'slow',
    atmosphere: 'Oxidation',
    holdMinutes: 10,
    countIn: 9,
    countOut: 8,
    failures: [
      { reason: 'Dunting', count: 1, note: 'A tall bud vase cracked on cooling through the 573°C quartz inversion — the slow ramp up wasn’t matched by an equally careful cool-down that load.' },
    ],
  },
  {
    number: 46,
    date: '2026-07-22',
    clayBodiesLoaded: ['stoneware', 'porcelain'],
    targetCone: '6',
    ramp: 'standard',
    atmosphere: 'Oxidation',
    holdMinutes: 10,
    countIn: 12,
    countOut: 11,
    failures: [
      { reason: 'Glaze crawl', count: 1, note: 'Amber Celadon pulled away from a dusty rim on a plate that wasn’t wiped clean before dipping.' },
    ],
  },
  {
    number: 47,
    date: '2026-08-19',
    clayBodiesLoaded: ['stoneware'],
    targetCone: '6',
    ramp: 'standard',
    atmosphere: 'Oxidation',
    holdMinutes: 10,
    countIn: 14,
    countOut: 12,
    failures: [
      { reason: 'Dunting', count: 1, note: 'A thick-footed mug, cooled on the studio’s standard schedule, cracked at the same 573°C inversion point.' },
      { reason: 'Glaze crawl (shiver)', count: 1, note: 'Cobalt Speckle shivered off a rim where the glaze layer ran thick — a fit problem between glaze and body, not a firing-temperature problem.' },
    ],
  },
];

export const latestFiring = firings[firings.length - 1];
