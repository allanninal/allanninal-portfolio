// Every finished, surviving piece from the four firings in src/data/firings.ts —
// count for count. Each firing's `countOut` above is the number of rows
// below tagged with that `firingNumber`; the two can never quietly drift
// apart because there is only one array of pieces, read by both the
// Collection table and the firing log's per-firing figures.
//
// `thrownDiameterCm` / `thrownHeightCm` are the only size numbers typed by
// hand — the fired size shown everywhere on the page is
// firedDimension(thrown, clayBody.shrinkageRate), computed in
// src/pages/index.astro from src/lib/ceramics.ts, never re-typed.
//
// One-of-a-kind: a `sold-out` piece stays listed rather than disappearing —
// it is the only one of itself, and the firing log above already proves it
// existed. `paymentLink` is a placeholder Stripe Payment Link; replace it
// with your own before shipping (see README).
import type { ClayBodyId } from '~/data/clayBodies';
import type { GlazeId } from '~/data/glazes';

export type Form = 'Mug' | 'Bowl' | 'Plate' | 'Vase' | 'Tumbler' | 'Bud vase';
export type Series = 'stoneware-tableware' | 'porcelain-vessels';
export type Status = 'in-stock' | 'sold-out';

export type Piece = {
  id: string;
  title: string;
  form: Form;
  series: Series;
  clayBodyId: ClayBodyId;
  glazeId: GlazeId;
  firingNumber: number;
  thrownDiameterCm: number;
  thrownHeightCm: number;
  priceUSD: number;
  status: Status;
  paymentLink: string;
};

type Row = [num: number, firingNumber: number, diameterCm: number, heightCm: number, priceUSD: number, status: Status, glazeId: GlazeId];

function build(form: Form, series: Series, clayBodyId: ClayBodyId, rows: Row[]): Piece[] {
  const slug = form.toLowerCase().replace(/\s+/g, '-');
  return rows.map(([num, firingNumber, diameterCm, heightCm, priceUSD, status, glazeId]) => ({
    id: `${slug}-${num}`,
    title: `${form} No. ${num}`,
    form,
    series,
    clayBodyId,
    glazeId,
    firingNumber,
    thrownDiameterCm: diameterCm,
    thrownHeightCm: heightCm,
    priceUSD,
    status,
    paymentLink: `https://buy.stripe.com/YOUR_PAYMENT_LINK_${slug}-${num}`,
  }));
}

const MUGS: Row[] = [
  [1, 44, 8.2, 11.5, 42, 'sold-out', 'satin-matte-white'],
  [2, 44, 8.5, 12.0, 42, 'in-stock', 'cobalt-speckle'],
  [3, 44, 8.0, 11.0, 38, 'in-stock', 'amber-celadon'],
  [4, 44, 8.6, 12.2, 44, 'sold-out', 'satin-matte-white'],
  [5, 44, 8.3, 11.8, 42, 'in-stock', 'cobalt-speckle'],
  [6, 47, 8.4, 12.0, 44, 'in-stock', 'amber-celadon'],
  [7, 47, 8.1, 11.4, 40, 'in-stock', 'satin-matte-white'],
  [8, 47, 8.7, 12.4, 46, 'sold-out', 'cobalt-speckle'],
  [9, 47, 8.2, 11.6, 42, 'in-stock', 'amber-celadon'],
  [10, 47, 8.5, 12.0, 44, 'in-stock', 'satin-matte-white'],
  [11, 47, 8.0, 11.2, 38, 'sold-out', 'cobalt-speckle'],
  [12, 47, 8.9, 12.6, 48, 'in-stock', 'amber-celadon'],
];

const BOWLS: Row[] = [
  [1, 44, 18.0, 7.5, 62, 'in-stock', 'amber-celadon'],
  [2, 44, 20.5, 8.2, 72, 'sold-out', 'honey-speckle'],
  [3, 44, 16.0, 6.8, 55, 'in-stock', 'amber-celadon'],
  [4, 44, 22.0, 9.0, 78, 'in-stock', 'honey-speckle'],
  [5, 47, 17.5, 7.2, 60, 'in-stock', 'amber-celadon'],
  [6, 47, 19.0, 7.8, 65, 'sold-out', 'honey-speckle'],
  [7, 47, 21.5, 8.6, 75, 'in-stock', 'amber-celadon'],
  [8, 47, 15.5, 6.5, 52, 'in-stock', 'honey-speckle'],
  [9, 47, 18.5, 7.6, 63, 'in-stock', 'amber-celadon'],
];

const PLATES: Row[] = [
  [1, 46, 26.0, 2.4, 68, 'in-stock', 'satin-matte-white'],
  [2, 46, 28.0, 2.6, 74, 'sold-out', 'satin-matte-white'],
  [3, 46, 24.5, 2.2, 62, 'in-stock', 'satin-matte-white'],
  [4, 46, 27.0, 2.5, 70, 'in-stock', 'satin-matte-white'],
  [5, 46, 25.0, 2.3, 65, 'in-stock', 'satin-matte-white'],
  [6, 46, 29.0, 2.7, 78, 'sold-out', 'satin-matte-white'],
];

const VASES: Row[] = [
  [1, 45, 10.5, 24.0, 95, 'in-stock', 'porcelain-clear'],
  [2, 45, 9.0, 21.0, 85, 'sold-out', 'cobalt-speckle'],
  [3, 45, 12.0, 27.0, 110, 'in-stock', 'porcelain-clear'],
  [4, 46, 8.5, 19.0, 80, 'in-stock', 'cobalt-speckle'],
  [5, 46, 11.0, 25.5, 100, 'in-stock', 'porcelain-clear'],
  [6, 46, 9.5, 22.0, 88, 'sold-out', 'cobalt-speckle'],
];

const TUMBLERS: Row[] = [
  [1, 45, 7.2, 11.5, 34, 'in-stock', 'porcelain-clear'],
  [2, 45, 7.5, 12.0, 36, 'in-stock', 'porcelain-clear'],
  [3, 45, 7.0, 11.2, 32, 'sold-out', 'porcelain-clear'],
  [4, 46, 7.4, 11.8, 35, 'in-stock', 'porcelain-clear'],
  [5, 46, 7.6, 12.2, 37, 'in-stock', 'porcelain-clear'],
];

const BUD_VASES: Row[] = [
  [1, 45, 5.5, 15.0, 30, 'in-stock', 'cobalt-speckle'],
  [2, 45, 6.0, 16.5, 32, 'sold-out', 'cobalt-speckle'],
];

export const pieces: Piece[] = [
  ...build('Mug', 'stoneware-tableware', 'stoneware', MUGS),
  ...build('Bowl', 'stoneware-tableware', 'stoneware', BOWLS),
  ...build('Plate', 'stoneware-tableware', 'stoneware', PLATES),
  ...build('Vase', 'porcelain-vessels', 'porcelain', VASES),
  ...build('Tumbler', 'porcelain-vessels', 'porcelain', TUMBLERS),
  ...build('Bud vase', 'porcelain-vessels', 'porcelain', BUD_VASES),
];

export function piecesForFiring(firingNumber: number): Piece[] {
  return pieces.filter((p) => p.firingNumber === firingNumber);
}

export const seriesLabel: Record<Series, string> = {
  'stoneware-tableware': 'Stoneware tableware',
  'porcelain-vessels': 'Porcelain vessels',
};
