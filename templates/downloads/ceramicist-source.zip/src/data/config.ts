// Iris Calder — Calder Studio Pottery. Fictional studio, Hudson Valley, NY.
// Demo address below is a placeholder; replace it with your own before
// deploying (see README).
import { firings } from '~/data/firings';

export const site = {
  name: 'Calder Studio Pottery',
  title: 'Calder Studio Pottery — Iris Calder, studio potter',
  tagline: `Firing №${firings[firings.length - 1].number} — cone 6, ${firings[firings.length - 1].countIn} in, ${firings[firings.length - 1].countOut} out.`,
  owner: 'Iris Calder',
  ownerRole: 'Studio potter',
  studioName: 'Calder Studio Pottery',
  addressLine: '118 Kettlebrook Farm Road',
  city: 'Rhinecliff Hollow',
  state: 'NY',
  zip: '12572',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'A single-kiln stoneware and porcelain studio that publishes the arithmetic a gallery photo hides: ' +
    'the fired size computed from shrinkage, and the loss rate computed from every kiln load, next to every piece.',
  ogImage: '/og-image.png',
};

export const firingNav = firings.map((f) => ({
  label: `№${f.number}`,
  href: `#firing-${f.number}`,
}));

export const secondaryNav = [
  { label: 'The log', href: '#the-log' },
  { label: 'Collection', href: '#collection' },
  { label: 'Cone & food safety', href: '#food-safety' },
  { label: 'Studio visit', href: '#studio-visit' },
  { label: 'Commissions', href: '#commission' },
];

export const howAPieceGetsToYou = [
  {
    step: 'Local pickup',
    detail: 'Preferred whenever it works — no packing risk, and you get to see the whole shelf, not just the one piece.',
  },
  {
    step: 'Insured shipping',
    detail: 'For everything else. Stoneware and porcelain ship double-boxed with a rigid interior liner; insured for the full listed price.',
  },
  {
    step: 'Payment',
    detail: 'Each in-stock piece links to its own Stripe Payment Link below — one object, one price, no cart. Sold pieces stay listed, marked Sold, because a one-of-a-kind object doesn’t stop existing when it sells.',
  },
];

export const commissionLeadTime = [
  { step: 'Throw', detail: 'The piece is thrown to order, sized against the same shrinkage math the catalogue uses.' },
  { step: 'Dry', detail: '3–7 days, slow and covered, so the walls don’t dry faster than the base and open an S-crack.' },
  { step: 'Bisque fire', detail: 'A first, lower firing hardens the clay enough to handle and glaze.' },
  { step: 'Glaze', detail: 'Glaze is applied to the bisqued piece by hand, dipped or brushed depending on the form.' },
  { step: 'Glaze-fire', detail: 'Cone 6, oxidation, the same kiln and schedule as every firing in the log above.' },
  { step: 'Cool', detail: 'A full, unhurried cool through the 573°C quartz inversion — the point most dunting cracks happen if it’s rushed.' },
];

export const faq = [
  {
    q: 'Why did my mug cost more than the one on Etsy?',
    a: 'That price already contains the third of a kiln load that didn’t survive the fire — the log above states the studio’s own rate, about 1 in 9. A price that doesn’t account for loss is a price that hasn’t looked at its own kiln.',
  },
  {
    q: 'Is this dishwasher safe?',
    a: 'If the body vitrified at cone 6 and the glaze is food-safe, yes — see the Cone & food-safety table below for the specific body/glaze pairs this studio uses, computed, not just claimed on a label.',
  },
  {
    q: 'Why do two mugs from the same firing look slightly different?',
    a: 'Kiln placement and the same shrinkage math: a mug nearer the element sees a slightly different heat-work curve than one on the cool side of the shelf, and even a stated 12.5% shrinkage rate is an average, not a guarantee down to the millimetre.',
  },
];
