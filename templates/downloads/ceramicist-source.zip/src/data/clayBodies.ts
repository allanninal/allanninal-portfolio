// Calder Studio Pottery fires a single 10 cu ft electric kiln to cone 6 in
// oxidation — no reduction claims, no gas kiln. Every dimension shown on
// this site is computed from the shrinkage rate below, at build time, from
// this file — src/lib/ceramics.ts's firedDimension() is the only place the
// arithmetic happens. Rates sit inside the published ranges cited in
// RESEARCH.md (stoneware 11–13% at cone 6–9, porcelain 12–16%) as the
// studio's own tested figures.
import type { ConeId } from '~/lib/ceramics';

export type ClayBodyId = 'stoneware' | 'porcelain';

export type ClayBody = {
  id: ClayBodyId;
  name: string;
  shrinkageRate: number;
  vitrifiesAtCone: ConeId;
  line: string;
  note: string;
};

export const CLAY_BODIES: Record<ClayBodyId, ClayBody> = {
  stoneware: {
    id: 'stoneware',
    name: 'Stoneware',
    shrinkageRate: 0.125,
    vitrifiesAtCone: '6',
    line: 'Tableware line',
    note: 'A mid-fire speckled stoneware, tested at 12.5% total wet-to-fired shrinkage in this kiln — mugs, bowls and plates that see a dishwasher.',
  },
  porcelain: {
    id: 'porcelain',
    name: 'Porcelain',
    shrinkageRate: 0.145,
    vitrifiesAtCone: '6',
    line: 'Vessel line',
    note: 'A translucent mid-fire porcelain, tested at 14.5% shrinkage — more vitreous than the stoneware body, so it shrinks more. Thrown thin for vases, tumblers and bud vases.',
  },
};

export const clayBodies = Object.values(CLAY_BODIES);
