// Five glaze recipes in rotation, all mixed and fired for cone 6 oxidation —
// the only atmosphere this single-kiln studio runs. Every one is a
// commercially formulated, lead-free, food-safe recipe at its stated cone;
// none of it is stoneware wood-ash mythology or a reduction claim.
import type { ClayBodyId } from '~/data/clayBodies';
import type { ConeId } from '~/lib/ceramics';

export type GlazeId =
  | 'amber-celadon'
  | 'satin-matte-white'
  | 'cobalt-speckle'
  | 'porcelain-clear'
  | 'honey-speckle';

export type Glaze = {
  id: GlazeId;
  name: string;
  coneLabel: string;
  cone: ConeId;
  bodies: ClayBodyId[];
  foodSafe: boolean;
  leadFree: boolean;
  hex: string;
  finish: 'Glossy' | 'Satin matte' | 'Matte';
  note: string;
};

export const GLAZES: Record<GlazeId, Glaze> = {
  'amber-celadon': {
    id: 'amber-celadon',
    name: 'Amber Celadon',
    coneLabel: 'Cone 5–6',
    cone: '6',
    bodies: ['stoneware'],
    foodSafe: true,
    leadFree: true,
    hex: '#8C9B72',
    finish: 'Glossy',
    note: 'Breaks amber over the speckled stoneware body wherever it pools thin over throwing rings.',
  },
  'satin-matte-white': {
    id: 'satin-matte-white',
    name: 'Satin Matte White',
    coneLabel: 'Cone 6',
    cone: '6',
    bodies: ['stoneware', 'porcelain'],
    foodSafe: true,
    leadFree: true,
    hex: '#EDEAE0',
    finish: 'Satin matte',
    note: 'The everyday liner glaze — craze-free at this kiln’s cooling rate, tested food-contact safe.',
  },
  'cobalt-speckle': {
    id: 'cobalt-speckle',
    name: 'Cobalt Speckle',
    coneLabel: 'Cone 6',
    cone: '6',
    bodies: ['stoneware', 'porcelain'],
    foodSafe: true,
    leadFree: true,
    hex: '#2E3E7C',
    finish: 'Glossy',
    note: 'Cobalt oxide, the oldest ceramic colourant on record, speckled by the iron in the stoneware body underneath it.',
  },
  'porcelain-clear': {
    id: 'porcelain-clear',
    name: 'Porcelain Clear',
    coneLabel: 'Cone 6',
    cone: '6',
    bodies: ['porcelain'],
    foodSafe: true,
    leadFree: true,
    hex: '#F2EEE6',
    finish: 'Glossy',
    note: 'A near-invisible clear liner that lets the porcelain’s own translucency read through the wall of a thin vessel.',
  },
  'honey-speckle': {
    id: 'honey-speckle',
    name: 'Honey Speckle',
    coneLabel: 'Cone 6',
    cone: '6',
    bodies: ['stoneware'],
    foodSafe: true,
    leadFree: true,
    hex: '#B9843F',
    finish: 'Matte',
    note: 'An iron-speckled matte, warmest of the five, reserved for bowls and the shallow flare of a plate rim.',
  },
};

export const glazes = Object.values(GLAZES);
