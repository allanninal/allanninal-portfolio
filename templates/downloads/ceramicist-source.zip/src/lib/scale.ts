// One scale for every shrinkage figure on the page, so a mug's circle and a
// plate's circle are honestly comparable to each other, the same device
// RoomCanvas-style templates use for paintings — here, diameter in plan
// view rather than a wall rectangle.
export const PX_PER_CM = 6;
export const FIGURE_PAD = 14;
