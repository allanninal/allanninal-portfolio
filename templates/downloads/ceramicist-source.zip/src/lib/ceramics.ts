// The shrinkage math and the loss-rate math, in one place, so the catalogue
// and the firing log are computed from the same functions and can never
// quietly disagree with each other. See RESEARCH.md, "The axis".

// ── Shrinkage: thrown dimension → fired dimension ───────────────────────
// A stated shrinkage rate is a fact about a clay body (flux content, degree
// of vitrification at the studio's fired cone), not a fudge factor. Every
// fired dimension shown anywhere on this site is thrown × (1 − rate),
// computed here — never typed twice.
export function firedDimension(thrownCm: number, shrinkageRate: number): number {
  return Math.round(thrownCm * (1 - shrinkageRate) * 10) / 10;
}

export function formatCm(n: number): string {
  return `${n.toFixed(1)} cm`;
}

export function formatPercent(fraction: number, digits = 1): string {
  return `${(fraction * 100).toFixed(digits)}%`;
}

// ── Loss rate: kiln-load count-in vs count-out ───────────────────────────
// (in − out) / in, computed once per firing and again across every firing
// shown, so the studio's stated "about 1 in 9, ~11%" rate on the hero and
// the per-firing numbers in the log are the same arithmetic, not a
// restated estimate.
export function lossRate(countIn: number, countOut: number): number {
  return (countIn - countOut) / countIn;
}

export function totalLossRate(firings: { countIn: number; countOut: number }[]): {
  countIn: number;
  countOut: number;
  lost: number;
  rate: number;
} {
  const countIn = firings.reduce((a, f) => a + f.countIn, 0);
  const countOut = firings.reduce((a, f) => a + f.countOut, 0);
  return { countIn, countOut, lost: countIn - countOut, rate: lossRate(countIn, countOut) };
}

// ── Cone 6 is heat-work, not a temperature ───────────────────────────────
// Orton's own literature: pyrometric cones measure heat-work, the combined
// effect of time and temperature — a digital controller that only reads
// temperature cannot measure it. The bending temperature below is stored in
// Fahrenheit, the unit the studio's kiln controller and Orton's own chart
// both use; Celsius is derived here rather than hand-converted a second
// time, for the same reason every other number on this page is computed
// once. Source: kilncontrol.com/blog/cone-6-temp (RESEARCH.md).
export type RampId = 'slow' | 'standard' | 'fast';

export type RampSpeed = {
  id: RampId;
  label: string;
  ratePerHourF: number;
  cone6BendF: number;
};

export const RAMP_SPEEDS: Record<RampId, RampSpeed> = {
  slow: { id: 'slow', label: 'Slow', ratePerHourF: 27, cone6BendF: 2165 },
  standard: { id: 'standard', label: 'Standard', ratePerHourF: 108, cone6BendF: 2232 },
  fast: { id: 'fast', label: 'Fast', ratePerHourF: 270, cone6BendF: 2269 },
};

export function fToC(f: number): number {
  return Math.round(((f - 32) * 5) / 9);
}

// ── Vitrification & food safety, computed from body + glaze + fired cone ─
// A vitrified body absorbs under 0.5% water and is dishwasher- and
// microwave-safe; an under-fired one is porous regardless of what a label
// says. Ordered coolest → hottest so a fired cone can be compared against
// the cone a body needs to reach to vitrify, by position, not by treating
// cone numbers as a normal number line (04 is hotter than 06, not colder).
export const CONE_ORDER = ['06', '04', '6', '10'] as const;
export type ConeId = (typeof CONE_ORDER)[number];

export function coneRank(cone: ConeId): number {
  return CONE_ORDER.indexOf(cone);
}

export type FoodSafety = {
  vitrified: boolean;
  absorptionPct: string;
  dishwasherSafe: boolean;
  microwaveSafe: boolean;
  ovenSafe: boolean;
};

export function computeFoodSafety(
  vitrifiesAtCone: ConeId,
  firedCone: ConeId,
  glazeFoodSafe: boolean,
): FoodSafety {
  const vitrified = coneRank(firedCone) >= coneRank(vitrifiesAtCone);
  const safe = vitrified && glazeFoodSafe;
  return {
    vitrified,
    absorptionPct: vitrified ? '< 0.5%' : '5–8%',
    dishwasherSafe: safe,
    microwaveSafe: safe,
    ovenSafe: vitrified,
  };
}
