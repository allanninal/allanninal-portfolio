/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Oswald', 'Impact', 'sans-serif'],
        body: ['Work Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        slate:   '#1C2128',
        copper:  '#C97C2E',
        amber:   '#D4943A',
        cream:   '#F5F0E8',
        'cream-dark': '#E8E0D0',
        char:    '#0F1318',
        'slate-2': '#252D38',
        'slate-3': '#2E3847',
        muted:   '#8A9BB0',
      },
    },
  },
  plugins: [],
};
