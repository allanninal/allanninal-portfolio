// ============================================================
// Brewery — Day 42 · Iron & Grain Brewing Co.
// Craft brewery: tap list, taproom hours, tour booking
// Palette: Slate Charcoal (#1C2128) + Copper (#C97C2E) + Cream (#F5F0E8)
// Fonts: Oswald (display/headings) + Work Sans (body)
// ============================================================

export const brewery = {
  name: 'Iron & Grain Brewing Co.',
  shortName: 'Iron & Grain',
  tagline: 'Brewed Slow. Poured Proud.',
  shortTagline: 'Small-batch craft ales and lagers brewed on-site in the heart of Asheville, NC.',
  description:
    'Iron & Grain Brewing Co. is an independent craft brewery in Asheville, North Carolina. We brew small-batch ales, lagers, and farmhouse styles using open fermenters, whole-cone hops, and locally malted grain. Our taproom is a living part of the brewery — every pour is made on the same floor it ferments on.',
  address: '48 Foundry Street, Asheville, NC 28801',
  phone: '+1 (828) 555-0173',
  email: 'hello@ironandgrain.com',
  tourUrl: '#tours',
  instagram: 'https://instagram.com/ironandgrain',
  facebook: 'https://facebook.com/ironandgrain',
  untappd: 'https://untappd.com/ironandgrain',
  estYear: '2016',
  mapsUrl: 'https://maps.google.com/?q=48+Foundry+Street+Asheville+NC',
};

// ─── Hours ───────────────────────────────────────────────────────────────────

export type HoursRow = {
  day: string;
  open: string;
  note?: string;
};

export const hours: HoursRow[] = [
  { day: 'Mon–Tue',   open: 'Closed',               note: 'Brewing days — no taproom service' },
  { day: 'Wed–Thu',   open: '3:00 PM – 9:00 PM',    note: 'Happy hour 3–5 PM on draft pints' },
  { day: 'Friday',    open: '2:00 PM – 10:00 PM',   note: 'Live music from 6 PM on select Fridays' },
  { day: 'Saturday',  open: '12:00 PM – 10:00 PM',  note: 'Brewery tours at 1 PM, 3 PM & 5 PM' },
  { day: 'Sunday',    open: '12:00 PM – 7:00 PM',   note: 'Sunday sessions — family-friendly until 5 PM' },
];

// ─── Tap List ─────────────────────────────────────────────────────────────────

export type BeerTag =
  | 'on-tap'
  | 'seasonal'
  | 'limited'
  | 'flagship'
  | 'new'
  | 'collaboration'
  | 'barrel-aged'
  | 'hazy'
  | 'dark';

export type BeerStyle =
  | 'IPA'
  | 'Hazy IPA'
  | 'Double IPA'
  | 'Pale Ale'
  | 'Pilsner'
  | 'Lager'
  | 'Wheat Beer'
  | 'Saison'
  | 'Stout'
  | 'Porter'
  | 'Amber Ale'
  | 'Sour'
  | 'Barrel-Aged Stout';

export type Beer = {
  id: string;
  name: string;
  style: BeerStyle;
  abv: number;
  ibu?: number;
  srm?: number;   // color units
  description: string;
  flavorNotes: string[];
  price: string;
  tags: BeerTag[];
  pairings?: string[];
};

export type TapCategory = {
  id: string;
  label: string;
  description: string;
  beers: Beer[];
};

export const tapList: TapCategory[] = [
  {
    id: 'on-tap',
    label: 'On Tap Now',
    description: 'Our rotating selection of freshly brewed ales and lagers — poured straight from the conditioning tank.',
    beers: [
      {
        id: 'foundry-pale',
        name: 'Foundry Pale Ale',
        style: 'Pale Ale',
        abv: 4.8,
        ibu: 32,
        srm: 6,
        description: 'Our house pale: bright, balanced, and easy-drinking. Cascade and Centennial hops over a light biscuit malt backbone. The one that never leaves the board.',
        flavorNotes: ['Citrus blossom', 'Light biscuit', 'Pine finish'],
        price: '$7',
        tags: ['on-tap', 'flagship'],
        pairings: ['Burgers', 'Grilled chicken', 'Sharp cheddar'],
      },
      {
        id: 'copper-ridge-ipa',
        name: 'Copper Ridge IPA',
        style: 'IPA',
        abv: 6.5,
        ibu: 65,
        srm: 8,
        description: 'West Coast-leaning IPA with Simcoe, Mosaic, and Citra. Assertive bitterness with a clean, dry finish. Named for the ridge above our barley source.',
        flavorNotes: ['Tropical fruit', 'Resinous pine', 'Grapefruit pith'],
        price: '$8',
        tags: ['on-tap', 'flagship'],
        pairings: ['Spicy wings', 'Fish tacos', 'Blue cheese'],
      },
      {
        id: 'asheville-haze',
        name: 'Asheville Haze',
        style: 'Hazy IPA',
        abv: 6.8,
        ibu: 28,
        srm: 4,
        description: 'Soft, pillowy, and fruit-forward. Nelson Sauvin and Galaxy hops give this New England-style IPA its signature tropical juice character with low perceived bitterness.',
        flavorNotes: ['Mango', 'Passion fruit', 'Creamy oats'],
        price: '$8.50',
        tags: ['on-tap', 'hazy', 'new'],
        pairings: ['Sushi', 'Soft pretzels', 'Brie'],
      },
      {
        id: 'grain-pilsner',
        name: 'Grain & Gold Pilsner',
        style: 'Pilsner',
        abv: 4.5,
        ibu: 22,
        srm: 2,
        description: 'A clean, crisp Czech-style pilsner dry-hopped with Saaz. Light malt sweetness, noble hop spice, and a long dry finish. Lagered for eight weeks.',
        flavorNotes: ['Herbal hops', 'Cracker malt', 'Honey finish'],
        price: '$7',
        tags: ['on-tap', 'flagship'],
        pairings: ['Schnitzel', 'Charcuterie', 'Mild soft cheeses'],
      },
      {
        id: 'ironmill-amber',
        name: 'Ironmill Amber',
        style: 'Amber Ale',
        abv: 5.4,
        ibu: 28,
        srm: 14,
        description: 'Toasted crystal malt gives this amber its caramel sweetness, balanced by Willamette hops. Smooth, sessionable, and endlessly food-friendly.',
        flavorNotes: ['Caramel', 'Toasted bread', 'Toffee'],
        price: '$7.50',
        tags: ['on-tap'],
        pairings: ['BBQ ribs', 'Roasted chicken', 'Gouda'],
      },
      {
        id: 'night-shift-stout',
        name: 'Night Shift Oatmeal Stout',
        style: 'Stout',
        abv: 5.9,
        ibu: 35,
        srm: 40,
        description: 'Rich and velvety with oats for body. Roasted barley and chocolate malt deliver dark espresso and cocoa notes. Nitrogenated for a creamy pour.',
        flavorNotes: ['Espresso', 'Dark chocolate', 'Roasted grain'],
        price: '$8',
        tags: ['on-tap', 'dark'],
        pairings: ['Oysters', 'Dark chocolate', 'Beef stew'],
      },
    ],
  },
  {
    id: 'seasonal',
    label: 'Seasonal Releases',
    description: 'Brewed to celebrate the season — limited batches that follow the harvest calendar.',
    beers: [
      {
        id: 'harvest-saison',
        name: 'Harvest Saison',
        style: 'Saison',
        abv: 6.2,
        ibu: 24,
        srm: 7,
        description: 'A summer-autumn transition beer. Spelt and wheat malt give a rustic, earthy base. Fermented with Belgian farmhouse yeast for peppery, fruity esters. Currently on draft.',
        flavorNotes: ['White pepper', 'Lemon zest', 'Earthy wheat'],
        price: '$8.50',
        tags: ['on-tap', 'seasonal'],
        pairings: ['Roast pork', 'Aged goat cheese', 'Herb-roasted vegetables'],
      },
      {
        id: 'wheat-summer',
        name: 'Blue Ridge Wheat',
        style: 'Wheat Beer',
        abv: 4.2,
        ibu: 12,
        srm: 3,
        description: 'An unfiltered American wheat brewed with a touch of coriander and orange peel. Light, hazy, and refreshing. The warm-season crowd pleaser.',
        flavorNotes: ['Orange peel', 'Coriander', 'Soft wheat'],
        price: '$7',
        tags: ['seasonal'],
        pairings: ['Seafood', 'Chicken salad', 'Citrus desserts'],
      },
      {
        id: 'winter-porter',
        name: 'Ironworks Winter Porter',
        style: 'Porter',
        abv: 6.4,
        ibu: 30,
        srm: 30,
        description: 'A robust porter brewed every November with Appalachian wildflower honey and a whisper of smoked malt from our local malthouse. Warming, complex, and perfect for a cold evening.',
        flavorNotes: ['Wildflower honey', 'Smoke', 'Dark fruit'],
        price: '$8.50',
        tags: ['seasonal', 'dark'],
        pairings: ['Smoked brisket', 'Walnut brownie', 'Aged cheddar'],
      },
    ],
  },
  {
    id: 'limited',
    label: 'Limited & Cellar',
    description: 'Small-batch experiments, barrel projects, and one-off collaborations. Ask the bar what\'s available.',
    beers: [
      {
        id: 'bourbon-barrel-stout',
        name: 'Barrel Reserve Stout',
        style: 'Barrel-Aged Stout',
        abv: 11.2,
        ibu: 40,
        srm: 45,
        description: 'Our flagship stout aged 14 months in Willett Distillery bourbon barrels. Intense vanilla, oak, and dark fruit aromas with a warming, luxurious finish. Only 4 kegs per release.',
        flavorNotes: ['Bourbon vanilla', 'Oak', 'Dried cherry'],
        price: '$14',
        tags: ['limited', 'barrel-aged', 'dark'],
        pairings: ['Vanilla ice cream', 'Pecan pie', 'Foie gras'],
      },
      {
        id: 'dipa-collab',
        name: 'Ridgeline DIPA (w/ Wicked Weed)',
        style: 'Double IPA',
        abv: 8.4,
        ibu: 70,
        srm: 6,
        description: 'A collaboration with our friends at Wicked Weed. Strata, Citra, and Mosaic hop bill. Intensely fruity with a bold, resinous bitterness. 2 kegs left.',
        flavorNotes: ['Passionfruit', 'Peach', 'Dank resin'],
        price: '$10',
        tags: ['limited', 'collaboration'],
        pairings: ['Thai curry', 'Strong cheddar', 'Pepperoni pizza'],
      },
      {
        id: 'cherry-sour',
        name: 'Orchard Sour — Montmorency Cherry',
        style: 'Sour',
        abv: 5.0,
        ibu: 8,
        srm: 10,
        description: 'Kettle-soured wheat base refermented on 200 lbs of Montmorency cherries. Bright acidity, tart cherry, and a dry finish. Collaboration with Blue Ridge Orchard.',
        flavorNotes: ['Tart cherry', 'Lactic tang', 'Stone fruit'],
        price: '$9',
        tags: ['limited', 'collaboration', 'seasonal'],
        pairings: ['Duck confit', 'Chocolate tart', 'Camembert'],
      },
    ],
  },
];

// ─── Tours ────────────────────────────────────────────────────────────────────

export type TourSlot = {
  id: string;
  name: string;
  duration: string;
  description: string;
  includes: string[];
  price: string;
  schedule: string;
  maxGuests: number;
  popular?: boolean;
};

export const tourSlots: TourSlot[] = [
  {
    id: 'taproom-tour',
    name: 'Taproom & Tank Tour',
    duration: '45 min',
    description: 'Walk the brewery floor, see the open fermenters, and learn how we take a grain bill from mash tun to conditioning tank. Ends with two tasting pours of your choice at the taproom bar.',
    includes: [
      'Guided walk through brew house, fermentation hall & packaging',
      '2 x 5 oz tasting pours',
      'Tasting notes card to take home',
    ],
    price: '$18 / person',
    schedule: 'Saturdays at 1:00 PM, 3:00 PM & 5:00 PM',
    maxGuests: 16,
  },
  {
    id: 'brewmaster-tour',
    name: 'Brewmaster\'s Deep Dive',
    duration: '2 hours',
    description: 'A private session with our head brewer. We\'ll cover grain selection, water chemistry, hop additions, and the art of open fermentation. Includes an in-progress tank sample you won\'t find on the board.',
    includes: [
      'Private 2-hour guided tour with Head Brewer',
      '4 x guided tasting pours including tank samples',
      'Signed recipe card for a current Iron & Grain batch',
      'Souvenir branded glass',
    ],
    price: '$55 / person',
    schedule: 'By appointment — Wednesday to Friday',
    maxGuests: 8,
    popular: true,
  },
  {
    id: 'group-event',
    name: 'Private Group Event',
    duration: 'Flexible',
    description: 'Book the taproom or beer garden for team events, birthday parties, corporate outings, or any gathering worth celebrating with great beer. Minimum 20 guests. Custom beer menu available.',
    includes: [
      'Exclusive taproom or beer garden hire',
      'Dedicated bar staff',
      'Custom tap selection',
      'Optional catering from our partner kitchen',
    ],
    price: 'From $600',
    schedule: 'Contact us for availability',
    maxGuests: 80,
  },
];

// ─── Events ───────────────────────────────────────────────────────────────────

export type BreweryEvent = {
  id: string;
  name: string;
  date: string;
  time: string;
  description: string;
  ticketUrl?: string;
  free?: boolean;
};

export const events: BreweryEvent[] = [
  {
    id: 'release-barrel',
    name: 'Barrel Reserve Stout Release',
    date: 'July 12, 2026',
    time: '3:00 PM – 9:00 PM',
    description: 'Limited kegs of our 14-month bourbon barrel-aged stout go on. First come, first served — bottles also available for cellar purchase. Live jazz from 5 PM.',
    free: false,
    ticketUrl: '#',
  },
  {
    id: 'open-brew-day',
    name: 'Open Brew Day',
    date: 'July 19, 2026',
    time: '9:00 AM – 2:00 PM',
    description: 'Watch a full brew day from mash-in to whirlpool. Ask questions, taste raw ingredients, sample the wort before fermentation. Coffee and pastries from our neighbour, Laurel Bakehouse.',
    free: true,
  },
  {
    id: 'collab-night',
    name: 'Collaboration Night: Iron & Grain × Wicked Weed',
    date: 'August 2, 2026',
    time: '5:00 PM – 10:00 PM',
    description: "Eight taps from both breweries, head-to-head tasting cards, and both brew teams behind the bar for a Q&A. We're pouring the last two kegs of our Ridgeline DIPA alongside Wicked Weed's newest releases.",
    free: false,
    ticketUrl: '#',
  },
  {
    id: 'homebrewer-comp',
    name: 'Mountain Homebrew Competition',
    date: 'August 16, 2026',
    time: '12:00 PM – 6:00 PM',
    description: 'Annual competition for WNC homebrewers. Categories: Pale/IPA, Dark, Wheat, and Wild/Sour. Entry forms at the bar from July 1. Winning recipe brewed at Iron & Grain in September.',
    free: true,
  },
];

// ─── Our Story ────────────────────────────────────────────────────────────────

export const story = {
  headline: 'Built from the Ground Up. Brewed the Old Way.',
  founderName: 'Marcus Holt',
  founderTitle: 'Head Brewer & Co-Founder',
  bio: [
    'Marcus Holt spent twelve years as a structural engineer before realising that the most interesting thing he was building on weekends was beer. What started as extract kits on an apartment stovetop grew into a 10-gallon all-grain system in the garage, then a 1-barrel pilot system in a rented unit off Merrimon Ave.',
    'In 2016, Marcus and his partner Deanna converted a decommissioned foundry building on Foundry Street — keeping the original brick walls, timber beams, and industrial character that now defines the taproom — and brewed the first commercial batch of Foundry Pale Ale on a 15-barrel open-top fermenter.',
    'Today Iron & Grain brews on a 30-barrel system, sources malted grain from three North Carolina malthouses, and has never taken outside investment. The taproom seats 120. The philosophy hasn\'t changed: brew slowly, ferment openly, pour proudly.',
  ],
  stats: [
    { label: 'Founded',         value: '2016' },
    { label: 'Barrel capacity', value: '30 bbl' },
    { label: 'Beers brewed',    value: '80+' },
    { label: 'NC malt partners', value: '3' },
  ],
};

// ─── Gallery ──────────────────────────────────────────────────────────────────

export const gallery = [
  { alt: 'Rows of bright stainless fermentation tanks rising to the exposed timber ceiling of the Iron & Grain brew house', label: 'The brew house', src: 'brewhouse' },
  { alt: 'A close-up of a clear amber pint of Copper Ridge IPA held up to industrial light, beer glowing golden', label: 'Copper Ridge IPA', src: 'ipa' },
  { alt: 'Craft beer pouring from the tap with a clean white head forming, bar top visible below', label: 'Night Shift pour', src: 'pour' },
  { alt: 'Bags of pale and crystal malt stacked in the Iron & Grain grain room', label: 'Grain room', src: 'grain' },
  { alt: 'Wide shot of the taproom: communal timber tables and the bar with the gleaming brew tanks in the background', label: 'The taproom', src: 'taproom' },
  { alt: 'A brewer at work beside the stainless fermentation tanks in the brew house', label: 'In the brew house', src: 'brewer' },
];

// ─── Maker ────────────────────────────────────────────────────────────────────

export const maker = {
  name: 'Iron & Grain Brewing Co.',
  linkedin: '#',
  twitter: '#',
  github: '#',
  email: 'hello@irongrainbrewingco.com',
  kofi: '#',
};

// ─── Site Meta ────────────────────────────────────────────────────────────────

export const site = {
  title: 'Iron & Grain Brewing Co. — Craft Brewery, Asheville NC',
  description:
    'Small-batch craft ales and lagers brewed on-site at our Foundry Street taproom. Tap list, taproom hours, brewery tours, and upcoming events in Asheville, North Carolina.',
  url: 'https://example.com/',
  ogImage: '/og-image.png',
  language: 'en',
};
