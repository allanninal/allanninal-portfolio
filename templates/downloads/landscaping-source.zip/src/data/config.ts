/**
 * Ashgrove Land & Garden — every string the page renders.
 *
 * Business fictional; PRICES ARE REAL 2026 US figures (sources in RESEARCH.md).
 * Boise is genuinely high-desert, so the drought-dormancy and lawn-conversion
 * advice is local fact rather than positioning.
 */

export const site = {
  name: 'Ashgrove Land & Garden',
  shortName: 'Ashgrove',
  tagline: 'A year in the garden, month by month.',
  description:
    'Design, install and maintenance across the Boise valley — built around a twelve-month calendar that tells you what your yard needs, and which months it needs nothing at all.',
  owner: 'Wren Halloran',
  ownerRole: 'Owner · Landscape designer',
  yearsExperience: 9,
  city: 'Boise',
  state: 'ID',
  streetAddress: '3117 West Fairview Avenue',
  postalCode: '83702',
  phoneDisplay: '(208) 555-0133',
  phoneHref: '+12085550133',
  email: 'hello@ashgrovegarden.example',
  formAction: '#',
  hours: 'Mon–Fri 7am–4pm · Design consults by appointment',
  bookingWindow: 'Design consults two weeks out. Maintenance routes open in February.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Ashgrove Land & Garden — Landscaping in Boise, ID',
  license: 'Idaho contractor registration #RCE-31940',
  instagram: 'https://www.instagram.com/ashgrovegarden',
  facebook: 'https://www.facebook.com/ashgrovegarden',
};

export const nav = [
  { label: 'The year', href: '#year' },
  { label: 'Quiet months', href: '#quiet' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Less lawn', href: '#lawn' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The twelve-month band — the page's primary device.
 *
 * `spend` is deliberately honest: 'none' months exist and are marked, because a
 * calendar that bills every month is a subscription pitch, not a calendar.
 */
export const months = [
  { m: 'Jan', name: 'January', spend: 'none', job: 'Nothing', body: 'Frozen ground, dormant everything. Do not walk on a frosted lawn — the blades snap and you will see the footprints in April.' },
  { m: 'Feb', name: 'February', spend: 'low', job: 'Structural pruning', body: 'Dormant pruning on deciduous trees and shrubs, while the framework is visible. The one month the shape of a garden is honest.' },
  { m: 'Mar', name: 'March', spend: 'high', job: 'Clean-up and first cut', body: 'Cut back perennials, clear beds, first mow high. Pre-emergent goes down now or not at all.' },
  { m: 'Apr', name: 'April', spend: 'high', job: 'Planting and irrigation start-up', body: 'Best planting window here. Charge the irrigation, walk every head, fix what the winter broke.' },
  { m: 'May', name: 'May', spend: 'med', job: 'Growth management', body: 'Weekly mowing begins in earnest. First fertiliser if the soil test asked for it — not automatically.' },
  { m: 'Jun', name: 'June', spend: 'med', job: 'Deep watering, less often', body: 'Fewer, longer waterings drive roots down. Daily light watering in June is how you build a lawn that dies in August.' },
  { m: 'Jul', name: 'July', spend: 'low', job: 'Hold the line', body: 'No fertiliser, no aggressive pruning. Raise the mower height and shade the roots. This month is about not making it worse.' },
  { m: 'Aug', name: 'August', spend: 'none', job: 'Let it go dormant', body: 'A brown lawn in a Boise August is dormant, not dead, and it greens back up. Watering it through peak restriction costs money and achieves very little.' },
  { m: 'Sep', name: 'September', spend: 'high', job: 'The real growing month', body: 'Aerate, overseed, fertilise. If you do one thing to a lawn all year, do it now — not in spring.' },
  { m: 'Oct', name: 'October', spend: 'med', job: 'Planting and bulbs', body: 'Second-best planting window; roots establish before frost. Bulbs go in.' },
  { m: 'Nov', name: 'November', spend: 'med', job: 'Blow out and cut back', body: 'Irrigation blow-out before the first hard freeze — the single most expensive thing to forget in this valley.' },
  { m: 'Dec', name: 'December', spend: 'none', job: 'Nothing', body: 'Leave the seed heads and the leaf litter in the beds. It is habitat, it is insulation, and tidying it is work you are paying for twice.' },
];

/** The four months that need least, gathered so the point cannot be missed. */
export const quiet = {
  intro: 'Three of the twelve months on that calendar need nothing at all, and two more need very little. We are saying so on our own website, which should tell you what our maintenance quotes look like.',
  points: [
    { title: 'January and December', body: 'Genuinely nothing. Any company billing a full monthly rate across a Boise winter is charging you for a truck that is not coming.' },
    { title: 'August', body: 'Let the lawn go dormant. It is the single biggest saving available to most of our clients, and it costs us the summer watering work.' },
    { title: 'July', body: 'Hold, do not push. Fertiliser in July burns and fresh planting bakes. Spend the money in September instead.' },
  ],
};

/** Real 2026 US figures. */
export const pricing = {
  rows: [
    { what: 'Standard mow, quarter-acre', rate: '$50 – $55 per visit' },
    { what: 'Standard residential mow', rate: '$45 – $90 per visit' },
    { what: 'Full service — mow, edge, cleanup', rate: '$125 – $450 per visit' },
    { what: 'General maintenance', rate: '$100 – $200 per month' },
    { what: 'Peak season, weekly plus treatments', rate: '$120 – $450 per month' },
    { what: 'Fertiliser application', rate: '$65 – $100 · 4–6 per year' },
    { what: 'Weed control', rate: '$50 – $210 per visit' },
  ],
  note: 'We bill nine months, not twelve. January, February and December are on call rather than on schedule, because there is nothing there to do.',
};

/** Lawn conversion — the honest long-term maintenance answer for many yards. */
export const lawn = {
  intro: 'For a lot of Boise yards the cheapest maintenance plan is less lawn. Here is the arithmetic rather than the sales pitch.',
  costs: [
    { what: 'Lawn replacement, installed', rate: '$1 – $3 per sq ft', note: 'Removal, topsoil, and seed or sod.' },
    { what: 'Sod alone', rate: '$1 – $2 per sq ft', note: 'If you are keeping lawn, this is the material line.' },
  ],
  math: [
    'A 1,500 sq ft lawn costs roughly $1,500 – $4,500 to convert',
    'It also costs $100 – $200 a month to maintain through the season',
    'Converted beds need real attention for two seasons, then far less than turf ever did',
    'Water is the other half of the sum, and in this valley it is the half that keeps rising',
  ],
  caveat: 'Keep the lawn your family actually uses. Removing the patch where the kids play to install gravel nobody walks on is not a saving, it is a redecoration.',
};

export const areas = [
  { zone: 'Boise', towns: 'North End · East End · Bench · Harris Ranch · Southeast Boise' },
  { zone: 'West valley', towns: 'Meridian · Eagle · Star · Middleton' },
  { zone: 'South', towns: 'Kuna · Nampa · Caldwell' },
  { zone: 'Foothills', towns: 'Hidden Springs · Highlands · Boise Heights' },
];

export const reviews = [
  { name: 'Marcus D.', town: 'North End', text: 'She talked me out of watering the lawn through August and off two of the twelve billing months. My bill went down and the lawn came back in September exactly like she said.' },
  { name: 'Tessa V.', town: 'Eagle', text: 'The calendar on this site is what got me to call. Nobody else told me September mattered more than April.' },
  { name: 'Jonah K.', town: 'Meridian', text: 'Converted about half the front lawn. She insisted we keep the back for the dog, which I appreciated more than if she had sold me the whole job.' },
  { name: 'Priya B.', town: 'Boise Bench', text: 'Blew out the irrigation the first week of November without being asked. The previous company forgot two years running and I paid for it both times.' },
];

export const faqs = [
  { q: 'Why do you only bill nine months?', a: 'Because January, February and December have nothing in them that needs a scheduled visit. We stay on call for storm damage and we do dormant pruning in February when the weather allows, but charging a flat twelve-month rate for a nine-month season is just a loan you did not ask for.' },
  { q: 'My lawn goes brown in August. Is it dying?', a: 'Almost certainly not. Cool-season grass goes dormant in heat and greens back up when temperatures drop and the September rain arrives. Watering it through a peak-restriction August costs a lot and mostly grows weeds. If it is still brown in October, then we should talk.' },
  { q: 'When should I actually fertilise?', a: 'September, and then late October if at all. Spring fertiliser feels right and mostly feeds top growth you then have to mow. If someone is putting four spring applications on your lawn, ask what the soil test said — and whether there was one.' },
  { q: 'Do you do design as well as maintenance?', a: 'Yes, and we would rather do both, because a garden designed without knowing who maintains it usually gets maintained badly. Design consults are separate and paid; the fee comes off the install if you go ahead with us.' },
  { q: 'What about native and low-water planting?', a: 'It is most of what we install now. It is not zero-maintenance — that is the myth — but after two establishment seasons it needs a fraction of the water and about a third of the labour of turf.' },
  { q: 'Can you take over a garden someone else designed?', a: 'Happily, and we will not disparage the previous work to win the job. We will tell you honestly what is thriving, what is in the wrong place, and what is going to be a problem in three years.' },
];
