import { test, expect } from '@playwright/test';

test.describe('Ashgrove Land & Garden — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Ashgrove Land & Garden/);
    await expect(page.locator('h1')).toContainText('month by month');
  });

  // The horizontally scrolled year is the archetype. It must be a real ordered
  // list so the month sequence survives without CSS.
  test('the year is an ordered list of twelve months', async ({ page }) => {
    await page.goto('/');
    const ol = page.locator('#year ol.year');
    await expect(ol).toHaveCount(1);
    expect(await ol.locator('> li.month').count()).toBe(12);
    const keys = await page.locator('#year .month-key').allTextContents();
    expect(keys).toEqual(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']);
  });

  // Accessibility is the whole risk with a sideways scroller, so it is asserted
  // rather than assumed: reachable by keyboard, and labelled.
  test('the scroller is a labelled region a keyboard can reach', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('.year-scroller');
    await expect(s).toHaveAttribute('role', 'region');
    await expect(s).toHaveAttribute('tabindex', '0');
    await expect(s).toHaveAttribute('aria-label', /January to December/i);
  });

  test('on a desktop the year really does scroll sideways', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 900 });
    await page.goto('/');
    const m = await page.evaluate(() => {
      const s = document.querySelector('.year-scroller') as HTMLElement;
      return { visible: Math.round(s.getBoundingClientRect().width), content: s.scrollWidth };
    });
    expect(m.content).toBeGreaterThan(m.visible);
  });

  // ...and on a phone it must NOT, because forcing a sideways scroll through
  // twelve months on a 375px screen is worse than stacking them.
  test('on a phone the year stacks instead of scrolling sideways', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const m = await page.evaluate(() => {
      const s = document.querySelector('.year-scroller') as HTMLElement;
      return { visible: Math.round(s.getBoundingClientRect().width), content: s.scrollWidth };
    });
    expect(m.content).toBeLessThanOrEqual(m.visible + 1);
  });

  // A calendar that bills every month is a subscription pitch, not a calendar.
  test('the no-spend months are real, and the hero quotes the true count', async ({ page }) => {
    await page.goto('/');
    const none = await page.locator('#year .spend--none').count();
    // January, August and December. A floor rather than an exact number, so
    // the data can grow — but a calendar that bills every month is a
    // subscription pitch and must not pass.
    expect(none).toBeGreaterThanOrEqual(3);
    // The hero renders this count from the data. Asserting they agree stops
    // the copy and the calendar drifting apart, which is exactly what happened
    // when this template's own brief claimed four.
    await expect(page.locator('main')).toContainText(`${none} of the twelve months below need nothing`);
  });

  test('every spend level reads as a word, not just a colour', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#year .spend').allTextContents()) {
      expect(['No spend', 'Light', 'Steady', 'Peak']).toContain(t.trim());
    }
  });

  test('the lawn-conversion section keeps its caveat', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#lawn')).toContainText(/Keep the lawn your family actually uses/i);
    expect(await page.locator('#lawn dl > div').count()).toBe(2);
  });

  test('pricing shows real per-visit and monthly figures', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#pricing .rate-table tbody tr');
    expect(await rows.count()).toBe(7);
    for (const t of await rows.allTextContents()) expect(t).toMatch(/\$\d/);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 80.
  test('no trace of the day-80 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['thornfield', 'raleigh', 'termite', 'delia', 'cockroach']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro water plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/water-plan/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('November blow-out');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
