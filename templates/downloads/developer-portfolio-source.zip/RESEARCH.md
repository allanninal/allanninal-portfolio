# Developer Portfolio Template — Research Brief

> **Assumption:** "Developer portfolio" = personal site for an individual software engineer (indie / freelancer / employed senior / junior). Not an agency, not a designer.

## Audience & primary CTA
- **Who visits:** recruiters (30s scan), hiring managers (resume + 1 case study), prospective clients, conference organizers, peers.
- **Primary CTA:** *Get in touch* (mailto). Hire-me intent dominates; client-acquisition is close second.
- **Secondary CTAs:** view resume PDF, read a case study, GitHub follow, RSS/newsletter.

## Reference sites (real engineers)
- https://brittanychiang.com — Inter, dark-default teal accent, vertical job timeline, 4 featured projects, prestige logos (Apple, Klaviyo). Canonical.
- https://leerob.com — prose minimalism, large name, conversational bio, "Reach out" mailto. Writing-led.
- https://www.robinwieruch.de — services-led; quantified trust ("3M annual visitors", GitHub Star), client logos, Dan Abramov endorsement.
- https://chronark.com — radical minimalism, one project (unkey.dev). Senior signal.
- https://rauno.me — manifesto-as-hero, Vercel affiliation, craft showcase. Design-engineer archetype.
- https://timlrx.com — writing-first, MDX blog with tags, newsletter CTA.
- https://hamishw.com, https://andy-bell.design, https://expensive.toys — animation-heavy design-engineer end.

## Existing templates surveyed
- **devportfolio** (4.9k, Astro+Tailwind) — generic; weak typography, no MDX case studies, dated dark mode.
- **astro-bento-portfolio** (347) — bento single-page, no case study system.
- **astro-antfustyle-theme** (244) — kitchen-sink, not opinionated.
- **shadcn-portfolio** — Next-only, locked to shadcn aesthetic.
- **Astrofy / Dante** — markdown blog grafted onto a CV; case studies feel like posts.
- **Vercel `portfolio-starter-kit`** — Next-only, no case study schema, light-first.
- **Saturated:** timeline + project grid + skill chips. **Missing:** opinionated typography, real MDX case-study layout, strong dark default, Person schema.

## Must-have sections (in order)
1. **Hero** — name, one-line value prop, role + location, current employer, primary CTA.
2. **About** — 2–3 short paragraphs; no "passionate" filler.
3. **Selected work** — 3–6 MDX case studies, grid linking to `/work/[slug]`.
4. **Experience** — vertical timeline; company, role, dates, 1–2 bullets.
5. **Writing** — 3–5 latest MDX posts, link to `/writing`.
6. **Speaking / OSS** — optional, ships hidden.
7. **Contact** — mailto + social row (GitHub, X, LinkedIn, RSS).

## Design conventions
- **Typography:** sans body (Inter or Geist), line-height 1.6+, one display moment (large hero name). Optional mono accent (JetBrains Mono / Geist Mono) for labels. Real prose, no lorem.
- **Color:** dark-default neutral (zinc/slate) + one accent (teal, mint, or orange). Light mode equally polished, not afterthought.
- **Imagery:** sparse — case study OG cards, optional headshot, no stock.
- **Density:** sparse marketing with one dense section (experience timeline).

## Trust signals to include
- Companies worked at (or "Currently at X" line).
- GitHub star counts for OSS.
- Published-on bylines.
- Talks given (conference + year).
- Quantified case-study outcomes ("reduced p95 40%").
- Endorsement quote slot (hidden by default).

## SEO / schema.org
- **Type:** `Person`.
- **Required:** `name`, `jobTitle`, `url`, `image`, `worksFor` (Organization), `sameAs` (GitHub, LinkedIn, X, Mastodon), `knowsAbout` (skills array).
- **OG image:** build-time generated — name + role + accent on dark, mono label.

## Static-only fit
No concerns. GitHub stats fetched at build time via content loaders or hardcoded frontmatter. Newsletter via Buttondown/ConvertKit embed. Contact = `mailto:`.

## Differentiation — what we'll do better
- **MDX case studies as a first-class collection** (`src/content/work/`) with structured frontmatter (problem, role, stack, outcome, links) and a real layout — not a blog hack.
- **Opinionated type scale + spacing** (modular scale, not Tailwind defaults).
- **Genuinely good dark mode** — designed first, respects `prefers-color-scheme` + manual toggle.
- **Real placeholder content** — believable engineer voice, not "passionate developer."
- **Person schema + per-page OG image** out of the box.
- **One-click GitHub Pages deploy** — no Vercel lock-in.
