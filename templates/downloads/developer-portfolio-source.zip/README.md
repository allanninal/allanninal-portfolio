# Developer Portfolio

A free, MIT-licensed, mobile-first developer portfolio built with Astro + Tailwind + MDX. Dark by default. Designed for senior engineers who want a clean, opinionated home on the web in under an hour — not a kitchen-sink theme to wrestle with.

> Live demo: `https://example.com/`

![Preview](./preview.png)

## Features

- Hero, about, selected work, experience timeline, writing, speaking, contact
- **MDX case studies as a first-class collection** — `src/content/work/*.mdx` with structured frontmatter (problem, role, stack, outcome, year, links) and a real layout, not a blog hack
- **MDX writing collection** with RSS feed at `/rss.xml`
- Light + dark mode end-to-end with `prefers-color-scheme` respect and a manual toggle that persists
- `Person` schema.org JSON-LD on the home page
- Self-hosted Inter + JetBrains Mono via `@fontsource/*` — works fully offline / pure-static
- Configurable donate button in the footer (Ko-fi by default, any URL works — or hide it entirely)
- Mobile-first, tested 375 → 1920 px
- One-command Playwright smoke tests
- One-click GitHub Pages deploy. No Vercel lock-in.

## Stack

- [Astro 4](https://astro.build/) (`output: 'static'`, `trailingSlash: 'always'`)
- [Tailwind CSS 3](https://tailwindcss.com/) with CSS variables for theme
- [`@astrojs/mdx`](https://docs.astro.build/en/guides/integrations-guide/mdx/) for content collections
- [`@fontsource/inter`](https://fontsource.org/fonts/inter) + [`@fontsource/jetbrains-mono`](https://fontsource.org/fonts/jetbrains-mono)
- [Playwright](https://playwright.dev/) for smoke tests

## Quick start

```bash
# 1. Use this template / clone it
git clone <your-fork>.git my-portfolio
cd my-portfolio

# 2. Install
npm install

# 3. Develop
npm run dev    # http://localhost:4321/developer-portfolio/

# 4. Build
npm run build

# 5. Preview the production build
npm run preview
```

## Deploy to GitHub Pages

This template ships designed to deploy to `https://<username>.github.io/<repo>/`.

1. **Download the source ZIP** from `example.com`. Unzip it into a fresh folder and `git init`. Push to a new repo of your own.
2. **Repo Settings → Pages → Source: GitHub Actions.**
3. Add a workflow at `.github/workflows/pages.yml` (or copy this snippet):

   ```yaml
   - run: npm ci
   - run: npm run build
     env:
       PUBLIC_SITE_URL: https://<username>.github.io
       PUBLIC_BASE_PATH: /<repo-name>/
   ```

### Surface as your own site

If you want this template at the *root* of a custom domain (e.g. `jordanreyes.com`):

```bash
PUBLIC_SITE_URL=https://jordanreyes.com
PUBLIC_BASE_PATH=/
```

Set both as repo variables. The build resolves them at compile time. No code edits required.

## Customize

This template is intentionally small. Most edits happen in three files.

| What you want to change | File |
|---|---|
| Your name, role, bio, current employer, location, email | `src/data/profile.ts` |
| Skill list, social links | `src/data/profile.ts` (`knowsAbout`, `socials`) |
| Experience timeline | `src/data/profile.ts` (`experience`) |
| Speaking / talks | `src/data/profile.ts` (`speaking`) |
| Add a case study | Drop a new `*.mdx` into `src/content/work/` with the required frontmatter |
| Add a blog post | Drop a new `*.mdx` into `src/content/writing/` |
| Color accent | `tailwind.config.mjs` → `colors.accent` |
| Fonts | Replace `@fontsource/*` imports in `src/styles/global.css` |
| Site URL / base path | `.env` (or repo variables) — `PUBLIC_SITE_URL`, `PUBLIC_BASE_PATH` |
| OG image | Replace `public/og.png` (1200 × 630) — see *OG image* below |
| Favicon / avatar | `public/favicon.svg`, `public/avatar.svg` |
| Footer donate button | `.env` — `PUBLIC_AUTHOR_DONATE_URL` (blank to hide) |
| **Hide "free template" download bar** | `.env` — `PUBLIC_TEMPLATE_HUB_URL` must be **blank** (it's the demo deploy's flag; leave empty on your fork) |

### MDX case study frontmatter

Every file in `src/content/work/` must have:

```yaml
---
title: 'A short, specific title'
role: 'Tech lead'           # your role on the project
problem: 'One-paragraph framing of the actual problem.'
stack: ['TypeScript', 'Go'] # tags rendered as pills
outcome: 'Quantified result: median p95 latency 312ms → 187ms.'
year: 2024
company: 'Lumen Labs'        # optional
period: 'Q2 2024 — Q4 2024'  # optional
order: 1                     # sort within work index (lower first)
featured: true               # show on home page
summary: 'One-sentence card-level summary.'
links:
  - label: 'Engineering blog post'
    href: 'https://example.com/templates/'
---
```

### OG image

Day 1 ships a static `public/og.png` (1200 × 630, dark, accent bar on the left). It is intentionally text-free — swap it for one with your name on it.

If you want a per-page generator pipeline, that's on the roadmap; for now, replace the file.

## Testing

```bash
npx playwright install --with-deps chromium  # first time only
npm run test
```

Day 1 ships a Playwright **smoke suite** (`tests/smoke.spec.ts`) that covers:

- The five core routes return 200, render an `<h1>`, and produce no console errors
- Home page at 375 × 667 has no horizontal scroll
- Theme toggle swaps `class="dark"` and `data-theme`, and persists across reload

The fuller test kit (axe a11y, full responsive matrix, Lighthouse CI, linkinator) lives in `.claude/skills/template-testing/SKILL.md` and will be added to this template in a follow-up.

When you add a new page or interactive widget, add a row to `tests/smoke.spec.ts`.

## Alternate deploys

The build output in `dist/` is plain static HTML/CSS/JS — drop it on any static host.

- **Vercel:** import the repo, framework preset Astro, set `PUBLIC_SITE_URL` + `PUBLIC_BASE_PATH=/` as env vars
- **Netlify:** same, with build command `npm run build`, publish directory `dist`
- **Cloudflare Pages:** same, build command `npm run build`, output `dist`

## Support / donations

This template is **MIT-licensed** and free. Use it personally, commercially, for client work — no permission needed, no attribution required (though appreciated).


The repo's "Sponsor" button is driven by the repo-root `.github/FUNDING.yml` (Ko-fi handle). Edit or delete that file in your fork to repoint or hide it.

The footer Ko-fi attribution is rendered by `<DonateButton>` (`src/components/DonateButton.astro`) and reads from `PUBLIC_AUTHOR_DONATE_URL`. Leave that env var blank to hide the link entirely.

## License

MIT. See [LICENSE](./LICENSE).

Built and maintained by [@example](#). Live at [example.com](https://example.com/templates).
