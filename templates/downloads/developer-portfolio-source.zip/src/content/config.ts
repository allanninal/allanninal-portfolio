import { defineCollection, z } from 'astro:content';

const work = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    role: z.string(),
    problem: z.string(),
    stack: z.array(z.string()),
    outcome: z.string(),
    year: z.number().int(),
    company: z.string().optional(),
    period: z.string().optional(),
    summary: z.string(),
    featured: z.boolean().default(true),
    order: z.number().int().default(0),
    links: z
      .array(
        z.object({
          label: z.string(),
          href: z.string().url(),
        })
      )
      .default([]),
  }),
});

const writing = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    description: z.string(),
    pubDate: z.coerce.date(),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { work, writing };
