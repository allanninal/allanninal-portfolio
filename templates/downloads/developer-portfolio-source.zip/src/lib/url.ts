// Base-path-aware URL helper. Always use this for internal links so the site
// works at both site root (custom domain) and a subpath (GitHub Pages, showcase).

const BASE = import.meta.env.BASE_URL; // already includes trailing slash

export function url(path: string): string {
  // Normalize so we can join without doubling slashes.
  const trimmedBase = BASE.endsWith('/') ? BASE.slice(0, -1) : BASE;
  if (!path || path === '/') return BASE;
  const trimmedPath = path.startsWith('/') ? path : `/${path}`;
  return `${trimmedBase}${trimmedPath}`;
}
