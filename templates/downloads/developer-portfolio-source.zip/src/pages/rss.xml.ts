import { getCollection } from 'astro:content';
import type { APIContext } from 'astro';
import { profile } from '~/data/profile';

export async function GET(context: APIContext) {
  const all = await getCollection('writing', ({ data }) => !data.draft);
  const items = all
    .sort((a, b) => b.data.pubDate.getTime() - a.data.pubDate.getTime())
    .map((entry) => {
      const link = new URL(`writing/${entry.slug}/`, context.site).toString();
      return `
    <item>
      <title><![CDATA[${entry.data.title}]]></title>
      <link>${link}</link>
      <guid>${link}</guid>
      <description><![CDATA[${entry.data.description}]]></description>
      <pubDate>${entry.data.pubDate.toUTCString()}</pubDate>
    </item>`;
    })
    .join('');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>${profile.name} — Writing</title>
    <link>${context.site}</link>
    <description>${profile.positioning}</description>
    ${items}
  </channel>
</rss>`;

  return new Response(xml, {
    headers: { 'Content-Type': 'application/rss+xml; charset=utf-8' },
  });
}
