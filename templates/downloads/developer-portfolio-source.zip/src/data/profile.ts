// Single source of truth for the persona behind this template.
// Cloning users edit this file to make the site theirs.

export const profile = {
  name: 'Jordan Reyes',
  firstName: 'Jordan',
  jobTitle: 'Senior Software Engineer',
  shortRole: 'Senior Software Engineer',
  location: 'Brooklyn, NY',
  pronoun: 'they',
  currentlyAt: 'Lumen Labs',
  email: 'hello@jordanreyes.com',
  // Used for schema.org "image"
  avatarUrl: '/avatar.svg',
  positioning:
    'Backend-leaning full-stack engineer focused on developer experience, build pipelines, and the parts of a product nobody screenshots.',
  tagline: 'Building tools that other engineers actually want to use.',
  bio: [
    "I'm Jordan, a senior software engineer based in Brooklyn. I've spent the last decade shipping infrastructure, internal platforms, and the occasional user-facing product at companies between five and five hundred engineers.",
    'My favorite work sits at the boundary between build systems and the people using them — type-safe data layers, hermetic CI, deploy pipelines that fail loudly and recover quickly. I believe most "performance problems" are actually clarity problems wearing a costume.',
    "Currently a staff engineer at Lumen Labs working on developer platform. Open to selective contract work and conference talks. Not looking for a new full-time role right now.",
  ],
  // schema.org sameAs
  // These default to the demo author's real accounts so the demo is
  // clickable. Cloning users SHOULD replace them with their own.
  socials: {
    github: 'https://github.com/allanninal',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    x: 'https://x.com/allannin',
    facebook: 'https://www.facebook.com/allan.ninal/',
    threads: 'https://www.threads.com/@allan.ninal',
    instagram: 'https://www.instagram.com/allan.ninal/',
    rss: '/rss.xml',
  },
  knowsAbout: [
    'TypeScript',
    'Go',
    'Distributed systems',
    'Build tooling',
    'Continuous integration',
    'Developer experience',
    'PostgreSQL',
    'Observability',
  ],
  experience: [
    {
      company: 'Lumen Labs',
      role: 'Staff Software Engineer, Developer Platform',
      period: '2023 — Present',
      bullets: [
        'Owns the internal CI/CD platform used by ~120 engineers across 9 product teams.',
        'Cut median pipeline runtime from 22 minutes to 4 minutes by introducing remote build caching and Bazel-style action graph hashing.',
      ],
    },
    {
      company: 'Northwind Studios',
      role: 'Senior Engineer, Infrastructure',
      period: '2020 — 2023',
      bullets: [
        'Led the migration of the monolith to a service mesh on Kubernetes without a customer-visible incident.',
        'Designed the multi-tenant feature flag service used by every product surface; now serves 40k req/s at p99 < 8ms.',
      ],
    },
    {
      company: 'Atlas Systems',
      role: 'Software Engineer',
      period: '2018 — 2020',
      bullets: [
        'Shipped the first version of the customer data export pipeline; still in production five years later.',
        'Reduced AWS spend 31% by right-sizing reserved capacity and consolidating staging clusters.',
      ],
    },
    {
      company: 'Field & Pine Co.',
      role: 'Junior Engineer',
      period: '2016 — 2018',
      bullets: [
        'First engineering hire. Built the Rails monolith that eventually got migrated away from (sorry).',
        'Wrote the original deploy scripts. They were bash. They were fine.',
      ],
    },
  ],
  speaking: [
    { event: 'StaffPlus NYC', year: 2025, talk: 'The boring layer underneath every fast deploy' },
    { event: 'LeadDev London', year: 2024, talk: 'Hermetic CI without the religion' },
  ],
};

export type Profile = typeof profile;
