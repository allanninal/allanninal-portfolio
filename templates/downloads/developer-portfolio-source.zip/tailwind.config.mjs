/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
        display: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // Modular scale 1.25 (major third) anchored at 16px body
        'xs':  ['0.8rem',   { lineHeight: '1.5' }],
        'sm':  ['0.9rem',   { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.7' }],
        'lg':  ['1.125rem', { lineHeight: '1.65' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.35' }],
        '3xl': ['1.875rem', { lineHeight: '1.25' }],
        '4xl': ['2.25rem',  { lineHeight: '1.15' }],
        '5xl': ['3rem',     { lineHeight: '1.1' }],
        '6xl': ['3.75rem',  { lineHeight: '1.05' }],
        '7xl': ['4.5rem',   { lineHeight: '1' }],
      },
      colors: {
        // Zinc-leaning neutral, dark-default
        ink: {
          50:  '#fafafa',
          100: '#f4f4f5',
          200: '#e4e4e7',
          300: '#d4d4d8',
          400: '#757582',
          500: '#71717a',
          600: '#52525b',
          700: '#3f3f46',
          800: '#27272a',
          900: '#18181b',
          950: '#09090b',
        },
        // Warm amber/orange accent — distinct from showcase purple #7c5cff
        accent: {
          DEFAULT: '#a46907',
          muted:   '#b45309',
          soft:    '#fbbf24',
        },
      },
      maxWidth: {
        prose: '68ch',
        '8xl': '88rem',
      },
      letterSpacing: {
        tightest: '-0.04em',
      },
    },
  },
};
