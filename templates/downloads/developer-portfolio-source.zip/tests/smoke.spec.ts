import { test, expect, type ConsoleMessage } from '@playwright/test';

// The Pro edition (PUBLIC_EDITION=pro) adds the standalone /services/ page;
// the free build redirects it, so it's only a real route under Pro.
const ROUTES = [
  '/',
  '/work/',
  '/writing/',
  '/work/lumen-ci-cache/',
  '/writing/measure-before-you-cache/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/services/'] : []),
];

// Ignore third-party noise from the author-deploy analytics/ads stack
// (GA + AdSense), which 403/CSP-warn under a real Chrome but never under the
// bundled headless browser. None of it is the template's own code.
const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
const isThirdParty = (m: ConsoleMessage) =>
  THIRD_PARTY.test(m.text()) ||
  THIRD_PARTY.test(m.location()?.url ?? '') ||
  /failed to load resource/i.test(m.text());

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() === 'error' && !isThirdParty(m)) errors.push(`console.error: ${m.text()}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home @ 375x667 has no horizontal scroll', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  // Wait for initial paint
  await page.locator('h1').first().waitFor();
  const overflow = await page.evaluate(() => {
    const html = document.documentElement;
    return html.scrollWidth > html.clientWidth;
  });
  expect(overflow).toBe(false);
});

test('theme toggle swaps class and persists across reload', async ({ page }) => {
  await page.goto('/');
  // Read initial state
  const initialDark = await page.evaluate(() => document.documentElement.classList.contains('dark'));

  await page.getByRole('button', { name: /toggle theme/i }).click();

  const afterDark = await page.evaluate(() => document.documentElement.classList.contains('dark'));
  expect(afterDark).toBe(!initialDark);

  // localStorage was written
  const stored = await page.evaluate(() => localStorage.getItem('theme'));
  expect(stored).toBe(afterDark ? 'dark' : 'light');

  // Reload — state must persist
  await page.reload();
  const reloadedDark = await page.evaluate(() => document.documentElement.classList.contains('dark'));
  expect(reloadedDark).toBe(afterDark);

  // data-theme attribute also reflects
  const dataTheme = await page.evaluate(() => document.documentElement.dataset.theme);
  expect(dataTheme).toBe(reloadedDark ? 'dark' : 'light');
});
