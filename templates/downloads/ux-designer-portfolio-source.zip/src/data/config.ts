// Devra Okonkwo — Minneapolis, MN. Fictional. The organising idea is
// attribution: every claim on this page names which parts were mine and who
// did the rest, because every portfolio in this trade says "we" and every
// reader hears "I".
//
// `role` is one of 'led' | 'did' | 'helped' | 'none'. The matrix is generated
// from it, the counts in the prose are generated from it, and there is no
// second place where a contribution is asserted.

export const site = {
  name:        'Devra Okonkwo',
  shortName:   'Devra Okonkwo',
  title:       'Devra Okonkwo — UX designer, Minneapolis',
  tagline:     'Every portfolio says “we”.',
  owner:       'Devra Okonkwo',
  ownerRole:   'UX designer',
  credential:  'Nine years · product and service · in-house and contract',
  city:        'Minneapolis',
  state:       'MN',
  language:    'en',
  phoneDisplay: '(612) 555-0198',
  phoneHref:   '+16125550198',
  email:       'devra@okonkwo.example',
  streetAddress: '1417 Nicollet Ave',
  postalCode:  '55403',
  hours:       'Contract work booked a month out · one project at a time',
  bookingWindow: 'Available from March · one engagement at a time, which is a constraint rather than a policy',
  description:
    'Four projects, eight disciplines, and a cell for each one saying whether I led it, did it, ' +
    'helped with it, or had nothing to do with it — with the people who did the rest named ' +
    'underneath. Then the outcomes, including the two that did not move and the two nobody ' +
    'measured.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Who did what', href: '#matrix' },
  { label: 'Projects',     href: '#projects' },
  { label: 'Outcomes',     href: '#outcomes' },
  { label: 'Work with me', href: '#contact' },
];

// ── The disciplines ───────────────────────────────────────────────────────

export const disciplines = [
  { id: 'research',  k: 'User research' },
  { id: 'ia',        k: 'IA and flows' },
  { id: 'ix',        k: 'Interaction design' },
  { id: 'visual',    k: 'Visual design' },
  { id: 'content',   k: 'Content design' },
  { id: 'proto',     k: 'Prototyping' },
  { id: 'testing',   k: 'Usability testing' },
  { id: 'frontend',  k: 'Front-end build' },
];

// ── The projects ──────────────────────────────────────────────────────────
// `roles` maps discipline id → 'led' | 'did' | 'helped' | 'none'.
// `others` names the people who did the work that was not mine. Nobody
// publishes this and it is the whole point of the page.

export const projects = [
  {
    id: 'clinic',
    name: 'Patient intake, regional clinic group',
    year: '2025',
    team: 'Team of six · eleven weeks',
    brief: 'Replace a paper intake form and a kiosk nobody used with something a person can finish in a waiting room on their own phone.',
    shipped: 'A seven-screen flow, in production at nine sites. Median completion 4 min 20 s, down from a paper form that took 9 minutes and was 31% incomplete at the desk.',
    roles: { research: 'led', ia: 'led', ix: 'did', visual: 'helped', content: 'did', proto: 'did', testing: 'led', frontend: 'none' },
    others: 'Front-end was Halvard Nyquist, two engineers. The visual language was already a design system I did not build; I chose from it and argued about two components.',
  },
  {
    id: 'freight',
    name: 'Dispatch console, regional freight',
    year: '2024',
    team: 'Team of four · nine months, part time',
    brief: 'One screen that eleven dispatchers look at for eight hours a day. The old one had 340 rows visible at once and everybody had built their own colour-coded system in a spreadsheet beside it.',
    shipped: 'A density-first console with saved views. Still in use. The spreadsheets did not disappear and I have stopped thinking that was a failure.',
    roles: { research: 'led', ia: 'led', ix: 'led', visual: 'none', content: 'helped', proto: 'did', testing: 'did', frontend: 'helped' },
    others: 'Visual design was entirely Ines Bergqvist, who is the reason the thing is legible at 340 rows. I wrote CSS for the table layout and nothing else.',
  },
  {
    id: 'library',
    name: 'Catalogue search, county library system',
    year: '2024',
    team: 'Team of three · six weeks',
    brief: 'Search that returned 900 results for “toni morrison” and put the large-print edition of a study guide first.',
    shipped: 'Reworked ranking and a facet rail. The interesting part was not the interface — it was a metadata cleanup nobody wanted to fund and I did not do.',
    roles: { research: 'did', ia: 'led', ix: 'did', visual: 'did', content: 'led', proto: 'did', testing: 'helped', frontend: 'did' },
    others: 'The ranking change was Marguerite Tolliver, a librarian who understood the catalogue better than any of us. I built the front end because there was nobody else, and it shows in two places.',
  },
  {
    id: 'benefits',
    name: 'Benefits enrolment, 900-person employer',
    year: '2023',
    team: 'Team of nine · fourteen weeks',
    brief: 'An annual enrolment where 40% of staff picked the default because reading the alternative took an hour.',
    shipped: 'A comparison step and plain-language summaries. Default-picking fell to 26%, and I do not know how much of that was the design and how much was HR emailing everybody twice.',
    roles: { research: 'helped', ia: 'did', ix: 'did', visual: 'none', content: 'led', proto: 'helped', testing: 'none', frontend: 'none' },
    others: 'Research was led by Anneke Prud’homme; I ran four of nineteen sessions. Visual design and build were an agency. Usability testing was run by their team and I watched.',
  },
];

export const matrixNote =
  'Four words, and the fourth one is the reason the table exists. On the freight console I did ' +
  'not touch visual design and it is the best-looking thing on this page. On the benefits ' +
  'project I ran four of nineteen research sessions and would have been within convention to ' +
  'write “led discovery”. Nobody would have checked.';

// ── One project, told properly ────────────────────────────────────────────

export const belief = {
  project: 'Patient intake, regional clinic group',
  steps: [
    { k: 'What I believed in week one', n: 'That the kiosk failed because it was ugly and slow, and that the same flow on a phone would fix it. I had a prototype by day four. It tested well with eight people in a room in an office.' },
    { k: 'What the research actually found', n: 'Eleven of nineteen patients were filling the form for somebody else — a parent, a partner, an adult child. The kiosk was not slow for them, it was wrong: every field said “you”.' },
    { k: 'What that killed', n: 'The prototype, and three weeks. Also the idea that completion time was the metric, since a proxy filling a form carefully takes longer and that is the good outcome.' },
    { k: 'What we changed', n: 'One question at the top: who is this for. It rewrites the pronouns in every subsequent field. It is four lines of logic and it is the entire project.' },
    { k: 'What it cost', n: 'Three weeks of my work and a difficult conversation with a product manager who had already told a board the date. We shipped two weeks late. The board did not notice; the desk staff did.' },
    { k: 'What I would do differently', n: 'Run the nineteen sessions before building the prototype rather than beside it. I knew that. I built it anyway because a prototype is how I think, and the honest fix is to build it and then not show anybody for a week.' },
  ],
};

// ── Outcomes ──────────────────────────────────────────────────────────────
// `verdict` is 'moved' | 'flat' | 'unmeasured'. Two of each, deliberately.

export const outcomes = [
  { p: 'Patient intake', m: 'Completion at the desk', before: '69%', after: '94%', verdict: 'moved',
    n: 'Nine sites, six months either side, same season. The most defensible number on this page and I still would not put it on a slide without the window.' },
  { p: 'Patient intake', m: 'Median time to complete', before: '9 min', after: '4 min 20 s', verdict: 'moved',
    n: 'Genuine, and less meaningful than it looks: a proxy filling the form for somebody else takes longer, and that is the outcome we wanted.' },
  { p: 'Dispatch console', m: 'Time to reassign a load', before: '41 s', after: '38 s', verdict: 'flat',
    n: 'Three seconds is noise at n=11. I called this a win internally for about a week and I was wrong to.' },
  { p: 'Dispatch console', m: 'Spreadsheets still in use', before: '11 of 11', after: '9 of 11', verdict: 'flat',
    n: 'The thing I actually set out to remove. Two dispatchers stopped; nine did not, and their spreadsheets do something the console genuinely does not.' },
  { p: 'Catalogue search', m: 'Zero-result searches', before: '12.4%', after: '3.1%', verdict: 'moved',
    n: 'Almost entirely the metadata cleanup, which I did not do. Putting it in my portfolio at all is a stretch and leaving it out would be a different kind of dishonest.' },
  { p: 'Catalogue search', m: 'Whether people found the right book', before: '—', after: '—', verdict: 'unmeasured',
    n: 'Never measured. We had no way to see whether a search ended in the book somebody wanted, and every number above is a proxy for that question.' },
  { p: 'Benefits enrolment', m: 'Staff taking the default', before: '40%', after: '26%', verdict: 'moved',
    n: 'HR also emailed everybody twice that year. I have no way to separate the two and neither does anybody else who has ever reported a number like this.' },
  { p: 'Benefits enrolment', m: 'Whether people chose better plans', before: '—', after: '—', verdict: 'unmeasured',
    n: 'Never measured, and it is the only question that mattered. Nobody wanted to fund the claims-data analysis that would have answered it.' },
];

// ── What I need ───────────────────────────────────────────────────────────

export const needs = [
  { t: 'Five of your users, for an hour each',
    d: 'Not five stakeholders. Not a survey. Five people who use the thing, on a call, in the first two weeks. If that is genuinely impossible the engagement is still doable and everything I produce is a hypothesis, and I will label it as one throughout.' },
  { t: 'One person who can decide',
    d: 'In the room, or at least reachable in a day. A project with three decision-makers and no tiebreak does not produce a worse design; it produces the same design four times.' },
  { t: 'Read access to whatever you already measure',
    d: 'Analytics, support tickets, the spreadsheet somebody keeps. I would rather spend a day in your existing data than a week reproducing it badly.' },
  { t: 'Permission to ship something smaller',
    d: 'The single highest-value thing I can be given. Almost every project on this page got better when somebody agreed to cut a third of it, and none of them were scoped that way at the start.' },
];

// ── How a project runs ────────────────────────────────────────────────────

export const intake = [
  { k: 'Week 0', d: 'Nothing is designed', n: 'Reading. Support tickets, existing analytics, whatever research already exists and got shelved. Most organisations have already been told the answer once.' },
  { k: 'Weeks 1–2', d: 'Still nothing is designed', n: 'The five conversations. Recorded with permission, transcribed, and quoted rather than summarised — a summary is where a research finding goes to become whatever the reader already believed.' },
  { k: 'Week 3', d: 'One page', n: 'What I think is true, what I am unsure of, and what I would need to find out. Reviewed with the decision-maker before anything is drawn. This is the meeting that decides whether the project works.' },
  { k: 'Weeks 4–7', d: 'Design, out loud', n: 'Flows, then screens, in public — a shared file with everything in it including the discarded versions. No reveals. A reveal is a way of avoiding a conversation.' },
  { k: 'Weeks 6–9', d: 'Testing, in rounds of five', n: 'Overlapping the design, not after it. Five people, three rounds, and the third round exists to check the fixes from the first two rather than to find new problems.' },
  { k: 'Handover', d: 'A file and two hours', n: 'Annotated states including the empty, error and loading ones, plus two hours with whoever builds it. The two hours are worth more than the annotations.' },
];

export const faqs = [
  {
    q: 'Why publish who did what? Nobody else does.',
    a: 'Because the first twenty minutes of every interview I have ever had were spent establishing it, politely and slowly. Putting it on the page gets that out of the way, and it means the things I did claim can be taken at face value. The cost is that the best-looking project on this site has “Not me” under visual design.',
  },
  {
    q: 'Is “Led” different from “Did”?',
    a: 'Led means I set the approach and other people worked to it. Did means I did the work, alone or nearly. Helped means somebody else owned it and I contributed real hours — not that I was in the meetings. If I was only in the meetings, the cell says “Not me”.',
  },
  {
    q: 'Why show flat results?',
    a: 'Because most results are flat, and a portfolio showing only the ones that moved is reporting a selection. The dispatch console reassignment time went from 41 seconds to 38 at n=11, which is noise, and I called it a win internally for a week before I looked at it properly.',
  },
  {
    q: 'What does “never measured” mean here?',
    a: 'That the question nobody answered was usually the important one. On the library project we never found out whether people got the right book; on benefits enrolment we never found out whether people chose better plans. Both would have been expensive to measure and both were the point.',
  },
  {
    q: 'Do you do visual design?',
    a: 'Competently, not excellently, and the matrix says so in two places. On a project where the interface has to be beautiful I would rather work alongside somebody who is genuinely good at it, and I have twice, and both times the work was better.',
  },
  {
    q: 'What if we cannot give you access to users?',
    a: 'Then we do the work anyway and everything I produce is labelled as a hypothesis rather than as a finding, throughout, including in the final deck. It is a real constraint and it is not a dealbreaker. What is a dealbreaker is being told there is access and then finding out in week four that there is not.',
  },
];
