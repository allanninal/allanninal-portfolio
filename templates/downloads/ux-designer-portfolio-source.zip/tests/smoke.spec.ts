import { test, expect } from '@playwright/test';

const int = (s: string) => Number((s.match(/-?[\d,.]+/) || ['0'])[0].replace(/,/g, ''));

test.describe('Devra Okonkwo — smoke tests', () => {
  test('homepage renders with the designer in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Devra Okonkwo/);
    await expect(page.locator('h1')).toContainText('Every portfolio says');
  });

  // A ProfilePage around a Person — not day 120's Organization, not day 119's
  // LocalBusiness.
  test('is a ProfilePage around a Person', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('ProfilePage'))!);
    const s = JSON.parse(raw);
    expect(s['@type']).toBe('ProfilePage');
    expect(s.mainEntity['@type']).toBe('Person');
    expect(raw).not.toContain('Organization');
    expect(raw).not.toContain('MusicAlbum');
  });

  // knowsAbout is a flat list of strings and this page's whole subject is that
  // contribution is not flat. The rule: led at least once, or it is not in there.
  test('knowsAbout lists only disciplines the matrix says were led', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('ProfilePage'))!);
    const knows: string[] = JSON.parse(raw).mainEntity.knowsAbout;

    const headers = (await page.locator('#matrix thead th').allTextContents()).slice(1);
    const rows = await page.locator('#matrix tbody tr').evaluateAll((trs) =>
      trs.map((tr) => [...tr.querySelectorAll('td .role')].map((r) => r.className)));
    const ledCols = headers.filter((_, i) => rows.some((r) => r[i].includes('role--led')));

    expect(new Set(knows)).toEqual(new Set(ledCols));
    expect(knows.length).toBeLessThan(headers.length);
    // Prototyping is "Did" on three projects and is deliberately absent.
    expect(knows.join(' ')).not.toContain('Prototyping');
  });

  // ── The matrix ──────────────────────────────────────────────────────────
  test('the matrix is visible and complete', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#matrix table.spec');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(200);
    const cols = (await page.locator('#matrix thead th').count()) - 1;
    const rows = await page.locator('#matrix tbody tr').count();
    expect(cols).toBe(8);
    expect(rows).toBe(4);
    expect(await page.locator('#matrix tbody .role').count()).toBe(cols * rows);
  });

  test('four states, each printed as a word with a glyph and its own colour', async ({ page }) => {
    await page.goto('/');
    const roles = page.locator('#matrix tbody .role');
    for (const r of await roles.all()) {
      expect(((await r.textContent()) || '').trim()).toMatch(/^(Led|Did|Helped|Not me)$/);
      expect(await r.getAttribute('data-glyph')).toBeTruthy();
    }
    const colours = await roles.evaluateAll((els) =>
      [...new Set(els.map((e) => getComputedStyle(e).color))]);
    expect(colours.length).toBe(4);
    // The key defines all four in prose before the table uses any of them.
    const key = page.locator('#matrix .key > div');
    expect(await key.count()).toBe(4);
    for (const k of await key.all()) {
      expect(((await k.locator('p').textContent()) || '').length).toBeGreaterThan(30);
    }
  });

  test('the headline counts are arithmetic over the matrix', async ({ page }) => {
    await page.goto('/');
    const classes = await page.locator('#matrix tbody .role').evaluateAll((els) =>
      els.map((e) => e.className));
    const led = classes.filter((c) => c.includes('role--led')).length;
    const none = classes.filter((c) => c.includes('role--none')).length;
    const h2 = (await page.locator('#matrix h2').textContent()) || '';
    expect(h2).toContain(`${led} of ${classes.length} say I led it`);
    expect(h2).toContain(`${none} say it was not me`);
    expect(none).toBeGreaterThan(0);
  });

  // ── Projects ────────────────────────────────────────────────────────────
  test('every project names who did the work that was not me', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#projects article');
    expect(await cards.count()).toBe(4);
    for (const c of await cards.all()) {
      const others = (await c.locator('.others').textContent()) || '';
      expect(others.length).toBeGreaterThan(60);
      // A real name, not "the team".
      expect(others).toMatch(/[A-Z][a-zà-ÿ’]+ [A-Z][a-zà-ÿ’]+/);
    }
  });

  // ── The belief sequence ─────────────────────────────────────────────────
  test('the case study runs in the order it happened, not challenge-process-solution', async ({ page }) => {
    await page.goto('/');
    const steps = page.locator('#belief ol.seq li');
    expect(await steps.count()).toBe(6);
    const first = (await steps.first().locator('.k').textContent()) || '';
    expect(first).toMatch(/believed/i);
    await expect(page.locator('#belief')).toContainText(/never the order it happens in/);
    const html = (await page.locator('#belief').innerHTML()).toLowerCase();
    expect(html).not.toContain('double diamond');
    await expect(steps.nth(4).locator('.k')).toContainText('What it cost');
  });

  // ── Outcomes ────────────────────────────────────────────────────────────
  test('outcomes include flat results and unmeasured ones', async ({ page }) => {
    await page.goto('/');
    const verdicts = await page.locator('#outcomes .verdict').allTextContents();
    expect(verdicts.length).toBe(8);
    expect(verdicts.filter((v) => /^Flat$/i.test(v.trim())).length).toBeGreaterThan(1);
    expect(verdicts.filter((v) => /never measured/i.test(v)).length).toBeGreaterThan(1);
    // The eyebrow count matches.
    const eyebrow = (await page.locator('#outcomes .eyebrow').textContent()) || '';
    expect(eyebrow).toContain(`${verdicts.filter((v) => /^Flat$/i.test(v.trim())).length} flat`);
  });

  test('every outcome carries the caveat that would be left off a slide', async ({ page }) => {
    await page.goto('/');
    for (const r of await page.locator('#outcomes tbody tr').all()) {
      expect(((await r.locator('td').last().textContent()) || '').length).toBeGreaterThan(70);
    }
    // The flat one that was called a win, admitted.
    await expect(page.locator('#outcomes')).toContainText(/called this a win internally/);
    // A moved metric that credits somebody else.
    await expect(page.locator('#outcomes')).toContainText(/which I did not do/);
  });

  test('unmeasured rows print a dash rather than inventing a number', async ({ page }) => {
    await page.goto('/');
    for (const r of await page.locator('#outcomes tbody tr').all()) {
      const v = (await r.locator('.verdict').textContent()) || '';
      if (/never measured/i.test(v)) {
        const cells = await r.locator('td.v').allTextContents();
        expect(cells.every((c) => c.trim() === '—')).toBe(true);
      }
    }
  });

  // ── Absences ────────────────────────────────────────────────────────────
  test('there is no testimonial anywhere on the page', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('blockquote').count()).toBe(0);
    expect(await page.locator('cite').count()).toBe(0);
  });

  test('what I need from a client is stated as a definition list', async ({ page }) => {
    await page.goto('/');
    const dl = page.locator('#needs dl.defs');
    expect(await dl.locator('dt').count()).toBe(4);
    await expect(dl).toContainText(/Five of your users/);
    await expect(dl).toContainText(/Permission to ship something smaller/);
  });

  test('the intake sequence puts three weeks before any design', async ({ page }) => {
    await page.goto('/');
    const seq = page.locator('#needs ol.seq li');
    expect(await seq.count()).toBe(6);
    const firstTwo = (await seq.nth(0).textContent() || '') + (await seq.nth(1).textContent() || '');
    expect(firstTwo).toMatch(/[Nn]othing is designed/);
  });

  test('the FAQ is an accordion', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the contact form asks who decides', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#who', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('select').count()).toBe(0);
  });

  test('no trace of the day-120 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['quarry line', 'lawrence', 'pressing', 'lacquer', 'plant slot']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro research plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/research-plan/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
