// Meridian Paint Studio — Boulder, CO.
//
// The load-bearing physical fact of paint correction, and the one almost no
// detailer puts on a website because it caps what can be sold: clear coat is
// finite. Every correction removes some and none of it comes back.

export const site = {
  name:        'Meridian Paint Studio',
  shortName:   'Meridian',
  title:       'Meridian Paint Studio — Auto Detailing in Boulder, CO',
  tagline:     'We measure before we polish.',
  owner:       'Ilinca Petrescu',
  ownerRole:   'IDA Certified Detailer',
  credential:  'IDA Certified Detailer · Skilled Ceramic Coating Installer',
  license:     'International Detailing Association Certified Detailer',
  city:        'Boulder',
  state:       'CO',
  language:    'en',
  phoneDisplay: '(303) 555-0176',
  phoneHref:   '+13035550176',
  email:       'studio@meridianpaint.example',
  streetAddress: '4820 Pearl East Cir',
  postalCode:  '80301',
  hours:       'Tue–Sat 8am–5pm · by appointment, one car at a time',
  bookingWindow: 'Two cars a week. Currently booking three weeks out.',
  description:
    'An IDA-certified paint studio in Boulder. Every car gets a depth gauge before ' +
    'a machine touches it, and this page publishes one real survey — including the ' +
    'two panels we told the owner we would not polish.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The survey', href: '#survey' },
  { label: 'The budget', href: '#budget' },
  { label: 'Coatings',   href: '#coatings' },
  { label: 'Services',   href: '#services' },
  { label: 'Areas',      href: '#areas' },
  { label: 'FAQ',        href: '#faq' },
];

// ── The physical constants the page runs on ───────────────────────────────

export const paint = {
  car:      '2019 Audi A4, Mythos Black',
  factoryLow:  40,   // µm — typical factory clear coat floor
  factoryHigh: 55,   // µm — typical factory clear coat ceiling
  safeFloor:   25,   // µm — below this, do not cut
  scaleMax:    160,  // µm — the meter ceiling, chosen so a repainted panel fits
  unit:     'µm',
  note:
    'Factory clear coat on a modern car is roughly 40 to 55 microns — about half ' +
    'the thickness of a sheet of paper. Below about 25 microns the clear is at ' +
    'risk of failing, and nobody should be cutting it. Those two numbers are the ' +
    'whole reason we own a gauge.',
};

// state: ok | thin | repaint
export const panels = [
  { id: 'bonnet',   name: 'Bonnet',            reading: 42,  state: 'ok',
    note: 'Healthy but the lowest of the horizontal panels, which is normal. Sun and washing both land here.' },
  { id: 'roof',     name: 'Roof',              reading: 31,  state: 'thin',
    note: 'Thin. Six microns above the floor. One previous correction here at most, and we are not adding another.' },
  { id: 'boot',     name: 'Boot lid',          reading: 46,  state: 'ok',
    note: 'Good. Full correction available if it is ever wanted.' },
  { id: 'fdoor-l',  name: 'Front door, left',  reading: 140, state: 'repaint',
    note: 'Three times its neighbours. This panel has been repainted, almost certainly after a door strike.' },
  { id: 'rdoor-l',  name: 'Rear door, left',   reading: 47,  state: 'ok',
    note: 'Factory. The step to the front door is what identifies the repaint.' },
  { id: 'fdoor-r',  name: 'Front door, right', reading: 45,  state: 'ok',
    note: 'Factory, and the reference we measured the left side against.' },
  { id: 'wing-r',   name: 'Wing, right',       reading: 44,  state: 'ok',
    note: 'Factory. Light swirling only, a single finishing pass will clear it.' },
  { id: 'bumper-r', name: 'Rear bumper',       reading: 38,  state: 'ok',
    note: 'Plastic, so it reads differently from steel and always will. Not a concern at this figure.' },
];

export const surveyClosing =
  'Two of the eight panels above change what we are willing to do to this car. ' +
  'The roof gets protected and left alone. The repainted door gets a lighter pass ' +
  'than the rest, because refinish clear is softer than factory and cuts faster.';

// ── The micron budget ─────────────────────────────────────────────────────

export const budget = {
  intro:
    'A car has a finite number of corrections in it — commonly three or four across ' +
    'its whole life. This is what each level spends. A shop selling an annual ' +
    'correction is spending something the owner cannot buy back.',
  levels: [
    { level: 'Wash and decontaminate', cut: '0 µm',    how: 'Chemical and clay. Removes what is sitting on the paint, not any of the paint.' },
    { level: 'Finishing polish',       cut: '1–3 µm',  how: 'A soft pad and a fine polish. Clears light swirling and haze.' },
    { level: 'One-step correction',    cut: '3–5 µm',  how: 'Cut and finish in one pass. Removes most moderate defects.' },
    { level: 'Two-step correction',    cut: '6–10 µm', how: 'Compound then refine. This is where the number starts to matter.' },
    { level: 'Wet sanding',            cut: '5–15 µm', how: 'Only on a measured panel, only for a defect worth it, and never on the roof of this car.' },
  ],
  maths:
    'At 42 microns the bonnet has about 17 microns of usable clear above the floor. ' +
    'That is roughly three one-step corrections, or two two-steps, for the rest of ' +
    'the car’s life.',
};

// ── Coatings, honestly ────────────────────────────────────────────────────

export const coatings = {
  intro: 'What a ceramic coating does, and the three things it is regularly sold as doing but does not.',
  does: [
    'Adds gloss and depth, measurably, on a corrected panel.',
    'Makes washing faster and reduces how often the paint needs touching at all.',
    'Resists chemical etching from bird droppings, sap and industrial fallout.',
    'Lasts two to five years depending on the product and how the car is washed.',
  ],
  doesNot: [
    { claim: 'Prevents scratches',      truth: 'It does not. A coating is a few microns of hard sacrificial layer; anything that would scratch clear coat will scratch through it.' },
    { claim: 'Means you never wash it', truth: 'You wash it more gently and less often. A neglected coated car looks worse than a neglected uncoated one.' },
    { claim: 'Undoes existing defects', truth: 'It seals in whatever is underneath. Correction happens first or not at all — which is why the survey comes before the quote.' },
  ],
};

export const services = [
  { name: 'Survey and consultation',  price: '$95',        note: 'Depth gauge over every panel, written up. Applied to any work booked.' },
  { name: 'Wash and decontaminate',   price: '$180',       note: 'No machine work. Removes nothing but contamination.' },
  { name: 'Finishing polish',         price: '$420',       note: 'One to three microns. The safest thing we do.' },
  { name: 'One-step correction',      price: '$680',       note: 'Quoted per panel after the survey, never before it.' },
  { name: 'Two-step correction',      price: '$1,150+',    note: 'Only where the readings support it. We will decline panels.' },
  { name: 'Ceramic coating',          price: '$900–$1,600', note: 'Priced by product and by how much correction it is going over.' },
];

export const areas = [
  { zone: 'Boulder',    towns: 'Downtown, Chautauqua, Newlands, Gunbarrel' },
  { zone: 'North',      towns: 'Longmont, Niwot, Lyons, Erie' },
  { zone: 'South',      towns: 'Louisville, Superior, Lafayette, Broomfield' },
  { zone: 'Front Range', towns: 'Golden, Arvada, Westminster — collection by arrangement' },
];

export const reviews = [
  { name: 'Sunniva Blackwood', town: 'Newlands',   text: 'She measured the roof, showed me the number, and told me not to spend the money. I booked the coating instead and I will be back.' },
  { name: 'Tobias Nakamura',   town: 'Longmont',   text: 'Found a repainted door on a car I had owned for four years and never known about. That alone was worth the survey fee.' },
  { name: 'Delphine Osei',     town: 'Louisville', text: 'The quote came after the measurements, itemised per panel. Nobody else I called would do it in that order.' },
  { name: 'Rurik Halvorsen',   town: 'Gunbarrel',  text: 'Asked about a yearly polish. Got a straight answer about why that is a bad idea, with the arithmetic.' },
];

export const faqs = [
  {
    q: 'Why does the survey cost money?',
    a: 'It takes about forty minutes with a gauge and it is the part that decides everything else. It comes off any work you book, so if you go ahead it costs you nothing.',
  },
  {
    q: 'Can you not just polish it until it looks right?',
    a: 'On most panels, yes. On a panel reading 31 microns, no — that is six above the floor, and getting the last of the swirling out would put the clear at risk of failing. We would rather protect what is there.',
  },
  {
    q: 'What does a repainted panel mean for me?',
    a: 'Usually nothing bad. It means the panel has more material but softer material, so it cuts faster and needs a lighter touch. It is also worth knowing if you are buying the car.',
  },
  {
    q: 'Will a coating stop scratches?',
    a: 'No, and anyone telling you otherwise is selling. It is a hard sacrificial layer a few microns thick. It resists chemical etching well and it makes washing easier, both of which genuinely reduce how much the paint gets scratched over time — but that is a different claim.',
  },
  {
    q: 'How often should a car be corrected?',
    a: 'Three or four times in its life, not annually. There is a fixed budget of clear coat and correction is the only thing that spends it.',
  },
  {
    q: 'Do you do interiors?',
    a: 'Not as a standalone service. We are a paint studio and we would rather do one thing properly than list six.',
  },
];
