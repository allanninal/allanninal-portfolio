import { test, expect } from '@playwright/test';

test.describe('Meridian Paint Studio — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Meridian Paint Studio/);
    await expect(page.locator('h1')).toContainText('Clear coat');
  });

  // AutoBodyShop is the tempting fallback and it is wrong: this business does
  // not do collision repair or refinishing. AutoWash is the honest nearest fit.
  test('uses AutoWash, not the misleading AutoBodyShop fallback', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"AutoWash"');
    expect(json).not.toContain('AutoBodyShop');
    expect(json).not.toContain('AutoRepair');
    expect(json).not.toContain('AutoDealer');
  });

  // ── The survey ──────────────────────────────────────────────────────────
  test('every panel reading is a real <meter> with its bounds set', async ({ page }) => {
    await page.goto('/');
    const meters = page.locator('#survey meter');
    expect(await meters.count()).toBe(8);
    for (const m of await meters.all()) {
      for (const attr of ['min', 'max', 'low', 'high', 'optimum', 'value']) {
        expect(await m.getAttribute(attr)).not.toBeNull();
      }
    }
  });

  test('each meter value sits inside its own declared range', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#survey meter').evaluateAll((els) =>
      els.map((e) => ({
        min: Number(e.getAttribute('min')),
        max: Number(e.getAttribute('max')),
        value: Number(e.getAttribute('value')),
      })),
    );
    for (const r of rows) {
      expect(r.value).toBeGreaterThanOrEqual(r.min);
      expect(r.value).toBeLessThanOrEqual(r.max);
    }
  });

  test('every panel states a verdict in words, not only a border colour', async ({ page }) => {
    await page.goto('/');
    const v = await page.locator('#survey .panel-verdict').allTextContents();
    expect(v.length).toBe(8);
    for (const x of v) {
      expect(['Correction available', 'Do not polish', 'Refinish — lighter pass']).toContain(x.trim());
    }
  });

  // A survey where every panel is healthy teaches nothing. The two that are
  // not are the entire reason the page exists.
  test('the survey is not all-healthy, and the exceptions are the point', async ({ page }) => {
    await page.goto('/');
    const v = await page.locator('#survey .panel-verdict').allTextContents();
    const flagged = v.filter((x) => x.trim() !== 'Correction available');
    expect(flagged.length).toBe(2);
    expect(v.map((x) => x.trim())).toContain('Do not polish');
    expect(v.map((x) => x.trim())).toContain('Refinish — lighter pass');
  });

  // The repaint tell: a panel three times its neighbours has been refinished.
  test('the repainted panel really does read far above its neighbours', async ({ page }) => {
    await page.goto('/');
    const reads = await page.locator('#survey .panel').evaluateAll((els) =>
      els.map((e) => ({
        name: e.querySelector('.panel-name')?.textContent?.trim(),
        value: Number(e.querySelector('meter')?.getAttribute('value')),
        verdict: e.querySelector('.panel-verdict')?.textContent?.trim(),
      })),
    );
    const repaint = reads.find((r) => r.verdict?.startsWith('Refinish'));
    const factory = reads.filter((r) => r.verdict === 'Correction available');
    const avg = factory.reduce((n, r) => n + r.value, 0) / factory.length;
    expect(repaint!.value).toBeGreaterThan(avg * 2);
  });

  // The thin panel is the one that caps what can be sold.
  test('the headline headroom is derived from the thinnest reading', async ({ page }) => {
    await page.goto('/');
    const values = await page.locator('#survey meter').evaluateAll((els) =>
      els.map((e) => ({ v: Number(e.getAttribute('value')), low: Number(e.getAttribute('low')) })),
    );
    const thinnest = values.reduce((a, b) => (a.v < b.v ? a : b));
    const expected = thinnest.v - thinnest.low;
    await expect(page.locator('#budget h2')).toContainText(`${expected} microns left`);
  });

  test('the micron budget names what each pass spends', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#budget ol.budget li');
    expect(await items.count()).toBe(5);
    // Every level must carry a micron figure, or the budget is not a budget.
    for (const c of await items.locator('.cut').allTextContents()) {
      expect(c).toMatch(/µm/);
    }
    await expect(page.locator('#budget')).toContainText(/finite number of corrections/i);
  });

  test('coatings section publishes what a coating does not do', async ({ page }) => {
    await page.goto('/');
    const c = page.locator('#coatings');
    await expect(c).toContainText('Prevents scratches');
    await expect(c).toContainText(/It does not/);
    expect(await c.locator('dl > div').count()).toBe(3);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 88.
  test('no trace of the day-88 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['grainline', 'des moines', 'teodoro', 'ledger', 'odometer', 'subaru']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro paint depth log is absent from the free build', async ({ page }) => {
    const res = await page.goto('/paint-depth-log/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Reading bands');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
