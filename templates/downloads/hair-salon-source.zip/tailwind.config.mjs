/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Bellefair"', 'Georgia', 'serif'],
        sans: ['"Questrial"', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Mauve / Champagne / Ivory / Espresso palette
        mauve: {
          50:  '#FAF5FA',
          100: '#F3E8F3',
          200: '#E8D0E8',
          300: '#D9B5DA',
          400: '#C8A7C9',
          DEFAULT: '#C8A7C9',
          500: '#B589B7',
          600: '#9D6B9E',
          700: '#7D5080',
          800: '#5E3A61',
          900: '#3E2541',
        },
        champagne: {
          50:  '#FDFAF3',
          100: '#FAF3E0',
          DEFAULT: '#F0DEB4',
          200: '#F0DEB4',
          300: '#E5C882',
          400: '#D9B050',
          500: '#C49828',
        },
        ivory: {
          DEFAULT: '#FAFAF7',
          50: '#FAFAF7',
          100: '#F5F5F0',
          200: '#ECECE4',
        },
        espresso: {
          DEFAULT: '#2C1810',
          light: '#4A2C20',
          muted: '#6B4A3A',
          faint: '#9A7060',
        },
        // Surface tokens
        surface: {
          DEFAULT: '#FAFAF7',
          2: '#F5F0E8',
          3: '#EDE6D8',
          border: '#DDD0C0',
        },
      },
      maxWidth: {
        content: '72ch',
      },
    },
  },
  plugins: [],
};
