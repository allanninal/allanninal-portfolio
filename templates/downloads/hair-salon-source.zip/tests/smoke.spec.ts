import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Maison Lumière/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('services section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#services')).toBeVisible();
});

test('services tabs are present', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('team section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#team')).toBeVisible();
});

test('team has stylist cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#team article');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('booking section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#booking')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('hours table is rendered', async ({ page }) => {
  await page.goto('/');
  const hoursRows = page.locator('#location dl > div');
  const count = await hoursRows.count();
  expect(count).toBeGreaterThanOrEqual(7);
});

test('nav book CTA is present', async ({ page }) => {
  await page.goto('/');
  const bookCta = page.locator('#nav-book-cta');
  await expect(bookCta).toBeVisible();
});

test('hero book CTA is present', async ({ page }) => {
  await page.goto('/');
  const heroCta = page.locator('#hero-book-cta');
  await expect(heroCta).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('site footer is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('contentinfo')).toBeVisible();
});

test('services tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = await page.locator('[role="tab"]').all();
  // Click the second tab
  if (tabs.length >= 2) {
    await tabs[1].click();
    const selected = await tabs[1].getAttribute('aria-selected');
    expect(selected).toBe('true');
  }
});
