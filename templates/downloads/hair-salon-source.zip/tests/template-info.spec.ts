import { test, expect } from '@playwright/test';

// Edition-aware: the Pro edition swaps the free download bar for a
// "Pro edition — live preview" strip with a locked Get-Pro link.
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';

test('TemplateInfo renders the canonical bar when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const info = page.locator(`[aria-label="${barLabel}"]`);
  await expect(info).toBeVisible();

  const allLink = info.locator('a', { hasText: 'All 365' });
  await expect(allLink).toBeVisible();

  if (isPro) {
    const getPro = info.locator('a', { hasText: 'Get Pro static' });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    await expect(info.locator('a[download]').first()).toBeVisible();
    return;
  }

  await expect(info.locator('a[download]').first()).toBeVisible();
  await expect(info.locator('a[download]').nth(1)).toBeVisible();

  const hireLink = info.locator('a', { hasText: 'Build with me' });
  await expect(hireLink).toBeVisible();
  expect(await hireLink.getAttribute('href')).toContain('linkedin.com');
});

test('TemplateInfo has no github.com/allanninal/templates links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`[aria-label="${barLabel}"] a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});

test('Day 50 label is present in the free TemplateInfo', async ({ page }) => {
  test.skip(isPro, 'Pro bar shows a live-preview label, not the day counter');
  await page.goto('/');
  const info = page.locator(`[aria-label="${barLabel}"]`);
  await expect(info).toContainText('Day 50 of 365');
});
