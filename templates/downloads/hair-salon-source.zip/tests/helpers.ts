import type { Page } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';

// Single-page template; the Pro edition adds the printable /services/ price list.
export const ROUTES = isPro ? ['/', '/services/'] : ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// Hair salon has no dark mode — stub for compatibility
export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
}
