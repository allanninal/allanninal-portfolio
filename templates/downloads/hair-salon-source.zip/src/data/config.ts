export const salon = {
  name: 'Maison Lumière',
  tagline: 'Hair As Art',
  description: 'A chic atelier in the heart of the city where precision craft meets personal style.',
  address: '247 West 14th Street, New York, NY 10011',
  phone: '+1 (212) 555-0192',
  email: 'landix.ninal@gmail.com',
  instagram: 'https://www.instagram.com/',
  facebook: 'https://www.facebook.com/',
  bookingUrl: 'https://vagaro.com/',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  kofi: 'https://ko-fi.com/allanninal',
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '10:00 am – 7:00 pm' },
    { day: 'Wednesday', open: '10:00 am – 7:00 pm' },
    { day: 'Thursday',  open: '10:00 am – 8:00 pm' },
    { day: 'Friday',    open: '10:00 am – 8:00 pm' },
    { day: 'Saturday',  open: '9:00 am – 6:00 pm' },
    { day: 'Sunday',    open: '10:00 am – 5:00 pm' },
  ],
};

export const site = {
  title: 'Maison Lumière — Hair Salon, New York City',
  description:
    'Maison Lumière is a chic NYC hair atelier offering precision cuts, colour, balayage, and styling. Meet our expert stylists and book your appointment online.',
  language: 'en',
  ogImage: '/og-image.png',
  twitterHandle: '@allanninal',
};

export const services = [
  {
    id: 'cuts',
    category: 'Cuts & Styling',
    icon: '✂',
    items: [
      { name: "Women's Cut & Blowout",  from: '$85',  description: 'Tailored cut with a salon-finish blowout.' },
      { name: "Men's Cut",              from: '$55',  description: 'Classic and modern cuts, clean finish.' },
      { name: 'Bang Trim',              from: '$25',  description: 'Quick fringe refresh between appointments.' },
      { name: 'Blowout',                from: '$65',  description: 'Volume, smoothness, or textured — your choice.' },
      { name: 'Special Occasion Style', from: '$110', description: 'Updo, braid, or pinned look for your big day.' },
    ],
  },
  {
    id: 'color',
    category: 'Colour',
    icon: '◈',
    items: [
      { name: 'Single Process Colour', from: '$95',  description: 'Full-head root-to-tip colour refresh.' },
      { name: 'Partial Highlights',    from: '$145', description: 'Face-framing or crown placement.' },
      { name: 'Full Highlights',       from: '$195', description: 'Comprehensive lightening throughout.' },
      { name: 'Colour Correction',     from: '$250', description: 'Consultations required. Priced individually.' },
      { name: 'Toner / Gloss',         from: '$55',  description: 'Tone-on-tone refinement and shine boost.' },
    ],
  },
  {
    id: 'balayage',
    category: 'Balayage & Blonding',
    icon: '◇',
    items: [
      { name: 'Balayage',           from: '$220', description: 'Hand-painted, sun-kissed dimension.' },
      { name: 'Babylights',         from: '$260', description: 'Ultra-fine highlights for a natural look.' },
      { name: 'Full Blonde / Bleach & Tone', from: '$295', description: 'Luminous platinum or icy blonde finish.' },
      { name: 'Ombré',             from: '$195', description: 'Seamless dark-to-light gradient.' },
    ],
  },
  {
    id: 'treatments',
    category: 'Treatments',
    icon: '◯',
    items: [
      { name: 'Keratin Smoothing',    from: '$280', description: 'Up to 5 months of frizz-free smoothness.' },
      { name: 'Deep Conditioning',    from: '$45',  description: 'Olaplex or custom bond-repair mask.' },
      { name: 'Scalp Treatment',      from: '$60',  description: 'Detoxifying scalp scrub and massage.' },
      { name: 'Gloss Treatment',      from: '$50',  description: 'Clear or tinted in-salon shine treatment.' },
    ],
  },
];

export const stylists = [
  {
    id: 'isabelle-march',
    name: 'Isabelle March',
    title: 'Creative Director',
    specialty: 'Balayage · Editorial Colour',
    bio: "Trained at the Vidal Sassoon Academy in London, Isabelle has spent a decade perfecting balayage and lived-in colour. Her work has been featured in Harper's Bazaar and Vogue Living.",
    yearsExp: 12,
    instagram: 'https://www.instagram.com/',
    avatar: null,
  },
  {
    id: 'rafael-duarte',
    name: 'Rafael Duarte',
    title: 'Senior Stylist',
    specialty: 'Precision Cuts · Texture',
    bio: 'A São Paulo native who trained with Neysa Bove in New York, Rafael specialises in sharp structural cuts and textured styles that move beautifully. His clientele spans runway to real life.',
    yearsExp: 9,
    instagram: 'https://www.instagram.com/',
    avatar: null,
  },
  {
    id: 'camille-fontaine',
    name: 'Camille Fontaine',
    title: 'Colour Specialist',
    specialty: 'Blonding · Colour Correction',
    bio: 'Camille brings a Parisian sensibility to blonding — effortless, nuanced, and always wearable. She is a certified Olaplex educator and runs monthly colour masterclasses for the team.',
    yearsExp: 7,
    instagram: 'https://www.instagram.com/',
    avatar: null,
  },
  {
    id: 'soo-jin-park',
    name: 'Soo-Jin Park',
    title: 'Stylist',
    specialty: 'Korean Styling · Treatments',
    bio: 'Soo-Jin blends Korean hair care rituals with contemporary styling to achieve hair that is as healthy as it is beautiful. Her scalp treatments and keratin work have a devoted following.',
    yearsExp: 5,
    instagram: 'https://www.instagram.com/',
    avatar: null,
  },
];

export const testimonials = [
  {
    quote: 'Isabelle gave me the balayage I had been dreaming of for three years. The colour is so dimensional — people stop me on the street to ask who does my hair.',
    author: 'Claire M.',
    service: 'Balayage & Toner',
  },
  {
    quote: 'Rafael understood exactly what I wanted even when I struggled to describe it. The cut was architectural — I got four compliments before I even left the block.',
    author: 'Thomas B.',
    service: "Men's Cut",
  },
  {
    quote: 'Camille corrected two years of box-dye damage in a single visit. My hair went from brassy and broken to the most beautiful champagne blonde. I could not be happier.',
    author: 'Anya K.',
    service: 'Colour Correction',
  },
  {
    quote: 'The scalp treatment Soo-Jin recommended was a revelation. My hair feels thicker, grows faster, and the keratin she did is still perfect three months later.',
    author: 'Priya S.',
    service: 'Scalp Treatment + Keratin',
  },
  {
    quote: 'Maison Lumière feels like stepping into a boutique in Paris — calm, considered, and completely focused on you. I will never go anywhere else.',
    author: 'Nicole D.',
    service: 'Cut & Blowout',
  },
  {
    quote: 'They took the time to understand my hair\'s texture before touching it. The result was worth every minute of the consultation. Truly exceptional stylists.',
    author: 'Marcus T.',
    service: 'Texture Cut',
  },
];

// `src` + `proLabel` drive the Pro edition's real photography (free uses the
// CSS-gradient `palette`). proLabel overrides the caption where the photo shows
// a styling moment / the studio rather than the free edition's colour name.
export const galleryImages = [
  { id: 1, label: 'Champagne Balayage',    palette: ['#F5E6C8', '#D4B483', '#A07840'], src: 'champagne' },
  { id: 2, label: 'Copper Lived-In',       palette: ['#C4603A', '#8B3A20', '#F0C090'], src: 'copper' },
  { id: 3, label: 'Ash Blonde',            palette: ['#E8E0D0', '#C8BBA8', '#9A9080'], src: 'ash', proLabel: 'Lived-In Dimension' },
  { id: 4, label: 'Dimensional Brunette',  palette: ['#4A2C18', '#7A5030', '#C8906A'], src: 'brunette', proLabel: 'The Atelier' },
  { id: 5, label: 'Platinum Ice',          palette: ['#F0F0EE', '#D8D0C8', '#B0A898'], src: 'platinum' },
  { id: 6, label: 'Rich Espresso',         palette: ['#2C1810', '#5A3020', '#8A6050'], src: 'espresso', proLabel: 'Occasion Styling' },
  { id: 7, label: 'Rose Quartz Tint',      palette: ['#F5D0D0', '#D4909A', '#A85060'], src: 'rose' },
  { id: 8, label: 'Deep Burgundy',         palette: ['#6A1A28', '#9A3040', '#C87080'], src: 'burgundy', proLabel: 'The Colour Bar' },
];

export const stats = [
  { value: '12+',   label: 'Years in the Craft' },
  { value: '4',     label: 'Expert Stylists' },
  { value: '2,400+', label: 'Happy Clients' },
  { value: '98%',   label: 'Rebooking Rate' },
];
