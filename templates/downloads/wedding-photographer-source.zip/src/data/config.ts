// Halvard & Wren — Ithaca, NY.
//
// Opens Sprint 4. The brief was explicit: unconventional layouts, and arts /
// editorial references rather than the wedding-vendor mainstream. So the page
// opens on a contact sheet instead of a full-bleed slideshow, and the sheet is
// the argument rather than an illustration of it — you watch selection happen.

export const site = {
  name:        'Halvard & Wren',
  shortName:   'Halvard & Wren',
  title:       'Halvard & Wren — Wedding Photography in Ithaca, NY',
  tagline:     'Three thousand frames. Six hundred pictures.',
  city:        'Ithaca',
  state:       'NY',
  language:    'en',
  phoneDisplay: '(607) 555-0122',
  phoneHref:   '+16075550122',
  email:       'studio@halvardwren.example',
  streetAddress: '212 N Aurora St',
  postalCode:  '14850',
  hours:       'Studio Tue–Thu · weddings most weekends May through October',
  bookingWindow: 'Twelve weddings a year. 2027 dates opening.',
  description:
    'Two photographers in the Finger Lakes. A wedding makes about three thousand ' +
    'frames and you receive six hundred; the sheet below is one roll of twelve, ' +
    'with the three that were delivered ringed. That is what you are actually buying.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The sheet',  href: '#sheet' },
  { label: 'The hours',  href: '#hours' },
  { label: 'Coverage',   href: '#coverage' },
  { label: 'Rights',     href: '#rights' },
  { label: 'Investment', href: '#investment' },
  { label: 'Enquire',    href: '#enquire' },
];

// ── The roll ──────────────────────────────────────────────────────────────
// Twelve frames, because 120 roll film gives twelve 6x6 exposures. Ordered as
// the day was shot. `select: true` means it was delivered.
//
// Image credits are in CREDITS.md and assets/image-registry.json.

export const roll = {
  label:  'Roll 04 · Kodak Portra 400 · 120',
  couple: 'Nneka & Solomiya, Taughannock Falls',
  date:   '14 September 2025',
  frames: [
    { n: 1,  file: 'f01.jpg', time: '9.12am',  what: 'Trainers, dress hem',    alt: 'Trainers worn under the hem of a wedding dress on a chequerboard floor' },
    { n: 2,  file: 'f02.jpg', time: '9.48am',  what: 'Sparkler, dark room',    alt: 'A bride in profile in a darkened room, lit by a ring of sparkler light', select: true },
    { n: 3,  file: 'f03.jpg', time: '10.31am', what: 'Bouquet, held',          alt: 'A bouquet of deep red roses held against the front of the dress' },
    { n: 4,  file: 'f04.jpg', time: '10.44am', what: 'Rings, linen',           alt: 'Two wedding rings resting on linen beside a sprig of greenery' },
    { n: 5,  file: 'f05.jpg', time: '12.02pm', what: 'Aisle, seated',          alt: 'A cathedral interior with a red aisle carpet and guests already seated' },
    { n: 6,  file: 'f06.jpg', time: '12.19pm', what: 'Arrangement, row 1',     alt: 'A tall floral arrangement beside gold chairs at the head of the aisle' },
    { n: 7,  file: 'f07.jpg', time: '1.06pm',  what: 'Processional — phones',  alt: 'Hands holding a phone up to record, the bride blurred beyond it' },
    { n: 8,  file: 'f08.jpg', time: '1.22pm',  what: 'Mehndi, hands',          alt: 'Hands decorated with mehndi resting together, one in a red sleeve' },
    { n: 9,  file: 'f09.jpg', time: '1.40pm',  what: 'Wide, mist',             alt: 'A monochrome wide frame: the couple small beneath windswept trees in mist', select: true },
    { n: 10, file: 'f10.jpg', time: '2.55pm',  what: 'Party, from behind',     alt: 'The bridal party photographed from behind on grass, dressed in pink' },
    { n: 11, file: 'f11.jpg', time: '6.31pm',  what: 'Blossom, from behind',   alt: 'The bride from behind beneath a cherry tree in full blossom', select: true },
    { n: 12, file: 'f12.jpg', time: '7.58pm',  what: 'Flutes, close',          alt: 'The couple holding champagne flutes, photographed close' },
  ],
};

export const sheetNote =
  'Twelve frames because a roll of 120 gives twelve. One in four survived here; ' +
  'across a whole wedding it is closer to one in five, because a real day has more ' +
  'near-duplicates than a single roll does. The nine that are not ringed are not ' +
  'mistakes — they are the same moment a quarter-second earlier, an expression that ' +
  'had not arrived yet, a hand in the wrong place. Choosing between them is most of ' +
  'the work.';

// ── Where the forty hours go ──────────────────────────────────────────────
// Totalled in the page, never asserted here.

export const hours = [
  { stage: 'Timeline planning and venue walk', h: 4,  note: 'Before the day. Where the light is at 6pm, and where the family photographs happen if it rains.' },
  { stage: 'The wedding day',                  h: 10, note: 'Two of us, from preparation to first dance.', isDay: true },
  { stage: 'Ingest, backup, verify',           h: 1,  note: 'Three copies before anyone sleeps. One leaves the building.' },
  { stage: 'Culling, 3,000 to 600',            h: 6,  note: 'The invisible half. This is where a photographer earns or loses the gallery.' },
  { stage: 'Colour and finish, 600 frames',    h: 16, note: 'Every delivered frame individually. Batch presets are why galleries look inconsistent.' },
  { stage: 'Gallery build and album proofing', h: 3,  note: 'Delivery, sequencing, and the first album layout.' },
];

export const hoursNote =
  'The wedding day is the part everyone pictures, and it is a quarter of it. When ' +
  'a quote seems high for "one day of work", this is the answer — it is not one ' +
  'day of work.';

// ── Coverage ──────────────────────────────────────────────────────────────

export const coverage = {
  intro:
    'Two of us on every wedding, which is a coverage decision rather than an upsell. ' +
    'One camera cannot be at the aisle and at the back of the room at the same moment, ' +
    'and preparation usually happens in two places at once.',
  rows: [
    { q: 'Do we need a second photographer?', a: 'Over about a hundred guests, or with preparation split across two locations, yes. Under fifty in one venue, honestly no — and we will say so and reduce the quote.' },
    { q: 'How long should coverage run?',     a: 'Preparation to about an hour into dancing. Coverage past that produces frames of a dark room, which nobody has ever printed.' },
    { q: 'What about an unplugged ceremony?', a: 'Worth asking for, not worth demanding. Frame 7 on the sheet is the processional seen past a guest’s phone, held up right where the aisle was. We still made a picture; it is just not the one that existed before the phone went up.' },
    { q: 'Do you take a shot list?',          a: 'For family groups, always — names and combinations, agreed beforehand. For everything else, a list turns a photographer into an order-taker and the day into a queue.' },
  ],
};

// ── Rights, said plainly ──────────────────────────────────────────────────

export const rights = {
  intro:
    'Every wedding contract in this trade grants a licence, and almost none of them ' +
    'say the word. Here is what ours actually does, in the order that matters.',
  rows: [
    { term: 'Copyright',        plain: 'Stays with us. That is the default under US law and every photographer you speak to will have the same term, whether or not they mention it.' },
    { term: 'Your licence',     plain: 'Perpetual, worldwide, for personal use: print anything at any size, share anywhere, hand files to family. No expiry, no per-print fee.' },
    { term: 'Commercial use',   plain: 'Not included, because it almost never comes up at a wedding. If your venue or florist wants to advertise with your pictures, that is a separate conversation and usually a free one.' },
    { term: '“Full rights”',    plain: 'A phrase that usually means the licence above. If someone offers you copyright, ask them to put the word copyright in the contract and watch what happens.' },
    { term: 'Our use of yours', plain: 'We ask before anything goes public and a no costs you nothing. Some couples say no. That is the end of it.' },
  ],
};

// ── Investment ────────────────────────────────────────────────────────────

export const investment = {
  note:
    'One collection. Splitting coverage into tiers means selling someone a version ' +
    'of their wedding with a photographer who leaves early, and we would rather not.',
  price: '$6,400',
  includes: [
    'Two photographers, ten hours',
    'Planning call, timeline, and a venue walk',
    'About 600 finished frames, individually colour-graded',
    'Online gallery, downloadable at full size, live for five years',
    'Perpetual personal-use licence',
  ],
  extras: [
    { what: 'Additional hour',        cost: '$450' },
    { what: 'Second day (welcome / mehndi / brunch)', cost: '$2,200' },
    { what: 'Fine-art album, 12×12, 40 sides',        cost: '$1,150' },
    { what: 'Travel beyond 90 minutes of Ithaca',     cost: 'At cost, agreed first' },
  ],
  small:
    'Under fifty guests in a single venue, we shoot alone for $3,900 — and we will ' +
    'tell you if your wedding is that wedding.',
};

export const faqs = [
  {
    q: 'Why only six hundred pictures?',
    a: 'Because the other two thousand four hundred are worse versions of the six hundred. A gallery of three thousand frames is a photographer refusing to make decisions and passing the work to you.',
  },
  {
    q: 'Do we get the raw files?',
    a: 'No, and no photographer worth booking will say yes. A raw file is an unfinished negative; the colour is half the picture and it is the half you are hiring us for. You get full-resolution finished files with no watermark.',
  },
  {
    q: 'How long until we see them?',
    a: 'A set of about thirty within a week. The full gallery in six weeks, and in eight during September and October, which is when everyone in the Finger Lakes gets married.',
  },
  {
    q: 'What if it rains?',
    a: 'It rains. We walk the venue beforehand precisely so there is a plan that is not "the lobby". Some of the best frames we have made happened under a porch.',
  },
  {
    q: 'Do you shoot film?',
    a: 'We shoot digital and finish it like film. The sheet at the top is laid out as a roll of 120 because that is the honest way to show selection, not because we are claiming the frames came off film.',
  },
  {
    q: 'What happens if one of you is ill?',
    a: 'The other shoots and we bring in a photographer we have worked with, at our cost. If both of us are somehow out, you get every penny back the same day and we help you find someone. It has not happened in nine years.',
  },
];
