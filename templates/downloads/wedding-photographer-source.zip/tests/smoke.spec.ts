import { test, expect } from '@playwright/test';

test.describe('Halvard & Wren — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Halvard & Wren/);
    await expect(page.locator('h1')).toContainText('Six hundred');
  });

  // schema.org has no photographer business type. LocalBusiness plus a
  // Wikidata additionalType is the documented way to say what it cannot.
  test('handles the schema.org vocabulary gap honestly', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
    // A photographer travels, so a fixed service area would be a false claim.
    expect(json).not.toContain('areaServed');
  });

  // ── The contact sheet ───────────────────────────────────────────────────
  test('the sheet is one roll of twelve frames', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#sheet figure.sheet ol.sheet-frames > li.frame').count()).toBe(12);
  });

  test('every frame has a real image, alt text and a rebate number', async ({ page }) => {
    await page.goto('/');
    const frames = await page.locator('#sheet li.frame').evaluateAll((els) =>
      els.map((e) => ({
        src: e.querySelector('img')?.getAttribute('src') || '',
        alt: e.querySelector('img')?.getAttribute('alt') || '',
        w: e.querySelector('img')?.getAttribute('width'),
        h: e.querySelector('img')?.getAttribute('height'),
        n: e.querySelector('.rebate-n')?.textContent?.trim(),
      })),
    );
    expect(frames.length).toBe(12);
    frames.forEach((f, i) => {
      expect(f.src).toMatch(/images\/roll\/f\d\d\.jpg$/);
      // Alt text is the point of an image-led template — no empty or lazy alts.
      expect(f.alt.length).toBeGreaterThan(20);
      expect(f.alt).not.toMatch(/^(image|photo|picture)$/i);
      // Dimensions must be present or the sheet reflows as images arrive.
      expect(f.w).toBeTruthy();
      expect(f.h).toBeTruthy();
      expect(f.n).toBe(String(i + 1).padStart(2, '0'));
    });
  });

  test('all twelve frames load — no broken images', async ({ page }) => {
    await page.goto('/');
    // Force the lazy ones in.
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')),
    );
    expect(broken).toEqual([]);
  });

  // The conceit: selection is shown, not described.
  test('exactly three frames are ringed, and the ring is never the only signal', async ({ page }) => {
    await page.goto('/');
    const selects = page.locator('#sheet li.frame--select');
    expect(await selects.count()).toBe(3);
    // A colour ring alone would fail anyone who cannot see it.
    for (const t of await selects.locator('.rebate-mark').allTextContents()) {
      expect(t.trim()).toBe('SELECT');
    }
  });

  test('the delivered plates are exactly the ringed frames', async ({ page }) => {
    await page.goto('/');
    const ringed = await page.locator('#sheet li.frame--select img').evaluateAll((e) =>
      e.map((i) => i.getAttribute('src')),
    );
    const plates = await page.locator('#plates figure.plate img').evaluateAll((e) =>
      e.map((i) => i.getAttribute('src')),
    );
    expect(plates.length).toBe(3);
    expect(plates.sort()).toEqual(ringed.sort());
  });

  // ── The hours ───────────────────────────────────────────────────────────
  test('the hours headline is summed from the rows, not asserted', async ({ page }) => {
    await page.goto('/');
    const qty = await page.locator('#hours .qty').allTextContents();
    const total = qty.reduce((n, q) => n + Number(q.replace(/[^0-9]/g, '')), 0);
    const day = await page.locator('#hours li.is-day .qty').textContent();
    const share = Math.round((Number(day!.replace(/[^0-9]/g, '')) / total) * 100);
    await expect(page.locator('#hours h2')).toContainText(`${total} hours`);
    await expect(page.locator('#hours h2')).toContainText(`${share}%`);
  });

  test('the shooting day is a minority of the billed hours', async ({ page }) => {
    await page.goto('/');
    const qty = await page.locator('#hours .qty').allTextContents();
    const total = qty.reduce((n, q) => n + Number(q.replace(/[^0-9]/g, '')), 0);
    const day = Number((await page.locator('#hours li.is-day .qty').textContent())!.replace(/[^0-9]/g, ''));
    expect(day).toBeLessThan(total / 2);
  });

  // ── Rights ──────────────────────────────────────────────────────────────
  test('rights are stated with the word licence, and copyright is not overclaimed', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#rights');
    await expect(r).toContainText('licence');
    await expect(r).toContainText('Copyright');
    await expect(page.locator('#rights h2')).toContainText('not copyright');
    expect(await r.locator('tbody tr').count()).toBe(5);
  });

  test('the studio names when you do not need two photographers', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#coverage')).toContainText(/honestly no/i);
    await expect(page.locator('#investment')).toContainText(/shoot alone/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the enquiry form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#date', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 90.
  test('no trace of the day-90 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['cascade', 'tacoma', 'tunnel', 'tariff', 'break-even', 'unbounded']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro shot list is absent from the free build', async ({ page }) => {
    const res = await page.goto('/shot-list/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Family groups');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
