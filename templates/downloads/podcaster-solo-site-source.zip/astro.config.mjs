import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
// Day 117 — podcaster-solo-site. Day 72 once shipped with the previous template's
// slug still on this line and rendered with no CSS at all, because every asset
// resolved under the wrong base. If you fork this template, change it.
const BASE = process.env.PUBLIC_BASE_PATH || '/podcaster-solo-site/';

export default defineConfig({
  site: SITE,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [
    tailwind({ applyBaseStyles: false }),
  ],
});
