// Nell Braithwaite — Fargo, ND. Fictional, and the figures are plausible for a
// mid-size independent show rather than aspirational.
//
// Podcast numbers are the least standardised figures in media. "Downloads" can
// mean a 24-hour window or a lifetime total, it counts a device that fetched a
// file rather than a person who listened, and a partial fetch counts the same
// as a complete play. A media kit that states its window and its standard is
// doing something almost nobody does.

export const site = {
  name:        'Nell Braithwaite',
  shortName:   'Nell Braithwaite',
  title:       'The Long Way Round — a solo podcast from Fargo',
  tagline:     'A download is not a listen.',
  owner:       'Nell Braithwaite',
  ownerRole:   'Host, The Long Way Round',
  credential:  'Weekly since 2021 · 214 episodes',
  city:        'Fargo',
  state:       'ND',
  language:    'en',
  phoneDisplay: '(701) 555-0182',
  phoneHref:   '+17015550182',
  email:       'nell@thelongwayround.example',
  streetAddress: '119 Broadway N',
  postalCode:  '58102',
  hours:       'Episodes Thursdays · sponsor mail answered within two days',
  bookingWindow: 'Two host-read slots per episode · booked a month out',
  description:
    'A weekly solo show about small infrastructure and the people who maintain it. Every number ' +
    'on this page states the window it was measured over and the standard it was measured ' +
    'against, because a media kit that does not is asking you to guess.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The numbers', href: '#numbers' },
  { label: 'Episodes',    href: '#episodes' },
  { label: 'Rates',       href: '#rates' },
  { label: 'Sponsor',     href: '#sponsor' },
];

// ── The numbers ───────────────────────────────────────────────────────────
// `kind` is 'download' or 'measured'. The distinction is the argument.

export const numbers = [
  { k: 'Downloads, 7 days',     v: '18,400', kind: 'download', std: 'IAB v2.2 certified · per episode, median of last 12',
    n: 'The number every media kit leads with. It counts a device that fetched at least a minute of the file, once, deduplicated over 24 hours. It does not count a person.' },
  { k: 'Downloads, 30 days',    v: '24,900', kind: 'download', std: 'IAB v2.2 · same episodes',
    n: 'The same episodes given three more weeks. If a kit quotes only this figure, it is quoting a bigger number for the same show — which is fine, as long as it says so.' },
  { k: 'Unique devices, 30 days', v: '14,200', kind: 'download', std: 'Deduplicated by device, not by person',
    n: 'Closer to an audience size, still not one. A phone and a car head unit are two devices and frequently one listener.' },
  { k: 'Median completion',     v: '71%',    kind: 'measured', std: 'Of episodes started, across last 12',
    n: 'From platform analytics rather than downloads. Half of everybody who starts an episode is still there at 71% of its length.' },
  { k: 'Past the mid-roll',     v: '9,700',  kind: 'measured', std: 'Reached 00:14:00, median episode',
    n: 'The number a sponsor should actually price against, and the one nobody publishes. It is roughly half the seven-day download figure, which is the whole point of this page.' },
  { k: 'Past the post-roll',    v: '6,100',  kind: 'measured', std: 'Reached final 3 minutes',
    n: 'Published because a post-roll slot costs less for a reason, and pretending otherwise sells a sponsor something they did not get.' },
];

export const numbersNote =
  'The gap between the first row and the fifth is the whole argument. Both are honest numbers ' +
  'about the same show; one is what a file server saw and one is what a person did. Any media ' +
  'kit can quote the first. A kit that quotes the fifth is telling you what it is actually ' +
  'selling, and I would rather price against a smaller true number than a larger vague one.';

// ── Episodes ──────────────────────────────────────────────────────────────
// 30-day downloads and completion, so the spread is visible.

export const episodes = [
  { n: 214, title: 'The last switchboard in the county',      dl: 61200, comp: 78 },
  { n: 213, title: 'Who owns the water tower',                 dl: 26400, comp: 74 },
  { n: 212, title: 'Two hundred miles of unlit road',          dl: 23100, comp: 69 },
  { n: 211, title: 'The man who reads the river gauge',        dl: 31800, comp: 81 },
  { n: 210, title: 'Snow fences, and why they are angled',     dl: 22600, comp: 72 },
  { n: 209, title: 'A grain elevator with a fax machine',      dl: 25300, comp: 70 },
  { n: 208, title: 'The bridge inspection nobody attended',    dl: 19800, comp: 64 },
  { n: 207, title: 'Rural broadband, four years later',        dl: 28700, comp: 67 },
  { n: 206, title: 'One traffic light, three jurisdictions',   dl: 21500, comp: 73 },
  { n: 205, title: 'What a county road actually costs',        dl: 24100, comp: 71 },
];

export const episodesNote =
  'The top episode did about two and a half times the median and it is not the one I would have ' +
  'predicted. That spread is normal, it is invisible in an averaged media kit, and it is why a ' +
  'sponsor buying "an episode" is buying a distribution rather than an average. Sponsorships ' +
  'here are sold against the median and reported against the actual, which means some months you ' +
  'get more than you paid for.';

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  intro:
    'CPM here is calculated against the mid-roll figure, not the download figure. Against ' +
    'downloads the same slot would look like a much lower CPM and would be selling attention the ' +
    'show does not have.',
  rows: [
    { k: 'Pre-roll, 30 sec',   v: '$180',  cpm: '$18 CPM', n: 'Priced against 9,700. Heard by nearly everyone who starts, which is why it is not the cheapest slot despite being the shortest.' },
    { k: 'Mid-roll, 60 sec',   v: '$340',  cpm: '$35 CPM', n: 'The one worth buying. Host-read, in my own words, placed at a break in the episode rather than at a fixed timestamp.' },
    { k: 'Post-roll, 30 sec',  v: '$110',  cpm: '$18 CPM', n: 'Priced against 6,100, not 9,700. It costs less because fewer people hear it, and that is the only honest reason a slot should cost less.' },
    { k: 'Four-episode run',   v: '$1,150', cpm: '—',      n: 'Mid-rolls, about 15% off. Repetition is most of what makes host-read advertising work and one episode rarely does anything.' },
    { k: 'Make-good',          v: 'Automatic', cpm: '—',   n: 'If an episode lands more than 20% below the median at 30 days, the next one is free. Not negotiated — it is in the confirmation email.' },
    { k: 'Categories I decline', v: 'Listed', cpm: '—',    n: 'Gambling, crypto trading, and anything making a health claim. Stated up front so nobody wastes a pitch.' },
  ],
};

export const said = {
  text: 'She sent a rate card with the mid-roll listener number on it, which was half the download number in the same email. I have bought from a hundred shows and it was the first time I could compare two of them honestly.',
  who: 'Media buyer, regional advertiser — 2025',
};

export const faqs = [
  {
    q: 'Why publish the smaller number?',
    a: 'Because it is the one being sold. A sponsor buying a mid-roll is buying the people who were still listening at fourteen minutes, and that is 9,700 rather than 18,400. Quoting the larger figure is not lying exactly — it is answering a different question than the one being asked.',
  },
  {
    q: 'What does IAB v2.2 mean?',
    a: 'An industry standard for counting a download: at least a minute of the file requested, deduplicated per device per 24 hours, bots excluded. It is the difference between a comparable number and a number. If a show cannot tell you which standard it uses, it does not have one.',
  },
  {
    q: 'Downloads or listeners?',
    a: 'Downloads are what a file server saw. Listeners are what platform analytics infer, imperfectly, from playback. This page publishes both and labels which is which — the blue figures are measured playback, the yellow ones are downloads.',
  },
  {
    q: 'Why is the top episode so far above the rest?',
    a: 'One episode got picked up by a much larger show and did two and a half times the median. That is the normal shape of a back catalogue and it is exactly what an average hides. You are buying the median; some months you get more.',
  },
  {
    q: 'Do you take pre-recorded ads?',
    a: 'Only if the alternative is not working. Host-read outperforms programmatic on this show by a wide margin, and I would rather turn down a booking than run a spot that will not perform and then be blamed for the CPM.',
  },
  {
    q: 'What reporting do I get?',
    a: 'A one-page report fourteen and thirty days after the episode: downloads, completion, mid-roll reach, and the make-good calculation if it applies. Sent without being asked, because a sponsor chasing numbers is a sponsor who will not renew.',
  },
];
