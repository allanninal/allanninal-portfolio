import { test, expect } from '@playwright/test';

const num = (s: string) => Number(s.replace(/[^\d]/g, ''));

test.describe('The Long Way Round — smoke tests', () => {
  test('homepage renders with the show name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/The Long Way Round/);
    await expect(page.locator('h1')).toContainText('A download is not a listen');
  });

  // First type in this sprint that models the object rather than the person.
  test('is a PodcastSeries with episodes', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"PodcastSeries"');
    expect(json).toContain('"PodcastEpisode"');
    expect(json).not.toContain('hasOccupation');
  });

  // Schema.org cannot distinguish a download from a listen, and this page
  // exists to insist on that distinction.
  test('the markup publishes no audience figure at all', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('PodcastSeries')) || '');
    const schema = JSON.parse(raw);
    expect(schema.audience).toBeUndefined();
    expect(schema.interactionStatistic).toBeUndefined();
    expect(raw).not.toContain('18,400');
    expect(raw).not.toContain('18400');
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#numbers table.figs');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(300);
  });

  // ── The numbers ─────────────────────────────────────────────────────────
  test('every figure states the standard it was measured under', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#numbers tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(4);
    for (const r of await rows.all()) {
      expect(((await r.locator('.std').textContent()) || '').length).toBeGreaterThan(10);
      expect(((await r.locator('td').last().textContent()) || '').length).toBeGreaterThan(40);
    }
  });

  // The gap between the download figure and the measured one is the argument.
  test('the measured figure is smaller than the download figure, and the headline says both', async ({ page }) => {
    await page.goto('/');
    const dl = num((await page.locator('#numbers tbody tr').first().locator('.num').textContent()) || '0');
    const mid = num((await page.locator('#numbers .num--measured').last().textContent()) || '0');
    expect(mid).toBeLessThan(dl);
    const h2 = (await page.locator('#numbers h2').textContent()) || '';
    expect(num(h2.split('.')[0])).toBe(dl);
    await expect(page.locator('#numbers')).toContainText('% of the first');
  });

  test('download and measured figures do not share a colour', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--color-accent', '--measured'].map((k) => s.getPropertyValue(k).trim());
    });
    expect(new Set(c).size).toBe(2);
    await expect(page.locator('#numbers caption')).toContainText(/Yellow figures are downloads/i);
  });

  // ── Episodes ────────────────────────────────────────────────────────────
  test('completion uses real meter elements and prints the number too', async ({ page }) => {
    await page.goto('/');
    const meters = page.locator('#episodes meter');
    const n = await meters.count();
    expect(n).toBe(await page.locator('#episodes tbody tr').count());
    for (const m of await meters.all()) {
      const v = Number(await m.getAttribute('value'));
      expect(v).toBeGreaterThan(0);
      expect(v).toBeLessThanOrEqual(Number(await m.getAttribute('max')));
    }
    const printed = await page.locator('#episodes .comp span').allTextContents();
    expect(printed.length).toBe(n);
    for (const p of printed) expect(p).toMatch(/\d+% completed/);
  });

  test('the episode spread is computed, and the list is sorted by it', async ({ page }) => {
    await page.goto('/');
    const dls = (await page.locator('#episodes .dl').allTextContents()).map(num);
    expect(dls.length).toBeGreaterThan(5);
    for (let i = 1; i < dls.length; i++) expect(dls[i]).toBeLessThanOrEqual(dls[i - 1]);
    const sorted = [...dls].sort((a, b) => a - b);
    const median = sorted[Math.floor(dls.length / 2)];
    const spread = (dls[0] / median).toFixed(1);
    await expect(page.locator('#episodes h2')).toContainText(`${spread}× the median`);
  });

  test('the download bars are decorative and their numbers are printed', async ({ page }) => {
    await page.goto('/');
    for (const b of await page.locator('#episodes .bar').all()) {
      await expect(b).toHaveAttribute('aria-hidden', 'true');
    }
  });

  // ── Rates ───────────────────────────────────────────────────────────────
  test('CPM is priced against the measured figure, and the page says so', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#rates')).toContainText(/against the mid-roll figure, not the download figure/i);
    await expect(page.locator('#rates')).toContainText(/Make-good/);
    await expect(page.locator('#rates')).toContainText(/Categories I decline/);
  });

  // A page arguing that a media kit should not make you click to find out
  // what a number means should not make you click to find out either.
  test('every answer is open — no disclosure widget anywhere', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('details').count()).toBe(0);
    const items = page.locator('#faq .qa-item');
    expect(await items.count()).toBeGreaterThan(4);
    for (const i of await items.all()) {
      await expect(i.locator('h3')).toBeVisible();
      await expect(i.locator('p')).toBeVisible();
    }
  });

  // The drawing is generated from the same rows the table publishes, so it
  // cannot drift away from them.
  test('the drop-off figure restates the table and is hidden from the a11y tree', async ({ page }) => {
    await page.goto('/');
    const fig = page.locator('#numbers figure.drop');
    await expect(fig).toBeVisible();
    await expect(fig.locator('svg')).toHaveAttribute('aria-hidden', 'true');
    const widths = await fig.locator('rect').evaluateAll((rs) =>
      rs.map((r) => Number(r.getAttribute('width'))));
    expect(widths.length).toBe(3);
    for (let i = 1; i < widths.length; i++) expect(widths[i]).toBeLessThan(widths[i - 1]);
    const labels = await fig.locator('text').allTextContents();
    const table = (await page.locator('#numbers table.figs').textContent()) || '';
    for (const l of labels) expect(table).toContain(l.split(' · ')[0].trim());
    await expect(fig.locator('figcaption')).toContainText('second bar');
  });

  test('the sponsor form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-116 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['priya nandakumar', 'tucson', 'casting', 'raw read', 'noise floor']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro media kit is absent from the free build', async ({ page }) => {
    const res = await page.goto('/media-kit/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
