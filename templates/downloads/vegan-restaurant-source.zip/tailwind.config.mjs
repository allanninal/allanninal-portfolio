/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Lora"', 'Georgia', 'serif'],
        sans: ['"Lato"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        moss: {
          DEFAULT: '#2D4A22',
          50: '#F2F6F0',
          100: '#D9E8D4',
          200: '#B3D1A8',
          300: '#8FAF7E',
          400: '#5C8A4A',
          500: '#3D6030',
          600: '#2D4A22',
          700: '#1E3216',
          800: '#0F190B',
        },
        clay: {
          DEFAULT: '#C17F3A',
          50: '#FDF6EC',
          100: '#F5E0BF',
          200: '#E8C38A',
          300: '#D9A55C',
          400: '#C17F3A',
          500: '#A36628',
          600: '#7A4D1E',
        },
        cream: {
          DEFAULT: '#FAF7F0',
          dark: '#F0EAD8',
        },
      },
    },
  },
  plugins: [],
};
