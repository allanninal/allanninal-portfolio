# Vegan Restaurant — Day 35 of 365

A modern, earthy Astro template for a plant-based restaurant. Built around a seasonal concept ("Verdant Table"), this template features a botanical identity distinct from every prior food template in the series.

**Live demo:** https://templates.allanninal.dev/vegan-restaurant/

---

## Visual identity

- **Palette:** Deep moss `#2D4A22` (hero, footer, accents) · Warm cream `#FAF7F0` (background) · Clay `#C17F3A` / `#8C5B1A` (accent, CTA highlights) · Sage `#8FAF7E` (muted text on dark) — all WCAG AA compliant
- **Fonts:** Lora (display serif, botanical elegance) + Lato (body, clean readable sans)
- **Differentiator from prior food templates:**
  - restaurant-general (day 22): dark olive/gold, Libre Baskerville + Mulish
  - coffee-shop (day 23): parchment/terracotta-rust, Fraunces + Plus Jakarta Sans
  - pizzeria (day 32): cream/tomato-red/basil, Playfair Display + Nunito
  - sushi-bar (day 33): washi white/indigo, Cormorant Garamond + Noto Sans JP
  - mexican-restaurant (day 34): vibrant teal/terracotta/marigold, Abril Fatface + Nunito
  - This template: earthy moss/cream/clay, Lora + Lato — botanical, grounded, distinct

---

## Sections

1. **Hero** — Deep moss hero with botanical leaf SVG illustration, key facts strip (farm partners, landfill output, sourcing radius), two CTAs
2. **Menu** — Four-tab menu (Small Plates / Mains / Desserts / Natural Wine) with prices, allergen tags (GF/NF/SF/R), chef's pick labels, and allergen legend
3. **Philosophy** — Four sustainability pillars (Seasonal & Local, Zero-Waste Kitchen, Community-Supported, Transparent Sourcing), farm partner grid, 2024 impact stats band
4. **Our Story** — Long-form narrative with chef founder bio card, credentials, pull quote
5. **Gallery** — Six-item SVG botanical grid with caption overlays, Instagram CTA
6. **Reservations & Hours** — Online/phone booking CTAs, weekly hours table, address & directions

---

## Structured data

- `schema.org/Restaurant` with address, opening hours, cuisine types, menu link, acceptsReservations
- `schema.org/Menu` with four category descriptions
- `schema.org/Person` (template author)

---

## Quick start

```bash
npm install
npm run dev
```

### Environment variables

```bash
cp .env.example .env
```

| Variable | Description |
|---|---|
| `PUBLIC_BASE_PATH` | Base path for deployment (e.g. `/vegan-restaurant/` for subfolder hosting) |
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — enables TemplateInfo bar + analytics (leave blank for personal use) |
| `PUBLIC_SITE_URL` | Canonical site URL for SEO |
| `PUBLIC_AUTHOR_DONATE_URL` | Ko-fi or other donation URL (shown in footer) |

### Customization

All content lives in `src/data/config.ts`:
- `restaurant` — name, tagline, address, phone, email, social links
- `hours` — weekly hours table
- `menu` — all four menu categories with items, prices, allergen tags
- `philosophy` — four pillars text, farm partner list
- `story` — narrative paragraphs

---

## Tests

```bash
npm test              # Playwright smoke + a11y + links
npm run test:a11y     # axe-core WCAG 2.1 AA
npm run test:links    # broken links + noopener checks
npm run test:lighthouse  # Lighthouse CI (≥ 95 on all four scores)
```

---

## License

MIT — free for commercial and personal use. Attribution appreciated but not required.

Built by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · Part of the [365 Templates project](https://templates.allanninal.dev/).
