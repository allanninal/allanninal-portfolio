export const restaurant = {
  name: 'Verdant Table',
  tagline: 'Plant-based. Seasonally driven. Rooted in purpose.',
  shortTagline: 'Plant-based dining with a conscience.',
  description:
    'A modern plant-based restaurant celebrating seasonal produce, zero-waste cooking, and community-supported sourcing. Every dish tells a story of the land it came from.',
  address: '48 Grove Street, Portland, OR 97201',
  phone: '+1 (503) 555-0148',
  email: 'hello@verdanttable.com',
  reservationUrl: '#reservations',
  orderUrl: '#order',
  instagram: 'https://instagram.com/verdanttable',
  facebook: 'https://facebook.com/verdanttable',
  openDate: 'Spring 2019',
};

export const hours = [
  { day: 'Monday', lunch: 'Closed',         dinner: 'Closed'         },
  { day: 'Tuesday', lunch: '11:30 – 14:30', dinner: '17:30 – 21:00' },
  { day: 'Wednesday', lunch: '11:30 – 14:30', dinner: '17:30 – 21:00' },
  { day: 'Thursday', lunch: '11:30 – 14:30', dinner: '17:30 – 21:30' },
  { day: 'Friday',   lunch: '11:30 – 15:00', dinner: '17:30 – 22:00' },
  { day: 'Saturday', lunch: '10:00 – 15:30', dinner: '17:30 – 22:00' },
  { day: 'Sunday',   lunch: '10:00 – 15:00', dinner: '17:30 – 21:00' },
];

export type AllergenTag = 'GF' | 'NF' | 'SF' | 'R';

export type MenuItem = {
  name: string;
  description: string;
  price: string;
  tags: AllergenTag[];
  featured?: boolean;
};

export type MenuCategory = {
  id: string;
  label: string;
  intro?: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: 'small-plates',
    label: 'Small Plates',
    intro: 'Share freely. Designed for the table.',
    items: [
      {
        name: 'Roasted Beet Carpaccio',
        description: 'Golden & red beets, whipped cashew ricotta, pickled mustard seeds, microgreens, smoked paprika oil.',
        price: '$14',
        tags: ['GF', 'NF'],
        featured: true,
      },
      {
        name: 'Tempeh Lettuce Cups',
        description: 'Tamari-glazed tempeh, mango salsa, toasted coconut, lime crema, butter lettuce, fresh chilli.',
        price: '$13',
        tags: ['GF', 'SF'],
      },
      {
        name: 'Charred Corn Elote Skewers',
        description: 'Fire-roasted sweet corn, chipotle aioli, crumbled almond feta, cilantro, smoked lime.',
        price: '$12',
        tags: ['GF', 'NF'],
      },
      {
        name: 'Wild Mushroom Crostini',
        description: 'Sourdough, truffle-roasted cremini & shiitake, caramelised onion jam, thyme, shaved fennel.',
        price: '$13',
        tags: [],
      },
      {
        name: 'Watermelon & Tomato Salad',
        description: 'Heirloom tomatoes, seedless watermelon, cucumber, fresh basil, balsamic pearls, fleur de sel.',
        price: '$12',
        tags: ['GF', 'NF', 'R'],
      },
    ],
  },
  {
    id: 'mains',
    label: 'Mains',
    intro: 'Seasonal, ingredient-led plates built around the harvest.',
    items: [
      {
        name: 'Black Lentil Dal',
        description: 'Slow-cooked beluga lentils, roasted tomato, coconut cream, toasted cumin, served with saffron basmati and charred flatbread.',
        price: '$24',
        tags: ['GF', 'NF', 'SF'],
        featured: true,
      },
      {
        name: 'Celeriac Schnitzel',
        description: 'Herb-crusted celeriac steak, lemon-caper butter, pea & mint smash, pickled red cabbage, dill oil.',
        price: '$26',
        tags: ['NF'],
      },
      {
        name: 'Roasted Cauliflower Steak',
        description: 'Whole-roasted cauliflower, chermoula, beluga lentil base, harissa-roasted chickpeas, pomegranate molasses.',
        price: '$25',
        tags: ['GF', 'NF', 'SF'],
      },
      {
        name: 'Verdant Garden Risotto',
        description: 'Arborio rice, asparagus, English peas, sorrel pesto, spring onion, nutritional yeast, lemon zest.',
        price: '$23',
        tags: ['GF', 'NF', 'SF'],
      },
      {
        name: 'Smoked Jackfruit Tacos',
        description: 'Three corn tacos, chipotle-braised jackfruit, avocado crema, pickled jalapeño, cabbage slaw, street salsa.',
        price: '$22',
        tags: ['GF', 'NF', 'SF'],
      },
      {
        name: 'Miso-Glazed Aubergine',
        description: 'Whole aubergine, white miso glaze, sesame, pickled cucumber, black rice, shiso, crispy shallots.',
        price: '$24',
        tags: ['GF', 'NF', 'SF'],
      },
    ],
  },
  {
    id: 'desserts',
    label: 'Desserts',
    intro: 'Sweet endings. All dairy-free, most nut-free on request.',
    items: [
      {
        name: 'Dark Chocolate Tart',
        description: 'Hazelnut crust, 70% cacao ganache, fleur de sel, raspberry coulis, candied orange.',
        price: '$12',
        tags: ['GF'],
        featured: true,
      },
      {
        name: 'Coconut Panna Cotta',
        description: 'Coconut cream set with agar, passion fruit curd, toasted coconut flakes, lime zest.',
        price: '$11',
        tags: ['GF', 'NF', 'SF'],
      },
      {
        name: 'Seasonal Fruit Crumble',
        description: 'Rotating seasonal stone fruit or berry filling, oat & almond crumble, vanilla oat cream.',
        price: '$13',
        tags: ['GF'],
      },
      {
        name: 'Affogato (Oat)',
        description: 'Oat-milk vanilla gelato, double espresso shot, dark chocolate shavings.',
        price: '$9',
        tags: ['GF', 'NF', 'SF'],
      },
    ],
  },
  {
    id: 'natural-wine',
    label: 'Natural Wine & Drinks',
    intro: 'Low-intervention, biodynamic, and organic pours. Ask our team for the seasonal selection.',
    items: [
      {
        name: 'Pét-Nat Blanc',
        description: 'Méthode ancestrale sparkling. Chenin Blanc. Loire Valley, France. Lively, floral, bone-dry.',
        price: '$14 / glass · $58 / bottle',
        tags: ['NF', 'SF'],
      },
      {
        name: 'Orange Wine',
        description: 'Skin-contact Pinot Grigio. Friuli, Italy. Amber hue, dried apricot, tannic finish.',
        price: '$15 / glass · $62 / bottle',
        tags: ['NF', 'SF'],
      },
      {
        name: 'Biodynamic Red',
        description: 'Grenache blend. Rhône, France. Spice, red berry, earthy minerality. Light-to-medium body.',
        price: '$16 / glass · $66 / bottle',
        tags: ['NF', 'SF'],
      },
      {
        name: 'Kombucha Flight',
        description: 'Three 60 ml pours of our in-house rotating seasonal kombucha — current flavours change weekly.',
        price: '$10',
        tags: ['GF', 'NF', 'SF'],
      },
      {
        name: 'Botanical Spritz',
        description: 'Elderflower, cucumber, fresh mint, lime, sparkling water, zero alcohol.',
        price: '$8',
        tags: ['GF', 'NF', 'SF', 'R'],
      },
    ],
  },
];

export const allergenLegend: { tag: AllergenTag; label: string; description: string }[] = [
  { tag: 'GF', label: 'Gluten-Free', description: 'Contains no wheat, barley, rye or oats. Cross-contamination possible in our kitchen — inform your server if you have coeliac disease.' },
  { tag: 'NF', label: 'Nut-Free',   description: 'Contains no tree nuts or peanuts in its ingredients.' },
  { tag: 'SF', label: 'Soy-Free',   description: 'Made without soy or soy-derived ingredients.' },
  { tag: 'R',  label: 'Raw',        description: 'Primarily uncooked or minimally heated to preserve nutrients.' },
];

export const philosophy = {
  headline: 'Food that respects the whole chain.',
  intro: 'We opened Verdant Table with a simple belief: great plant-based food doesn\'t require compromise — it requires creativity, honesty, and a deep respect for where ingredients come from.',
  pillars: [
    {
      icon: '&#127807;',
      title: 'Seasonal & Local',
      body: 'Our menu changes with the harvest. We source from 11 farms within 120 miles of Portland, visiting each one personally every season to choose what goes on the plate.',
    },
    {
      icon: '&#9832;',
      title: 'Zero-Waste Kitchen',
      body: 'Vegetable trimmings become stocks, citrus peels become garnishes, spent grains go back to the farms as compost. Our kitchen sends less than 2 kg to landfill per week.',
    },
    {
      icon: '&#127858;',
      title: 'Community-Supported',
      body: 'We operate a CSA share with four local farms, guaranteeing them a fair price before the season starts — giving us first pick of the harvest and them the financial security to grow sustainably.',
    },
    {
      icon: '&#127807;',
      title: 'Transparent Sourcing',
      body: 'Every ingredient on the menu includes a producer note on our printed card. We believe you deserve to know who grew your food and how far it travelled to reach your plate.',
    },
  ],
  farmPartners: [
    { name: 'Sunroot Farm', location: 'Yamhill County, OR', specialty: 'Root vegetables & brassicas' },
    { name: 'Meadowlark Organics', location: 'Chehalem Valley, OR', specialty: 'Heritage grain & legumes' },
    { name: 'Blue Heron Flowers', location: 'Tualatin Valley, OR', specialty: 'Edible flowers & micro-herbs' },
    { name: 'River Bend Produce', location: 'Willamette Valley, OR', specialty: 'Seasonal stone fruit & berries' },
  ],
};

export const story = {
  headline: 'From one small garden to sixty covers',
  body: [
    'Chef Maya Okafor grew up in a household where the garden was the pantry. Her grandmother kept a half-acre plot in Lagos, and every meal began not with a recipe but with a walk outside. Maya carried that instinct through culinary school in Paris and a decade cooking in New York, until she arrived in Portland in 2017 and found a farming community that reminded her of home.',
    'Verdant Table opened on a wet Tuesday in March 2019, with a 40-seat dining room, a daily-changing blackboard menu, and a very short list of farm partners. Five years on, we\'ve grown to 60 covers, added a natural wine list, and deepened relationships with eleven regional farms — but the blackboard is still how every week starts.',
    'We believe that plant-based cooking at its best is not about what you remove, but about what you reveal: the sweetness of a carrot slow-roasted for two hours, the umami depth of a properly aged miso, the brightness that only perfectly ripe fruit can provide. Come hungry. Leave changed.',
  ],
};

export const galleryItems = [
  { id: 'beet',           alt: 'Roasted beet carpaccio with cashew ricotta on a dark ceramic plate',   label: 'Beet Carpaccio' },
  { id: 'aubergine',      alt: 'Miso-glazed whole aubergine with sesame and shiso on a stone platter', label: 'Miso Aubergine' },
  { id: 'chocolate-tart', alt: 'Dark chocolate tart with fleur de sel and raspberry coulis',            label: 'Chocolate Tart' },
  { id: 'harvest',        alt: 'Farm-fresh seasonal vegetables arranged in a wicker basket',            label: 'The Harvest' },
  { id: 'dining',         alt: 'Interior of Verdant Table dining room — warm lighting, reclaimed wood', label: 'Our Dining Room' },
  { id: 'kitchen',        alt: 'Chef plating a dish in the open kitchen',                               label: 'In the Kitchen' },
];

export const maker = {
  name: 'Verdant Table',
  linkedin: '#',
  twitter: '#',
  github: '#',
  email: 'hello@verdanttable.com',
  kofi: '#',
};

export const site = {
  title: 'Verdant Table — Plant-Based Restaurant, Portland OR',
  description:
    'Verdant Table is a modern plant-based restaurant in Portland, Oregon. Seasonal tasting menus, natural wine, zero-waste kitchen, and community-supported farm sourcing.',
  url: 'https://example.com/',
  ogImage: '/og-image.png',
  language: 'en',
};
