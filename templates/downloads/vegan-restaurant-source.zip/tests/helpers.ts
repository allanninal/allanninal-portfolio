import type { Page } from '@playwright/test';

// Single-page template — only one route
export const ROUTES = ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// Vegan-restaurant is light-only; no theme toggle.
// This helper is a no-op but kept for API compatibility with the harness.
export async function setTheme(page: Page, _theme: 'light' | 'dark') {
  // Light-only template — nothing to switch
  await page.waitForLoadState('domcontentloaded');
}
