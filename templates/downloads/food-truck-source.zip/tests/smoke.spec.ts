import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Rolled Smoke/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('schedule section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#schedule')).toBeVisible();
});

test('schedule has 7 day cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.schedule-card');
  const count = await cards.count();
  expect(count).toBe(7);
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu has at least 3 tab buttons', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('.menu-tab-btn');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  // Click "Sides & Extras" tab
  await page.locator('.menu-tab-btn[data-tab="sides"]').click();
  await expect(page.locator('.menu-panel[data-panel="sides"]')).not.toHaveClass(/hidden/);
  await expect(page.locator('.menu-panel[data-panel="tacos"]')).toHaveClass(/hidden/);
});

test('find-us section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#find-us')).toBeVisible();
});

test('catering section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#catering')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('navigation links exist in header', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('truck has phone number in footer', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer');
  await expect(footer).toBeVisible();
  const phoneLink = footer.locator('a[href^="tel:"]');
  await expect(phoneLink).toBeVisible();
});

test('header has Book the Truck CTA', async ({ page }) => {
  await page.goto('/');
  const header = page.locator('header');
  const cta = header.locator('a[href="#catering"]').first();
  await expect(cta).toBeVisible();
});

test('catering has 3 packages', async ({ page }) => {
  await page.goto('/');
  const packages = page.locator('#catering article');
  const count = await packages.count();
  expect(count).toBeGreaterThanOrEqual(3);
});
