import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo bar renders with hub URL set', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR)).toBeVisible();
});

test('TemplateInfo has a static-zip download button', async ({ page }) => {
  await page.goto('/');
  const btn = page.locator(`${BAR} a[download]`).first();
  await expect(btn).toBeVisible();
  expect(await btn.getAttribute('href')).toContain('food-truck-static.zip');
});

test('TemplateInfo source / Get-Pro affordance', async ({ page }) => {
  await page.goto('/');
  if (isPro) {
    const getPro = page.locator(BAR).locator('a', { hasText: /Get Pro static/ });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    return;
  }
  const btn = page.locator(`${BAR} a[download]`).nth(1);
  await expect(btn).toBeVisible();
  expect(await btn.getAttribute('href')).toContain('food-truck-source.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  const link = page.locator(`${BAR} a:not([download])`).filter({ hasText: 'All 365' });
  await expect(link).toBeVisible();
});

test('TemplateInfo links to LinkedIn (Build with me / Get Pro static)', async ({ page }) => {
  await page.goto('/');
  const link = page.locator(`${BAR} a[href*="linkedin.com"]`);
  await expect(link).toBeVisible();
  const text = await link.textContent();
  expect(text?.trim()).toContain(isPro ? 'Get Pro static' : 'Build with me');
});

test('no github.com/allanninal/templates links on page', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
