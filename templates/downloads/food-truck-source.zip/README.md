# Rolled Smoke — Food Truck Template (Day 47 of 365)

A high-energy Astro + Tailwind template for street food trucks.
Bold charcoal + flame-red + mustard palette. Barlow Condensed display + Inter body.

**Live demo:** https://templates.allanninal.dev/food-truck/

## Key Sections

- **Energetic hero** — full-bleed dark, quick schedule preview
- **This Week's Schedule** — 7-day card grid with day / neighborhood / time / address / notes
- **Menu** — tabbed (Tacos / Sides / Drinks), prices, dietary tags (GF, Vegan, Dairy-Free, Spicy, Bestseller, New)
- **Where to Find Us** — contact details + embedded map placeholder
- **Book the Truck / Catering** — 3-tier packages (Smoke Starter / Full Roll / Pit Boss)
- **Our Story** — founder bio + stats band (year, smoke hours, tacos/day)
- **Gallery** — 6-slot responsive grid with street-level alt text
- **Social callout** — mustard band linking Instagram + TikTok
- **schema.org** — FoodEstablishment + Menu JSON-LD

## Quick Start

```bash
npm install
npm run dev
```

## Environment Variables

Copy `.env.example` to `.env` and fill in:

| Variable | Purpose |
|---|---|
| `PUBLIC_SITE_URL` | Canonical site root |
| `PUBLIC_BASE_PATH` | Base URL path (e.g. `/food-truck/`) |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables TemplateInfo download bar + Analytics |
| `PUBLIC_AUTHOR_DONATE_URL` | Ko-fi link shown in footer |

## Customise

- Edit `src/data/config.ts` — change truck name, schedule, menu, catering packages
- Replace the SVG map placeholder in `FindUs.astro` with a real Google Maps / Mapbox iframe
- Add real food photography in `Gallery.astro`
- Adjust palette in `src/styles/global.css` (CSS custom properties)

## License

MIT — free to use, fork, and deploy.
