/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Barlow Condensed"', '"Barlow Condensed Fallback"', '"Arial Narrow"', 'system-ui', 'sans-serif'],
        sans: ['"Inter Variable"', 'Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        flame: {
          DEFAULT: '#E63329',
          light:   '#FDE8E7',
          dark:    '#B52220',
          text:    '#8C1815',
        },
        mustard: {
          DEFAULT: '#F0A500',
          light:   '#FEF3CC',
          dark:    '#B87D00',
          text:    '#7A5200',
        },
        charcoal: {
          DEFAULT: '#1C1C1C',
          muted:   '#3A3A3A',
          faint:   '#6B6B6B',
        },
        cream: {
          DEFAULT: '#FAF7F2',
          100:    '#F5F0E8',
          200:    '#EDE4D4',
        },
      },
    },
  },
  plugins: [],
};
