// ============================================================
// Rolled Smoke — Food Truck — Day 47
// Street-smoked BBQ & tacos — Austin, TX
// ============================================================

export const truck = {
  name: 'Rolled Smoke',
  tagline: 'Find us. Eat well.',
  subtitle: 'Wood-smoked BBQ tacos & street sides — rolling Austin since 2019.',
  description:
    'Rolled Smoke is a wood-fired BBQ taco truck rolling the streets of Austin, TX. Every taco is built on a fresh flour tortilla with slow-smoked meats, house-made salsas, and zero shortcuts.',
  address: 'Austin, TX',
  phone: '(512) 555-0147',
  email: 'hello@rolledsmoke.com',
  url: 'https://www.allanninal.dev/templates/food-truck/',
  instagram: 'https://instagram.com/allanninal',
  twitter: 'https://twitter.com/allanninal',
  tiktok: 'https://tiktok.com/@allanninal',
  cateringEmail: 'catering@rolledsmoke.com',
  priceRange: '$',
  cuisine: ['BBQ', 'Tacos', 'Street Food', 'Tex-Mex'],
  coords: { lat: 30.2672, lng: -97.7431 },
};

export const founder = {
  name: 'Marcus Webb',
  role: 'Pitmaster & Founder',
  bio: 'Marcus spent a decade in competition BBQ before hitching a smoker to a truck and hitting the streets. Every cut is sourced from Texas ranches and smoked low-and-slow overnight. No shortcuts, ever.',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  email: 'hello@rolledsmoke.com',
};

export const site = {
  title: 'Rolled Smoke — BBQ Taco Truck · Austin, TX',
  description:
    'Wood-smoked BBQ taco truck rolling Austin, TX. Check this week\'s schedule, find us on the map, browse our menu of slow-smoked tacos, sides, and house-made salsas.',
  ogImage: '/og-image.png',
  language: 'en',
};

// ============================================================
// This Week's Schedule
// ============================================================
export type ScheduleStop = {
  day: string;
  location: string;
  neighborhood: string;
  address: string;
  time: string;
  note?: string;
};

export const schedule: ScheduleStop[] = [
  {
    day: 'Monday',
    location: 'South Congress Ave',
    neighborhood: 'SoCo',
    address: '1600 S Congress Ave, Austin, TX 78704',
    time: '11:30 AM – 3:00 PM',
    note: 'Street parking on SoCo strip',
  },
  {
    day: 'Tuesday',
    location: 'Rainey Street',
    neighborhood: 'Rainey St',
    address: '85 Rainey St, Austin, TX 78701',
    time: '5:00 PM – 9:00 PM',
    note: 'Bar District — evening service',
  },
  {
    day: 'Wednesday',
    location: 'Domain Northside',
    neighborhood: 'The Domain',
    address: '11600 Century Oaks Terrace, Austin, TX 78758',
    time: '11:30 AM – 2:30 PM',
  },
  {
    day: 'Thursday',
    location: 'East 6th Street',
    neighborhood: 'East Austin',
    address: '1601 E 6th St, Austin, TX 78702',
    time: '5:00 PM – 9:00 PM',
    note: 'Late-night menu from 8 PM',
  },
  {
    day: 'Friday',
    location: 'Barton Springs Pool',
    neighborhood: 'Zilker Park',
    address: '2101 Barton Springs Rd, Austin, TX 78746',
    time: '11:00 AM – 4:00 PM',
    note: 'Park lot — cash & card',
  },
  {
    day: 'Saturday',
    location: 'SXSW Lot / 2nd & Guadalupe',
    neighborhood: 'Downtown',
    address: '200 W 2nd St, Austin, TX 78701',
    time: '10:00 AM – 5:00 PM',
    note: 'Weekend flagship stop — full menu',
  },
  {
    day: 'Sunday',
    location: 'Mueller Farmers Market',
    neighborhood: 'Mueller',
    address: '4550 Mueller Blvd, Austin, TX 78723',
    time: '10:00 AM – 2:00 PM',
    note: 'Market day — limited quantities',
  },
];

// ============================================================
// Menu
// ============================================================
export type MenuTag = 'SPICY' | 'GF' | 'VG' | 'DF' | 'BESTSELLER' | 'NEW';

export type MenuItem = {
  name: string;
  description: string;
  price: number;
  tags: MenuTag[];
};

export type MenuSection = {
  id: string;
  label: string;
  icon: string;
  items: MenuItem[];
};

export const menu: MenuSection[] = [
  {
    id: 'tacos',
    label: 'Tacos',
    icon: '🌮',
    items: [
      {
        name: 'Brisket Taco',
        description:
          '14-hour oak-smoked brisket, pickled red onion, cilantro, house chipotle crema, fresh flour tortilla',
        price: 5,
        tags: ['BESTSELLER', 'DF'],
      },
      {
        name: 'Pulled Pork Taco',
        description:
          'Apple-wood smoked pulled pork, green cabbage slaw, jalapeño-lime sauce, toasted sesame',
        price: 4.5,
        tags: ['DF'],
      },
      {
        name: 'Smoked Chicken Taco',
        description:
          'Achiote-rubbed smoked chicken thigh, mango-habanero salsa, cotija, micro cilantro',
        price: 4.5,
        tags: ['GF', 'SPICY'],
      },
      {
        name: 'Smoked Jackfruit Taco',
        description:
          'Slow-smoked pulled jackfruit, black bean mash, avocado crema, pickled jalapeño',
        price: 4,
        tags: ['VG', 'GF', 'DF'],
      },
      {
        name: 'Al Pastor Taco',
        description:
          'Pineapple-marinated pork shoulder, tomatillo salsa verde, white onion, fresh cilantro',
        price: 4.5,
        tags: ['DF', 'BESTSELLER'],
      },
      {
        name: 'Triple Threat (3-Taco Combo)',
        description: 'Choose any 3 tacos — brisket, pulled pork, or smoked chicken',
        price: 13,
        tags: ['NEW'],
      },
    ],
  },
  {
    id: 'sides',
    label: 'Sides & Extras',
    icon: '🍟',
    items: [
      {
        name: 'Smoked Street Corn',
        description: 'Elotes-style: char-grilled corn, mayo crema, cotija, chili powder, lime',
        price: 4,
        tags: ['VG', 'GF'],
      },
      {
        name: 'Pit Beans',
        description: 'Slow-cooked pinto beans simmered with smoked brisket ends and chipotles',
        price: 3.5,
        tags: ['GF', 'DF'],
      },
      {
        name: 'Loaded Fries',
        description:
          'Crispy fries, brisket drippings gravy, pickled jalapeños, shredded cheddar, sour cream',
        price: 7,
        tags: ['BESTSELLER'],
      },
      {
        name: 'Smoked Sausage Link',
        description: 'House-made beef & jalapeño smoked sausage link, served with crackers + mustard',
        price: 5,
        tags: ['GF', 'DF'],
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Drinks',
    icon: '🥤',
    items: [
      {
        name: 'Agua Fresca',
        description: 'Daily rotating fresh fruit agua fresca — ask the crew for today\'s flavor',
        price: 3,
        tags: ['VG', 'GF', 'DF'],
      },
      {
        name: 'Mexican Coke',
        description: 'Glass-bottle Coca-Cola, cane sugar, ice-cold',
        price: 3,
        tags: ['VG', 'GF', 'DF'],
      },
      {
        name: 'Horchata',
        description: 'House-made rice milk, cinnamon, vanilla — a creamy crowd favourite',
        price: 4,
        tags: ['VG', 'GF', 'DF', 'BESTSELLER'],
      },
    ],
  },
];

// ============================================================
// Gallery placeholder images (SVG color blocks with descriptive alt)
// ============================================================
export const galleryImages = [
  { alt: 'Brisket tacos on flour tortillas with chipotle crema and pickled onion', bg: '#1C1C1C', accent: '#E63329', src: 'tacos' },
  { alt: 'The Rolled Smoke truck parked on South Congress at golden hour', bg: '#F0A500', accent: '#1C1C1C', src: 'truck' },
  { alt: 'Lifting the smoker lid on a full rack of ribs', bg: '#3A3A3A', accent: '#F0A500', src: 'ribs' },
  { alt: 'Loaded fries topped with brisket gravy and jalapeños', bg: '#E63329', accent: '#FAF7F2', src: 'fries' },
  { alt: 'Smoked street corn elotes at the service window', bg: '#FAF7F2', accent: '#1C1C1C', src: 'elotes' },
  { alt: 'Saturday crowd waiting at Mueller Farmers Market', bg: '#FEF3CC', accent: '#8C1815', src: 'crowd' },
];

// ============================================================
// Catering packages
// ============================================================
export type CateringPackage = {
  name: string;
  guests: string;
  price: string;
  features: string[];
};

export const cateringPackages: CateringPackage[] = [
  {
    name: 'Smoke Starter',
    guests: 'Up to 50 guests',
    price: 'From $800',
    features: [
      '2-hour service window',
      '2 taco proteins',
      '2 sides',
      'Soft drinks included',
      'Disposable serviceware',
    ],
  },
  {
    name: 'Full Roll',
    guests: '50 – 150 guests',
    price: 'From $2,000',
    features: [
      '3-hour service window',
      'Full menu access (4 proteins)',
      '3 sides + drinks',
      'Setup & breakdown included',
      'Custom branded menu board',
    ],
  },
  {
    name: 'Pit Boss',
    guests: '150 – 400 guests',
    price: 'Custom quote',
    features: [
      'Half-day or full-day service',
      'Full menu + seasonal specials',
      'Second truck available',
      'On-site pitmaster',
      'Custom menu design',
    ],
  },
];
