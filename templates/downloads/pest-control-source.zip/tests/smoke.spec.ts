import { test, expect } from '@playwright/test';

test.describe('Thornfield Pest — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Thornfield Pest & Wildlife/);
    await expect(page.locator('h1')).toContainText('Identify first');
  });

  // The editorial grid is the archetype. Entries carry unequal weight on
  // purpose, so sizing them all the same would undo the whole point.
  test('the field guide is an editorial grid with entries of unequal weight', async ({ page }) => {
    await page.goto('/');
    const entries = page.locator('#guide .entry');
    expect(await entries.count()).toBe(8);
    expect(await page.locator('#guide .entry--lead').count()).toBe(2);
    expect(await page.locator('#guide .entry--mid').count()).toBe(4);
    expect(await page.locator('#guide .entry--minor').count()).toBe(2);
  });

  test('at 1060px the lead entries really are wider than the minor ones', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 900 });
    await page.goto('/');
    const lead = await page.locator('#guide .entry--lead').first().evaluate((e) => e.getBoundingClientRect().width);
    const minor = await page.locator('#guide .entry--minor').first().evaluate((e) => e.getBoundingClientRect().width);
    expect(lead).toBeGreaterThan(minor);
  });

  // A pest-control page that says "treat" for everything is a spray schedule
  // wearing a field guide's clothes.
  test('half the guide declines to sell a treatment, and the hero says so', async ({ page }) => {
    await page.goto('/');
    const now = await page.locator('#guide .flag--now').count();
    const watch = await page.locator('#guide .flag--watch').count();
    const none = await page.locator('#guide .flag--none').count();
    expect(now + watch + none).toBe(8);
    // Not "most" — four of these genuinely warrant action, and softening real
    // advice to make a metric look better would be the wrong trade. What must
    // hold is that a substantial share says do nothing yet, and that at least
    // one entry is not a pest at all.
    expect(watch + none).toBeGreaterThanOrEqual(4);
    expect(none).toBeGreaterThanOrEqual(1);
    // The hero quotes this count. If the data changes, the copy must follow.
    await expect(page.locator('main')).toContainText(`${watch + none} do not need treating on sight`);
  });

  test('every threshold flag reads as a word, not just a colour', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#guide .flag').allTextContents()) {
      expect(['Treat now', 'Monitor', 'Leave it']).toContain(t.trim());
    }
  });

  test('each entry gives a tell and a threshold', async ({ page }) => {
    await page.goto('/');
    const entries = page.locator('#guide .entry');
    for (const t of await entries.allTextContents()) {
      expect(t).toContain('How you know');
      expect(t).toContain('Threshold');
    }
  });

  test('the IPM section is an ordered list of four steps', async ({ page }) => {
    await page.goto('/');
    const ol = page.locator('#ipm ol');
    await expect(ol).toHaveCount(1);
    expect(await ol.locator('> li').count()).toBe(4);
  });

  test('plans and termite pricing show real figures', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#plans article').count()).toBe(3);
    const rows = page.locator('#termites .rate-table tbody tr');
    expect(await rows.count()).toBe(4);
    for (const t of await rows.allTextContents()) expect(t).toMatch(/\$\d/);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 79.
  test('no trace of the day-79 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['clearwater', 'portland', 'ike brennan', 'hard-water', 'squeegee']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro termite guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/termite-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Barrier, bait, or both');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
