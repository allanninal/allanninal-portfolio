/**
 * Thornfield Pest & Wildlife — every string the page renders.
 *
 * Business fictional; PRICES ARE REAL 2026 US figures, and the IPM thresholds
 * follow EPA and university-extension guidance rather than sales copy.
 * Sources in RESEARCH.md. Replace contact details before shipping.
 */

export const site = {
  name: 'Thornfield Pest & Wildlife',
  shortName: 'Thornfield',
  tagline: 'Identify first. Treat only what needs treating.',
  description:
    'Integrated pest management in Raleigh — we identify what you actually have, tell you whether it crosses the threshold for treatment, and reach for a spray last rather than first.',
  owner: 'Delia Okonkwo',
  ownerRole: 'Owner · BS Entomology',
  yearsExperience: 12,
  city: 'Raleigh',
  state: 'NC',
  streetAddress: '1408 Rock Quarry Road',
  postalCode: '27610',
  phoneDisplay: '(919) 555-0176',
  phoneHref: '+19195550176',
  email: 'hello@thornfieldpest.example',
  formAction: '#',
  hours: 'Mon–Fri 8am–5pm · Emergency stinging-insect calls same day',
  bookingWindow: 'Inspections within three business days. Termite inspections are free.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Thornfield Pest & Wildlife — Integrated Pest Management in Raleigh, NC',
  license: 'NC Structural Pest Control licence #PW-7742',
  instagram: 'https://www.instagram.com/thornfieldpest',
  facebook: 'https://www.facebook.com/thornfieldpest',
};

export const nav = [
  { label: 'Field guide', href: '#guide' },
  { label: 'Why IPM', href: '#ipm' },
  { label: 'Plans', href: '#plans' },
  { label: 'Termites', href: '#termites' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The field guide. `weight` drives the editorial grid: lead entries get a wide
 * cell, minor ones a narrow one. Sizing every entry the same would misrepresent
 * how common — and how serious — each one actually is.
 *
 * `action` is the honest part. 'now' means treat; 'watch' means monitor and do
 * nothing yet; 'none' means this is not a pest and we will not sell you a spray
 * for it.
 */
export const pests = [
  {
    id: 'termite', name: 'Subterranean termites', weight: 'lead', action: 'now',
    tell: 'Mud tubes on foundation walls, hollow-sounding trim, discarded wings on sills in spring.',
    threshold: 'Any confirmed activity. This is the one pest where waiting genuinely costs you thousands.',
    season: 'Swarms March–May',
  },
  {
    id: 'roach', name: 'German cockroach', weight: 'lead', action: 'now',
    tell: 'Small, tan, two dark stripes behind the head. Seen in daylight means a large population.',
    threshold: 'Any sighting indoors. They breed too fast for monitoring to be a strategy.',
    season: 'Year-round, indoors',
  },
  {
    id: 'ant', name: 'Odorous house ants', weight: 'mid', action: 'watch',
    tell: 'A trail to one food source; crushed, they smell faintly of blue cheese.',
    threshold: 'A steady indoor trail for more than a week. A single scouting line after rain usually stops on its own.',
    season: 'Spring through autumn',
  },
  {
    id: 'mouse', name: 'House mouse', weight: 'mid', action: 'now',
    tell: 'Droppings along wall runs, gnawed packaging, scratching in the ceiling after dark.',
    threshold: 'Any indoor evidence. Exclusion first — sealing the entry beats trapping what already got in.',
    season: 'Moves indoors October–February',
  },
  {
    id: 'wasp', name: 'Yellowjackets', weight: 'mid', action: 'now',
    tell: 'Steady traffic to a single gap in siding or a hole in the lawn.',
    threshold: 'A nest within about 20 feet of a door, a play area, or anyone with a sting allergy. Otherwise a nest in a far fence line can be left to die off in winter.',
    season: 'Peaks August–September',
  },
  {
    id: 'mosquito', name: 'Mosquitoes', weight: 'mid', action: 'watch',
    tell: 'Biting at dawn and dusk, worst within a few days of rain.',
    threshold: 'Standing water is the treatment. We will walk the yard and empty it with you before we quote a barrier spray, because the spray without that is money burned.',
    season: 'April–October',
  },
  {
    id: 'spider', name: 'Common house spider', weight: 'minor', action: 'none',
    tell: 'Untidy cobwebs in corners, ceilings and window reveals.',
    threshold: 'None. They eat the things you actually mind and they are not a structural or health risk. We will knock the webs down while we are there and not charge you for a treatment.',
    season: 'Year-round',
  },
  {
    id: 'silverfish', name: 'Silverfish', weight: 'minor', action: 'watch',
    tell: 'Fast, wingless, tapered; usually in bathrooms, basements and boxes of old paper.',
    threshold: 'Persistent numbers, which almost always means a humidity problem. Fix the damp and they leave.',
    season: 'Year-round, humidity-driven',
  },
];

/** The IPM argument, in the order the EPA lays it out. */
export const ipm = [
  { step: 'Identify', body: 'Half the calls we take are for something that is not what the caller thinks it is, and a third are for something that does not need treating at all. Nothing sensible happens before identification.' },
  { step: 'Set a threshold', body: 'One ant is not an infestation. A threshold is the point where damage or risk becomes unacceptable — and it is different for a wasp nest by the back door than for one in a far hedge.' },
  { step: 'Prevent', body: 'Exclusion, moisture, food storage, habitat. This is the least glamorous part and it is the part that actually holds.' },
  { step: 'Control, least-risk first', body: 'Traps, baits and targeted application before anything broadcast. Broadcast spraying is the last resort, not the opening move.' },
];

/** Real 2026 US figures. */
export const plans = [
  { name: 'One-time visit', price: '$150 – $500', fit: 'A specific problem you want gone, with no ongoing commitment.', includes: ['Full identification', 'Targeted treatment', '30-day retreat if it returns'] },
  { name: 'Quarterly', price: '$100 – $175 per visit', fit: 'The default for most Raleigh homes. $400 – $700 across a year.', includes: ['Four scheduled visits', 'Exterior perimeter and entry points', 'Free callbacks between visits', 'Annual termite inspection'] },
  { name: 'Monitoring only', price: 'From $58 per month', fit: 'Termite stations and a yearly inspection, with no routine spraying at all.', includes: ['Bait stations checked quarterly', 'Written inspection report', 'Treatment quoted only if activity appears'] },
];

export const termites = {
  intro: 'Termites get their own section because the numbers are an order of magnitude apart from everything else on this page, and because North Carolina is genuine subterranean-termite country.',
  rows: [
    { what: 'Inspection', cost: '$75 – $200', note: 'Ours is free. Most companies use it as a way in, and we would rather say so than pretend otherwise.' },
    { what: 'Monitoring, per month', cost: '$58 – $125', note: 'Averaged across annual inspection and station checks.' },
    { what: 'Initial treatment', cost: '$700 – $2,500', note: 'Depends on linear footage and construction type.' },
    { what: 'Full treatment', cost: '$1,500 – $4,000', note: 'Slab, crawlspace and access all move this number.' },
  ],
};

export const areas = [
  { zone: 'Raleigh', towns: 'Downtown · Five Points · North Hills · Brier Creek · Southeast Raleigh' },
  { zone: 'West', towns: 'Cary · Apex · Morrisville · Holly Springs' },
  { zone: 'North', towns: 'Wake Forest · Rolesville · Youngsville' },
  { zone: 'East & South', towns: 'Knightdale · Garner · Clayton · Fuquay-Varina' },
];

export const reviews = [
  { name: 'Curtis M.', town: 'Five Points', text: 'Called about spiders. She looked, told me they were harmless, knocked the webs down and did not charge me. I have used her for everything since.' },
  { name: 'Anjali S.', town: 'Cary', text: 'Free termite inspection found actual mud tubes under the crawlspace. The quote was detailed enough that I got two others to compare and hers held up.' },
  { name: 'Tobias R.', town: 'Wake Forest', text: 'She walked the yard, emptied three things holding water, and said to call back in two weeks if it was still bad. It was not.' },
  { name: 'Lorraine P.', town: 'Garner', text: 'Yellowjackets in the siding a week before a family party. Same day, gone, and she showed me the gap they were using so I could seal it.' },
];

export const faqs = [
  { q: 'Is quarterly spraying actually necessary?', a: 'For a lot of homes, no. A quarterly plan makes sense if you have recurring pressure — ants every spring, roaches from a shared wall, a wooded lot. If you called once about one problem, a one-time visit and some exclusion work is usually the better spend, and we will tell you that.' },
  { q: 'Do you use chemicals inside?', a: 'Rarely, and never as a first move. Most indoor work is baiting, trapping and sealing. When an interior application is genuinely warranted we tell you the product, where it goes, and how long to stay out.' },
  { q: 'Is the treatment safe for pets and children?', a: 'The products are applied at label rates and the label is the law. That said, "safe" depends entirely on following re-entry intervals, so we give you them in writing. If you have fish, reptiles or nursing pets, tell us before we start — those change what we use.' },
  { q: 'Why is your termite inspection free when others charge?', a: 'Because it is how we get the chance to quote treatment, and that is worth being honest about. It is a real inspection with a written report either way, and there is no obligation.' },
  { q: 'Will one treatment fix it?', a: 'For wasps, usually. For mice, only if the entry is sealed. For German cockroaches, no — that takes a sequence over several weeks, and anyone promising a single visit is selling you a relapse.' },
  { q: 'Do you handle wildlife?', a: 'Squirrels, raccoons and bats in the structure, yes — exclusion and one-way doors, not poison. Bats have legal protections and a maternity season when they cannot be excluded at all; we work to that calendar.' },
];
