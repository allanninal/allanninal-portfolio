/**
 * Rampart Exterior Cleaning — every string the page renders.
 *
 * Business fictional. PRESSURE FACTS AND PRICES ARE REAL 2026 figures; the
 * "never pressure wash" instructions are industry standard, not positioning.
 * Sources in RESEARCH.md.
 */

export const site = {
  name: 'Rampart Exterior Cleaning',
  shortName: 'Rampart',
  tagline: 'The right pressure for the surface. Often that means none.',
  description:
    'Pressure and soft washing across Chattanooga. Three of the seven surfaces we clean must never see high pressure — and we would rather tell you that than sell you the version that looks best on video.',
  owner: 'Dell Marchetti',
  ownerRole: 'Owner',
  yearsExperience: 8,
  city: 'Chattanooga',
  state: 'TN',
  streetAddress: '1440 Rossville Avenue',
  postalCode: '37408',
  phoneDisplay: '(423) 555-0181',
  phoneHref: '+14235550181',
  email: 'hello@rampartexterior.example',
  formAction: '#',
  hours: 'Mon–Sat 7am–5pm · Not in freezing weather, and we will say when',
  bookingWindow: 'Quoting within two days. Most jobs booked inside a fortnight.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Rampart Exterior Cleaning — Pressure & Soft Washing in Chattanooga, TN',
  license: 'Licensed and insured · $2M liability',
  instagram: 'https://www.instagram.com/rampartexterior',
  facebook: 'https://www.facebook.com/rampartexterior',
};

export const nav = [
  { label: 'Surfaces', href: '#surfaces' },
  { label: 'Two methods', href: '#methods' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The seven surfaces — the scrollytelling stage.
 *
 * `method` is the honest field. THREE of these say soft-wash-only, including
 * roofs where high pressure voids shingle warranties outright. Those three are
 * the least photogenic and the most valuable thing on the page.
 *
 * `swatch` and `texture` drive the CSS-drawn surface panel; no photography
 * ships in the free edition.
 */
export const surfaces = [
  {
    id: 'concrete', name: 'Concrete driveway', method: 'pressure', psi: '3,000 PSI',
    swatch: '#9E9C97', texture: 'concrete',
    why: 'Dense, non-porous once cured, and the one surface where full pressure is genuinely correct.',
    note: 'This is where the satisfying video comes from. It is also the only surface on this list where that video is honest.',
    rate: '$0.15 – $0.30 / sq ft',
  },
  {
    id: 'brick', name: 'Brick and stone', method: 'pressure', psi: '1,500 – 2,500 PSI',
    swatch: '#9B6B57', texture: 'brick',
    why: 'Hard face, but the mortar is softer than the brick and blows out first.',
    note: 'We drop the pressure at every joint. A driveway wand held on old lime mortar will take it out in seconds.',
    rate: '$0.20 – $0.40 / sq ft',
  },
  {
    id: 'vinyl', name: 'Vinyl siding', method: 'soft', psi: 'Under 500 PSI',
    swatch: '#C9CBC4', texture: 'siding',
    why: 'Panels overlap and are not watertight from below. High pressure drives water behind them, into the sheathing.',
    note: 'Soft wash only: detergent, dwell time, low-pressure rinse. Slower, less dramatic, and the reason your wall cavity stays dry.',
    rate: '$0.20 – $0.50 / sq ft',
  },
  {
    id: 'roof', name: 'Roof', method: 'never', psi: 'No pressure. Ever.',
    swatch: '#5F6166', texture: 'shingle',
    why: 'High pressure strips the granules that are the shingle’s UV protection, and forces water up under the courses.',
    note: 'It also voids many shingle warranties outright. Anyone who offers to pressure wash your roof is telling you what they do not know.',
    rate: '$0.30 – $0.70 / sq ft, soft wash',
  },
  {
    id: 'cedar', name: 'Cedar and painted wood', method: 'never', psi: 'No pressure. Ever.',
    swatch: '#B98A5E', texture: 'wood',
    why: 'Wood is soft and directional. Pressure raises the grain, furs the surface and drives water into the end grain.',
    note: 'A pressure-washed cedar fence looks bright for a season and then greys faster than one that was never touched.',
    rate: '$0.20 – $0.40 / sq ft, soft wash',
  },
  {
    id: 'stucco', name: 'Stucco and EIFS', method: 'never', psi: 'No pressure. Ever.',
    swatch: '#D7D2C6', texture: 'stucco',
    why: 'Porous, and EIFS is a foam system with a thin coat over it. Pressure punches straight through.',
    note: 'One of the most expensive repairs in this trade, and one of the most common mistakes.',
    rate: '$0.25 – $0.50 / sq ft, soft wash',
  },
  {
    id: 'deck', name: 'Composite decking', method: 'pressure', psi: '1,200 – 1,500 PSI',
    swatch: '#8A8478', texture: 'deck',
    why: 'Tougher than wood, but the cap layer scars and the scars hold dirt permanently.',
    note: 'Fan tip, wide, kept moving. Most composite damage we see is a stationary wand and thirty careless seconds.',
    rate: '$0.20 – $0.40 / sq ft',
  },
];

export const methods = [
  {
    name: 'Pressure washing',
    psi: '1,500 – 3,000 PSI',
    on: 'Concrete, brick, stone, unsealed masonry, composite decking',
    how: 'Mechanical. Water at pressure does the work.',
    risk: 'Wrong surface, wrong distance or a stationary wand causes permanent damage in seconds.',
  },
  {
    name: 'Soft washing',
    psi: 'Under 500 PSI, plus detergent and algaecide',
    on: 'Vinyl, painted wood, cedar, stucco, EIFS, roofs',
    how: 'Chemical. The solution kills the organic growth and dwell time does the work.',
    risk: 'Slower, uses more product, and looks far less impressive while it is happening. It is still the correct answer.',
  },
];

/** Real 2026 US figures. */
export const pricing = {
  perSqFt: [
    { surface: 'Concrete flatwork', rate: '$0.15 – $0.30' },
    { surface: 'House and siding, soft wash', rate: '$0.20 – $0.50' },
    { surface: 'Deck and patio', rate: '$0.20 – $0.40' },
    { surface: 'Roof, soft wash', rate: '$0.30 – $0.70' },
  ],
  jobs: [
    { job: 'Whole-house wash', total: '$250 – $600' },
    { job: 'Driveway', total: '$100 – $250' },
    { job: 'Roof wash', total: '$300 – $700' },
  ],
  note: 'Across everything, $0.15 to $0.75 per square foot. Soft washing sits at the upper end because it takes longer and uses more chemical — not because it is a premium service.',
};

export const areas = [
  { zone: 'Chattanooga', towns: 'Northshore · St Elmo · Highland Park · Brainerd · Hixson' },
  { zone: 'North', towns: 'Red Bank · Signal Mountain · Soddy-Daisy' },
  { zone: 'East', towns: 'Ooltewah · Collegedale · East Ridge' },
  { zone: 'Georgia line', towns: 'Fort Oglethorpe · Ringgold · Rossville' },
];

export const reviews = [
  { name: 'Corinne B.', town: 'St Elmo', text: 'Two companies quoted pressure washing the roof. Dell told me that voids the shingle warranty and soft washed it instead. The roofer confirmed it when he came for something else.' },
  { name: 'Wes A.', town: 'Signal Mountain', text: 'He refused to pressure wash the cedar fence and explained why. It has been two years and it still looks better than my neighbour’s, which was blasted.' },
  { name: 'Tanya M.', town: 'Hixson', text: 'The driveway looks like new concrete. He also told me the stucco on the front needed the slow treatment and charged accordingly.' },
  { name: 'Julian P.', town: 'Ooltewah', text: 'Straightforward quote, arrived when he said, and told me the north wall would go green again in about eighteen months. It did, almost exactly.' },
];

export const faqs = [
  { q: 'Why won’t you pressure wash my roof?', a: 'Because it strips the granules that protect the shingle from UV, forces water up under the courses, and voids many manufacturer warranties. Soft washing kills the algae with solution instead of force and the roof looks the same afterwards. Anyone offering to pressure wash a roof is telling you what they do not know.' },
  { q: 'Soft washing sounds like it just means weaker. Does it work?', a: 'It works better on organic growth, because it kills it rather than knocking it off. Pressure removes what is on the surface; the algae root structure stays and regrows quickly. The trade-off is that soft washing is slower and far less satisfying to watch.' },
  { q: 'How long will it stay clean?', a: 'In this climate, twelve to twenty-four months on a north-facing surface, longer on one that gets sun. Anyone promising five years is selling a coating, not a wash.' },
  { q: 'Will the chemicals kill my plants?', a: 'They can if nobody bothers. We pre-wet everything within the splash zone, tarp what needs it and rinse afterwards. Ask any quote what their plant protection actually is; the answer tells you a lot.' },
  { q: 'Can I just rent a machine?', a: 'For a concrete driveway, genuinely yes — it is not difficult and a rental will do a decent job. For siding, wood, stucco or a roof, a rental machine in unpractised hands is how the expensive mistakes happen.' },
  { q: 'Do you work in winter?', a: 'Down to about 40°F. Below that the solution stops working properly and anything we rinse can freeze on a walkway, which is a liability nobody needs.' },
];
