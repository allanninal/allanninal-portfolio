import { test, expect } from '@playwright/test';

test.describe('Rampart Exterior — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Rampart Exterior Cleaning/);
    await expect(page.locator('h1')).toContainText('right pressure');
  });

  // The stage is an ordered list, so the surface sequence survives with CSS
  // off — which is the whole reason this scrollytelling is CSS-only.
  test('the stage is an ordered list of seven surfaces', async ({ page }) => {
    await page.goto('/');
    const ol = page.locator('#surfaces ol');
    await expect(ol).toHaveCount(1);
    expect(await ol.locator('> li.stage').count()).toBe(7);
    expect(await page.locator('#surfaces .surface-panel').count()).toBe(7);
  });

  test('each visual pins while its spec scrolls, on a desktop viewport', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 900 });
    await page.goto('/');
    const pos = await page.locator('#surfaces .stage-visual').first().evaluate((e) => getComputedStyle(e).position);
    expect(pos).toBe('sticky');
  });

  // ...and must NOT pin on a phone, because a pinned panel on a 375px screen
  // just steals the viewport.
  test('the stage stops pinning on a phone', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const pos = await page.locator('#surfaces .stage-visual').first().evaluate((e) => getComputedStyle(e).position);
    expect(pos).not.toBe('sticky');
  });

  // The argument of the page: three surfaces must never see pressure.
  test('three surfaces say never, and the hero quotes the real count', async ({ page }) => {
    await page.goto('/');
    const never = await page.locator('#surfaces .method-flag--never').count();
    expect(never).toBe(3);
    await expect(page.locator('main')).toContainText(`${never} of the 7 surfaces below must never see high pressure`);
    // Roofs specifically — the most commonly mis-sold job in this trade.
    await expect(page.locator('#surfaces')).toContainText(/voids many shingle warranties/i);
  });

  test('every method flag reads as words, not just a colour', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#surfaces .method-flag').allTextContents()) {
      expect(['Pressure wash', 'Soft wash', 'Never pressure wash']).toContain(t.trim());
    }
  });

  test('each surface states a PSI figure and a failure mode', async ({ page }) => {
    await page.goto('/');
    const specs = page.locator('#surfaces .spec');
    expect(await specs.count()).toBe(7);
    for (const t of await specs.allTextContents()) {
      expect(t).toMatch(/PSI|No pressure/);
      expect(t).toMatch(/\$\d/);
    }
  });

  test('both methods are compared with their trade-offs', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#methods article').count()).toBe(2);
    await expect(page.locator('#methods')).toContainText(/less impressive/i);
  });

  test('pricing shows per-sq-ft rates and whole-job totals', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#pricing .rate-table tbody tr').count()).toBe(7);
    for (const t of await page.locator('#pricing .rate-table tbody tr').allTextContents()) {
      expect(t).toMatch(/\$\d/);
    }
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('quote form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 83.
  test('no trace of the day-83 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['meridian pool', 'scottsdale', 'cyanuric', 'ivy castellanos', 'chlorine']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro surface guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/surface-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('PSI and nozzle by surface');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
