import { test, expect } from '@playwright/test';

test.describe('Auberge Two — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Auberge Two/);
    await expect(page.locator('h1')).toContainText('holding the camera');
  });

  test('handles the schema.org gap and claims no service area', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
    expect(json).not.toContain('areaServed');
  });

  // ── The credit blocks ───────────────────────────────────────────────────
  test('every shoot carries a credit block, always visible', async ({ page }) => {
    await page.goto('/');
    const shoots = page.locator('#shoots figure.shoot');
    expect(await shoots.count()).toBe(5);
    for (const s of await shoots.all()) {
      await expect(s.locator('dl.credits')).toBeVisible();
      await expect(s.locator('img')).toHaveCount(1);
    }
  });

  // The page's headline claim has to be true of the page's own data.
  test('each frame names between eight and fifteen people', async ({ page }) => {
    await page.goto('/');
    const counts = await page.locator('#shoots dl.credits').evaluateAll((dls) =>
      dls.map((dl) =>
        [...dl.querySelectorAll('dt')].filter((d) => !/garment/i.test(d.textContent || '')).length,
      ),
    );
    expect(counts.length).toBe(5);
    for (const c of counts) {
      expect(c).toBeGreaterThanOrEqual(8);
      expect(c).toBeLessThanOrEqual(15);
    }
  });

  test('photography is credited alongside the crew, not above it', async ({ page }) => {
    await page.goto('/');
    for (const dl of await page.locator('#shoots dl.credits').all()) {
      const roles = await dl.locator('dt').allTextContents();
      expect(roles.map((r) => r.trim())).toContain('Photography');
      // A block naming only the photographer would defeat the whole point.
      expect(roles.length).toBeGreaterThan(3);
    }
  });

  // ── The money disclosure ────────────────────────────────────────────────
  test('the money is a native disclosure, closed by default', async ({ page }) => {
    await page.goto('/');
    const d = page.locator('#shoots details.money');
    expect(await d.count()).toBe(5);
    for (const one of await d.all()) {
      expect(await one.getAttribute('open')).toBeNull();
    }
  });

  test('opening a disclosure reveals a net that equals fee minus costs', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#shoots details.money').first();
    await first.locator('summary').click();
    await expect(first).toHaveAttribute('open', '');
    const nums = await first.locator('.money-rows .n').allTextContents();
    const parse = (s: string) => {
      const t = s.trim();
      if (t === '—') return 0;
      const v = Number(t.replace(/[^0-9]/g, ''));
      return t.startsWith('−') ? -v : v;
    };
    const vals = nums.map(parse);
    const net = vals[vals.length - 1];
    const sum = vals.slice(0, -1).reduce((a, b) => a + b, 0);
    expect(net).toBe(sum);
  });

  // The taboo half: at least one shoot must show a loss, or the page is lying.
  test('at least one shoot shows a loss, and the count is derived', async ({ page }) => {
    await page.goto('/');
    for (const s of await page.locator('#shoots details.money summary').all()) await s.click();
    const losses = await page.locator('#shoots .money-rows .net.is-loss').count();
    // Two elements carry the class per losing shoot (label and figure).
    const losingShoots = losses / 2;
    expect(losingShoots).toBeGreaterThanOrEqual(1);
    await expect(page.locator('#shoots .figure-lead'))
      .toContainText(`${losingShoots} of the 5 shoots above lost money`);
  });

  test('the disclosure works with JavaScript disabled', async ({ browser }) => {
    const ctx = await browser.newContext({ javaScriptEnabled: false });
    const p = await ctx.newPage();
    await p.goto('/');
    const first = p.locator('#shoots details.money').first();
    await first.locator('summary').click();
    await expect(first.locator('.money-rows')).toBeVisible();
    await ctx.close();
  });

  // ── The crew tally ──────────────────────────────────────────────────────
  test('the crew list is derived from the credit blocks, naming nobody extra', async ({ page }) => {
    await page.goto('/');
    const named = new Set(
      (await page.locator('#shoots dl.credits dd').allTextContents()).map((s) => s.trim()),
    );
    const tallied = (await page.locator('#crew .tally li > span:first-child').allTextContents())
      .map((s) => s.trim());
    expect(tallied.length).toBeGreaterThan(0);
    for (const person of tallied) expect(named.has(person)).toBe(true);
    await expect(page.locator('#crew h2')).toContainText(`${tallied.length} people made the 5 frames`);
  });

  test('every image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#shoots img').evaluateAll((els) =>
      els.map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })),
    );
    expect(imgs.length).toBe(5);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.w).toBeTruthy();
      expect(i.h).toBeTruthy();
    }
  });

  test('all five images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')),
    );
    expect(broken).toEqual([]);
  });

  test('rates are published rather than hidden behind an enquiry', async ({ page }) => {
    await page.goto('/');
    const p = page.locator('#pays');
    await expect(p).toContainText('Editorial does not pay');
    expect(await p.locator('tbody tr').count()).toBe(5);
    await expect(p).toContainText(/why do editorial at all/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the contact form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 93.
  test('no trace of the day-93 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['ovist', 'milwaukee', 'kumbh', 'reddit mono', 'exclusivity']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro credit standard is absent from the free build', async ({ page }) => {
    const res = await page.goto('/credit-standard/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
