// Auberge Two — Savannah, GA.
//
// Fourth photography template in a row, so a fourth axis: 91 what you receive,
// 92 who you are, 93 what you are buying, 94 who actually made it.
//
// The spine is the credit block — fashion's own artifact, and the thing
// photographers' portfolio sites routinely drop. Under each one is a
// disclosure with the money in it, including the shoots that lost money.

export const site = {
  name:        'Auberge Two',
  shortName:   'Auberge Two',
  title:       'Auberge Two — Fashion Photography in Savannah, GA',
  tagline:     'Eight to fifteen people make a fashion image. One of them is holding the camera.',
  owner:       'Odile Auberge',
  ownerRole:   'Fashion photographer',
  credential:  'Editorial and lookbook · Savannah',
  license:     'Fashion photography, working since 2015',
  city:        'Savannah',
  state:       'GA',
  language:    'en',
  phoneDisplay: '(912) 555-0143',
  phoneHref:   '+19125550143',
  email:       'studio@aubergetwo.example',
  streetAddress: '2214 Bull St',
  postalCode:  '31401',
  hours:       'Studio Mon–Fri · shoot days scheduled around casting',
  bookingWindow: 'Editorial by conversation. Commercial estimating for spring.',
  description:
    'Editorial and lookbook photography in Savannah. Every frame here carries the full ' +
    'credit block, because a fashion image is made by a crew and the convention exists ' +
    'for a reason — and under each one you can open what the shoot actually paid.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The work',   href: '#shoots' },
  { label: 'The crew',   href: '#crew' },
  { label: 'What it pays', href: '#pays' },
  { label: 'Commissions', href: '#commissions' },
  { label: 'Contact',    href: '#contact' },
];

// ── The shoots ────────────────────────────────────────────────────────────
// Alt strings written from the files. The source page for e01 describes
// classical columns and a dark coat; it is a camel coat and a modernist facade.
//
// `fee` and `costs` are real-shaped numbers for this end of the trade. Net is
// computed in the page, never typed, so an edit cannot leave a stale total.

export const shoots = [
  {
    id: 'e01', file: 'e01.jpg',
    title: 'Bauhaus, Anywhere',
    forWhom: 'Editorial · Ochre Quarterly, issue 14',
    alt: 'A woman in a camel coat, black wide-brimmed hat and sunglasses standing before a white modernist building',
    credits: [
      ['Photography', 'Odile Auberge'],
      ['Styling', 'Marisol Okonkwo'],
      ['Hair', 'Devendra Rai'],
      ['Make-up', 'Fiadh Ó Braonáin'],
      ['Model', 'Tuuli Rehn at Grove'],
      ['Production', 'Auberge Two'],
      ['Manicure', 'Perpetua Lindgren'],
      ['Set design', 'Halvor Ndiaye'],
      ['Retouch', 'Kwabena Asare'],
      ['Garments', 'Vestry Atelier'],
    ],
    fee: 350,
    costs: [['Studio and location permit', 240], ['Crew day rates, four', 620], ['Transport and meals', 180], ['Retouch, six frames', 140]],
    note: 'A loss, and a normal one for an independent title. The stylist on this shoot has recommended us for three paid jobs since.',
  },
  {
    id: 'e02', file: 'e02.jpg',
    title: 'Long Coat, White Rail',
    forWhom: 'Editorial · Ochre Quarterly, issue 14',
    alt: 'A figure in a long tan coat on a white balcony, one arm outstretched along the rail',
    credits: [
      ['Photography', 'Odile Auberge'],
      ['Styling', 'Marisol Okonkwo'],
      ['Hair', 'Devendra Rai'],
      ['Make-up', 'Fiadh Ó Braonáin'],
      ['Model', 'Ilhan Yusuf at Grove'],
      ['Assistant', 'Perpetua Lindgren'],
      ['Digital tech', 'Halvor Ndiaye'],
      ['Casting', 'Marisol Okonkwo'],
      ['Retouch', 'Kwabena Asare'],
      ['Garments', 'Vestry Atelier'],
    ],
    fee: 350,
    costs: [['Shared with the frame above', 0], ['Additional assistant day', 220], ['Retouch, four frames', 95]],
    note: 'Same day, same crew, second story. Splitting a shoot day across two stories is how editorial is made to almost work.',
  },
  {
    id: 'e03', file: 'e03.jpg',
    title: 'Yellow, From Behind',
    forWhom: 'Editorial · Wend Magazine, autumn',
    alt: 'A woman photographed from behind in a yellow coat and navy wide-brimmed hat on a city street',
    credits: [
      ['Photography', 'Odile Auberge'],
      ['Styling', 'Bexley Ferreira'],
      ['Hair and make-up', 'Nnenna Achebe'],
      ['Model', 'Saoirse Delacroix at Meridian'],
      ['Casting', 'Wend Magazine'],
      ['Manicure', 'Perpetua Lindgren'],
      ['Assistant', 'Halvor Ndiaye'],
      ['Retouch', 'Odile Auberge'],
      ['Garments', "Stylist's own and archive"],
    ],
    fee: 900,
    costs: [['Crew day rates, two', 480], ['Transport', 90], ['Retouch, in-house', 0]],
    note: 'An established title, so a real fee. Still under a commercial half-day, and it took the same amount of everyone’s life.',
  },
  {
    id: 'e04', file: 'e04.jpg',
    title: 'Shearling, Runway',
    forWhom: 'Show coverage · Janerations, autumn presentation',
    alt: 'A model in a shearling-trimmed coat and gold boots walking a catwalk past a seated audience',
    credits: [
      ['Photography', 'Odile Auberge'],
      ['Show production', 'Janerations'],
      ['Styling', 'Bexley Ferreira'],
      ['Hair', 'Devendra Rai'],
      ['Make-up', 'Nnenna Achebe'],
      ['Model', 'Anouk Thiessen at Meridian'],
      ['Manicure', 'Perpetua Lindgren'],
      ['Assistant', 'Halvor Ndiaye'],
      ['Retouch', 'Odile Auberge'],
      ['Garments', 'Janerations, knitwear collection'],
    ],
    fee: 1400,
    costs: [['Assistant, one day', 220], ['Same-night edit and delivery', 300], ['Transport', 110]],
    note: 'Show coverage pays properly because the deadline is brutal. Images delivered by 2am for next-morning press.',
  },
  {
    id: 'e05', file: 'e05.jpg',
    title: 'Collar, Autumn',
    forWhom: 'Lookbook · Vestry Atelier, autumn/winter',
    alt: 'A woman in a dark high-collared coat photographed against autumn foliage',
    credits: [
      ['Photography', 'Odile Auberge'],
      ['Art direction', 'Vestry Atelier'],
      ['Styling', 'Marisol Okonkwo'],
      ['Hair and make-up', 'Fiadh Ó Braonáin'],
      ['Model', 'Rosalind Achterberg at Grove'],
      ['Production', 'Auberge Two'],
      ['Manicure', 'Perpetua Lindgren'],
      ['Digital tech', 'Halvor Ndiaye'],
      ['Retouch', 'Kwabena Asare'],
      ['Garments', 'Vestry Atelier'],
    ],
    fee: 4200,
    costs: [['Crew day rates, four', 980], ['Location fee', 350], ['Transport and meals', 220], ['Retouch, 22 frames', 640]],
    note: 'Commercial. This one pays for the two above it, which is the honest shape of the year.',
  },
];

export const shootsNote =
  'The credit block is not a courtesy. A fashion image is made by a crew, the convention ' +
  'for naming them is universal in print, and it is dropped almost everywhere else. ' +
  'Every name above is on every frame it belongs to, in the order the trade uses.';

// ── What it pays ──────────────────────────────────────────────────────────

export const pays = {
  headline: 'Editorial does not pay. That is not a complaint, it is the arithmetic.',
  rows: [
    { kind: 'Independent title',   day: '$0 – $400',      note: 'Expenses often unreimbursed. Everyone on the call sheet is there for the book.' },
    { kind: 'Established title',   day: '$500 – $1,500',  note: 'A real fee. Still less than a commercial half-day.' },
    { kind: 'Show coverage',       day: '$1,200 – $2,000', note: 'Paid properly because the turnaround is overnight.' },
    { kind: 'Lookbook',            day: '$2,500 – $4,500', note: 'Plus licence, quoted separately by media, term and territory.' },
    { kind: 'Campaign',            day: 'Quoted per job',  note: 'Where the licence usually costs more than the shoot.' },
  ],
  why: {
    q: 'So why do editorial at all?',
    a: 'Because it is how the book gets made, how you meet the stylists who recommend you, ' +
       'and how commercial clients find you. That is a working answer rather than a romantic ' +
       'one — and the shoot above that lost $830 is the reason three paid jobs happened.',
  },
};

export const commissions = {
  intro: 'What a commercial enquiry needs to say, so the first reply is a number rather than a question.',
  rows: [
    { need: 'What is being shot',     why: 'Garment count and whether there is a model changes the day more than anything else.' },
    { need: 'Where it runs',          why: 'Lookbook, e-commerce, paid social and outdoor are four different licences.' },
    { need: 'How long you need it',   why: 'A season, a year, or no end date. It is the cheapest thing to decide early.' },
    { need: 'Who is art directing',   why: 'You, us, or an agency. All three are fine; not knowing on the day is not.' },
    { need: 'The date, honestly',     why: 'Casting and crew are booked in the same week. A moving date costs the crew, not us.' },
  ],
};

export const faqs = [
  {
    q: 'Why publish what a shoot paid?',
    a: 'Because the numbers are the only honest explanation for how this business is shaped. Editorial is subsidised by commercial work in every fashion studio in the country, and pretending otherwise leaves young photographers budgeting for a job that does not exist.',
  },
  {
    q: 'Will you credit everyone?',
    a: 'Always, on every image, wherever we control the caption. If a title drops the block we ask once and then we hold the line: we do not post the frame without the crew on it.',
  },
  {
    q: 'Do you shoot tests?',
    a: 'A few a year, with people we want to work with rather than to fill a day. A test where nobody is paid should at least be a test everybody chose.',
  },
  {
    q: 'Can you work with our art director?',
    a: 'Preferably. A strong deck makes the day faster and the results better. What slows a shoot is not direction, it is direction that arrives at eleven.',
  },
  {
    q: 'Who books the model?',
    a: 'Whoever is paying, usually. We will run casting if you want it and it is a line on the estimate — options, fittings and the agency booking fee, which is 20% on top of the model rate and surprises people every time.',
  },
  {
    q: 'Do you retouch in-house?',
    a: 'Small jobs yes, volume no. Kwabena is credited on the frames he worked on, which is the same reason everyone else is.',
  },
];
