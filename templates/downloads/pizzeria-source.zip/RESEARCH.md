# Day 32 — Pizzeria Research

## Differentiation from existing food templates

| Day | Template | Palette | Fonts | Mode |
|-----|----------|---------|-------|------|
| 22 | restaurant-general | Dark olive-charcoal (#1A1A13) + gold (#C4973A) | Libre Baskerville + Mulish | Dark |
| 23 | coffee-shop | Parchment (#F7EEE2) + terracotta-rust | Fraunces + Plus Jakarta Sans | Light |
| **32** | **pizzeria** | **Warm cream (#FDFAF5) + tomato red (#C0392B) + basil green (#2D6A4F)** | **Playfair Display + Nunito** | **Light** |

## Palette rationale

- **Tomato red (#C0392B)** — Primary accent. Vibrant, appetizing, Italian-coded. Contrast ratio ~5.8:1 on cream (#FDFAF5) — WCAG AA compliant.
- **Warm cream (#FDFAF5)** — Light-mode background. Evokes fresh dough / mozzarella. Distinct from coffee-shop's parchment-brown tone.
- **Basil green (#2D6A4F)** — Secondary accent for vegan tags, est. badge. Contrast ratio ~6.1:1 on cream — WCAG AA compliant.
- **Deep espresso (#1C1208)** — Body text. Distinct from the olive-black of Day 22.
- Hero uses a full red-to-cream gradient evoking a wood-fired oven glow.

## Typography

- **Playfair Display** — High-contrast italic serif with luxurious letterforms. Italian dining energy without being stuffy. Never used in prior sprints.
- **Nunito** — Rounded humanist sans, warm and approachable. Pairs well with Playfair's elegance. Never used in prior sprints.
- Both loaded via @fontsource (self-hosted, no Google Fonts CDN).

## Persona

Three-generation family pizzeria (Napoli's, Little Italy Manhattan). Opened 1974 by Giovanni Russo, now run by grandson Marco. Wood-fired oven, 48-hour fermented dough, imported San Marzano tomatoes. Order via Slice. Neighborhood institution persona — warm, proud, unpretentious.

## Key differentiators vs Day 22 (restaurant-general)

1. **Light mode** vs dark — completely opposite mood.
2. **Italian-coded** vs American bistro.
3. **Tomato red + basil green** vs olive-gold.
4. **Playfair + Nunito** vs Libre Baskerville + Mulish.
5. **Online-order-first** (Slice CTA) vs reservation-first (OpenTable).
6. **Pizza-specific menu structure** (Pizzas/Starters/Drinks) vs multi-cuisine tabbed menu (Starters/Mains/Desserts/Drinks).
7. **SVG pizza illustration + Italian-flag colour rule** vs grain-texture dark hero.

## Sections

1. Hero — gradient oven-glow, "Napoli's" in massive Playfair, Italian-flag accent rule, Order Online + View Menu CTAs
2. Specials — 3-card weekly specials with chef-pick/vegan/spicy tags
3. Menu — tabbed (Pizzas · Starters · Drinks) with tag chips and prices
4. Order CTA — full-width tomato red band, Slice + phone CTAs
5. Hours — clean card table, Monday closed
6. Our Story — Marco Russo bio, philosophy blockquote, SVG pizza illustration
7. Location — SVG map, address, subway directions, contact, social
8. Footer — dark espresso, quick links, contact, built-by + Ko-fi

## Schema.org

- `Restaurant` with `servesCuisine`, `openingHoursSpecification`, `AggregateRating`, `hasMenu`, `foundingDate`
- `Menu` linked via `@id`
- `Person` (Marco Russo, owner/pizzaiolo)

## No external images

All visuals are SVG/CSS — no external photography. Image registry stays clean.
