import { test, expect } from '@playwright/test';

test.describe("Pizzeria — smoke tests", () => {
  test("home page loads with restaurant name", async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Napoli/i);
    await expect(page.getByRole('heading', { level: 1 })).toContainText("Napoli");
  });

  test("navigation links are present", async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Main navigation' });
    await expect(nav.getByRole('link', { name: 'Menu', exact: true })).toBeVisible();
    await expect(nav.getByRole('link', { name: /Hours/i })).toBeVisible();
    await expect(nav.getByRole('link', { name: /Order/i })).toBeVisible();
  });

  test("specials section is present", async ({ page }) => {
    await page.goto('/');
    const specials = page.locator('#specials');
    await expect(specials.getByRole('heading', { name: 'Specials' })).toBeVisible();
    await expect(specials.getByText('Pistachio & Burrata')).toBeVisible();
  });

  test("menu tabs are present and switchable", async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('tab', { name: 'Pizzas' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Starters' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Drinks' })).toBeVisible();

    // Default panel shows pizzas
    await expect(page.getByRole('tabpanel', { name: 'Pizzas' })).toBeVisible();
    await expect(page.getByRole('tabpanel', { name: 'Pizzas' }).getByText('Margherita')).toBeVisible();

    // Click Starters tab
    await page.getByRole('tab', { name: 'Starters' }).click();
    await expect(page.getByRole('tabpanel', { name: 'Starters' })).toBeVisible();
    await expect(page.getByRole('tabpanel', { name: 'Starters' }).getByText('Bruschetta')).toBeVisible();
  });

  test("hours section shows closed on Monday", async ({ page }) => {
    await page.goto('/');
    const hoursSection = page.locator('#hours');
    await expect(hoursSection.getByRole('heading', { name: 'Hours' })).toBeVisible();
    await expect(hoursSection.getByText('Monday')).toBeVisible();
    await expect(hoursSection.getByText('Closed')).toBeVisible();
  });

  test("order section has Slice link", async ({ page }) => {
    await page.goto('/');
    const orderSection = page.locator('#order');
    await expect(orderSection.getByRole('heading', { name: 'Order Online' })).toBeVisible();
    await expect(orderSection.getByRole('link', { name: /Order on Slice/i })).toBeVisible();
  });

  test("story section shows owner name", async ({ page }) => {
    await page.goto('/');
    const storySection = page.locator('#story');
    await expect(storySection.getByRole('heading', { name: 'Our Story' })).toBeVisible();
    await expect(storySection.locator('blockquote footer')).toContainText('Marco Russo');
  });

  test("location section shows address", async ({ page }) => {
    await page.goto('/');
    const locationSection = page.locator('#location');
    await expect(locationSection.getByRole('heading', { name: 'Location & Getting Here' })).toBeVisible();
    await expect(locationSection.locator('address')).toContainText('174 Mulberry Street');
    await expect(locationSection.locator('address')).toContainText('New York');
  });

  test("JSON-LD Restaurant schema is present", async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasRestaurant = false;
    let hasOpeningHours = false;
    let hasRating = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('"Restaurant"')) hasRestaurant = true;
      if (content && content.includes('openingHoursSpecification')) hasOpeningHours = true;
      if (content && content.includes('AggregateRating')) hasRating = true;
    }
    expect(hasRestaurant).toBe(true);
    expect(hasOpeningHours).toBe(true);
    expect(hasRating).toBe(true);
  });

  test("JSON-LD has servesCuisine and Menu", async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasCuisine = false;
    let hasMenu = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('servesCuisine')) hasCuisine = true;
      if (content && content.includes('"Menu"')) hasMenu = true;
    }
    expect(hasCuisine).toBe(true);
    expect(hasMenu).toBe(true);
  });

  test("no github.com deep-links in page source", async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const deepLinks = html.match(/github\.com\/allanninal\/templates[^"'\s]*/g);
    expect(deepLinks).toBeNull();
  });
});
