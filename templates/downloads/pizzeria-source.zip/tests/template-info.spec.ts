import { test, expect } from '@playwright/test';

// Asserts the canonical TemplateInfo download bar is present on the live demo
// build. Requires playwright.config.ts to set PUBLIC_TEMPLATE_HUB_URL on the
// webServer.env block — otherwise the bar correctly returns null and tests fail.

test.describe('TemplateInfo download bar', () => {
  test('renders 4 canonical links with correct hrefs', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', {
      name: /Free template — download or fork/i,
    });
    await expect(bar).toBeVisible();

    const slug = 'pizzeria';

    const staticZip = bar.getByRole('link', { name: /Download static/i });
    const sourceZip = bar.getByRole('link', { name: /Source \(Astro\)/i });
    const gallery   = bar.getByRole('link', { name: /All 365/i });
    const hire      = bar.getByRole('link', { name: /Build with me/i });

    await expect(staticZip).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-static\\.zip$`)
    );
    await expect(sourceZip).toHaveAttribute(
      'href',
      new RegExp(`/downloads/${slug}-source\\.zip$`)
    );
    await expect(gallery).toHaveAttribute('href', /templates\.allanninal\.dev/);
    await expect(hire).toHaveAttribute(
      'href',
      'https://www.linkedin.com/in/allanninal/'
    );
  });

  test('contains zero github.com links', async ({ page }) => {
    await page.goto('/');
    const bar = page.getByRole('complementary', {
      name: /Free template — download or fork/i,
    });
    const hrefs = await bar
      .locator('a')
      .evaluateAll((els) => els.map((e) => e.getAttribute('href') || ''));
    const githubLinks = hrefs.filter((h) => h.includes('github.com'));
    expect(githubLinks).toEqual([]);
  });
});
