import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES } from './helpers';

// Pizzeria is light-only — no theme toggle, so we run axe in light mode only.
for (const route of ROUTES) {
  test(`a11y ${route} (light)`, async ({ page }) => {
    await page.goto(route);
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(
      results.violations,
      `A11y violations on ${route} (light):\n${JSON.stringify(results.violations, null, 2)}`
    ).toEqual([]);
  });
}
