import type { Page } from '@playwright/test';

// Single-page template — only one route
export const ROUTES = ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// Pizzeria is light-only (no theme toggle). setTheme is kept for API
// compatibility with the shared test helpers pattern, but only 'light' is used.
export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    localStorage.setItem('theme', t);
    document.documentElement.setAttribute('data-theme', t);
  }, theme);
}
