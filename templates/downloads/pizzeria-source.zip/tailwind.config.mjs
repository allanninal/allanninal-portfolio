/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'ui-serif', 'serif'],
        sans: ['"Nunito"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      colors: {
        // Warm cream light-mode + tomato red accent + basil green — Day 32 Pizzeria
        bg:       '#FDFAF5',
        surface:  '#FFFFFF',
        'surface-2': '#F7F2EA',
        border:   '#E8DFD0',
        // Tomato red — WCAG AA on cream
        accent: {
          DEFAULT: '#C0392B',
          dark:    '#962D22',
          light:   '#FFE8E5',
          dim:     '#E5504A',
        },
        // Basil green — used for tags, secondary accents
        green: {
          DEFAULT: '#2D6A4F',
          light:   '#E8F5EE',
        },
        text: {
          DEFAULT: '#1C1208',
          muted:   '#6B5B45',
          faint:   '#A89880',
        },
      },
      fontSize: {
        xs:    ['0.8rem',   { lineHeight: '1.5' }],
        sm:    ['0.9rem',   { lineHeight: '1.55' }],
        base:  ['1rem',     { lineHeight: '1.7' }],
        lg:    ['1.125rem', { lineHeight: '1.65' }],
        xl:    ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.35' }],
        '3xl': ['1.875rem', { lineHeight: '1.25' }],
        '4xl': ['2.25rem',  { lineHeight: '1.15' }],
        '5xl': ['3rem',     { lineHeight: '1.1' }],
        '6xl': ['3.75rem',  { lineHeight: '1.05' }],
        '7xl': ['4.5rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '80rem',
        '8xl': '88rem',
      },
    },
  },
};
