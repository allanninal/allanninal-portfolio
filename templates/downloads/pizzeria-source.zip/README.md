# Pizzeria — Day 32 of 365

A mouth-watering Neapolitan pizzeria template built with Astro + Tailwind CSS.

**Live demo:** https://example.com/

## Features

- Appetizing hero with wood-fired oven atmosphere (tomato red gradient)
- Weekly specials strip with chef's pick, vegan, and spicy tags
- Full tabbed menu: Pizzas, Starters, Drinks — all static, no JS framework
- Bold online-order CTA (Slice/Toast placeholder)
- Hours table with Monday-closed layout
- Owner story section with SVG pizza illustration
- Location section with SVG map, directions, subway info
- schema.org Restaurant + Menu + Person JSON-LD
- GA + AdSense injected only when `PUBLIC_TEMPLATE_HUB_URL` is set
- MIT licensed — fork, customize, ship

## Palette

| Token        | Value     | Usage                        |
|--------------|-----------|------------------------------|
| `bg`         | `#FDFAF5` | Warm cream page background   |
| `accent`     | `#C0392B` | Tomato red — CTAs, prices    |
| `green`      | `#2D6A4F` | Basil green — vegan tags     |
| `text`       | `#1C1208` | Deep espresso text           |
| `text-muted` | `#6B5B45` | Secondary text               |

## Fonts

- **Display:** Playfair Display (serif) — headings, restaurant name
- **Body:** Nunito (sans-serif) — body copy, labels, UI

## Sections

1. Hero (gradient oven-glow, name, tagline, Order + Menu CTAs)
2. Specials (this week's chef features)
3. Menu (tabs: Pizzas / Starters / Drinks)
4. Order CTA band (Slice link + phone)
5. Hours table
6. Our Story (owner bio + SVG pizza illustration)
7. Location (SVG map, address, transit, contact, social)
8. Footer

## Getting Started

```bash
cd templates/pizzeria
npm install
npm run dev
```

Visit http://localhost:4321/

## Environment Variables

| Variable                | Required | Description                             |
|-------------------------|----------|-----------------------------------------|
| `PUBLIC_BASE_PATH`      | No       | Base URL path (default: `/pizzeria/`)   |
| `PUBLIC_SITE_URL`       | No       | Full site URL for canonical links       |
| `PUBLIC_TEMPLATE_HUB_URL` | No     | Author hub — enables GA, AdSense, download bar |

## Customization

1. Edit `src/data/site.ts` — restaurant name, address, phone, social links
2. Edit `src/data/menu.ts` — add/remove menu items and specials
3. Edit `src/data/hours.ts` — update opening hours
4. Swap `public/og-image.svg` + `.png` with your own branding
5. Replace Slice order URL with your actual ordering platform

## License

MIT © 2026 Allan Niñal
