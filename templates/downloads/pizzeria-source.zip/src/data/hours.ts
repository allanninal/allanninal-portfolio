export type DayHours = {
  day: string;
  dayOfWeek: string[];
  opens: string;
  closes: string;
  label: string;
  closed?: boolean;
};

export const hours: DayHours[] = [
  { day: 'Monday',    dayOfWeek: ['Monday'],    opens: '00:00', closes: '00:00', label: 'Closed', closed: true },
  { day: 'Tuesday',   dayOfWeek: ['Tuesday'],   opens: '11:30', closes: '22:00', label: '11:30 AM – 10:00 PM' },
  { day: 'Wednesday', dayOfWeek: ['Wednesday'], opens: '11:30', closes: '22:00', label: '11:30 AM – 10:00 PM' },
  { day: 'Thursday',  dayOfWeek: ['Thursday'],  opens: '11:30', closes: '22:00', label: '11:30 AM – 10:00 PM' },
  { day: 'Friday',    dayOfWeek: ['Friday'],    opens: '11:30', closes: '23:00', label: '11:30 AM – 11:00 PM' },
  { day: 'Saturday',  dayOfWeek: ['Saturday'],  opens: '11:00', closes: '23:00', label: '11:00 AM – 11:00 PM' },
  { day: 'Sunday',    dayOfWeek: ['Sunday'],    opens: '11:00', closes: '21:00', label: '11:00 AM – 9:00 PM' },
];

export const openingHoursSpec = hours.filter(h => !h.closed);
