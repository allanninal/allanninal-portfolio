export type MenuItem = {
  name: string;
  description: string;
  price: string;
  tag?: 'chef-pick' | 'vegan' | 'spicy' | 'new' | 'gluten-free';
};

export type MenuCategory = {
  id: string;
  label: string;
  items: MenuItem[];
};

export const specials: MenuItem[] = [
  {
    name: 'Pistachio & Burrata',
    description: 'San Marzano base, fior di latte, Sicilian pistachio cream, fresh burrata, basil oil, lemon zest.',
    price: '$26',
    tag: 'chef-pick',
  },
  {
    name: "La Norma",
    description: 'Roasted eggplant, smoked ricotta salata, cherry tomatoes, basil, light tomato sauce.',
    price: '$22',
    tag: 'vegan',
  },
  {
    name: 'Nduja Diavola',
    description: "Spicy Calabrian 'nduja, fior di latte, San Marzano, Castelvetrano olives, fresh chili.",
    price: '$24',
    tag: 'spicy',
  },
];

export const menuCategories: MenuCategory[] = [
  {
    id: 'pizzas',
    label: 'Pizzas',
    items: [
      {
        name: 'Margherita',
        description: 'San Marzano tomato, fior di latte, fresh basil, extra virgin olive oil.',
        price: '$18',
      },
      {
        name: 'Marinara',
        description: 'San Marzano tomato, garlic, oregano, extra virgin olive oil. (No cheese.)',
        price: '$15',
        tag: 'vegan',
      },
      {
        name: 'Diavola',
        description: "San Marzano tomato, fior di latte, spicy salami, Calabrian chili.",
        price: '$21',
        tag: 'spicy',
      },
      {
        name: 'Quattro Stagioni',
        description: 'Artichoke hearts, prosciutto cotto, black olives, mushrooms, tomato, mozzarella.',
        price: '$23',
      },
      {
        name: 'Prosciutto e Rucola',
        description: 'White base, fior di latte, San Daniele prosciutto crudo, wild arugula, Parmigiano shavings.',
        price: '$25',
      },
      {
        name: 'Funghi Porcini',
        description: 'White base, fior di latte, porcini mushrooms, truffle oil, fresh thyme.',
        price: '$24',
        tag: 'chef-pick',
      },
      {
        name: 'Salsiccia e Friarielli',
        description: 'Fior di latte, Italian sausage, sautéed broccoli rabe, garlic, chili.',
        price: '$23',
      },
      {
        name: 'Quattro Formaggi',
        description: 'Fior di latte, gorgonzola, smoked scamorza, Parmigiano, drizzle of honey.',
        price: '$24',
      },
      {
        name: 'Pistachio & Burrata',
        description: 'San Marzano base, fior di latte, Sicilian pistachio cream, fresh burrata, basil oil.',
        price: '$26',
        tag: 'chef-pick',
      },
      {
        name: "La Norma",
        description: 'Roasted eggplant, smoked ricotta salata, cherry tomatoes, basil, light tomato sauce.',
        price: '$22',
        tag: 'vegan',
      },
    ],
  },
  {
    id: 'starters',
    label: 'Starters',
    items: [
      {
        name: 'Bruschetta al Pomodoro',
        description: 'Grilled sourdough, crushed San Marzano tomatoes, basil, garlic, olive oil.',
        price: '$9',
        tag: 'vegan',
      },
      {
        name: 'Burrata & Prosciutto',
        description: 'Fresh burrata, San Daniele prosciutto, cherry tomatoes, arugula, truffle honey.',
        price: '$16',
      },
      {
        name: 'Arancini al Ragù',
        description: 'Two Sicilian rice balls stuffed with slow-cooked beef ragù and peas, tomato sauce.',
        price: '$13',
      },
      {
        name: 'Polpette al Forno',
        description: 'Wood-oven baked meatballs in San Marzano tomato sauce, pecorino, crusty bread.',
        price: '$15',
      },
      {
        name: 'Antipasto della Casa',
        description: 'Selection of cured meats, aged cheeses, marinated vegetables, grissini. Serves 2–3.',
        price: '$24',
      },
      {
        name: 'Insalata Caprese',
        description: 'Buffalo mozzarella, heirloom tomatoes, basil, aged balsamic, extra virgin olive oil.',
        price: '$17',
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Drinks',
    items: [
      {
        name: 'House Chianti',
        description: 'Smooth Tuscan Chianti Classico. Glass / Carafe.',
        price: '$10 / $32',
      },
      {
        name: 'Peroni Nastro Azzurro',
        description: 'Italian lager, crisp and refreshing. Bottle.',
        price: '$7',
      },
      {
        name: 'San Pellegrino',
        description: 'Sparkling mineral water. 500 ml / 1 L.',
        price: '$4 / $7',
      },
      {
        name: 'Acqua Panna',
        description: 'Still mineral water. 500 ml / 1 L.',
        price: '$4 / $7',
      },
      {
        name: 'Limonata Artigianale',
        description: 'House-made Amalfi lemon soda with fresh mint. Non-alcoholic.',
        price: '$6',
      },
      {
        name: 'Espresso / Doppio',
        description: "Italian roast pulled on our La Marzocco. Single / Double.",
        price: '$3 / $4.50',
      },
      {
        name: 'Tiramisu della Casa',
        description: 'Mascarpone cream, espresso-soaked savoiardi, cocoa. Not a drink — but order it anyway.',
        price: '$9',
        tag: 'chef-pick',
      },
    ],
  },
];
