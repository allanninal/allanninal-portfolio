export const site = {
  name: "Napoli's",
  tagline: 'Authentic Neapolitan Pizzeria',
  neighborhood: 'Little Italy, Manhattan',
  description:
    "Napoli's serves hand-stretched Neapolitan pizza baked in a wood-fired oven at 900°F. Three generations of the Russo family have been bringing a taste of Naples to Little Italy since 1974.",
  cuisine: 'Italian, Pizza',
  priceRange: '$$',
  phone: '(212) 555-0174',
  phoneDisplay: '(212) 555-0174',
  email: 'ciao@napolisnyc.com',
  address: {
    street: '174 Mulberry Street',
    city: 'New York',
    state: 'NY',
    zip: '10013',
    full: '174 Mulberry Street, Little Italy, Manhattan, NY 10013',
    country: 'US',
  },
  geo: {
    lat: 40.7199,
    lng: -73.9969,
  },
  mapUrl: 'https://maps.google.com/?q=174+Mulberry+Street+New+York+NY+10013',
  orderUrl: 'https://slice.com',
  instagram: '@napolisnyc',
  instagramUrl: 'https://instagram.com/napolisnyc',
  facebook: 'napolisnyc',
  facebookUrl: 'https://facebook.com/napolisnyc',
  rating: {
    value: 4.8,
    count: 1247,
    max: 5,
  },
  estYear: 1974,
  og: {
    alt: "Napoli's — Authentic Neapolitan Pizzeria in Little Italy, Manhattan",
  },
};

export const owner = {
  name: 'Marco Russo',
  title: 'Owner & Pizzaiolo',
  bio: `Marco Russo grew up in the kitchen behind this very restaurant, watching his grandfather Giovanni shape dough with calloused hands and a quiet confidence. The wood-fired oven at the back wall — the same one Giovanni had shipped from Naples in 1974 — is still the heart of the operation.

After studying under a master pizzaiolo in Naples and returning to New York with a deeper reverence for the craft, Marco took over Napoli's in 2003. He sources 00-grade flour from a mill in Caputo, uses San Marzano tomatoes grown in volcanic soil near Mount Vesuvius, and imports his fior di latte fresh every week.

He believes a perfect pizza needs nothing more than great ingredients, a hot oven, and fifty years of family memory.`,
  philosophy:
    'Fifty years. Same oven. Same dough recipe. We do one thing, and we do it right.',
};
