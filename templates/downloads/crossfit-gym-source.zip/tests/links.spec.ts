import { test, expect } from '@playwright/test';

test.describe('CrossFit Gym — link integrity', () => {
  test('homepage loads with HTTP 200', async ({ page }) => {
    const response = await page.goto('/');
    expect(response?.status()).toBe(200);
  });

  test('page title is set correctly', async ({ page }) => {
    await page.goto('/');
    const title = await page.title();
    expect(title).toContain('CrossFit Ironclad');
  });

  test('meta description is present and meaningful', async ({ page }) => {
    await page.goto('/');
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description).toBeTruthy();
    expect(description!.length).toBeGreaterThan(50);
  });

  test('canonical URL is set', async ({ page }) => {
    await page.goto('/');
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical).toBeTruthy();
  });

  test('OG image meta is present', async ({ page }) => {
    await page.goto('/');
    const ogImage = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(ogImage).toBeTruthy();
  });

  test('key section IDs exist in DOM', async ({ page }) => {
    await page.goto('/');
    for (const id of ['wod', 'schedule', 'coaches', 'onramp', 'membership', 'faq', 'contact', 'about', 'testimonials']) {
      await expect(page.locator(`#${id}`)).toBeAttached();
    }
  });

  test('join and start links are present', async ({ page }) => {
    await page.goto('/');
    const joinLinks = page.locator('a[href*="crossfitironclad.com"]');
    const count = await joinLinks.count();
    expect(count).toBeGreaterThan(0);
  });

  test('tel and mailto links are present', async ({ page }) => {
    await page.goto('/');
    const telLinks  = page.locator('a[href^="tel:"]');
    const mailLinks = page.locator('a[href^="mailto:"]');
    const telCount  = await telLinks.count();
    const mailCount = await mailLinks.count();
    expect(telCount + mailCount).toBeGreaterThanOrEqual(2);
  });

  test('social links have noopener noreferrer', async ({ page }) => {
    await page.goto('/');
    const socialLinks = page.locator('a[target="_blank"][rel*="noopener"]');
    const count = await socialLinks.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('JSON-LD structured data blocks are present', async ({ page }) => {
    await page.goto('/');
    const jsonLd = await page.locator('script[type="application/ld+json"]').all();
    expect(jsonLd.length).toBeGreaterThanOrEqual(3);
  });

  test('favicon is linked', async ({ page }) => {
    await page.goto('/');
    const favicon = page.locator('link[rel="icon"]');
    await expect(favicon).toBeAttached();
  });

  test('class schedule filter works', async ({ page }) => {
    await page.goto('/');
    const wodBtn = page.locator('.filter-btn[data-filter="WOD"]');
    await wodBtn.click();
    await expect(wodBtn).toHaveClass(/active/);
    const visibleRows = page.locator('#schedule-table tbody tr:not([hidden])');
    const count = await visibleRows.count();
    expect(count).toBeGreaterThan(0);
  });

  test('membership pricing section has three tiers', async ({ page }) => {
    await page.goto('/');
    const pricingCards = page.locator('.pricing-card');
    const count = await pricingCards.count();
    expect(count).toBe(3);
  });

  test('WOD board is present and has movement list', async ({ page }) => {
    await page.goto('/');
    const wodBoard = page.locator('#wod');
    await expect(wodBoard).toBeAttached();
    const wodMovements = page.locator('.wod-movement');
    const count = await wodMovements.count();
    expect(count).toBeGreaterThanOrEqual(3);
  });

  test('On-Ramp section has 6 sessions', async ({ page }) => {
    await page.goto('/');
    const sessions = page.locator('.session-card');
    const count = await sessions.count();
    expect(count).toBe(6);
  });
});
