# CrossFit Gym — Day 61 of 365 Templates

A CrossFit affiliate box website featuring a daily WOD (Workout of the Day) board, class schedule with JS filter, 4-coach grid, On-Ramp Foundations program breakdown, 3-tier membership pricing, member testimonials, box philosophy pillars, FAQ accordion, and contact form.

**Persona:** CrossFit Ironclad — Denver, CO (RiNo District)
**Palette:** Steel Night `#0E1520` + Volt Yellow `#C8F000` — distinct from Day 60's Carbon Black + Electric Orange
**Fonts:** Anton (display) + Saira (body) — distinct from Day 60's Russo One + Exo 2

## Features

- WOD Board section — today's workout with Warm-Up, Skill Work, WOD movements (Rx + Scaled), Cool-Down
- Weekly class schedule table with JS filter (WOD / Competitors / Open Gym)
- On-Ramp Foundations — 6 session breakdown grid
- 4 coach cards with CF-L1/CF-L2/USAW certifications
- 3-tier membership pricing (Foundations + First Month / Monthly Unlimited / Punch Card)
- 5 member testimonials
- Box Philosophy section (Constantly Varied / Functional Movement / High Intensity)
- FAQ accordion (8 Q&A)
- Contact form (Formspree placeholder) + hours
- Mindbody booking CTAs
- Sticky header with mobile nav toggle
- TemplateInfo download bar (hub-gated)
- AnalyticsHead (GA + AdSense, hub-gated)
- HealthClub + SportsActivityLocation + LocalBusiness + Person + FAQPage JSON-LD

## Live Demo

[example.com](https://example.com/)

## Quick Start

```bash
cd templates/crossfit-gym
npm install
npm run dev
```

## Env Variables

| Variable | Purpose |
|---|---|
| `PUBLIC_SITE_URL` | Canonical URL base |
| `PUBLIC_BASE_PATH` | Deploy base path (e.g. `/crossfit-gym/`) |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables download bar + analytics |
| `PUBLIC_EDITION` | Set `pro` for Pro edition bar |
| `PUBLIC_SHOP_URL` | Pro edition shop URL |

## Part of 365 Templates

[example.com](https://example.com) · [LinkedIn](#)
