export const box = {
  name:         'CrossFit Ironclad',
  tagline:      'Built Strong. Forged Together.',
  description:  'CrossFit affiliate box in Denver, CO (RiNo) — coached WOD classes, On-Ramp foundations program, and a tight-knit community for all levels.',
  phone:        '(720) 555-0193',
  email:        'hello@crossfitironclad.com',
  address:      '3720 Brighton Blvd',
  city:         'Denver',
  state:        'CO',
  zip:          '80216',
  instagram:    'https://instagram.com/crossfitironclad',
  facebook:     'https://facebook.com/crossfitironclad',
  youtube:      'https://youtube.com/@crossfitironclad',
  joinUrl:      'https://app.crossfitironclad.com/join',
  startUrl:     'https://app.crossfitironclad.com/foundations',
  headCoach: {
    name:  'Coach Jake Rivera',
    title: 'Owner & Head Coach',
    certs: ['CF-L2', 'USAW Level 1', 'Precision Nutrition L1'],
  },
  makerBio: {
    name:     'CrossFit Ironclad',
    url:      'https://allanninal.dev',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'CrossFit Ironclad | CrossFit Box in Denver CO — WODs, Coaches & Membership',
  description:   'CrossFit Ironclad is a CrossFit affiliate box in Denver, CO\'s RiNo district. Daily WOD classes, On-Ramp foundations for beginners, 4 CF-L1/L2 certified coaches. First week free — start your CrossFit journey today.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
