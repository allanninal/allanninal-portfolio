# Day 61 — CrossFit Gym: Niche Research

## Slug
`crossfit-gym`

## Differentiation from Days 1–60

### Why CrossFit is distinct from Day 60 (fitness-gym-general)

Day 60 (fitness-gym-general) ships a general commercial gym: multiple group-class formats (HIIT, Spin, Strength, Yoga, Boxing), a filterable schedule table, 4 trainer cards, 3-tier memberships, Russo One + Exo 2 fonts, Carbon Black (#111214) + Electric Orange (#EF4900) dark-default palette, Iron Peak Fitness Austin persona.

Day 61 (crossfit-gym) is a **CrossFit "box"** — a fundamentally different sub-niche:
- Not a gym, it's a **box** (community-first, shared suffering, tribe culture)
- **WOD Board** (Workout of the Day) as hero centrepiece — an iconic CrossFit UI element not found in general gyms
- **CF-L1 / CF-L2 / USAW** certified coaches, not generic CPT/CSCS trainers
- **On-Ramp / Foundations program** — mandatory 6-session intro for new members (unique to CrossFit)
- Language: "Box" not "gym", "Coach" not "trainer", "Workout" not "class", "Athletes" not "members"

### Visual register audit (all prior days — palettes taken)

| Day | Palette family | Fonts |
|-----|----------------|-------|
| 1 | Amber #FFB020 on near-black | Inter + Geist Mono |
| 2 | Violet/indigo on light | Geist/Satoshi + Inter |
| 3 | Lime #A3E635 on dark | Geist |
| 4 | Coral #FF6B4A on light | DM Sans |
| 5 | Forest green #1C4A2E on warm-white | Newsreader + Inter |
| 6 | Cobalt #2563EB on light | IBM Plex |
| 7 | Magenta #DB2777 on warm off-white | Manrope |
| 8 | Burnt orange #C2410C on warm off-white | Fraunces + Space Grotesk |
| 10 | Teal #14B8A6 on dark | Outfit + Geist Mono |
| 11 | Oxblood #881337 on cream | Lora + Work Sans |
| 12 | Aubergine #4A1942 on warm white | Fraunces + Space Grotesk |
| 13 | Near-black + Amber #E8A020 on dark | Bricolage Grotesque + JetBrains Mono |
| 22 | Olive-charcoal + gold | Libre Baskerville + Mulish |
| 23 | Parchment + terracotta-rust | Fraunces + Plus Jakarta Sans |
| 25 | Sage-linen + green | Raleway + Nunito |
| 27 | Navy #0D1117 + cyan #00D4FF | Space Grotesk + JetBrains Mono |
| 28 | Cobalt blue (GitHub palette) | IBM Plex Mono |
| 29 | Warm off-white + indigo #6366F1 | Inter Tight + JetBrains Mono |
| 32 | Cream + tomato red #C0392B | Playfair Display + Nunito |
| 35 | Terracotta #C45B3A + parchment | Archivo Black + Cormorant |
| 36 | Near-black + oxblood + brass | DM Serif Display + Karla |
| 37 | Buttercream + strawberry-rose | Playfair Display + Nunito |
| 38 | Champagne ivory + pistachio | Gilda Display + Jost |
| 39 | Bubblegum-pink + sky-blue | Fredoka + Nunito Sans |
| 40 | Pistachio + strawberry + vanilla | Pacifico + Source Sans 3 |
| 41 | Citrus-orange + leafy-green | Urbanist Variable + Geist |
| 42 | Slate-charcoal + copper-amber | Oswald + Work Sans |
| 43 | Deep velvet + burgundy + gold | Cinzel + Montserrat |
| 44 | Noir-black + emerald-neon | Bodoni Moda + IBM Plex Mono |
| 45 | Parchment + celadon | Cardo + Figtree |
| 46 | Sunny-yellow + coral + sky | Gabarito + Poppins |
| 48 | Midnight-navy + champagne-gold | Marcellus + Mulish |
| 49 | Aubergine + champagne-blush | Tenor Sans + Albert Sans |
| 50 | Mauve + champagne + ivory | Bellefair + Questrial |
| 51 | Near-black + oxblood + brass | Teko + Hind |
| 52 | Coral + rose-gold + plum | Italiana + Plus Jakarta Sans |
| 53 | Sage-green #3A6047 + stone + pearl | Crimson Pro + Raleway |
| 54 | Deep ocean teal #1A4A5A + sand | Libre Baskerville + Source Sans 3 |
| 55 | Ink-black + bone-white + amber #E8A020 | Bebas Neue + Barlow |
| 56 | Blush-ivory + warm-clay #C2705A + forest | DM Serif Display + DM Sans |
| 57 | Deep-plum #4A1860 + champagne-gold | Cormorant Garamond + Nunito Sans |
| 58 | Espresso-dark #1C1410 + dusty-rose | Playfair Display + DM Sans |
| 59 | Crisp white + herb-green #1F7A54 + honey | Josefin Sans + Bitter |
| 60 | **Carbon Black #111214 + Electric Orange #EF4900** | **Russo One + Exo 2** |

### Day 61 distinct visual register

**Palette: Steel Night + Volt Yellow**

- **Base**: Steel Night `#0E1520` — a cold blue-tinged near-black, distinct from day 60's warmer Carbon Black `#111214` and from all prior darks (ink-black, near-black, espresso, noir-black, deep-velvet)
- **Accent**: Volt Yellow `#C8F000` — vivid neon athletic yellow, the "volt" color used in performance sports branding. Distinct from:
  - Day 3 lime `#A3E635`: greener, muted by comparison; Volt is purer yellow-green
  - Day 55 amber-gold `#E8A020`: amber/orange territory, not yellow-green
  - Day 60 Electric Orange `#EF4900`: completely different hue
  - Day 41 citrus-orange/leafy-green: warm consumer palette vs cold athletic
- **Surface 1**: `#151D2B` — card backgrounds
- **Surface 2**: `#1A2437` — slightly elevated surface
- **Border**: `#252F42` — structural dividers
- **Text Primary**: `#EEF2FB` — cool off-white, slight blue tint (distinct from day 60's neutral Concrete White `#F0F0EE`)
- **Text Muted**: `#8896B0` — supporting text

**WCAG AA contrast verification:**
- `#EEF2FB` on `#0E1520`: ~13.8:1 — AAA ✓
- `#EEF2FB` on `#151D2B`: ~12.5:1 — AAA ✓
- `#C8F000` on `#0E1520`: ~8.4:1 — AAA ✓ (large headings & icons)
- `#0E1520` on `#C8F000`: ~8.4:1 — AAA ✓ (button text on volt)
- `#8896B0` on `#0E1520`: ~4.6:1 — AA ✓ (muted text)
- `#C8F000` on `#151D2B`: ~7.6:1 — AA ✓ (labels on cards)
- DO NOT use `#C8F000` as small body text on `#1A2437` — use `#EEF2FB` instead

**Typography: Anton + Saira**

- **Anton** (Google Fonts — single weight 400): Ultra-bold condensed sans-serif. Classic of performance/athletic display. NOT used in any of days 1–60. Visually very different from Russo One (day 60) — Anton is significantly more condensed/narrow vs Russo One's wider proportions. Renders well in all-caps WOD headings.
- **Saira** (Google Fonts — variable 100–900): Clean geometric sans, slightly condensed, with a technical precision. Great range from light to black weights. NOT used in any of days 1–60. Distinct from Exo 2 (day 60) — Saira has tighter apertures and a more rigid grid feel.

**Density**: High-density information layout — WOD board (daily workout breakdown), coach cards, class schedule, membership tiers, on-ramp section, testimonials, FAQ.

---

## Persona

**CrossFit Ironclad** — CrossFit Affiliate Box
- Location: Denver, CO (River North Art District / RiNo area)
- Head Coach / Owner: **Coach Jake Rivera**, CF-L2 (CrossFit Level 2 Trainer), USAW Level 1 Weightlifting Coach, 8 years coaching
- Box founded: 2019
- Capacity: 25 athletes per class
- Tagline: "Built Strong. Forged Together."
- Tone: community-first, no-BS, results-driven, inclusive but hard-working

### Coaches (4)
1. **Coach Jake Rivera** — CF-L2, USAW L1 (owner/head coach, 8 years)
2. **Coach Priya Singh** — CF-L2, CF Gymnastics (gymnastics & skills specialist, 5 years)
3. **Coach Tyler Brooks** — CF-L1, CF Endurance (metcon & conditioning specialist, 3 years)
4. **Coach Sam Okafor** — CF-L1, Precision Nutrition L1 (strength & nutrition specialist, 4 years)

---

## Sections

1. **Header** — sticky, box name "CROSSFIT IRONCLAD", nav (WOD / Classes / Coaches / On-Ramp / Membership / FAQ), "START FREE" CTA button in Volt Yellow
2. **Hero** — full-width dark industrial, large headline "BUILT STRONG. FORGED TOGETHER." + sub, dual CTAs (Get Started Free / View Today's WOD)
3. **WOD Board** — distinctive hero section showing today's Workout of the Day breakdown:
   - Warm-Up (10 min)
   - Skill Work: Power Cleans (15 min)
   - WOD: "IRONCLAD 21-15-9" — Thrusters, Pull-Ups, Box Jumps (AMRAP/For Time)
   - Cool-Down (5 min)
   - Scaled / Rx options noted
4. **Stats band** — 4 numbers: 250+ Athletes · 5+ Years · 4 Certified Coaches · 365 Workouts/Year
5. **Class Schedule** — weekly class grid (Mon–Sat): 5:30am / 6am / 9am / noon / 5pm / 6pm WOD classes, Open Gym slots, Competitors class Sat 7am
6. **Coaches** — 4 coach cards with photo area, name, certifications, specialty, years coaching
7. **On-Ramp Program** — dedicated section explaining the Foundations/On-Ramp: 6-session intro course, scheduled 3× per week, $149 total (included in first-month membership option)
8. **Membership** — 3-tier pricing:
   - Foundations + First Month: $249 (6 On-Ramp sessions + 30-day unlimited)
   - Monthly Unlimited: $179/mo (unlimited WODs, Open Gym, Competitors class)
   - 10-Class Punch Card: $220 (valid 90 days, no commitment)
9. **Testimonials** — 5 member stories (first WOD, On-Ramp to Rx, weight loss + community, competition prep, over-50 athlete)
10. **Box Philosophy** — 3 pillars: "Constantly Varied" · "Functional Movement" · "High Intensity"
11. **FAQ accordion** — 8 questions: What is CrossFit? / Do I need to be fit to start? / What's the difference from a regular gym? / How many times per week should I train? / Are the workouts safe? / What do I wear? / Can I try before joining? / Is CrossFit for older athletes?
12. **CTA Band** — Volt Yellow background, dark text, "Try Your First Week Free" CTA
13. **Contact & Hours** — Mon–Fri 5:30am–8pm, Sat 7am–1pm, Sun Closed; RiNo Denver address, phone, email, Mindbody booking link
14. **Footer**

---

## Schema.org Types
- `SportsActivityLocation` + `HealthClub` + `LocalBusiness`
- `Person` × 4 coaches
- `Offer` × 3 membership tiers
- `FAQPage` + `Question` + `Answer`

---

## Key differentiators from all prior fitness templates

- **vs. fitness-gym-general (day 60)**: Box not gym; WOD board hero section; CrossFit certifications; volt palette vs electric orange; Anton + Saira vs Russo One + Exo 2; Denver not Austin; different membership language ("Punch Card" not "Day Pass")
- **vs. nutritionist-clinic (day 59)**: Different industry entirely; dark vs. light; fitness performance vs. clinical nutrition
- **vs. personal trainer (day 68 — not yet shipped)**: Group community box vs. 1:1 training; WOD public posting; box culture language
- **vs. yoga-studio (day 63 — not yet shipped)**: High-intensity functional fitness vs. mind-body; industrial aesthetic vs. serene
