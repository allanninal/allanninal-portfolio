/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Anton"', 'Impact', 'sans-serif'],
        body:    ['"Saira"', 'system-ui', 'sans-serif'],
      },
      colors: {
        steel: {
          50:  '#EEF2FB',
          100: '#C8D3E8',
          200: '#8896B0',
          300: '#52607A',
          400: '#2E3A52',
          500: '#1A2437',
          600: '#151D2B',
          700: '#121B2A',
          800: '#0E1520',
          900: '#080E17',
        },
        volt: {
          50:  '#F5FF99',
          100: '#EEFF55',
          200: '#E0FF00',
          300: '#C8F000',
          400: '#A6C800',
          500: '#84A000',
          600: '#637800',
          700: '#425000',
          800: '#212800',
          900: '#0E1520',
        },
      },
    },
  },
  plugins: [],
};
