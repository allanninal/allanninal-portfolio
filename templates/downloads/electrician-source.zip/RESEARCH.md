# Day 70 — Electrician: Niche Research

## Slug
`electrician`

## Sprint context
Day 70 is the SECOND template in Sprint 3 trade services (sibling of Day 69 plumber). It must use the same structural base (services grid, service-area coverage, emergency/24-7 phone CTA, licensed & insured trust badges, upfront pricing, reviews) but with a completely distinct visual register and electrician-specific content.

## Differentiation from Days 1–69

### All Sprint 3 / prior palettes taken
| Day | Template | Palette | Fonts |
|-----|----------|---------|-------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Championship Red #EF4444 + Gold | Black Ops One + Rubik |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 | EB Garamond + Quicksand |
| 64 | pilates-studio | Cool Stone #F5F4F1 + Deep Ocean Slate #2B5E7B | Prata + Fira Sans |
| 65 | dance-studio | Deep Stage Ink #0C0E18 + Rose Crimson #C4315A + Gold | Josefin Sans + Nunito Sans |
| 66 | climbing-gym | Chalk #F6F5F2 + Summit Forest #1B6E3F + Route Ochre | Barlow Condensed + DM Sans |
| 67 | martial-arts-dojo | Iron Night #090A12 + Tournament Blue #1C58E0 + Gold | Oswald + Inter |
| 68 | personal-trainer | Near-White #FAFAFA + Violet #7C3AED + Deep Purple-Black | Syne + Lexend |
| 69 | plumber | Deep Water Navy #0B2559 + Safety Orange #F97316 | Sora + Plus Jakarta Sans |

## Design decisions

### Palette: Zinc Charcoal + Deep Amber (light-default, charcoal hero)

Electrician palette is distinct from all prior 69 days. Key differences from plumber:
- **Charcoal instead of Navy**: Zinc-900 `#18181B` is a warm-neutral dark vs. plumber's cold nautical navy. Reads as "electrical panel / industrial" rather than "water/pipe."
- **Deep Amber instead of Safety Orange**: Amber-800 `#92400E` is a dark, rich amber that works as text AND button color on light backgrounds (6.87:1 contrast), unlike plumber's decorative-only orange (2.8:1).
- **Warm Stone neutrals**: Stone-50/Stone-600/Stone-900 vs. plumber's cool Slate-50/Gray family.

| Token | Value | Use | Contrast |
|-------|-------|-----|---------|
| `--color-bg` | `#FAFAF9` | Page background (Stone-50 warm white) | — |
| `--color-bg-alt` | `#FFF7ED` | Amber-50 warm tint sections | — |
| `--color-surface` | `#FFFFFF` | Card surfaces | — |
| `--color-accent` | `#92400E` | CTA buttons, links (Amber-800) | White on this: 7.17:1 AAA ✓ |
| `--color-accent-hover` | `#78350F` | Button hover (Amber-900) | White: 9.18:1 AAA ✓ |
| `--color-accent-text` | `#92400E` | Eyebrow + link text on light bg | 6.87:1 AA on #FAFAF9 ✓ |
| `--color-amber-bright` | `#F59E0B` | Decorative SVG (lightning, dots) — NOT as text on light bg | Decorative only |
| `--color-emergency` | `#B91C1C` | Emergency bar + CTA (Red-700) | White: 6.52:1 AA ✓ |
| `--color-text` | `#1C1917` | Body text (Stone-900) | 18.8:1 on #FAFAF9 AAA ✓ |
| `--color-text-muted` | `#57534E` | Secondary text (Stone-600) | 7.08:1 on #FAFAF9 AA ✓ |
| `--color-text-faint` | `#44403C` | Fine print (Stone-700) | 10.01:1 on #FAFAF9 AAA ✓ |
| `--color-dark-bg` | `#18181B` | Hero + final CTA (Zinc-900) | — |
| `--color-dark-text` | `#FAFAF9` | Text on dark bg | 18.8:1 AAA ✓ |
| `--color-dark-muted` | `#A8A29E` | Muted text on dark (Stone-400) | 6.43:1 AA ✓ |
| `--color-dark-accent` | `#F59E0B` | Amber bright on dark bg ONLY | 8.72:1 AA ✓ |

WCAG note: Amber-bright `#F59E0B` is ONLY used on the dark (#18181B) hero background (8.72:1) and in SVG decorative elements. It is never used as text color on light backgrounds — its contrast ratio against #FAFAF9 is ~2.5:1, which fails. All light-section amber text uses #92400E (Amber-800) which passes 6.87:1.

### Fonts: Archivo + IBM Plex Sans (BOTH FIRST USE in 365 library)

- **Display: Archivo** — Wide, bold, technical grotesque. Distinct from: Russo One (stencil), Anton (ultra-condensed), Oswald (classic condensed), Sora (geometric slim). Archivo's wide letterforms give it an engineering/technical authority perfect for a licensed trade.
- **Body: IBM Plex Sans** — IBM's professional technical font. Humanist-technical hybrid with strong legibility. Distinct from: Plus Jakarta Sans (geometric modern), Lexend (accessibility-first), Fira Sans (developer tool), DM Sans (minimal). IBM Plex Sans reads as "precision and reliability" — ideal for a licensed electrician's site.

### Persona: Voltage Masters Electric

- **Business:** Voltage Masters Electric
- **Location:** 2847 Commerce Dr, Nashville, TN 37214
- **Owner:** Tom Keller — Owner & Master Electrician
- **License:** TN Master Electrician License #ME-29518
- **Founded:** 2011 (14+ years experience)
- **Phone:** (615) 555-0147
- **Email:** landix.ninal@gmail.com

### Service Area (Nashville Metro)
- East Nashville: Donelson, Hermitage, Old Hickory, Inglewood, Eastwood, Opry Mills
- West Nashville: Belle Meade, Bellevue, West End, Sylvan Park, Charlotte Pike
- North Nashville: Goodlettsville, Madison, Hendersonville, White House, Greenbrier
- South Nashville: Brentwood (service calls), Franklin, Antioch, Nolensville, Berry Hill

### Sections
1. **Emergency bar** — Red (#B91C1C) full-width sticky banner: "24/7 EMERGENCY LINE — (615) 555-0147"
2. **Sticky header** — Warm white, lightning bolt logo mark, nav, CTA button
3. **Hero** — Zinc-900 charcoal bg, circuit/lightning SVG motif, large headline, dual CTAs
4. **Trust badge strip** — White bg, amber-accented: Licensed & Insured | Master Electrician | Permit-Ready | Same-Day | 5-Star
5. **Services grid** — 6 services: Panel Upgrades, EV Charger, Lighting, Wiring, Safety Inspections, Emergency Electrical
6. **Why Choose Us** — 4-column layout on dark bg: Permit-Ready | Same-Day | 24/7 | 14+ Years
7. **Service Area** — 4-zone neighborhood list with zip codes
8. **Pricing** — 3 transparent tiers: $95 service call, $175 standard, $275 emergency
9. **Reviews** — 5 Google-style reviews
10. **About Owner** — Tom Keller bio, license credentials, amber-initials avatar
11. **FAQ** — 8 questions: panel cost, EV charger capacity, Federal Pacific panels, permits, areas, warranty
12. **Contact** — Formspree form + emergency phone + address
13. **Final CTA Band** — Zinc-900 bg, "Electrical emergency? Don't wait." with phone CTA
14. **Footer** — Dark zinc, 4-column grid

### Schema.org types
- `ElectricalContractor` + `LocalBusiness`
- `Person` (owner Tom Keller)
- `Service` × 6 (each electrical service)
- `FAQPage` + 8 `Question`/`Answer` pairs
- `WebSite`

### Key differentiators from Day 69 (plumber)
- **Charcoal hero vs. navy hero**: Zinc-900 (#18181B) is warmer and more neutral than Deep Water Navy (#0B2559). Different emotional register: industrial/technical vs. nautical/trustworthy.
- **Amber accent vs. orange accent**: Deep Amber (#92400E) works as safe text/CTA color at 6.87:1; plumber's orange was decorative-only at 2.8:1 on white.
- **Archivo vs. Sora**: Wide, bold, technical vs. modern geometric slim. Completely different visual weight.
- **IBM Plex Sans vs. Plus Jakarta Sans**: Technical precision vs. clean professional. Different character spacing and weight distribution.
- **Electrician-specific services**: Panel upgrades, EV charger installs, safety inspections (Federal Pacific panel checks) — not plumbing.
- **Permit emphasis**: Electricians are the most permit-scrutinized trade. The permit-ready messaging is unique to this template.
- **Nashville metro vs. Charlotte metro**: Different city, different service area geography.
