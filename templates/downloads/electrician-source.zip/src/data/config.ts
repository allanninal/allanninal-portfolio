// Voltage Masters Electric — configuration data
// Day 70 of the 365-template roadmap

export const electrician = {
  name:        'Voltage Masters Electric',
  tagline:     "Nashville's Trusted Master Electrician — Licensed, Insured & Available 24/7",
  description: 'Licensed & insured master electrical contractor serving Nashville, TN and surrounding areas. Panel upgrades, EV charger installation, lighting, wiring, safety inspections, and 24/7 emergency service.',
  phone:       '(615) 555-0147',
  phoneHref:   'tel:+16155550147',
  email:       'hello@voltagemasterselectric.com',
  address:     '2847 Commerce Dr',
  city:        'Nashville',
  state:       'TN',
  zip:         '37214',
  license:     'TN Master Electrician License #ME-29518',
  licensed:    true,
  insured:     true,
  bonded:      true,
  founded:     2011,
  yearsExperience: 14,
  bookUrl:     '#',
  owner: {
    name:     'Tom Keller',
    title:    'Owner & Master Electrician',
    initials: 'TK',
    bio:      "I founded Voltage Masters Electric in 2011 after spending 10 years as a journeyman electrician across residential and commercial projects in Middle Tennessee. I earned my Master Electrician license because I wanted to run a company where the work is done right — not cut short, not skipped on permits, not handed off to an unlicensed sub. In 14 years we've wired hundreds of Nashville homes, upgraded more panels than I can count, and built a reputation on showing up when we say and doing exactly what we quote.",
  },
  instagram: '#',
  facebook:  '#',
  makerBio: {
    linkedin: '#',
    site:     'https://example.com',
  },
};

export const site = {
  title:         'Voltage Masters Electric — Nashville TN | Licensed Master Electrician',
  description:   "Nashville's trusted licensed & insured master electrician. Panel upgrades, EV charger installation, lighting, wiring, safety inspections, and 24/7 emergency electrical service. Upfront flat-rate pricing. Call (615) 555-0147.",
  ogImage:       '/og-image.png',
  language:      'en',
  twitterHandle: '@example',
};

export const services = [
  {
    slug:     'panel-upgrades',
    name:     'Panel Upgrades',
    icon:     'panel',
    tagline:  '100A to 200A/400A — done to code.',
    desc:     'Electrical panel replacement and upgrades for homes running out of capacity. We handle 100A to 200A and 200A to 400A upgrades, subpanel installation, and outdated fuse box replacements. All work is permit-pulled and inspection-coordinated.',
    includes: ['Permit application & coordination', 'Full panel replacement', '200A & 400A service upgrades', 'Subpanel installation', 'Final inspection coordination', 'Whole-home load assessment'],
  },
  {
    slug:     'ev-charger',
    name:     'EV Charger Installation',
    icon:     'ev',
    tagline:  'Level 2 home charging, properly wired.',
    desc:     'Dedicated 240V circuit and Level 2 EVSE installation for all major EV brands — Tesla, Ford, GM, Rivian, and more. We assess your panel capacity, pull the permit, install the outlet or hardwired unit, and schedule the inspection.',
    includes: ['Panel capacity assessment', 'Dedicated 240V circuit', 'NEMA 14-50 outlet or hardwire', 'Works with all EV brands', 'Permit & inspection included', 'Same-day install often available'],
  },
  {
    slug:     'lighting',
    name:     'Lighting Installation',
    icon:     'lighting',
    tagline:  'LED recessed, fans, outdoor, landscape.',
    desc:     'Recessed LED retrofit and new construction, ceiling fan wiring and installation, under-cabinet lighting, outdoor security lights, and landscape low-voltage systems. We spec, install, and test — no return trips for dim fixtures.',
    includes: ['LED recessed lighting retrofit', 'Ceiling fan wiring & install', 'Under-cabinet lighting', 'Outdoor & security lighting', 'Dimmer switch installation', 'Landscape lighting circuits'],
  },
  {
    slug:     'wiring',
    name:     'Electrical Wiring',
    icon:     'wiring',
    tagline:  'New circuits, remodels, additions.',
    desc:     'New circuit installation, remodel rough-in wiring, home additions, kitchen and bathroom circuit upgrades (GFCI-required areas), generator transfer switch wiring, and whole-home rewires for older homes with knob-and-tube or aluminum wiring.',
    includes: ['New circuit installation', 'Remodel rough-in wiring', 'Kitchen & bath circuit upgrades', 'GFCI/AFCI protected outlets', 'Generator transfer switch', 'Knob-and-tube replacement'],
  },
  {
    slug:     'inspections',
    name:     'Safety Inspections',
    icon:     'inspect',
    tagline:  'Pre-purchase, code compliance, peace of mind.',
    desc:     'Pre-purchase electrical inspections for home buyers, code compliance reviews for sellers, and general electrical safety assessments for older homes. We identify Federal Pacific / Zinsco panels, double-tapping, overloaded circuits, and missing GFCI/AFCI protection.',
    includes: ['Pre-purchase inspection report', 'Code compliance assessment', 'Federal Pacific panel check', 'GFCI/AFCI coverage audit', 'Written findings report', 'Priority repair recommendations'],
  },
  {
    slug:     'emergency',
    name:     'Emergency Electrical',
    icon:     'emergency',
    tagline:  '24/7 — sparking outlets, no power, breakers.',
    desc:     'Power outages, sparking or burning outlets, breakers that trip repeatedly, smell of burning plastic, flickering lights that signal a wiring fault. We dispatch within the hour — any time, any day. Don\'t ignore electrical warning signs.',
    includes: ['24/7/365 response', '1-hour dispatch', 'Sparking outlet repair', 'Breaker replacement', 'Power restoration', 'Burning smell investigation'],
  },
];

export const whyUs = [
  {
    title:   'Permit-Ready Work',
    desc:    'We pull all required permits and coordinate final inspections. Every job is done to NEC code — not just close enough. Your home\'s electrical record stays clean for future sales.',
    stat:    '100%',
    statLabel: 'Permitted Jobs',
  },
  {
    title:   'Same-Day Service',
    desc:    'Most service calls are available same day when you call before noon. We stock common parts on every truck so one visit usually finishes the job.',
    stat:    '90%',
    statLabel: 'Same-Day Fix',
  },
  {
    title:   '24/7 Emergency Line',
    desc:    'A licensed electrician answers our emergency line — not a voicemail, not a dispatcher. When your breaker sparks at midnight, you need a real answer from someone who knows what they\'re talking about.',
    stat:    '24/7',
    statLabel: 'Always Available',
  },
  {
    title:   '14+ Years in Nashville',
    desc:    "We've served Nashville families and businesses since 2011. We know the area's home ages, the common panel problems in older Donelson ranches, and the capacity demands of newer Brentwood homes.",
    stat:    '14+',
    statLabel: 'Years Serving Nashville',
  },
];

export const serviceArea = [
  {
    zone:       'East Nashville',
    neighborhoods: ['Donelson', 'Hermitage', 'Old Hickory', 'Inglewood', 'Eastwood', 'Opry Mills'],
    zips:       ['37214', '37076', '37138', '37206', '37216', '37211'],
  },
  {
    zone:       'West Nashville',
    neighborhoods: ['Belle Meade', 'Bellevue', 'West End', 'Sylvan Park', 'Charlotte Pike', 'Whites Creek'],
    zips:       ['37205', '37221', '37209', '37208', '37207', '37189'],
  },
  {
    zone:       'North Nashville',
    neighborhoods: ['Goodlettsville', 'Madison', 'Hendersonville', 'White House', 'Greenbrier', 'NoDa'],
    zips:       ['37072', '37115', '37075', '37188', '37073', '37217'],
  },
  {
    zone:       'South Nashville',
    neighborhoods: ['Brentwood (Service Calls)', 'Franklin', 'Antioch', 'Nolensville', 'Berry Hill', 'Woodbine'],
    zips:       ['37027', '37064', '37013', '37135', '37204', '37211'],
  },
];

export const pricing = [
  {
    name:     'Service Call',
    price:    '$95',
    period:   'diagnostic fee',
    desc:     'We come out, assess the problem, and give you an exact flat-rate quote before any work begins. The $95 diagnostic fee is waived when you proceed with the repair.',
    includes: [
      'On-site licensed electrician',
      'Full problem assessment',
      'Upfront repair quote',
      'No obligation to proceed',
      'Fee waived if you book the repair',
    ],
    cta:      'Schedule Diagnostic',
    featured: false,
    tag:      '',
  },
  {
    name:     'Standard Service',
    price:    'From $175',
    period:   'flat rate per job',
    desc:     'Outlet replacements, GFCI installs, switch replacements, ceiling fan wiring, breaker replacement, and most common electrical repairs. Flat-rate price quoted before we start. Parts included.',
    includes: [
      'Outlet & switch replacement',
      'GFCI/AFCI outlet install',
      'Ceiling fan wiring',
      'Breaker replacement',
      'Dimmer switch install',
      'Parts & labor included',
    ],
    cta:      'Request Service',
    featured: true,
    tag:      'Most Common',
  },
  {
    name:     'After-Hours & Emergency',
    price:    'From $275',
    period:   'emergency dispatch',
    desc:     'Emergency response for sparking outlets, repeated breaker trips, burning smell, power outages, and dangerous electrical conditions. Dispatched within the hour. After-hours pricing applies 8pm–7am and all day weekends.',
    includes: [
      '1-hour dispatch guarantee',
      '24/7/365 availability',
      'Sparking outlet repair',
      'Breaker fault diagnosis',
      'Power restoration',
      'No after-hours surprise pricing',
    ],
    cta:      'Call Emergency Line',
    featured: false,
    tag:      '',
  },
];

export const reviews = [
  {
    name:    'David M.',
    detail:  'East Nashville homeowner',
    rating:  5,
    quote:   'Tom and his team upgraded our 100A panel to 200A for the EV charger we needed. They pulled the permit, scheduled the inspection, and the inspector was in and out in 20 minutes. Flat-rate quote, no surprises. Exactly the experience you hope for.',
  },
  {
    name:    'Karen S.',
    detail:  'Property manager, 12 units in Donelson',
    rating:  5,
    quote:   "Voltage Masters has been my go-to electrician for three years across all my rental units. When a tenant calls about sparking outlets or a tripped breaker at midnight, Tom's crew actually shows up. That reliability is worth everything.",
  },
  {
    name:    'Brian & Lisa T.',
    detail:  'Hermitage homeowners',
    rating:  5,
    quote:   "We bought a 1970s ranch and needed a full electrical inspection before closing. Tom found the old Federal Pacific panel and double-tapped breakers immediately. His report gave us real leverage in negotiations. We replaced the panel with Voltage Masters before move-in.",
  },
  {
    name:    'Jason R.',
    detail:  'General contractor, Nashville',
    rating:  5,
    quote:   "I've used every electrical subcontractor in Nashville over the years. Voltage Masters is the only crew that shows up on schedule, passes inspection first try, and communicates proactively. I won't use anyone else on my jobs.",
  },
  {
    name:    'Michelle C.',
    detail:  'Belle Meade homeowner, 6 years customer',
    rating:  5,
    quote:   "Tom rewired our kitchen and added recessed lighting throughout. He was honest about what we needed versus what was nice-to-have. The LED lighting alone cut our electric bill noticeably. We've referred him to every neighbor on our street.",
  },
];

export const faqs = [
  {
    q: 'How fast can you respond to an electrical emergency?',
    a: "For genuine electrical emergencies — sparking outlets, burning smell, repeated breaker trips, complete power loss — we dispatch within the hour, 24 hours a day, 365 days a year. A licensed electrician answers the phone, not a dispatcher. We understand that electrical hazards can't wait until morning.",
  },
  {
    q: 'Do you pull permits for panel upgrades and EV charger installs?',
    a: "Yes — always. We pull all required permits for panel upgrades, new circuits, EV charger installations, and any work that Tennessee code requires a permit for. We coordinate the final inspection and make sure the work is signed off correctly. This protects you when you sell the home and keeps your insurance valid.",
  },
  {
    q: 'Are you licensed and insured?',
    a: "Tom Keller holds Tennessee Master Electrician License #ME-29518. Voltage Masters Electric carries $1M general liability insurance and workers' compensation coverage on all employees. We perform all work to National Electrical Code (NEC) standards and pull permits for all required work. You can verify our license at tn.gov.",
  },
  {
    q: 'What does a panel upgrade cost and how long does it take?',
    a: "A standard 100A to 200A panel upgrade typically runs $1,500–$2,500 depending on your home's wiring condition and meter location. The work itself takes one day. Permit and inspection are included in our quote. We'll give you an exact flat-rate price after a brief on-site assessment — no surprises.",
  },
  {
    q: 'Can you install an EV charger if my panel is already at 200A?',
    a: "Usually yes — a Level 2 EV charger needs a dedicated 240V/50A circuit, which is about 25% of a 200A panel's capacity. We'll assess your current load before committing. If your panel is already heavily loaded, we may recommend a panel upgrade or a subpanel first. We'll be honest about what your home actually needs.",
  },
  {
    q: 'What areas do you serve?',
    a: "We serve Nashville and the greater Nashville metro: East Nashville (Donelson, Hermitage, Old Hickory, Inglewood), West Nashville (Belle Meade, Bellevue, West End, Sylvan Park), North Nashville (Goodlettsville, Madison, Hendersonville, Greenbrier), and South Nashville (Antioch, Nolensville, Berry Hill, Brentwood service calls). Call us to confirm your address.",
  },
  {
    q: 'How do I know if I have a dangerous electrical panel?',
    a: "Federal Pacific Electric (FPE) Stab-Lok panels and Zinsco panels are the two most common dangerous panels found in Nashville-area homes built before 1990. Signs of trouble include breakers that don't trip when overloaded, breakers that won't reset, or a burning smell from the panel. If your panel says \"Federal Pacific\" or \"Stab-Lok,\" schedule an inspection — don't wait.",
  },
  {
    q: 'Do you offer any warranty on your electrical work?',
    a: "Yes. All labor is warranted for one year from the date of service — if the same problem recurs due to our workmanship, we return at no charge. Parts carry the manufacturer's warranty. New panels and circuit breakers typically carry a 5-10 year manufacturer warranty. We'll walk you through what's covered before we leave.",
  },
];
