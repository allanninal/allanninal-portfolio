/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Prata"', 'Georgia', 'serif'],
        body:    ['"Fira Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        stone: {
          50:  '#FAFAF8',
          100: '#F5F4F1',
          200: '#ECEAE6',
          300: '#DCDAD5',
          400: '#C6C3BB',
          500: '#A8A39A',
          600: '#7E7A72',
          700: '#5C5850',
          800: '#3A3730',
          900: '#18181F',
        },
        slate: {
          50:  '#E8F1F6',
          100: '#C8DDE8',
          200: '#97BDCE',
          300: '#6698B0',
          400: '#3F7A97',
          500: '#2B5E7B',
          600: '#1E4A63',
          700: '#153A50',
          800: '#0D2A3C',
          900: '#061A26',
        },
      },
    },
  },
  plugins: [],
};
