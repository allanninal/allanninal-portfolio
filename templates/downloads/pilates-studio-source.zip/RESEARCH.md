# Day 64 — Pilates Studio: Niche Research

## Slug
`pilates-studio`

## Visual differentiation from Days 60–63 (fitness sprint)

### Days 60–63 taken palettes
| Day | Template | Palette | Fonts |
|-----|----------|---------|-------|
| 60 | fitness-gym-general | Carbon Black #111214 + Electric Orange #EF4900 | Russo One + Exo 2 |
| 61 | crossfit-gym | Steel Night #0E1520 + Volt Yellow #C8F000 | Anton + Saira |
| 62 | boxing-gym | Ring Mat Black #1C1108 + Championship Red + Gold | Black Ops One + Rubik |
| 63 | yoga-studio | Warm Linen #F8F4EE + Dusty Sage #4A6557 + Warm Clay #A05540 | EB Garamond + Quicksand |

### Day 64 distinct visual register

**LIGHT-DEFAULT template** — second in Sprint 3 (after yoga-studio), but radically different:
- NOT the dark high-energy gym palettes (days 60–62)
- NOT yoga's warm/earthy/botanical Warm Linen + Sage + Clay
- Instead: cool, minimal, precision-focused — a **refined reformer studio aesthetic**

**Palette: Cool Stone + Deep Ocean Slate**
- Background: `#F5F4F1` (Cool Stone White — cooler/more neutral than yoga's yellowy warm linen)
- Background alt: `#ECEAE6` (Stone Alt — slightly deeper)
- Accent: `#2B5E7B` (Deep Ocean Slate — a muted teal-navy hybrid, 7.3:1 on white, AAA)
- On-accent: `#FFFFFF`
- Text: `#18181F` (Near Black — cool undertone vs. yoga's warm near-black #2C2420)
- Text muted: `#5C5B6D` (Cool Slate Gray — blue-shifted mid-tone, 6.1:1 on bg, AA)
- Border: `#DCDAD5`

**Fonts: Prata (display) + Fira Sans (body)** — FIRST USE of both in the 365 library
- Prata: a classical transitional serif with strong optical character — elegant and authoritative
- Fira Sans: a humanist sans with slight technical/engineered quality — precise and clean
- Combined feel: precision + elegance, exactly what Pilates method communicates
- Distinct from yoga (EB Garamond / Quicksand — both warmer, more meditative)

**Identity distinction:**
- Pilates is METHOD-based (Joseph Pilates' 6 principles) vs yoga's flow/meditative lineage
- Reformer equipment dominates (spring-resistance apparatus) vs yoga mats
- Clinical precision language: "posterior pelvic tilt", "neutral spine", "Powerhouse"
- PMA-CPT / STOTT / BASI credentials vs RYT/E-RYT yoga credentials
- Intro offer: "Reformer Trio" (3 private orientation sessions) vs "30 days / $30"
- Location: Capitol Hill, Seattle WA (tech/design city = clean minimalism resonates)

## Studio persona
- **Name**: Forma Pilates Studio
- **Tagline**: "Precision. Control. Strength."
- **Location**: 1847 E Pine St, Capitol Hill, Seattle WA 98112
- **Head Instructor**: Elena Vasquez, PMA-CPT / STOTT PILATES Certified

## Sections
1. Hero (warm animated background with geometric reformer motif)
2. Stats band (accent bg)
3. Classes (5 types: Reformer Fundamentals, Reformer Flow, Mat Pilates, Barre Fusion, Tower & Chair)
4. Schedule (JS-filterable weekly table, 30+ entries)
5. Instructors (4 profiles with PMA-CPT / STOTT / BASI / Polestar credentials)
6. Intro Offer (Reformer Trio — 3 sessions $99 + 4-step new-student guide)
7. Pricing (3 tiers: Drop-in $35 / 10-Pack $295 / Unlimited $215/mo)
8. Philosophy (6 Pilates Principles: Concentration, Control, Centering, Precision, Breath, Flow)
9. Testimonials (5 reviews)
10. FAQ (8 items)
11. Contact (info panel + Formspree form)
12. CTA Band

## Schema.org
SportsActivityLocation + HealthClub + LocalBusiness + Person + Service + FAQPage
