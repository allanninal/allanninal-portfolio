export const studio = {
  name:        'Forma Pilates Studio',
  tagline:     'Precision. Control. Strength.',
  description: 'Boutique reformer Pilates studio in Capitol Hill, Seattle WA — Reformer, Mat, Barre Fusion, and Tower & Chair classes for all levels. Begin with our Intro Reformer Trio.',
  phone:       '(206) 555-0174',
  email:       'hello@formapilates.com',
  address:     '1847 E Pine St',
  city:        'Seattle',
  state:       'WA',
  zip:         '98112',
  instagram:   'https://instagram.com/formapilatesseattle',
  facebook:    'https://facebook.com/formapilatesseattle',
  youtube:     'https://youtube.com/@formapilatesseattle',
  bookUrl:     'https://app.formapilates.com/book',
  joinUrl:     'https://app.formapilates.com/join',
  headInstructor: {
    name:  'Elena Vasquez',
    title: 'Founder & Lead Instructor',
    certs: ['PMA-CPT', 'STOTT PILATES Certified', 'NASM-CPT'],
  },
  makerBio: {
    name:     'Allan Ninal',
    url:      'https://allanninal.dev',
    linkedin: 'https://linkedin.com/in/allanninal',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'Forma Pilates Studio | Reformer & Mat Pilates in Seattle WA — Capitol Hill',
  description:   'Forma Pilates Studio offers Reformer, Mat, Barre Fusion, and Tower & Chair Pilates classes in Capitol Hill, Seattle WA. All levels welcome. Start with our Intro Reformer Trio — 3 sessions for $99.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
