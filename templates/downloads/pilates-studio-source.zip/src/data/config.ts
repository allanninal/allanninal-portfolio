export const studio = {
  name:        'Forma Pilates Studio',
  tagline:     'Precision. Control. Strength.',
  description: 'Boutique reformer Pilates studio in Capitol Hill, Seattle WA — Reformer, Mat, Barre Fusion, and Tower & Chair classes for all levels. Begin with our Intro Reformer Trio.',
  phone:       '(206) 555-0174',
  email:       'hello@formapilates.com',
  address:     '1847 E Pine St',
  city:        'Seattle',
  state:       'WA',
  zip:         '98112',
  instagram:   'https://instagram.com/formapilatesseattle',
  facebook:    'https://facebook.com/formapilatesseattle',
  youtube:     'https://youtube.com/@formapilatesseattle',
  bookUrl:     'https://app.formapilates.com/book',
  joinUrl:     'https://app.formapilates.com/join',
  headInstructor: {
    name:  'Elena Vasquez',
    title: 'Founder & Lead Instructor',
    certs: ['PMA-CPT', 'STOTT PILATES Certified', 'NASM-CPT'],
  },
  makerBio: {
    name:     'Forma Pilates Studio',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Forma Pilates — Reformer & Mat Pilates, Capitol Hill Seattle',
  description:   'Reformer, Mat, Barre Fusion and Tower Pilates in Capitol Hill, Seattle. All levels. Start with the Intro Reformer Trio, 3 sessions for $99.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
