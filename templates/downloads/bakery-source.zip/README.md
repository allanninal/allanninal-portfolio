# The Golden Crumb — Artisan Bakery Template (Day 37 of 365)

A warm, inviting neighborhood bakery website template built with Astro and Tailwind. Features a daily-fresh menu with tabs (Breads, Pastries, Cakes, Coffee), custom cake order form, founder story, gallery, and hours with an early-morning bakery feel.

**[Live demo](https://templates.allanninal.dev/bakery/)** | Free MIT license

## Visual design

- **Palette:** Buttercream (`#FFF8EC`) background + Strawberry-Rose (`#C0405E`) accent + Cocoa-Brown (`#3D2314`) headings + Wheat Gold (`#E8C87A`) warmth
- **Fonts:** Playfair Display (charming display serif) + Nunito (clean, friendly body) via `@fontsource`
- **Mood:** Light-only, warm, artisan-craft — distinct from coffee-shop (parchment/terracotta/Fraunces) and steakhouse (dark obsidian/brass)
- **WCAG AA verified** — all color pairs checked, axe-core clean

## Sections

1. **Hero** — bakery name, tagline "Baked fresh daily. Gone by noon.", daily stats, dual CTA
2. **Daily Fresh Menu** — 4-tab layout (Breads/Pastries/Cakes & Sweets/Coffee) with prices, tags (bestseller/vegan/GF/seasonal/sold-out), "baked fresh daily" badges
3. **Custom Cake Orders** — sizes/pricing, flavour selector, 48-hour lead time notice, inquiry form
4. **Our Story** — founder bio, stats grid, bakery interior placeholder
5. **Gallery** — 6 photo placeholders with descriptive alt text
6. **Hours & Location** — full weekly hours, map placeholder, contact info

## Schema.org

- `Bakery` (schema type) with address, phone, hours, founder
- `Menu` with 4 sections
- `Person` (template author)

## Quick start

```bash
git clone https://github.com/allanninal/templates
cd templates/bakery
npm install
npm run dev
```

## Environment variables

| Variable | Description | Default |
|---|---|---|
| `PUBLIC_SITE_URL` | Canonical site URL | `https://templates.allanninal.dev` |
| `PUBLIC_BASE_PATH` | Base path (end with `/`) | `/bakery/` |
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — enables TemplateInfo bar & analytics | _(blank)_ |
| `PUBLIC_AUTHOR_DONATE_URL` | Ko-fi / donate URL | `https://ko-fi.com/allanninal` |

## Customizing

1. Edit `src/data/config.ts` — bakery name, address, phone, hours, menu items
2. Replace photo placeholders with real images in `public/`
3. Update `public/og-image.svg` and regenerate PNG
4. Point the form `action` to Formspree, Netlify Forms, or your backend

## Tests

```bash
npm test           # Playwright smoke + a11y + template-info
npm run test:a11y  # axe-core WCAG 2.1 AA only
npm run test:links # link checker
npm run test:lighthouse  # Lighthouse CI (≥ 95 all categories)
```

---

MIT License — [Allan Ninal](https://www.linkedin.com/in/allanninal/)
