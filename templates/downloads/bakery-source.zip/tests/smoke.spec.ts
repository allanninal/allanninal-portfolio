import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/The Golden Crumb/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('hero heading contains bakery tagline', async ({ page }) => {
  await page.goto('/');
  const heading = await page.locator('#hero-heading').textContent();
  expect(heading?.toLowerCase()).toContain('baked');
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu-heading')).toBeVisible();
});

test('menu tabs exist and are interactive', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  // Click Pastries tab
  const pastriesTab = page.locator('[role="tab"]', { hasText: /pastries/i });
  await pastriesTab.click();
  expect(await pastriesTab.getAttribute('aria-selected')).toBe('true');

  const pastriesPanel = page.locator('[data-panel="pastries"]');
  await expect(pastriesPanel).toBeVisible();
});

test('order section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order')).toBeVisible();
});

test('custom cake form is present', async ({ page }) => {
  await page.goto('/');
  const form = page.locator('form[name="cake-order"]');
  await expect(form).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('hours section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hours')).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('a[href="#main-content"]');
  await expect(skipLink).toBeAttached();
});

test('navigation has accessible label', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('nav[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('footer nav has accessible label', async ({ page }) => {
  await page.goto('/');
  const footerNav = page.locator('nav[aria-label="Footer navigation"]');
  await expect(footerNav).toBeVisible();
});

test('bakery name appears in page', async ({ page }) => {
  await page.goto('/');
  const content = await page.content();
  expect(content).toContain('The Golden Crumb');
});

test('order CTA button is present in header', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('header a[href*="order"]').first();
  await expect(cta).toBeAttached();
});
