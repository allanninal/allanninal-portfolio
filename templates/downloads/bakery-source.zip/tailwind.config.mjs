/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"Nunito"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        buttercream: {
          DEFAULT: '#FFF8EC',
          50: '#FFFDF7',
          100: '#FFF4E0',
          200: '#FDECC8',
        },
        strawberry: {
          DEFAULT: '#C0405E',
          light: '#D45A74',
          dark: '#9A2F49',
          pale: '#F7D6DC',
        },
        cocoa: {
          DEFAULT: '#3D2314',
          light: '#5C3622',
          muted: '#7A5040',
        },
        wheat: {
          DEFAULT: '#E8C87A',
          light: '#F0DA9E',
          dark: '#C9A44A',
        },
      },
    },
  },
  plugins: [],
};
