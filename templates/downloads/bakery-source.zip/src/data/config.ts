export const bakery = {
  name: 'The Golden Crumb',
  tagline: 'Baked fresh daily. Gone by noon.',
  shortTagline: 'A neighborhood bakery crafting artisan breads, pastries & cakes.',
  description:
    'The Golden Crumb is a neighborhood bakery where everything is baked fresh each morning — from crusty sourdough loaves and flaky croissants to layer cakes and custom celebration orders. Warm, welcoming, and worth waking up early for.',
  address: '418 Maple Street, Portland, OR 97201',
  phone: '+1 (503) 555-0174',
  email: 'hello@thegoldencrumb.com',
  orderUrl: '#order',
  instagram: 'https://instagram.com/thegoldencrumb',
  facebook: 'https://facebook.com/thegoldencrumb',
  estYear: '2014',
};

export const hours = [
  { day: 'Monday',    open: 'Closed',          note: '' },
  { day: 'Tuesday',   open: '6:30 AM – 2:00 PM', note: '' },
  { day: 'Wednesday', open: '6:30 AM – 2:00 PM', note: '' },
  { day: 'Thursday',  open: '6:30 AM – 2:00 PM', note: '' },
  { day: 'Friday',    open: '6:30 AM – 3:00 PM', note: '' },
  { day: 'Saturday',  open: '7:00 AM – 3:00 PM', note: 'Specialty pastry drops at 8 AM' },
  { day: 'Sunday',    open: '7:00 AM – 1:00 PM', note: 'Brunch loaves available' },
];

export type MenuTag = 'vegan' | 'gluten-free' | 'seasonal' | 'bestseller' | 'sold-out';

export type MenuItem = {
  name: string;
  description: string;
  price: string;
  tags?: MenuTag[];
  note?: string;
  fresh?: boolean;
};

export type MenuCategory = {
  id: string;
  label: string;
  icon: string;
  intro?: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: 'breads',
    label: 'Breads',
    icon: '🍞',
    intro: 'Stone-milled flours. Long cold ferments. Baked in our deck oven every morning by 6 AM.',
    items: [
      {
        name: 'Country Sourdough',
        description: 'Open crumb, chewy crust, mild tang. Our signature 48-hour cold-ferment loaf using local whole wheat and hard white wheat.',
        price: '$9',
        tags: ['bestseller', 'vegan'],
        fresh: true,
      },
      {
        name: 'Seeded Rye',
        description: 'Dense, dark, earthy. Caraway, sesame, and sunflower seeds folded through 80% rye flour. Exceptional toasted with butter.',
        price: '$10',
        tags: ['vegan'],
        fresh: true,
      },
      {
        name: 'Honey Oat Loaf',
        description: 'Soft crumb, lightly sweet, oat-topped crust. Perfect for sandwiches or morning toast.',
        price: '$8',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Jalapeño Cheddar Sourdough',
        description: 'Sharp cheddar pockets and sliced jalapeños throughout our sourdough base. Weekend special — sells out early.',
        price: '$11',
        tags: ['seasonal', 'bestseller'],
        note: 'Sat & Sun only',
        fresh: true,
      },
      {
        name: 'Focaccia — Rosemary & Sea Salt',
        description: 'Light, airy, dimpled slab focaccia finished with fresh rosemary, fleur de sel, and a generous pour of olive oil.',
        price: '$7 / quarter sheet',
        tags: ['vegan', 'bestseller'],
        fresh: true,
      },
      {
        name: 'Gluten-Free Sandwich Loaf',
        description: 'Rice flour and tapioca base. Soft crumb, great structure. Made in a dedicated GF space on Tuesday and Friday mornings.',
        price: '$12',
        tags: ['gluten-free'],
        note: 'Tue & Fri only — call ahead to reserve',
      },
    ],
  },
  {
    id: 'pastries',
    label: 'Pastries',
    icon: '🥐',
    intro: 'All-butter laminated pastry. Hand-shaped. Nothing from a box, ever.',
    items: [
      {
        name: 'Butter Croissant',
        description: 'Classic French laminate — 27 layers, three-day process, shatteringly flaky. Served warm from the oven.',
        price: '$4.50',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Almond Croissant',
        description: 'Yesterday\'s croissants syrup-soaked, filled with almond frangipane, and finished with toasted sliced almonds.',
        price: '$5',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Pain au Chocolat',
        description: 'Two batons of 64% dark Valrhona chocolate enclosed in buttery laminated dough.',
        price: '$4.75',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Morning Bun',
        description: 'Laminated dough rolled in cinnamon-orange sugar, coiled, and baked in muffin tins. Crisp edge, pillowy center.',
        price: '$4.50',
        tags: ['seasonal'],
        fresh: true,
      },
      {
        name: 'Seasonal Danish',
        description: 'Cream cheese or pastry-cream base with rotating seasonal fruit. Ask at the counter for today\'s flavour.',
        price: '$5.25',
        tags: ['seasonal'],
        fresh: true,
      },
      {
        name: 'Kouign-Amann',
        description: 'Caramelised Breton pastry — buttery, crisp, with a candied sugar crust. Made in limited quantities on weekends.',
        price: '$5.50',
        tags: ['sold-out'],
        note: 'Weekend only — limited 12 per day',
      },
    ],
  },
  {
    id: 'cakes',
    label: 'Cakes & Sweets',
    icon: '🎂',
    intro: 'From daily slices to full celebration cakes. Custom orders welcome with 48-hour notice.',
    items: [
      {
        name: 'Strawberry Layer Cake (slice)',
        description: 'Vanilla chiffon layers, strawberry compote, mascarpone whipped cream, fresh strawberries. Our most requested cake.',
        price: '$7 / slice',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Lemon Olive Oil Cake (slice)',
        description: 'Moist, not-too-sweet, bright with Meyer lemon zest. Dusted with powdered sugar. Accidentally vegan.',
        price: '$6 / slice',
        tags: ['vegan'],
        fresh: true,
      },
      {
        name: 'Brown Butter Blondie',
        description: 'Chewy, fudgy centre, crisp top, toasted walnuts and dark chocolate chips throughout.',
        price: '$3.50',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Cardamom Snickerdoodle',
        description: 'Soft, pillowy, rolled in cinnamon-cardamom sugar. A hint of Scandinavian warmth.',
        price: '$2.75',
        tags: ['bestseller'],
        fresh: true,
      },
      {
        name: 'Seasonal Tart',
        description: 'Buttery pâte sucrée shell with pastry cream and rotating seasonal topping. Ask the counter for today\'s.',
        price: '$7.50',
        tags: ['seasonal'],
        fresh: true,
      },
      {
        name: 'Custom Celebration Cake',
        description: 'Whole cakes for birthdays, weddings, and events. Choose your flavour, size, and design. 48-hour notice required.',
        price: 'from $65',
        note: 'Order via form or call us',
      },
    ],
  },
  {
    id: 'drinks',
    label: 'Coffee & Drinks',
    icon: '☕',
    intro: 'Single-origin drip and espresso from our friends at Stumptown. Simple drinks done right.',
    items: [
      {
        name: 'Drip Coffee',
        description: 'Single-origin, house-roasted blend. Changed daily. We keep it strong and honest.',
        price: '$3 / $3.75',
        tags: ['vegan', 'bestseller'],
        note: '12 oz / 16 oz',
      },
      {
        name: 'Espresso',
        description: 'Double shot of our house espresso blend. Bright acidity, stone fruit finish.',
        price: '$3.50',
        tags: ['vegan'],
      },
      {
        name: 'Latte',
        description: 'Double espresso, steamed whole milk, light microfoam. Oat, almond, or soy available.',
        price: '$5.25',
      },
      {
        name: 'Cortado',
        description: 'Equal parts espresso and warm milk. The bakery staff\'s drink of choice.',
        price: '$4.25',
        tags: ['bestseller'],
      },
      {
        name: 'Matcha Latte',
        description: 'Ceremonial-grade matcha whisked with steamed oat milk. Earthy, slightly sweet.',
        price: '$5.50',
        tags: ['vegan'],
      },
      {
        name: 'Fresh-Squeezed OJ',
        description: 'Valencia oranges, squeezed to order each morning. Classic.',
        price: '$4',
        tags: ['vegan', 'gluten-free'],
        fresh: true,
      },
    ],
  },
];

export const cakeOrder = {
  headline: 'Custom Celebration Cakes',
  description:
    'Planning a birthday, wedding, shower, or office event? We craft custom layer cakes, sheet cakes, and pastry platters to order. All custom cakes are made with the same quality ingredients as our daily bakes — no artificial flavors, no shortening, no shortcuts.',
  flavours: [
    'Vanilla Bean', 'Lemon Mascarpone', 'Chocolate Fudge', 'Carrot Spice',
    'Strawberry & Cream', 'Earl Grey Honey', 'Funfetti', 'Brown Butter Hazelnut',
  ],
  sizes: [
    { label: '6-inch (serves 8–10)', price: 'from $65' },
    { label: '8-inch (serves 16–20)', price: 'from $95' },
    { label: '10-inch (serves 24–30)', price: 'from $135' },
    { label: 'Sheet cake (serves 24–30)', price: 'from $110' },
    { label: 'Pastry platter (20 pieces)', price: 'from $85' },
  ],
  leadTime: '48 hours minimum notice. Weekend orders by Thursday noon.',
  contactNote: 'Call us at (503) 555-0174 or fill out the form below. We\'ll confirm within 2 hours.',
};

export const story = {
  headline: 'Baked with intention since 2014.',
  body: [
    'The Golden Crumb started in Mei Chen\'s home kitchen — a 20-quart mixer, a temperamental oven, and a farmers\' market stall that sold out every Saturday by 9 AM. Neighbors kept asking where they could buy the bread during the week. The answer, in 2014, was: Maple Street.',
    'We still use the same sourdough starter Mei fed on day one. It lives in the walk-in, gets fed every morning at 4:30, and has shaped tens of thousands of loaves. That\'s the thing about fermentation: patience compounds. You can\'t rush it. The bread knows.',
    'Everything here is baked on-site, every single morning, before the doors open. When we sell out — and we do, most days — we close early rather than compromise on anything that came out earlier in the day. Fresh means fresh.',
  ],
  stats: [
    { label: 'Founded',         value: '2014' },
    { label: 'Starter Age',     value: '10+ years' },
    { label: 'Loaves / Week',   value: '~400' },
    { label: 'Regulars',        value: 'Countless' },
  ],
};

export const galleryItems = [
  { alt: 'A rustic sourdough country loaf with scored wheat pattern, golden crust, on a wooden board', label: 'Country Sourdough', src: 'sourdough' },
  { alt: 'Fresh butter croissants stacked on a white marble slab, shatteringly flaky', label: 'Butter Croissants', src: 'croissants' },
  { alt: 'Strawberry layer cake with mascarpone cream and fresh berries on a cake stand', label: 'Strawberry Layer Cake', src: 'cake' },
  { alt: 'Morning pastry case with croissants, Danishes, and morning buns in warm light', label: 'Pastry Case', src: 'pastry-case' },
  { alt: 'Rows of focaccia with rosemary and sea salt, golden on a sheet pan', label: 'Rosemary Focaccia', src: 'focaccia' },
  { alt: 'Interior of The Golden Crumb bakery — warm wood tones, chalkboard menu, morning light through the window', label: 'The Bakery', src: 'interior' },
];

export const maker = {
  name: 'The Golden Crumb',
  linkedin: '#',
  twitter: '#',
  github: '#',
  email: 'hello@thegoldencrumb.com',
  kofi: '#',
};

export const site = {
  title: 'The Golden Crumb — Artisan Bakery, Portland OR',
  description:
    'The Golden Crumb is a neighborhood artisan bakery in Portland, OR. Fresh-baked sourdough, pastries, cakes, and specialty coffee every morning. Custom celebration cakes by order.',
  url: 'https://example.com/',
  ogImage: '/og-image.png',
  language: 'en',
};
