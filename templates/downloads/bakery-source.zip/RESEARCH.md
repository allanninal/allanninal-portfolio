# Research Brief — Bakery (Day 37)

## Visual differentiation from prior food templates

| Template | Palette | Fonts | Mood |
|---|---|---|---|
| D22 restaurant-general | Dark olive-charcoal + gold | Libre Baskerville + Mulish | Dark bistro |
| D23 coffee-shop | Parchment + terracotta-rust | Fraunces + Plus Jakarta Sans | Light indie cafe |
| D32 pizzeria | Tomato-red + basil-green + cream | Italiana + Lato | Italian trattoria |
| D33 sushi-bar | Washi off-white + sumi-ink + deep indigo | Cormorant Garamond + Noto Sans JP | Minimalist Japanese |
| D34 mexican-restaurant | Talavera-teal + terracotta + marigold | Abril Fatface + Nunito | Vibrant Oaxacan |
| D35 vegan-restaurant | Moss + cream + clay | Lora + Lato | Earthy botanical |
| D36 steakhouse | Obsidian + oxblood + brass | DM Serif Display + Karla | Dark premium |
| **D37 bakery** | **Buttercream + strawberry-rose + cocoa** | **Playfair Display + Nunito** | **Warm artisan** |

## Palette rationale

- **Buttercream `#FFF8EC`** — warm off-white, evokes freshly baked goods, flour-dusted counters
- **Strawberry-Rose `#C0405E`** — a berry-red that signals freshness without competing with coffee-shop's terracotta
- **Cocoa-Brown `#3D2314`** — deep warm brown for headings and dark sections (distinct from steakhouse's obsidian `#0F0D0B`)
- **Wheat Gold `#E8C87A`** — secondary warm accent for the dark cocoa sections; echoes crust colour

## Font pairing rationale

- **Playfair Display** (display) — charming editorial serif, used widely for bakery/food editorial. NOT yet used in series (D17 used Playfair on writer-author-site but that's distant enough in food context, and D37 pairs it with Nunito — a completely different body).
- **Nunito** — round, friendly, approachable sans-serif. Pairs with the bakery's informal neighborhood feel. Not used in any prior food template.

## Persona

Mei Chen, owner of "The Golden Crumb" (Portland, OR, est. 2014). A neighborhood artisan bakery grown from a farmers market stall. 10-year-old sourdough starter. Stone-milled flour. Opens at 6:30 AM, closes when sold out.

## Key differentiators vs coffee-shop

1. Light mode but **buttercream** not parchment (warmer, less paper-toned)
2. **Strawberry-rose** accent (not terracotta-rust)
3. **Playfair Display** not Fraunces (different weight/personality)
4. **Menu is daily-fresh-led** with sold-out mechanics — not a coffee origins / subscription angle
5. **Custom cake order form** — a functional B2B/events section that coffee-shop lacks

## Sections

1. Hero — dark cocoa bg, wheat gold stats, dual CTA
2. Daily Fresh Menu — 4-tab (Breads/Pastries/Cakes/Coffee), sold-out/fresh/vegan/GF tags
3. Custom Cake Order — sizes, flavours, inquiry form (Square/Formspree placeholder)
4. Our Story — founder, 10+ year starter, stats
5. Gallery — 6 photo placeholders
6. Hours & Location — early-morning hours, map placeholder

## Schema.org

`schema.org/Bakery` + `schema.org/Menu` + `schema.org/Person`
