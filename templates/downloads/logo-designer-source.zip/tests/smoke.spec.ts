import { test, expect } from '@playwright/test';

const int = (s: string) => Number((s.match(/\d+/) || ['0'])[0]);

test.describe('Tobias Renner — smoke tests', () => {
  test('homepage renders with the designer in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Tobias Renner/);
    await expect(page.locator('h1')).toContainText(/register isn’t finished/);
  });

  // The single most important assertion on this template.
  test('the disclaimer is on the page and in the markup, word for word', async ({ page }) => {
    await page.goto('/');
    const notice = (await page.locator('.notice p').last().textContent()) || '';
    expect(notice).toMatch(/not an attorney/i);
    expect(notice).toMatch(/not a clearance opinion/i);
    expect(notice).toMatch(/not legal advice/i);
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('ProfessionalService'))!);
    const s = JSON.parse(raw);
    expect(s.disclaimer).toBe(notice.trim());
    // And the FAQ says it a second time.
    await expect(page.locator('#faq')).toContainText(/Is this legal advice/);
  });

  test('is a ProfessionalService, and quotes nobody else’s fees as its own', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const s = JSON.parse(blocks.find((b) => b.includes('ProfessionalService'))!);
    expect(s['@type']).toBe('ProfessionalService');
    expect(s.serviceOutput.length).toBe(2);
    const all = blocks.join('');
    expect(all).not.toContain('hasOfferCatalog');
    expect(all).not.toContain('priceSpecification');
    expect(all).not.toContain('350');
    expect(all).not.toContain('aggregateRating');
    // Not the previous days' types.
    expect(all).not.toContain('creativeWorkStatus');
    expect(all).not.toContain('accessibilityFeature');
  });

  // ── The funnel ──────────────────────────────────────────────────────────
  test('the funnel narrows monotonically and the headline is computed from it', async ({ page }) => {
    await page.goto('/');
    const n = (await page.locator('#funnel .n').allTextContents()).map(int);
    expect(n.length).toBe(5);
    for (let i = 1; i < n.length; i++) expect(n[i]).toBeLessThan(n[i - 1]);
    expect(n[n.length - 1]).toBe(1);
    const h2 = (await page.locator('#funnel h2').textContent()) || '';
    expect(h2).toContain(`${n[0]} concepts`);
    // "N of the last M were already taken" must be the real difference.
    expect(h2).toContain(`${n[2] - n[3]} of the last ${n[2]}`);
  });

  // ── Killed at search ────────────────────────────────────────────────────
  test('four kill cards, and only one of them is a registration', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#killed article.kill');
    expect(await cards.count()).toBe(4);
    for (const c of await cards.all()) {
      expect(((await c.locator('.hit').textContent()) || '').length).toBeGreaterThan(80);
      expect(((await c.locator('.when').textContent()) || '')).toMatch(/Found:/);
      expect(((await c.locator('.cost').textContent()) || '').length).toBeGreaterThan(30);
    }
    const text = (await page.locator('#killed').textContent()) || '';
    expect(text).toMatch(/common-law|no registration at all/i);
    expect(text).toMatch(/licen[cs]ed for print and web but not for logo use/i);
    await expect(page.locator('#killed h2')).toContainText('one of these was a trademark problem');
  });

  // ── The spectrum ────────────────────────────────────────────────────────
  test('the distinctiveness spectrum is five steps, weakest first, with no bar', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#spectrum ol.spectrum li');
    expect(await items.count()).toBe(5);
    const names = await page.locator('#spectrum .k').allTextContents();
    expect(names.map((s) => s.trim())).toEqual(
      ['Generic', 'Descriptive', 'Suggestive', 'Arbitrary', 'Fanciful']);
    // Strength is printed as a word rather than drawn as a proportional bar.
    for (const s of await page.locator('#spectrum .s').allTextContents()) {
      expect(s.trim().length).toBeGreaterThan(3);
    }
    const widths = await page.locator('#spectrum .s').evaluateAll((els) =>
      [...new Set(els.map((e) => (e as HTMLElement).style.width))]);
    expect(widths).toEqual(['']);
  });

  // ── Classes ─────────────────────────────────────────────────────────────
  test('classes print a word, and one is deliberately not filed', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#classes .verdict');
    expect(await v.count()).toBeGreaterThan(5);
    for (const el of await v.all()) {
      expect(((await el.textContent()) || '').trim()).toMatch(/^(Filed|Not yet|No)$/);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    const words = await v.allTextContents();
    const filed = words.filter((w) => /^Filed$/i.test(w.trim())).length;
    expect(words.some((w) => /Not yet/i.test(w))).toBe(true);
    expect(words.some((w) => /^No$/i.test(w.trim()))).toBe(true);
    await expect(page.locator('#classes .eyebrow')).toContainText(`${filed} classes filed`);
    // Class 35 is on the page and explained, because it is the one people miss.
    await expect(page.locator('#classes')).toContainText('35');
    await expect(page.locator('#classes')).toContainText(/retail service/i);
  });

  // ── Cost ────────────────────────────────────────────────────────────────
  test('the cost table separates what is mine from what is not', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#cost tbody tr');
    expect(await rows.count()).toBe(6);
    const text = (await page.locator('#cost').textContent()) || '';
    expect(text).toMatch(/Included/);
    expect(text).toMatch(/Not me/);
    expect(text).toMatch(/6–9 months/);
    expect(text).toMatch(/Approximate/i);
  });

  test('the FAQ is an accordion and the form asks what is actually sold', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    for (const id of ['#name', '#email', '#mark', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#contact select').count()).toBe(1);
  });

  test('the footer navigation is back', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer nav').count()).toBe(1);
    expect(await page.locator('nav').count()).toBe(3);
  });

  test('no trace of the day-123 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['marit halvorsen', 'portland', 'kestrel', 'clear space', 'eighteen months']) {
      expect(html).not.toContain(noun);
    }
    expect(await page.locator('figure').count()).toBe(0);
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro search method is absent from the free build', async ({ page }) => {
    const res = await page.goto('/search-method/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
