// Tobias Renner — Milwaukee, WI. Fictional, and so is every client and every
// colliding mark below.
//
// The organising idea: a mark you cannot register is not finished. Every logo
// site is a grid of marks and a price; none of them mention the half of the job
// that decides whether the mark survives contact with somebody else's
// registration.
//
// Nothing here is legal advice and the page says so twice. A knockout search is
// a designer's job; a clearance opinion is an attorney's.

export const site = {
  name:        'Tobias Renner',
  shortName:   'Tobias Renner',
  title:       'Tobias Renner — logo design and knockout searching, Milwaukee',
  tagline:     'A mark you can’t register isn’t finished.',
  owner:       'Tobias Renner',
  ownerRole:   'Logo designer',
  credential:  'Fourteen years · marks for operators · searches before sketches',
  city:        'Milwaukee',
  state:       'WI',
  language:    'en',
  phoneDisplay: '(414) 555-0166',
  phoneHref:   '+14145550166',
  email:       'tobias@rennermarks.example',
  streetAddress: '318 N Milwaukee St',
  postalCode:  '53202',
  hours:       'Searches start the week you book · marks take five weeks',
  bookingWindow: 'Two projects at a time · a knockout search can start inside a week',
  description:
    'Every logo site is a grid of marks and a price list. This one publishes the other half: a ' +
    'funnel from 34 concepts to one filed mark, the four that died at search and what killed ' +
    'them, the spectrum that decides whether a name is ownable at all, and what registration ' +
    'actually costs. I am not a lawyer, and this page says so twice.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The funnel',      href: '#funnel' },
  { label: 'Killed at search', href: '#killed' },
  { label: 'What it costs',   href: '#cost' },
  { label: 'Start a mark',    href: '#contact' },
];

export const disclaimer =
  'I am a designer, not an attorney. What I do is a knockout search — federal register, state ' +
  'registers, common-law use and domains — which finds the obvious collisions early and cheaply. ' +
  'It is not a clearance opinion and it is not legal advice. A clearance opinion comes from a ' +
  'trademark attorney, it costs money, and it is on the fee table below because it belongs there.';

// ── The funnel ────────────────────────────────────────────────────────────
// One real project, from concepts to a filed mark. Every stage says what
// removed the difference, and the search stage removes more than taste does.

export const project = {
  client: 'Ferrous & Bloom',
  what: 'A three-shop hardware and garden supply operator in Waukesha County',
  when: 'February to June 2026',
};

export const funnel = [
  { n: 34, k: 'Concepts on paper',    d: 'Two weeks of drawing, mostly bad on purpose. Nothing is searched at this stage because searching 34 things is a way of spending a week finding out that 34 things are taken.' },
  { n: 12, k: 'Worth drawing properly', d: 'The cut is mine and it is taste. This is the only stage on this list where taste decides anything, which surprises people.' },
  { n: 7,  k: 'Distinctive enough to be worth searching', d: 'Three were descriptive — a leaf and a bolt for a garden and hardware shop — and a descriptive mark is hard to own even when nobody else has it. Two were near-identical to each other.' },
  { n: 3,  k: 'Survived a knockout search', d: 'Half a day each. Federal register, two state registers, common-law use, domains, and a plain image search. Four died here and they are on the page below.' },
  { n: 1,  k: 'Chosen, refined and filed', d: 'The client picked from three that were all defensible, which is the entire reason the search happens before the presentation rather than after it.' },
];

export const funnelNote =
  'The interesting number is not 34 and it is not 1. It is that four of the seven marks worth ' +
  'searching were already taken, in the right class, by businesses that did the same thing. That ' +
  'is normal. A designer who presents three unsearched concepts is presenting a coin flip and ' +
  'charging for it.';

// ── Killed at search ──────────────────────────────────────────────────────

export const killed = [
  {
    k: 'The anvil monogram',
    was: 'An F and a B locked into an anvil silhouette. The best drawing of the set and the one I wanted.',
    hit: 'A live federal registration in class 35 held since 2011 by a hardware retailer in Ohio. Not a similar mark — the same idea, executed almost identically, by somebody doing the same job.',
    when: 'Day one of searching',
    cost: 'Three days of drawing. Cheap, because it died before the client had ever seen it.',
  },
  {
    k: 'The seed-and-screw',
    was: 'A seed head that reads as a screw thread at small sizes. Clever, and it survived the distinctiveness cut easily.',
    hit: 'Nothing on the federal register — and a Wisconsin garden centre trading under a near-identical mark since 2004 with no registration at all. Common-law rights, in the same state, in the same trade.',
    when: 'Day one, on the third page of an image search',
    cost: 'Nothing, and it is the one that would have been expensive. An unregistered mark in active local use does not show up on the federal register and it can still stop you.',
  },
  {
    k: 'The two-tone “FB” block',
    was: 'A tight geometric lockup. The client’s favourite in an early informal look.',
    hit: 'Not a trademark problem. A search turned up an unrelated organisation using the same two letters in the same arrangement, and the association was one nobody wanted on a shop sign.',
    when: 'Day two',
    cost: 'One awkward conversation. Worth having in week three rather than after the vinyl was cut.',
  },
  {
    k: 'The wordmark alone, set in a serif',
    was: 'Just the name, well spaced. Often the right answer and it was not this time.',
    hit: 'The name itself is fine. The specific typeface was licensed for print and web but not for logo use, which is a licence term about half of all display faces carry and almost nobody reads.',
    when: 'Day two, in the EULA',
    cost: 'A $220 extended licence, paid, and the mark was redrawn anyway so the letterforms are no longer the font.',
  },
];

// ── Distinctiveness ───────────────────────────────────────────────────────
// The one piece of trademark law every designer should be able to name.

export const spectrum = [
  { k: 'Generic', s: 'Unownable', d: '“Hardware Store” for a hardware store. Nobody can register it and nobody should be able to, because the word is the thing.' },
  { k: 'Descriptive', s: 'Nearly unownable', d: '“Fast Bolt” for fasteners. Registrable only after years of use and evidence that people already associate it with you. Most first-time clients arrive wanting one of these.' },
  { k: 'Suggestive', s: 'Ownable', d: '“Ferrous & Bloom” — it hints at metal and gardens without describing either. The commercially useful sweet spot and the hardest one to sell to a client who wants to be understood instantly.' },
  { k: 'Arbitrary', s: 'Strong', d: 'A real word with no relationship to the trade. Apple for computers. Strong protection, and it needs marketing money to mean anything.' },
  { k: 'Fanciful', s: 'Strongest', d: 'An invented word. Kodak. The strongest possible protection and the most expensive to make familiar, which is why it suits companies with budgets and not shops with three locations.' },
];

export const spectrumNote =
  'This is a naming conversation and it belongs in week one, not in an attorney’s letter in ' +
  'month five. A client who has already printed a descriptive name on three vans has made a ' +
  'trademark decision without knowing it, and the mark cannot fix it.';

// ── Classes ───────────────────────────────────────────────────────────────

export const classes = [
  { n: '06', k: 'Metal hardware',        need: 'Yes',   n2: 'Fasteners, hand tools, the actual goods. The obvious one and rarely the one that matters most.' },
  { n: '08', k: 'Hand tools',            need: 'Yes',   n2: 'Overlaps 06 in practice. Filed because the shops sell both and the fee per class is small next to the cost of being wrong.' },
  { n: '31', k: 'Plants and seeds',      need: 'Yes',   n2: 'The garden half of the business. Left out of the first draft of the filing and it is the class the Ohio collision sat in.' },
  { n: '35', k: 'Retail services',       need: 'Yes',   n2: 'The one everybody forgets and the one most disputes are actually about. If you sell other people’s goods, this is the class your mark lives in.' },
  { n: '44', k: 'Landscaping services',  need: 'Later', n2: 'Not filed. The business does not offer it yet, and filing for goods you do not sell is a way of getting a registration cancelled.' },
  { n: '25', k: 'Clothing',              need: 'No',    n2: 'Merchandise T-shirts are not a clothing business. Filed by a surprising number of small operators on a designer’s advice, at $350 a class, for nothing.' },
];

export const classNote =
  'A mark is owned in the classes it is registered in and nowhere else. Class 35 is the one that ' +
  'catches people: a shop that sells other companies’ products is providing a retail service, ' +
  'and that is where a competitor’s sign actually collides with yours.';

// ── Cost and time ─────────────────────────────────────────────────────────

export const costs = [
  { k: 'Knockout search',            v: 'Included',    t: 'Half a day per mark', n: 'Mine, on every project, before anything is presented. It is not a clearance opinion.' },
  { k: 'Attorney clearance opinion', v: '$600–1,500',  t: '1–2 weeks',           n: 'Not me. Worth it any time the mark is going on a building or the business is raising money.' },
  { k: 'USPTO filing, per class',    v: '~$350',       t: 'Filed same week',      n: 'Approximate, TEAS Standard, per class. Four classes is four fees and the arithmetic surprises everybody once.' },
  { k: 'Examination',                v: '—',           t: '6–9 months',          n: 'You wait. Nothing about this is fast, which is why filing happens before the signage order rather than after.' },
  { k: 'Office action response',     v: '$300–900',    t: 'Adds 2–5 months',     n: 'Roughly half of applications get one. It is normal, it is not a rejection, and a designer who has not warned you about it has not been through it.' },
  { k: 'Opposition window',          v: '—',           t: '30 days after publication', n: 'Anybody can object. Usually nobody does. It is the last point at which a collision costs a rebrand rather than a letter.' },
];

export const costNote =
  'Five weeks of design and roughly nine months of waiting. The design fee is the small number ' +
  'on this page and it is the only one anybody asks about before starting.';

// ── Rounds ────────────────────────────────────────────────────────────────

export const rounds = [
  { k: 'Week 1 — the naming conversation', n: 'Where the name sits on the distinctiveness spectrum, and what that costs. Half the projects change something in this week and it is always cheaper than changing it later.' },
  { k: 'Week 2 — 34 concepts, unsearched', n: 'Deliberately unsearched. Searching everything is how two weeks disappear into confirming that everything is taken.' },
  { k: 'Week 3 — searching seven',         n: 'Half a day each. Federal, two states, common-law, domains, image search, and the typeface licence.' },
  { k: 'Week 4 — presenting three',        n: 'Three marks that are all defensible. Not three so the client feels consulted — three because that is how many survived.' },
  { k: 'Week 5 — refinement and files',    n: 'One-colour, small sizes, the K-alone version if there is one. Files named for where they go.' },
  { k: 'Then — filing, and waiting',       n: 'Application in the same week. Then six to nine months in which nothing happens and the shop opens anyway, under a mark that is at least searched.' },
];

export const said = {
  text: 'Three of the marks we liked were already taken by hardware shops doing exactly what we do, and we found that out in week three instead of after the signs went up. The one we chose is not my favourite drawing and it is the one we still own.',
  who: 'Owner, Ferrous & Bloom — 2026',
};

export const faqs = [
  {
    q: 'Is this legal advice?',
    a: 'No, and it is worth saying twice on one page. I am a designer. A knockout search finds obvious collisions early and cheaply, and it is not a clearance opinion — that comes from a trademark attorney and it is on the fee table above because it belongs there. Everything on this page is the designer’s side of that line.',
  },
  {
    q: 'Why search before presenting?',
    a: 'Because a presentation of unsearched concepts is a coin flip that the client pays for. Four of the seven marks worth searching on the last project were taken, in the right class, by businesses doing the same thing. Presenting those would have meant either withdrawing a favourite or shipping a collision.',
  },
  {
    q: 'Can I just not register it?',
    a: 'You can, and common-law rights are real in the territory where you actually trade. What you give up is the ability to stop somebody else registering it nationally and then telling you to stop. One of the marks on this page died to an unregistered garden centre in the same state, which is the same rule working in the other direction.',
  },
  {
    q: 'How many classes do I need?',
    a: 'As many as you actually trade in, and class 35 more often than people expect — if you sell other companies’ goods, that is a retail service and it is where a competitor’s sign collides with yours. Filing for classes you do not trade in is a way of getting a registration cancelled later.',
  },
  {
    q: 'Why does the typeface matter?',
    a: 'About half of all display typefaces are licensed for print and web but not for logo use, and that term is in a EULA nobody reads. One mark on this page needed a $220 extended licence. In practice a wordmark gets redrawn anyway, at which point the letterforms are no longer the font and the question goes away.',
  },
  {
    q: 'What if the search finds nothing?',
    a: 'Then you have a mark with no obvious collision, which is worth a great deal and is still not a guarantee. The register is searchable; common-law use in a town you have never heard of is not, entirely. That residual risk is exactly what an attorney’s opinion is for and it is why I do not pretend a search is one.',
  },
];
