// Sula Brant — Detroit, MI.
//
// Every DJ page has a booking email and an embedded mix. What a promoter
// actually needs — and almost never gets until the week of the show — is the
// technical list, with a failure mode per line. So the rider here is written
// for the promoter rather than at them.

export const site = {
  name:        'Sula Brant',
  shortName:   'Sula Brant',
  title:       'Sula Brant — DJ, Detroit',
  tagline:     'The rider is for you, not at you.',
  owner:       'Sula Brant',
  ownerRole:   'DJ · house and techno',
  credential:  'Playing since 2014 · Detroit and touring',
  city:        'Detroit',
  state:       'MI',
  language:    'en',
  phoneDisplay: '(313) 555-0192',
  phoneHref:   '+13135550192',
  email:       'bookings@sulabrant.example',
  streetAddress: '2934 Russell St',
  postalCode:  '48207',
  hours:       'Bookings answered within two days · Fridays and Saturdays gone first',
  bookingWindow: 'Taking dates from eight weeks out',
  description:
    'A DJ in Detroit. Most nights that go wrong go wrong on the technical list, not on the ' +
    'music — so this page publishes the whole rider with what happens when each line is missing, ' +
    'three click tracks so “something upbeat” can become a number, and what a night actually costs.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The rider',  href: '#rider' },
  { label: 'Tempo',      href: '#tempo' },
  { label: 'Sets',       href: '#sets' },
  { label: 'What a night costs', href: '#cost' },
  { label: 'Book',       href: '#book' },
];

// ── The rider ─────────────────────────────────────────────────────────────
// `need` is 'must' or 'nice'. Only four of eleven are musts, which is the
// point: a rider that is all musts teaches a promoter nothing.

export const rider = [
  { item: 'Two players, same model',   need: 'must',
    what: 'Any current club standard. Same model on both, not one of each.',
    without: 'Mismatched players means every transition is done by feel with different controls under each hand. It is doable and it is not what you booked.' },
  { item: 'Players linked',            need: 'must',
    what: 'A network cable between the units, or a switch.',
    without: 'No shared beat grid and no waveform on the incoming track. Adds about a second of guesswork to every mix, all night.' },
  { item: 'A booth monitor that works', need: 'must',
    what: 'One speaker aimed at the booth, on its own level control.',
    without: 'Beatmatching to a room delay. This is the single most common cause of a set that sounds loose on the floor and fine to the person playing it.' },
  { item: 'A working mixer channel per player', need: 'must',
    what: 'Tested before doors, not at changeover.',
    without: 'A dead channel discovered at 1am costs the first ten minutes of a set and all of its momentum.' },
  { item: 'Set times in writing',      need: 'nice',
    what: 'Who is on before and after, and the actual close.',
    without: 'A warm-up plays peak-time, or a closer gets cut at 1:40. Both happen weekly and both are a text message to avoid.' },
  { item: 'A booth light',             need: 'nice',
    what: 'Any dim light, gooseneck or otherwise.',
    without: 'Phone torch on the mixer. It works, and it looks exactly as good as it sounds.' },
  { item: 'Water in the booth',        need: 'nice',
    what: 'Two bottles.',
    without: 'Nothing catastrophic. It is on this list because it is the cheapest possible signal that somebody thought about the night.' },
  { item: 'A named person on the night', need: 'nice',
    what: 'One phone number that will be answered after 11pm.',
    without: 'Any of the problems above take forty minutes to solve instead of five, because nobody knows who has the key to the cupboard.' },
  { item: 'Load-in details',           need: 'nice',
    what: 'Door, parking, and whether there are stairs.',
    without: 'A record bag carried the long way round a building at midnight. Minor, avoidable, and it sets the tone.' },
  { item: 'Confirmation that the sound is signed off', need: 'nice',
    what: 'That somebody has run the system that week.',
    without: 'A limiter set for a live band, discovered during the first record.' },
  { item: 'The deposit, before the date', need: 'nice',
    what: 'Half the fee, on booking.',
    without: 'Nothing on the night. Everything afterwards — this is the line that decides whether chasing an invoice takes a week or five months.' },
];

export const NEED = {
  must: { label: 'Required', glyph: '!' },
  nice: { label: 'Asked for', glyph: '·' },
} as const;

export const riderNote =
  'Four of eleven are required and the rest are asked for, which is the difference between a ' +
  'rider and a list of demands. A rider where everything is a must teaches a promoter nothing ' +
  'about what actually matters, so when something has to give they guess — and they guess wrong, ' +
  'because nobody told them the booth monitor was load-bearing and the water was not.';

// ── Tempo ─────────────────────────────────────────────────────────────────
// Generated click tracks, not recordings. A metronome is a metronome.

export const tempo = {
  intro:
    '"Something upbeat" is not a tempo and neither is "house". These are three click tracks, ' +
    'generated rather than recorded, so a booking conversation can be about a number. Press play ' +
    'on the one that sounds like your room at midnight.',
  bands: [
    { bpm: 118, file: 'click-118.mp3', label: 'Warm-up, early rooms, bars',
      body: 'What the first two hours of most nights should be, and what almost every warm-up plays too fast. If you have booked an opener and the floor is empty at midnight, this is usually why.' },
    { bpm: 126, file: 'click-126.mp3', label: 'House, peak time',
      body: 'Where most of my sets live. Broad enough to cover disco-leaning and stripped-back in the same hour without the room noticing a gear change.' },
    { bpm: 138, file: 'click-138.mp3', label: 'Techno, late',
      body: 'After 1am, in a room that has already committed. Booking this for a 10pm slot is the other half of the warm-up problem.' },
  ],
  note:
    'None of these is a mix and none of them is trying to be. They are metronomes, which is why ' +
    'they are on a page that otherwise has no audio: the sets on this site are fictional, and a ' +
    'fabricated mix would be inventing a product where a click track is just a click track.',
};

// ── Sets ──────────────────────────────────────────────────────────────────

export const sets = [
  { venue: 'Bramble Hall',      city: 'Detroit, MI',   when: 'Jun 2026', len: '3 h', room: 'Peak time, 400 capacity, no booth monitor for the first twenty minutes. See the rider.' },
  { venue: 'Corktown Social',   city: 'Detroit, MI',   when: 'May 2026', len: '4 h', room: 'Open to close, small bar, 118 to 124 the whole way. The most fun kind of night and the hardest to record.' },
  { venue: 'The Wharf Rooms',   city: 'Chicago, IL',   when: 'Apr 2026', len: '2 h', room: 'Warm-up before a headliner. Left the room at 122 and got a thank-you from the person after me, which is the whole job.' },
  { venue: 'Pallet & Pine',     city: 'Columbus, OH',  when: 'Mar 2026', len: '2 h', room: 'Outdoor, ended early for weather. Half the set is on this list because the other half did not happen.' },
  { venue: 'Union Vault',       city: 'Detroit, MI',   when: 'Feb 2026', len: '3 h', room: 'Late slot, 132 upward, the one room in the city where that lands before 2am.' },
  { venue: 'Northline Festival', city: 'Grand Rapids, MI', when: 'Aug 2025', len: '1 h', room: 'Festival stage, daylight, and a completely different job from a club. Shorter, brighter, less patient.' },
  { venue: 'Bramble Hall',      city: 'Detroit, MI',   when: 'Jul 2025', len: '5 h', room: 'Open to close after a cancellation. Five hours is a different skill and I would not claim to be good at it yet.' },
  { venue: 'The Wharf Rooms',   city: 'Chicago, IL',   when: 'May 2025', len: '2 h', room: 'Second time. Booth monitor arrived because it was on the rider, which is the entire argument of this page.' },
];

export const setsNote =
  'No mixes on this page. There is a set list, because where and how long and what the room was ' +
  'doing tells a promoter more than a two-hour recording they will not listen to — and because ' +
  'the sets on this site are fictional, so a recording would be a fabrication rather than a ' +
  'portfolio.';

// ── What a night costs ────────────────────────────────────────────────────

export const cost = {
  premise: 'A 250-mile booking, offered "for exposure"',
  lines: [
    { op: 'Fuel and tolls, return',   val: '$96',  why: 'Five hundred miles of driving. Not negotiable and not reimbursed on an exposure booking.' },
    { op: 'A room, because it ends at 3am', val: '$85', why: 'Driving four hours after a five-hour night is the part of this job that actually hurts people.' },
    { op: 'Food',                     val: '$34',  why: 'Two meals on the road. Small, and it is real money.' },
    { op: 'The day after',            val: '$180', why: 'A shift not worked, at what an hourly job in this city pays. This is the line every "exposure" conversation leaves out.' },
    { op: 'Total cost of playing free', val: '−$395', why: 'Before a single record. This is not a complaint about small promoters, most of whom are also losing money — it is the number that makes the conversation honest.' },
  ],
  note:
    'I do play for less than the rate, fairly often, for rooms and people I want to be part of. ' +
    'What I do not do is pretend the number is zero. If your budget is small, say the number and ' +
    'I will tell you whether it works — that conversation takes one email and it beats the one ' +
    'where "exposure" is offered to somebody who is already four hundred dollars down.',
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { what: 'Club, 2–3 hours, local',  figure: '$450',  note: 'Detroit metro. Half on booking, half on the night — see the last line of the rider.' },
    { what: 'Open to close, 4–5 hours', figure: '$700',  note: 'A different job, not a longer one. Priced accordingly and worth discussing before you book it.' },
    { what: 'Warm-up, 2 hours',        figure: '$280',  note: 'Deliberately the cheapest line, because the warm-up is the slot that most needs somebody who will not overplay it.' },
    { what: 'Out of state',            figure: 'Fee + costs', note: 'Travel, a room if it ends after 1am, and the fee. Itemised in the advance, never bundled into one number.' },
    { what: 'Festival or brand',       figure: 'Quoted',  note: 'Different insurance, different tech, different day. Quoted from the actual spec rather than from the club rate.' },
    { what: 'Cancellation inside 14 days', figure: 'Deposit retained', note: 'Standard, and it works both ways — if I cancel inside fourteen days you get it back doubled.' },
  ],
};

export const said = {
  text: 'She sent the rider with a column for us to tick and a note about which four lines actually mattered. It was the first time a booking made our production job easier instead of harder.',
  who: 'Promoter, 400-capacity room — after a second booking',
};

export const faqs = [
  {
    q: 'Why publish the whole rider?',
    a: 'Because most nights that go wrong go wrong on this list rather than on the music, and because a promoter who reads it two weeks out can fix four of the lines for free. A rider that arrives the day before is a document nobody had time to act on.',
  },
  {
    q: 'What if we cannot meet a required line?',
    a: 'Tell me and I will tell you honestly whether it changes the booking. Two of the four have workarounds; the booth monitor does not, and I would rather know in advance than find out during the first record.',
  },
  {
    q: 'Are those real mixes?',
    a: 'There are no mixes on this page. The three audio players are generated click tracks at three tempos, and the sets on this site are fictional — this is a website template. If you are using it, put your real mixes here and delete this answer.',
  },
  {
    q: 'Will you play for exposure?',
    a: 'Sometimes, for rooms and people I want to be part of, and never on the pretence that it costs me nothing. The subtraction on this page is what a 250-mile night actually costs. Say your real budget and we will find out in one email whether it works.',
  },
  {
    q: 'Vinyl or digital?',
    a: 'Digital, on club-standard players. I will bring a USB and a backup USB, and I will not bring my own mixer unless we have agreed it, because a DJ arriving with a mixer at 11pm is a production problem you did not ask for.',
  },
  {
    q: 'Can we hear a set before booking?',
    a: 'Come to one, if you can — a recording of a room is not the room. Failing that, tell me the tempo band and the slot and I will tell you honestly whether it is a night I would be right for.',
  },
];
