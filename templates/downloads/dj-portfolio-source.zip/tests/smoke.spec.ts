import { test, expect } from '@playwright/test';

test.describe('Sula Brant — smoke tests', () => {
  test('homepage renders with the DJ name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Sula Brant/);
    await expect(page.locator('h1')).toContainText('rider is for you');
  });

  // Fifth schema shape in five days. This one adds makesOffer, because a
  // booking is a service with a price and the vocabulary models that.
  test('is a Person with an occupation and real offers', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('Disc jockey');
    expect(json).toContain('makesOffer');
    expect(json).not.toContain('"Organization"');
    expect(json).not.toContain('Record producer');
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#rider table.rider');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(400);
  });

  // ── The rider ───────────────────────────────────────────────────────────
  test('every rider line states a need and a failure mode', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#rider tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(8);
    for (const r of await rows.all()) {
      const need = ((await r.locator('.need').textContent()) || '').trim();
      expect(['Required', 'Asked for']).toContain(need);
      expect(((await r.locator('.without').textContent()) || '').length).toBeGreaterThan(40);
    }
  });

  // The argument is that most of the rider is NOT required.
  test('only a minority of the rider is required, and the count is derived', async ({ page }) => {
    await page.goto('/');
    const needs = (await page.locator('#rider .need').allTextContents()).map((s) => s.trim());
    const musts = needs.filter((x) => x === 'Required').length;
    expect(musts).toBeGreaterThan(0);
    expect(musts).toBeLessThan(needs.length / 2);
    await expect(page.locator('#rider h2'))
      .toHaveText(`${needs.length} lines. ${musts} of them are required.`);
    await expect(page.locator('h1 ~ div a').first()).toContainText(`${needs.length} lines, ${musts} required`);
  });

  test('each need state carries a glyph, and neither state is the accent', async ({ page }) => {
    await page.goto('/');
    for (const n of await page.locator('#rider .need').all()) {
      expect(await n.getAttribute('data-glyph')).toBeTruthy();
    }
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--state-ok', '--state-gone', '--color-accent'].map((k) => s.getPropertyValue(k).trim());
    });
    expect(new Set(c).size).toBe(3);
  });

  // ── Tempo — the first <audio> in this library ───────────────────────────
  test('each tempo band has a real audio element that is not preloaded', async ({ page }) => {
    await page.goto('/');
    const players = page.locator('#tempo audio');
    const n = await players.count();
    expect(n).toBe(3);
    for (const a of await players.all()) {
      expect(await a.getAttribute('controls')).not.toBeNull();
      expect(await a.getAttribute('preload')).toBe('none');
      expect(await a.getAttribute('src')).toMatch(/click-\d+\.mp3$/);
      expect(((await a.getAttribute('aria-label')) || '')).toMatch(/beats per minute/);
    }
  });

  test('every audio file actually resolves', async ({ page, request }) => {
    await page.goto('/');
    const srcs = await page.locator('#tempo audio').evaluateAll((els) =>
      els.map((e) => (e as HTMLAudioElement).src));
    expect(srcs.length).toBe(3);
    for (const s of srcs) {
      const res = await request.get(s);
      expect(res.status()).toBe(200);
      expect(Number(res.headers()['content-length'] || '1')).toBeGreaterThan(1000);
    }
  });

  // The audio must illustrate, never carry. The page has to work with sound off.
  test('every tempo band states its BPM and purpose in text', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#tempo article');
    expect(await cards.count()).toBe(3);
    const bpms: number[] = [];
    for (const c of await cards.all()) {
      const bpm = ((await c.locator('.bpm').textContent()) || '').match(/(\d+)/);
      expect(bpm).not.toBeNull();
      bpms.push(Number(bpm![1]));
      expect(((await c.locator('p').last().textContent()) || '').length).toBeGreaterThan(60);
    }
    for (let i = 1; i < bpms.length; i++) expect(bpms[i]).toBeGreaterThan(bpms[i - 1]);
    // and the booking form offers the same three
    const opts = await page.locator('#tempo option, select#tempo option').allTextContents();
    for (const b of bpms) expect(opts.join(' ')).toContain(String(b));
  });

  test('there are no fabricated mixes, and the page says so', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#sets')).toContainText(/No mixes on this page/i);
    await expect(page.locator('#faq')).toContainText(/generated click tracks/i);
  });

  // ── Cost ────────────────────────────────────────────────────────────────
  test('the cost of a free night is worked and lands in the headline', async ({ page }) => {
    await page.goto('/');
    const vals = (await page.locator('#cost .val').allTextContents()).map((s) => s.trim());
    expect(vals.length).toBeGreaterThan(3);
    const last = vals[vals.length - 1];
    expect(last).toMatch(/^−\$\d/);
    await expect(page.locator('#cost h2')).toContainText(last.replace('−', ''));
  });

  test('the page does not simply refuse low budgets', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#cost')).toContainText(/I do play for less than the rate/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#date', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-111 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['roan whitfield', 'memphis', 'discography', 'stems', 'royalty point']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro advance sheet is absent from the free build', async ({ page }) => {
    const res = await page.goto('/advance-sheet/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
