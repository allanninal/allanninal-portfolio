// ============================================================
// The Velvet Cipher — Day 44 · Cocktail Lounge / Speakeasy
// Sultry dark speakeasy: signature cocktails, DJ events, small bites, guestlist
// Palette: Noir Black (#0D0D0D) + Emerald Neon (#00E5A0, decorative) + Deep Jade (#0A4A3A) + Cream (#F0E6CF)
// Fonts: Bodoni Moda (display) + IBM Plex Mono (body/UI)
// ============================================================

export const lounge = {
  name: 'The Velvet Cipher',
  shortName: 'Velvet Cipher',
  tagline: 'Drinks That Demand an Alias.',
  shortTagline: 'A clandestine cocktail lounge in the Lower East Side. Signature pours, late-night sets, no cover — just know the door.',
  description:
    'The Velvet Cipher is a subterranean cocktail lounge and speakeasy on the Lower East Side of New York City. We craft original cocktails built around house-made syrups, clarified juices, and spirits that most bars have never heard of — then pair them with late-night DJ sets and the kind of atmosphere that makes you forget what time it is outside.',
  address: '54 Orchard Street, New York, NY 10002',
  phone: '+1 (212) 555-0174',
  email: 'hello@velvetcipher.com',
  reservationUrl: '#guestlist',
  instagram: 'https://instagram.com/velvetcipher',
  facebook: 'https://facebook.com/velvetcipher',
  estYear: '2021',
  mapsUrl: 'https://maps.google.com/?q=54+Orchard+Street+New+York+NY',
  neighborhood: 'Lower East Side, New York City',
  dressCode: 'Smart-casual. No athletic wear. We reserve the right of admission.',
};

// ─── Hours ───────────────────────────────────────────────────────────────────

export type HoursRow = {
  day: string;
  open: string;
  note?: string;
};

export const hours: HoursRow[] = [
  { day: 'Mon–Wed', open: 'Closed',             note: 'The cipher rests.' },
  { day: 'Thursday', open: '7:00 PM – 2:00 AM', note: 'Opening night set from 9 PM. Walk-ins from 7 PM.' },
  { day: 'Friday',   open: '7:00 PM – 4:00 AM', note: 'DJ sets 10 PM – 3 AM. Guestlist recommended.' },
  { day: 'Saturday', open: '7:00 PM – 4:00 AM', note: 'Signature night. Guestlist closes at 9 PM.' },
  { day: 'Sunday',   open: '6:00 PM – 12:00 AM', note: 'Slow Sundays — acoustic sets, no cover.' },
];

// ─── Cocktail Menu ────────────────────────────────────────────────────────────

export type CocktailTag = 'signature' | 'classic' | 'zero-proof' | 'strong' | 'low-abv' | 'seasonal' | 'house-special';

export type CocktailSection = 'signature' | 'classics' | 'zero-proof';

export type Cocktail = {
  id: string;
  name: string;
  spirits: string;
  description: string;
  price: string;
  tags: CocktailTag[];
  section: CocktailSection;
  recommended?: boolean;
};

export const cocktails: Cocktail[] = [
  // ── Signature Originals ────────────────────────────────────────────────────
  {
    id: 'dead-drop',
    name: 'Dead Drop',
    spirits: 'Mezcal, Genmaicha tea syrup, yuzu, activated charcoal salt rim',
    description: 'Smoky Oaxacan mezcal meets a house-made roasted rice tea syrup and tart yuzu — served over a single obsidian sphere ice, finished with a charcoal-dusted rim. The cipher begins here.',
    price: '$19',
    tags: ['signature', 'house-special'],
    section: 'signature',
    recommended: true,
  },
  {
    id: 'emerald-cypher',
    name: 'Emerald Cypher',
    spirits: 'Empress 1908 gin, green Chartreuse, cucumber, basil, lime foam',
    description: 'Indigo-hued Empress gin balanced by herbal Chartreuse, muddled cucumber and basil — crowned with a delicate lime-acid foam. Complex, botanical, electric.',
    price: '$18',
    tags: ['signature', 'low-abv'],
    section: 'signature',
    recommended: true,
  },
  {
    id: 'noir-negroni',
    name: 'Noir Negroni',
    spirits: 'Blended Scotch, cold-brew Campari, black walnut bitters, dried orange',
    description: 'A brooding riff on the classic — Scotch replaces gin, Campari is cold-brew-infused for depth, and black walnut bitters add earthiness. A 40-second stir over hand-carved ice.',
    price: '$17',
    tags: ['signature', 'strong'],
    section: 'signature',
  },
  {
    id: 'velvet-storm',
    name: 'Velvet Storm',
    spirits: 'Aged rum, passion fruit, cardamom, coconut cream, overproof float',
    description: 'Rich aged rum shaken with ripe passion fruit and fragrant cardamom syrup, softened with house coconut cream and finished with an overproof rum float. Dense, tropical, dangerous.',
    price: '$18',
    tags: ['signature', 'strong'],
    section: 'signature',
  },
  {
    id: 'smoke-signal',
    name: 'Smoke Signal',
    spirits: 'Peated whisky, honey-thyme cordial, lemon, egg white, smoked cedar mist',
    description: 'Peated Islay whisky softened by a house honey-thyme cordial and fresh lemon, dry-shaken for a silky egg-white foam, then kissed with a cedar smoke mist tableside.',
    price: '$20',
    tags: ['signature', 'house-special', 'seasonal'],
    section: 'signature',
  },
  {
    id: 'cipher-sour',
    name: 'Cipher Sour',
    spirits: 'Pisco, lychee, rose water, aquafaba, Peychaud\'s bitters',
    description: 'Pisco shaken with fresh lychee, a breath of rose water, and aquafaba for a silky vegan foam. Three dashes of Peychaud\'s on the surface. Floral, bright, seductive.',
    price: '$16',
    tags: ['signature', 'low-abv'],
    section: 'signature',
  },
  {
    id: 'ghost-old-fashioned',
    name: 'Ghost Old Fashioned',
    spirits: 'Clairin agricole, coconut-washed bourbon, vanilla, Angostura',
    description: 'Fat-washed bourbon meets Haitian Clairin for a ghost-like funkiness. Coconut oil wash, pure vanilla sugar, two dashes Angostura. Stirred to perfection over a hand-chiseled block.',
    price: '$21',
    tags: ['signature', 'strong', 'house-special'],
    section: 'signature',
    recommended: true,
  },
  {
    id: 'last-transmission',
    name: 'Last Transmission',
    spirits: 'Navy-strength gin, kaffir lime leaf, turmeric shrub, tonic mist',
    description: 'High-proof navy-strength gin with a house kaffir lime leaf and turmeric shrub — golden, aromatic, served long over ice with a light tonic mist. Citrus-forward with a lingering heat.',
    price: '$17',
    tags: ['signature'],
    section: 'signature',
  },

  // ── Classics ──────────────────────────────────────────────────────────────
  {
    id: 'martini',
    name: 'Dirty Martini',
    spirits: 'London Dry gin or Ketel One vodka, dry vermouth, house olive brine',
    description: 'Stirred until it\'s cold enough to hurt. Three-to-one ratio, expressed lemon peel, house-cured olive on a steel pick.',
    price: '$16',
    tags: ['classic', 'strong'],
    section: 'classics',
  },
  {
    id: 'negroni-classic',
    name: 'Negroni',
    spirits: 'Tanqueray 10, Campari, Cocchi Vermouth di Torino',
    description: 'Equal parts. Stirred. Orange peel. Non-negotiable.',
    price: '$15',
    tags: ['classic', 'strong'],
    section: 'classics',
  },
  {
    id: 'daiquiri',
    name: 'Daiquiri',
    spirits: 'Plantation 3 Stars white rum, fresh lime, house-made demerara syrup',
    description: 'The platonic daiquiri — rum, lime, sugar, nothing else. Shaken hard, served up in a chilled coupe. Deceptively simple, ruthlessly executed.',
    price: '$14',
    tags: ['classic'],
    section: 'classics',
  },
  {
    id: 'paper-plane',
    name: 'Paper Plane',
    spirits: 'Bourbon, Aperol, Amaro Nonino, fresh lemon',
    description: 'Sam Ross\'s modern classic — four equal parts, shaken, strained. Bittersweet, tart, unforgettable.',
    price: '$15',
    tags: ['classic'],
    section: 'classics',
  },
  {
    id: 'whisky-sour',
    name: 'Whisky Sour',
    spirits: 'Bulleit Rye, lemon, simple syrup, egg white (aquafaba on request)',
    description: 'The original sour — rye whisky balanced against fresh citrus and sweetness, shaken with egg white for froth. Angostura on top.',
    price: '$14',
    tags: ['classic'],
    section: 'classics',
  },
  {
    id: 'espresso-martini',
    name: 'Espresso Martini',
    spirits: 'Ketel One vodka, Kahlúa, cold-brew espresso, demerara, three coffee beans',
    description: 'Double-shot cold brew, vodka, Kahlúa — dry-shaken for a thick crema. The after-midnight recalibration.',
    price: '$16',
    tags: ['classic'],
    section: 'classics',
  },

  // ── Zero-Proof ────────────────────────────────────────────────────────────
  {
    id: 'phantom-spritz',
    name: 'Phantom Spritz',
    spirits: 'House-made bergamot shrub, grapefruit, elderflower tonic, dehydrated citrus',
    description: 'Bright bergamot and white grapefruit over ice with a floral elderflower tonic. Gorgeous, complex, and entirely alcohol-free. Garnished with a dehydrated citrus wheel.',
    price: '$12',
    tags: ['zero-proof'],
    section: 'zero-proof',
    recommended: true,
  },
  {
    id: 'dark-signal',
    name: 'Dark Signal',
    spirits: 'Cold-brew, tamarind-date syrup, coconut milk, activated charcoal, orange bitters (non-alcoholic)',
    description: 'Smoky and complex without a drop of spirit — cold brew with a tamarind-date reduction, coconut milk, and non-alcoholic bitters. Looks like the night sky. Tastes like dessert.',
    price: '$12',
    tags: ['zero-proof'],
    section: 'zero-proof',
  },
  {
    id: 'jade-garden',
    name: 'Jade Garden',
    spirits: 'Cucumber, green tea, yuzu, honey, soda',
    description: 'Freshly pressed cucumber with cold-brewed green tea, yuzu juice, and a light honey syrup. Long over ice, topped with soda. Refreshing and herbal.',
    price: '$11',
    tags: ['zero-proof'],
    section: 'zero-proof',
  },
];

// ─── Small Bites ──────────────────────────────────────────────────────────────

export type Bite = {
  id: string;
  name: string;
  description: string;
  price: string;
  tags?: string[];
};

export const smallBites: Bite[] = [
  {
    id: 'oysters',
    name: 'Oysters on Ice (Half Dozen)',
    description: 'Market oysters, mignonette, Tabasco honey, lime. The ideal Dead Drop companion.',
    price: '$26',
    tags: ['gluten-free'],
  },
  {
    id: 'wagyu-sliders',
    name: 'Wagyu Sliders (×2)',
    description: 'Wagyu beef on brioche, truffle aioli, caramelized onion, aged cheddar, house pickles.',
    price: '$22',
  },
  {
    id: 'charcuterie',
    name: 'Cipher Board',
    description: 'Rotating selection of three cured meats, two cheeses, honeycomb, grain mustard, cornichons, artisan crackers.',
    price: '$28',
  },
  {
    id: 'truffle-fries',
    name: 'Truffle & Parmesan Fries',
    description: 'Hand-cut double-fried potato, black truffle oil, shaved parmesan, smoked flaky salt.',
    price: '$14',
    tags: ['vegetarian', 'gluten-free'],
  },
  {
    id: 'tuna-tataki',
    name: 'Tuna Tataki',
    description: 'Seared yellowfin, ponzu, avocado cream, sesame, microgreens, crispy wonton strips.',
    price: '$24',
    tags: ['gluten-free'],
  },
  {
    id: 'mushroom-crostini',
    name: 'Wild Mushroom Crostini',
    description: 'Chanterelle and black trumpet mushrooms, whipped ricotta, thyme oil, aged balsamic on sourdough crostini.',
    price: '$16',
    tags: ['vegetarian'],
  },
];

// ─── Events ───────────────────────────────────────────────────────────────────

export type LoungeEvent = {
  id: string;
  name: string;
  date: string;
  time: string;
  description: string;
  format: string;
  price?: string;
  free?: boolean;
  guestlistUrl?: string;
};

export const events: LoungeEvent[] = [
  {
    id: 'friday-resident',
    name: 'MØBIUS — Resident DJ Night',
    date: 'Every Friday',
    time: '10:00 PM – 3:00 AM',
    description: 'Our Friday resident MØBIUS plays an unbroken journey through dark house, minimal techno, and deep electronic music. No genre constraints. Expect the unexpected. Guestlist closes 9 PM.',
    format: 'DJ Set',
    free: true,
    guestlistUrl: '#guestlist',
  },
  {
    id: 'saturday-guest',
    name: 'Guest DJ: ILLVANE',
    date: 'July 12, 2026',
    time: '10:00 PM – 4:00 AM',
    description: 'Berlin-based ILLVANE brings her signature blend of industrial techno and acid-laced club music to the Velvet Cipher for one night only. Internationally renowned. Intimate room. Rare opportunity.',
    format: 'Guest DJ',
    price: '$20 guestlist / $30 door',
    guestlistUrl: '#guestlist',
  },
  {
    id: 'cocktail-class',
    name: 'Black Craft: Cocktail Masterclass',
    date: 'July 19, 2026',
    time: '6:30 PM – 9:00 PM',
    description: 'Head bartender Mara Solano walks a group of twelve through the construction of four signature Velvet Cipher cocktails — including our misting and fat-washing techniques. Cocktails included. Limited seats.',
    format: 'Cocktail class',
    price: '$95 per person',
    guestlistUrl: '#guestlist',
  },
  {
    id: 'slow-sunday',
    name: 'Slow Sunday: ECHO & PEARL (Acoustic)',
    date: 'July 20, 2026',
    time: '7:00 PM – 10:00 PM',
    description: 'Guitar and voice duo Echo & Pearl play an intimate, low-lit acoustic set in the lounge. No DJ, no cover. Just cocktails and live music at a civilized volume.',
    format: 'Live acoustic',
    free: true,
  },
  {
    id: 'cipher-launch',
    name: 'Cipher Sessions Vol. 3',
    date: 'August 2, 2026',
    time: '9:00 PM – 4:00 AM',
    description: 'The quarterly Cipher Sessions label night returns — three back-to-back DJs, a bespoke cocktail menu, and a vinyl-only B2B set at midnight. The most anticipated night on our calendar.',
    format: 'Label night',
    price: '$25 guestlist / $40 door',
    guestlistUrl: '#guestlist',
  },
];

// ─── Our Story ────────────────────────────────────────────────────────────────

export const story = {
  headline: 'A Room Built for the Hours Between Midnight and Reason.',
  founderName: 'Mara Solano',
  founderTitle: 'Co-Founder & Head Bartender',
  bio: [
    'Mara Solano spent seven years behind bars in Mexico City, London, and Tokyo before landing in New York with a notebook full of ideas nobody was willing to back. The Velvet Cipher opened in 2021 in a basement on Orchard Street — low ceilings, green neon, and cocktails that required an actual explanation.',
    'The concept was simple: every drink on the menu is an original. No bottles-and-sodas shortcuts. Every syrup is house-made, every garnish is intentional, and the spirits are chosen because they have a point of view. The kitchen sends out small bites designed to companion — not compete with — the drinks.',
    'Three years in, the room fills up every weekend with people who found out through word of mouth. We haven\'t run a single ad. The cocktails do the talking.',
  ],
  stats: [
    { label: 'Original cocktails', value: '40+' },
    { label: 'House-made syrups', value: '18' },
    { label: 'Nights open per year', value: '208' },
    { label: 'Opened', value: '2021' },
  ],
};

// ─── Gallery ──────────────────────────────────────────────────────────────────

export const gallery = [
  { alt: 'The Velvet Cipher bar counter at night — rows of rare spirits backlit against noir-black walls', label: 'The main bar', src: 'bar' },
  { alt: 'Close-up of the Dead Drop cocktail — deep smoky liquid catching neon light', label: 'Dead Drop', src: 'dead-drop' },
  { alt: 'The Velvet Cipher lounge interior — dark low-ceilinged room with tufted green leather seating in low light', label: 'The lounge room', src: 'lounge' },
  { alt: 'A bartender mid-stir, barspoon in a crystal mixing glass, low light behind the bar', label: 'The craft', src: 'craft' },
  { alt: 'The DJ at the booth — silhouette backlit by coloured light, mixing in the dark room', label: 'On the decks', src: 'dj' },
  { alt: 'The Emerald Cypher cocktail in a coupe glass — vivid green hue catching the bar light', label: 'Emerald Cypher', src: 'cypher' },
];

// ─── Maker ────────────────────────────────────────────────────────────────────

export const maker = {
  name: 'Allan Ninal',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  email: 'landix.ninal@gmail.com',
  kofi: 'https://ko-fi.com/allanninal',
};

// ─── Site Meta ────────────────────────────────────────────────────────────────

export const site = {
  title: 'The Velvet Cipher — Cocktail Lounge, Lower East Side NYC',
  description:
    'A clandestine cocktail lounge and speakeasy on the Lower East Side, New York. Original signature cocktails, late-night DJ sets, and small bites. Guestlist recommended on weekends.',
  url: 'https://templates.allanninal.dev/cocktail-lounge/',
  ogImage: '/og-image.png',
  language: 'en',
};
