/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Bodoni Moda"', 'Georgia', 'serif'],
        mono: ['"IBM Plex Mono"', '"Courier New"', 'monospace'],
      },
      colors: {
        noir: '#0D0D0D',
        'noir-2': '#171717',
        'noir-3': '#1F1F1F',
        jade: '#0A4A3A',
        'jade-mid': '#0D5C48',
        emerald: '#00E5A0',
        'emerald-dim': '#00C288',
        cream: '#F0E6CF',
        'cream-dim': '#C8B99A',
        'smoke': '#8A8A8A',
      },
    },
  },
  plugins: [],
};
