import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Velvet Cipher/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('cocktail menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#cocktail-menu')).toBeVisible();
});

test('cocktail heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#cocktail-heading')).toBeVisible();
});

test('small bites section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#small-bites')).toBeVisible();
});

test('events section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#events')).toBeVisible();
});

test('events heading is present', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#events-heading')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('guestlist section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#guestlist')).toBeVisible();
});

test('guestlist form has email input', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gl-email')).toBeVisible();
});

test('visit section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#visit')).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('[aria-label="Main navigation"]');
  await expect(nav).toBeVisible();
});

test('menu tabs switch panels', async ({ page }) => {
  await page.goto('/');
  // Classics tab
  await page.click('#tab-btn-classics');
  await expect(page.locator('#tab-classics')).toBeVisible();
  await expect(page.locator('#tab-signature')).toBeHidden();
  // Zero-proof tab
  await page.click('#tab-btn-zero');
  await expect(page.locator('#tab-zero')).toBeVisible();
  // Back to signature
  await page.click('#tab-btn-signature');
  await expect(page.locator('#tab-signature')).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('LinkedIn hire link is present', async ({ page }) => {
  await page.goto('/');
  const linkedinLink = page.locator('a[href*="linkedin.com"]').first();
  await expect(linkedinLink).toBeVisible();
});
