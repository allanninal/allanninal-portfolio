import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo bar renders with hub URL set', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR)).toBeVisible();
});

test('TemplateInfo has static-zip download link', async ({ page }) => {
  await page.goto('/');
  const staticLink = page.locator(`${BAR} a[download]`).first();
  await expect(staticLink).toBeVisible();
  expect(await staticLink.getAttribute('href')).toContain('cocktail-lounge-static.zip');
});

test('TemplateInfo source / Get-Pro affordance', async ({ page }) => {
  await page.goto('/');
  if (isPro) {
    const getPro = page.locator(BAR).locator('a', { hasText: /Get Pro static/ });
    await expect(getPro).toBeVisible();
    expect(await getPro.getAttribute('href')).toContain('linkedin.com');
    return;
  }
  const sourceLink = page.locator(`${BAR} a[download]`).nth(1);
  await expect(sourceLink).toBeVisible();
  expect(await sourceLink.getAttribute('href')).toContain('cocktail-lounge-source.zip');
});

test('TemplateInfo has All 365 link', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator(BAR).locator('a', { hasText: /All 365/ })).toBeVisible();
});

test('TemplateInfo links to LinkedIn (Build with me / Get Pro static)', async ({ page }) => {
  await page.goto('/');
  const link = page.locator(BAR).locator('a', { hasText: isPro ? /Get Pro static/ : /Build with me/ });
  await expect(link).toBeVisible();
  expect(await link.getAttribute('href')).toContain('linkedin.com');
});

test('no private repo links in TemplateInfo', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`${BAR} a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});
