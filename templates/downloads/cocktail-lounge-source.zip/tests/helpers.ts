import type { Page } from '@playwright/test';

// Single-page template; the Pro edition adds a standalone /menu (cocktail list) page.
export const ROUTES =
  process.env.PUBLIC_EDITION === 'pro' ? ['/', '/menu/'] : ['/'];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'wide',    width: 1920, height: 1080 },
];

// This template is dark-only — no theme toggle
export async function setTheme(page: Page, _theme: 'light' | 'dark') {
  // No-op: dark theme only
  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
  });
}
