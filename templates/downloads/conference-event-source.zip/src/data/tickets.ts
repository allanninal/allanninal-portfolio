export type TicketFeature = {
  text: string;
  included: boolean;
};

export type Ticket = {
  id: string;
  name: string;
  price: number;
  currency: string;
  availability: string;
  badge?: string;
  highlighted?: boolean;
  features: TicketFeature[];
  ctaText: string;
  note?: string;
};

export const tickets: Ticket[] = [
  {
    id: 'early-bird',
    name: 'Early Bird',
    price: 299,
    currency: 'USD',
    availability: 'Available until July 15, 2026',
    badge: 'Limited',
    highlighted: false,
    ctaText: 'Get Early Bird Ticket',
    note: 'Price increases to $449 on July 16.',
    features: [
      { text: 'Both conference days (Sep 15–16)', included: true },
      { text: 'Access to both tracks (A & B)', included: true },
      { text: 'Lunch & coffee both days', included: true },
      { text: 'Opening Night Social (Day 1)', included: true },
      { text: 'Workshop sessions', included: true },
      { text: 'Speaker recordings (post-event)', included: true },
      { text: 'Team invoice (5+ seats)', included: false },
    ],
  },
  {
    id: 'standard',
    name: 'Standard',
    price: 449,
    currency: 'USD',
    availability: 'July 16 – September 1, 2026',
    badge: 'Most popular',
    highlighted: true,
    ctaText: 'Get Standard Ticket',
    features: [
      { text: 'Both conference days (Sep 15–16)', included: true },
      { text: 'Access to both tracks (A & B)', included: true },
      { text: 'Lunch & coffee both days', included: true },
      { text: 'Opening Night Social (Day 1)', included: true },
      { text: 'Workshop sessions', included: true },
      { text: 'Speaker recordings (post-event)', included: true },
      { text: 'Team invoice (5+ seats)', included: false },
    ],
  },
  {
    id: 'team',
    name: 'Team (5+ seats)',
    price: 349,
    currency: 'USD',
    availability: 'Available until September 1, 2026',
    highlighted: false,
    ctaText: 'Request Team Invoice',
    note: 'Per person price. Minimum 5 tickets. Invoice and bulk payment available.',
    features: [
      { text: 'Both conference days (Sep 15–16)', included: true },
      { text: 'Access to both tracks (A & B)', included: true },
      { text: 'Lunch & coffee both days', included: true },
      { text: 'Opening Night Social (Day 1)', included: true },
      { text: 'Workshop sessions', included: true },
      { text: 'Speaker recordings (post-event)', included: true },
      { text: 'Team invoice & bulk payment', included: true },
    ],
  },
];
