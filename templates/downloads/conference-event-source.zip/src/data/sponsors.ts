export type SponsorTier = 'title' | 'gold' | 'silver' | 'community';

export type Sponsor = {
  name: string;
  tier: SponsorTier;
  website: string;
  /** Background color for the SVG logo placeholder */
  bgColor: string;
  /** Text color for the SVG logo placeholder */
  textColor: string;
};

export const sponsors: Sponsor[] = [
  // Title
  {
    name: 'Vercel',
    tier: 'title',
    website: 'https://vercel.com',
    bgColor: '#000000',
    textColor: '#ffffff',
  },
  // Gold
  {
    name: 'Cloudflare',
    tier: 'gold',
    website: 'https://cloudflare.com',
    bgColor: '#F6821F',
    textColor: '#0E1117',
  },
  {
    name: 'Neon',
    tier: 'gold',
    website: 'https://neon.tech',
    bgColor: '#00E599',
    textColor: '#000000',
  },
  {
    name: 'Turso',
    tier: 'gold',
    website: 'https://turso.tech',
    bgColor: '#4FF8D2',
    textColor: '#000000',
  },
  // Silver
  {
    name: 'Sentry',
    tier: 'silver',
    website: 'https://sentry.io',
    bgColor: '#362D59',
    textColor: '#ffffff',
  },
  {
    name: 'Resend',
    tier: 'silver',
    website: 'https://resend.com',
    bgColor: '#000000',
    textColor: '#ffffff',
  },
  {
    name: 'Upstash',
    tier: 'silver',
    website: 'https://upstash.com',
    bgColor: '#00CB82',
    textColor: '#0E1117',
  },
  {
    name: 'Trigger.dev',
    tier: 'silver',
    website: 'https://trigger.dev',
    bgColor: '#7C3AED',
    textColor: '#ffffff',
  },
  // Community
  {
    name: 'Open Collective',
    tier: 'community',
    website: 'https://opencollective.com',
    bgColor: '#3385FF',
    textColor: '#ffffff',
  },
  {
    name: 'OSS Capital',
    tier: 'community',
    website: 'https://oss.capital',
    bgColor: '#1a1a2e',
    textColor: '#ffffff',
  },
  {
    name: 'DevRel Collective',
    tier: 'community',
    website: 'https://devrelcollective.fun',
    bgColor: '#059669',
    textColor: '#ffffff',
  },
];
