export type FaqItem = {
  question: string;
  answer: string;
};

export const faq: FaqItem[] = [
  {
    question: 'What is the refund policy?',
    answer:
      'Full refunds are available up to 30 days before the event (August 16, 2026). After that, tickets are transferable but not refundable. If OpenSignal Summit is cancelled or postponed due to unforeseen circumstances, all ticket holders will receive a full refund.',
  },
  {
    question: 'Will sessions be recorded?',
    answer:
      'Yes. All main stage keynotes and Track A/B talks will be recorded and shared with ticket holders within 3 weeks of the event. Workshop sessions are not recorded to encourage open participation.',
  },
  {
    question: 'Is there a student or scholarship discount?',
    answer:
      'We reserve 20 scholarship tickets for students and community contributors from underrepresented backgrounds. Applications open June 1 at opensignal.dev/scholarship. Student pricing ($99) is also available with a valid .edu email address.',
  },
  {
    question: 'What is your code of conduct?',
    answer:
      'OpenSignal Summit is committed to providing a safe, welcoming, and harassment-free environment for everyone. We enforce a strict code of conduct. All speakers, sponsors, and attendees must agree to it before registering. Read the full code of conduct at opensignal.dev/conduct.',
  },
  {
    question: 'Will there be a remote or live-stream option?',
    answer:
      'Keynotes and selected talks will be live-streamed for free on our YouTube channel. A virtual ticket ($49) includes access to all livestreams in real-time plus the post-event recording archive. Remote attendees will not have access to workshops.',
  },
  {
    question: 'Can I submit a talk? Is the CFP open?',
    answer:
      'The CFP (Call for Proposals) is open until June 30, 2026. We accept talks (40 min), lightning talks (8 min), and workshop proposals (90 min). All proposals are reviewed anonymously by our program committee. Submit at opensignal.dev/cfp.',
  },
];
