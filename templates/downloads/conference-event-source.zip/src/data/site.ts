export const site = {
  name: 'OpenSignal Summit',
  edition: '2026',
  tagline: 'Build what matters. Ship what lasts.',
  description:
    'OpenSignal Summit is a two-day conference for developers and product engineers in San Francisco. 12 speakers, 2 tracks, 400 attendees. September 15–16, 2026.',
  dates: {
    start: 'September 15, 2026',
    end: 'September 16, 2026',
    startIso: '2026-09-15',
    endIso: '2026-09-16',
  },
  city: 'San Francisco, CA',
  organizer: {
    name: 'OpenSignal Foundation',
    url: 'https://opensignal.dev',
    email: 'hello@opensignal.dev',
  },
  social: {
    twitter: 'https://twitter.com/opensignalconf',
    linkedin: 'https://www.linkedin.com/company/opensignal',
    youtube: 'https://youtube.com/@opensignalconf',
  },
  ticketUrl: 'https://ti.to/opensignal/summit-2026',
  cfpUrl: 'https://sessionize.com/opensignal-2026',
  sponsorEmail: 'sponsors@opensignal.dev',
  codeOfConductUrl: '#code-of-conduct',
  og: {
    image: '/og.png',
    alt: 'OpenSignal Summit 2026 — Sep 15–16, San Francisco',
  },
};
