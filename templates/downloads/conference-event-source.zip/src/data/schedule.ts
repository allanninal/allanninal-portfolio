export type ScheduleSession = {
  time: string;
  title: string;
  speaker?: string;
  speakerId?: string;
  track: 'A' | 'B' | 'All';
  type: 'keynote' | 'talk' | 'break' | 'workshop' | 'panel' | 'social';
  room?: string;
  duration?: string;
};

export type ScheduleDay = {
  day: number;
  date: string;
  dateIso: string;
  sessions: ScheduleSession[];
};

export const schedule: ScheduleDay[] = [
  {
    day: 1,
    date: 'Tuesday, September 15',
    dateIso: '2026-09-15',
    sessions: [
      {
        time: '8:00 AM',
        title: 'Registration & Morning Coffee',
        track: 'All',
        type: 'break',
        room: 'Main Lobby',
        duration: '60 min',
      },
      {
        time: '9:00 AM',
        title: 'Opening Keynote: The State of the Open Web',
        speaker: 'OpenSignal Foundation',
        track: 'All',
        type: 'keynote',
        room: 'Hall A (Main Stage)',
        duration: '45 min',
      },
      {
        time: '10:00 AM',
        title: 'Edge Functions Are Not Just Serverless',
        speaker: 'Priya Mehta',
        speakerId: 'priya-mehta',
        track: 'A',
        type: 'talk',
        room: 'Room 101',
        duration: '40 min',
      },
      {
        time: '10:00 AM',
        title: 'CRDTs Without the PhD',
        speaker: 'Marcus Okonkwo',
        speakerId: 'marcus-okonkwo',
        track: 'B',
        type: 'talk',
        room: 'Room 102',
        duration: '40 min',
      },
      {
        time: '11:00 AM',
        title: 'Lunch & Networking',
        track: 'All',
        type: 'break',
        room: 'Terrace',
        duration: '90 min',
      },
      {
        time: '12:30 PM',
        title: 'Sponsor Demos & Open Workshop',
        track: 'All',
        type: 'workshop',
        room: 'Exhibition Hall',
        duration: '90 min',
      },
      {
        time: '2:00 PM',
        title: 'Islands Architecture at Scale: Lessons from 2 Years',
        speaker: 'Aiko Tanaka',
        speakerId: 'aiko-tanaka',
        track: 'A',
        type: 'talk',
        room: 'Room 101',
        duration: '40 min',
      },
      {
        time: '2:00 PM',
        title: 'The GraphQL You Never Wanted to Write',
        speaker: 'Dara Osei',
        speakerId: 'dara-osei',
        track: 'B',
        type: 'talk',
        room: 'Room 102',
        duration: '40 min',
      },
      {
        time: '3:00 PM',
        title: 'Coffee Break',
        track: 'All',
        type: 'break',
        room: 'Main Lobby',
        duration: '30 min',
      },
      {
        time: '3:30 PM',
        title: 'Panel: Developer Experience in 2027',
        track: 'All',
        type: 'panel',
        room: 'Hall A (Main Stage)',
        duration: '60 min',
      },
      {
        time: '5:00 PM',
        title: 'Day 1 Wrap-up & Speaker Q&A',
        track: 'All',
        type: 'keynote',
        room: 'Hall A (Main Stage)',
        duration: '30 min',
      },
      {
        time: '6:00 PM',
        title: 'Opening Night Social — Rooftop Terrace',
        track: 'All',
        type: 'social',
        room: 'Rooftop Terrace',
        duration: '2 hrs',
      },
    ],
  },
  {
    day: 2,
    date: 'Wednesday, September 16',
    dateIso: '2026-09-16',
    sessions: [
      {
        time: '8:30 AM',
        title: 'Morning Coffee & Sponsor Expo',
        track: 'All',
        type: 'break',
        room: 'Exhibition Hall',
        duration: '30 min',
      },
      {
        time: '9:00 AM',
        title: 'Day 2 Keynote: Open Source in the Age of AI',
        speaker: 'OpenSignal Foundation',
        track: 'All',
        type: 'keynote',
        room: 'Hall A (Main Stage)',
        duration: '40 min',
      },
      {
        time: '10:00 AM',
        title: 'When the CDN Is the Bug',
        speaker: 'Rafael Santos',
        speakerId: 'rafael-santos',
        track: 'A',
        type: 'talk',
        room: 'Room 101',
        duration: '40 min',
      },
      {
        time: '10:00 AM',
        title: 'Serverless Postgres: What Nobody Tells You',
        speaker: 'Linda Chen',
        speakerId: 'linda-chen',
        track: 'B',
        type: 'talk',
        room: 'Room 102',
        duration: '40 min',
      },
      {
        time: '11:00 AM',
        title: 'Lunch & Birds-of-a-Feather Sessions',
        track: 'All',
        type: 'break',
        room: 'Terrace',
        duration: '90 min',
      },
      {
        time: '12:30 PM',
        title: 'Hands-on Workshop: Deploying to the Edge in 30 Minutes',
        track: 'All',
        type: 'workshop',
        room: 'Workshop Room 1',
        duration: '90 min',
      },
      {
        time: '2:00 PM',
        title: 'Lightning Talks (5 × 8 min)',
        track: 'All',
        type: 'panel',
        room: 'Hall A (Main Stage)',
        duration: '60 min',
      },
      {
        time: '3:00 PM',
        title: 'Coffee Break',
        track: 'All',
        type: 'break',
        room: 'Main Lobby',
        duration: '30 min',
      },
      {
        time: '3:30 PM',
        title: 'Closing Keynote: What We\'re Building Next',
        speaker: 'OpenSignal Foundation',
        track: 'All',
        type: 'keynote',
        room: 'Hall A (Main Stage)',
        duration: '40 min',
      },
      {
        time: '4:30 PM',
        title: 'Closing Ceremony, Thank-yous & Swag',
        track: 'All',
        type: 'keynote',
        room: 'Hall A (Main Stage)',
        duration: '30 min',
      },
    ],
  },
];
