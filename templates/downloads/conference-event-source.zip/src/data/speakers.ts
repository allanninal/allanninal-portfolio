export type Speaker = {
  id: string;
  name: string;
  title: string;
  company: string;
  bio: string;
  talk: string;
  talkAbstract: string;
  track: 'A' | 'B';
  day: 1 | 2;
  time: string;
  linkedin?: string;
  twitter?: string;
  /** CSS gradient for avatar placeholder */
  avatarGradient: string;
};

export const speakers: Speaker[] = [
  {
    id: 'priya-mehta',
    name: 'Priya Mehta',
    title: 'Staff Engineer',
    company: 'Vercel',
    bio: 'Priya builds the infrastructure that powers millions of deploys per day. She speaks regularly at QCon, Systems Conference, and is a co-author of "Reliability Patterns at Scale."',
    talk: 'Edge Functions Are Not Just Serverless',
    talkAbstract:
      'A practical tour of what edge runtimes actually give you beyond latency — streaming, geo-aware personalization, and the caching primitives that matter.',
    track: 'A',
    day: 1,
    time: '10:00 AM',
    linkedin: 'https://linkedin.com/in/priyamehta',
    twitter: 'https://twitter.com/priyamehta',
    avatarGradient: 'from-emerald-400 to-teal-600',
  },
  {
    id: 'marcus-okonkwo',
    name: 'Marcus Okonkwo',
    title: 'Principal Product Engineer',
    company: 'Linear',
    bio: "Marcus designed the real-time sync architecture behind Linear's live presence features. Prev: Figma. Writes about collaborative systems at devwriting.co.",
    talk: 'CRDTs Without the PhD',
    talkAbstract:
      'Conflict-free replicated data types explained from first principles — and a live demo of building a shared-canvas component with Yjs in 45 minutes.',
    track: 'B',
    day: 1,
    time: '10:00 AM',
    linkedin: 'https://linkedin.com/in/marcusokonkwo',
    twitter: 'https://twitter.com/marcusokonkwo',
    avatarGradient: 'from-violet-400 to-indigo-600',
  },
  {
    id: 'aiko-tanaka',
    name: 'Aiko Tanaka',
    title: 'Open Source Lead',
    company: 'Astro',
    bio: 'Aiko maintains the Astro core renderer and leads the community working group on islands architecture. She previously worked on V8 at Google.',
    talk: 'Islands Architecture at Scale: Lessons from 2 Years',
    talkAbstract:
      'What we got right, what we got wrong, and where partial hydration is headed in Astro 5 and beyond. Real performance data from production sites.',
    track: 'A',
    day: 1,
    time: '2:00 PM',
    linkedin: 'https://linkedin.com/in/aikotanaka',
    twitter: 'https://twitter.com/aikotanaka',
    avatarGradient: 'from-pink-400 to-rose-600',
  },
  {
    id: 'dara-osei',
    name: 'Dara Osei',
    title: 'Engineering Manager',
    company: 'Shopify',
    bio: 'Dara leads the Storefront API team at Shopify, responsible for the developer experience for 1.7M merchants. Speaker at Remix Conf, Node Conf, and previously at Stripe.',
    talk: 'The GraphQL You Never Wanted to Write',
    talkAbstract:
      'How Shopify migrated 40% of its merchant GraphQL calls to a generated SDK — and what the DX lessons were for teams thinking about type-safe API clients.',
    track: 'B',
    day: 1,
    time: '2:00 PM',
    linkedin: 'https://linkedin.com/in/daraosei',
    twitter: 'https://twitter.com/daraosei',
    avatarGradient: 'from-amber-400 to-orange-600',
  },
  {
    id: 'rafael-santos',
    name: 'Rafael Santos',
    title: 'Staff SRE',
    company: 'Cloudflare',
    bio: 'Rafael has been running distributed systems for 15 years, the last 6 at Cloudflare. He is the author of the popular "Production Postmortems" newsletter.',
    talk: 'When the CDN Is the Bug',
    talkAbstract:
      'A case study of three production incidents where the edge network itself was the failure mode — and how to design observability that survives the chaos.',
    track: 'A',
    day: 2,
    time: '10:00 AM',
    linkedin: 'https://linkedin.com/in/rafaelsantos',
    twitter: 'https://twitter.com/rafaelsantos_sr',
    avatarGradient: 'from-sky-400 to-blue-600',
  },
  {
    id: 'linda-chen',
    name: 'Linda Chen',
    title: 'Head of Developer Relations',
    company: 'Neon',
    bio: 'Linda has spent the last decade helping developers understand databases. She runs the Postgres for JavaScript developers course series and co-organizes PGConf NYC.',
    talk: 'Serverless Postgres: What Nobody Tells You',
    talkAbstract:
      'Cold starts, connection pooling limits, and the migration story from RDS — a straight-talk session on what works, what doesn\'t, and how to plan your move.',
    track: 'B',
    day: 2,
    time: '10:00 AM',
    linkedin: 'https://linkedin.com/in/lindachen',
    twitter: 'https://twitter.com/lindachen_dev',
    avatarGradient: 'from-green-400 to-emerald-600',
  },
];
