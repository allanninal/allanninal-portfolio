import { test, expect } from '@playwright/test';

test.describe('Conference Event — smoke tests', () => {
  test('home page loads with conference name', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/OpenSignal Summit/i);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('OpenSignal');
  });

  test('navigation links are present', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('link', { name: /Get Tickets/i }).first()).toBeVisible();
    await expect(page.getByRole('link', { name: /Speakers/i }).first()).toBeVisible();
    await expect(page.getByRole('link', { name: /Schedule/i }).first()).toBeVisible();
  });

  test('speakers section is present', async ({ page }) => {
    await page.goto('/');
    // Use role heading to be strict-mode safe (speaker name appears in heading + table cell)
    await expect(page.getByRole('heading', { name: 'Priya Mehta' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Marcus Okonkwo' })).toBeVisible();
  });

  test('ticket pricing is shown', async ({ page }) => {
    await page.goto('/');
    // Use role heading for ticket name to avoid strict mode violations
    await expect(page.getByRole('heading', { name: 'Early Bird' })).toBeVisible();
    await expect(page.getByText('$299', { exact: true })).toBeVisible();
  });

  test('JSON-LD Event schema is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasEvent = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('"Event"')) {
        hasEvent = true;
        break;
      }
    }
    expect(hasEvent).toBe(true);
  });

  test('no github.com deep-links in page source', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const deepLinks = html.match(/github\.com\/allanninal\/templates[^"'\s]*/g);
    expect(deepLinks).toBeNull();
  });

  test('hero has Get Tickets CTA', async ({ page }) => {
    await page.goto('/');
    const hero = page.locator('section').first();
    await expect(hero.getByRole('link', { name: /Get Tickets/i })).toBeVisible();
  });

  test('FAQ section has questions', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText('What is the refund policy?')).toBeVisible();
  });
});
