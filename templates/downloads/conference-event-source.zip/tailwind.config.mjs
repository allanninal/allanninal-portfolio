/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      colors: {
        bg: '#0E1117',
        surface: '#161B27',
        surface2: '#1E2640',
        border: '#1E293B',
        // Emerald accent — untaken in Days 1-19
        accent: {
          DEFAULT: '#10B981', // emerald-500
          dark:    '#059669', // emerald-600 hover
          light:   '#D1FAE5', // emerald-100 badge bg
          dim:     '#065F46', // emerald-900 subtle tint
        },
        text: {
          DEFAULT: '#F1F5F9', // slate-100
          muted:   '#94A3B8', // slate-400
          faint:   '#475569', // slate-600
        },
        gold: '#F59E0B',
        silver: '#94A3B8',
      },
      fontSize: {
        xs:   ['0.8rem',   { lineHeight: '1.5' }],
        sm:   ['0.9rem',   { lineHeight: '1.55' }],
        base: ['1rem',     { lineHeight: '1.65' }],
        lg:   ['1.125rem', { lineHeight: '1.6' }],
        xl:   ['1.25rem',  { lineHeight: '1.5' }],
        '2xl':['1.5rem',   { lineHeight: '1.3' }],
        '3xl':['1.875rem', { lineHeight: '1.2' }],
        '4xl':['2.25rem',  { lineHeight: '1.1' }],
        '5xl':['3rem',     { lineHeight: '1.05' }],
        '6xl':['3.75rem',  { lineHeight: '1.02' }],
        '7xl':['4.5rem',   { lineHeight: '1' }],
        '8xl':['6rem',     { lineHeight: '0.98' }],
      },
      maxWidth: {
        '7xl': '80rem',
        '8xl': '88rem',
      },
    },
  },
};
