# Conference / Event Template — Niche Research

## Concept

**OpenSignal Summit 2026** — A fictional 2-day developer and product conference in San Francisco. The template targets organizers of professional tech conferences, industry summits, and regional developer events (All Things Open, Config, React Conf, GopherCon, JSConf, RailsConf register).

**Conversion goal:** Ticket purchase / RSVP — primary CTA is "Get Tickets →" with tiered pricing.

---

## Competitive Landscape

### Reference sites studied
- **All Things Open** (allthingsopen.org) — Dense speaker grid, multi-track schedule, clear sponsor tiers, strong community messaging. Gold standard for mid-size open-source conferences.
- **Config 2024** (config.figma.com) — Minimal-chic dark hero, large typographic speaker names, single CTA "Register". Premium feel, product-company budget.
- **React Conf** (conf.react.dev) — Bold red/white, single-screen hero, speaker grid as primary content. Clean but single-accent branding.
- **Smashing Conf** (smashingconf.com) — Red/bright, busy, heavy sponsor logos. Functional but visually cluttered.
- **Web Summit** (websummit.com) — Enterprise dark, dense, overwhelmingly corporate. Too far from indie/community register.
- **GopherCon** — Community feel, gopher mascot, simple sections. Good model for tight budget aesthetic.
- **Luma event pages** — Mobile-first, clean, minimal. Great CTA patterns; lacks full conference depth.

### What's missing (our gap)
Free Astro conference templates do not exist. The niche is entirely occupied by:
1. Paid WordPress event themes (EventOn, The Events Calendar premium) — heavy, plugin-dependent
2. Static HTML templates (HTML5Up, ThemeForest) — no component architecture, no MDX schedule, no JSON-LD
3. Custom conference sites built by agencies — not open-source, not reusable

Our template closes this gap: **Astro + Tailwind, component-driven, full section suite, semantic JSON-LD (Event + Place + Offer + FAQPage + Person), GH Pages–ready.**

### Saturated patterns to avoid
- Countdown timer as the entire hero (already in startup-waitlist, Day 3)
- Dark hero with neon/electric accent (Days 1, 3, 10, 13 already own this)
- Generic "coming soon" registration form (Day 3 + Day 12)
- Purple/indigo "tech conference" default (React Conf, many paid themes)

---

## Visual Differentiation

### Days 1–19 palettes taken
| Day | Accent | Background register |
|-----|--------|-------------------|
| 1 | Amber (#FFB020) | Dark |
| 2 | Violet/cyan | Light |
| 3 | Electric lime | Dark |
| 4 | Coral (#FF6B4A) | Light warm |
| 5 | Forest green (#1C4A2E) | Light warm |
| 6 | Cobalt blue (#2563EB) | Light/dark Starlight |
| 7 | Deep magenta (#DB2777) | Light warm |
| 8 | Burnt orange (#C2410C) | Light warm |
| 9 | Slate-700 muted | Light/white |
| 10 | Teal (#14B8A6) | Dark |
| 11 | Oxblood (#881337) | Cream warm |
| 12 | Aubergine (#4A1942) | Warm white |
| 13 | Amber/saffron (#F59E0B) | Near-black |
| 14 | Electric blue (#2563EB) | Warm paper |
| 15 | Terracotta (#C45B3A) | Near-white |
| 16 | Slate-indigo (#3B5BDB) | Pure white |
| 17 | Prussian blue (dark, on ivory) | Ivory warm |
| 18 | Deep teal/jade (#0D7377) | Warm cream |
| 19 | Burgundy/crimson (#C0392B) | Warm near-black |

### Day 20 — chosen palette

**Accent: Deep saffron-gold → `#D97706` (Tailwind amber-600, full-opacity)** — Wait, amber is taken (Day 1, Day 13). Must avoid.

**Revised: Vivid emerald green → `#059669` (Tailwind emerald-600)** — emerald is distinct from:
- Forest green Day 5 (`#1C4A2E` — very dark, near-black green): emerald-600 is bright, saturated, not dark
- Teal Day 10 (`#14B8A6` — teal/cyan family): emerald-600 is yellow-shifted green, not cyan
- Jade Day 18 (`#0D7377` — darker, more muted teal): emerald-600 is brighter and greener

**Emerald is untaken as a primary accent on this dark charcoal base.**

### Final palette

```
--color-bg:           #0E1117   /* near-black, slight blue-tint — conference venue/night sky */
--color-surface:      #161B27   /* elevated card surface */
--color-surface-2:    #1E2640   /* section divider surfaces */
--color-accent:       #10B981   /* Tailwind emerald-500 — bright, energetic, "go" */
--color-accent-dark:  #059669   /* emerald-600 for hover states */
--color-accent-light: #D1FAE5   /* emerald-100 for badges on dark bg */
--color-text:         #F1F5F9   /* slate-100 — off-white, not harsh pure white */
--color-text-muted:   #94A3B8   /* slate-400 — secondary labels */
--color-border:       #1E293B   /* slate-800 subtle dividers */

/* Sponsor tier accents */
--color-gold:         #F59E0B   /* amber for gold sponsors only — not primary accent */
--color-silver:       #94A3B8   /* slate for silver sponsors */
```

**Contrast checks (WCAG AA, min 4.5:1 for normal text):**
- `#F1F5F9` on `#0E1117`: 15.8:1 — AAA ✓
- `#0E1117` on `#10B981` (CTA button): 8.4:1 — AAA ✓
- `#D1FAE5` on `#059669` (badge): 6.2:1 — AA ✓
- `#94A3B8` on `#0E1117`: 5.8:1 — AA ✓ (large text / UI elements)

**No Tailwind opacity modifiers** — all text colors are full-opaque tokens.
**No `opacity-*` on text at small sizes** — all muted text uses `--color-text-muted` (#94A3B8) directly.

---

## Typography

### Days 1–19 fonts taken
Display: Inter, Geist, DM Sans, IBM Plex Sans, Newsreader, Source Serif 4, Fraunces, Archivo Black, Playfair Display, Spectral, DM Serif Display, Cormorant Garamond, Bricolage Grotesque, Plus Jakarta Sans, Manrope, Outfit, Work Sans (body)

### Day 20 — chosen fonts

**Display/headings: `Familjen Grotesk`** (Google Fonts, `@fontsource/familjen-grotesk`)
- A Swedish-designed humanist grotesque with subtle optical quirks in the letterforms. Bold weight (700/800) feels authoritative for conference hero headings without being corporate-bland. Completely untaken in Days 1–19.
- Distinct from: Inter (too neutral), Bricolage Grotesque (too expressive, Day 13), Manrope (Day 7), Archivo Black (Day 15), Outfit (Day 10).
- Reads as: modern, professional, with personality — the typeface equivalent of "serious conference with a human side."

**Body / UI: `Inter`** — already in the repo, used as body in Day 19. But Day 20 uses it differently: **only for body text and UI labels**, while Familjen Grotesk handles ALL headings. The pairing is untried in the roadmap (prior Inter uses either went all-Inter or paired with a serif display face).

Actually, to be fully distinct: use **`Syne`** (Google Fonts, `@fontsource/syne`) as the display font instead. Syne is a geometric sans with sharp, architectural character — used on art festival and design conference sites. Completely untaken.

**Final typography decision:**
- **Display / headings:** `Syne` weight 700/800 — architectural, sharp, festival-grade
- **Body / UI:** `Inter` weight 400/500/600 — reliable, readable at any size

**Rationale for Syne:** Architecture students, design conference orgs, and cultural institutions use Syne for its "structure meets creativity" personality. At 100px on a dark background, conference names look like poster design. Untaken in all 19 prior days.

---

## Layout & Density Profile

**Dark-default, multi-section, high-density editorial.**

Distinct from all prior dark templates:
- Day 1 (developer-portfolio): sparse prose, personal
- Day 3 (startup-waitlist): single-screen countdown
- Day 10 (open-source-project): OSS-tool register
- Day 13 (AI startup): futurist, benchmark-focused
- Day 19 (podcast-site): studio aesthetic, audio-first

Conference register: **event poster meets professional program.** Think printed conference brochure adapted for screen — structured grids, speaker headshots in rigid card layout, schedule as a table/grid, sponsor logos as a horizontal tier band.

**Sections (in order):**
1. **Hero** — Date + city band at top, conference name in massive Syne, tagline, two CTAs ("Get Tickets →" + "View Speakers ↓"). Subtle emerald diagonal accent stripe. No countdown timer (that's startup-waitlist territory).
2. **Stats bar** — "12 speakers · 2 tracks · 400 attendees · 2 days" inline strip.
3. **Why Attend** — 3-column feature grid. Icons (inline SVG), bold heading, 2-line description. Tone: "Grow your network", "Level up your craft", "Ship inspired".
4. **Speakers** — 3×2 grid (6 speakers) with photo placeholder (CSS gradient avatar), name in Syne 700, job title, company, talk title. Each card links to an anchor on the schedule. `Person` JSON-LD for each.
5. **Schedule** — Two-column tab layout (Day 1 / Day 2). Each session row: time, track badge (Track A / Track B), session title, speaker name, room. Compact table-style with alternating row backgrounds.
6. **Tickets** — 3 pricing tiers (horizontal cards on desktop, stacked on mobile):
   - **Early Bird** — $299 · Available until May 1 · All sessions + lunch + workshop
   - **Standard** — $449 · Full conference access
   - **Team (5+)** — $349/pp · Bulk discount, invoice available
   Features comparison list below. Primary CTA: "Get Tickets →" (links to Tito/Eventbrite placeholder). `Offer` JSON-LD for each tier.
7. **Sponsors** — Tiered layout: Title sponsor (large, centered), Gold (medium, 3 across), Silver (small, 4-5 across), Community (text list). Each tier has a distinct header label. "Become a sponsor →" CTA links to a sponsor prospectus email.
8. **Venue + Travel** — Split layout: left = venue card (name, address, photo placeholder CSS gradient, "View on Google Maps →"), right = travel tips (2-3 closest airports, hotel partner discount, transit options). `Place` JSON-LD.
9. **FAQ** — 6 questions in two-column accordion layout. Real questions: refunds, recording policy, student discounts, code of conduct, remote attendance, CFP. `FAQPage` JSON-LD.
10. **Code of Conduct** — Prominent single-section: "We enforce a strict code of conduct. Read it →" + brief 3-bullet summary. Distinct emerald-border callout box.
11. **Footer** — Conference name, dates, city, social links (Twitter/X, LinkedIn, YouTube, newsletter), email. Copyright. LinkedIn primary per project convention.

---

## Schema.org JSON-LD

**Primary type: `Event`** (distinct from Day 18's `Course` + `CourseInstance`)

```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Event",
      "name": "OpenSignal Summit 2026",
      "startDate": "2026-09-15",
      "endDate": "2026-09-16",
      "eventStatus": "https://schema.org/EventScheduled",
      "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode",
      "location": { "@type": "Place", ... },
      "organizer": { "@type": "Organization", ... },
      "offers": [{ "@type": "Offer", ... }],
      "performer": [{ "@type": "Person", ... }]
    },
    { "@type": "Place", "name": "Moscone Center West", ... },
    { "@type": "FAQPage", ... }
  ]
}
```

This schema combination (`Event` + `Place` + `Offer` + `FAQPage` + `Person`) is specifically called out in the brief as the differentiator from Day 18's `Course` + `CourseInstance` schema.

---

## Persona

**Event organizer profile:**
- Running a 200–500 person developer or product conference
- Has a working Tito or Eventbrite for ticket sales — wants a marketing site that converts
- May also organize regional meetups or community events
- Budget: lean (community-run) to mid-size (company-sponsored)
- Needs: speaker grid, schedule, ticket pricing, sponsor logos, venue info — all in one template

---

## Differentiation Summary

| Axis | Day 20 (conference-event) | Closest prior |
|------|--------------------------|---------------|
| Accent color | Emerald `#10B981` on dark | Teal Day 10 (different: Day 10 is cyan-teal on dark; emerald is yellow-green) |
| Background | `#0E1117` blue-tinted near-black | Day 1 `#111827` (more neutral) |
| Display font | Syne (architectural grotesque) | Untaken — no prior day |
| Body font | Inter (body-only role) | Used in 7 prior but always differently |
| Layout | Event poster / conference program | Untaken niche |
| Density | High editorial dark, multi-section | Most similar: Day 13 (AI) — but very different content type |
| Schema | Event + Place + Offer + FAQPage | Day 18 was Course + CourseInstance |
| Sections | Speakers + Schedule + Sponsors + Venue + Tickets | Unique — no prior template has this set |

---

## Technical Notes

- **Fonts:** `@fontsource/syne` (weights 400, 700, 800) + `@fontsource/inter` (400, 500, 600)
- **No countdown timer** — startup-waitlist owns that. Conference dates are static text.
- **Schedule data:** Defined in `src/data/schedule.ts` as a typed array, rendered as a component, not hardcoded in markup.
- **Speakers data:** `src/data/speakers.ts` — name, title, company, talk, bio excerpt, social link.
- **Sponsors data:** `src/data/sponsors.ts` — name, tier, website, logo placeholder (inline SVG text marks).
- **Ticket tiers:** `src/data/tickets.ts` — price, name, features array, availability.
- **A11y rules enforced:**
  - No opacity modifiers on accent text
  - `role="listitem"` only on `<li>` elements
  - `aria-label` matches visible text or omitted
  - All interactive elements have `:focus-visible` ring in emerald
- **Assets:** `og-image.svg` (1200×630), `favicon.svg`, `favicon.ico`
- **Lighthouse:** `startServerCommand: "PUBLIC_BASE_PATH=/ npm run preview -- --host 127.0.0.1 --port 4321"`
