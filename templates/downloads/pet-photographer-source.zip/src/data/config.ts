// Good Dog Standard — Missoula, MT.
//
// Ninth photography template, ninth axis: who is actually in charge.
//
// Every other page in this run had a photographer controlling the frame. Here
// the subject does, and the honest inventory of the job is a short list of
// things you can ask an animal for and a longer list of things you cannot.

export const site = {
  name:        'Good Dog Standard',
  shortName:   'Good Dog',
  title:       'Good Dog Standard — Pet Photography in Missoula, MT',
  tagline:     'You cannot direct a dog.',
  owner:       'Rowan Achterberg',
  ownerRole:   'Pet photographer',
  credential:  'Studio and at-home sessions · Missoula',
  license:     'Pet photography, working since 2018',
  city:        'Missoula',
  state:       'MT',
  language:    'en',
  phoneDisplay: '(406) 555-0128',
  phoneHref:   '+14065550128',
  email:       'hello@gooddogstandard.example',
  streetAddress: '431 N Higgins Ave',
  postalCode:  '59802',
  hours:       'Sessions Wed–Sun · senior sessions first thing, any day',
  bookingWindow: 'Two sessions a day. Senior and end-of-life bookings jump the queue.',
  description:
    'Pet photography in Missoula. Every technique in this trade is a way of asking, and ' +
    'the animal is allowed to say no — so this page publishes what can actually be asked ' +
    'for, what cannot, and how long the waiting takes.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'What we can ask', href: '#asks' },
  { label: 'Subjects',        href: '#subjects' },
  { label: 'Senior sessions', href: '#senior' },
  { label: 'Rates',           href: '#rates' },
  { label: 'Book',            href: '#book' },
];

// ── What can and cannot be asked ──────────────────────────────────────────

export const asks = {
  can: [
    { ask: 'A direction to look',        how: 'A sound behind the camera. It works once, sometimes twice, and then that sound is spent for the day.' },
    { ask: 'Two or three seconds still', how: 'A sit or a down they already know, from their own person, not from me.' },
    { ask: 'A head tilt',                how: 'An unfamiliar noise at the right moment. Genuinely the whole trick, and it has a short shelf life.' },
    { ask: 'Ears forward',               how: 'Interest. Something new appearing at the edge of the room does it; asking does not.' },
    { ask: 'To come toward the lens',    how: 'Their person standing behind me. This is where the good frames usually come from.' },
  ],
  cannot: [
    { ask: 'Hold an expression',   why: 'A dog\'s face changes four times a second. You wait for one and take it; you do not extend it.' },
    { ask: 'A specific pose on request', why: 'Even a trained dog gives you their version of it, which is often better and never the one in your head.' },
    { ask: 'Two animals looking the same way', why: 'Possible, and it is a composite or forty minutes of luck. We will tell you which we did.' },
    { ask: 'Anything from a frightened animal', why: 'A scared dog photographs as a scared dog. The session stops and we try a different day.' },
    { ask: 'A cat to do anything at all', why: 'You photograph a cat where it has decided to be. That is not a joke, it is the entire method.' },
    { ask: 'To ignore their own person', why: 'A dog looks at the person they love, not at a stranger with a camera. Which is why that person stands behind the lens rather than out of the room.' },
    { ask: 'Impulse control from a puppy', why: 'Under about twelve weeks there is none to draw on. Puppy sessions are shorter, messier, and priced the same.' },
    { ask: 'A repeat of something that just worked', why: 'The good frame is usually the first time a sound is heard. Doing it again gets you a dog who has heard that sound before.' },
  ],
  note:
    'The left column is short and the right one is long, and that ratio is why a session is ' +
    'ninety minutes for maybe twenty-five keepers. Most of the time we are waiting for ' +
    'something on the left to happen by itself.',
};

// ── The session ───────────────────────────────────────────────────────────

export const session = {
  intro: 'A studio session, minute by minute. Almost none of it is photography.',
  steps: [
    { mins: '0–15',  what: 'The dog explores, nobody photographs',  note: 'The camera is out and on the floor. An animal that has already sniffed the tripod is not startled by it later.' },
    { mins: '15–30', what: 'First frames, expect nothing',           note: 'These are almost never used. They exist so the shutter becomes boring.' },
    { mins: '30–60', what: 'The working stretch',                    note: 'Where most of the delivered set comes from. Their person is behind me the whole time.' },
    { mins: '60–75', what: 'Treats and sounds, sparingly',           note: 'Each sound works once. Spending them early is the most common amateur mistake.' },
    { mins: '75–90', what: 'Tired dog, different pictures',          note: 'A settled, sleepy animal gives you the calm frames you cannot get in the first hour.' },
  ],
  closing:
    'If it is not working by minute sixty it is usually not going to, and we stop and rebook ' +
    'rather than push. That costs nothing and it has never once made the pictures worse.',
};

// ── Subjects ──────────────────────────────────────────────────────────────
// Alt strings written from the files. Each frame illustrates one point.

export const subjects = [
  {
    file: 'a01.jpg', title: 'Black dogs',
    lesson: 'The hardest common subject. Black fur reflects so little that an exposure correct for the room leaves the dog a silhouette, and one correct for the dog blows out everything else. The answer is separation — a rim light, and a background that is not the same value as the coat. This frame keeps only the eye and the nose, which is a decision rather than an accident.',
    said: 'Nobody has ever managed to photograph her. I assumed it was the dog.',
    who: 'Perpetua, about Juno',
    cap: 'Black coat on black · rim light only',
    alt: 'A black dog in profile against a near-black background, only the eye and the nose catching light',
  },
  {
    file: 'a02.jpg', title: 'A settled dog',
    lesson: 'What thirty minutes of doing nothing buys. Ears forward, weight even, eyes on the person behind the lens rather than on the lens. Nothing here was asked for in the moment — it was waited for.',
    said: 'He sat like that for four seconds. He has never done it since.',
    who: 'Emeka, about Sabre',
    cap: 'Studio · minute 44 · no treat used',
    alt: 'A silver-grey Weimaraner facing the camera against a black background, ears hanging forward',
  },
  {
    file: 'a03.jpg', title: 'Cats',
    lesson: 'You do not pose a cat, you photograph where it has decided to be, so cat sessions happen at home and run longer. This one chose the top of a bookcase and stayed there for the entire session, which is a normal outcome and not a failed one.',
    said: 'I said she would not come down and you said that was fine.',
    who: 'Rosalind, about Beatrix',
    cap: 'At home · where she chose · 2 hours',
    alt: 'A long-haired grey cat with amber eyes staring straight ahead against a dark background',
  },
  {
    file: 'a04.jpg', title: 'What actually happens',
    lesson: 'Ask a dog to come toward the lens and this is frequently the result: a nose at minimum focus distance and an expression nobody planned. Half the delivered set on a good day looks more like this than like the portrait above it.',
    said: 'This is the one we framed. Not the nice one — this one.',
    who: 'Tobias, about Wren',
    cap: 'Nose at minimum focus · kept anyway',
    alt: 'A tan and black dog filling the frame from below on white, nose closest to the lens',
  },
];

// ── Senior sessions ───────────────────────────────────────────────────────

export const senior = {
  headline: 'About a third of our sessions are for a dog who is running out of time.',
  body:
    'It is a large and quiet part of this trade and almost nobody puts it on a website. ' +
    'We do these, and here is exactly how they run, so that nobody has to ask.',
  points: [
    { k: 'At home',        v: 'Always',   n: 'No car journey, no strange room, no stairs. We come to whichever room they already sleep in.' },
    { k: 'Time of day',    v: 'First thing', n: 'Most old dogs are at their best in the morning. Sessions are booked at 8am for that reason.' },
    { k: 'Length',         v: '45 min',   n: 'Shorter, and it stops the moment they are tired rather than at a time on a schedule.' },
    { k: 'Turnaround',     v: '3 days',   n: 'Not three weeks. Families booking these sessions are frequently working to a horizon.' },
    { k: 'The queue',      v: 'Skipped',  n: 'If you tell us it is urgent we will believe you and find a morning this week.' },
    { k: 'Hands in frame', v: 'Encouraged', n: 'A hand on a head is the picture people keep. Ask for it — most people are too polite to.' },
  ],
};

export const rates = {
  rows: [
    { what: 'Studio session',        figure: '$320', note: '90 minutes, 25–35 finished images.' },
    { what: 'At-home session',       figure: '$385', note: 'Required for cats, and better for anxious dogs.' },
    { what: 'Senior or end-of-life', figure: '$285', note: 'Shorter, at home, three-day turnaround, and it jumps the queue.' },
    { what: 'Second animal',         figure: '$60',  note: 'Two animals in one frame is a composite or luck; either way we will say which.' },
    { what: 'Print licence',         figure: 'Included', note: 'Perpetual, any size. No per-print charges, ever.' },
    { what: 'Rebook if it is not working', figure: '$0', note: 'Called by us or by you, at any point in the session.' },
  ],
};

export const faqs = [
  {
    q: 'My dog will not sit still. Is that a problem?',
    a: 'No, and it is not unusual. Nothing on this page depends on a dog sitting still on request — the session is built around waiting for a few seconds of stillness that arrive on their own. Ninety minutes is long enough for that to happen many times.',
  },
  {
    q: 'Can you photograph my black dog?',
    a: 'Yes, and it is the hardest common subject rather than an impossible one. Black fur needs separation: a rim light and a background that is not the same value as the coat. It takes longer and the results are worth it.',
  },
  {
    q: 'Will you use treats?',
    a: 'Sparingly, with your permission, and yours rather than mine if there are allergies. Every sound and every treat works about once, so spending them in the first ten minutes is how a session gets wasted.',
  },
  {
    q: 'What about a nervous or reactive dog?',
    a: 'A slower session at home, no flash, no strangers, and we will stop early if that is the right thing. Some animals should not be photographed that particular week and saying so is part of the job rather than a failure of it.',
  },
  {
    q: 'Can I be in the pictures?',
    a: 'Please. You are behind the camera for most of the session anyway, and a hand on a head is the frame families keep. Ask for it — most people are too polite to and then wish they had.',
  },
  {
    q: 'Our dog is very old. How soon can you come?',
    a: 'This week. Senior sessions jump the queue, run at 8am, happen at home, last about 45 minutes and come back in three days. If you tell us it is urgent we will believe you.',
  },
];
