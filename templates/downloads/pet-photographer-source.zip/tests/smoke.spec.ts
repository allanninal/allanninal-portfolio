import { test, expect } from '@playwright/test';

test.describe('Good Dog Standard — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Good Dog Standard/);
    await expect(page.locator('h1')).toContainText('cannot direct a dog');
  });

  test('handles the schema.org photographer gap', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
  });

  // ── The spine ───────────────────────────────────────────────────────────
  test('the headline counts are derived from the two lists', async ({ page }) => {
    await page.goto('/');
    const can = await page.locator('#asks .ask-col--can li').count();
    const cannot = await page.locator('#asks .ask-col:not(.ask-col--can) li').count();
    await expect(page.locator('#asks h2'))
      .toContainText(`${can} things we can ask for. ${cannot} we cannot`);
  });

  // The page claims the second list is longer. It has to actually be longer.
  test('there really are more things that cannot be asked than can', async ({ page }) => {
    await page.goto('/');
    const can = await page.locator('#asks .ask-col--can li').count();
    const cannot = await page.locator('#asks .ask-col:not(.ask-col--can) li').count();
    expect(cannot).toBeGreaterThan(can);
    await expect(page.locator('#asks')).toContainText(/left column is short and the right one is long/i);
  });

  test('every entry in both lists explains itself', async ({ page }) => {
    await page.goto('/');
    const spans = await page.locator('#asks .ask-col li span').allTextContents();
    expect(spans.length).toBeGreaterThanOrEqual(13);
    for (const s of spans) expect(s.trim().length).toBeGreaterThan(30);
  });

  // Word-first: the two columns must be distinguishable without colour.
  test('the two columns are labelled in words, not only by colour', async ({ page }) => {
    await page.goto('/');
    const heads = await page.locator('#asks .ask-col h3').allTextContents();
    expect(heads.map((h) => h.trim())).toEqual(['What can be asked', 'What cannot']);
  });

  // The timeline lives inside the toolkit section, because it is the
  // explanation of the ask/cannot ratio rather than a separate argument.
  test('the session timeline sits with the toolkit it explains', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#asks .shape li').count()).toBe(5);
    await expect(page.locator('#asks h3').last()).toContainText(/ninety minutes/i);
    await expect(page.locator('#asks')).toContainText(/stop and rebook/i);
  });

  test('each subject carries the owner\'s own line about the animal', async ({ page }) => {
    await page.goto('/');
    const quotes = page.locator('#subjects blockquote.said');
    expect(await quotes.count()).toBe(4);
    for (const q of await quotes.all()) {
      await expect(q.locator('cite')).toHaveCount(1);
      expect(((await q.textContent()) || '').trim().length).toBeGreaterThan(30);
    }
  });

  // The quiet part of the trade.
  test('senior sessions are published with their real terms', async ({ page }) => {
    await page.goto('/');
    const s = page.locator('#senior');
    await expect(s).toContainText(/running out of time/i);
    expect(await s.locator('.terms .term').count()).toBe(6);
    await expect(s).toContainText('3 days');
    await expect(s).toContainText(/Skipped/);
    await expect(page.locator('#rates')).toContainText(/jumps the queue/i);
  });

  test('every subject image has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#subjects img').evaluateAll((els) =>
      els.map((e) => ({ alt: e.getAttribute('alt') || '', w: e.getAttribute('width'), h: e.getAttribute('height') })));
    expect(imgs.length).toBe(4);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.w).toBeTruthy(); expect(i.h).toBeTruthy();
    }
  });

  test('all subject images load', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')));
    expect(broken).toEqual([]);
  });

  test('each subject carries a lesson, not just a caption', async ({ page }) => {
    await page.goto('/');
    const lessons = await page.locator('#subjects .lesson').allTextContents();
    expect(lessons.length).toBe(4);
    for (const l of lessons) expect(l.trim().length).toBeGreaterThan(120);
    await expect(page.locator('#subjects')).toContainText(/Black coat on black/i);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-98 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['halló', 'burlington', 'newborn', 'swaddle', 'spotter', 'gowun']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro session kit is absent from the free build', async ({ page }) => {
    const res = await page.goto('/session-kit/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
