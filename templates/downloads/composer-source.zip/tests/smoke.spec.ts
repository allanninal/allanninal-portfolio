import { test, expect } from '@playwright/test';

test.describe('Aurelio Sandoval — smoke tests', () => {
  test('homepage renders with the composer name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Aurelio Sandoval/);
    await expect(page.locator('h1')).toContainText(/\d+ works\. \d+ have been played twice\./);
  });

  // Seventh schema shape in seven days. MusicGroup is right for a performing
  // act and wrong for somebody whose output is scores other people play.
  test('is a Person with works, not a MusicGroup', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(json).toContain('"Person"');
    expect(json).toContain('MusicComposition');
    expect(json).not.toContain('"MusicGroup"');
    expect(json).not.toContain('"member"');
  });

  // An unperformed piece is real and belongs on the page; emitting it as a
  // structured work asserts a public existence it does not have.
  test('only performed works are emitted as compositions', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('workExample')) || '');
    const schema = JSON.parse(raw);
    const counts = (await page.locator('#works .plays').allTextContents())
      .map((t) => Number((t.trim().match(/^\d+/) || ['0'])[0]));
    const performed = counts.filter((c) => c > 0).length;
    const never = counts.filter((c) => c === 0).length;
    expect(never).toBeGreaterThan(0);
    expect(schema.workExample.length).toBe(performed);
  });

  test('the spine is visible, not just present in the DOM', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#works table.works');
    await expect(t).toBeVisible();
    expect((await t.boundingBox())!.height).toBeGreaterThan(400);
  });

  // ── The catalogue ───────────────────────────────────────────────────────
  test('every work carries a performance count and a state in words', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#works tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(10);
    for (const r of await rows.all()) {
      const cell = ((await r.locator('.plays').textContent()) || '').trim();
      expect(cell).toMatch(/^\d+/);
      const state = ((await r.locator('.plays .state').textContent()) || '').trim();
      expect(['Never performed', 'Premiere only', 'Played again']).toContain(state);
    }
  });

  test('the tallies are counted from the catalogue', async ({ page }) => {
    await page.goto('/');
    const counts = (await page.locator('#works .plays').allTextContents())
      .map((t) => Number((t.trim().match(/^\d+/) || ['0'])[0]));
    const again = counts.filter((c) => c > 1).length;
    const never = counts.filter((c) => c === 0).length;
    const total = counts.reduce((a, b) => a + b, 0);
    const dd = page.locator('#works dl.tally dd');
    await expect(dd.nth(0)).toHaveText(String(counts.length));
    await expect(dd.nth(1)).toHaveText(String(again));
    await expect(dd.nth(2)).toHaveText(String(never));
    await expect(page.locator('#works caption'))
      .toHaveText(`${total} performances across ${counts.length} works`);
    await expect(page.locator('h1')).toContainText(`${counts.length} works. ${again} have been played twice.`);
  });

  test('unperformed works are listed with a reason, not hidden', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#works tbody tr');
    let found = 0;
    for (const r of await rows.all()) {
      const cell = ((await r.locator('.plays').textContent()) || '').trim();
      if (cell.startsWith('0')) {
        found++;
        expect(((await r.locator('td').last().textContent()) || '').length).toBeGreaterThan(50);
      }
    }
    expect(found).toBeGreaterThan(0);
    await expect(page.locator('#works')).toContainText(/hides which\s+is which/i);
  });

  // Nothing on this page is a failure, so nothing on it is red.
  test('the played-again state is not the accent, and is not a warning colour', async ({ page }) => {
    await page.goto('/');
    const c = await page.evaluate(() => {
      const s = getComputedStyle(document.documentElement);
      return ['--again-yes', '--color-accent'].map((k) => s.getPropertyValue(k).trim());
    });
    expect(new Set(c).size).toBe(2);
  });

  // ── Rights ──────────────────────────────────────────────────────────────
  test('the rights list says copyright does not transfer by default', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#rights .rights > div');
    expect(await rows.count()).toBeGreaterThan(4);
    await expect(page.locator('#rights')).toContainText(/Stays with me/);
    await expect(page.locator('#rights')).toContainText(/opposite of the default in film/i);
  });

  test('the adjective list gives a replacement for every phrase', async ({ page }) => {
    await page.goto('/');
    const items = page.locator('#briefs .adj li');
    const n = await items.count();
    expect(n).toBeGreaterThan(3);
    for (const i of await items.all()) {
      await expect(i.locator('.instead b')).toHaveText('Send instead');
      expect(((await i.locator('.instead').textContent()) || '').length).toBeGreaterThan(40);
    }
    await expect(page.locator('#briefs h2')).toContainText(`${n} adjectives`);
  });

  test('the page does not blame commissioners for using adjectives', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#briefs')).toContainText(/None of this is a complaint about people who commission/i);
  });

  test('there are no photographs', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('img').count()).toBe(0);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('scores are offered without a form gate', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#contact')).toContainText(/no form gate|free and sent the same day/i);
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('no trace of the day-114 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['bellwether', 'asheville', 'songwriting split', 'former member', 'who owns the name']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro commission agreement is absent from the free build', async ({ page }) => {
    const res = await page.goto('/commission-agreement/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
