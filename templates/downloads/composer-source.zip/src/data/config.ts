// Aurelio Sandoval — Santa Fe, NM. Fictional.
//
// Every composer's works list gives a title, a year and an instrumentation.
// None gives the number a programmer actually wants: has anybody played this
// since the premiere? For most new concert works the answer is no.

export const site = {
  name:        'Aurelio Sandoval',
  shortName:   'Aurelio Sandoval',
  title:       'Aurelio Sandoval — composer, Santa Fe',
  tagline:     'Fourteen works. Six have been played twice.',
  owner:       'Aurelio Sandoval',
  ownerRole:   'Composer',
  credential:  'Concert and chamber music since 2012',
  city:        'Santa Fe',
  state:       'NM',
  language:    'en',
  phoneDisplay: '(505) 555-0173',
  phoneHref:   '+15055550173',
  email:       'aurelio@aureliosandoval.example',
  streetAddress: '418 Montezuma Ave',
  postalCode:  '87501',
  hours:       'Writing mornings · everything else after two',
  bookingWindow: 'Commissions for 2028 · scores on request, free',
  description:
    'A composer in Santa Fe. Every catalogue on the internet lists a title, a year and an ' +
    'instrumentation. This one adds the column programmers actually want and nobody publishes: ' +
    'how many times each piece has been played since its premiere.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'Catalogue', href: '#works' },
  { label: 'Rights',    href: '#rights' },
  { label: 'Briefs',    href: '#briefs' },
  { label: 'Contact',   href: '#contact' },
];

// ── The catalogue ─────────────────────────────────────────────────────────
// `plays` counts performances INCLUDING the premiere. Three are zero.

export const works = [
  { title: 'Cinder Antiphon',      year: 2025, dur: "11'", forces: 'String quartet',              plays: 1, note: 'Premiered in March. Nobody has programmed it since, which at eight months is neither surprising nor a good sign.' },
  { title: 'Salt Cantos',          year: 2025, dur: "24'", forces: 'Chamber orchestra',           plays: 0, note: 'Delivered, paid for, and not yet performed — the commissioning ensemble lost its season. This happens and the piece is not worse for it.' },
  { title: 'Second Room',          year: 2024, dur: "8'",  forces: 'Solo piano',                  plays: 9, note: 'The one that travels. Short, difficult in a way that reads as easy, and it fits at the end of almost any recital.' },
  { title: 'Marrow',               year: 2024, dur: "17'", forces: 'Soprano and ensemble',        plays: 2, note: 'Premiere and one revival. The text is in the public domain, which removes the single most common obstacle to a second performance.' },
  { title: 'Quarry Light',         year: 2023, dur: "14'", forces: 'Wind quintet',                plays: 5, note: 'Written for a competition it did not win, then taken up by two other groups. Losing was the best thing that happened to it.' },
  { title: 'The Longer Way',       year: 2023, dur: "31'", forces: 'Orchestra',                   plays: 1, note: 'One performance, and honestly the correct number so far. A thirty-one-minute orchestral piece by somebody with no name is a large ask.' },
  { title: 'Undertow',             year: 2022, dur: "6'",  forces: 'Cello and electronics',       plays: 7, note: 'The electronics run from a single stereo file, which is why it gets played. Anything needing a technician gets played half as often.' },
  { title: 'Beulah Street',        year: 2022, dur: "19'", forces: 'Choir, SATB divisi',          plays: 4, note: 'Choirs programme repertoire; that is the whole reason this number is higher than the orchestral one.' },
  { title: 'Iron Season',          year: 2021, dur: "22'", forces: 'Piano trio',                  plays: 3, note: 'Slow start, then two performances in one season after a recording appeared. Recordings are how a chamber piece finds its second life.' },
  { title: 'Kindling',             year: 2020, dur: "4'",  forces: 'Solo clarinet',               plays: 12, note: 'The most-played thing I have written, by a distance, because it is four minutes long and needs one person.' },
  { title: 'Low Water Mark',       year: 2019, dur: "27'", forces: 'Orchestra and choir',         plays: 0, note: 'Never performed. Written speculatively, which is a mistake I made once and would not repeat at this scale.' },
  { title: 'Dryland',              year: 2018, dur: "13'", forces: 'Percussion quartet',          plays: 6, note: 'Percussion groups are the most adventurous programmers in the field and this is the evidence.' },
  { title: 'First Position',       year: 2015, dur: "9'",  forces: 'Two violins',                 plays: 2, note: 'A teaching piece. Both performances were by students, which is the point of it.' },
  { title: 'Cane Break',           year: 2012, dur: "16'", forces: 'String orchestra',            plays: 0, note: 'The first thing I finished and the first thing I withdrew. It stays in the list because a catalogue that hides its beginning is not a catalogue.' },
];

export const worksNote =
  'Three of these have never been played and one of the three I withdrew myself. Publishing that ' +
  'costs nothing and answers the only question a programmer is really asking, which is whether ' +
  'anybody else has taken the risk first. The honest shape of a career in this field is a small ' +
  'number of pieces that travel and a larger number that do not, and a catalogue that hides which ' +
  'is which is not telling you about the music.';

// ── Rights ────────────────────────────────────────────────────────────────

export const rights = {
  intro:
    'The most misunderstood transaction in the field. A commissioner who believes they bought ' +
    'the music has usually bought a first performance, and neither side finds out until somebody ' +
    'wants to record it.',
  rows: [
    { k: 'Commission fee',       v: 'For the writing', n: 'It pays for the piece to exist and for you to give the premiere. It does not, on its own, transfer anything.' },
    { k: 'Exclusivity period',   v: '12 months',       n: 'Nobody else may perform it during that window. This is what a commissioner is usually actually buying and it is worth having in writing.' },
    { k: 'Copyright',            v: 'Stays with me',   n: 'Unless we agree otherwise in writing and the fee reflects it. This is the default in concert music and the opposite of the default in film.' },
    { k: 'Performance rights',   v: 'Through the society', n: 'Licensed collectively rather than by me. It is why a second performance costs a programmer nothing extra to arrange.' },
    { k: 'Recording',            v: 'Separate consent', n: 'A commercial recording is its own conversation. Free to agree, and not automatically included.' },
    { k: 'Buyout',              v: 'Possible, priced',  n: 'If you genuinely need to own it outright, say so at the start. It roughly doubles the fee and I will tell you honestly when you do not need it.' },
  ],
};

// ── Adjectives ────────────────────────────────────────────────────────────

export const adjectives = [
  { said: '"Epic but intimate"',   means: 'Usually: loud in one place and quiet everywhere else, with a solo line somebody can follow.',
    instead: 'Name the moment you want people to feel it, and how long the piece has to be.' },
  { said: '"Not too modern"',      means: 'Almost always: with a tonal centre. It is rarely about dissonance and usually about whether the ear knows where home is.',
    instead: 'Send two pieces you have programmed that audiences liked, and one you regretted.' },
  { said: '"Something like the temp"', means: 'That the temp track already solved the problem, which is useful information rather than an insult.',
    instead: 'Say which twenty seconds of the temp, and what it is doing there — tempo, register, or the fact that nothing happens.' },
  { said: '"Accessible"',          means: 'Playable by this ensemble in the rehearsal time they actually have.',
    instead: 'Tell me the number of rehearsals. It changes more about the piece than any adjective can.' },
  { said: '"Make it more emotional"', means: 'That a transition is not earning its arrival.',
    instead: 'Point at the bar. Nine times in ten the problem is thirty seconds earlier than the place it is felt.' },
];

export const adjectivesNote =
  'None of this is a complaint about people who commission music. Adjectives are how anybody ' +
  'talks about sound before there is a score to point at — the useful move is to translate them ' +
  'quickly and in writing, rather than to write eleven minutes of the wrong piece politely.';

export const said = {
  text: 'The performance count was the reason we programmed him. Every other catalogue I read that month told me what a piece was scored for. His told me which ones had survived contact with an audience.',
  who: 'Artistic director, chamber series — 2025',
};

export const faqs = [
  {
    q: 'Why publish performance counts?',
    a: 'Because it answers the question a programmer is actually asking — has anybody taken this risk before me — and because the alternative is a list that implies every piece is equally alive. A small number of pieces travel and most do not. That is the field, not a confession.',
  },
  {
    q: 'Three works have never been played. Should I be worried?',
    a: 'Two of them were written for situations that fell through, which happens constantly and says nothing about the music. The third I withdrew myself and it stays listed because a catalogue that hides its beginning is not a catalogue.',
  },
  {
    q: 'Can I see a score?',
    a: 'Yes, any of them, free and without a form. Perusal scores exist to be read and a composer who makes you ask twice is costing themselves performances.',
  },
  {
    q: 'Do I own the music if I commission it?',
    a: 'You own the premiere and an exclusivity period, and the copyright stays with me unless we agree otherwise and the fee reflects it. That is the norm in concert music and the reverse of the norm in film, which is where most of the confusion comes from.',
  },
  {
    q: 'How long does a commission take?',
    a: 'For a ten to fifteen minute chamber piece, four to six months from a signed agreement, of which the writing is about six weeks. The rest is the piece being wrong and then becoming right.',
  },
  {
    q: 'Will you write for amateur or student players?',
    a: 'Gladly, and it is harder rather than easier. The constraint that matters is rehearsal count, not ability — tell me how many and I will write something that can actually be finished.',
  },
];
