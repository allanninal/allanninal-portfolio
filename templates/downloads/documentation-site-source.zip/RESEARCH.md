# Documentation Site Template — Research Brief

> **Assumption:** Multi-page technical reference site for an indie open-source library, CLI tool, or SDK. The defining structural element: left sidebar categorical nav + main content with code blocks + right-side on-page TOC. Target author is a solo maintainer or small eng team shipping an OSS project that needs credible, scannable docs.

> **Fictional product chosen:** `routekit` — a zero-dependency TypeScript library for type-safe client-side routing. Small enough that the full API fits in docs; realistic enough that every section (install, quickstart, config, API reference, examples) has natural code-block density.

---

## Audience & primary CTA

- **Who visits:** Developers evaluating whether to adopt `routekit`; existing users looking up a specific API method or config option; contributors reading the architecture guide.
- **Primary CTA:** Install / copy the install command (`npm install routekit`) — the package name in the hero nav bar + a prominent code block on the landing page.
- **Secondary CTAs:** Star the GitHub repo; read the Getting Started guide; copy a code snippet.

---

## Reference sites (real businesses)

- https://htmx.org/docs/ — Densely nested left-nav with multi-level sections; attribute-reference tables; zero decoration; raw HTML prose. Proves deep nesting works for reference material. Weakness: no right TOC, no search, visually dated.
- https://bun.sh/docs — Card-based landing page with dual Shiki themes (github-light / dracula per page). File-path labels on code blocks (`terminal`, `index.tsx`). Clean two-panel layout. One of the best baseline docs UX in the ecosystem right now.
- https://docs.astro.build/en/getting-started/ — Four-section sidebar (Tutorial / Guide / Reference / Ecosystem). Multi-language toggle. Sponsor strip for credibility. Collapsible nav groups. Shiki code blocks with copy button. System dark/light toggle in top bar. Sets the bar for Starlight's own showcase.
- https://tailwindcss.com/docs/installation/using-vite — Numbered procedure steps (01, 02, 03). Language labels above every code block (`Terminal`, `vite.config.ts`, `CSS`, `HTML`). Version badge in nav. "Are you stuck?" callout box with icon. Breadcrumb trail. Best-in-class "getting started" procedural layout.
- https://tanstack.com/query/latest/docs/framework/react/overview — TSX code blocks with StackBlitz open-in-editor link. Emoji-sparse but strategically used. "You talked me into it" resource section anchored at the bottom of overview pages. Framework-switcher tab (React / Vue / Solid / Svelte) — most relevant multi-tab pattern in the niche.
- https://fly.io/docs/ — Illustration-driven hero (Frankie character); card-based category grid on the landing page; multiple parallel entry points (language quick-links + feature exploration). Differentiates from sterile API docs via personality. Collapsible sidebar with many top-level sections.
- https://vercel.com/docs — Categorical link-grid homepage (not a prose landing page). Deep sidebar (Build / Deploy / Collaborate / Secure). Clear `**Bold term**` + description list pattern for reference pages. Clean separation between conceptual and reference content.

---

## Existing templates surveyed

- https://starlight.astro.build — Default Starlight starter: ships sidebar, pagefind search, Shiki, dark mode, TOC, sitemap, robots.txt, 404 out of the box. Default palette is purple/violet accent on near-white/near-black with Inter font throughout. Weakness: ships on thousands of OSS sites unchanged — visually generic. No personality, no custom callout design, no demo product content.
- https://astro.build/themes/details/starlight-rapide — Inspired by VS Code Vitesse. Warm tones, clean typography. Still recognizably Starlight; no sidebar IA demonstration with real content.
- https://astro.build/themes/details/starlight-black — shadcn-inspired dark theme. Neutral gray/white on black. Strong for a dev tool but saturated — many repos are shipping this exact look now.
- **Saturated patterns:** Purple/violet Starlight default; pitch-black with white text; catppuccin pastel. These are the three most-cloned looks in the Starlight ecosystem right now.
- **Missing:** A Starlight template with (a) a fully customized non-purple palette, (b) IBM Plex typography, (c) a real fictional product with ≥10 MDX pages, (d) multi-language code tabs, (e) a landing page (`/`) distinct from the first doc page, (f) GH Pages deploy pre-wired.

---

## Decision: Use Starlight, heavily customized

**Yes, Starlight.** Pagefind search, right TOC, dark/light toggle, sidebar, MDX, Shiki, sitemap, robots.txt, 404 — all free. The risk (looking like every other Starlight site) is mitigated by: custom CSS variables overriding all color tokens, IBM Plex Sans + IBM Plex Mono as the type stack, a custom hero component on the root index page, and real content that demonstrates the template's range.

Building a custom docs layout from scratch would take 3–4× longer and produce a result that's harder to maintain and less accessible by default. Starlight's accessibility story (skip links, ARIA landmarks, keyboard nav) is production-grade.

---

## Must-have sections (in order)

### Pages / Sidebar IA (≥10 MDX pages)

1. **Landing page (`/`)** — NOT a doc page. A mini marketing page: headline, one-liner, install snippet, three feature cards, link to Get Started. Custom Starlight index component override.
2. **Getting Started (`/getting-started/`)** — Installation (npm/pnpm/bun tabs), quickstart in ≤10 lines of code, "Your first route" walkthrough.
3. **Guides / Basic routing** — Defining routes, nested routes, route params.
4. **Guides / Navigation** — `<Link>` component, programmatic `navigate()`, active-link styling.
5. **Guides / Code splitting** — Lazy routes, `Suspense` boundaries, loading states.
6. **API Reference / `createRouter()`** — Full function signature, options table, return type.
7. **API Reference / `<Router>`** — Props table, examples, caveats.
8. **API Reference / `useRoute()`** — Hook signature, return shape, code example.
9. **Reference / Configuration** — Config file schema (`routekit.config.ts`), all options with types and defaults.
10. **Reference / TypeScript** — Generic type params, `RouteDefinition<T>`, inference behavior.
11. **Examples / Basic SPA** — Full working example, embedded or linked StackBlitz.
12. **Examples / With data fetching** — Loader pattern, typed loader data.
13. **Changelog** — Recent versions, breaking-change callout style demonstrated.

---

## Design conventions

- **Typography:** **IBM Plex Sans** (body, UI, headings) + **IBM Plex Mono** (all code). Both from Google Fonts. IBM Plex Sans is humanist/technical — distinct from the geometric Inter (Days 1–3), DM Sans (Day 4), and Newsreader serif (Day 5). The Mono variant is optically matched to the Sans, so inline code sits harmoniously in prose. Body: `font-size: 1rem`, `line-height: 1.7`, `max-width: 72ch`. Headings: IBM Plex Sans 600.
- **Color palette:** **Deep cobalt accent** `#2563EB` (Tailwind blue-600) on a near-white base `#F8FAFC` (light mode) / near-black `#0F1117` (dark mode). None of the prior five days use blue. The palette reads "precision engineering tool" — neither the warmth of amber/coral nor the editorial green/cream. Secondary accent for callout borders: `#DBEAFE` (light) / `#1E3A5F` (dark). Text: `#0F172A` (light) / `#E2E8F0` (dark).
- **Imagery style:** No photography. Inline diagrams as committed SVGs where needed (e.g., router lifecycle diagram). Code blocks are the visual anchors. Icon set: Lucide (consistent with many OSS docs sites, low bundle cost, MIT licensed).
- **Density:** Medium. Sidebar always visible on desktop. Main content column ~72ch. Right TOC visible at ≥1280px. Inline code snippets and frequent H2/H3 headers create natural visual rhythm. Not sparse (unlike Day 4 personal-blog), not bento-dense (unlike Day 2 saas-landing).

---

## Trust signals to include

- GitHub star badge (shields.io static SVG, no JS) in the top nav
- npm version badge (shields.io static SVG) on the landing page
- "MIT License" chip in the footer
- Changelog page with real version history demonstrates the project is maintained
- `<packagename>.config.ts` type definitions shown in docs — signals TypeScript-first rigor
- Code blocks with real, runnable snippets (not `// TODO: example here`)

---

## SEO / schema.org

- **Type:** `TechArticle` on all doc pages. `WebSite` with `SearchAction` on the root. `SoftwareApplication` on the landing page (for the library itself).
- **Required properties on `TechArticle`:** `headline`, `description`, `url`, `datePublished`, `dateModified`, `author` (org), `inLanguage: "en"`, `about` (the library name).
- **`SoftwareApplication` on landing:** `name`, `url`, `applicationCategory: "DeveloperApplication"`, `operatingSystem: "Any"`, `license`, `codeRepository`.
- **Suggested OG image:** Library name in IBM Plex Mono bold on cobalt background, version number in smaller text, a faint grid/code pattern background. One static `og-default.png` committed; per-page override via Starlight's `head` frontmatter slot.

---

## Code block conventions

- **Renderer:** Starlight's built-in Shiki. Dual theme: `github-light` (light mode) / `one-dark-pro` (dark mode) — the cobalt accent pairs cleanly with One Dark Pro's blue/teal syntax highlights.
- **Language tabs:** Yes, for install commands (`npm | pnpm | bun | yarn`). Implemented via Starlight's `<Tabs>` component (built-in since Starlight 0.14). This is the highest-value interactive pattern in OSS docs.
- **Copy button:** Starlight ships this by default. Keep.
- **File labels:** Yes — `// routekit.config.ts` as a comment OR Starlight's `title` prop on code blocks.
- **Right TOC:** On. All doc pages. Off only on the custom landing page (`/`).
- **Pagefind search:** On. At ≥10 pages it provides genuine value. Starlight wires it automatically at build.

---

## Versioning decision

Single version only (v1). No `/v2/` path prefix, no version dropdown. Reasoning: versioned docs require either a monorepo multi-build or duplicated content; both are operationally complex for an indie maintainer. The Changelog page covers breaking changes. Version can be added in v2 of this template when there is demonstrated demand.

---

## Static-only fit

No concerns. Every feature works at build time or client-side:

- **Search:** Pagefind runs post-build, generates a static index. Zero server.
- **Code tabs:** Starlight `<Tabs>` component is pure client-side JS (no server needed).
- **Shields.io badges:** Static SVG `<img>` tags (shields.io serves them; no JS).
- **Dark mode toggle:** Starlight ships this via `localStorage` + CSS custom properties.
- **Changelog:** Static MDX page, manually maintained.
- **StackBlitz links in Examples:** External links only — no embedding required. Embed is optional via `<iframe>` if the author wants it; no server dependency.

---

## Differentiation — what we'll do better

1. **IBM Plex Sans + IBM Plex Mono.** No existing Starlight theme ships this stack. It reads "IBM engineering precision" — appropriate for a developer tool. Visually distinct from Inter (the default) and every prior day in this sprint.
2. **Cobalt `#2563EB` accent, not purple.** The default Starlight purple is shipped by thousands of repos. Cobalt is fresh and equally readable at WCAG AA.
3. **Separate landing page (`/`).** Default Starlight treats the root as the first doc page. We ship a mini marketing page that explains what the library does BEFORE jumping into docs — critical for adoption by new visitors arriving from a GitHub README link.
4. **Multi-language install tabs out of the box.** `npm | pnpm | bun | yarn` — the single most-copied pattern from Bun/Tailwind/Astro docs. Not present in the default Starlight starter content.
5. **Real fictional product content (≥10 MDX pages).** The default Starlight starter ships three placeholder pages that say "Replace this content." Our template ships a complete, coherent `routekit` docs set — the user can search it, browse the TOC, test the sidebar IA depth, and see what a real project looks like.
6. **Callout component showcase.** Starlight ships `<Aside>` (note/tip/caution/danger). We use all four variants in the content with real copy, so the author can see the design working before they write a word.
7. **GH Pages deploy pre-wired.** `base` path set, `pages.yml` workflow included, `site:` in `astro.config.mjs` — the three things Starlight's own starter doesn't pre-configure for GitHub Pages.

---

## Explicitly NOT building

- **Versioned docs** — see decision above. One version, one deploy.
- **i18n / multi-language** — Starlight supports it via `locales` config; out of scope for v1. Adds directory nesting complexity and doubles content maintenance.
- **AI chat widget** — LLM-based doc search (Inkeep, Kapa, Mintlify Chat) requires a third-party API key and a server relay. Incompatible with static + MIT + free. pagefind covers 95% of the use case.
- **In-page editing ("Edit this page on GitHub")** — Starlight supports it via `editLink` config. We leave the config key as a commented placeholder — the author adds their repo URL in one line. Not wired by default because the placeholder URL would 404.
- **Comments / feedback widgets** — Out of scope. GitHub Issues is the static substitute.
- **API playground / live sandbox** — Requires a server or WASM runtime. StackBlitz `<iframe>` in Examples pages covers the interactive demo use case statically.
- **Algolia DocSearch** — Requires application approval and an API key. Pagefind is self-hosted, zero-config, and sufficient at this scale.
