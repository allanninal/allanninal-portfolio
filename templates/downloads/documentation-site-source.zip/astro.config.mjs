import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';

const SITE = process.env.PUBLIC_SITE_URL || 'https://www.allanninal.dev';
const BASE = process.env.PUBLIC_BASE_PATH || '/documentation-site/';
const siteUrl = SITE.endsWith('/') ? SITE.slice(0, -1) : SITE;

// Google Analytics + AdSense — only injected on the author's deploy (the
// hub env var is set in apps/showcase + per-template build envs at
// .github/workflows/pages.yml, never in cloning users' deploys).
const HUB = process.env.PUBLIC_TEMPLATE_HUB_URL;
// Pro edition (PUBLIC_EDITION=pro) surfaces the standalone Advanced Patterns
// guide in the sidebar. The free edition omits it and redirects the route.
const IS_PRO = process.env.PUBLIC_EDITION === 'pro';
const analyticsHead = HUB
  ? [
      {
        tag: 'script',
        attrs: { async: true, src: 'https://www.googletagmanager.com/gtag/js?id=G-DLRBEQ85ZN' },
      },
      {
        tag: 'script',
        content:
          "window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','G-DLRBEQ85ZN');",
      },
      {
        tag: 'meta',
        attrs: { name: 'google-adsense-account', content: 'ca-pub-3474747237489350' },
      },
      {
        tag: 'script',
        attrs: {
          async: true,
          src: 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3474747237489350',
          crossorigin: 'anonymous',
        },
      },
    ]
  : [];

export default defineConfig({
  site: siteUrl,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  integrations: [
    starlight({
      title: 'routekit',
      description:
        'Type-safe client-side routing for TypeScript. Zero dependencies, ~3 KB minified, designed to fit in your head.',
      logo: { src: './src/assets/logo.svg', replacesTitle: false },

      // Pagefind search — on. Static, runs at build.
      pagefind: true,
      // Right-side TOC — h2 + h3 (default) is the right depth for our content density.
      tableOfContents: { minHeadingLevel: 2, maxHeadingLevel: 3 },
      // Last-updated date in the footer of each doc page.
      lastUpdated: true,
      credits: false,

      // (No social.github — the source repo is private; users get the source
      // via the ZIP download surfaced by the TemplateInfo bar.)

      // ── Theming ─────────────────────────────────────────────────────────────
      // Custom CSS lives in src/styles/custom.css. It overrides --sl-color-*
      // tokens and registers IBM Plex Sans + Mono. The font CSS is registered
      // here too so Starlight bundles it correctly.
      customCss: [
        './src/styles/fonts.css',
        './src/styles/custom.css',
      ],

      // Dual Shiki theme — github-light (light mode) + one-dark-pro (dark mode).
      // Cobalt accent pairs cleanly with One Dark Pro's blue/teal syntax tones.
      expressiveCode: {
        themes: ['github-light', 'one-dark-pro'],
        styleOverrides: {
          borderRadius: '0.5rem',
        },
      },

      // ── Navigation IA ───────────────────────────────────────────────────────
      sidebar: [
        { label: 'Overview', link: '/' },
        {
          label: 'Getting Started',
          items: [
            { slug: 'getting-started/installation' },
            { slug: 'getting-started/quickstart' },
            { slug: 'getting-started/your-first-route' },
          ],
        },
        {
          label: 'Guides',
          items: [
            { slug: 'guides/basic-routing' },
            { slug: 'guides/navigation' },
            { slug: 'guides/code-splitting' },
          ],
        },
        // Pro-only: the Advanced Patterns guide (a standalone StarlightPage).
        ...(IS_PRO
          ? [{ label: 'Advanced Patterns', link: '/advanced-patterns/', badge: { text: 'Pro', variant: 'tip' } }]
          : []),
        {
          label: 'API Reference',
          items: [
            { slug: 'reference/create-router' },
            { slug: 'reference/router-component' },
            { slug: 'reference/use-route' },
            { slug: 'reference/configuration' },
            { slug: 'reference/typescript' },
          ],
        },
        {
          label: 'Examples',
          collapsed: true,
          items: [
            { slug: 'examples/basic-spa' },
            { slug: 'examples/data-fetching' },
          ],
        },
        {
          label: 'Changelog',
          link: '/changelog/',
        },
      ],

      // Edit-this-page link — left as a commented placeholder so cloning users
      // wire it to their own repo without the default URL 404'ing meanwhile.
      // editLink: {
      //   baseUrl: 'https://github.com/<you>/<your-repo>/edit/main/',
      // },

      head: [
        ...analyticsHead,
        {
          tag: 'meta',
          attrs: { property: 'og:image', content: `${siteUrl}${BASE}og-image.png` },
        },
        {
          tag: 'meta',
          attrs: { property: 'og:image:width', content: '1200' },
        },
        {
          tag: 'meta',
          attrs: { property: 'og:image:height', content: '630' },
        },
        {
          tag: 'meta',
          attrs: { name: 'twitter:card', content: 'summary_large_image' },
        },
        {
          tag: 'meta',
          attrs: { name: 'twitter:image', content: `${siteUrl}${BASE}og-image.png` },
        },
        {
          tag: 'meta',
          attrs: { name: 'twitter:site', content: '@allannin' },
        },
        {
          tag: 'meta',
          attrs: { name: 'twitter:creator', content: '@allannin' },
        },
        {
          // a11y — Expressive Code's <pre> elements are scrollable but not
          // focusable by default. Screen-reader users can't keyboard-scroll
          // them. Fix once at runtime via a tiny inline script — no client
          // bundle cost, no library required.
          tag: 'script',
          content:
            "addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('pre[data-language]').forEach(p=>{p.setAttribute('tabindex','0')});});",
        },
        {
          tag: 'script',
          attrs: { type: 'application/ld+json' },
          content: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'SoftwareApplication',
            name: 'routekit',
            applicationCategory: 'DeveloperApplication',
            operatingSystem: 'Any',
            description:
              'Type-safe client-side routing for TypeScript. Zero dependencies, ~3 KB minified.',
            license: 'https://opensource.org/licenses/MIT',
            url: `${siteUrl}${BASE}`,
            offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
          }),
        },
      ],

      components: {
        // Override Starlight's default Hero with our custom landing-page hero.
        Hero: './src/components/Hero.astro',
        // PageFrame override prepends the "Download static / source / All 365"
        // bar shipped with every other day's template (rendered from each
        // template's Base.astro). Starlight composes its own <html> layout, so
        // we slot the bar in via PageFrame instead. Hidden when
        // PUBLIC_TEMPLATE_HUB_URL is unset (cloning users' own deploys).
        PageFrame: './src/components/PageFrame.astro',
      },
    }),
  ],
});
