import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    const errors: string[] = [];
    // Ignore third-party noise from the author-deploy analytics/ads stack
    // (GA + AdSense), which 403/CSP-warn under a real Chrome but never under
    // the bundled headless browser. None of it is the template's own code.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const isThirdParty = (m: ConsoleMessage) =>
      THIRD_PARTY.test(m.text()) ||
      THIRD_PARTY.test(m.location()?.url ?? '') ||
      /failed to load resource/i.test(m.text());
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() === 'error' && !isThirdParty(m)) errors.push(`console.error: ${m.text()}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home page meta description is set', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home page emits SoftwareApplication JSON-LD', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const found = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const sw = found.find((d) => d && d['@type'] === 'SoftwareApplication');
  expect(sw, 'SoftwareApplication JSON-LD missing').toBeTruthy();
  expect(sw.name).toBe('routekit');
  expect(sw.applicationCategory).toBe('DeveloperApplication');
  expect(sw.license).toBeTruthy();
});

test('OG image meta tag present and absolute URL', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toBeTruthy();
  expect(og!).toMatch(/^https?:\/\//);
  expect(og!).toContain('og-image.png');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  const card = await page.locator('meta[name="twitter:card"]').getAttribute('content');
  expect(card).toBe('summary_large_image');
});

test('canonical link is absolute on every doc route', async ({ page }) => {
  for (const route of ROUTES.slice(0, 3)) {
    await page.goto(route);
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical, `canonical missing on ${route}`).toBeTruthy();
    expect(canonical, `canonical not absolute on ${route}`).toMatch(/^https?:\/\//);
  }
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});

test('pagefind static index built', async ({ page }) => {
  // Pagefind generates /pagefind/pagefind.js when search is enabled.
  const res = await page.request.get('http://localhost:4321/pagefind/pagefind.js');
  expect(res.status()).toBe(200);
});

test('404 page exists at /404.html', async ({ page }) => {
  const res = await page.request.get('http://localhost:4321/404.html');
  expect(res.status()).toBe(200);
});
