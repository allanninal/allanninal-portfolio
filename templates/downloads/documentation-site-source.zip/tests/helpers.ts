import type { Page } from '@playwright/test';

// Routes that exist on the live preview build (PUBLIC_BASE_PATH=/).
export const ROUTES = [
  '/',
  '/getting-started/installation/',
  '/getting-started/quickstart/',
  '/getting-started/your-first-route/',
  '/guides/basic-routing/',
  '/guides/navigation/',
  '/guides/code-splitting/',
  '/reference/create-router/',
  '/reference/router-component/',
  '/reference/use-route/',
  '/reference/configuration/',
  '/reference/typescript/',
  '/examples/basic-spa/',
  '/examples/data-fetching/',
  '/changelog/',
  // Pro edition adds the standalone Advanced Patterns guide; the free build
  // redirects it, so it's only a real route under Pro.
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/advanced-patterns/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    document.documentElement.setAttribute('data-theme', t);
    try {
      localStorage.setItem('starlight-theme', t);
    } catch (_) { /* ignore */ }
  }, theme);
}
