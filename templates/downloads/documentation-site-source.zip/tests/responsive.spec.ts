import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

for (const route of ROUTES.slice(0, 6)) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}x${vp.height}) — no horizontal scroll`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await page.locator('h1').first().waitFor();
      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth,
      );
      expect(overflow).toBe(false);
    });
  }
}

test('mobile (375x667) shows a Menu hamburger button on doc pages', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  // The landing page (`/`) is a `template: splash` and intentionally has no
  // sidebar — Starlight hides the menu button there. Test on a real doc page.
  await page.goto('/getting-started/installation/');
  const menu = page.getByRole('button', { name: 'Menu' });
  await expect(menu).toBeVisible();
});

test('right-side TOC is hidden below the lg breakpoint', async ({ page }) => {
  // Starlight hides the right-side TOC nav under ~lg (1024px). The mobile-TOC
  // dropdown still exists, but the side-rail nav should not be visible.
  await page.setViewportSize({ width: 1024, height: 768 });
  await page.goto('/getting-started/quickstart/');
  const sideToc = page.locator('nav[aria-labelledby="starlight__on-this-page"]');
  const visible = await sideToc.first().isVisible().catch(() => false);
  expect(visible).toBe(false);
});
