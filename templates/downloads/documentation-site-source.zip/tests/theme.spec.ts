import { test, expect } from '@playwright/test';
import { ROUTES, setTheme } from './helpers';

// Sample 4 representative routes (full ROUTES across both themes is 30 tests
// — overkill for theme verification when content variation is what matters).
const SAMPLE = ['/', '/getting-started/installation/', '/reference/create-router/', '/changelog/'];

for (const route of SAMPLE) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${route} renders in ${theme} mode`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);
      const dataTheme = await page.evaluate(() =>
        document.documentElement.getAttribute('data-theme'),
      );
      expect(dataTheme).toBe(theme);
      await expect(page.locator('h1').first()).toBeVisible();
    });
  }
}

test('cobalt accent CSS variable is set in light mode', async ({ page }) => {
  await page.goto('/');
  await setTheme(page, 'light');
  const accent = await page.evaluate(() =>
    getComputedStyle(document.documentElement).getPropertyValue('--sl-color-accent').trim(),
  );
  // Light mode cobalt: #2563EB
  expect(accent.toLowerCase()).toBe('#2563eb');
});

test('accent lightens to #60A5FA in dark mode', async ({ page }) => {
  await page.goto('/');
  await setTheme(page, 'dark');
  const accent = await page.evaluate(() =>
    getComputedStyle(document.documentElement).getPropertyValue('--sl-color-accent').trim(),
  );
  expect(accent.toLowerCase()).toBe('#60a5fa');
});

test('IBM Plex Sans is the body font', async ({ page }) => {
  await page.goto('/');
  const fontFamily = await page.evaluate(() =>
    getComputedStyle(document.body).fontFamily.toLowerCase(),
  );
  expect(fontFamily).toContain('ibm plex sans');
});

test('IBM Plex Mono is the code font', async ({ page }) => {
  await page.goto('/getting-started/installation/');
  const codeEl = page.locator('code').first();
  await codeEl.waitFor();
  const fontFamily = await codeEl.evaluate((el) =>
    getComputedStyle(el).fontFamily.toLowerCase(),
  );
  expect(fontFamily).toContain('ibm plex mono');
});
