# documentation-site

A free, MIT-licensed **Astro Starlight** documentation template for indie open-source libraries, CLIs, and SDKs. Demonstrated by documenting a fictional `routekit` library — ~10 substantive MDX pages, real code blocks, package-manager tabs, and all four `<Aside>` callout variants.

**Light/dark · IBM Plex Sans + IBM Plex Mono · Cobalt #2563EB on near-white / near-black.**

![Preview](./preview.png)

**Live demo:** [example.com](https://example.com/)

---

## Features

- **Astro Starlight** under the hood — sidebar, [pagefind](https://pagefind.app/) search, right-side TOC, dark/light toggle, sitemap, robots.txt, 404 page, and full a11y story all out of the box.
- **Custom theme** — IBM Plex Sans + IBM Plex Mono (variable fonts, self-hosted via @fontsource), **cobalt** `#2563EB` accent on warm-near-black `#0F1117` (dark) / near-white `#F8FAFC` (light). The default Starlight purple is replaced wholesale via the documented `--sl-color-*` token system.
- **Marketing landing page (`/`)** distinct from the first doc page — a custom `<Hero />` component override that ships a pill badge, install snippet, shields-style version badges, and a 4-card feature grid. Default Starlight treats the root as the first doc page; this template separates the "why should I adopt this?" entry point from the docs proper.
- **Real fictional product content** — `routekit`, a TypeScript routing library, documented across 10 MDX pages: install, quickstart, your-first-route, basic-routing, navigation, code-splitting, four API reference pages (`createRouter`, `<Router />`, `useRoute`, configuration, TypeScript), two examples (basic SPA, data fetching), and a changelog. Every page has working code blocks, real prose, and demonstrates a different Starlight component.
- **Multi-language install tabs** — `npm | pnpm | bun | yarn` synchronized across the site via Starlight's `<Tabs syncKey>`. The single most-copied pattern from Bun/Tailwind/Astro docs.
- **All four `<Aside>` variants demonstrated** in the content — `note`, `tip`, `caution`, `danger`. Authors see the design working before they write a word.
- **Dual-theme code blocks** — Expressive Code with `github-light` (light) + `one-dark-pro` (dark) — warm syntax that pairs with the cobalt accent instead of clashing.
- **Schema.org**: `WebSite` site-wide, `SoftwareApplication` on the landing page (with `applicationCategory: DeveloperApplication`, `license`, `codeRepository`), Starlight's built-in per-page metadata for everything else.
- **a11y refinement** — code blocks (`<pre data-language>`) are made keyboard-focusable via a tiny inline `addEventListener` script in `<head>`, fixing the `scrollable-region-focusable` axe violation that ships with Starlight by default.
- **GH Pages deploy pre-wired** — `base` path resolved from `GITHUB_REPOSITORY` env var, `pages.yml` workflow included, `site:` set in `astro.config.mjs`. The three things Starlight's own starter doesn't pre-configure for GitHub Pages.
- **Full test suite** — 84 Playwright tests including: every route renders, JSON-LD shape, OG image absolute URL, Twitter card, sitemap, robots.txt, pagefind index built, 404 page exists, sidebar IA, sidebar navigation, package-manager tabs render and switch, all four Aside variants present, theme toggle flips data-theme, IBM Plex fonts apply, copy button on code blocks, Hero renders custom landing, pagination footer, mobile hamburger menu, right-TOC hidden below lg, axe clean across both themes on 4 routes, broken-link checker, Lighthouse ≥ 95 all four categories.

## Stack

- **Framework:** [Astro 5](https://astro.build/) + [Starlight 0.30](https://starlight.astro.build/)
- **Markdown:** MDX with Starlight's prose components
- **Styles:** Custom CSS (no Tailwind here — Starlight ships its own design system)
- **Fonts:** IBM Plex Sans Variable + IBM Plex Mono (self-hosted via @fontsource-variable)
- **Code highlighting:** Expressive Code with `github-light` + `one-dark-pro` dual theme
- **Search:** [Pagefind](https://pagefind.app/) (static, runs at build, ~5 KB JS)
- **Testing:** Playwright, @axe-core/playwright, Lighthouse CI, linkinator

## Quick start

```bash
unzip documentation-site-source.zip -d my-docs
cd my-docs
npm install
cp .env.example .env
npm run dev
```

## Customize

### 1. Rename the product

Search and replace `routekit` with your product name across:
- `astro.config.mjs` — `title`, `description`, JSON-LD `name` and `description`
- `src/components/Hero.astro` — the headline + tagline
- `src/content/docs/index.mdx` — landing-page prose
- `src/content/docs/**/*.mdx` — sample content (or delete and start fresh)
- `package.json` — name + npm-install commands inside install pages
- `public/og-image.svg` (and re-run `rsvg-convert` to regenerate `og-image.png`)
- `src/assets/logo.svg` and `public/favicon.svg`

That's enough to deploy your own docs with your branding.

### 2. Sidebar IA

Edit the `sidebar` array in `astro.config.mjs`. The structure is documented at the [Starlight reference](https://starlight.astro.build/reference/configuration/#sidebar). You can mix manual entries:

```ts
{
  label: 'Guides',
  items: [
    { slug: 'guides/basic-routing' },
    { slug: 'guides/navigation' },
  ],
},
```

…with auto-generated groups:

```ts
{
  label: 'Reference',
  autogenerate: { directory: 'reference' },
},
```

### 3. Theme tokens

Override `--sl-color-*` and `--sl-font` in `src/styles/custom.css`. Starlight 0.30 defines `:root` for the **dark** theme and `:root[data-theme='light']` for the **light** theme — your overrides must follow that pattern (this is inverted from earlier Starlight versions).

```css
:root {
  /* DARK theme overrides */
  --sl-color-accent: #YOUR_DARK_ACCENT;
}
:root[data-theme='light'] {
  /* LIGHT theme overrides */
  --sl-color-accent: #YOUR_LIGHT_ACCENT;
}
```

Verify both accents pass WCAG AA against `--sl-color-bg` (4.5:1 for normal text, 3:1 for large/UI). If unsure, see [accent-contrast-check](../../.claude/skills/accent-contrast-check/SKILL.md) in the parent repo.

### 4. Code block themes

In `astro.config.mjs`:

```ts
expressiveCode: {
  themes: ['github-light', 'one-dark-pro'],
},
```

Available themes: any [Shiki theme name](https://shiki.style/themes). Try `dracula` or `night-owl` for more contrast, `min-light` + `min-dark` for monochrome.

### 5. Search (pagefind)

`pagefind: true` in `astro.config.mjs` is the entire setup. Pagefind crawls `dist/` after build and emits a static index. To exclude pages from search, add `pagefind: false` to a page's frontmatter.

### 6. Edit-this-page links

Uncomment and set the `editLink.baseUrl` in `astro.config.mjs`:

```ts
editLink: {
  baseUrl: 'https://github.com/<you>/<your-repo>/edit/main/',
},
```

The link is hidden by default (the placeholder URL would 404). Activate it once you have a real repo.

### 7. Multi-language install tabs

The `<Tabs syncKey="...">` component in MDX synchronizes selection across the site. We use `syncKey="package-manager"` for npm/pnpm/bun/yarn. To add more sync groups (e.g. framework tabs for React/Vue/Solid), use a different `syncKey`:

```mdx
<Tabs syncKey="framework">
  <TabItem label="React">...</TabItem>
  <TabItem label="Vue">...</TabItem>
</Tabs>
```

---

## Deploy to GitHub Pages

> The source repo is private — there is no Fork button. Download the source ZIP from [example.com](https://example.com/) and follow these steps.

1. **Unzip + init**:

   ```bash
   unzip documentation-site-source.zip -d my-docs
   cd my-docs
   git init && git add . && git commit -m "init from documentation-site template"
   ```

2. **Push**:

   ```bash
   git remote add origin https://github.com/<you>/<your-repo>.git
   git push -u origin main
   ```

3. **Settings → Pages → Source: GitHub Actions.** The included `pages.yml` builds and deploys on every push.

### Custom domain

1. Add a `CNAME` file in `public/` with your domain.
2. Settings → Variables → Actions, set `PUBLIC_SITE_URL` and `PUBLIC_BASE_PATH=/`.

---

## Testing

```bash
npm run test:all
# = npm run build && npm run test && npm run test:links && npm run test:lighthouse
```

| Suite | What it covers |
|---|---|
| `tests/pages.spec.ts` | Every route renders, h1 visible, no console errors; meta description, SoftwareApplication JSON-LD, OG image absolute, Twitter `summary_large_image`, canonical URLs, sitemap, robots.txt, pagefind index built, 404 page reachable |
| `tests/interactions.spec.ts` | Sidebar IA (5 groups visible), sidebar nav navigates correctly, right-side TOC at desktop width, package-manager tabs (4 visible, swap on click), all four `<Aside>` variants present, theme toggle flips `data-theme`, search dialog opens + finds results, code copy button attached, Hero renders pill + install snippet + 4 features, pagination footer present |
| `tests/responsive.spec.ts` | No horizontal scroll at 4 viewports across 6 routes; mobile shows Menu hamburger; right-TOC hidden below lg breakpoint |
| `tests/theme.spec.ts` | Sample 4 routes × 2 themes; cobalt `--sl-color-accent` is `#2563EB` (light) and `#60A5FA` (dark); IBM Plex Sans is body font; IBM Plex Mono is code font |
| `tests/a11y.spec.ts` | Zero axe violations on 4 sample routes × 2 themes (covers all chrome — Starlight is identical across pages) |
| `tests/links.spec.ts` | All `target="_blank"` links use `rel="noopener noreferrer"`; internal links resolve |

---

## Support and donations

This template is **free and MIT-licensed**. Use it for personal, commercial, or client work — no permission or attribution required.


### For cloning users

- The GitHub "Sponsor" button on your fork is driven by `.github/FUNDING.yml`. Edit `ko_fi: your-handle` to point at your own handle, or delete the file to hide the button.

---

## License

MIT — see [LICENSE](./LICENSE).

Part of the [365-template series](https://example.com/templates/) — Day 6 of 365 free, MIT-licensed static website templates.
