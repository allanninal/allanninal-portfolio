// The rail — eight published looks, each carrying its real editorial credit
// block as structured data (not a caption line). This file is the single
// source every surface on the page reads from: the rail's <dl> blocks, the
// pull ledger (src/data/pullLedger.ts references the same item names), and
// the Pro archive. Publication, showroom and brand names are plausible but
// fictional — never a real design house or masthead attached to a stock
// photo. See RESEARCH.md, "Persona" and "Real vocabulary used on the page".
export type Lane = 'Editorial' | 'Advertising & campaign' | 'Private client';
export type ShotType = 'On-figure' | 'Flat lay';
export type CreditLine = { term: string; value: string };

export type Look = {
  id: string;
  number: string;
  title: string;
  lane: Lane;
  shotType: ShotType;
  image: string;
  alt: string;
  credits: CreditLine[];
};

export const LOOKS: Look[] = [
  {
    id: 'fieldnote',
    number: '01',
    title: 'Fieldnote',
    lane: 'Editorial',
    shotType: 'On-figure',
    image: 'look-03-field-coat.jpg',
    alt: 'A woman in a beige field coat and hat photographed outdoors for an editorial feature',
    credits: [
      { term: 'Client / Publication', value: 'Ember & Field Quarterly' },
      { term: 'Photographer', value: 'Priya Chandran' },
      { term: 'Hair', value: 'Dez Okafor' },
      { term: 'Makeup', value: 'Rosa Linetti' },
      { term: 'Model', value: 'Wren Halloway' },
      { term: 'Coat', value: 'Larkbeck wool field coat' },
      { term: 'Shoes', value: 'Corvina Studio ankle boots' },
      { term: 'Jewellery', value: 'Fen & Moss brass cuff' },
    ],
  },
  {
    id: 'night-shift',
    number: '02',
    title: 'Night Shift',
    lane: 'Editorial',
    shotType: 'On-figure',
    image: 'look-01-leather-jacket.jpg',
    alt: 'A woman photographed from behind in a black leather jacket crossing an urban footbridge',
    credits: [
      { term: 'Client / Publication', value: 'Modern Ledger Magazine' },
      { term: 'Photographer', value: 'Theo Marsh' },
      { term: 'Hair', value: 'Ingrid Solheim' },
      { term: 'Makeup', value: 'Cass Abioye' },
      { term: 'Model', value: 'Ren Delacroix' },
      { term: 'Jacket', value: 'Hallow & Rowe leather biker jacket' },
      { term: 'Shoes', value: 'Thistlewood combat boots' },
      { term: 'Bag', value: 'Orin & Vale structured tote' },
    ],
  },
  {
    id: 'frankfurt-grey',
    number: '03',
    title: 'Frankfurt Grey',
    lane: 'Editorial',
    shotType: 'On-figure',
    image: 'look-02-street-style-coat.jpg',
    alt: 'A man in a structured wool overcoat photographed in black and white on a city street',
    credits: [
      { term: 'Client / Publication', value: 'Aperture Coastal — menswear feature' },
      { term: 'Photographer', value: 'Mika Sundberg' },
      { term: 'Grooming', value: 'Jonas Ferreira' },
      { term: 'Model', value: 'Elian Cross' },
      { term: 'Coat', value: 'Bellcastor wool overcoat' },
      { term: 'Shoes', value: 'Maren Row leather derbies' },
      { term: 'Watch', value: 'Corvina Studio steel watch' },
    ],
  },
  {
    id: 'runway-to-retail',
    number: '04',
    title: 'Runway to Retail',
    lane: 'Advertising & campaign',
    shotType: 'On-figure',
    image: 'look-04-denim-jacket.jpg',
    alt: 'A woman in a denim jacket carrying a canvas backpack, photographed street-style for a campaign',
    credits: [
      { term: 'Client / Brand', value: 'Halden & Cole — spring campaign' },
      { term: 'Photographer', value: 'Odessa Kwan' },
      { term: 'Hair', value: 'Marisol Vance' },
      { term: 'Makeup', value: 'Rosa Linetti' },
      { term: 'Model', value: 'Talia Renwick' },
      { term: 'Jacket', value: 'Halden & Cole denim jacket' },
      { term: 'Bag', value: 'Fen & Moss canvas backpack' },
      { term: 'Shoes', value: 'Thistlewood white trainers' },
    ],
  },
  {
    id: 'belted',
    number: '05',
    title: 'Belted',
    lane: 'Editorial',
    shotType: 'On-figure',
    image: 'look-05-raincoat-street.jpg',
    alt: 'A young woman in a belted trench coat photographed street-style for an editorial feature',
    credits: [
      { term: 'Client / Publication', value: 'Rove Quarterly' },
      { term: 'Photographer', value: 'Callum Reyes' },
      { term: 'Hair', value: 'Noa Fenwick' },
      { term: 'Makeup', value: 'Dez Okafor' },
      { term: 'Model', value: 'Ines Maddox' },
      { term: 'Coat', value: 'Larkbeck belted trench' },
      { term: 'Shoes', value: 'Corvina Studio loafers' },
      { term: 'Bag', value: 'Orin & Vale top-handle bag' },
    ],
  },
  {
    id: 'the-pitch',
    number: '06',
    title: 'The Pitch',
    lane: 'Advertising & campaign',
    shotType: 'On-figure',
    image: 'look-06-tailored-suit.jpg',
    alt: 'A man in a tailored two-piece suit photographed full-length against a plain studio background',
    credits: [
      { term: 'Client / Brand', value: 'Bellcastor Tailoring — lookbook campaign' },
      { term: 'Photographer', value: 'Priya Chandran' },
      { term: 'Grooming', value: 'Jonas Ferreira' },
      { term: 'Model', value: 'Malik Osei' },
      { term: 'Suit', value: 'Bellcastor two-piece wool suit' },
      { term: 'Shoes', value: 'Maren Row oxfords' },
      { term: 'Tie', value: 'Hallow & Rowe silk tie' },
    ],
  },
  {
    id: 'desk-to-dinner',
    number: '07',
    title: 'Desk to Dinner',
    lane: 'Private client',
    shotType: 'Flat lay',
    image: 'look-07-flatlay-accessories.jpg',
    alt: 'A wristwatch and necktie arranged as a flat lay for a press-day capsule story',
    credits: [
      { term: 'Client', value: 'Private client — press-day capsule' },
      { term: 'Photographer', value: 'Theo Marsh' },
      { term: 'Watch', value: 'Corvina Studio steel watch' },
      { term: 'Tie', value: 'Hallow & Rowe silk tie' },
      { term: 'Note', value: 'Shot flat lay — no model, hair or makeup credit on a laydown story' },
    ],
  },
  {
    id: 'ledger',
    number: '08',
    title: 'Ledger',
    lane: 'Editorial',
    shotType: 'Flat lay',
    image: 'look-08-jewelry-flatlay.jpg',
    alt: 'Gold and silver earrings and jewellery arranged as a flat lay for an accessories story',
    credits: [
      { term: 'Client / Publication', value: 'Ember & Field Quarterly — accessories story' },
      { term: 'Photographer', value: 'Odessa Kwan' },
      { term: 'Jewellery', value: 'Fen & Moss gold hoop earrings; Thistlewood layered chain necklace' },
      { term: 'Note', value: 'Shot flat lay — the accessories are the story, not the fit' },
    ],
  },
];
