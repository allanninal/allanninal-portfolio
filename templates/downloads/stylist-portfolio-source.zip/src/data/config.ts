// Noor Aslani — editorial + advertising wardrobe stylist, Los Angeles.
// Fictional persona. Structured tailoring, outerwear and accessories-led
// editorial only — no swimwear, no lingerie, per house convention. Showroom
// and brand names throughout this file and src/data/looks.ts are plausible
// but fictional placeholders, flagged for the buyer to swap with real
// credits — never a real design house attached to a stock photo.
export const site = {
  name: 'Noor Aslani',
  title: 'Noor Aslani — wardrobe stylist, editorial + advertising, Los Angeles',
  tagline: 'Noor Aslani is the wardrobe stylist whose looks come with the paperwork attached.',
  owner: 'Noor Aslani',
  ownerRole: 'Wardrobe stylist',
  studioName: 'Noor Aslani',
  addressLine: '2447 Sunset Studio Row',
  city: 'Los Angeles',
  state: 'CA',
  zip: '90026',
  country: 'US',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'Noor Aslani is an editorial and advertising wardrobe stylist in Los Angeles who publishes the credit ' +
    'block, the pull ledger and the signed pull letter behind every look — not just the photograph.',
  ogImage: '/og-image.png',
};

export const primaryNav = [
  { label: 'The Rail', href: '#rail' },
  { label: 'The Pull', href: '#pull' },
  { label: 'Pull Letter', href: '#pull-letter' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'Lanes & Rates', href: '#lanes-rates' },
  { label: 'Press', href: '#press' },
  { label: 'About', href: '#about' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export const quotes = {
  photographer: {
    text: '“Most stylists hand you a mood board and hope. Noor hands you the mood board, the pull letter and the return date, all before the call sheet goes out. I never have to ask where a piece came from — it’s already written down.”',
    cite: 'Theo Marsh, photographer',
  },
  editor: {
    text: '“A credit line is a promise to a reader that the coat in the photo is a real, buyable thing. Noor’s the rare stylist whose credit blocks I never have to fact-check before we go to print.”',
    cite: 'Priya Chandran, fashion editor, Ember & Field Quarterly',
  },
};

// ── How a pull works ────────────────────────────────────────────────────
export const howAPullWorks = [
  { step: 'Mood board', detail: 'A direction — silhouette, palette, references — shared with the photographer and, for advertising work, the brand before any garment is requested.' },
  { step: 'Showroom request, during market', detail: 'Specific pieces requested from each PR showroom against the mood board, timed to that season’s market appointment window.' },
  { step: 'Pull letter signed', detail: 'Before anything leaves the showroom, a Letter of Responsibility is signed naming who’s financially responsible, the shoot dates, and the return date — see below.' },
  { step: 'Pickup', detail: 'Garments collected in person or via a bonded courier, checked against the pull letter’s itemised list piece by piece.' },
  { step: 'Shoot', detail: 'Steamed or pressed on set immediately before camera — every look is checked for pulls, creases and fit right up to the first frame.' },
  { step: 'Return by due date', detail: 'Every piece goes back to its showroom by the date on the pull letter, re-listed and back on the sales floor or sample rack the same week.' },
  { step: 'Follow-up', detail: 'A tearsheet or usage confirmation sent back to the showroom once the piece runs — closing the loop that got the label credited in the first place.' },
];

// ── Lanes & rates ────────────────────────────────────────────────────────
export const laneDefinitions = [
  {
    term: 'Editorial',
    definition: 'Regional glossies and brand editorial — the lowest day rate of the three lanes, paid in access, credit and tearsheets as much as cash. Where most of Noor’s calendar lives.',
  },
  {
    term: 'Advertising & campaign',
    definition: 'Paid brand campaigns and catalogue work — the highest day rate, plus a separately negotiated usage or buyout fee for how the resulting images are used.',
  },
  {
    term: 'Private client',
    definition: 'A small, clearly separate line: press days and red-carpet appearances for individual clients. Not a closet-audit or personal-shopping retail practice — no capsule-wardrobe packages offered.',
  },
];

export const ratesByLane = [
  {
    lane: 'Editorial',
    dayRate: '$300–$600',
    usageFee: 'Typically none beyond the day rate — editorial usage is standard tearsheet/print credit',
    kitFee: '$75/day',
  },
  {
    lane: 'Advertising & campaign',
    dayRate: '$750–$2,000+',
    usageFee: 'Negotiated separately per campaign — print vs. digital, duration, exclusivity',
    kitFee: '$75/day',
  },
  {
    lane: 'Private client',
    dayRate: '$200–$300/hr',
    usageFee: 'N/A — personal appearance, no image-usage license involved',
    kitFee: 'Included',
  },
];

// ── The kit ──────────────────────────────────────────────────────────────
export const kitItems = [
  { item: 'Steamer', note: 'Travel steamer for on-set creases — first thing unpacked at every call time.' },
  { item: 'Clothing tape', note: 'Double-sided, for fit corrections that can’t wait for a pin.' },
  { item: 'Clips & pins', note: 'Bulldog clips and safety pins for cinching a garment behind camera, out of frame.' },
  { item: 'Sewing kit', note: 'Needle, thread and spare buttons for a split seam or a popped button mid-shoot.' },
  { item: 'Shoe inserts', note: 'Gel inserts and heel grips so a borrowed sample shoe fits a model it wasn’t made for.' },
];

// ── FAQ ──────────────────────────────────────────────────────────────────
export const faq = [
  {
    q: 'Do you shop as well as style?',
    a: 'Occasionally, for the private-client line — a press day or a red-carpet appearance sometimes needs a piece sourced and purchased rather than pulled. That’s a small, separate line item from editorial or advertising work, and it’s never a closet-audit or capsule-wardrobe retail service.',
  },
  {
    q: 'What happens if something’s damaged on set?',
    a: 'The pull letter is exactly the document that answers this: it names who’s financially responsible and states the piece’s replacement value before it ever leaves the showroom. Minor issues (a scuff, a loose thread) are flagged to the showroom immediately; anything beyond that follows the loss/damage clause on the signed letter.',
  },
  {
    q: 'On-figure or flat lay — how do you decide?',
    a: 'On-figure shows drape, movement and how a piece actually sits on a body — the default for anything with structure or tailoring. Flat lay is faster, cheaper and better suited to an accessories or capsule story where the garment itself, not the fit, is the point — two of the looks on the rail below are shot that way on purpose.',
  },
];
