// The pull ledger — downstream of the rail. Every garment credited in
// src/data/looks.ts came from a showroom and had to go back; this is the
// document that tracks it. Item names deliberately match the garment
// credits on the rail, so the rail and the ledger can never quietly
// disagree with each other. See RESEARCH.md, "The pull ledger".
export type PullStatus = 'Returned' | 'Steaming' | 'Past due';

export type PullRow = {
  look: string;
  item: string;
  showroom: string;
  pulled: string;
  dueBack: string;
  status: PullStatus;
  responsible: string;
};

export const PULL_LEDGER: PullRow[] = [
  {
    look: 'Fieldnote',
    item: 'Larkbeck wool field coat',
    showroom: 'Larkbeck PR Showroom',
    pulled: '2026-02-03',
    dueBack: '2026-02-10',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Night Shift',
    item: 'Hallow & Rowe leather biker jacket',
    showroom: 'Hallow & Rowe Press Office',
    pulled: '2026-02-11',
    dueBack: '2026-02-18',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Frankfurt Grey',
    item: 'Bellcastor wool overcoat',
    showroom: 'Bellcastor Menswear Showroom',
    pulled: '2026-03-02',
    dueBack: '2026-03-09',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Runway to Retail',
    item: 'Halden & Cole denim jacket',
    showroom: 'Halden & Cole Brand Studio',
    pulled: '2026-03-14',
    dueBack: '2026-03-21',
    status: 'Steaming',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Belted',
    item: 'Larkbeck belted trench',
    showroom: 'Larkbeck PR Showroom',
    pulled: '2026-04-01',
    dueBack: '2026-04-08',
    status: 'Past due',
    responsible: 'Noor Aslani',
  },
  {
    look: 'The Pitch',
    item: 'Bellcastor two-piece wool suit',
    showroom: 'Bellcastor Menswear Showroom',
    pulled: '2026-04-10',
    dueBack: '2026-04-17',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Desk to Dinner',
    item: 'Corvina Studio steel watch',
    showroom: 'Corvina Studio Accessories PR',
    pulled: '2026-04-20',
    dueBack: '2026-04-27',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Ledger',
    item: 'Fen & Moss gold hoop earrings',
    showroom: 'Fen & Moss Jewellery Showroom',
    pulled: '2026-05-02',
    dueBack: '2026-05-09',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
];

// ── Pro edition — the full multi-season archive ────────────────────────
// Same shape, extended across earlier seasons and additional showrooms —
// the document a PR house actually asks to see when deciding whether to
// lend to Noor again: a track record, not just the current season.
export const PULL_ARCHIVE: PullRow[] = [
  ...PULL_LEDGER,
  {
    look: 'Low Tide (archive)',
    item: 'Maren Row canvas trench',
    showroom: 'Maren Row Press Office',
    pulled: '2025-09-08',
    dueBack: '2025-09-15',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Low Tide (archive)',
    item: 'Corvina Studio raffia tote',
    showroom: 'Corvina Studio Accessories PR',
    pulled: '2025-09-08',
    dueBack: '2025-09-15',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Boardroom (archive)',
    item: 'Bellcastor pinstripe blazer',
    showroom: 'Bellcastor Menswear Showroom',
    pulled: '2025-10-14',
    dueBack: '2025-10-21',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Boardroom (archive)',
    item: 'Maren Row leather brogues',
    showroom: 'Maren Row Press Office',
    pulled: '2025-10-14',
    dueBack: '2025-10-21',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Signal (archive)',
    item: 'Hallow & Rowe wool poncho',
    showroom: 'Hallow & Rowe Press Office',
    pulled: '2025-11-19',
    dueBack: '2025-11-26',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Signal (archive)',
    item: 'Fen & Moss silver cuff',
    showroom: 'Fen & Moss Jewellery Showroom',
    pulled: '2025-11-19',
    dueBack: '2025-11-26',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Afterglow (archive)',
    item: 'Larkbeck sequin slip dress',
    showroom: 'Larkbeck PR Showroom',
    pulled: '2025-12-03',
    dueBack: '2025-12-10',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Afterglow (archive)',
    item: 'Corvina Studio strap heels',
    showroom: 'Corvina Studio Accessories PR',
    pulled: '2025-12-03',
    dueBack: '2025-12-10',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Carry-On (archive)',
    item: 'Orin & Vale weekender bag',
    showroom: 'Orin & Vale Accessories Showroom',
    pulled: '2026-01-12',
    dueBack: '2026-01-19',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'Carry-On (archive)',
    item: 'Thistlewood wool scarf',
    showroom: 'Thistlewood Press Office',
    pulled: '2026-01-12',
    dueBack: '2026-01-19',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'First Light (archive)',
    item: 'Halden & Cole selvedge jeans',
    showroom: 'Halden & Cole Brand Studio',
    pulled: '2026-01-26',
    dueBack: '2026-02-02',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
  {
    look: 'First Light (archive)',
    item: 'Maren Row canvas sneakers',
    showroom: 'Maren Row Press Office',
    pulled: '2026-01-26',
    dueBack: '2026-02-02',
    status: 'Returned',
    responsible: 'Noor Aslani',
  },
];
