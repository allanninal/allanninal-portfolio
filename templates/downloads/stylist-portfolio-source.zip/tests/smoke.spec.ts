import { test, expect } from '@playwright/test';

test.describe('Noor Aslani — smoke tests', () => {
  test('the hero states "wardrobe stylist" explicitly, not just "stylist"', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Noor Aslani/);
    await expect(page.locator('h1')).toContainText(/wardrobe stylist/i);
  });

  test('primary nav is the page spine, not Home/About/Services', async ({ page }) => {
    await page.goto('/');
    const nav = page.getByRole('navigation', { name: 'Primary' });
    const links = await nav.getByRole('link').allTextContents();
    expect(links).toEqual([
      'The Rail', 'The Pull', 'Pull Letter', 'How It Works', 'Lanes & Rates', 'Press', 'About', 'FAQ', 'Contact',
    ]);
  });

  // ── The rail ──────────────────────────────────────────────────────────────
  test('the rail lists all 8 looks, each a credited article', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#rail .look-card');
    await expect(cards).toHaveCount(8);
  });

  test('every look card carries a real structured credit <dl>, not a caption line', async ({ page }) => {
    await page.goto('/');
    const dls = page.locator('#rail dl.credit-dl');
    await expect(dls).toHaveCount(8);
    for (let i = 0; i < 8; i++) {
      const terms = await dls.nth(i).locator('dt').count();
      expect(terms).toBeGreaterThanOrEqual(4);
    }
  });

  test('two looks are shot flat lay, credited without a model/hair/makeup line', async ({ page }) => {
    await page.goto('/');
    const flatLayTags = page.locator('#rail .look-tag', { hasText: 'Flat lay' });
    await expect(flatLayTags).toHaveCount(2);
  });

  test('the rail scrolls horizontally inside its own region and is keyboard reachable', async ({ page }) => {
    await page.goto('/');
    const rail = page.locator('.rail-scroll');
    await expect(rail).toHaveAttribute('tabindex', '0');
    await expect(rail).toHaveAttribute('role', 'region');
    await expect(rail).toHaveAttribute('aria-label', /.+/);
  });

  // ── The pull ──────────────────────────────────────────────────────────────
  test('the pull ledger lists all 8 current-season rows, matched to the rail', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#pull-ledger-table tbody tr');
    await expect(rows).toHaveCount(8);
    const text = await page.locator('#pull-ledger-table').innerText();
    expect(text).toMatch(/Fieldnote/);
    expect(text).toMatch(/Larkbeck wool field coat/);
    expect(text).toMatch(/Larkbeck PR Showroom/);
  });

  test('the pull ledger states status honestly, including a past-due row', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#pull-ledger-table').innerText();
    expect(text).toMatch(/Returned/);
    expect(text).toMatch(/Steaming/);
    expect(text).toMatch(/Past due/);
  });

  // ── The pull letter ─────────────────────────────────────────────────────────
  test('the pull-letter iframe is same-origin, lazy-loaded and sized to avoid CLS', async ({ page }) => {
    await page.goto('/');
    const iframe = page.locator('#pull-letter iframe');
    await expect(iframe).toHaveAttribute('src', /pull-letter\.html$/);
    await expect(iframe).toHaveAttribute('loading', 'lazy');
    await expect(iframe).toHaveAttribute('width');
    await expect(iframe).toHaveAttribute('height');
    await expect(iframe).toHaveAttribute('title', /.+/);
  });

  test('the pull-letter document itself renders the itemised loan and the loss/damage clause', async ({ page }) => {
    const res = await page.goto('/pull-letter.html');
    expect(res?.status()).toBe(200);
    const text = await page.locator('body').innerText();
    expect(text).toMatch(/Letter of Responsibility/i);
    expect(text).toMatch(/Larkbeck wool field coat/);
    expect(text).toMatch(/Loss \/ damage clause/i);
    expect(text).toMatch(/signature/i);
  });

  // ── How a pull works ─────────────────────────────────────────────────────────
  test('the how-a-pull-works ol lists all seven steps in order', async ({ page }) => {
    await page.goto('/');
    const items = await page.locator('#how-it-works ol.seq li .k').allTextContents();
    expect(items).toEqual([
      'Mood board', 'Showroom request, during market', 'Pull letter signed', 'Pickup', 'Shoot', 'Return by due date', 'Follow-up',
    ]);
  });

  // ── Lanes & rates ─────────────────────────────────────────────────────────
  test('lanes & rates defines all three lanes and states rates as ranges, not single numbers', async ({ page }) => {
    await page.goto('/');
    const terms = await page.locator('#lanes-rates dl.glossary dt').allTextContents();
    expect(terms).toEqual(['Editorial', 'Advertising & campaign', 'Private client']);

    const rows = page.locator('#lanes-rates table.spec tbody tr');
    await expect(rows).toHaveCount(3);
    const text = await page.locator('#lanes-rates table.spec').innerText();
    expect(text).toMatch(/\$300–\$600/);
    expect(text).toMatch(/\$750–\$2,000\+/);
    expect(text).toMatch(/\$200–\$300\/hr/);
  });

  // ── Press ─────────────────────────────────────────────────────────────────
  test('press carries a named on-the-record quote', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#press').innerText();
    expect(text).toMatch(/Priya Chandran/);
  });

  // ── About ─────────────────────────────────────────────────────────────────
  test('about states training, the kit and what she declines', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#about').innerText();
    expect(text).toMatch(/Training/);
    expect(text).toMatch(/Steamer/);
    expect(text).toMatch(/What she declines/);
    expect(text).toMatch(/no swim or intimate-apparel/i);
  });

  // ── FAQ ───────────────────────────────────────────────────────────────────
  test('FAQ has three questions', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#faq details.faq-item')).toHaveCount(3);
  });

  // ── Contact ───────────────────────────────────────────────────────────────
  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('.contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  test('the request-a-pull form requires name, email, lane and message', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#contact-name', '#contact-email', '#project-lane', '#contact-message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    const options = await page.locator('#project-lane option').allTextContents();
    expect(options).toEqual(['Choose one', 'Editorial', 'Advertising & campaign', 'Press day', 'Private client']);
  });

  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Schema ────────────────────────────────────────────────────────────────
  test('the Service schema carries no price or priceRange', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const serviceBlock = blocks.find((b) => b.includes('"Service"'))!;
    const service = JSON.parse(serviceBlock);
    expect(service.price).toBeUndefined();
    expect(service.priceRange).toBeUndefined();
    expect(service.serviceType).toBe('Wardrobe Styling');
  });

  test('the Person schema names Noor with a LinkedIn sameAs', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const personBlock = blocks.find((b) => b.includes('"Person"'))!;
    const person = JSON.parse(personBlock);
    expect(person.name).toBe('Noor Aslani');
    expect(person.sameAs).toContain('#');
  });

  test('no aggregateRating or gtin/Product schema appears anywhere', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    expect(html).not.toContain('aggregateRating');
    expect(html).not.toContain('"@type":"Product"');
    expect(html).not.toContain('"gtin"');
  });

  // ── Hygiene ───────────────────────────────────────────────────────────────
  test('no trace of earlier-day source templates survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['amara adeyemi', 'adeyemi studio', 'imogen vasey', 'kelham', 'firescale', 'iris calder']) {
      expect(html, `earlier-day copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('no couple, swim or lingerie framing appears anywhere on the page', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['swimwear', 'lingerie', 'bikini']) {
      expect(html, `off-brief copy present: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width, even with the horizontal rail', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1920, 1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/carbon-copy pink/i);
  });

  // The Full Pull Archive is Pro-only. In the free build it must not be
  // reachable as real content — Astro.redirect() renders it as a meta-refresh
  // stub — and it must not be linked from the homepage.
  test('the Pro Full Pull Archive is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="archive"]').count()).toBe(0);

    const res = await page.goto('/archive/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
