# Day 55 — Tattoo Studio: Niche Research

## Slug
`tattoo-studio`

## Differentiation from Days 1–54

### Visual register audit (recent days)
| Day | Palette family | Fonts |
|-----|---------------|-------|
| 54 massage-therapist | deep-ocean-teal / warm-sand / linen | Libre Baskerville + Source Sans 3 |
| 53 day-spa | sage / stone / pearl cream | Crimson Pro + Raleway |
| 52 nail-salon | coral / rose-gold / plum | Italiana + Plus Jakarta Sans |
| 51 barbershop | near-black / oxblood / brass | Teko + Hind |
| 50 hair-salon | mauve / champagne / ivory | Bellefair + Questrial |
| 49 personal-chef | aubergine / champagne blush | Tenor Sans + Albert Sans |
| 44 cocktail-lounge | noir-black / emerald neon | Bodoni Moda + IBM Plex Mono |

### Day 55 distinct visual register
- **Palette**: Ink black (#111111) + Bone white (#F7F3EC) + Electric amber-gold (#E8A020) as primary accent + Blood orange (#D43D15) as secondary
  - Near-black but not oxblood (day 51) — pure ink dominant
  - Amber-gold as accent: no prior template used this on a dark-dominant canvas
  - Bone white (warm off-white) adds texture without being cream (day 49) or champagne (day 50)
  - Dark-dominant template (barbershop was dark, but oxblood/heritage — tattoo is pure ink/editorial)
- **Typography**: Bebas Neue (all-caps display headings) + Barlow (body + service text)
  - Neither used in any prior day
  - Bebas Neue is authentically used in tattoo studio branding — bold, condensed, industrial
  - Barlow gives excellent legibility at body size on dark backgrounds
- **Density**: High visual density — multiple artist galleries (photo-first), flash grid, layered sections

## Persona
**Void & Vein Tattoo** — collective studio, Austin TX
- 3 resident artists: Maya Reyes (fine-line / botanical), Damon Cross (blackwork / geometric), Ryo Nakamura (Japanese traditional / realism)
- Fourth artist slot: guest-artist rotations
- Studio character: established (founded 2016), hygiene-forward, artist-driven, no walk-ins — consultation-required
- Booking platform: Vagaro (common for tattoo studios)
- Tone: confident, artistic, non-corporate — the kind of studio with a curated wall of flash art

## Sections (single-page)
1. **Hero** — dark full-bleed studio interior photo, logo mark, headline, Book Consultation CTA
2. **Artists** — 3 resident artists, each with style description + mini gallery (2-3 work images per artist)
3. **Studio Gallery** — 8-image grid of healed work and studio space shots (lightbox optional)
4. **Services & Booking** — consultation → design → session flow, what to expect, booking CTA
5. **Safety & Hygiene** — autoclave sterilization, single-use needles, APP-member callout, prep checklist
6. **Aftercare FAQ** — substantive 10-question accordion covering: immediate aftercare, moisturizing schedule, sun protection, swimming, peeling, touch-ups, colour vs black, fresh vs healed
7. **Flash Gallery** — small grid of flash designs available for booking
8. **Hours & Location** — studio hours, address, walk-in vs appointment policy
9. **Footer** — links, social handles, Instagram CTA

## Schema.org
- `TattooShop` (HealthAndBeautyBusiness subtype)
- `LocalBusiness`
- `Person` for each artist
- `Service` + `Offer` for consultation and custom work
- `FAQPage` for the aftercare FAQ section

## Color contrast checks (WCAG AA 4.5:1 minimum for text)
- Amber (#E8A020) on ink-black (#111111): ≈ 8.7:1 — AAA ✓
- Bone white (#F7F3EC) on ink-black (#111111): ≈ 17.5:1 — AAA ✓
- Ink-black (#111111) on bone white (#F7F3EC): ≈ 17.5:1 — AAA ✓
- Amber (#E8A020) on near-black surface (#1A1A1A): ≈ 8.4:1 — AAA ✓
- Dark amber (#9A6B0A) on bone white (#F7F3EC): ≈ 5.1:1 — AA ✓ (for decorative text on light sections)
- Muted body text: #C8C0B0 on #111111: ≈ 8.5:1 — AAA ✓
→ High-contrast palette: all text passes AA and most pass AAA

## Image plan (Unsplash)
- hero.jpg — tattoo studio interior / tattoo being applied (dark, atmospheric)
- artist-maya.jpg — female tattoo artist at work / close-up fine-line work
- artist-damon.jpg — male tattoo artist applying blackwork
- artist-ryo.jpg — Japanese style tattoo / realism work
- work-1.jpg through work-5.jpg — healed tattoo work (various styles)
- studio-1.jpg — studio space / hygiene setup

Total: 9 images

## Key differentiators from barbershop (day 51)
1. **Multi-artist collective** vs solo/team hair service
2. **Aftercare FAQ** (deep and tattoo-specific — unique section not in any prior template)
3. **Gallery-first** — artist portfolios with individual work shots
4. **Safety/hygiene callout** (APP membership, autoclave, needle protocol — tattoo-specific)
5. **Flash art grid** — a tattoo-specific UI concept not present elsewhere
6. **Austin TX** not heritage US
7. **Consultation flow** not booking flow
8. **Amber-gold on ink-black** — vs brass/oxblood (barbershop) or teal (massage)
