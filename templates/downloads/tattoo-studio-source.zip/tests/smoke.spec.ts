import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Void & Vein/);
});

test('hero section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero')).toBeVisible();
});

test('hero heading contains key phrase', async ({ page }) => {
  await page.goto('/');
  const h1 = page.locator('h1');
  await expect(h1).toContainText('lasts');
});

test('hero badges are present', async ({ page }) => {
  await page.goto('/');
  const badges = page.locator('.hero-badge');
  const count = await badges.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('stats band is visible', async ({ page }) => {
  await page.goto('/');
  const stats = page.locator('.stats-band');
  await expect(stats).toBeVisible();
});

test('artists section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#artists')).toBeVisible();
});

test('artist cards render (at least 3)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.artist-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('gallery images render (at least 6)', async ({ page }) => {
  await page.goto('/');
  const galleryItems = page.locator('.gallery-item');
  const count = await galleryItems.count();
  expect(count).toBeGreaterThanOrEqual(6);
});

test('flash section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#flash')).toBeVisible();
});

test('flash cards render (at least 4)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.flash-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('booking process section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#booking')).toBeVisible();
});

test('process steps render (at least 3)', async ({ page }) => {
  await page.goto('/');
  const steps = page.locator('.process-step');
  const count = await steps.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('safety section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#safety')).toBeVisible();
});

test('hygiene cards render (at least 4)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.hygiene-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('testimonial cards render (at least 4)', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('.testimonial-card');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(4);
});

test('aftercare FAQ section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#aftercare')).toBeVisible();
});

test('FAQ accordion items render (at least 10)', async ({ page }) => {
  await page.goto('/');
  const triggers = page.locator('.faq-trigger');
  const count = await triggers.count();
  expect(count).toBeGreaterThanOrEqual(10);
});

test('FAQ accordion opens on click', async ({ page }) => {
  await page.goto('/');
  const firstTrigger = page.locator('.faq-trigger').first();
  await firstTrigger.click();
  const expanded = await firstTrigger.getAttribute('aria-expanded');
  expect(expanded).toBe('true');
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('hours table is present', async ({ page }) => {
  await page.goto('/');
  const table = page.locator('.hours-table');
  await expect(table).toBeVisible();
});

test('booking CTA section is visible', async ({ page }) => {
  await page.goto('/');
  const cta = page.locator('.booking-cta');
  await expect(cta).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist in header', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('Book Consult button exists in header', async ({ page }) => {
  await page.goto('/');
  const bookBtn = page.locator('header .btn-book');
  await expect(bookBtn).toBeVisible();
});

test('footer has studio name', async ({ page }) => {
  await page.goto('/');
  const footer = page.locator('footer.site-footer');
  await expect(footer).toContainText('Void & Vein');
});

test('hero background photo renders', async ({ page }) => {
  await page.goto('/');
  const heroImg = page.locator('.hero-bg img');
  await expect(heroImg).toBeVisible();
});

test('artists named correctly in page', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('text=Maya Reyes').first()).toBeVisible();
  await expect(page.locator('text=Damon Cross').first()).toBeVisible();
  await expect(page.locator('text=Ryo Nakamura').first()).toBeVisible();
});
