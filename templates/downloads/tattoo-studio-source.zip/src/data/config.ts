export const studio = {
  name:         'Void & Vein Tattoo',
  tagline:      'Collector-quality tattooing in Austin, TX.',
  description:
    'Austin\'s most artist-driven tattoo collective. Fine-line, blackwork, Japanese traditional, and realism — by appointment only. Founded 2016.',
  address:      '2847 East 6th Street, Austin, TX 78702',
  neighborhood: 'East Austin',
  phone:        '+1 (512) 555-0193',
  email:        'hello@voidveintattoo.com',
  instagram:    'https://www.instagram.com/',
  facebook:     'https://www.facebook.com/',
  linkedin:     '#',
  kofi:         '#',
  bookingUrl:   'https://vagaro.com/',
  founded:      '2016',
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '12:00 pm – 8:00 pm' },
    { day: 'Wednesday', open: '12:00 pm – 8:00 pm' },
    { day: 'Thursday',  open: '12:00 pm – 8:00 pm' },
    { day: 'Friday',    open: '12:00 pm – 9:00 pm' },
    { day: 'Saturday',  open: '10:00 am – 8:00 pm' },
    { day: 'Sunday',    open: '12:00 pm – 6:00 pm' },
  ],
};

export const site = {
  title:         'Void & Vein Tattoo — Austin TX Tattoo Studio',
  description:
    'Collector-quality tattooing in Austin, TX. Fine-line, blackwork, Japanese traditional & realism by appointment only. Request a consultation online.',
  language:      'en',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
};

export type Artist = {
  id:          string;
  name:        string;
  title:       string;
  styles:      string[];
  bio:         string;
  specialties: string[];
  instagram:   string;
  image:       string;
  workImages:  { src: string; alt: string }[];
};

export const artists: Artist[] = [
  {
    id:       'maya',
    name:     'Maya Reyes',
    title:    'Fine-Line & Botanical',
    styles:   ['Fine-Line', 'Botanical', 'Micro-Realism'],
    bio:
      'Maya\'s work is built on patience and precision. She spent three years as a medical illustrator before pivoting to tattooing in 2017 — and it shows. Her botanical fine-line pieces are sought out by collectors across the country, with a waitlist that regularly stretches six months. She works exclusively in black and grey and takes no flash walk-ins.',
    specialties: [
      'Single-needle botanical illustrations',
      'Micro-portrait realism',
      'Minimal geometric placement',
      'Fine-line script and lettering',
    ],
    instagram: 'https://www.instagram.com/',
    image:     '/images/artist-maya.jpg',
    workImages: [
      { src: '/images/work-maya-1.jpg', alt: 'Fine-line botanical fern tattoo on forearm — detailed single-needle work' },
      { src: '/images/work-maya-2.jpg', alt: 'Micro-realism floral piece on shoulder — healed fine-line tattoo' },
    ],
  },
  {
    id:       'damon',
    name:     'Damon Cross',
    title:    'Blackwork & Geometric',
    styles:   ['Blackwork', 'Geometric', 'Neo-Traditional'],
    bio:
      'Damon has been tattooing since 2013 and joined Void & Vein at founding. His signature is bold blackwork with architectural precision — sacred geometry, mandala-inspired designs, and neo-tribal pieces that hold their contrast for decades. He\'s a stickler for linework: every piece he takes on gets a custom design session before ink touches skin.',
    specialties: [
      'Sacred geometry and mandalas',
      'Bold blackwork sleeves',
      'Neo-tribal and Polynesian-inspired',
      'Black & grey illustrative',
    ],
    instagram: 'https://www.instagram.com/',
    image:     '/images/artist-damon.jpg',
    workImages: [
      { src: '/images/work-damon-1.jpg', alt: 'Geometric blackwork mandala tattoo on upper arm — bold lines and symmetry' },
      { src: '/images/work-damon-2.jpg', alt: 'Neo-tribal blackwork sleeve in progress — intricate pattern work' },
    ],
  },
  {
    id:       'ryo',
    name:     'Ryo Nakamura',
    title:    'Japanese Traditional & Realism',
    styles:   ['Japanese Traditional', 'Realism', 'Color'],
    bio:
      'Ryo trained under a horimono master in Osaka for four years before moving to Austin in 2019. His Japanese traditional work — dragons, peonies, koi, and waves — follows classical composition rules while integrating modern colour saturation techniques. He is one of the few artists in Texas who does full-coverage Japanese bodysuits by commission.',
    specialties: [
      'Japanese traditional bodysuit work',
      'Dragons, koi, and chrysanthemum',
      'Full-colour realism portraits',
      'Irezumi composition and flow',
    ],
    instagram: 'https://www.instagram.com/',
    image:     '/images/artist-ryo.jpg',
    workImages: [
      { src: '/images/work-ryo-1.jpg', alt: 'Japanese traditional koi and wave tattoo on ribs — vivid color and classic composition' },
      { src: '/images/work-ryo-2.jpg', alt: 'Color realism peony and dragon sleeve — full Japanese traditional bodywork' },
    ],
  },
];

export type GalleryImage = {
  src:  string;
  alt:  string;
  style: string;
};

export const galleryImages: GalleryImage[] = [
  { src: '/images/studio-1.jpg',   alt: 'Void & Vein Tattoo studio interior — clean, bright workspace with art on walls', style: 'Studio' },
  { src: '/images/work-maya-1.jpg', alt: 'Fine-line botanical fern tattoo on forearm — healed single-needle detail', style: 'Fine-Line' },
  { src: '/images/work-damon-1.jpg', alt: 'Geometric blackwork mandala on upper arm — bold contrast', style: 'Blackwork' },
  { src: '/images/work-ryo-1.jpg',  alt: 'Japanese traditional koi tattoo on ribs — vivid colors', style: 'Japanese' },
  { src: '/images/work-maya-2.jpg', alt: 'Micro-realism floral piece on shoulder — fine-line technique', style: 'Fine-Line' },
  { src: '/images/work-damon-2.jpg', alt: 'Neo-tribal blackwork sleeve — intricate Polynesian-inspired pattern', style: 'Blackwork' },
  { src: '/images/work-ryo-2.jpg',  alt: 'Peony and dragon sleeve — Japanese traditional with vivid color', style: 'Japanese' },
  { src: '/images/work-flash-1.jpg', alt: 'Traditional flash snake and dagger design available for booking', style: 'Flash' },
];

export type FlashItem = {
  src:   string;
  alt:   string;
  title: string;
  price: string;
  size:  string;
  artist: string;
};

export const flashItems: FlashItem[] = [
  { src: '/images/work-flash-1.jpg', alt: 'Traditional snake and dagger flash tattoo design — available for immediate booking', title: 'Snake & Dagger', price: '$200', size: '3″ × 5″', artist: 'Damon' },
  { src: '/images/work-damon-1.jpg', alt: 'Small geometric compass flash design — classic blackwork available now', title: 'Compass Rose', price: '$180', size: '3″ × 3″', artist: 'Damon' },
  { src: '/images/work-maya-1.jpg', alt: 'Fine-line fern sprig flash available — single-needle botanicals', title: 'Fern Sprig', price: '$150', size: '2″ × 4″', artist: 'Maya' },
  { src: '/images/work-ryo-1.jpg', alt: 'Mini koi flash design — Japanese traditional style, full color', title: 'Mini Koi', price: '$250', size: '3″ × 4″', artist: 'Ryo' },
];

export type Stat = {
  value: string;
  label: string;
};

export const stats: Stat[] = [
  { value: '2016',  label: 'Founded' },
  { value: '3',     label: 'Resident Artists' },
  { value: '9+',    label: 'Years in Austin' },
  { value: '4.97★', label: 'Average Rating' },
];

export type Testimonial = {
  quote:  string;
  author: string;
  piece:  string;
  rating: number;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      'Maya spent two hours on the initial design consultation before a single needle touched my skin. The botanical sleeve she created is something I get stopped for on the street every week. Truly once-in-a-lifetime work.',
    author: 'Cassandra M.',
    piece:  'Fine-line botanical full sleeve — Maya Reyes',
    rating: 5,
  },
  {
    quote:
      'Damon\'s blackwork is architectural in the best way. My geometric chest piece has crispy lines that haven\'t faded in two years. The studio is clean, professional, and the aftercare instructions were the most detailed I\'ve ever received.',
    author: 'Terrence B.',
    piece:  'Geometric blackwork chest piece — Damon Cross',
    rating: 5,
  },
  {
    quote:
      'Ryo is an absolute master of Japanese traditional. He redesigned my concept entirely during our consultation and the result is infinitely better than what I walked in with. My rib koi is regularly reposted by major tattoo accounts.',
    author: 'Priya S.',
    piece:  'Japanese traditional koi rib piece — Ryo Nakamura',
    rating: 5,
  },
  {
    quote:
      'The hygiene and safety standards here are next-level. Everything is single-use, the autoclave logs are visible, and the room was spotless. As someone with autoimmune issues, I can\'t recommend this studio enough.',
    author: 'Alex W.',
    piece:  'Fine-line minimalist wrist piece — Maya Reyes',
    rating: 5,
  },
];

export type HygieneFact = {
  icon:  string;
  title: string;
  body:  string;
};

export const hygieneFacts: HygieneFact[] = [
  {
    icon:  '✦',
    title: 'Autoclave Sterilization',
    body:
      'All reusable equipment is sterilized in a Class B autoclave after every use. Spore tests run weekly with results on file.',
  },
  {
    icon:  '◈',
    title: 'Single-Use Needles',
    body:
      'Every needle, cartridge, and ink cap is used once and disposed of as regulated biohazard waste. No exceptions.',
  },
  {
    icon:  '◇',
    title: 'APP Member Studio',
    body:
      'Void & Vein is a member of the Association of Professional Piercers (APP) and follows the highest industry safety standards.',
  },
  {
    icon:  '◉',
    title: 'Licensed & Inspected',
    body:
      'All artists hold current Texas Department of State Health Services tattoo artist licenses. The studio is inspected annually.',
  },
];

export type FAQ = {
  q: string;
  a: string;
};

export const faqs: FAQ[] = [
  {
    q: 'What should I do immediately after getting my tattoo?',
    a: 'Your artist will wrap your fresh tattoo in medical-grade plastic wrap or a second-skin bandage. If using plastic wrap, remove it after 2–4 hours, gently wash with unscented antibacterial soap and lukewarm water, pat dry with a clean paper towel, and apply a thin layer of unscented moisturizer. If using a second-skin bandage (like Saniderm), leave it on for 3–5 days — it does the work for you.',
  },
  {
    q: 'How long does the healing process take?',
    a: 'Surface healing (when the skin looks and feels normal) takes 2–4 weeks. Full dermal healing — where the ink settles into the deeper skin layers — takes 3–6 months. During this time your tattoo may look slightly dull or cloudy; this is completely normal and resolves as healing completes.',
  },
  {
    q: 'How often should I moisturize my new tattoo?',
    a: 'For the first two weeks, moisturize 2–3 times daily with a thin, even layer of unscented lotion (Lubriderm, Aveeno unscented, or CeraVe work well). Avoid petroleum-based products like Vaseline — they can suffocate the skin and draw out ink. The goal is "just moisturized," not greasy.',
  },
  {
    q: 'Can I go swimming with a new tattoo?',
    a: 'No swimming for at least 3–4 weeks. Fresh tattoos are essentially open wounds, and submerging in chlorinated pools, lakes, or the ocean introduces bacteria and chemicals that can cause infection and fade the ink unevenly. Showers are fine — just keep them short and avoid direct high-pressure stream on the tattoo.',
  },
  {
    q: 'My tattoo is peeling and itchy. Is this normal?',
    a: 'Yes — peeling and mild itching are completely normal parts of the healing process, usually appearing around days 5–10. Do NOT pick or scratch the peeling skin. Let it fall off naturally. Picking can pull out ink and cause patchy healing. If the itching is intense, lightly slapping the area (rather than scratching) helps relieve it without damaging the tattoo.',
  },
  {
    q: 'How do I protect my tattoo from the sun?',
    a: 'Keep the tattoo out of direct sunlight during the entire healing period (2–4 weeks). After healing is complete, apply SPF 50+ broad-spectrum sunscreen whenever the tattoo will be exposed. UV radiation is the primary cause of tattoo fading over time. Long-term sun protection keeps colours vivid and black ink crisp for years longer.',
  },
  {
    q: 'What\'s the difference between black ink healing vs colour healing?',
    a: 'Black and grey tattoos typically heal more predictably — the ink settles without significant colour shift. Coloured tattoos, especially yellows and reds, may look more intense during healing and settle to a slightly softer tone once the top layer of skin regenerates. Saturated colour work by Ryo typically takes the full 3–6 months to fully reveal its healed saturation.',
  },
  {
    q: 'When can I get a touch-up if needed?',
    a: 'We ask that all clients wait a minimum of 8 weeks before returning for a touch-up. The skin needs full surface healing before we add more ink — working too soon causes trauma to tissue still in recovery. Most of our work holds beautifully without touch-ups, but if you notice any light spots or uneven areas after 8+ weeks, reach out through the booking portal.',
  },
  {
    q: 'What should I eat and drink before my appointment?',
    a: 'Eat a full, nutritious meal 1–2 hours before your session. Low blood sugar during a tattoo can cause lightheadedness, nausea, or fainting — especially during longer sessions. Bring snacks for sessions over 3 hours. Avoid alcohol for at least 24 hours beforehand — it thins the blood, causes excess bleeding, and affects how the ink settles. Stay well hydrated.',
  },
  {
    q: 'What are the signs of infection I should watch for?',
    a: 'A healing tattoo will be red, warm, and slightly swollen for the first 2–3 days — this is normal inflammation. Signs of infection include: increasing (not decreasing) redness after day 3, pus or unusual discharge, hot skin around the tattoo, red streaks extending from the site, fever, or a foul smell. If you experience any of these, seek medical attention promptly and contact us so we can document the case.',
  },
];
