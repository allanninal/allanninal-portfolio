# Day 55 — Tattoo Studio Template

> Part of the [365 Astro Templates](https://templates.allanninal.dev) project.

**Live demo:** [templates.allanninal.dev/tattoo-studio/](https://templates.allanninal.dev/tattoo-studio/)

A collector-quality tattoo studio site for artist-driven studios. Photo-heavy with multiple artist portfolios, a flash gallery, substantive aftercare FAQ, and studio hygiene callout.

## Features

- **3 resident artist profiles** — each with distinct style tags, bio, specialty list, and 2-image work gallery
- **8-image studio/work gallery** with style-label overlays
- **Flash grid** — 4 immediately-bookable designs with price, size, and artist attribution
- **Booking flow** — 3-step consultation → design → session process section
- **Safety & Hygiene callout** — autoclave, single-use needles, APP membership, prep checklist
- **10-item Aftercare FAQ** — substantive accordion covering healing, moisturizing, sun protection, swimming, peeling, color vs black, and more
- **Hours & location** — Austin TX East 6th Street studio
- **Stats band** — founded year, artist count, rating, years active

## Design

| Token | Value |
|-------|-------|
| Primary background | Ink black `#111111` |
| Accent | Electric amber-gold `#E8A020` |
| Text | Bone white `#F7F3EC` |
| Heading font | Bebas Neue (display) |
| Body font | Barlow 400/600/700 |

All text passes WCAG AA (most AAA) — amber on black is 8.7:1.

## Schema.org

`HealthAndBeautyBusiness` + `LocalBusiness` + `Person` (×3 artists) + `Service` + `Offer`

## Stack

- **Astro** 4.x static output
- **Tailwind CSS** 3.x utility classes
- **Bebas Neue** + **Barlow** via `@fontsource`
- Playwright + axe-core tests

## Quick start

```bash
npm install
npm run dev        # http://localhost:4321
npm run build      # static output → dist/
npm run preview    # serve dist/ locally
```

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PUBLIC_SITE_URL` | `https://templates.allanninal.dev` | Used in canonical + OG tags |
| `PUBLIC_BASE_PATH` | `/tattoo-studio/` | Path prefix for deploy |
| `PUBLIC_TEMPLATE_HUB_URL` | *(blank)* | Set to enable analytics + download bar |

## License

MIT — free for personal and commercial use. See [LICENSE](./LICENSE).

---

Built by [Allan Ninal](https://www.linkedin.com/in/allanninal/) · [Ko-fi](https://ko-fi.com/allanninal)
