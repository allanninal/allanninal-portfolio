import { test, expect } from '@playwright/test';

const nums = (s: string) => (s.match(/[\d.]+/g) || []).map(Number);

test.describe('Rowan Street Sound — smoke tests', () => {
  test('homepage renders with the studio in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Rowan Street Sound/);
    await expect(page.locator('h1')).toContainText('A studio is a building');
  });

  // A place with a floor area and a capacity — not day 118's Service, not
  // day 117's PodcastSeries.
  test('is a LocalBusiness described as a place', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').find((t) => t.includes('LocalBusiness')) || '');
    const s = JSON.parse(raw);
    expect(s['@type']).toBe('LocalBusiness');
    expect(s.floorSize.value).toBe(456);
    expect(s.floorSize.unitCode).toBe('FTK');
    expect(s.maximumAttendeeCapacity).toBe(9);
    expect(s.amenityFeature.length).toBeGreaterThan(8);
    expect(raw).not.toContain('OfferCatalog');
    expect(raw).not.toContain('PodcastSeries');
  });

  // The two properties a local-business page reaches for by reflex, and both
  // of them would say less than the page does.
  test('the markup declines priceRange and aggregateRating', async ({ page }) => {
    await page.goto('/');
    const raw = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || '').join(''));
    expect(raw).not.toContain('priceRange');
    expect(raw).not.toContain('aggregateRating');
    expect(raw).not.toContain('ratingValue');
    // But the page itself publishes four exact prices.
    expect(await page.locator('#rates tbody tr').count()).toBe(4);
  });

  // ── The plan ────────────────────────────────────────────────────────────
  test('the plan is drawn and visible', async ({ page }) => {
    await page.goto('/');
    const fig = page.locator('#plan figure.dwg');
    await expect(fig).toBeVisible();
    expect((await fig.boundingBox())!.height).toBeGreaterThan(200);
    await expect(fig.locator('svg')).toHaveAttribute('aria-hidden', 'true');
    expect(await fig.locator('rect.wall, rect.inner').count()).toBe(4);
  });

  // The design page claims every number in the drawing is also in the table.
  // This is that claim, checked.
  test('every dimension in the plan is also in the rooms table', async ({ page }) => {
    await page.goto('/');
    const drawn = await page.locator('#plan svg text.dlabel').allTextContents();
    const rows = await page.locator('#plan tbody tr').allTextContents();
    const roomNames = await page.locator('#plan svg text.rlabel').allTextContents();
    expect(roomNames.length).toBe(4);
    for (const n of roomNames) {
      expect(rows.some((r) => r.includes(n))).toBe(true);
    }
    // Each "W × H" label must match a Size cell, digits and all.
    const sizes = (await page.locator('#plan tbody td.v').allTextContents())
      .map((s) => nums(s).join('x'));
    for (const d of drawn.filter((t) => t.includes('×'))) {
      expect(sizes).toContain(nums(d).join('x'));
    }
  });

  // ── Will you fit ────────────────────────────────────────────────────────
  test('three diagrams, one scale, one outline', async ({ page }) => {
    await page.goto('/');
    const figs = page.locator('#fit figure.dwg');
    expect(await figs.count()).toBe(3);
    const boxes = await figs.locator('rect.wall').evaluateAll((rs) =>
      rs.map((r) => `${r.getAttribute('width')}x${r.getAttribute('height')}`));
    expect(new Set(boxes).size).toBe(1);
    for (const f of await figs.all()) {
      await expect(f.locator('svg')).toHaveAttribute('aria-hidden', 'true');
      expect(await f.locator('rect.clear').count()).toBe(1);
    }
  });

  // The one that does not fit is the one drawn crossing the clearance line.
  test('only the choir overflows, and it overflows in the drawing', async ({ page }) => {
    await page.goto('/');
    const figs = await page.locator('#fit figure.dwg').all();
    const outs = [];
    for (const f of figs) outs.push(await f.locator('circle.person--out').count());
    expect(outs[0]).toBe(0);
    expect(outs[1]).toBe(0);
    expect(outs[2]).toBeGreaterThan(3);
    await expect(figs[2].locator('figcaption')).toContainText('Does not fit');
  });

  test('every verdict prints the word and carries a glyph', async ({ page }) => {
    await page.goto('/');
    const v = page.locator('#fit table .verdict');
    const n = await v.count();
    expect(n).toBeGreaterThan(6);
    for (const el of await v.all()) {
      expect(((await el.textContent()) || '').trim().length).toBeGreaterThan(3);
      expect(await el.getAttribute('data-glyph')).toBeTruthy();
    }
    // Three states, three distinct colours, and the word never depends on them.
    const colours = await v.evaluateAll((els) =>
      [...new Set(els.map((e) => getComputedStyle(e).color))]);
    expect(colours.length).toBe(3);
  });

  test('the headline count of non-fitting arrangements is computed', async ({ page }) => {
    await page.goto('/');
    const words = await page.locator('#fit table .verdict').allTextContents();
    const no = words.filter((w) => /does not fit/i.test(w)).length;
    await expect(page.locator('#fit p.eyebrow + h2 + p')).toContainText(`${no} of the ${words.length}`);
  });

  // ── Load-in ─────────────────────────────────────────────────────────────
  test('the load-in is a sequence and the landing is the narrowest measured step', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#loadin ol.route')).toBeVisible();
    const widths = (await page.locator('#loadin ol.route .w').allTextContents())
      .filter((w) => /in/.test(w)).map((w) => nums(w)[0]);
    expect(widths.length).toBeGreaterThan(2);
    await expect(page.locator('#loadin h2')).toContainText('landing is the constraint');
    await expect(page.locator('#loadin')).toContainText('58 in');
  });

  test('the grand piano refusal is arithmetic, not taste', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#fit')).toContainText(/60 inches across the case and the landing turn is 58/);
    await expect(page.locator('#loadin')).toContainText(/does not go/i);
  });

  // ── The building ────────────────────────────────────────────────────────
  test('the building section publishes readings, not adjectives', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#building tbody tr');
    expect(await rows.count()).toBe(6);
    for (const r of await rows.all()) {
      expect(((await r.locator('td.v').textContent()) || '').trim().length).toBeGreaterThan(2);
      expect(((await r.locator('td').last().textContent()) || '').length).toBeGreaterThan(50);
    }
    await expect(page.locator('#building')).toContainText('19 dBA');
    await expect(page.locator('#building')).toContainText('31 dBA');
  });

  // ── Rates ───────────────────────────────────────────────────────────────
  test('every rate says whether the engineer is in it', async ({ page }) => {
    await page.goto('/');
    for (const r of await page.locator('#rates tbody tr').all()) {
      expect((await r.locator('td').nth(1).textContent()) || '').toMatch(/Engineer (not )?included/);
    }
    await expect(page.locator('#rates')).toContainText(/six and a half hours of tape/);
  });

  test('the booking form uses radios, not a dropdown', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('select').count()).toBe(0);
    const radios = page.locator('#book input[type="radio"]');
    expect(await radios.count()).toBe(4);
    await expect(page.locator('#book fieldset legend')).toHaveText(/Which booking/);
    for (const id of ['#name', '#email', '#lineup']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  test('the FAQ is an accordion', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('no trace of the day-118 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['hollis yeo', 'louisville', 'buy-out', 'usage licence', 'territory']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0); const x = window.scrollX; window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro session plan is absent from the free build', async ({ page }) => {
    const res = await page.goto('/session-plan/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
