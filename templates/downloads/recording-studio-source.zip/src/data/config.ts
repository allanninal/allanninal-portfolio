// Rowan Street Sound — Asheville, NC. Fictional, and every dimension on the
// page is internally consistent: the plan, the fit table and the load-in list
// are all generated from the numbers in this file, so none of them can drift
// away from the others.
//
// The organising idea: a studio is a building. Door widths, a stair turn,
// ceiling height and what the air handling does in August decide more bookings
// than any preamp does, and no studio site publishes any of it.

export const site = {
  name:        'Rowan Street Sound',
  shortName:   'Rowan Street',
  title:       'Rowan Street Sound — a third-floor room in Asheville',
  tagline:     'A studio is a building.',
  owner:       'Teodor Maas',
  ownerRole:   'Engineer and owner',
  credential:  'Third floor · since 2016 · 24 ft × 19 ft live room',
  city:        'Asheville',
  state:       'NC',
  language:    'en',
  phoneDisplay: '(828) 555-0164',
  phoneHref:   '+18285550164',
  email:       'teo@rowanstreetsound.example',
  streetAddress: '41 Rowan St, Floor 3',
  postalCode:  '28801',
  hours:       'Sessions 10–10 · load-in from 9 · no tracking before 10am, the floor below is a bakery',
  bookingWindow: 'Booked two to five weeks out · hold with a date, not a deposit',
  description:
    'Every studio site opens with a gear list. None of them tell you whether your band fits in the ' +
    'room, whether the organ gets up the stairs, or what happens to a take when the air handling ' +
    'has to be off in August. This one is drawn to scale and answers those first.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The plan',    href: '#plan' },
  { label: 'Will you fit', href: '#fit' },
  { label: 'Load-in',     href: '#loadin' },
  { label: 'Book',        href: '#book' },
];

// ── The floor, to scale ───────────────────────────────────────────────────
// Feet. The plan SVG is generated from these, so the drawing cannot disagree
// with the table beside it.

export const floor = {
  ceiling: 12.5,
  storey: 3,
  // Feet of clearance the live room needs on every wall before a source
  // starts hearing the wall instead of the room. Measured, and it is the
  // number that decides the choir question — the floor area never was.
  clearance: 4,
  rooms: [
    { id: 'live',    name: 'Live room',    x: 0,    y: 0,    w: 24, h: 19, door: 30,
      note: 'Timber floor over joists, 12 ft 6 in to the underside of the beams. The one room in the building that is genuinely quiet.' },
    { id: 'control', name: 'Control room', x: 24.5, y: 0,    w: 14, h: 12, door: 30,
      note: 'Not symmetrical, and it is corrected rather than pretended about. The listening position is 38% of the room length from the front wall.' },
    { id: 'booth',   name: 'Iso booth',    x: 24.5, y: 12.5, w: 7,  h: 6.5, door: 26,
      note: 'Fits a guitar cabinet and a chair, or one vocalist standing. Not both, and anyone who tells you their booth does both has a bigger booth.' },
    { id: 'lounge',  name: 'Lounge',       x: 32,   y: 12.5, w: 6.5, h: 6.5, door: 28,
      note: 'A kettle, a sofa and the only window that opens. More sessions are saved here than in the control room.' },
  ],
};

export const floorNote =
  'Drawn to scale from a tape measure, not from the lease. The live room is 456 square feet with ' +
  'a 12 ft 6 in ceiling, which is the single number that decides whether a loud kit sounds like a ' +
  'kit or like a room fighting one. The dashed line inside it is four feet from every wall: get ' +
  'closer than that and a source starts hearing the wall rather than the room. Everything below ' +
  'is generated from the same measurements.';

// ── Will you fit ──────────────────────────────────────────────────────────
// Three of these are drawn into the live-room outline. `fits` is one of
// 'yes' | 'tight' | 'no' — never colour alone: each row prints the word.

export const ensembles = [
  { id: 'four', name: 'Four-piece band, live', fits: 'yes',
    people: 4, needs: 'Kit, two amps in the booth and the lounge, scratch vocal in the corner',
    why: 'The default, and everything sits inside the four-foot clearance. Everyone has sightlines to the kit without headphones and the amps are in two different rooms, so the bleed is a choice rather than an accident.',
    // Drawn positions in feet inside the 24×19 live room, r = radius in feet.
    marks: [ {x:8,y:7,r:3,l:'Kit'}, {x:15,y:6.5,r:1.6,l:'Bass'}, {x:17,y:11,r:1.6,l:'Gtr'}, {x:7,y:12.8,r:1.6,l:'Vox'} ] },
  { id: 'quartet', name: 'String quartet', fits: 'yes',
    people: 4, needs: 'Four chairs in an arc, two mains and two spots',
    why: 'Everybody clears the walls by more than the four feet the room needs. The mains go up at nine feet, which the 12 ft 6 in ceiling allows and a ten-foot ceiling would not.',
    marks: [ {x:9,y:7,r:1.5,l:'Vn1'}, {x:13,y:6.5,r:1.5,l:'Vn2'}, {x:15,y:10,r:1.5,l:'Va'}, {x:11,y:12,r:1.7,l:'Vc'} ] },
  { id: 'choir', name: 'Fourteen-voice choir', fits: 'no',
    people: 14, needs: 'Three rows and a conductor, which is more depth than the room has',
    why: 'It does not fit, and the reason is depth rather than floor area — there is plenty of floor. Three rows plus a conductor is about 17 feet front to back in a room that has 11 feet between its clearance lines, so the back row and the conductor both end up inside four feet of a wall and sound exactly like it. Nine voices is the honest ceiling here. The Methodist church on Haywood is a better room for this and I will make the call.',
    marks: [ {x:12,y:2.6,r:1.3,l:''},
             {x:5,y:6,r:1.3,l:''}, {x:8,y:6,r:1.3,l:''}, {x:11,y:6,r:1.3,l:''}, {x:14,y:6,r:1.3,l:''}, {x:17,y:6,r:1.3,l:''},
             {x:6.5,y:10.5,r:1.3,l:''}, {x:9.5,y:10.5,r:1.3,l:''}, {x:12.5,y:10.5,r:1.3,l:''}, {x:15.5,y:10.5,r:1.3,l:''}, {x:18.5,y:10.5,r:1.3,l:''},
             {x:8,y:15,r:1.3,l:''}, {x:11,y:15,r:1.3,l:''}, {x:14,y:15,r:1.3,l:''}, {x:17,y:15,r:1.3,l:''} ] },
];

// Rows that are only in the table, because drawing all seven would be a
// diagram nobody reads.
export const alsoFits = [
  { name: 'Solo acoustic and vocal', fits: 'yes',   why: 'Guitar and voice together in the live room, two mics, no headphones. This is the room at its best and it is also the cheapest way to use it.' },
  { name: 'Drums alone, loud',       fits: 'yes',   why: 'What the 12 ft 6 in ceiling is for. Room mics at 11 feet in the far corner are most of the sound and they are free.' },
  { name: 'Full horn section, five', fits: 'tight', why: 'Fits with the section standing in an arc and the trombone slide pointing into the room rather than at a wall. Book the half day, not the two-hour.' },
  { name: 'Nine-piece with kit',     fits: 'tight', why: 'The absolute ceiling. Amps go to the booth and the lounge, which means two players cannot see the drummer, which means a click. Say so when you book.' },
  { name: 'Grand piano',             fits: 'no',    why: 'There is not one, and there will not be. A 7-foot grand is 60 inches across the case and the landing turn is 58. It has been measured twice by two different piano movers.' },
];

// ── Load-in ───────────────────────────────────────────────────────────────

export const loadin = {
  stairs: 34,
  turn: 58,
  steps: [
    { k: 'The kerb',      w: '—',   n: 'Two loading spaces outside from 9am, unmetered until noon. After noon it is the deck on Rankin, which is 90 yards and a slope.' },
    { k: 'Street door',   w: '35 in', n: 'Propped open with a wedge that lives behind it. This is the widest thing on the route and it is not the constraint.' },
    { k: 'The stairs',    w: '—',   n: '34 treads in two flights with a turn. Nothing longer than about six feet gets round the turn upright, which is why the answer to the organ question is no.' },
    { k: 'The landing',   w: '58 in', n: 'The constraint. Measured corner to corner, not wall to wall, because that is the diagonal a case actually travels.' },
    { k: 'Live room door', w: '30 in', n: 'Doors come off their hinges in about four minutes if something needs the extra inch and a half. It has been done nine times.' },
  ],
  refused: [
    { what: 'Hammond B3 with bench', n: '44 in wide and 425 lb. It has been up twice, both times with four people and a stair dolly, and both times I said never again. The Nord is in the control room for a reason.' },
    { what: 'Leslie 122',            n: 'Came up on its side and went back down the same way. Fine, but budget forty minutes at each end and do not book it against a hard out.' },
    { what: '7-foot grand',          n: 'Does not go round the turn. Not "difficult" — does not go.' },
  ],
};

// ── What the building does to the sound ───────────────────────────────────

export const building = [
  { k: 'Noise floor, air handling off', v: '19 dBA', n: 'Measured at the live-room centre, C-weighted slow, at 3am with the building empty. This is the honest floor and it is why the air handling goes off.' },
  { k: 'Noise floor, air handling on',  v: '31 dBA', n: 'Twelve decibels is the difference between a quiet room and a room. It runs between takes and not during them, which is a working method rather than a fault.' },
  { k: 'Room temperature drift',        v: '+2°C/hr', n: 'In July, with the handling off and four people in. In practice that is a hard stop at about ninety minutes before somebody has to open the lounge window.' },
  { k: 'Live room RT60, 500 Hz',        v: '0.62 s',  n: 'Measured, not modelled. Long for a small studio and deliberately so — the room is meant to be audible on the record rather than removed from it.' },
  { k: 'The bakery, below',             v: 'From 4am', n: 'Mixers and a walk-in compressor. Inaudible above 100 Hz and slightly audible below it, which is why nothing gets tracked in here before ten.' },
  { k: 'The dance studio, above',       v: 'Tue/Thu 6–8pm', n: 'Footfall through the joists. Nothing acoustic fixes a floor above you, so those four hours are booked for overdubs and mixing and never for drums.' },
];

// ── The gear that changes the record ──────────────────────────────────────

export const gear = {
  four: [
    { k: 'The room',         n: 'A 456 sq ft timber floor at 0.62 seconds. It is the most expensive thing in the building and the only one that cannot be hired for the day.' },
    { k: 'Two ribbon mics',  n: 'Coles 4038s as room pair. Ninety per cent of what people like about drums recorded here is these two microphones eleven feet up.' },
    { k: 'A 1970s console',  n: 'Sixteen channels of it, used as a summing and preamp box rather than as a mixer. Recall is a photograph and a notebook, which is a real cost and worth it.' },
    { k: 'Somebody who has been here nine years', n: 'Knowing that the second window rattles at 94 Hz is not a spec. It is the difference between a usable take and a re-take, and it is not transferable to a different building.' },
  ],
  restNote:
    'There is a list — the usual preamps, the usual compressors, four more microphones than anybody needs, and a Nord because the organ does not come up the stairs. It is two pages, it is sent on request, and it has never once been the reason somebody booked. If a studio leads with its list, ask what its room measures.',
};

// ── Rates ─────────────────────────────────────────────────────────────────

export const rates = {
  rows: [
    { k: 'Day, 10 hours',   v: '$620', e: 'Engineer included', n: 'The normal booking. Load-in from 9, first take usually around 10:40, and the last hour is for rough mixes rather than for one more take.' },
    { k: 'Half day, 5 hours', v: '$360', e: 'Engineer included', n: 'Enough for overdubs or a solo session. Not enough to set up and record a full kit, and I will say so rather than take the booking.' },
    { k: 'Lockout, per day',  v: '$480', e: 'Engineer not included', n: 'You bring your own engineer and the room is yours for 24 hours. Cheaper because I am not in it, which is the honest reason.' },
    { k: 'Weekly lockout',    v: '$2,600', e: 'Engineer not included', n: 'Seven days. Includes the lounge, the kettle and a key, and it is the only booking where the air handling schedule becomes your problem rather than mine.' },
  ],
  note:
    'A ten-hour day contains about six and a half hours of tape. The rest is load-in, setup, tuning, ' +
    'a tea break that everybody needs, and teardown. Any studio quoting an hourly rate against ' +
    'tracked minutes is quoting a number that has never existed.',
};

export const said = {
  text: 'The floor plan arrived with the stair landing measured on it before we had even agreed a date, and with it a note that the organ would not go up. It saved us a rental and a wasted morning, and we booked on the strength of that one email.',
  who: 'Bandleader, five-piece — 2025',
};

export const faqs = [
  {
    q: 'Is the engineer included?',
    a: 'On the day and the half day, yes — that is me, for the whole booking, and there is no separate line. On a lockout, no: you bring your own and the price drops by $140 a day, which is the honest difference rather than a discount.',
  },
  {
    q: 'How loud can we be?',
    a: 'As loud as you like between 10am and 10pm, with two exceptions. Tuesdays and Thursdays from six to eight there is a dance class directly above and the footfall comes through the joists, so those hours are for overdubs and mixing. And nothing before ten, because the bakery below is a working business and the goodwill is worth more than the two hours.',
  },
  {
    q: 'Will our gear get up there?',
    a: 'Thirty-four treads, two flights, one turn with 58 inches of diagonal on the landing. Anything under six feet long or 33 inches wide goes up without drama. Beyond that, send me the dimensions before you book — I have measured the turn twice and I would rather tell you no by email than have you find out with a van outside.',
  },
  {
    q: 'Do you have a piano?',
    a: 'No, and there will not be one. A 7-foot grand is 60 inches across the case and the landing turn is 58. There is a Nord in the control room and an upright at the church on Haywood if a real piano is genuinely the sound, which I can arrange.',
  },
  {
    q: 'What actually happens in a ten-hour day?',
    a: 'Roughly: an hour of load-in and setup, forty minutes of drum tuning and mic placement, six and a half hours of tracking in blocks, an hour that disappears into lunch and one conversation about the second chorus, and the last forty minutes on rough mixes so you leave with something to listen to in the car.',
  },
  {
    q: 'Can we mix here later?',
    a: 'Yes, at the half-day rate, and it is usually a mistake to book it in the same week. The control room is not symmetrical, it is corrected rather than pretended about, and it is a better mix room on a Tuesday morning than it is at hour eleven of a tracking day.',
  },
];
