import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Lumière Catering/);
});

test('hero section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero')).toBeVisible();
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('services section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#services')).toBeVisible();
});

test('packages section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#packages')).toBeVisible();
});

test('packages section has 3 package cards', async ({ page }) => {
  await page.goto('/');
  const packages = page.locator('#packages article');
  const count = await packages.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('process section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#process')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('inquiry form is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#inquiry')).toBeVisible();
});

test('inquiry form has required fields', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#name')).toBeVisible();
  await expect(page.locator('#email')).toBeVisible();
  await expect(page.locator('#event-type')).toBeVisible();
  await expect(page.locator('#event-date')).toBeVisible();
  await expect(page.locator('#guest-count')).toBeVisible();
});

test('contact section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#contact')).toBeVisible();
});

test('LinkedIn contact link is present', async ({ page }) => {
  await page.goto('/');
  const contactSection = page.locator('#contact');
  const linkedinLink = contactSection.locator('a[href*="linkedin.com"]');
  await expect(linkedinLink).toBeVisible();
});

test('navigation has correct links', async ({ page }) => {
  await page.goto('/');
  const nav = page.locator('header nav').first();
  await expect(nav).toBeVisible();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('skip link exists', async ({ page }) => {
  await page.goto('/');
  const skipLink = page.locator('.skip-link');
  await expect(skipLink).toBeAttached();
});

test('mobile menu toggle exists', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  await expect(page.locator('#mobile-menu-toggle')).toBeVisible();
});

test('mobile menu opens on toggle click', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  const toggle = page.locator('#mobile-menu-toggle');
  const menu = page.locator('#mobile-menu');
  await toggle.click();
  await expect(menu).toBeVisible();
});
