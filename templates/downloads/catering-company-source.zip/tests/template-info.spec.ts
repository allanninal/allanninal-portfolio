import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo bar has download and All 365 links', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(BAR);
  await expect(bar).toBeVisible();
  await expect(bar.locator('a', { hasText: 'All 365' })).toBeVisible();
  // Static download present in both editions.
  await expect(bar.locator('a[download]').first()).toBeVisible();
});

test('TemplateInfo bar links to LinkedIn (Build with me / Get Pro static)', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(BAR);
  const link = bar.locator('a', { hasText: isPro ? 'Get Pro static' : 'Build with me' });
  await expect(link).toBeVisible();
  expect(await link.getAttribute('href')).toContain('linkedin.com');
});

test('TemplateInfo bar has no private github.com/allanninal/templates links', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator(`${BAR} a[href*="github.com/allanninal/templates"]`);
  expect(await badLinks.count()).toBe(0);
});
