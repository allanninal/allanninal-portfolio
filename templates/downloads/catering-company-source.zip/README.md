# Day 48 — Catering Company

**Lumière Catering** — a full-service event catering company landing page. Polished multi-section site covering weddings, corporate events, private celebrations, and galas with per-head pricing packages, a portfolio gallery, testimonials, process walkthrough, and an event-inquiry form.

**Palette:** Midnight Navy `#1B2B4B` · Champagne Gold `#C9A96E` · Warm Cream `#FAF7F0` · Sage `#7A9A7E`
**Fonts:** Marcellus (display serif) + Mulish (body sans)
**Schema:** `FoodService` + `Organization` with `Offer` JSON-LD per package

Live demo: <https://templates.allanninal.dev/catering-company/>

---

## Sections

1. **Hero** — Full-viewport navy hero with gold accent, tagline, stats band (events, chefs, satisfaction, years)
2. **Services** — 4 event types: Weddings, Corporate Events, Private Celebrations, Galas & Fundraisers
3. **Packages** — 3 pricing tiers (Silver $85/head · Gold $145/head · Platinum $220/head) with sample menus
4. **Gallery** — 6-item portfolio grid with hover overlays
5. **Testimonials** — 3 client reviews with star ratings
6. **Process** — 4-step "how we work" section
7. **About** — Company story, founding, team, sourcing philosophy
8. **Inquiry Form** — Event date, guest count, event type, budget, package preference, message
9. **Contact** — Phone, email, LinkedIn

---

## Quick start

```bash
npm install
npm run dev
```

### Environment variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

| Variable | Default | Description |
|---|---|---|
| `PUBLIC_SITE_URL` | `https://templates.allanninal.dev` | Canonical site URL |
| `PUBLIC_BASE_PATH` | `/catering-company/` | Sub-path for GitHub Pages deployment |
| `PUBLIC_TEMPLATE_HUB_URL` | *(blank)* | Set to the hub URL to enable the download bar + analytics |

---

## Customise

### Brand & copy
Edit `src/data/config.ts` to update company name, tagline, phone, email, address, social links.

### Services, packages, gallery, testimonials
All content is in `src/pages/index.astro` — plain TypeScript arrays near the top of the file. No CMS needed.

### Colours
Modify `tailwind.config.mjs` and the CSS variables in `src/styles/global.css`.

### Fonts
Replace the `@fontsource` imports in `src/styles/global.css` and update `fontFamily` in `tailwind.config.mjs`.

### Inquiry form
The form posts to Formspree by default. Replace the `action` attribute in `src/pages/index.astro` with your own endpoint (Formspree, Basin, Netlify Forms, etc.).

---

## Deploy to GitHub Pages

1. Push to your own repo
2. Repo Settings → Pages → Source: **GitHub Actions**
3. The root `.github/workflows/pages.yml` builds and deploys on every push to `main`

---

## Tests

```bash
npm run test            # Playwright smoke + a11y + links + template-info
npm run test:a11y       # axe-core WCAG 2.1 AA
npm run test:links      # No broken internal links, correct rel attributes
npm run test:lighthouse # Lighthouse CI ≥ 95 on all 4 categories
```

---

## License

MIT — free for personal and commercial use. Attribution appreciated but not required.

Built by [Allan Ninal](https://www.linkedin.com/in/allanninal/) · [allanninal.dev](https://allanninal.dev)
