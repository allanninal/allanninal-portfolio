import { defineConfig } from 'astro/config';
import mdx from '@astrojs/mdx';
import sitemap from '@astrojs/sitemap';
import tailwind from '@astrojs/tailwind';
import remarkGfm from 'remark-gfm';

const SITE = process.env.PUBLIC_SITE_URL || 'https://example.com';
const BASE = process.env.PUBLIC_BASE_PATH || '/personal-blog/';

const siteUrl = SITE.endsWith('/') ? SITE.slice(0, -1) : SITE;

export default defineConfig({
  site: siteUrl,
  base: BASE,
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  markdown: {
    remarkPlugins: [remarkGfm],
    shikiConfig: {
      // Dual theme — Shiki emits CSS variables; the .dark / light selectors
      // pick which palette renders. Vesper is warm amber/ochre, contrasting
      // with the cold-blue github-dark used by most blog templates.
      themes: {
        light: 'github-light',
        dark: 'vesper',
      },
      wrap: false,
    },
  },
  integrations: [
    tailwind({ applyBaseStyles: false }),
    mdx(),
    sitemap({
      customPages: [`${siteUrl}${BASE.endsWith('/') ? BASE : `${BASE}/`}`],
    }),
  ],
});
