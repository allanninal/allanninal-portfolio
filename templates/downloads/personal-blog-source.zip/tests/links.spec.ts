import { test, expect } from '@playwright/test';

// External links must open safely ──────────────────────────────────────────

test('all target=_blank links have rel="noopener noreferrer"', async ({ page }) => {
  await page.goto('/');
  const ext = await page.locator('a[target="_blank"]').all();
  const unsafe: string[] = [];
  for (const a of ext) {
    const rel = await a.getAttribute('rel');
    const href = await a.getAttribute('href');
    if (!rel || !rel.includes('noopener') || !rel.includes('noreferrer')) {
      unsafe.push(`${href} — rel="${rel}"`);
    }
  }
  expect(unsafe, `Unsafe external links:\n${unsafe.join('\n')}`).toEqual([]);
});

// Internal links resolve ───────────────────────────────────────────────────

test('all internal links on home resolve successfully', async ({ page }) => {
  await page.goto('/');
  const links = await page.locator('a[href]').all();
  const broken: string[] = [];
  for (const link of links) {
    const href = await link.getAttribute('href');
    if (!href) continue;
    if (href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) continue;
    if (href.startsWith('http') && !href.includes('localhost')) continue;
    if (href.startsWith('/') || !href.startsWith('http')) {
      try {
        const url = href.startsWith('/') ? `http://localhost:4321${href}` : href;
        const res = await page.request.get(url);
        if (!res.ok()) broken.push(`${href} → ${res.status()}`);
      } catch {
        broken.push(`${href} → fetch failed`);
      }
    }
  }
  expect(broken, `Broken internal links:\n${broken.join('\n')}`).toEqual([]);
});

// Mailto well-formed ───────────────────────────────────────────────────────

test('mailto links use a valid email format', async ({ page }) => {
  await page.goto('/');
  const mailtos = await page.locator('a[href^="mailto:"]').all();
  for (const m of mailtos) {
    const href = await m.getAttribute('href');
    expect(href).toMatch(/^mailto:[^\s@]+@[^\s@]+\.[^\s@]+/);
  }
});

// Every post page links back to home ──────────────────────────────────────

test('post page has a "Back to essays" link to home', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  const back = page.getByRole('link', { name: /back to essays/i });
  await expect(back).toBeVisible();
});
