import { test, expect } from '@playwright/test';
import { ROUTES, setTheme } from './helpers';

for (const route of ROUTES) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${route} renders correctly in ${theme} mode`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);

      const dataTheme = await page.evaluate(() => document.documentElement.dataset.theme);
      expect(dataTheme).toBe(theme);

      const hasClass = await page.evaluate(
        (t) => document.documentElement.classList.contains('dark') === (t === 'dark'),
        theme,
      );
      expect(hasClass).toBe(true);

      await expect(page.locator('h1').first()).toBeVisible();
    });
  }
}

test('default mode is decided by system preference + localStorage', async ({ page }) => {
  await page.addInitScript(() => localStorage.removeItem('theme'));
  await page.emulateMedia({ colorScheme: 'light' });
  await page.goto('/');
  const dataTheme = await page.evaluate(() => document.documentElement.dataset.theme);
  expect(['light', 'dark']).toContain(dataTheme);
});

test('post body color in dark mode uses #E8E6DF (warm off-white, not pure white)', async ({
  page,
}) => {
  await page.goto('/blog/measure-before-you-cache/');
  await setTheme(page, 'dark');
  const bodyColor = await page.evaluate(() => {
    const proseEl = document.querySelector('.prose-blog p');
    return proseEl ? getComputedStyle(proseEl).color : '';
  });
  // #E8E6DF normalized to rgb
  expect(bodyColor).toBe('rgb(232, 230, 223)');
});
