import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    const errors: string[] = [];
    // Ignore third-party noise from the author-deploy analytics/ads stack
    // (GA + AdSense), which 403/CSP-warn under a real Chrome but never under
    // the bundled headless browser. None of it is the template's own code.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead|google\.com|content security policy|frame-ancestors|report-only/i;
    const isThirdParty = (m: ConsoleMessage) =>
      THIRD_PARTY.test(m.text()) ||
      THIRD_PARTY.test(m.location()?.url ?? '') ||
      /failed to load resource/i.test(m.text());
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() === 'error' && !isThirdParty(m)) errors.push(`console.error: ${m.text()}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home meta description is present', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(10);
});

test('home has WebSite + Person JSON-LD', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  expect(scripts.length).toBeGreaterThanOrEqual(2);

  const types = await Promise.all(
    scripts.map(async (s) => JSON.parse((await s.textContent())!)['@type']),
  );
  expect(types).toContain('WebSite');
  expect(types).toContain('Person');
});

test('post page has BlogPosting JSON-LD with timeRequired and wordCount', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const blogPosting = (
    await Promise.all(scripts.map(async (s) => JSON.parse((await s.textContent())!)))
  ).find((d) => d['@type'] === 'BlogPosting');

  expect(blogPosting).toBeTruthy();
  expect(blogPosting.headline).toBeTruthy();
  expect(blogPosting.datePublished).toBeTruthy();
  expect(blogPosting.timeRequired).toMatch(/^PT\d+M$/);
  expect(typeof blogPosting.wordCount).toBe('number');
  expect(blogPosting.wordCount).toBeGreaterThan(50);
});

test('tag page has CollectionPage JSON-LD', async ({ page }) => {
  await page.goto('/tags/engineering-habits/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const collection = (
    await Promise.all(scripts.map(async (s) => JSON.parse((await s.textContent())!)))
  ).find((d) => d['@type'] === 'CollectionPage');
  expect(collection).toBeTruthy();
});

test('OG type is "article" on post pages and "website" elsewhere', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  expect(await page.locator('meta[property="og:type"]').getAttribute('content')).toBe('article');

  await page.goto('/');
  expect(await page.locator('meta[property="og:type"]').getAttribute('content')).toBe('website');
});

test('canonical URLs are absolute on every route', async ({ page }) => {
  for (const route of ROUTES) {
    await page.goto(route);
    const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
    expect(canonical, `canonical missing on ${route}`).toBeTruthy();
    expect(canonical, `canonical not absolute on ${route}`).toMatch(/^https?:\/\//);
  }
});

test('RSS link tag in <head> points to /rss.xml', async ({ page }) => {
  await page.goto('/');
  const href = await page
    .locator('link[rel="alternate"][type="application/rss+xml"]')
    .getAttribute('href');
  expect(href).toBeTruthy();
  expect(href).toContain('rss.xml');
});

test('rss.xml is reachable and contains full content', async ({ page }) => {
  const res = await page.goto('/rss.xml');
  expect(res?.status()).toBe(200);
  const body = await page.content();
  // Full-content RSS — the marker "<content:encoded>" appears for each item
  expect(body).toContain('content:encoded');
  // Channel-level metadata
  expect(body).toContain('<language>en-us</language>');
  // At least one essay title in the feed
  expect(body).toContain('Measure before you cache');
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});
