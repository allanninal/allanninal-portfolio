import type { Page } from '@playwright/test';

// Routes that exist on the live preview build (PUBLIC_BASE_PATH=/).
// The Pro edition (PUBLIC_EDITION=pro) adds the curated /start-here/ guide;
// the free build redirects that path, so it's only a real route under Pro.
export const ROUTES = [
  '/',
  '/about/',
  '/now/',
  '/tags/',
  '/tags/engineering-habits/',
  '/blog/measure-before-you-cache/',
  ...(process.env.PUBLIC_EDITION === 'pro' ? ['/start-here/'] : []),
];

export const VIEWPORTS = [
  { name: 'mobile',  width: 375,  height: 667 },
  { name: 'tablet',  width: 768,  height: 1024 },
  { name: 'desktop', width: 1280, height: 720 },
  { name: 'wide',    width: 1920, height: 1080 },
];

export async function setTheme(page: Page, theme: 'light' | 'dark') {
  await page.emulateMedia({ colorScheme: theme });
  await page.evaluate((t) => {
    document.documentElement.classList.toggle('dark', t === 'dark');
    document.documentElement.dataset.theme = t;
    localStorage.setItem('theme', t);
  }, theme);
}
