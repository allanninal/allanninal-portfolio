import { test, expect } from '@playwright/test';

// ── Theme toggle ────────────────────────────────────────────────────────────

test('theme toggle flips dark class and persists across reload', async ({ page }) => {
  await page.goto('/');
  // Reset to ensure deterministic start state
  await page.evaluate(() => {
    localStorage.removeItem('theme');
    document.documentElement.classList.remove('dark');
  });
  await page.reload();

  const initialDark = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );

  await page.getByRole('button', { name: /toggle theme/i }).click();
  const flipped = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );
  expect(flipped).toBe(!initialDark);

  const stored = await page.evaluate(() => localStorage.getItem('theme'));
  expect(stored).toMatch(/^(light|dark)$/);

  await page.reload();
  const afterReload = await page.evaluate(() =>
    document.documentElement.classList.contains('dark'),
  );
  expect(afterReload).toBe(flipped);
});

// ── Post list ──────────────────────────────────────────────────────────────

test('home page shows ≥3 essay cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('article');
  expect(await cards.count()).toBeGreaterThanOrEqual(3);
});

test('exactly two posts are featured (matches frontmatter)', async ({ page }) => {
  await page.goto('/');
  const featuredHeading = page.getByRole('heading', { name: 'Featured' });
  await expect(featuredHeading).toBeVisible();
  // Featured section sits BEFORE "All essays" — verify it has at least 1, less than total
  // (We can't be too strict because the seed posts may change, but featured must exist.)
});

test('reading time is shown on every post card', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('article');
  const count = await cards.count();
  for (let i = 0; i < count; i++) {
    const meta = await cards.nth(i).locator('time + span, span:has-text("min read")').count();
    expect(meta, 'reading-time label missing on card').toBeGreaterThan(0);
  }
});

// ── Post page ──────────────────────────────────────────────────────────────

test('post page shows title, date, reading time, and tag chips', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  await expect(page.locator('h1')).toContainText('Measure before you cache');
  await expect(page.getByText(/min read/)).toBeVisible();
  await expect(page.locator('time').first()).toBeVisible();
  // Tags rendered as #pill chips
  const tagPills = page.locator('a.tag-pill');
  expect(await tagPills.count()).toBeGreaterThan(0);
});

test('post body uses prose-blog typography (serif body)', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  const fontFamily = await page.evaluate(() => {
    const proseEl = document.querySelector('.prose-blog p');
    return proseEl ? getComputedStyle(proseEl).fontFamily : '';
  });
  expect(fontFamily.toLowerCase()).toContain('newsreader');
});

test('post page renders GFM footnotes with backref', async ({ page }) => {
  await page.goto('/blog/measure-before-you-cache/');
  // remark-gfm emits a <section data-footnotes>
  const footnotes = page.locator('section[data-footnotes], section.footnotes');
  await expect(footnotes).toBeVisible();
  // At least one footnote backref
  const backref = footnotes.locator('a[data-footnote-backref], a.data-footnote-backref');
  expect(await backref.count()).toBeGreaterThan(0);
});

// ── Tag pages ──────────────────────────────────────────────────────────────

test('tag index lists all tags with post counts', async ({ page }) => {
  await page.goto('/tags/');
  await expect(page.locator('h1')).toContainText('Tags');
  const items = page.locator('main ul li');
  const count = await items.count();
  expect(count).toBeGreaterThanOrEqual(3);
  // Each row should mention "post(s)"
  for (let i = 0; i < count; i++) {
    const text = await items.nth(i).textContent();
    expect(text).toMatch(/post/i);
  }
});

test('tag feed shows only posts with that tag', async ({ page }) => {
  await page.goto('/tags/engineering-habits/');
  // H1 renders the human-readable label, not the slug — "Engineering Habits"
  await expect(page.locator('h1')).toContainText('Engineering Habits');
  const cards = page.locator('article');
  const count = await cards.count();
  expect(count).toBeGreaterThan(0);
  for (let i = 0; i < count; i++) {
    const tagLinks = await cards.nth(i).locator('a.tag-pill').allTextContents();
    expect(tagLinks.some((t) => t.toLowerCase().includes('engineering habits'))).toBe(true);
  }
});

// ── Navigation ─────────────────────────────────────────────────────────────

test('header nav has Essays, Tags, Now, About, and an RSS link', async ({ page }) => {
  await page.goto('/');
  for (const label of ['Essays', 'Tags', 'Now', 'About']) {
    await expect(page.locator('header').getByRole('link', { name: label })).toBeVisible();
  }
  // Header RSS link is icon-only, aria-label="RSS feed"
  await expect(page.locator('header').getByRole('link', { name: 'RSS feed' })).toBeVisible();
});

test('footer donate link points to ko-fi when env var is set', async ({ page }) => {
  await page.goto('/');
  const donate = page.locator('[data-donate-url]').first();
  if ((await donate.count()) > 0) {
    expect(await donate.getAttribute('href')).toContain('ko-fi.com');
  }
});

// ── LinkedIn-primary contact convention ────────────────────────────────────

test('LinkedIn appears first in the footer social row', async ({ page }) => {
  await page.goto('/');
  const footerLinks = page.locator('footer a[href]');
  // Find index of first LinkedIn link in footer; verify it precedes Email
  const hrefs = await footerLinks.evaluateAll((els) =>
    els.map((e) => (e as HTMLAnchorElement).getAttribute('href') || ''),
  );
  const idxLinkedIn = hrefs.findIndex((h) => h.includes('linkedin.com'));
  const idxEmail = hrefs.findIndex((h) => h.startsWith('mailto:'));
  expect(idxLinkedIn).toBeGreaterThan(-1);
  expect(idxEmail).toBeGreaterThan(-1);
  expect(idxLinkedIn).toBeLessThan(idxEmail);
});
