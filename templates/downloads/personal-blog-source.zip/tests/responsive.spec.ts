import { test, expect } from '@playwright/test';
import { ROUTES, VIEWPORTS } from './helpers';

// No horizontal scroll at any viewport on any route ─────────────────────────

for (const route of ROUTES) {
  for (const vp of VIEWPORTS) {
    test(`${route} @ ${vp.name} (${vp.width}x${vp.height}) — no horizontal scroll`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto(route);
      await page.locator('h1').first().waitFor();
      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth,
      );
      expect(overflow).toBe(false);
    });
  }
}

// Mobile: post body is constrained to readable measure ──────────────────────

test('post body measures ≤68ch on desktop', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto('/blog/measure-before-you-cache/');
  const proseWidth = await page.evaluate(() => {
    const el = document.querySelector('.prose-blog');
    if (!el) return null;
    return (el as HTMLElement).getBoundingClientRect().width;
  });
  // 68ch in Newsreader at ~18px is roughly 600-680px; allow some headroom.
  expect(proseWidth).not.toBeNull();
  expect(proseWidth!).toBeLessThan(820);
});

// Tap targets on the header nav ─────────────────────────────────────────────

test('theme toggle button meets 36px tap target', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  const btn = page.getByRole('button', { name: /toggle theme/i });
  const box = await btn.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.height).toBeGreaterThanOrEqual(28); // small icon button — 28-36 ok
  expect(box!.width).toBeGreaterThanOrEqual(28);
});
