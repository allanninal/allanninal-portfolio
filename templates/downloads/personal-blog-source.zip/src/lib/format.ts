// Date + reading-time formatters. Centralized so display strings are consistent
// across post cards, post pages, RSS, and JSON-LD.

const dateFmt = new Intl.DateTimeFormat('en-US', {
  month: 'long',
  day: 'numeric',
  year: 'numeric',
});

const dateShortFmt = new Intl.DateTimeFormat('en-US', {
  month: 'short',
  day: '2-digit',
  year: 'numeric',
});

export function formatDate(date: Date): string {
  return dateFmt.format(date);
}

export function formatDateShort(date: Date): string {
  return dateShortFmt.format(date);
}

// ISO 8601 duration for schema.org timeRequired property.
// 9.4 minutes -> "PT9M". Always rounds up so a "9 min read" reports as PT9M.
export function isoDuration(minutes: number): string {
  return `PT${Math.max(1, Math.round(minutes))}M`;
}
