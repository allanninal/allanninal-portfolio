// Tag slugification — display label "Build Systems" → URL slug "build-systems".
// Stored as human-readable in frontmatter; slugified at display + URL time.

export function tagSlug(label: string): string {
  return label
    .trim()
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

export type TagCount = { label: string; slug: string; count: number };

export function tagCounts<T extends { data: { tags: string[]; draft: boolean } }>(
  posts: T[],
): TagCount[] {
  const map = new Map<string, { label: string; count: number }>();
  for (const p of posts) {
    if (p.data.draft) continue;
    for (const label of p.data.tags) {
      const slug = tagSlug(label);
      const existing = map.get(slug);
      if (existing) existing.count += 1;
      else map.set(slug, { label, count: 1 });
    }
  }
  return [...map.entries()]
    .map(([slug, { label, count }]) => ({ slug, label, count }))
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label));
}
