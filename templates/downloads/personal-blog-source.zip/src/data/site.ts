// Single source of truth for this blog's identity, navigation, and
// author profile. Cloning users edit this file (and src/content/blog/*.mdx
// for posts) to make the site theirs.

export const site = {
  // Site / publication identity
  name: 'Slow Dispatch',
  tagline: 'Long-form notes on building software, slowly and with care.',
  description:
    'A personal essay blog by Nadia Whitfield. Writing about systems, trade-offs, and the parts of engineering that don\'t fit on a slide.',
  language: 'en-us',
  // Year the site started — used in colophon + post-count line.
  foundedYear: 2024,

  // Navigation — keep flat and short; one row in the header.
  nav: [
    { label: 'Essays', href: '/' },
    { label: 'Tags', href: '/tags/' },
    { label: 'Now', href: '/now/' },
    { label: 'About', href: '/about/' },
  ],
};

export const author = {
  firstName: 'Allan',
  name: 'Slow Dispatch',
  jobTitle: 'Senior Software Engineer',
  shortBio: 'Senior engineer in Toronto. Writing about systems, trade-offs, and the craft of programming.',
  longBio:
    'I\'ve spent the last decade building infrastructure for distributed teams and high-throughput pipelines. These essays are the long-form version of arguments I keep having with myself — usually about whether the simple solution is actually simple, and whether it\'s worth the dependency.',
  location: 'Toronto, ON',
  email: 'hello@slowdispatch.com',
  // Avatar lives in src/assets/ and is referenced via the Astro Image pipeline.
  // For the demo, /og-default.png is committed in public/.
  avatarSrc: '',
  socials: {
    linkedin: '#',
    github:   '#',
    x:        '#',
    // Mastodon (rel=me verification) — leave blank if not used.
    mastodon: '',
  },
  // Comma-separated, lowercase keywords for SEO + Person.knowsAbout schema.
  knowsAbout: [
    'software engineering',
    'distributed systems',
    'developer experience',
    'build pipelines',
    'static site generators',
  ],
};

export type Site = typeof site;
export type Author = typeof author;
