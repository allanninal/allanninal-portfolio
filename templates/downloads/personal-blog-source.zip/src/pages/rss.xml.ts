import rss from '@astrojs/rss';
import { getCollection } from 'astro:content';
import sanitizeHtml from 'sanitize-html';
import type { APIContext } from 'astro';
import { site, author } from '~/data/site';
import { experimental_AstroContainer } from 'astro/container';
import { tagSlug } from '~/lib/tags';

// Render each post body to HTML at build time, sanitize, and emit
// <content:encoded> with the full content. Reader-first: subscribers in
// Reeder / NetNewsWire / Readwise Reader get the entire essay in their
// feed reader instead of being forced back to the site for excerpts.
//
// `sanitize-html` strips MDX/JSX nodes that don't survive serialization
// (e.g. <Component>) and any inline scripts that might survive a
// custom remark plugin.

const ALLOWED_TAGS = [
  'p', 'br', 'a', 'strong', 'em', 'b', 'i', 'u', 'code', 'pre', 'blockquote',
  'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'hr', 'img',
  'figure', 'figcaption', 'sup', 'sub', 'section', 'article',
  'table', 'thead', 'tbody', 'tr', 'th', 'td',
];
const ALLOWED_ATTR = {
  a: ['href', 'title', 'rel', 'target'],
  img: ['src', 'alt', 'title', 'width', 'height', 'loading'],
  '*': ['id', 'class'],
};

export async function GET(context: APIContext) {
  const posts = (await getCollection('blog', ({ data }) => !data.draft)).sort(
    (a, b) => b.data.pubDate.getTime() - a.data.pubDate.getTime(),
  );

  // Astro's experimental container API renders MDX/Markdown to HTML at
  // build time. Falls back to the raw body markup if rendering fails on
  // any single post — RSS shouldn't break the build.
  const container = await experimental_AstroContainer.create();

  const items = await Promise.all(
    posts.map(async (post) => {
      let contentHtml = '';
      try {
        const { Content } = await post.render();
        const rendered = await container.renderToString(Content);
        contentHtml = sanitizeHtml(rendered, {
          allowedTags: ALLOWED_TAGS,
          allowedAttributes: ALLOWED_ATTR,
        });
      } catch {
        contentHtml = '';
      }
      return {
        title: post.data.title,
        description: post.data.description,
        pubDate: post.data.pubDate,
        link: `/blog/${post.slug}/`,
        categories: post.data.tags.map((t) => tagSlug(t)),
        author: `${author.email} (${author.name})`,
        content: contentHtml || post.data.description,
      };
    }),
  );

  return rss({
    title: `${site.name} — Essays`,
    description: site.description,
    site: context.site!.toString(),
    items,
    customData: `<language>${site.language}</language>`,
    xmlns: { atom: 'http://www.w3.org/2005/Atom' },
    stylesheet: false,
  });
}
