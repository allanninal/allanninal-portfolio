import { defineCollection, z } from 'astro:content';

const blog = defineCollection({
  type: 'content',
  schema: z.object({
    title:       z.string(),
    description: z.string(),
    pubDate:     z.coerce.date(),
    updatedDate: z.coerce.date().optional(),
    tags:        z.array(z.string()).default([]),
    draft:       z.boolean().default(false),
    featured:    z.boolean().default(false),
    hero:        z.string().optional(),  // committed image path
    ogImage:     z.string().optional(),  // override the default OG image
    // readingTime is NOT a frontmatter field — auto-computed at build via
    // `reading-time` on post.body so it cannot drift from the prose.
  }),
});

export const collections = { blog };
