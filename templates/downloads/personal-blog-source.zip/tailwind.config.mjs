/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        // Inter — UI: nav, meta lines, tags, reading time, buttons
        sans: ['"Inter Variable"', 'Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        // Newsreader — body copy + post headings (long-form reading)
        serif: ['"Newsreader Variable"', 'Newsreader', 'Georgia', 'Cambria', 'serif'],
        display: ['"Newsreader Variable"', 'Newsreader', 'Georgia', 'serif'],
      },
      fontSize: {
        'xs':  ['0.8rem',   { lineHeight: '1.5' }],
        'sm':  ['0.875rem', { lineHeight: '1.55' }],
        'base':['1rem',     { lineHeight: '1.7' }],
        'prose':['1.125rem',{ lineHeight: '1.75' }], // body for post pages
        'lg':  ['1.25rem',  { lineHeight: '1.6' }],
        'xl':  ['1.5rem',   { lineHeight: '1.45' }],
        '2xl': ['1.875rem', { lineHeight: '1.3' }],
        '3xl': ['2.25rem',  { lineHeight: '1.2' }],
        '4xl': ['2.75rem',  { lineHeight: '1.15' }],
        '5xl': ['3.5rem',   { lineHeight: '1.05' }],
      },
      maxWidth: {
        prose: '68ch', // long-form measure
        bio: '36rem',
      },
      letterSpacing: {
        tightest: '-0.04em',
        tight2: '-0.02em',
      },
    },
  },
};
