# Martial Arts Dojo — Day 67 of 365

**Live demo**: https://templates.allanninal.dev/martial-arts-dojo/

A feature-rich Astro + Tailwind template for a multi-discipline martial arts dojo. Dark-default palette with Tournament Blue accent and Metallic Gold secondary — visually distinct from all 66 prior Sprint 3 siblings.

## Features

- **5 disciplines grid** — BJJ, Muay Thai, Judo, Karate, MMA with condensed description cards
- **Belt rank progression** — visual BJJ belt system (White → Blue → Purple → Brown → Black) with progression timelines, focus areas, and milestone markers
- **First Week Free intro offer** — prominent enrollment CTA section
- **JS-filterable class schedule** — 27 weekly classes filterable by discipline (BJJ / Muay Thai / Judo / Karate / MMA / Kids)
- **5 coached programs** — Intro to Martial Arts, BJJ, Muay Thai, Kids & Teens, Competition MMA Team
- **3 instructor profiles** — Marcus Chen (BJJ Black Belt), Yuki Tanaka (Muay Thai), Priya Kapoor (Judo/Kids)
- **3-tier pricing** — Drop-In $28 / Monthly Unlimited $149 / Family Plan $229
- **4 student testimonials** grid
- **8-item FAQ accordion** with martial-arts-specific questions
- **Formspree contact form** + hours panel
- **Final CTA band** with primary + phone ghost button
- **Sticky header** with mobile hamburger nav
- **Skip link**, semantic `main` landmark, logical heading hierarchy
- **4 JSON-LD blocks** — SportsActivityLocation + LocalBusiness + Person + Service + FAQPage

## Visual design

| Token | Value |
|-------|-------|
| Palette | Iron Temple (Dark default) |
| Background | Iron Night `#090A12` |
| Accent | Tournament Blue `#1C58E0` |
| Gold | Metallic Gold `#D4AF37` |
| Text | `#F2F0F8` (17.4:1 AAA) |
| Text muted | `#9898B0` (6.98:1 AA) |
| Display font | Oswald (700/600/500/400) |
| Body font | Inter (600/500/400/300) |

## Quick start

```bash
cd templates/martial-arts-dojo
npm install
npm run dev
```

## Build

```bash
npm run build
# Or with hub env:
PUBLIC_TEMPLATE_HUB_URL=https://templates.allanninal.dev npm run build
```

## Tests

```bash
npm run test:a11y       # axe WCAG AA audit
npm run test:links      # link integrity
npm run test:lighthouse # Perf/A11y/BP/SEO ≥ 95
```

## Customise

1. Edit `src/data/config.ts` — dojo name, address, phone, email, social URLs
2. Edit `src/pages/index.astro` — disciplines, programs, schedule, pricing, instructors, testimonials, FAQ
3. Edit `src/styles/global.css` — CSS custom properties for palette and typography
4. Replace `public/og-image.svg` + regenerate `og-image.png`
5. Update `TemplateInfo.astro` slug if you fork

## Environment variables

| Variable | Purpose |
|----------|---------|
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — shows the download bar when set |
| `PUBLIC_BASE_PATH` | Base path for hosting in a subdirectory |
| `PUBLIC_EDITION` | Set to `pro` for the Pro edition build |

## License

MIT — free to use for personal and commercial projects. See [LICENSE](./LICENSE).

---

Part of the [365 Templates](https://allanninal.dev) project by [Allan Ninal](https://linkedin.com/in/allanninal).
