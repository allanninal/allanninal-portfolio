/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,ts}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Oswald"', 'system-ui', 'sans-serif'],
        body:    ['"Inter"', 'system-ui', 'sans-serif'],
      },
      colors: {
        iron: {
          50:  '#F2F0F8',
          100: '#D8D6E8',
          200: '#A0A0B8',
          300: '#7474A0',
          400: '#4A4A70',
          500: '#2A2A50',
          600: '#1D1F32',
          700: '#17192A',
          800: '#10121C',
          900: '#090A12',
        },
        cobalt: {
          50:  '#EEF4FF',
          100: '#C5D9FF',
          200: '#70AAFF',
          300: '#4488FF',
          400: '#2262E8',
          500: '#1C58E0',
          600: '#1448C0',
          700: '#0C38A0',
          800: '#082880',
          900: '#041860',
        },
        gold: {
          50:  '#FEF9E7',
          100: '#FCF0B8',
          200: '#F8DC72',
          300: '#E8C03E',
          400: '#D4AF37',
          500: '#B8930A',
          600: '#927400',
          700: '#6C5600',
          800: '#463800',
          900: '#201A00',
        },
      },
    },
  },
  plugins: [],
};
