export const dojo = {
  name:        'Bushido Academy',
  tagline:     'Discipline. Respect. Power.',
  description: 'Portland\'s premier multi-discipline martial arts dojo — BJJ, Muay Thai, Judo, Karate, and MMA for all levels ages 5 and up. Traditional values, world-class instruction, and a community built on respect.',
  phone:       '(503) 555-0183',
  email:       'hello@bushidoacademy.com',
  address:     '1847 NW Davis St',
  city:        'Portland',
  state:       'OR',
  zip:         '97209',
  instagram:   'https://instagram.com/bushidoacademy',
  facebook:    'https://facebook.com/bushidoacademy',
  youtube:     'https://youtube.com/@bushidoacademy',
  bookUrl:     'https://app.bushidoacademy.com/book',
  membershipUrl: 'https://app.bushidoacademy.com/membership',
  headInstructor: {
    name:  'Marcus Chen',
    title: 'Head Instructor & BJJ Black Belt',
    certs: ['IBJJF Certified Black Belt', '3× IBJJF Gold Medalist', '15 Years Teaching'],
  },
  makerBio: {
    name:     'Bushido Academy',
    url:      'https://allanninal.dev',
    linkedin: 'https://www.linkedin.com/in/allanninal/',
    twitter:  'https://twitter.com/allanninal',
    github:   'https://github.com/allanninal',
  },
};

export const site = {
  title:         'Bushido Academy | Martial Arts Portland OR — BJJ, Muay Thai, Judo, Karate, MMA',
  description:   'Bushido Academy in Portland OR — Brazilian Jiu-Jitsu, Muay Thai, Judo, Karate, and MMA for all levels ages 5+. World-class certified instructors, intro week free for new students. Traditional discipline, modern training methods.',
  ogImage:       '/og-image.png',
  twitterHandle: '@allanninal',
  language:      'en',
};
