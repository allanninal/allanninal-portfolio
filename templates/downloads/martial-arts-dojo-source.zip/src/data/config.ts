export const dojo = {
  name:        'Bushido Academy',
  tagline:     'Discipline. Respect. Power.',
  description: 'Portland\'s premier multi-discipline martial arts dojo — BJJ, Muay Thai, Judo, Karate, and MMA for all levels ages 5 and up. Traditional values, world-class instruction, and a community built on respect.',
  phone:       '(503) 555-0183',
  email:       'hello@bushidoacademy.com',
  address:     '1847 NW Davis St',
  city:        'Portland',
  state:       'OR',
  zip:         '97209',
  instagram:   'https://instagram.com/bushidoacademy',
  facebook:    'https://facebook.com/bushidoacademy',
  youtube:     'https://youtube.com/@bushidoacademy',
  bookUrl:     'https://app.bushidoacademy.com/book',
  membershipUrl: 'https://app.bushidoacademy.com/membership',
  headInstructor: {
    name:  'Marcus Chen',
    title: 'Head Instructor & BJJ Black Belt',
    certs: ['IBJJF Certified Black Belt', '3× IBJJF Gold Medalist', '15 Years Teaching'],
  },
  makerBio: {
    name:     'Bushido Academy',
    url:      'https://example.com',
    linkedin: '#',
    twitter:  '#',
    github:   '#',
  },
};

export const site = {
  title:         'Bushido Academy — Martial Arts in Portland OR',
  description:   'Brazilian Jiu-Jitsu, Muay Thai, Judo, Karate and MMA in Portland OR, all levels ages 5 and up. Certified instructors, first week free.',
  ogImage:       '/og-image.png',
  twitterHandle: '@example',
  language:      'en',
};
