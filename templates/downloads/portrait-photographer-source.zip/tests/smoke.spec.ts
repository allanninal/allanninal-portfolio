import { test, expect } from '@playwright/test';

test.describe('Ferrier & Blunt — smoke tests', () => {
  test('homepage renders with the studio name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Ferrier & Blunt/);
    await expect(page.locator('h1')).toContainText('hate photographs of themselves');
  });

  // Same vocabulary gap as day 91, but this one keeps the address: a portrait
  // studio is a room people come to, where a wedding photographer travels.
  test('handles the schema.org gap, and does assert an address', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"LocalBusiness"');
    expect(json).toContain('Q622237');
    expect(json).toContain('PostalAddress');
    expect(json).toContain('417 Warren St');
  });

  // ── The wall ────────────────────────────────────────────────────────────
  // A photographer's page that opens on words rather than a photograph. If an
  // image creeps above it, the whole conceit is gone.
  test('the page opens on words, with no photograph above them', async ({ page }) => {
    await page.goto('/');
    const wallTop = await page.locator('#wall ul.wall').evaluate((e) => e.getBoundingClientRect().top + window.scrollY);
    const firstImg = await page.locator('#sittings img').first().evaluate((e) => e.getBoundingClientRect().top + window.scrollY);
    expect(wallTop).toBeLessThan(firstImg);
    expect(await page.locator('#wall li').count()).toBe(12);
  });

  test('the wall is real sentences, not single words', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#wall li').allTextContents()) {
      expect(t.trim().split(/\s+/).length).toBeGreaterThan(2);
    }
  });

  // ── The sittings ────────────────────────────────────────────────────────
  test('each sitting pairs a portrait with what the person said', async ({ page }) => {
    await page.goto('/');
    const figs = page.locator('#sittings figure.sitting');
    expect(await figs.count()).toBe(6);
    for (const f of await figs.all()) {
      await expect(f.locator('img')).toHaveCount(1);
      await expect(f.locator('blockquote.said')).toHaveCount(1);
      await expect(f.locator('blockquote.said cite')).toHaveCount(1);
      expect(((await f.locator('.did').textContent()) || '').length).toBeGreaterThan(60);
    }
  });

  test('every portrait has substantive alt text and fixed dimensions', async ({ page }) => {
    await page.goto('/');
    const imgs = await page.locator('#sittings img').evaluateAll((els) =>
      els.map((e) => ({
        alt: e.getAttribute('alt') || '',
        w: e.getAttribute('width'),
        h: e.getAttribute('height'),
        src: e.getAttribute('src') || '',
      })),
    );
    expect(imgs.length).toBe(6);
    for (const i of imgs) {
      expect(i.alt.length).toBeGreaterThan(30);
      expect(i.alt).not.toMatch(/^(portrait|photo|image|model)$/i);
      expect(i.w).toBeTruthy();
      expect(i.h).toBeTruthy();
      expect(i.src).toMatch(/images\/sittings\/s\d\d\.jpg$/);
    }
  });

  test('all six portraits load — no broken images', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForLoadState('networkidle');
    const broken = await page.locator('img').evaluateAll((imgs) =>
      imgs.filter((i) => !(i as HTMLImageElement).complete || (i as HTMLImageElement).naturalWidth === 0)
          .map((i) => i.getAttribute('src')),
    );
    expect(broken).toEqual([]);
  });

  test('sittings alternate sides', async ({ page }) => {
    await page.goto('/');
    const flipped = await page.locator('#sittings figure.sitting').evaluateAll((els) =>
      els.map((e) => e.classList.contains('sitting--flip')),
    );
    expect(flipped).toEqual([false, true, false, true, false, true]);
  });

  // ── The retouch line ────────────────────────────────────────────────────
  test('the retouch line publishes both halves, and refuses the usual request', async ({ page }) => {
    await page.goto('/');
    const r = page.locator('#retouch');
    await expect(r).toContainText('What comes out');
    await expect(r).toContainText('What stays');
    expect(await r.locator('.line ul li').count()).toBe(10);
    // Scars and body size staying is the substance of the claim.
    await expect(r).toContainText(/Scars, birthmarks/i);
    await expect(page.locator('#faq')).toContainText(/make me look thinner/i);
  });

  test('the sitting admits the first twenty minutes are unusable', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#hour h2')).toContainText(/first twenty minutes/i);
    expect(await page.locator('#hour tbody tr').count()).toBe(4);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 91.
  test('no trace of the day-91 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['halvard', 'wren', 'ithaca', 'contact sheet', 'grease', 'rebate']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  // The overlap is removed below 900px on purpose — a quote on a face needs room.
  test('the account does not overlap the portrait on a phone', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const fig = page.locator('#sittings figure.sitting').first();
    const img = await fig.locator('img').boundingBox();
    const acc = await fig.locator('.account').boundingBox();
    expect(acc!.y).toBeGreaterThanOrEqual(img!.y + img!.height - 2);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro session guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/session-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Before the day');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
