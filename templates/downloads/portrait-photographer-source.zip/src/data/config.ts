// Ferrier & Blunt — Hudson, NY.
//
// Day 91 opened on a contact sheet: cold, analytical, a page about process.
// This is the opposite register on purpose. A portrait studio's subject is not
// its process, it is the person in front of the camera — so the page opens on
// what people say walking through the door, and every photograph on it is
// evidence for something somebody said.

export const site = {
  name:        'Ferrier & Blunt',
  shortName:   'Ferrier & Blunt',
  title:       'Ferrier & Blunt — Portrait Studio in Hudson, NY',
  tagline:     'Nine in ten people tell us they hate photographs of themselves.',
  owner:       'Imogen Blunt',
  ownerRole:   'Portrait photographer',
  credential:  'Portrait studio · Warren Street, Hudson',
  license:     'Portrait studio, established 2014',
  city:        'Hudson',
  state:       'NY',
  language:    'en',
  phoneDisplay: '(518) 555-0164',
  phoneHref:   '+15185550164',
  email:       'studio@ferrierblunt.example',
  streetAddress: '417 Warren St',
  postalCode:  '12534',
  hours:       'Sittings Wed–Sat, one a day · daylight studio, no strobes',
  bookingWindow: 'One sitting a day. Booking about four weeks out.',
  description:
    'A daylight portrait studio in Hudson. Almost everyone who books tells us they ' +
    'photograph badly. This page is mostly what they said, and what we did about it.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'What people say', href: '#wall' },
  { label: 'Why',             href: '#why' },
  { label: 'Sittings',        href: '#sittings' },
  { label: 'Retouching',      href: '#retouch' },
  { label: 'The hour',        href: '#hour' },
  { label: 'Book',            href: '#book' },
];

// ── The wall ──────────────────────────────────────────────────────────────
// Verbatim-style openers. The page leads with these instead of a photograph.

export const wall = [
  'I photograph badly',
  'I hate my smile',
  'Can you do something about my nose',
  'I never know what to do with my hands',
  'I look angry when I am not',
  'Just make me look normal',
  'My good side is the left one',
  'I have not had a photo taken since school',
  'Everyone else is photogenic',
  'I always blink',
  'Do not make me smile',
  'Can you make me look thinner',
];

export const wallNote =
  'Every one of those was said to us in the studio, most of them more than once. ' +
  'Almost nobody arrives comfortable. That is the normal condition of being ' +
  'photographed, not a problem with your face.';

// ── Why you do not recognise yourself ─────────────────────────────────────

export const why = {
  headline: 'You have been looking at the wrong version of your face your whole life.',
  points: [
    {
      title: 'The mirror is reversed and you are used to it',
      body:
        'Every mirror you have ever used shows you a flipped face. Faces are not symmetrical, ' +
        'so the flipped one is genuinely a different arrangement — and it is the one you know. ' +
        'A photograph shows the version everyone else has always seen, and it looks subtly wrong ' +
        'to you and completely normal to them.',
    },
    {
      title: 'Familiarity is doing the liking, not beauty',
      body:
        'People reliably prefer the version of a face they have seen most often. Your friends ' +
        'prefer your photographs. You prefer your mirror. Neither of you is wrong, and only one ' +
        'of you is looking at something other people can see.',
    },
    {
      title: 'A face at rest is not a face being unfriendly',
      body:
        'A relaxed face has a downturned mouth and heavy lids, and reads as displeased in a still ' +
        'frame in a way it never does in motion. Most people who say they look angry in photographs ' +
        'are looking at their own face at rest for the first time.',
    },
    {
      title: 'Lenses change the geometry, and close ones are unkind',
      body:
        'A phone camera held at arm’s length enlarges whatever is nearest it, which is your nose. ' +
        'Stepping back and using a longer lens flattens that out. Most self-perception about noses ' +
        'is a lens problem, and it is ours to solve, not yours.',
    },
  ],
  closing:
    'None of this is reassurance. It is the reason a sitting takes an hour instead of ten minutes: ' +
    'we are waiting for the point where you stop watching yourself.',
};

// ── The sittings ──────────────────────────────────────────────────────────
// Every alt string was written from looking at the file. The Pixabay title for
// s03 says "musician / rockstar" and there is no instrument in the frame.

export const sittings = [
  {
    id: 's01', file: 's01.jpg', who: 'Dariusz, 26 · actor’s headshot',
    said: 'I never know what to do with my hands.',
    did: 'So we took them out of the picture. He is turned away and looking back, which gives the hands a job — holding the jacket — and gives the face something to do that is not posing.',
    alt: 'A young man in a black leather jacket, turned away and looking back over his shoulder against a grey studio backdrop',
  },
  {
    id: 's02', file: 's02.jpg', who: 'Mei-Lin, 31 · thirtieth-birthday sitting',
    said: 'I hate my smile.',
    did: 'She spent the first twenty minutes hiding behind things, so we let her. The daisy is hers; she picked it up off the table. The frame is about the eye she did not cover.',
    alt: 'A young woman reclining among dried flowers, holding a single white daisy over one eye',
  },
  {
    id: 's03', file: 's03.jpg', who: 'Rowan, 44 · booked by a friend as a gift',
    said: 'Just make me look normal.',
    did: 'We tried normal for half an hour and it was flat. Then we asked what they actually wanted to do, and this happened in about four frames. It is the only picture from that day anybody has printed.',
    alt: 'A person shouting with their long grey hair thrown outward, wearing slatted red and yellow novelty sunglasses',
  },
  {
    id: 's04', file: 's04.jpg', who: 'Priya, 38 · painter, for a gallery listing',
    said: 'Photograph me working, not posing.',
    did: 'The best portrait of someone who makes things is usually of them making the thing. We turned the lights off, kept the one over the easel, and stayed out of the way for forty minutes.',
    alt: 'A woman painting at an easel in a dim studio, seen from the side under a warm hanging lamp',
  },
  {
    id: 's05', file: 's05.jpg', who: 'Adaeze & Kwame, 29 and 33 · anniversary',
    said: 'Neither of us is photogenic.',
    did: 'Both of them were fine the moment they stopped looking at the camera. We asked them to talk to each other and ignore us, and then waited. This is frame sixty-one.',
    alt: 'A couple in white vests and jeans laughing together in black and white, the man crouching beside the standing woman',
  },
  {
    id: 's06', file: 's06.jpg', who: 'Beatrix, 22 · portfolio sitting',
    said: 'I want to look like someone else.',
    did: 'We said no to that, and yes to a different light. Nothing here is retouched beyond dust and one stray hair — the change is where the lamp is, not what was done afterwards.',
    alt: 'A woman with her hair up and strong eye make-up, lit against a background of gold glitter bokeh',
  },
];

// ── The retouch line ──────────────────────────────────────────────────────

export const retouch = {
  headline: 'We remove what is temporary. We keep what is you.',
  intro:
    'This is a line, not a slider, and it is the same line for everybody. If you want it moved ' +
    'we will move it and say so on the invoice, but we will tell you first what it costs the ' +
    'picture.',
  removed: [
    'A spot that will be gone in a fortnight',
    'A stray hair across the face',
    'Dust, sensor marks, a shine from the lamp',
    'A bra strap, a label, a crooked collar',
    'Something distracting in the background',
  ],
  kept: [
    'Lines, and where they came from',
    'Scars, birthmarks, freckles, moles',
    'The shape of your nose and jaw',
    'Your teeth, as they are',
    'Your body, at the size it is',
  ],
  closing:
    'The reason is practical rather than moral. A retouched face stops looking like the person, ' +
    'and the people who love you notice immediately even when they cannot say what changed.',
};

// ── The hour ──────────────────────────────────────────────────────────────

export const hour = {
  intro: 'One sitting a day, because the last twenty minutes are the ones worth having.',
  steps: [
    { at: '0–10 min',  what: 'Tea, and no camera in the room',       note: 'Nothing is being photographed. This is not a warm-up exercise, it is genuinely just talking.' },
    { at: '10–25 min', what: 'The camera comes out, on a tripod',    note: 'On a tripod so there is a face behind it rather than a lens. Most of these frames are of someone being photographed.' },
    { at: '25–40 min', what: 'You see the back of the camera',       note: 'Always. Seeing three good frames early is the single fastest way to stop bracing.' },
    { at: '40–60 min', what: 'The part we are here for',             note: 'Somewhere in here you forget. Every frame we have ever delivered comes from this stretch.' },
  ],
  after:
    'About thirty finished frames within ten days, and a call to go through them if you want one. ' +
    'You choose; we do not pick for you.',
};

export const pricing = {
  note: 'One rate. A headshot and a birthday sitting take the same hour and the same care.',
  price: '$420',
  includes: [
    'One hour, one person or one couple',
    'About 30 finished frames, full resolution, no watermark',
    'A gallery you can download from for five years',
    'Personal-use licence, perpetual',
  ],
  extras: [
    { what: 'A second person in the same hour', cost: '$90' },
    { what: 'On location within Columbia County', cost: '$140' },
    { what: 'Commercial licence, per image',     cost: 'From $200' },
    { what: 'Print, 8×10, hand-finished',        cost: '$65' },
  ],
};

export const faqs = [
  {
    q: 'What if I freeze up?',
    a: 'You will, for about the first half hour. Everyone does and the hour is built around it. The first frames are of someone being photographed; the ones we deliver come from after you stop noticing.',
  },
  {
    q: 'Can you make me look thinner?',
    a: 'No, and it is the one request we always decline. It never looks like the person afterwards, and the people who love you spot it instantly even when they cannot name what changed. We can light you well, which is a real answer to the same question.',
  },
  {
    q: 'Do I need professional hair and make-up?',
    a: 'No. Some people like it and it photographs fine, but a sitting where you do not recognise yourself in the mirror before we start is a harder sitting, not an easier one.',
  },
  {
    q: 'What should I wear?',
    a: 'Something you have worn before and were comfortable in. New clothes photograph as new clothes. Avoid a print so loud it becomes the subject, and bring a second option in case the first fights the light.',
  },
  {
    q: 'Do you use flash?',
    a: 'Almost never. The studio faces north and the window is the light. It means we shoot in daylight hours and it means the pictures look like the room you were actually sitting in.',
  },
  {
    q: 'Can I see everything you shot?',
    a: 'You can see the whole take if you ask, and about one person a year does. Mostly it is two hundred frames of you blinking, and looking at them makes people feel worse rather than better.',
  },
];
