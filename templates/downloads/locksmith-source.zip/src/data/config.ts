// Redoubt Lock & Key — Spokane, WA.
//
// The page is built on one claim that most locksmith sites avoid because it
// sells less hardware: on a hinged residential door, the frame fails before
// the cylinder does. Every number below is here to support or qualify that.

export const site = {
  name:        'Redoubt Lock & Key',
  shortName:   'Redoubt',
  title:       'Redoubt Lock & Key — Locksmith in Spokane, WA',
  tagline:     'The lock is rarely what failed.',
  owner:       'Marisol Okonjo',
  ownerRole:   'ALOA-certified locksmith',
  credential:  'ALOA-certified · WA endorsement LOC-4471',
  license:     'Washington locksmith endorsement LOC-4471',
  city:        'Spokane',
  state:       'WA',
  language:    'en',
  phoneDisplay: '(509) 555-0184',
  phoneHref:   '+15095550184',
  email:       'dispatch@redoubtlockandkey.example',
  streetAddress: '1120 N Monroe St',
  postalCode:  '99201',
  // Published because the trade's own scam runs on a hidden one. See `scam`.
  calloutFee:  '$45 flat, waived if we do the work',
  hours:       'Mon–Sat 7am–7pm · after-hours dispatch until 11pm',
  description:
    'An ALOA-certified locksmith in Spokane. This page grades your existing hardware ' +
    'against the five ways doors actually get opened — and is honest that on four ' +
    'out of five of them, the lock is not what failed.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The matrix', href: '#matrix' },
  { label: 'The frame',  href: '#frame' },
  { label: 'Rekey',      href: '#rekey' },
  { label: 'Services',   href: '#services' },
  { label: 'Areas',      href: '#areas' },
  { label: 'FAQ',        href: '#faq' },
];

// ── The matrix ────────────────────────────────────────────────────────────
// Rows are hardware, columns are attack methods. The cross-tab is the point:
// reading across a row grades one lock; reading down a column grades your whole
// house. The `kick` column is deliberately almost uniform.

export const attacks = [
  { id: 'pick',  name: 'Picking',      note: 'Slow, quiet, and rare. Television has this badly out of proportion.' },
  { id: 'bump',  name: 'Bumping',      note: 'A cut key struck to jump the pins. Seconds, if the cylinder allows it.' },
  { id: 'drill', name: 'Drilling',     note: 'Loud and fast. Beaten by hardened inserts, not by grade.' },
  { id: 'snap',  name: 'Snapping',     note: 'The euro-cylinder failure. Mostly a UK problem — named here because UK advice circulates widely.' },
  { id: 'kick',  name: 'Kick / spread', note: 'What actually happens. Read this column down before you read any row across.' },
] as const;

export type Resist = 'strong' | 'fair' | 'weak' | 'n/a';

export const hardware = [
  {
    id: 'g3',
    name: 'Grade 3 deadbolt',
    spec: 'ANSI/BHMA Grade 3 · 2 strikes · 100,000 cycles',
    blurb: 'Builder-grade. This is on most front doors in the United States.',
    cells: { pick: 'weak', bump: 'weak', drill: 'weak', snap: 'n/a', kick: 'weak' },
  },
  {
    id: 'g2',
    name: 'Grade 2 deadbolt',
    spec: 'ANSI/BHMA Grade 2 · 5 strikes · 150,000 cycles',
    blurb: 'The sensible residential upgrade. Roughly doubles the strike count.',
    cells: { pick: 'fair', bump: 'weak', drill: 'fair', snap: 'n/a', kick: 'weak' },
  },
  {
    id: 'g1',
    name: 'Grade 1 deadbolt',
    spec: 'ANSI/BHMA Grade 1 · 10 strikes · 250,000 cycles',
    blurb: 'Commercial spec. Excellent cylinder. Still bolted to your door frame.',
    cells: { pick: 'fair', bump: 'fair', drill: 'strong', snap: 'n/a', kick: 'weak' },
  },
  {
    id: 'highsec',
    name: 'High-security cylinder',
    spec: 'Restricted keyway · security pins · hardened inserts',
    blurb: 'Keys cannot be copied at a kiosk. This is what actually stops picking and bumping.',
    cells: { pick: 'strong', bump: 'strong', drill: 'strong', snap: 'n/a', kick: 'weak' },
  },
  {
    id: 'euro',
    name: 'Euro cylinder',
    spec: 'Common on patio and uPVC doors',
    blurb: 'The only row where snapping is a live column — and it is the row people ask about least.',
    cells: { pick: 'fair', bump: 'fair', drill: 'fair', snap: 'weak', kick: 'weak' },
  },
  {
    id: 'smart',
    name: 'Smart lock',
    spec: 'Motorised deadbolt · keypad or app',
    blurb: 'The physical bolt underneath is usually Grade 2 or 3. The app changes who can open it, not how hard it is to force.',
    cells: { pick: 'fair', bump: 'fair', drill: 'fair', snap: 'n/a', kick: 'weak' },
  },
  {
    id: 'frame',
    name: 'Reinforced strike + 3in screws',
    spec: 'Box strike anchored to the framing stud',
    blurb: 'Not a lock at all. It is the only row that changes the column everyone ignores.',
    cells: { pick: 'n/a', bump: 'n/a', drill: 'n/a', snap: 'n/a', kick: 'strong' },
  },
] as const;

export const matrixNote =
  'Six of the seven rows read “weak” under Kick / spread, and the row that does not ' +
  'is not a lock. That column is a frame problem, and no cylinder you buy will move it.';

// ── The frame ─────────────────────────────────────────────────────────────

export const frame = {
  headline: 'The eleven-dollar fix we would rather sell you than a cylinder.',
  body:
    'The strike plate that came with your door is fastened with three-quarter-inch ' +
    'screws. Those bite the door casing — a thin trim board — and nothing behind it. ' +
    'A box strike with three-inch screws reaches past the casing into the framing ' +
    'stud, which is the first structural member in the wall.',
  parts: [
    { part: 'Box strike plate',        cost: '$8–$14',   why: 'Wraps the bolt cavity instead of sitting flat on the jamb.' },
    { part: '3in wood screws, four',   cost: 'under $2', why: 'Long enough to reach the stud behind the casing.' },
    { part: 'Hinge screws, six',       cost: 'under $3', why: 'The hinge side fails second. Same screws, same reason.' },
  ],
  labour: 'We do it for $45 on a call we are already making. It takes about twenty minutes.',
  caveat:
    'This will not help a door with a rotted jamb, a glass sidelight within arm’s reach ' +
    'of the thumbturn, or an out-swinging door with exposed hinge pins. We will tell you ' +
    'if you have one of those instead of fitting a strike and taking the money.',
};

// ── Rekey vs replace ──────────────────────────────────────────────────────

export const rekey = {
  intro:
    'If the hardware is sound and you simply need the old keys to stop working, ' +
    'rekeying is the right answer and it is the cheaper one.',
  rows: [
    { situation: 'New tenant, hardware in good order',      answer: 'Rekey',   cost: '$22 per cylinder + call-out' },
    { situation: 'Lost one key, no idea where',             answer: 'Rekey',   cost: '$22 per cylinder + call-out' },
    { situation: 'Bolt is stiff or the cylinder is worn',   answer: 'Replace', cost: '$95–$180 fitted' },
    { situation: 'Grade 3 on an exterior door',             answer: 'Replace', cost: '$110–$210 fitted' },
    { situation: 'You want keys that cannot be copied',     answer: 'Replace', cost: '$180–$260 fitted' },
  ],
};

// ── The trade's own problem ───────────────────────────────────────────────

export const scam = {
  headline: 'Why the first quote you get is often not the price.',
  body:
    'Locksmith bait-and-switch is documented enough that the FTC has published ' +
    'consumer guidance on it: a search ad quotes nineteen dollars, an unlicensed ' +
    'subcontractor arrives in an unmarked car, and the invoice at the door is three ' +
    'hundred and fifty. It is common enough that we lose calls to it.',
  asks: [
    'Ask for the licence number before the van leaves. Ours is LOC-4471.',
    'Ask what the call-out fee is and whether it is waived. Ours is $45, waived if we do the work.',
    'Ask whether the person arriving is an employee. Ours are.',
    'If the answer is “the technician will price it on site”, that is the scam.',
  ],
};

export const services = [
  { name: 'Lockout, residential',  price: '$45 call-out + $40–$85', note: 'Most doors open non-destructively. We do not drill first.' },
  { name: 'Rekey',                 price: '$22 per cylinder',        note: 'Same key across the house if you want it.' },
  { name: 'Deadbolt supply + fit', price: '$95–$260',                note: 'Grade 2 minimum on exterior doors.' },
  { name: 'Frame reinforcement',   price: '$45',                     note: 'Box strike, 3in screws, hinge screws.' },
  { name: 'Safe opening',          price: 'Quoted on inspection',    note: 'We need the make and the model before we quote.' },
  { name: 'Commercial master key', price: 'Quoted per schedule',     note: 'Restricted keyway, documented key control.' },
];

export const areas = [
  { zone: 'Central',    towns: 'Downtown, Browne’s Addition, Riverside, Peaceful Valley' },
  { zone: 'North',      towns: 'Garland, Shadle, Five Mile Prairie, Hillyard' },
  { zone: 'South Hill', towns: 'Manito, Comstock, Rockwood, Lincoln Heights' },
  { zone: 'Valley',     towns: 'Spokane Valley, Millwood, Liberty Lake, Otis Orchards' },
];

export const reviews = [
  { name: 'Dana Whitcomb',  town: 'South Hill',      text: 'I called about upgrading three deadbolts. She fitted one and reinforced all three frames instead, and the bill was smaller than the quote I had in hand.' },
  { name: 'Petros Vasiliou', town: 'Spokane Valley', text: 'Locked out at nine at night. Open in under ten minutes with a pick, not a drill, and the lock still works.' },
  { name: 'Adaeze Nnamani', town: 'Garland',         text: 'Rekeyed six units between tenants. Priced per cylinder as quoted, no surprise at the end, invoice matched the phone call.' },
  { name: 'Hollis Barre',   town: 'Liberty Lake',    text: 'She talked me out of a smart lock. Told me the bolt underneath was the same Grade 3 I already had. That is the first honest thing anyone said to me about it.' },
];

export const faqs = [
  {
    q: 'Is a Grade 1 deadbolt worth the money?',
    a: 'For the cylinder, yes — it resists drilling and survives far more cycles. For forced entry through the frame, it changes nothing. Fit the strike first, then buy the grade.',
  },
  {
    q: 'Are smart locks less secure?',
    a: 'Not usually less, but rarely more. The motorised bolt underneath is typically Grade 2 or 3. A smart lock changes who can open your door and when — a useful thing — but it does not change how hard the door is to force.',
  },
  {
    q: 'Should I worry about lock bumping?',
    a: 'Less than the internet suggests. It is real and it is fast, but it needs the right key blank and it leaves the lock working, so it is under-reported rather than common. Security pins defeat it, and any high-security cylinder has them.',
  },
  {
    q: 'Can you open my door without drilling it?',
    a: 'Almost always. Non-destructive entry is the default and it is what the call-out fee covers. If a lock genuinely has to be drilled we tell you before we start and the replacement is quoted first.',
  },
  {
    q: 'Do you charge more at night?',
    a: 'After 7pm the call-out is $70 instead of $45. The labour rate does not change. That is the whole difference and it is on this page so you do not hear it at the door.',
  },
  {
    q: 'How do I check a locksmith is licensed in Washington?',
    a: 'Ask for the endorsement number and the business name, then check it against the Department of Licensing record. Ours is LOC-4471, Redoubt Lock & Key. A firm that will not give you a number over the phone is telling you something.',
  },
];
