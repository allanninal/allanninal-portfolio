import { test, expect } from '@playwright/test';

test.describe('Redoubt Lock & Key — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Redoubt Lock & Key/);
    await expect(page.locator('h1')).toContainText('frame');
  });

  // Locksmith is one of the eight real subtypes of HomeAndConstructionBusiness,
  // so like day 86 this template does not need a fallback type.
  test('uses the real Locksmith schema type, not a fallback', async ({ page }) => {
    await page.goto('/');
    const json = await page.$$eval('script[type="application/ld+json"]', (els) =>
      els.map((e) => e.textContent || '').join(''),
    );
    expect(json).toContain('"Locksmith"');
    expect(json).not.toContain('HomeAndConstructionBusiness');
    expect(json).not.toContain('GeneralContractor');
  });

  // ── The matrix ──────────────────────────────────────────────────────────
  // It is a cross-tab, so the test checks both header axes exist. A grid of
  // divs would pass a "renders 35 cells" test and fail a screen reader.
  test('the matrix is a real cross-tab with both header axes', async ({ page }) => {
    await page.goto('/');
    const t = page.locator('#matrix table.matrix');
    // Six column headers: the five attacks plus the corner cell, which heads
    // the column of row-headers and is labelled for screen readers only.
    const cols = await t.locator('thead th[scope="col"]').allTextContents();
    expect(cols.length).toBe(6);
    expect(cols[0].trim()).toBe('Hardware');
    expect(cols.slice(1).map((c) => c.trim())).toEqual([
      'Picking', 'Bumping', 'Drilling', 'Snapping', 'Kick / spread',
    ]);
    expect(await t.locator('tbody th[scope="row"]').count()).toBe(7);
    expect(await t.locator('tbody td.cell').count()).toBe(35);
  });

  test('every matrix cell states a word, not only a colour', async ({ page }) => {
    await page.goto('/');
    const words = await page.locator('#matrix td.cell').allTextContents();
    expect(words.length).toBe(35);
    for (const w of words) expect(['Strong', 'Fair', 'Weak', 'n/a']).toContain(w.trim());
  });

  // The argument of the whole page lives in this one column.
  test('the kick column is weak on every row except the strike plate', async ({ page }) => {
    await page.goto('/');
    const kick = await page.locator('#matrix tbody tr').evaluateAll((rows) =>
      rows.map((r) => ({
        name: r.querySelector('.hw-name')?.textContent?.trim(),
        kick: r.querySelectorAll('td.cell')[4]?.textContent?.trim(),
      })),
    );
    expect(kick.length).toBe(7);
    const strong = kick.filter((r) => r.kick === 'Strong');
    expect(strong.length).toBe(1);
    expect(strong[0].name).toContain('strike');
    expect(kick.filter((r) => r.kick === 'Weak').length).toBe(6);
  });

  test('the frame section leads with the cheap fix, above anything we sell', async ({ page }) => {
    await page.goto('/');
    const frame = page.locator('#frame');
    await expect(frame).toContainText('eleven-dollar');
    await expect(frame).toContainText('framing stud');
    // The caveat has to survive edits — it is the part that keeps the claim honest.
    await expect(frame).toContainText(/rotted jamb/i);
    const frameTop = await frame.evaluate((e) => e.getBoundingClientRect().top + window.scrollY);
    const svcTop = await page.locator('#services').evaluate((e) => e.getBoundingClientRect().top + window.scrollY);
    expect(frameTop).toBeLessThan(svcTop);
  });

  test('rekey/replace answers are words, and rekey is the cheaper column', async ({ page }) => {
    await page.goto('/');
    const answers = await page.locator('#rekey .answer').allTextContents();
    expect(answers.length).toBe(5);
    for (const a of answers) expect(['Rekey', 'Replace']).toContain(a.trim());
    expect(answers.filter((a) => a.trim() === 'Rekey').length).toBe(2);
  });

  test('the call-out fee is published as a number, not "call for pricing"', async ({ page }) => {
    await page.goto('/');
    const body = await page.locator('body').textContent();
    expect(body).toContain('$45');
    expect(body).not.toMatch(/call for pricing/i);
  });

  test('the licence number appears so a caller can check it', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#scam')).toContainText('LOC-4471');
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('the call-out form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 86.
  test('no trace of the day-86 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['cardinal', 'richmond', 'wendell', '60 cents', 'literata', 'valuation']) {
      expect(html).not.toContain(noun);
    }
  });

  // The matrix has a min-width and scrolls in its own box. The page must not.
  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('the matrix scrolls inside its own container on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const scrollable = await page.locator('#matrix .matrix-wrap').evaluate(
      (e) => e.scrollWidth > e.clientWidth,
    );
    expect(scrollable).toBe(true);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro door survey is absent from the free build', async ({ page }) => {
    const res = await page.goto('/door-survey/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Opening by opening');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
