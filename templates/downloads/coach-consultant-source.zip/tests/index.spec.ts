import { test, expect } from '@playwright/test';

test.describe('Coach / Consultant template — home page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  // Nav
  test('sticky nav renders with book button', async ({ page }) => {
    const nav = page.getByRole('navigation', { name: /Main navigation/i });
    await expect(nav).toBeVisible();
    const bookBtn = page.locator('#nav-book-btn');
    await expect(bookBtn).toBeVisible();
    await expect(bookBtn).toHaveAttribute('href', /cal\.com/);
  });

  // Hero
  test('hero section renders heading and booking CTAs', async ({ page }) => {
    const hero = page.locator('#hero');
    await expect(hero).toBeVisible();
    // h1 scoped to hero to avoid strict-mode collision
    const heading = hero.getByRole('heading', { level: 1 });
    await expect(heading).toBeVisible();
    await expect(heading).toContainText('engineering leaders');
    // Primary booking CTA
    const heroBook = page.locator('#hero-book-btn');
    await expect(heroBook).toBeVisible();
    await expect(heroBook).toHaveAttribute('href', /cal\.com/);
    // Secondary CTA
    const secondaryCta = hero.getByRole('link', { name: /See how I work/i });
    await expect(secondaryCta).toBeVisible();
  });

  // Audiences
  test('audiences section renders 3 audience cards', async ({ page }) => {
    const section = page.locator('#audiences');
    await expect(section).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(3);
  });

  // Services
  test('services section renders 4 service cards', async ({ page }) => {
    const section = page.locator('#services');
    await expect(section).toBeVisible();
    const h2 = section.getByRole('heading', { level: 2 });
    await expect(h2).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(4);
  });

  // Featured service has "Most popular" badge
  test('featured service (1:1 Coaching) shows most-popular badge', async ({ page }) => {
    const section = page.locator('#services');
    await expect(section.getByText('Most popular')).toBeVisible();
  });

  // Testimonials
  test('testimonials section renders 4 cards', async ({ page }) => {
    const section = page.locator('#testimonials');
    await expect(section).toBeVisible();
    const cards = section.locator('article');
    await expect(cards).toHaveCount(4);
  });

  // Outcomes
  test('outcomes section renders 4 stat counters', async ({ page }) => {
    const section = page.locator('#outcomes');
    await expect(section).toBeVisible();
    // Each stat counter is inside the grid — use the grid's direct children
    const grid = section.locator('.grid');
    const stats = grid.locator('> div');
    await expect(stats).toHaveCount(4);
  });

  // About
  test('about section renders credentials list', async ({ page }) => {
    const section = page.locator('#about');
    await expect(section).toBeVisible();
    const h2 = section.getByRole('heading', { level: 2 });
    await expect(h2).toBeVisible();
    // Credentials card is present
    const credCard = section.locator('.bg-white').first();
    await expect(credCard).toBeVisible();
  });

  // Booking
  test('booking section renders with booking CTA', async ({ page }) => {
    const section = page.locator('#booking');
    await expect(section).toBeVisible();
    const h2 = section.getByRole('heading', { level: 2 });
    await expect(h2).toBeVisible();
    const bookBtn = page.locator('#booking-cta-btn');
    await expect(bookBtn).toBeVisible();
    await expect(bookBtn).toHaveAttribute('href', /cal\.com/);
  });

  // Newsletter
  test('newsletter section renders signup form', async ({ page }) => {
    const section = page.locator('#newsletter');
    await expect(section).toBeVisible();
    const form = page.locator('#newsletter-form');
    await expect(form).toBeVisible();
    const emailInput = page.locator('#newsletter-email');
    await expect(emailInput).toBeVisible();
    const submitBtn = form.getByRole('button');
    await expect(submitBtn).toBeVisible();
  });

  // FAQ accordion
  test('FAQ section renders and accordion opens on click', async ({ page }) => {
    const section = page.locator('#faq');
    await expect(section).toBeVisible();
    // First item
    const firstBtn = page.locator('#faq-btn-0');
    await expect(firstBtn).toBeVisible();
    // Answer hidden initially
    const firstAnswer = page.locator('#faq-answer-0');
    await expect(firstAnswer).toBeHidden();
    // Click to open
    await firstBtn.click();
    await expect(firstAnswer).toBeVisible();
    // aria-expanded updated
    await expect(firstBtn).toHaveAttribute('aria-expanded', 'true');
  });

  // FAQ has 6 items
  test('FAQ renders 6 question items', async ({ page }) => {
    const section = page.locator('#faq');
    const items = section.locator('[id^="faq-btn-"]');
    await expect(items).toHaveCount(6);
  });

  // Footer
  test('footer renders with coach name and contact link', async ({ page }) => {
    const footer = page.getByRole('contentinfo');
    await expect(footer).toBeVisible();
    await expect(footer).toContainText('Jordan Steele');
    const emailLink = footer.getByRole('link', { name: /hello@jordansteele\.coach/i });
    await expect(emailLink).toBeVisible();
  });

  // No github.com/allanninal/templates deep-links on page
  test('no github.com/allanninal/templates links anywhere on page', async ({ page }) => {
    const allLinks = await page.locator('a').evaluateAll(
      (els) => els.map((e) => e.getAttribute('href') || '')
    );
    const deepLinks = allLinks.filter((h) =>
      h.includes('github.com/allanninal/templates')
    );
    expect(deepLinks).toEqual([]);
  });

  // Responsive — no horizontal overflow
  test('no horizontal overflow on mobile viewport', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const docWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const vp = await page.evaluate(() => window.innerWidth);
    expect(docWidth).toBeLessThanOrEqual(vp + 1); // 1px tolerance
  });
});
