/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,svelte,vue,mdx}'],
  theme: {
    extend: {
      colors: {
        // Warm near-white — primary background
        linen: {
          50:  '#FAFAF7',
          100: '#F2F0EB',
          200: '#E8E5DE',
          300: '#D4D1CA',
          400: '#B8B5AE',
        },
        // Sage-forest green — primary accent
        sage: {
          900: '#1E2D1A',
          800: '#2A3E25',
          700: '#3A5333',
          600: '#4A6741',
          500: '#5D7D54',
          400: '#7A9873',
          300: '#D3DDD1',
          200: '#E9F0E8',
          100: '#E1EAE0',
          50:  '#F0F5EF',
        },
        // Honey highlight — pull quotes only
        honey: {
          100: '#FDF4E0',
          200: '#F5E6C8',
          300: '#EDCF8A',
          400: '#D4A840',
        },
        // Ink — text
        ink: {
          900: '#1C1F1A',
          800: '#2A2E27',
          700: '#3A3F37',
          600: '#4A5047',
          500: '#5C6359',
          400: '#70756D',
          300: '#9BA29A',
          200: '#C5CBC3',
          100: '#E0E4DF',
          50:  '#F2F0EB',
        },
      },
      fontFamily: {
        display: ['Raleway', 'system-ui', 'sans-serif'],
        sans: ['Nunito', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
