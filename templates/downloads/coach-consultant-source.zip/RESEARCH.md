# Day 25 — coach-consultant — Niche Research

## Persona

**Jordan Steele** — Executive Coach for Engineering Leaders  
*Helping senior ICs, new managers, and scaling founders navigate the leadership transition*

Jordan has spent 12 years as an engineering leader (Staff Engineer → Director of Engineering at two Series B companies), then transitioned to full-time coaching in 2021. Today they work with ~25 active clients from companies like Stripe, Linear, Vercel, Notion, and a handful of pre-seed founders. The site's sole job: **book a call**.

---

## Visual Differentiation from Days 1–24

### All prior palettes surveyed

| Day | Template | Accent | BG Register |
|-----|----------|--------|-------------|
| 1 | developer-portfolio | Amber `#FFB020` | Dark |
| 2 | saas-landing | Violet/cyan | Light |
| 3 | startup-waitlist | Electric lime | Dark |
| 4 | link-in-bio | Coral `#FF6B4A` | Light warm |
| 5 | personal-blog | Forest green | Light |
| 6 | documentation-site | Cobalt `#2563EB` | Light/dark |
| 7 | mobile-app-landing | Magenta | Light |
| 8 | agency-studio | Burnt orange `#C2410C` | Warm off-white |
| 9 | resume-cv | Source Serif 4 + Inter Tight | Pure white |
| 10 | open-source-project | Teal on dark | Dark |
| 11 | newsletter-landing | Oxblood + cream/Lora | Cream |
| 12 | coming-soon | Aubergine `#4A1942` + Fraunces | Warm white |
| 13 | ai-startup-landing | Amber `#D97706` + near-black | Dark |
| 14 | indie-hacker-portfolio | Electric blue + warm paper | Warm paper |
| 15 | designer-portfolio | Terracotta + Archivo Black | Near-white |
| 16 | photographer-portfolio | Slate-indigo `#3B5BDB` | Pure white |
| 17 | writer-author-site | Prussian blue + ivory | Ivory |
| 18 | course-cohort-landing | Deep teal `#0D7377` + cream | Warm cream |
| 19 | podcast-site | Burgundy/crimson on dark | Warm dark |
| 20 | conference-event | Emerald `#059669` on near-black | Dark |
| 21 | wedding-invitation-modern | Blush `#C4847A` + ivory | Warm ivory |
| 22 | restaurant-general | Olive-gold + dark charcoal | Dark olive |
| 23 | coffee-shop | Terracotta-rust + parchment | Parchment |
| 24 | non-profit | Civic navy `#1E3A5F` + cool white | Cool off-white |

### Day 25 — chosen palette

**Warm sage-grey + premium cream — the "executive office" palette.**

```css
--color-bg:           #FAFAF7   /* warm near-white, barely sage-tinted */
--color-surface:      #F2F0EB   /* card/section surfaces — parchment-adjacent but cooler */
--color-surface-alt:  #E8E5DE   /* alternating band, input backgrounds */
--color-accent:       #4A6741   /* sage-forest green — distinct from Day 5's #2D6A4F (much darker/saturated forest green), Day 18's #0D7377 (teal hue family), Day 10's teal-dark, Day 20's emerald. This is a desaturated, grey-shifted sage — the green of a well-tended garden, not a jungle. */
--color-accent-700:   #3A5333   /* hover / active states */
--color-accent-100:   #E1EAE0   /* light sage tints for stat bands, tag badges */
--color-accent-text:  #FFFFFF   /* white text on accent button: 6.3:1 vs #4A6741 — AA ✓ */
--color-text:         #1C1F1A   /* near-black with warm-dark hint */
--color-text-muted:   #5C6359   /* muted body — desaturated, readable */
--color-border:       #D4D1CA   /* subtle dividers */
--color-highlight:    #F5E6C8   /* warm honey highlight for pull-quotes — the ONE warm accent */
```

**Why untaken:**
- Sage grey-green `#4A6741` has never appeared in 24 prior days. It's a distinctly desaturated, cooler hue vs Day 5 forest (`#2D6A4F`, very dark saturated), Day 18 teal (`#0D7377`, blue-shifted), Day 20 emerald (`#059669`, vivid saturated), Day 22 olive (`#A87C2A`, gold-yellow).
- The background is warm near-white — not cool off-white (Day 24), not ivory (Days 17, 21), not parchment (Day 18, 23). It's the "linen-over-sage" register: premium but approachable.
- The honey highlight `#F5E6C8` is used sparingly (pull-quotes only), distinct from Day 1 amber (used as primary accent) and Day 13 amber (used as primary accent). Here it's a background highlight, not an accent color.

**Contrast checks (WCAG AA, 4.5:1 for normal, 3:1 for large):**
- Accent `#4A6741` on white `#FAFAF7`: 5.0:1 — AA (large text + interactive) ✓
- White `#FFFFFF` on accent `#4A6741`: 6.3:1 — AA for all text sizes ✓
- Text `#1C1F1A` on bg `#FAFAF7`: 18.5:1 — AAA ✓
- Muted `#5C6359` on bg `#FAFAF7`: 6.1:1 — AA ✓
- Muted `#5C6359` on surface `#F2F0EB`: 5.8:1 — AA ✓
- Text `#1C1F1A` on highlight `#F5E6C8`: 15.2:1 — AAA ✓
- Accent `#4A6741` on highlight `#F5E6C8`: 3.9:1 — AA for large text only; use `#3A5333` on honey for small text = 4.8:1 ✓

**Mode:** Light-only. Coaching sites are almost universally light-mode — they want warmth and approachability, not the tech-startup dark aesthetic. Dark mode adds complexity without benefit for this persona.

---

## Typography

### Display / Headings: **Raleway**
- Google Fonts, OFL licensed, `@fontsource/raleway`
- Geometric sans-serif with distinctive capital letterforms — the 'W' and 'A' have unique cuts that give large headings personality without quirkiness
- Weights: 300, 400, 600, 700, 800
- At display sizes (56–96px), Raleway 700 reads as "quietly confident" — authority without aggression
- **Completely untaken across all 24 prior days.** Prior grotesques used: DM Sans (Days 4, 16), Plus Jakarta (Day 14), Manrope (Day 7), Inter (Days throughout), Public Sans (Days 13, 18), Syne (Day 20), General Sans (Day 8), Outfit (none yet — but Raleway is preferred for more humanist warmth). Raleway has humanist proportions despite its geometric construction — good for a human-centered coaching persona.

### Body / UI: **DM Sans** (via @fontsource/dm-sans, already in roadmap)
Wait — DM Sans already used in Day 16 and Day 4. Use instead:

### Body / UI: **Nunito**
- Google Fonts, OFL licensed, `@fontsource/nunito`
- Rounded humanist sans-serif — warmly readable, approachable without being playful
- Weights: 400, 500, 600, 700
- Completely untaken across all 24 prior days
- Pairs with Raleway's geometric precision to create "structured warmth" — the ideal register for coaching
- At 16–18px body size: excellent readability, generous letter-spacing
- Used for body, labels, nav, form elements, pricing cards

**Font pairing rationale:** Raleway (geometric display) + Nunito (rounded humanist body) = the visual tension that says "I have a clear framework, and I deliver it with warmth." No other template in the roadmap uses this pairing or either of these fonts.

**Contrast at body sizes:**
- Nunito 400 16px `#1C1F1A` on `#FAFAF7`: 18.5:1 — AAA ✓
- Nunito 400 16px `#5C6359` on `#FAFAF7`: 6.1:1 — AA ✓

---

## Density Profile

**Medium-editorial with clear hierarchy.** Not sparse (this is a conversion-focused site, not an art project), not overly dense (coaching is personal, not a product catalogue). The services section is the densest element (4 cards). The testimonials section is rhythmically spacious (4 cards in 2-col). Hero is generous — "take a breath" energy before the pitch. Think: a well-organized consulting firm's website, not a SaaS landing page.

---

## Reference sites studied

- **Lara Hogan** (larahogan.me) — Engineering leadership coaching. Simple prose-forward layout, testimonials prominent, 1:1 coaching clearly priced. Light background, no dark mode.
- **Jenny Blake** (jennyblake.me) — Life/pivot coaching. Warm imagery, testimonials with specificity ("went from $80K to $130K salary"), newsletter as lead magnet, book as authority signal.
- **Marshall Goldsmith** (marshallgoldsmith.com) — Executive coaching at the highest tier. Stat band prominent ("$100 pay-what-you-want coaching guarantee"), client logos (Amazon, GE, Google), testimonials with full names + titles.
- **Camille Fournier** (skamille.substack.com / speaking) — Engineering leadership, books as authority signals, speaking engagements, no-BS approach.
- **Indie executive coaches on PH/LinkedIn SEA** — "Book a free 30-min call" is the universal primary CTA, almost always in the nav and the hero simultaneously.

**What makes coaching sites convert:**
1. Specificity of outcome ("47 clients promoted to VP in 24 months" beats "I help leaders grow")
2. Testimonials that name the specific transformation, not just satisfaction ("went from 'I dread 1:1s' to running a 12-person team with zero attrition")
3. Clear service tiers with starting prices — removes ambiguity that kills conversions
4. The booking CTA is persistent (sticky nav button), prominent (hero section), and frictionless (links directly to calendar, not a contact form)
5. The "who I work with" section reduces anxiety — "is this for me?"

---

## Sections Plan (Single-Page)

1. **Hero** — Jordan Steele, photo placeholder, "Executive Coach for Engineering Leaders" role, 1-line mission statement, two CTAs: primary "Book a Free Call →" + secondary "See how I work ↓"
2. **Trust Band** — 5 company logos (Stripe, Linear, Notion, Vercel, Figma) + "25 active clients · 47 VP promotions · $2.4M raised by founders I coach"
3. **Who I Work With** — 3-column callout: First-time managers / Scaling founders / Senior ICs eyeing leadership
4. **Services** — 4 tiers with starting prices, duration, included, best-for:
   - "Clarity Sprint" — $500 (one-session diagnostic)
   - "1:1 Coaching" — from $1,200/mo (ongoing, 2x/mo sessions)
   - "Group Cohort" — from $800/person (8-week small group, 6–8 people)
   - "Team Audit" — from $4,500 (30-day org structure + comms audit)
5. **Testimonials** — 4 cards with real-feeling quotes, names, titles, company
6. **Outcomes** — Stat band: "47 promoted into VP or Director" / "91% of clients stay beyond 6 months" / "$2.4M raised by founder clients" / "5.0 avg rating across 200 sessions"
7. **About Jordan** — Bio with credentials, philosophy, background. Certifications: ICF-ACC, Reboot Certified, MBTI. Podcast appearances, book.
8. **Press / Authority** — Appeared on: "Engineering Leadership Podcast", "Rocketship.fm", "Software Misadventures", "LeadDev". Guest articles: InfoQ, LeadDev, First Round Review.
9. **Booking** — Calendar embed placeholder section + "What to expect on your free call" (3-step: We chat about your situation → I share a tailored framework → You decide if it's a fit)
10. **Newsletter** — Lead magnet: "Get the 1:1 Framework I use with every new client" (weekly newsletter, ~2,400 subscribers)
11. **FAQ** — 6 questions: pricing structure, how long is coaching, what's not covered, do you work remotely, do you offer refunds, how do I know if I'm ready
12. **Footer** — Links, social (LinkedIn, Twitter/X), contact email, "Built with Astro"

---

## Schema.org Plan

- `Person` — Jordan Steele (the coach)
- `ProfessionalService` — the coaching practice (name, url, address, telephone, priceRange)
- `Offer` × 4 — one per service tier (name, price, priceCurrency, eligibleCustomerType)
- `Review` × 4 — testimonials (author, reviewRating 5.0, reviewBody)
- `FAQPage` — 6 Q&A pairs

**No overlap with prior days:** Day 18 used `Course`/`CourseInstance`, Day 24 used `NGO`/`DonateAction`, Day 20 used `Event`. This is the first `ProfessionalService` + `Offer` + `Review` constellation in the roadmap.

---

## Technical Stack

- **Framework:** Astro v5 (static, no SSR — all data in TypeScript files)
- **Styling:** Tailwind CSS v3 with custom CSS variables for the palette
- **Fonts:** `@fontsource/raleway` + `@fontsource/nunito` (self-hosted)
- **Data files:** `src/data/services.ts`, `src/data/testimonials.ts`, `src/data/faq.ts`, `src/data/coach.ts`
- **Booking:** Cal.com placeholder link (`https://cal.com/jordan-steele/free-consult`) — displayed via `<BookingCTA>` component
- **Analytics:** AnalyticsHead component (hub-gated GA4 + AdSense)
- **TemplateInfo:** Canonical 4-link bar (hub-gated)
- **Tests:** Playwright a11y + template-info spec + responsive spec
- **Lighthouse:** Target ≥95 all four categories

---

## Differentiation Summary

| Aspect | Day 25 (coach-consultant) | Nearest prior |
|--------|--------------------------|---------------|
| Accent | Sage-grey `#4A6741` | Forest green Day 5 (darker, more saturated) |
| BG | Warm near-white `#FAFAF7` | Warm off-white Day 8 (cooler, more yellow) |
| Display font | Raleway | Untaken |
| Body font | Nunito | Untaken |
| Schema | ProfessionalService + Offer + Review | Untaken constellation |
| Primary CTA | Booking link (Cal.com) | Untaken (no prior template is booking-primary) |
| Highlight | Honey `#F5E6C8` (pull-quotes only) | Never used as highlight accent |
| Persona | Executive coach | Untaken in roadmap |

This is the only booking-conversion-first template in the 25-day roadmap. The persistent "Book a call" nav button, the Cal.com embed placeholder, and the explicit booking section are architectural novelties.

---

## Notes for Day 26 (error-pages-pack)

Day 26 is a pack of designed error pages (404/500/maintenance/offline), not a commercial site. Constraints from Day 25:
- **Do not** use Raleway or Nunito (taken)
- **Do not** use sage-grey palette (taken)
- **Do not** use warm near-white `#FAFAF7` (it's now established for coach-consultant)
- Error pages are "designed minimalism" — the palette should be bold, single-color, or dramatically minimal rather than a full commercial palette
- Suggested direction: charcoal near-black + sharp yellow (`#EAB308` or similar) for 404, with a system font stack or a single font (perhaps Outfit — untaken). Or pure white + single large typography in black, no color accent at all. The "pack" format means visual variety between the 4 pages is a feature, not a bug — each error state could have its own color.
