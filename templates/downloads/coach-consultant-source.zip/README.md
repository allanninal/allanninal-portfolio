# Day 25 — Coach / Consultant Template

**Live demo:** https://example.com/

Part of the [365 Templates](https://example.com/templates) project — one free Astro template shipped every day.

---

## What's in the box

Sage-green on warm linen. Raleway + Nunito. Booking-conversion-first: persistent Book a Call nav CTA, 4-tier services with pricing, 4 outcome-specific testimonials, stat band, about+credentials, Cal.com booking placeholder, newsletter, FAQ. ProfessionalService + Offer + Review JSON-LD.

**Persona:** Jordan Steele. All business data is fictional — replace it in `src/data/coach.ts` before you ship.

**Page sections** (the `<h2>`s on the homepage, in order):

- Are you in the right season for coaching?
- Choose the right entry point
- Real outcomes, not vague praise
- Outcomes that speak for themselves
- I've been where you are. Twice.
- What to expect on your free 30-min call
- Get the 1:1 Framework I use with every new client
- Common questions

**Additional pages:** `/work-with-me/`

---

## Stack

- [Astro](https://astro.build) 4.x (static output)
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [Nunito](https://fonts.google.com/specimen/Nunito) + [Raleway](https://fonts.google.com/specimen/Raleway) via `@fontsource`
- Playwright + axe-core for accessibility testing
- Lighthouse CI (≥ 95 all categories)

---

## Getting started

```bash
git clone https://github.com/<you>/<your-fork>.git
cd templates/coach-consultant
npm install

npm run dev      # dev server
npm run build    # production build
```

### Environment variables

| Variable | Purpose | Required |
|----------|---------|----------|
| `PUBLIC_SITE_URL` | Canonical site URL | No (defaults to `https://example.com`) |
| `PUBLIC_BASE_PATH` | Base path for asset URLs (e.g. `/coach-consultant/`) | No |
| `PUBLIC_TEMPLATE_HUB_URL` | Enables the download bar + analytics (author's deploy only) | No |
| `PUBLIC_EDITION` | Set to `pro` to activate the Pro edition UI | No |

### Customization

1. Edit `src/data/coach.ts` (and `src/data/faq.ts`, `src/data/services.ts`, `src/data/testimonials.ts`) — every string shown on the page lives there.
2. Replace `public/og-image.svg` and `public/favicon.svg` with your own brand marks.
3. Adjust the palette via the CSS custom properties in `src/styles/`.
4. Point any form `action` at your own endpoint (Formspree, Basin, your backend).

---

## Running tests

```bash
npm run test            # Playwright suite
npm run test:a11y       # axe WCAG 2.1 AA
npm run test:links      # link integrity
npm run test:lighthouse # Lighthouse ≥ 95 all categories
```

Tests run against system Google Chrome — no `playwright install` needed.

---

## License

MIT — free for personal and commercial use, under the repository’s root [LICENSE](../../LICENSE).

Made by [Allan Niñal](https://example.com) · [LinkedIn](#) · Day 25 of 365
