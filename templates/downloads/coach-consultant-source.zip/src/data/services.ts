export interface Service {
  id: string;
  name: string;
  tagline: string;
  price: string;
  priceDetail: string;
  duration: string;
  includes: string[];
  bestFor: string;
  featured?: boolean;
}

export const SERVICES: Service[] = [
  {
    id: 'clarity-sprint',
    name: 'Clarity Sprint',
    tagline: 'One focused session to diagnose what\'s actually holding you back.',
    price: '$500',
    priceDetail: 'one-time',
    duration: '90-minute session + written summary',
    includes: [
      'Pre-session intake questionnaire',
      '90-minute deep-dive video call',
      'Written summary with 3 concrete next actions',
      'One follow-up email within 2 weeks',
    ],
    bestFor: 'Leaders at a crossroads who need clarity before committing to longer coaching.',
  },
  {
    id: 'one-on-one',
    name: '1:1 Coaching',
    tagline: 'Ongoing support as you grow into the leader your team needs.',
    price: 'From $1,200',
    priceDetail: 'per month',
    duration: '2 sessions/month, 60 min each',
    includes: [
      '2 × 60-minute video sessions per month',
      'Unlimited async Q&A via Signal/email',
      'Session recordings + action summaries',
      'Access to the private resource library',
      'Introductions to relevant practitioners',
    ],
    bestFor: 'New managers or principals ready for sustained, high-accountability growth.',
    featured: true,
  },
  {
    id: 'group-cohort',
    name: 'Group Cohort',
    tagline: 'Learn alongside 6–8 peers navigating the same transition.',
    price: 'From $800',
    priceDetail: 'per person',
    duration: '8 weeks, weekly 90-min sessions',
    includes: [
      '8 × 90-minute live group sessions',
      'Private cohort Slack channel',
      'Weekly frameworks + reading',
      'Two 1:1 office-hour slots per person',
      'Lifetime access to cohort recordings',
    ],
    bestFor: 'Engineering managers who want peer accountability alongside expert facilitation.',
  },
  {
    id: 'team-audit',
    name: 'Team Audit',
    tagline: 'A 30-day diagnostic of your org structure, comms, and engineering culture.',
    price: 'From $4,500',
    priceDetail: 'flat fee',
    duration: '30-day engagement',
    includes: [
      'Structured interviews with 6–10 team members',
      'Review of your team processes & rituals',
      'Comprehensive findings report (20–30 pages)',
      'Executive read-out presentation',
      '60-day follow-up check-in',
    ],
    bestFor: 'CTOs and EMs who suspect something is off but can\'t name it precisely.',
  },
];
