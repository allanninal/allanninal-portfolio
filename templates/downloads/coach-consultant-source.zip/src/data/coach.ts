export const COACH = {
  name: 'Jordan Steele',
  role: 'Executive Coach for Engineering Leaders',
  tagline: 'I help senior ICs, new managers, and scaling founders navigate the leadership transition — with clarity, not chaos.',
  email: 'hello@jordansteele.coach',
  website: 'https://jordansteele.coach',
  bookingUrl: 'https://cal.com/jordan-steele/free-consult',
  bookingLabel: 'Book a Free Call',
  linkedin: 'https://linkedin.com/in/jordan-steele-coach',
  twitter: 'https://twitter.com/jordansteeleHQ',
  newsletter: {
    headline: 'Get the 1:1 Framework I use with every new client',
    subhead: 'A weekly letter on engineering leadership, team dynamics, and the art of the difficult conversation. Read by 2,400+ leaders.',
    cta: 'Get the Framework',
    platform: 'Buttondown', // swap to ConvertKit / Substack / MailerLite
    actionUrl: 'https://buttondown.email/jordan-steele',
  },
  stats: [
    { value: '47', label: 'Promoted to VP or Director' },
    { value: '91%', label: 'Clients renew beyond 6 months' },
    { value: '$2.4M', label: 'Raised by founder clients' },
    { value: '5.0', label: 'Avg rating across 200+ sessions' },
  ],
  credentials: [
    'ICF Associate Certified Coach (ACC)',
    'Reboot.io Certified Coach',
    'MBTI Certified Practitioner',
    'Former Director of Engineering, Luma Labs (Series B)',
    'Former Staff Engineer, Fieldwork Systems (acq. 2019)',
    'Author: "The Reluctant Leader" (2023)',
  ],
  authority: {
    podcasts: [
      { name: 'Engineering Leadership Podcast', episode: 'Ep. 214 — Making the IC-to-Manager Jump', url: '#' },
      { name: 'Rocketship.fm', episode: 'Ep. 389 — Coaching Your Way to Scale', url: '#' },
      { name: 'Software Misadventures', episode: 'Ep. 88 — The Framework Problem', url: '#' },
      { name: 'LeadDev Podcast', episode: 'Ep. 57 — Psychological Safety in Practice', url: '#' },
    ],
    publications: [
      { name: 'LeadDev', title: 'How to run a first 1:1 that actually matters', url: '#' },
      { name: 'InfoQ', title: 'Scaling teams without scaling chaos', url: '#' },
      { name: 'First Round Review', title: 'The uncomfortable truth about engineering management', url: '#' },
    ],
  },
};

export const CLIENT_LOGOS = [
  { name: 'Stripe', abbr: 'Str' },
  { name: 'Linear', abbr: 'Lin' },
  { name: 'Notion', abbr: 'Not' },
  { name: 'Vercel', abbr: 'Vrc' },
  { name: 'Figma', abbr: 'Fig' },
];

export const AUDIENCES = [
  {
    icon: '🚀',
    title: 'First-time managers',
    description: 'You just got the promotion. Now you\'re responsible for the people who used to be your peers. The technical skills that got you here won\'t be enough. Let\'s build the leadership muscle.',
  },
  {
    icon: '📈',
    title: 'Scaling founders',
    description: 'You\'re past product-market fit and growing fast. The engineering team that worked at 10 people is breaking at 40. You need a different kind of leadership — and a different kind of you.',
  },
  {
    icon: '🎯',
    title: 'Senior ICs eyeing leadership',
    description: 'You\'re a Staff or Principal engineer wondering if the manager track is right for you. Let\'s explore it honestly — not everyone should, and that\'s a perfectly valid outcome.',
  },
];

export const BOOKING_STEPS = [
  {
    step: '1',
    title: 'We talk about your situation',
    description: 'A free 30-minute call with no sales pressure. You tell me what\'s not working and what you\'re hoping to change.',
  },
  {
    step: '2',
    title: 'I share a tailored framework',
    description: 'Based on what I hear, I\'ll suggest a specific approach — not a generic package, but a path that fits your actual context.',
  },
  {
    step: '3',
    title: 'You decide if it\'s a fit',
    description: 'No pitch, no deadline, no pressure. If the work makes sense, we set up a pilot session and go from there.',
  },
];
