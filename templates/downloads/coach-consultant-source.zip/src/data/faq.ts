export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-0',
    question: 'What does coaching actually cost, all in?',
    answer: 'The Clarity Sprint is a flat $500 one-time session. Monthly 1:1 coaching starts at $1,200/month (billed monthly, no contract — cancel anytime with 30 days notice). Group Cohort seats start at $800/person for the full 8-week program. Team Audits are priced at $4,500 flat for up to 10 interviews + the report. No hidden fees, no upsell at the end of every call.',
  },
  {
    id: 'faq-1',
    question: 'How long does coaching typically last?',
    answer: 'Most 1:1 clients work with me for 6–12 months. The first 90 days are the hardest and most intensive — we\'re building new habits and rewiring how you show up. After that, many clients drop to a lighter maintenance cadence (1 session/month) or graduate. I don\'t have a minimum commitment, but I\'ll tell you honestly if I think 3 months won\'t be enough for what you\'re working on.',
  },
  {
    id: 'faq-2',
    question: 'Do you only work with engineering leaders?',
    answer: 'Primarily, yes. My background is engineering leadership — Staff, Principal, Director, VP levels, and technical co-founders. That specificity is the value. I\'m not a generalist executive coach trying to work with everyone; I\'m a specialist who has lived the exact transitions you\'re navigating. That said, I occasionally work with product leaders whose work is deeply intertwined with engineering culture.',
  },
  {
    id: 'faq-3',
    question: 'Do you work with people outside the US?',
    answer: 'Yes — all sessions are remote via Zoom or Google Meet. I have clients in the UK, the EU, Singapore, and Canada. I schedule to accommodate a range of time zones, with most sessions available between 7am–7pm PT. If you\'re in APAC, we\'ll find a window that works.',
  },
  {
    id: 'faq-4',
    question: 'What if I realize coaching isn\'t for me after a few sessions?',
    answer: 'Monthly 1:1 coaching is cancel-anytime with 30 days notice — no penalty, no pressure. The Clarity Sprint and Group Cohort are non-refundable once completed, but if you feel the session didn\'t deliver value, send me an email and we\'ll work it out. I\'ve never left a client feeling like they paid for nothing.',
  },
  {
    id: 'faq-5',
    question: 'How do I know if I\'m ready for coaching?',
    answer: 'You\'re ready if you\'re willing to be honest about what\'s not working, open to feedback that might be uncomfortable, and prepared to take action between sessions. You\'re probably not ready if you\'re looking for someone to validate decisions you\'ve already made, or if you expect coaching to fix your team\'s problems without you changing anything. The free 30-minute call is a no-pressure way to find out.',
  },
];
