export interface Testimonial {
  id: string;
  name: string;
  title: string;
  company: string;
  avatarInitials: string;
  avatarColor: string;
  // Pro edition only — real client headshot under public/images/pro/.
  photo?: string;
  quote: string;
  outcome: string;
  rating: number;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Priya Menon',
    title: 'Engineering Manager',
    company: 'Linear',
    avatarInitials: 'PM',
    avatarColor: '#4A6741',
    photo: 'images/pro/client-priya.jpg',
    quote: 'I went from dreading my weekly 1:1s to genuinely looking forward to them. Jordan gave me a framework for hard conversations that I now use every single week. Six months in, I have zero attrition on a team that was losing someone every quarter.',
    outcome: 'Zero attrition after 6 months; two direct reports promoted.',
    rating: 5,
  },
  {
    id: 't2',
    name: 'Marcus Webb',
    title: 'Co-founder & CTO',
    company: 'Fieldwork (acq.)',
    avatarInitials: 'MW',
    avatarColor: '#2A3E25',
    photo: 'images/pro/client-marcus.jpg',
    quote: 'We were 28 people and I still had five directs. Jordan helped me see the org structure problem before it became a people problem. We restructured in a month, hired two EMs, and I got my calendar back. The $1.2M we raised the following quarter was partly because investors finally saw a scalable org.',
    outcome: 'Raised $1.2M; hired 2 EMs; CEO confidence rating up 40pts on next board survey.',
    rating: 5,
  },
  {
    id: 't3',
    name: 'Aisha Okonkwo',
    title: 'Staff Engineer → VP of Engineering',
    company: 'Notion',
    avatarInitials: 'AO',
    avatarColor: '#3A5333',
    photo: 'images/pro/client-aisha.jpg',
    quote: 'I spent two years debating whether I wanted to go into management. One 90-minute Clarity Sprint with Jordan gave me more clarity than those two years combined. The answer was yes — but with specific conditions I had never articulated. Three months after that call I accepted the VP role.',
    outcome: 'Promoted to VP of Engineering within 3 months of the Clarity Sprint.',
    rating: 5,
  },
  {
    id: 't4',
    name: 'Daniel Cho',
    title: 'Engineering Director',
    company: 'Vercel',
    avatarInitials: 'DC',
    avatarColor: '#5D7D54',
    photo: 'images/pro/client-daniel.jpg',
    quote: 'Jordan does not tell you what you want to hear. They ask the exact question that makes you realize what you already know but have been avoiding. After 8 months I\'m a significantly better listener, my team trust scores are up 28 points, and I finally enjoy the parts of the job that used to exhaust me.',
    outcome: 'Team trust score +28 points; reduced meeting load by 40%.',
    rating: 5,
  },
];
