import { test, expect } from '@playwright/test';

test('no broken internal links on home page', async ({ page }) => {
  const errors: string[] = [];
  await page.goto('/');

  const links = await page.locator('a[href]').all();
  const internalHrefs = (
    await Promise.all(
      links.map(async (link) => {
        const href = await link.getAttribute('href');
        return href;
      })
    )
  ).filter(
    (href): href is string =>
      !!href &&
      !href.startsWith('http') &&
      !href.startsWith('mailto:') &&
      !href.startsWith('tel:') &&
      !href.startsWith('#') &&
      !href.startsWith('javascript:')
  );

  for (const href of internalHrefs) {
    const res = await page.request.get(href).catch(() => null);
    if (!res || res.status() >= 400) {
      errors.push(`${href} → ${res?.status() ?? 'network error'}`);
    }
  }

  expect(errors, `Broken internal links:\n${errors.join('\n')}`).toEqual([]);
});
