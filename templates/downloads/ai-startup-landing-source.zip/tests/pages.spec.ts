import { test, expect, type ConsoleMessage } from '@playwright/test';
import { ROUTES } from './helpers';

for (const route of ROUTES) {
  test(`${route} renders, has h1, no console errors`, async ({ page }) => {
    // Ignore third-party console noise (AnalyticsHead's hub-gated GA/AdSense
    // scripts can 403 under real Chrome) — only template errors should fail.
    const THIRD_PARTY = /googlesyndication|google-analytics|googletagmanager|doubleclick|adsbygoogle|gtag|pagead/i;
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
    page.on('console', (m: ConsoleMessage) => {
      if (m.type() !== 'error') return;
      const text = m.text();
      const u = m.location()?.url || '';
      if (THIRD_PARTY.test(text) || THIRD_PARTY.test(u)) return;
      if (/failed to load resource/i.test(text)) return;
      errors.push(`console.error: ${text}`);
    });

    const res = await page.goto(route);
    expect(res, `no response for ${route}`).not.toBeNull();
    expect(res!.status(), `status for ${route}`).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
    await expect(page.locator('footer').first()).toBeVisible();
    expect(errors, `console errors on ${route}:\n${errors.join('\n')}`).toEqual([]);
  });
}

test('home meta description is set', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="description"]').getAttribute('content');
  expect(meta).toBeTruthy();
  expect(meta!.length).toBeGreaterThan(20);
});

test('home emits SoftwareApplication JSON-LD with required fields', async ({ page }) => {
  await page.goto('/');
  const scripts = await page.locator('script[type="application/ld+json"]').all();
  const docs = await Promise.all(
    scripts.map(async (s) => {
      try { return JSON.parse((await s.textContent()) || ''); } catch { return null; }
    })
  );
  const app = docs.find((d) => d && d['@type'] === 'SoftwareApplication');
  expect(app, 'SoftwareApplication JSON-LD missing').toBeTruthy();
  expect(app.name).toBe('ContextIQ');
  expect(app.applicationCategory).toBeTruthy();
  expect(app.operatingSystem).toBeTruthy();
  expect(Array.isArray(app.offers)).toBe(true);
  expect(app.offers.length).toBeGreaterThanOrEqual(1);
});

test('OG image absolute and 1200x630', async ({ page }) => {
  await page.goto('/');
  const og = await page.locator('meta[property="og:image"]').getAttribute('content');
  expect(og).toMatch(/^https?:\/\//);
  expect(og).toContain('og-image.png');
  expect(await page.locator('meta[property="og:image:width"]').getAttribute('content')).toBe('1200');
  expect(await page.locator('meta[property="og:image:height"]').getAttribute('content')).toBe('630');
});

test('Twitter card is summary_large_image', async ({ page }) => {
  await page.goto('/');
  expect(await page.locator('meta[name="twitter:card"]').getAttribute('content')).toBe('summary_large_image');
});

test('canonical link is absolute', async ({ page }) => {
  await page.goto('/');
  const canonical = await page.locator('link[rel="canonical"]').getAttribute('href');
  expect(canonical).toMatch(/^https?:\/\//);
});

test('sitemap.xml is reachable', async ({ page }) => {
  const res = await page.goto('/sitemap-index.xml');
  expect(res?.status()).toBe(200);
});

test('robots.txt is reachable', async ({ page }) => {
  const res = await page.goto('/robots.txt');
  expect(res?.status()).toBe(200);
});

test('color-scheme meta declares dark', async ({ page }) => {
  await page.goto('/');
  const meta = await page.locator('meta[name="color-scheme"]').getAttribute('content');
  expect(meta).toBe('dark');
});

test('hero contains playground card', async ({ page }) => {
  await page.goto('/');
  const playground = page.locator('[aria-label="ContextIQ API playground demo"]');
  await expect(playground).toBeVisible();
});

test('pricing section has 3 tiers', async ({ page }) => {
  await page.goto('/');
  const tiers = page.locator('#pricing article');
  await expect(tiers).toHaveCount(3);
});

test('FAQ section has 6 items', async ({ page }) => {
  await page.goto('/');
  const faqs = page.locator('#faq details.faq-item');
  await expect(faqs).toHaveCount(6);
});

test('FAQ accordion opens on click', async ({ page }) => {
  await page.goto('/');
  const first = page.locator('#faq details.faq-item').first();
  await expect(first).not.toHaveAttribute('open');
  await first.locator('summary').click();
  await expect(first).toHaveAttribute('open', '');
});

test('features section has 6 cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#features .feature-card');
  await expect(cards).toHaveCount(6);
});

test('how-it-works section has 3 steps', async ({ page }) => {
  await page.goto('/');
  const steps = page.locator('#how-it-works ol > li');
  await expect(steps).toHaveCount(3);
});
