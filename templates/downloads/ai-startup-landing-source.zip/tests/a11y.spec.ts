import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const isPro = process.env.PUBLIC_EDITION === 'pro';

async function auditFor(page, route) {
  await page.goto(route);
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  return results.violations.map((v) => ({
    id: v.id,
    impact: v.impact,
    description: v.description,
    nodes: v.nodes.length,
    help: v.helpUrl,
  }));
}

test('a11y: / — zero violations', async ({ page }) => {
  const violations = await auditFor(page, '/');
  expect(
    violations,
    `Axe violations on /:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});

test('a11y: Pro /compare/ — zero violations', async ({ page }) => {
  test.skip(!isPro, 'The /compare/ page only exists in the Pro edition');
  const violations = await auditFor(page, '/compare/');
  expect(
    violations,
    `Axe violations on /compare/:\n${JSON.stringify(violations, null, 2)}`,
  ).toEqual([]);
});
