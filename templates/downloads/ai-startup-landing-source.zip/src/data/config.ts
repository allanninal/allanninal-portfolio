// ContextIQ — AI Document Intelligence API
// Single source of truth. Clone and edit this file to customize for your product.

export const brand = {
  name: 'ContextIQ',
  tagline: 'Your documents, answered in milliseconds.',
  description:
    'ContextIQ is an AI-powered document summarization and Q&A API. Feed it any PDF, Markdown, or URL — get back structured summaries, semantic answers, and citation-aware responses in under 200ms.',
  version: '2.1.0',
  category: 'Document Intelligence API',
  language: 'en',
  // Canonical URLs
  docsUrl: 'https://docs.contextiq.dev',
  signupUrl: 'https://app.contextiq.dev/signup',
  demoUrl: 'https://app.contextiq.dev/playground',
  // Social / contact — LinkedIn primary, email secondary per project convention
  socials: {
    linkedin: '#',
    twitter: '#',
    github: '#',
    email: 'hello@contextiq.com',
  },
};

// Stats shown in the benchmark band
export const stats = [
  { value: '< 200ms', label: 'p99 response time', mono: true },
  { value: '99.97%', label: 'uptime (12-mo avg)', mono: true },
  { value: '4', label: 'model backends', mono: false },
];

// Companies using ContextIQ — fictional but plausible names
export const logos = [
  'Arcadia Health',
  'Stormfront Analytics',
  'Brio Legal',
  'Novela Publishing',
  'Tangram AI',
  'Cascade Finance',
];

// Feature grid
export const features = [
  {
    icon: 'switch',
    title: 'Multi-model switching',
    body: 'Choose GPT-4o, Claude Sonnet, Gemini Pro, or Mistral Large per request. No lock-in, no extra config.',
  },
  {
    icon: 'citation',
    title: 'Citation-aware answers',
    body: 'Every response traces to its source — page, paragraph, exact passage. Not hallucinated references.',
  },
  {
    icon: 'speed',
    title: 'Sub-200ms p99',
    body: 'Streaming plus caching mean your users never wait. Benchmark table available in the docs.',
  },
  {
    icon: 'eval',
    title: 'Eval suite built in',
    body: 'Score every response with faithfulness, relevance, and groundedness metrics. Catch regressions before prod.',
  },
  {
    icon: 'json',
    title: 'Structured output',
    body: 'Get JSON, Markdown, or plain text. Schema-validated responses. Works with any downstream pipeline.',
  },
  {
    icon: 'sdk',
    title: 'Webhooks + SDK',
    body: 'Node.js, Python, Go SDKs. Webhook on async jobs. OpenAPI spec for self-generated clients.',
  },
];

// How it works steps
export const steps = [
  {
    num: '01',
    title: 'Upload or link your document',
    body: 'PDF, URL, Markdown, or plain text. Up to 500 pages per request. We handle parsing, chunking, and embedding.',
    code: `curl -X POST https://api.contextiq.dev/v1/ingest \\
  -H "Authorization: Bearer $CIQ_KEY" \\
  -F "file=@q4-roadmap.pdf"
# → { "doc_id": "doc_9f3k2", "pages": 24 }`,
  },
  {
    num: '02',
    title: 'Choose your model and output format',
    body: 'Switch models per request. Specify a JSON schema or get Markdown by default. Every call is stateless.',
    code: `curl -X POST https://api.contextiq.dev/v1/query \\
  -H "Authorization: Bearer $CIQ_KEY" \\
  -d '{
    "doc_id": "doc_9f3k2",
    "question": "What are the top 3 priorities in Q4?",
    "model": "claude-sonnet-4",
    "format": "json"
  }'`,
  },
  {
    num: '03',
    title: 'Receive answers with citations',
    body: 'The endpoint returns a structured object: summary, Q&A pairs, citations array, latency stats. Ready to pipe into your product.',
    code: `{
  "answer": "The top 3 priorities are: ...",
  "citations": [
    { "page": 4,  "text": "Priority 1: Ship eval pipeline..." },
    { "page": 11, "text": "Priority 2: Enterprise SSO launch..." },
    { "page": 17, "text": "Priority 3: Latency SLA reduction..." }
  ],
  "model": "claude-sonnet-4",
  "latency_ms": 187
}`,
  },
];

// Pricing tiers
export const pricingTiers = [
  {
    name: 'Free',
    price: '$0',
    period: '/month',
    description: 'For personal projects and experimentation.',
    featured: false,
    badge: null,
    cta: 'Get started free',
    ctaUrl: 'https://app.contextiq.dev/signup',
    features: [
      '1,000 pages / month',
      '3 model backends (GPT-4o, Gemini Pro, Mistral)',
      'JSON + Markdown output',
      '10 req/min rate limit',
      '99.9% SLA',
      'Community support',
    ],
  },
  {
    name: 'Pro',
    price: '$49',
    period: '/month',
    description: 'For production apps and growing teams.',
    featured: true,
    badge: 'Most popular',
    cta: 'Start Pro trial',
    ctaUrl: 'https://app.contextiq.dev/signup?plan=pro',
    features: [
      '50,000 pages / month',
      'All 4 model backends',
      'Citation API included',
      'Eval suite access',
      '200 req/min rate limit',
      '99.95% SLA',
      'Email support',
    ],
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For regulated industries and large-scale deployments.',
    featured: false,
    badge: null,
    cta: 'Talk to us',
    ctaUrl: 'https://app.contextiq.dev/enterprise',
    features: [
      'Unlimited pages',
      'Private deployment option',
      'SSO + RBAC',
      'Dedicated SLA + SLO',
      'SOC 2 Type II audit reports',
      'Custom rate limits',
      'Slack + dedicated support',
    ],
  },
];

// FAQ items
export const faqs = [
  {
    question: 'Is my data used to train your models?',
    answer: 'No. ContextIQ processes documents ephemerally. We do not store your content beyond your retention setting (default: 24 hours) and we never use it to train or fine-tune any model. This is covered in our Data Processing Agreement (DPA), available on request.',
  },
  {
    question: 'Which AI models are available?',
    answer: 'GPT-4o, Claude Sonnet 4, Gemini Pro 1.5, and Mistral Large 2. The Free plan includes GPT-4o, Gemini Pro, and Mistral Large. The Pro and Enterprise plans include all four plus priority access to new models as they launch.',
  },
  {
    question: 'Which cloud providers do you support?',
    answer: 'Documents can be fetched from Amazon S3, Google Cloud Storage, Azure Blob Storage, or any public HTTPS URL. No vendor lock-in — we speak standard S3-compatible APIs including Cloudflare R2 and Backblaze B2.',
  },
  {
    question: 'What document formats are supported?',
    answer: 'PDF, Markdown, plain text (.txt), HTML, DOCX (via our conversion pipeline), and raw URL crawl (we fetch and parse the page). Support for XLSX and PPTX is on the roadmap for Q3 2026.',
  },
  {
    question: 'What are the rate limits?',
    answer: 'Free: 10 requests/min, 1,000 pages/month. Pro: 200 requests/min, 50,000 pages/month. Enterprise: custom — contact us for bespoke limits. Burst capacity is available on Pro and Enterprise.',
  },
  {
    question: 'Do you offer a self-hosted version?',
    answer: 'The Enterprise plan includes a containerized private-deployment option that runs in your own VPC. You retain full data sovereignty. Contact us for architecture details and pricing.',
  },
];
