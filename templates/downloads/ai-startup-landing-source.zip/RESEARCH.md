# AI Startup Landing — Research Brief

> **Assumption:** A landing page for a focused AI SaaS product aimed at developer-adjacent buyers — engineering leads, product managers, growth teams. The product is **ContextIQ** — an AI-powered document summarization and Q&A API. Developers feed it PDFs, Notion exports, or raw text; ContextIQ returns structured summaries, answer chains, and citation links in <200ms. Not a generic "AI platform" — a specific tool with specific latency numbers, model options, and a free tier. The hero anchor is an **interactive playground mockup** — a prompt-in/output-out chat card that shows ContextIQ in action, statically rendered with realistic placeholder content.

---

## Audience & primary CTA

- **Who visits:** Backend developers and technical product managers evaluating AI summarization APIs. They arrive from a Hacker News post, a Twitter/X thread, or a product hunt listing. Dwell time is 60-120 seconds.
- **Primary CTA:** *Start free — 1,000 pages/month included.* External link to sign-up.
- **Secondary CTAs:** *View API docs*, *Book a demo* (for enterprise), copy-to-clipboard API snippet in the playground.

---

## Fictional product: ContextIQ

**Tagline:** "Your documents, answered in milliseconds."

**What it does:** Accepts a document (PDF, Markdown, plain text, URL) and returns:
1. A structured summary (key points, entities, action items)
2. A semantic Q&A interface — ask any question, get an answer with source citations
3. A JSON endpoint developers can pipe into their own products

**Key differentiators (used throughout copy):**
- **< 200ms** p99 response time (benchmark, not marketing fluff)
- **4 model backends** — GPT-4o, Claude Sonnet, Gemini Pro, Mistral Large — switchable per request
- **Citation-aware** — every answer points to the source passage, line, and page
- **GDPR + SOC 2 Type II** — no training on customer data, ever
- **Free tier:** 1,000 pages/month, 3 model backends, 99.9% SLA

**Believable mock document for the playground:** A fictional "Q4 Product Roadmap (PDF, 24 pages)." The playground shows:
- *Input:* "What are the top 3 priorities in Q4?"
- *Output:* A formatted answer with 3 bullet points + citation indicators [p.4], [p.11], [p.17]

---

## Reference sites (real companies — the visual register)

- https://www.anthropic.com — Near-black surfaces, cream/white text, single electric-red accent. Austere, confident, serious. Not playful.
- https://cursor.com — Dark, gradient hero with mesh effect, mono numerics, electric blue accent. Playground-forward.
- https://platform.openai.com — Clean dark UI, tabbed code snippets, "Try it" playground panel inline in the page. Model picker as a select component.
- https://www.cohere.com — Coral/warm accent on dark, card-based feature grid, model benchmark table. Dense but structured.
- https://mistral.ai — Near-black, saffron/amber accent, minimal copy, technical credibility via model names and benchmarks.

---

## Visual register — differentiation from Days 1–12

All 12 prior palettes to avoid:
- Day 1: indigo on dark
- Day 2: violet/cyan on light — **closest adjacent; avoid violet entirely**
- Day 3: lime on dark
- Day 4: coral on light
- Day 5: forest green on light, serif
- Day 6: cobalt on light, IBM Plex
- Day 7: magenta on light, Manrope
- Day 8: premium minimal (near-white + charcoal)
- Day 9: editorial serif, warm neutrals
- Day 10: teal on near-black (#0D1117), Outfit
- Day 11: oxblood on cream, Lora
- Day 12: aubergine on warm-white, Fraunces + Space Grotesk

**Day 13 chosen register: futurist dark — electric amber/saffron on near-black with subtle radial mesh gradient.**

- **Background:** `#09090C` (warmer than GitHub's `#0D1117`, cooler than pure black — reads "AI infrastructure")
- **Primary accent:** `#F59E0B` (Tailwind amber-500 / saffron) — untaken across all 12 days; reads as "precision, speed, intelligence" without the startup-green or startup-violet clichés
- **Accent hover:** `#D97706` (amber-600)
- **Surface cards:** `#111118` with `#1E1E28` borders — slightly cool dark with warm amber contrast
- **Text:** `#F8FAFC` (near-white body), `#94A3B8` (slate-400 muted), `#F59E0B` (amber accent labels)
- **Gradient hero:** subtle `radial-gradient` mesh centered on top of hero — amber glow at 5% opacity bleeds from center, fading to flat dark. Not a neon splash — restrained and technical.

**Typography:**
- **Display/headings:** **Bricolage Grotesque** (Google Fonts, variable, optical size — geometric with expressive quirks at large sizes. Used by Vercel in some marketing contexts; untaken in any Day 1–12 template.) Weights: 300, 400, 600, 800.
- **Body/UI:** **Inter** (already a stack dependency for some prior templates, but as the *body* font here, not display — it pairs cleanly with Bricolage Grotesque's expressiveness). Or swap to **Public Sans** to avoid any repetition. Decision: **Public Sans** (US Web Design System's typeface, clean, slightly condensed, government-serious but readable — fully untaken in Days 1–12).
- **Mono (playground, code snippets, latency numbers, benchmark stats):** **JetBrains Mono** — distinct from Geist Mono (Day 1), IBM Plex Mono (Day 6), Geist Mono (Day 10). JetBrains Mono's ligatures add technical credibility.

**Density:** High. This is a technical product for technical buyers. Dense information architecture but clear visual hierarchy. Comparable to Cursor.com or Cohere.

---

## Required sections (in order)

### 1. Hero — with playground embed slot
**Layout:** Left column (copy + CTAs) | Right column (playground card) — 50/50 on desktop, stacked mobile.

**Copy:**
- Eyebrow tag: `API · Document Intelligence`
- Headline: "Your documents, answered in milliseconds."
- Subhead: "ContextIQ extracts answers, summaries, and citations from any document — PDF, Markdown, URL — with model-switching and < 200ms p99 latency."
- CTA primary: `Start free — 1,000 pages/month →`
- CTA secondary: `View API docs ↗`
- Trust line below CTAs: `SOC 2 Type II · GDPR · No training on your data`

**Playground card (right side — the demo embed slot):**
- Header: `Try ContextIQ` | document picker showing "Q4 Roadmap.pdf (24 pages)" | model selector showing "Claude Sonnet ▾"
- Input area: A pre-filled question: "What are the top 3 priorities in Q4?"
- Output area: 3-bullet formatted answer with amber citation badges `[p.4]` `[p.11]` `[p.17]`
- Footer of card: `< 187ms` latency badge | `Copy as JSON` button
- Visual treatment: dark card `#1A1A24` with amber top border accent, JetBrains Mono for the output text, amber citation pills

### 2. Logo strip — "Teams using ContextIQ"
5–6 grayscale fictional-but-plausible company wordmarks or name pills:
- "Arcadia Health" · "Stormfront Analytics" · "Brio Legal" · "Novela Publishing" · "Tangram AI" · "Cascade Finance"
Displayed as white text on transparent, opacity-50 on dark background. Not real companies, but the names feel real.

### 3. Benchmark band / stats triplet
Full-width, high-contrast band:
- `< 200ms` — p99 response time
- `99.97%` — uptime last 12 months
- `4` — model backends (GPT-4o, Claude, Gemini, Mistral)
Typography: Bricolage Grotesque 800 weight for numbers (giant), JetBrains Mono for labels below.

### 4. Feature grid — AI-specific features
6 cards, 3-col desktop / 2-col tablet / 1-col mobile:
1. **Multi-model switching** — Choose GPT-4o, Claude Sonnet, Gemini Pro, or Mistral Large per request. No lock-in.
2. **Citation-aware answers** — Every response traces to its source: page, paragraph, exact passage. Not hallucinated references.
3. **Sub-200ms p99** — Streaming + caching mean your users never wait. Benchmark table available in docs.
4. **Eval suite built-in** — Score every response with our faithfulness, relevance, and groundedness metrics. Catch regressions before they reach prod.
5. **Structured output** — Get JSON, Markdown, or plain text. Schema-validated responses. Works with any downstream pipeline.
6. **Webhook + SDK** — Node.js, Python, Go SDKs. Webhook on async jobs. OpenAPI spec for self-generated clients.

Visual: icon (inline SVG — no Heroicons dependency) + title + 2-line description + subtle amber accent on card top-left corner.

### 5. How it works — 3 steps
1. **Upload or link your document** — PDF, URL, Markdown, or plain text. Up to 500 pages per request.
2. **Choose your model and output format** — Switch models per request; specify JSON schema or get Markdown by default.
3. **Receive answers with citations** — Your endpoint returns a structured object: summary, Q&A pairs, citations array, latency stats.

Each step has a small code snippet (Shiki-highlighted) showing the API call or response. Step 3 shows the JSON response object.

### 6. Pricing tiers (3 tiers, monthly default — no annual toggle needed for simplicity)
- **Free** — $0/mo — 1,000 pages/mo · 3 model backends · 99.9% SLA · Community support
- **Pro** — $49/mo — 50,000 pages/mo · All 4 model backends · Citation API · Eval suite · Email support · 99.95% SLA
- **Enterprise** — Custom — Unlimited · Private deployment option · SSO + RBAC · Dedicated SLA · SOC 2 audit reports · Slack support

Free is the most-emphasized tier in the card (amber accent, "Most popular" badge on Pro).

### 7. FAQ (6 items, accordion via `<details>`)
1. "Is my data used to train your models?" — No. ContextIQ processes documents ephemerally. We do not store your content beyond your retention setting (default: 24 hours). Covered by our DPA.
2. "Which models are available?" — GPT-4o, Claude Sonnet 4, Gemini Pro 1.5, and Mistral Large 2. Pro plan includes all four; Free plan includes GPT-4o, Gemini Pro, and Mistral Large.
3. "Which cloud providers do you support?" — Documents can be fetched from S3, GCS, Azure Blob, or any HTTPS URL. No vendor lock-in.
4. "What document formats are supported?" — PDF, Markdown, plain text, HTML, DOCX (via conversion), and raw URL crawl.
5. "What is your rate limit?" — Free: 10 requests/min. Pro: 200 requests/min. Enterprise: custom.
6. "Do you offer a self-hosted version?" — Enterprise plan includes a containerized private-deployment option. Contact us for details.

### 8. Final CTA band
Dark amber-gradient band:
- Headline: "Start summarizing in 5 minutes."
- Sub: "Free tier. No credit card. API key delivered instantly."
- CTA: `Get your API key →`
- Trust: "SOC 2 Type II · GDPR · Used by teams at Arcadia Health, Brio Legal, and more"

---

## Schema.org

- **Type:** `SoftwareApplication` with nested `Offer` objects per pricing tier
- **Properties:** `name: "ContextIQ"`, `description`, `applicationCategory: "DeveloperApplication"`, `operatingSystem: "Web"`, `offers: [{price: 0, ...}, {price: 49, ...}, {price: -1 (contact), ...}]`, `featureList`, `softwareVersion: "2.1.0"`
- **OG image direction:** `#09090C` background, "ContextIQ" in Bricolage Grotesque 800 at ~80px, amber tagline below, subtle radial amber glow behind the text, `API · Document Intelligence` label in JetBrains Mono at bottom. Static committed PNG 1200×630.

---

## Static-only fit

No concerns:
- **Playground:** Static HTML/CSS mockup — no live API calls, no iframe. Realistic enough to demonstrate the UX, no backend required.
- **Model picker in playground:** Static `<select>` with 4 options, no JS behavior needed (decorative).
- **Pricing:** Hardcoded in a data file (`src/data/pricing.ts`). No Stripe integration (CTAs link to external sign-up URL).
- **Code snippets:** Astro `<Code>` component with Shiki, `github-dark` theme. Build-time highlighting.
- **FAQ:** `<details>/<summary>` — zero JS.
- **Schema:** Build-time `<script type="application/ld+json">`.

---

## Differentiation story

- **vs Day 2 (saas-landing, violet/cyan, light, bento):** Day 13 is dark-default; amber accent vs violet; Bricolage Grotesque + Public Sans vs Geist/Inter; futurist vs clean-minimal register; the hero is anchored by a functional-looking playground mockup rather than a product UI screenshot bento.
- **vs Day 3 (startup-waitlist, lime, dark):** Day 13 is amber not lime; full multi-section product landing vs single-screen waitlist; AI-specific sections (model picker, eval suite, citation API, FAQ about data training) vs generic hype.
- **vs Day 10 (open-source-project, teal, dark):** Amber vs teal; commercial product vs OSS utility; pricing/eval/FAQ vs install-tabs/stars/contributors; Bricolage Grotesque vs Outfit.
- **Playground embed slot is the defining section:** No other Day 1–12 template has an interactive-demo-slot as the hero anchor. This is the template's calling card — the reason someone building an AI product reaches for it.
