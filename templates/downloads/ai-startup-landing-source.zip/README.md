# AI Startup Landing — Free Astro Template

**Day 13 of 365 Free Static Website Templates**

A dark-futurist AI product landing page for technical buyers — developers, engineering leads, product managers. The defining feature is an **interactive playground embed slot** as the hero anchor: a static mockup of a prompt-in/output-out card that shows your AI product in action at first scroll. Built for an AI document summarization API (ContextIQ) but designed to be swapped to any AI SaaS with minimal config edits.

Visual register: near-black `#09090C` + electric amber `#F59E0B` + Bricolage Grotesque display + JetBrains Mono code. Futurist and technical, like Cursor or Anthropic — not another violet/cyan bento or startup-green waitlist.

![Preview](./preview.png)

**[Live demo](https://example.com/)**

---

## Features

- **Playground embed slot** — The hero's right column is a static mock of the AI API: document picker, model selector, pre-filled question, citation-tagged answer output, latency badge. No live API calls — realistic enough to demo the UX, purely static.
- **Dark-default futurist** — `#09090C` background, `#F59E0B` amber accent. Distinct from violet (Day 2), lime (Day 3), teal (Day 10), and aubergine (Day 12).
- **Bricolage Grotesque + JetBrains Mono** — untaken in all prior 12 days. Expressive variable-weight display + developer-credible mono.
- **Benchmark band** — `< 200ms / 99.97% / 4 models` stat triplet in Bricolage Grotesque 800.
- **6-feature grid** — AI-specific: multi-model switching, citation-aware answers, eval suite, structured output, SDKs.
- **3-step API how-it-works** — With JetBrains Mono code blocks for ingest, query, and response.
- **3-tier pricing** — Free / Pro / Enterprise. Free tier most prominent, Pro badged "Most popular".
- **FAQ (6 items)** — Addresses "is my data used for training", "which models", "which cloud providers", "what formats". Pure `<details>/<summary>` — zero JS.
- **Final CTA band** — Radial amber gradient, two CTAs (sign up + docs).
- **SoftwareApplication JSON-LD** — With nested `Offer` objects per pricing tier, `featureList`, `softwareVersion`.
- **Full OG / Twitter card** — 1200×630 committed og-image.png.
- **Accessible** — axe-core WCAG 2.1 AA clean. All interactive elements keyboard-accessible.
- **Lighthouse ≥ 95** — Performance, Accessibility, Best Practices, SEO.
- **Mobile-first** — Verified at 375 / 768 / 1280 / 1920 px.
- **GitHub Pages ready** — `pages.yml` workflow included.

---

## Stack & dependencies

- [Astro 4](https://astro.build) — static site generator
- [Tailwind CSS 3](https://tailwindcss.com) — utility CSS
- [@fontsource-variable/bricolage-grotesque](https://fontsource.org/fonts/bricolage-grotesque) — self-hosted variable display sans
- [@fontsource/public-sans](https://fontsource.org/fonts/public-sans) — self-hosted body sans
- [@fontsource/jetbrains-mono](https://fontsource.org/fonts/jetbrains-mono) — self-hosted monospace
- Playwright + axe-core + LHCI — test suite

---

## Quick start

```bash
# 1. Download the source ZIP from the live demo page:
#    https://example.com/ai-startup-landing-source.zip
unzip ai-startup-landing-source.zip -d my-ai-landing && cd my-ai-landing

# 2. Install + develop
npm install
npm run dev

# 3. Customize (see Customize section below)

# 4. Build
npm run build

# 5. Preview locally
npm run preview
```

---

## Deploy to GitHub Pages

1. Download the source ZIP from `https://example.com/ai-startup-landing-source.zip`
2. Unzip into a new folder on your machine.
3. Initialize a new Git repo and push to a new GitHub repo of your own:
   ```bash
   git init && git add . && git commit -m "init from ai-startup-landing template"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
4. In your repo Settings → Pages → Source: **GitHub Actions**.
5. The included `.github/workflows/pages.yml` builds and deploys on every push to `main`.

---

## Customize

All content lives in **`src/data/config.ts`** — one file to rule them all.

| What | Where |
|---|---|
| Product name, tagline, description | `brand.name`, `brand.tagline`, `brand.description` |
| Docs URL, signup URL | `brand.docsUrl`, `brand.signupUrl` |
| Social links | `brand.socials.linkedin`, `.twitter`, `.github`, `.email` |
| Stats (benchmark band) | `stats[]` array |
| Logo strip companies | `logos[]` array |
| Feature grid (6 items) | `features[]` array |
| How-it-works (3 steps + code) | `steps[]` array |
| Pricing tiers (3 tiers) | `pricingTiers[]` array |
| FAQ (6 items) | `faqs[]` array |

### Playground card

The playground card is in `src/components/Hero.astro`. It's a static HTML mockup — edit the document name, model selector, question, answer lines, and citation badges directly in the component. No data file drives it (it's meant to be a bespoke demo of your specific product).

### Colors & fonts

Override CSS variables in `src/styles/global.css`:

```css
:root {
  --color-bg:      #09090C;  /* near-black */
  --color-accent:  #F59E0B;  /* amber */
  /* ... */
}
```

Font families are set in `tailwind.config.mjs`.

### Custom domain

Set two repo variables (Settings → Secrets and variables → Actions → Variables):
```
PUBLIC_BASE_PATH=/
PUBLIC_SITE_URL=https://your-domain.com
```

---

## Testing

```bash
npm run test:all         # build + Playwright + links + Lighthouse
npm run test             # Playwright only
npm run test:a11y        # axe accessibility only
npm run test:links       # linkinator dead-link check on dist/
npm run test:lighthouse  # Lighthouse CI (all 4 scores >= 95)
```

Playwright covers:
- Page renders, h1 visible, no console errors
- Playground card visible
- Pricing section has 3 tiers
- FAQ section has 6 items, accordion opens on click
- Feature grid has 6 cards
- How-it-works has 3 steps
- Responsive at 4 viewports (no horizontal overflow)
- Hero h1 visible above the fold on mobile
- axe WCAG 2.1 AA zero violations
- SoftwareApplication JSON-LD with offers
- OG / Twitter card tags
- Canonical, robots.txt, sitemap.xml

---

## Alternate deploys

| Provider | Notes |
|---|---|
| **Netlify** | Drop the `dist/` folder or connect your repo. Set `PUBLIC_BASE_PATH=/` |
| **Vercel** | Connect repo. Set `PUBLIC_BASE_PATH=/` as env var. Framework: Astro. |
| **Cloudflare Pages** | Connect repo. Build command: `npm run build`. Output: `dist`. Set `PUBLIC_BASE_PATH=/` |

---

## Support / donations

This template is free and MIT-licensed. If it saves you time:

- [All 365 templates](https://example.com/templates) — browse the rest of the library.

---

## License

MIT — free to use, modify, and distribute. Attribution appreciated but not required.

Built by [Allan Niñal](https://example.com) as part of the [365 Free Static Templates](https://example.com/templates) project.
