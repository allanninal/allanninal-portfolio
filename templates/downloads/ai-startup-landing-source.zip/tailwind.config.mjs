/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  // Dark-default futurist register. Electric amber on near-black.
  // Bricolage Grotesque display + Public Sans body + JetBrains Mono code.
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Public Sans"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Bricolage Grotesque Variable"', '"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'monospace'],
      },
      fontSize: {
        'xs':  ['0.75rem',  { lineHeight: '1.6' }],
        'sm':  ['0.875rem', { lineHeight: '1.65' }],
        'base':['1rem',     { lineHeight: '1.75' }],
        'lg':  ['1.125rem', { lineHeight: '1.65' }],
        'xl':  ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.3' }],
        '3xl': ['1.875rem', { lineHeight: '1.2' }],
        '4xl': ['2.5rem',   { lineHeight: '1.1' }],
        '5xl': ['3.5rem',   { lineHeight: '1.05' }],
        '6xl': ['4.5rem',   { lineHeight: '1.02' }],
      },
      maxWidth: {
        '7xl': '74rem',
        prose: '64ch',
      },
      colors: {
        amber: {
          400: '#FBBF24',
          500: '#F59E0B',
          600: '#D97706',
          700: '#B45309',
        },
      },
    },
  },
};
