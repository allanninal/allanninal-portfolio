export type GalleryPhoto = {
  id: number;
  alt: string;
  caption?: string;
  aspectRatio: 'portrait' | 'landscape' | 'square';
  // CSS background gradient used as placeholder (no external images needed)
  placeholderGradient: string;
  // Pro edition: local photo filename under images/pro/gallery/
  src?: string;
};

export const gallery: GalleryPhoto[] = [
  {
    id: 1,
    src: 'lake',
    alt: 'Emma and James at Crater Lake, where Emma proposed',
    caption: 'Crater Lake — where it all began again',
    aspectRatio: 'landscape',
    placeholderGradient: 'linear-gradient(135deg, #D4B8B4 0%, #A8C5B8 50%, #C4D4CC 100%)',
  },
  {
    id: 2,
    src: 'vineyard',
    alt: 'Emma and James in a sunlit vineyard',
    caption: 'Golden hour in the vines',
    aspectRatio: 'portrait',
    placeholderGradient: 'linear-gradient(160deg, #E8D5C4 0%, #C4B09A 60%, #D4C4A8 100%)',
  },
  {
    id: 3,
    src: 'laughing',
    alt: 'James laughing on a hillside',
    caption: 'A perfect afternoon',
    aspectRatio: 'portrait',
    placeholderGradient: 'linear-gradient(140deg, #F0D8D4 0%, #C4847A 70%, #D4A098 100%)',
  },
  {
    id: 4,
    src: 'coast',
    alt: 'Emma and James walking on a coastal path',
    caption: 'Our engagement walk',
    aspectRatio: 'landscape',
    placeholderGradient: 'linear-gradient(120deg, #B8C8C4 0%, #8AAFA8 50%, #A4BCBC 100%)',
  },
  {
    id: 5,
    src: 'rings',
    alt: 'Hands with engagement rings',
    caption: 'Yes.',
    aspectRatio: 'square',
    placeholderGradient: 'linear-gradient(135deg, #F5E8E6 0%, #E8D4D0 50%, #D4B8B4 100%)',
  },
  {
    id: 6,
    src: 'beach',
    alt: 'Emma and James at sunset on the beach',
    caption: 'Chasing sunsets together',
    aspectRatio: 'landscape',
    placeholderGradient: 'linear-gradient(150deg, #E8C8A0 0%, #D4A878 50%, #C4907A 100%)',
  },
];
