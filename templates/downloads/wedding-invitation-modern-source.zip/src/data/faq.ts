export type FaqItem = {
  question: string;
  answer: string;
};

export const faq: FaqItem[] = [
  {
    question: 'What is the dress code?',
    answer:
      'Garden formal — think sundresses, linen suits, flowy separates. Heels are not recommended as the ceremony is on grass. Please avoid white and ivory out of respect for the couple.',
  },
  {
    question: 'Can I bring a plus-one?',
    answer:
      'Due to venue capacity, plus-ones are only available if listed on your invitation. If your envelope says "and guest," you are welcome to bring one. If you have questions, please reach out before RSVPing.',
  },
  {
    question: 'Are children welcome?',
    answer:
      'We adore your little ones! Children under 3 are welcome. For older children, we respectfully ask that this be an adults-only evening so everyone can celebrate freely. We hope you can arrange childcare and join us!',
  },
  {
    question: 'I have dietary restrictions — will there be options?',
    answer:
      'Absolutely. The RSVP form has a dietary field — please let us know about any allergies or restrictions. Our caterer accommodates vegetarian, vegan, gluten-free, and nut-free diets.',
  },
  {
    question: 'Is there parking at the venue?',
    answer:
      'Yes, free parking is available on-site. However, we strongly encourage using the shuttle service if you plan to drink. The shuttle runs every 30 minutes between the venue and the Napa Marriott from 3:00 PM to midnight.',
  },
  {
    question: 'Can I take photos during the ceremony?',
    answer:
      'We are having an unplugged ceremony — please put devices away during the vows so everyone can be fully present. Our photographer will capture every moment beautifully. The reception is fully camera-friendly!',
  },
  {
    question: 'What happens if I need to cancel my RSVP?',
    answer:
      'Life happens! Please let us know as soon as possible at hello@emmaandjames.com. Our caterer needs final numbers by September 5th.',
  },
  {
    question: 'Where should I stay?',
    answer:
      'We have a room block at the Napa Marriott (5 minutes from the venue) for guests who need lodging. Use code EMMAJAMES2026 for the discounted group rate. The block is available until August 15th.',
  },
];
