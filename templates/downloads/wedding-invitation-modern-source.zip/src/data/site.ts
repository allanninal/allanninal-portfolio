export const site = {
  couple: {
    name1: 'Emma',
    name2: 'James',
    fullName1: 'Emma Kim',
    fullName2: 'James Reyes',
    combinedName: 'Emma & James',
    lastNames: 'Kim-Reyes',
    email: 'hello@emmaandjames.com',
    hashtag: '#EmmaAndJames2026',
  },
  wedding: {
    date: 'Saturday, September 19, 2026',
    dateShort: 'Sept 19, 2026',
    dateIso: '2026-09-19',
    timeIso: '2026-09-19T16:00:00-07:00',
    endTimeIso: '2026-09-19T23:00:00-07:00',
    timezone: 'America/Los_Angeles',
    rsvpDeadline: 'August 1, 2026',
  },
  venue: {
    name: 'The Orchard at Sunrise Farm',
    address: '142 Willow Creek Road',
    city: 'Napa',
    state: 'CA',
    zip: '94558',
    country: 'US',
    mapUrl: 'https://maps.google.com/?q=142+Willow+Creek+Road+Napa+CA+94558',
    lat: 38.2975,
    lng: -122.2869,
  },
  description:
    'Emma Kim and James Reyes invite you to celebrate their wedding on September 19, 2026 at The Orchard at Sunrise Farm in Napa, California.',
  og: {
    alt: 'Emma & James — Wedding, September 19, 2026',
  },
};
