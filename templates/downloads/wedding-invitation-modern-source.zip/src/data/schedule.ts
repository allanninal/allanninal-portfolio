export type ScheduleItem = {
  time: string;
  title: string;
  description: string;
  icon: string;
};

export const schedule: ScheduleItem[] = [
  {
    time: '3:30 PM',
    title: 'Guests Arrive',
    description: 'Doors open. Enjoy welcome drinks and take your seats in the orchard.',
    icon: '◇',
  },
  {
    time: '4:00 PM',
    title: 'Ceremony',
    description: 'Join us under the oak canopy as we exchange vows. Approximately 30 minutes.',
    icon: '◇',
  },
  {
    time: '5:00 PM',
    title: 'Cocktail Hour',
    description: 'Celebrate with bubbles, small bites, and music by the garden terrace.',
    icon: '◇',
  },
  {
    time: '6:30 PM',
    title: 'Dinner',
    description: 'Seated farm-to-table dinner in the barn. Three courses, locally sourced.',
    icon: '◇',
  },
  {
    time: '8:30 PM',
    title: 'First Dance & Speeches',
    description: 'First dance, toasts from family and friends, and the cake cutting.',
    icon: '◇',
  },
  {
    time: '9:00 PM',
    title: 'Dancing',
    description: 'Let loose on the dance floor. Music until 11:00 PM.',
    icon: '◇',
  },
  {
    time: '11:00 PM',
    title: 'Last Dance & Farewell',
    description: 'Safe travels! Shuttles depart at 11:15 PM from the main entrance.',
    icon: '◇',
  },
];
