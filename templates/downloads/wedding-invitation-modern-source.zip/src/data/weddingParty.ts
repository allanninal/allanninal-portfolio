export type PartyMember = {
  name: string;
  role: string;
  relation: string;
  side: 'person1' | 'person2';
};

export const weddingParty: PartyMember[] = [
  // Emma's side
  {
    name: 'Sam Kim',
    role: 'Best Person',
    relation: 'Sibling of Emma',
    side: 'person1',
  },
  {
    name: 'Riley Chen',
    role: 'Attendant',
    relation: 'Childhood friend of Emma',
    side: 'person1',
  },
  {
    name: 'Morgan Patel',
    role: 'Attendant',
    relation: 'College roommate of Emma',
    side: 'person1',
  },
  // James's side
  {
    name: 'Taylor Reyes',
    role: 'Best Person',
    relation: 'Sibling of James',
    side: 'person2',
  },
  {
    name: 'Quinn Nakamura',
    role: 'Attendant',
    relation: 'Childhood friend of James',
    side: 'person2',
  },
  {
    name: 'Drew Okonkwo',
    role: 'Attendant',
    relation: 'Graduate school friend of James',
    side: 'person2',
  },
];
