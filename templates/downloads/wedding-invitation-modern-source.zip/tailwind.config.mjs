/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'ui-serif', 'serif'],
        sans: ['"DM Sans"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      colors: {
        // Warm blush / ivory palette — unique to Day 21
        bg:      '#FAF7F4',
        surface: '#FFFFFF',
        border:  '#E8E0D8',
        // Dusty rose accent — WCAG AA compliant at full opacity
        accent: {
          DEFAULT: '#C4847A',
          dark:    '#A86860',
          light:   '#F5E8E6',
          dim:     '#8C4F47',
        },
        text: {
          DEFAULT: '#2C2420',
          muted:   '#7A6E6A',
          faint:   '#B0A49E',
        },
        // Wedding-specific shades
        blush:  '#F0D8D4',
        linen:  '#FAF7F4',
        sage:   '#8BAF8A',
      },
      fontSize: {
        xs:    ['0.8rem',   { lineHeight: '1.5' }],
        sm:    ['0.9rem',   { lineHeight: '1.55' }],
        base:  ['1rem',     { lineHeight: '1.7' }],
        lg:    ['1.125rem', { lineHeight: '1.65' }],
        xl:    ['1.25rem',  { lineHeight: '1.5' }],
        '2xl': ['1.5rem',   { lineHeight: '1.35' }],
        '3xl': ['1.875rem', { lineHeight: '1.25' }],
        '4xl': ['2.25rem',  { lineHeight: '1.15' }],
        '5xl': ['3rem',     { lineHeight: '1.1' }],
        '6xl': ['3.75rem',  { lineHeight: '1.05' }],
        '7xl': ['4.5rem',   { lineHeight: '1.02' }],
        '8xl': ['6rem',     { lineHeight: '1' }],
      },
      maxWidth: {
        '7xl': '80rem',
        '8xl': '88rem',
      },
      letterSpacing: {
        widest: '0.25em',
        wider: '0.15em',
      },
    },
  },
};
