# Day 21 — Wedding Invitation (Modern) — Niche Research

## Persona
**Emma & James** — a couple planning an intimate, modern wedding. Aesthetic: editorial minimalism with warm organic touches. The site is their digital invitation and RSVP hub, shared privately with 150 guests.

## Visual Identity
- **Palette family:** Warm blush/ivory — entirely distinct from all Days 1-20.
  - Background: off-white linen `#FAF7F4`
  - Surface: warm white `#FFFFFF`
  - Border: warm sand `#E8E0D8`
  - Accent (dusty rose): `#C4847A` — AA-compliant against white at 14px+
  - Accent dark (hover): `#A86860`
  - Text: charcoal `#2C2420`
  - Text muted: warm grey `#7A6E6A`
- **Density:** Generous whitespace — single-page editorial scroll, lots of breathing room between sections
- **Motion:** Subtle fade-in on scroll, no jarring transitions

## Typography
- **Display/Heading:** Cormorant Garamond (italic weight for names) — elegance without being stuffy
- **Body/UI:** DM Sans — contemporary, readable, pairs well with serif display
- Combination is FRESH: designer-portfolio (Day 15) used Cormorant Garamond but paired with Archivo Black; here it pairs with DM Sans which is a completely different body register

## Schema.org
- `Event` with `eventAttendanceMode: OfflinePrivate` — private, non-ticketed wedding
- `Place` for the venue
- `Person` for each member of the couple
- NO `Offer` / NO `ticketUrl` — differentiates from Day 20 (conference-event)

## Sections (single page)
1. **Hero** — names "Emma & James", wedding date, location, decorative divider
2. **Our Story** — 3-panel narrative: how they met, the proposal, the year ahead
3. **The Day** — schedule (ceremony 4:00 PM, cocktails 5:30 PM, dinner 7:00 PM, dancing 9:00 PM)
4. **Venue + Travel** — venue name/address, map link, hotel block, transit note
5. **Wedding Party** — bridesmaids + groomspeople with names and roles
6. **Registry** — Zola, Honeyfund, Amazon (generic placeholder links)
7. **RSVP** — the conversion goal; name, attendance, meal preference, dietary, message (accessible form)
8. **Gallery** — engagement photo grid (CSS art-direction placeholder images)
9. **FAQ** — dress code, plus-ones, kids, dietary, parking, photography policy
10. **Footer** — couple names, date, couple email placeholder

## Differentiation from prior days
- Day 17 (writer-author-site): Playfair Display + Crimson Pro, ivory + Prussian blue → completely different blue-based palette
- Day 15 (designer-portfolio): Cormorant Garamond + Archivo Black, terracotta → terracotta vs blush/dusty rose, Archivo Black vs DM Sans
- Day 20 (conference-event): dark emerald, Syne + Inter → dark vs light, public event vs private wedding, has Offers vs no Offers
- This template is the ONLY warm-blush/ivory palette in the roadmap so far

## Content placeholders
- Couple: Emma & James Kim-Reyes
- Date: Saturday, September 19, 2026
- Venue: The Orchard at Sunrise Farm, 142 Willow Creek Road, Napa, CA 94558
- Couple email: hello@emmaandjames.com (placeholder, NOT Allan's real email)
