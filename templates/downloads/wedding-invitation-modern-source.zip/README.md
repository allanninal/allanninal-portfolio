# Wedding Invitation (Modern) — Day 21 of 365

A modern, editorial wedding invitation site with RSVP. Single-page scroll, warm blush/ivory palette, Cormorant Garamond + DM Sans. Built with Astro + Tailwind.

**Live demo:** https://templates.allanninal.dev/wedding-invitation-modern/

## Features

- Hero with couple names, date, and venue
- Our Story — 3-chapter narrative
- Day schedule — timeline with ceremony, cocktails, dinner, and dancing
- Venue + travel — hotel block, shuttle info, airports
- Wedding party — grid of bridesmaids/groomspeople with roles
- Registry — links to Zola, Honeyfund, and Amazon
- RSVP form — name, email, attendance, meal preference, dietary notes, and message (Formspree-ready)
- Engagement photo gallery — masonry grid with placeholder gradients
- FAQ — 8 questions (dress code, plus-ones, kids, dietary, parking, photography, cancellation, hotels)
- JSON-LD: `Event` (private, `OfflineEventAttendanceMode`) + `Place` + `Person` + `FAQPage`

## Personalize

1. **Couple data** — edit `src/data/site.ts` for names, date, venue, and couple email
2. **Schedule** — edit `src/data/schedule.ts`
3. **Wedding party** — edit `src/data/weddingParty.ts`
4. **FAQ** — edit `src/data/faq.ts`
5. **Gallery** — replace placeholder gradients in `src/data/gallery.ts` with real `<img>` tags
6. **RSVP form** — replace the Formspree placeholder URL in `src/pages/index.astro`
7. **Colors/fonts** — edit `tailwind.config.mjs` and `src/styles/global.css`
8. **OG image** — edit or replace `public/og-image.svg`, run through a PNG export tool

## Quick start

```bash
npm install
npm run dev       # dev server at http://localhost:4321
npm run build     # production build to dist/
npm run preview   # preview the built output
npm run test      # Playwright tests
```

## Deploy

GitHub Pages workflow included at `.github/workflows/pages.yml`.

1. Fork/clone this template into a new repo
2. Push to `main`
3. Settings → Pages → Source: GitHub Actions
4. Done — the site builds and deploys automatically on every push

## License

MIT — free to use, modify, and distribute. Attribution appreciated but not required.
