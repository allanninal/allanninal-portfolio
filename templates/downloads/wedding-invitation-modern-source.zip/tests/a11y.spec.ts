import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

// Portable accessibility gate. Everything here is true of every template in the
// library, so this file can be dropped into any of them unchanged. Template-specific
// structure (named components, section counts) belongs in that template's own spec.

/** Same-origin pages reachable from the homepage, including the homepage itself. */
async function sitePages(page: import('@playwright/test').Page): Promise<string[]> {
  await page.goto('/');
  const hrefs = await page.$$eval('a[href]', (as) => as.map((a) => (a as HTMLAnchorElement).getAttribute('href') || ''));
  const paths = new Set<string>(['/']);
  for (const h of hrefs) {
    if (!h || h.startsWith('http') || h.startsWith('mailto:') || h.startsWith('tel:') || h.startsWith('#')) continue;
    const path = h.split('#')[0].split('?')[0];
    if (!path || /\.(zip|pdf|png|jpe?g|svg|webp|xml|txt|ico)$/i.test(path)) continue;
    paths.add(path.startsWith('/') ? path : `/${path}`);
  }
  return [...paths];
}

async function axeOn(page: import('@playwright/test').Page, path: string) {
  await page.goto(path);
  await page.waitForLoadState('networkidle');
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .exclude('script[type="application/ld+json"]')
    .analyze();
  if (results.violations.length) {
    console.log(`Axe violations on ${path}:`);
    for (const v of results.violations) {
      console.log(`  [${v.impact}] ${v.id}: ${v.description}`);
      for (const n of v.nodes) console.log(`    → ${n.html}`);
    }
  }
  return results.violations;
}

test.describe('accessibility', () => {
  test('every page passes the axe WCAG 2.1 AA audit', async ({ page }) => {
    const pages = await sitePages(page);
    const failed: string[] = [];
    for (const p of pages) {
      if ((await axeOn(page, p)).length) failed.push(p);
    }
    expect(failed, `pages with WCAG AA violations: ${failed.join(', ')}`).toEqual([]);
  });

  test('no ARIA attribute errors', async ({ page }) => {
    await page.goto('/');
    const results = await new AxeBuilder({ page }).withTags(['cat.aria']).analyze();
    expect(results.violations).toEqual([]);
  });

  // Colour contrast is the rule this library regresses on most often, and the footer
  // is where it hides: a var() fallback chain that silently resolves to currentColor
  // leaves the maker credit unreadable while the rest of the page passes.
  test('colour contrast passes, including inside the footer', async ({ page }) => {
    await page.goto('/');
    const all = await new AxeBuilder({ page }).withRules(['color-contrast']).analyze();
    if (all.violations.length) {
      for (const v of all.violations) for (const n of v.nodes) {
        console.log(`  ${n.html}`);
        n.any.forEach((a: any) => console.log(`    ${JSON.stringify(a.data)}`));
      }
    }
    expect(all.violations).toEqual([]);

    if (await page.locator('footer').count()) {
      const footer = await new AxeBuilder({ page }).include('footer').withRules(['color-contrast']).analyze();
      expect(footer.violations).toEqual([]);
    }
  });

  test('each page has exactly one h1', async ({ page }) => {
    for (const p of await sitePages(page)) {
      await page.goto(p);
      expect(await page.locator('h1').count(), `h1 count on ${p}`).toBe(1);
    }
  });

  test('every image carries an alt attribute', async ({ page }) => {
    for (const p of await sitePages(page)) {
      await page.goto(p);
      const missing = await page.$$eval('img:not([alt])', (els) => els.map((e) => e.outerHTML.slice(0, 120)));
      expect(missing, `<img> without alt on ${p}`).toEqual([]);
    }
  });
});
