import { test, expect } from '@playwright/test';

test.describe('Wedding Invitation Modern — smoke tests', () => {
  test('home page loads with couple names', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Emma & James/i);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Emma');
  });

  test('navigation links are present', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('link', { name: /RSVP/i }).first()).toBeVisible();
    await expect(page.getByRole('link', { name: /Our Story/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /The Day/i })).toBeVisible();
    // Use the nav-scoped anchor to avoid strict-mode collision with "Get Directions"
    await expect(page.getByRole('navigation').getByRole('link', { name: /Venue/i })).toBeVisible();
  });

  test('RSVP form is present and functional', async ({ page }) => {
    await page.goto('/');
    const form = page.getByRole('form', { name: /RSVP form/i });
    await expect(form).toBeVisible();
    await expect(form.getByLabel(/your name/i)).toBeVisible();
    await expect(form.getByLabel(/email address/i)).toBeVisible();
    await expect(form.getByRole('button', { name: /Send RSVP/i })).toBeVisible();
  });

  test('schedule section shows ceremony time', async ({ page }) => {
    await page.goto('/');
    // Use heading role to avoid strict-mode collision with FAQ text
    await expect(page.getByRole('heading', { name: 'Ceremony' })).toBeVisible();
    await expect(page.getByText('4:00 PM')).toBeVisible();
  });

  test('FAQ section has dress code question', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText('What is the dress code?')).toBeVisible();
  });

  test('JSON-LD Event schema with OfflineEventAttendanceMode is present', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    let hasEvent = false;
    let hasOfflineMode = false;
    for (const script of scripts) {
      const content = await script.textContent();
      if (content && content.includes('"Event"')) hasEvent = true;
      if (content && content.includes('OfflineEventAttendanceMode')) hasOfflineMode = true;
    }
    expect(hasEvent).toBe(true);
    expect(hasOfflineMode).toBe(true);
  });

  test('JSON-LD has no Offer (private event)', async ({ page }) => {
    await page.goto('/');
    const scripts = await page.locator('script[type="application/ld+json"]').all();
    for (const script of scripts) {
      const content = await script.textContent();
      if (content) {
        expect(content).not.toContain('"Offer"');
      }
    }
  });

  test('no github.com deep-links in page source', async ({ page }) => {
    await page.goto('/');
    const html = await page.content();
    const deepLinks = html.match(/github\.com\/allanninal\/templates[^"'\s]*/g);
    expect(deepLinks).toBeNull();
  });

  test('wedding party section shows party members', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText('Sam Kim')).toBeVisible();
    await expect(page.getByText('Taylor Reyes')).toBeVisible();
  });

  test('registry links are present', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('link', { name: /zola registry/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /honeyfund/i })).toBeVisible();
  });

  test('venue section shows venue name', async ({ page }) => {
    await page.goto('/');
    // Use heading role to avoid strict-mode collision (venue name appears in hero + venue section + footer)
    await expect(page.getByRole('heading', { name: 'The Orchard at Sunrise Farm' })).toBeVisible();
  });
});
