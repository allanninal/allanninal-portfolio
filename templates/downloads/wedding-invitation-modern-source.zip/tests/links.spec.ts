import { test, expect } from '@playwright/test';

// Portable link-integrity gate. Asserts only what holds for every template in the
// library, so it can be dropped into any of them unchanged.

async function internalPaths(page: import('@playwright/test').Page): Promise<string[]> {
  await page.goto('/');
  const hrefs = await page.$$eval('a[href]', (as) => as.map((a) => (a as HTMLAnchorElement).getAttribute('href') || ''));
  const paths = new Set<string>(['/']);
  for (const h of hrefs) {
    if (!h || h.startsWith('http') || h.startsWith('mailto:') || h.startsWith('tel:') || h.startsWith('#')) continue;
    const path = h.split('#')[0].split('?')[0];
    if (!path) continue;
    paths.add(path.startsWith('/') ? path : `/${path}`);
  }
  return [...paths];
}

test.describe('link integrity', () => {
  test('homepage responds 200', async ({ page }) => {
    const res = await page.goto('/');
    expect(res?.status()).toBe(200);
  });

  test('homepage has a non-empty, non-placeholder title', async ({ page }) => {
    await page.goto('/');
    const title = (await page.title()).trim();
    expect(title.length).toBeGreaterThan(10);
    // "Astro" is NOT forbidden here: several templates legitimately name the stack
    // in the title (e.g. "… — Free Astro Template · Day 26 of 365").
    expect(title).not.toMatch(/lorem ipsum|todo|placeholder|untitled|document/i);
  });

  test('every internal link resolves', async ({ page, request }) => {
    const broken: string[] = [];
    for (const p of await internalPaths(page)) {
      const res = await request.get(p);
      if (res.status() >= 400) broken.push(`${p} → ${res.status()}`);
    }
    expect(broken, `broken internal links: ${broken.join(', ')}`).toEqual([]);
  });

  // An href of "#" or "" is a button wearing a link's clothes: it reaches the
  // accessibility tree as a link, and it goes nowhere.
  test('no dead-end hrefs', async ({ page }) => {
    await page.goto('/');
    const dead = await page.$$eval('a[href]', (as) =>
      as
        .filter((a) => {
          const h = (a as HTMLAnchorElement).getAttribute('href') || '';
          return h === '' || h === '#';
        })
        .map((a) => a.outerHTML.slice(0, 120)),
    );
    expect(dead).toEqual([]);
  });

  // Deliberately checks rendered text, not raw HTML: the test harness sets
  // PUBLIC_SITE_URL to http://localhost:<port>, so canonical/og:url legitimately
  // carry a localhost origin during a run. What must never appear is unfilled
  // scaffold copy.
  test('no placeholder copy survives into the rendered page', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('body').innerText();
    for (const bad of ['example.com', 'YOUR_', 'TODO', 'Lorem ipsum', 'lorem ipsum', 'FIXME']) {
      expect(text, `page renders the placeholder ${bad}`).not.toContain(bad);
    }
  });

  // target="_blank" without rel="noopener" hands the opened tab a window.opener
  // handle back to this page.
  test('external new-tab links carry rel="noopener"', async ({ page }) => {
    await page.goto('/');
    const unsafe = await page.$$eval('a[target="_blank"]', (as) =>
      as
        .filter((a) => !((a as HTMLAnchorElement).rel || '').includes('noopener'))
        .map((a) => a.outerHTML.slice(0, 120)),
    );
    expect(unsafe).toEqual([]);
  });
});
