/**
 * Meridian Pool Co. — every string the page renders.
 *
 * Business fictional. The CHEMISTRY TARGETS AND PRICES ARE REAL, cross-checked
 * across industry sources; where sources disagree (notably total alkalinity)
 * the copy says so rather than picking one silently. Sources in RESEARCH.md.
 */

export const site = {
  name: 'Meridian Pool Co.',
  shortName: 'Meridian',
  tagline: 'Six numbers decide whether your pool is safe.',
  description:
    'CPO-certified pool service in Scottsdale. We publish the readings your water should hit, what each one does when it drifts, and the one nobody checks that quietly makes chlorine useless.',
  owner: 'Ivy Castellanos',
  ownerRole: 'Owner · CPO certified',
  credential: 'Certified Pool Operator #CPO-44902',
  yearsExperience: 10,
  city: 'Scottsdale',
  state: 'AZ',
  streetAddress: '7120 East Thomas Road',
  postalCode: '85251',
  phoneDisplay: '(480) 555-0164',
  phoneHref: '+14805550164',
  email: 'hello@meridianpool.example',
  formAction: '#',
  hours: 'Mon–Fri 6am–3pm · Green-pool calls triaged same day',
  bookingWindow: 'Routes open weekly. Green-pool recovery quoted within a day.',

  language: 'en-US',
  twitterHandle: '@example',
  ogImage: '/og-image.png',
  title: 'Meridian Pool Co. — Pool Service & Water Chemistry in Scottsdale, AZ',
  license: 'AZ ROC #331204 · Fully insured',
  instagram: 'https://www.instagram.com/meridianpoolco',
  facebook: 'https://www.facebook.com/meridianpoolco',
};

export const nav = [
  { label: 'The panel', href: '#panel' },
  { label: 'When it drifts', href: '#drift' },
  { label: 'Plans', href: '#plans' },
  { label: 'Skip us', href: '#skip' },
  { label: 'Areas', href: '#areas' },
  { label: 'FAQ', href: '#faq' },
];

/**
 * The six readings.
 *
 * These drive real <meter> elements — the correct HTML for a value inside a
 * known range. min/low/high/max/optimum are the element's own attributes, so a
 * screen reader announces the reading and its bounds with no ARIA at all.
 *
 * `reading` is a plausible current sample, deliberately not all-ideal: two are
 * out of band, because a panel where everything is green teaches nothing.
 */
export const panel = [
  {
    id: 'fc', name: 'Free chlorine', unit: 'ppm',
    min: 0, low: 1, high: 3, max: 6, reading: 2.4, state: 'ok',
    ideal: '1 – 3 ppm', accept: '1 – 4 ppm',
    role: 'The sanitiser. Everything else on this panel exists to keep it working.',
  },
  {
    id: 'ph', name: 'pH', unit: '',
    min: 6.8, low: 7.4, high: 7.6, max: 8.4, reading: 7.5, state: 'ok',
    ideal: '7.4 – 7.6', accept: '7.2 – 7.8',
    role: 'Moves everything else. Fix pH before you touch any other number.',
  },
  {
    id: 'ta', name: 'Total alkalinity', unit: 'ppm',
    min: 0, low: 80, high: 120, max: 200, reading: 132, state: 'high',
    ideal: '80 – 120 ppm', accept: 'sources differ — 50–90 is also cited for chlorine pools',
    role: 'pH’s shock absorber. Too low and pH bounces; too high and pH will not move at all.',
  },
  {
    id: 'cya', name: 'Cyanuric acid', unit: 'ppm',
    min: 0, low: 30, high: 50, max: 120, reading: 88, state: 'high',
    ideal: '30 – 50 ppm', accept: 'up to about 70',
    role: 'The one nobody checks. Above 70–100 ppm chlorine gets progressively less effective, and no test strip will tell you.',
  },
  {
    id: 'ch', name: 'Calcium hardness', unit: 'ppm',
    min: 0, low: 200, high: 400, max: 800, reading: 340, state: 'ok',
    ideal: '200 – 400 ppm', accept: '—',
    role: 'Below 200 the water corrodes plaster and metal; above 400–500 it scales.',
  },
  {
    id: 'temp', name: 'Water temperature', unit: '°F',
    min: 50, low: 78, high: 86, max: 104, reading: 88, state: 'high',
    ideal: '78 – 86 °F', accept: '—',
    role: 'Not a chemical, but it drives demand. Chlorine burns off far faster above 88 °F.',
  },
];

/** What each drift actually does. The CYA entry is the argument of the page. */
export const drift = [
  { param: 'pH too low', below: 'Below 7.2', effect: 'Etches plaster, corrodes metal, stings eyes. Chlorine is aggressive but short-lived.', fix: 'Soda ash, slowly, then retest in 6 hours.' },
  { param: 'pH too high', below: 'Above 7.8', effect: 'Chlorine loses most of its bite, scale forms, water clouds.', fix: 'Muriatic acid in small doses. Check alkalinity first — high TA is usually the reason pH keeps climbing.' },
  { param: 'Alkalinity too high', below: 'Above 120 ppm', effect: 'pH becomes stubborn and drifts upward no matter what you add.', fix: 'Acid additions with aeration. Slow work; nobody fixes this in one visit.' },
  { param: 'CYA too high', below: 'Above 70 ppm', effect: 'The trap. Chlorine reads fine on a strip and is progressively less able to kill anything. This is how a pool with "normal" chlorine goes green.', fix: 'There is no chemical that removes it. Partial drain and refill is the only real answer — which is why we watch it rather than let it get there.' },
  { param: 'Calcium too low', below: 'Below 200 ppm', effect: 'Water pulls calcium out of plaster and grout to satisfy itself.', fix: 'Calcium chloride. Easy to fix, easy to overshoot.' },
  { param: 'Calcium too high', below: 'Above 500 ppm', effect: 'Scale on tile, heater elements and salt cells.', fix: 'Partial drain, or a sequestrant to buy time in hard-water areas like this one.' },
];

/** Real 2026 US figures. */
export const plans = [
  { name: 'Chemistry only', price: '$30 – $95 / month', fit: 'You brush and skim; we test, dose and log.', includes: ['Weekly test of all six readings', 'Chemicals included', 'A written log you keep', 'Equipment check monthly'] },
  { name: 'Full weekly', price: '$150 – $350+ / month', fit: 'The standard plan for most Scottsdale pools.', includes: ['Everything in chemistry only', 'Brush, skim, vacuum', 'Baskets and filter pressure', 'Salt cell inspection'] },
  { name: 'Per visit', price: '$80 – $150', fit: 'Vacation cover, or a one-off before guests.', includes: ['Full clean and balance', 'Written reading sheet', 'No contract'] },
];

/** The section that costs the business money. */
export const skip = {
  intro: 'Not everyone needs a pool service, and we would rather say so than sell you one you resent.',
  points: [
    { when: 'A small pool and a bit of curiosity', why: 'A $60 drop-test kit and twenty minutes a week genuinely covers it. The kit pays for itself in under a month against any plan on this page.' },
    { when: 'You already test and log', why: 'If you know your CYA and your alkalinity off the top of your head, you do not need us weekly. Book a quarterly check instead.' },
    { when: 'The pool is closed for the season', why: 'Winter cover in this climate is a monthly look, not a weekly visit. Ask us to drop to the low plan; we will not raise it back without telling you.' },
  ],
  caveat: 'Where we do earn the money: green-pool recovery, salt cells, heaters, and the CYA creep that nobody notices until chlorine stops working.',
};

export const areas = [
  { zone: 'Scottsdale', towns: 'Old Town · McCormick Ranch · Gainey Ranch · North Scottsdale' },
  { zone: 'Phoenix', towns: 'Arcadia · Biltmore · Paradise Valley · Camelback East' },
  { zone: 'East valley', towns: 'Tempe · Mesa · Gilbert · Chandler' },
  { zone: 'North', towns: 'Cave Creek · Carefree · Fountain Hills' },
];

export const reviews = [
  { name: 'Renata O.', town: 'McCormick Ranch', text: 'Two services before her told me the chlorine was fine. Ivy tested CYA at 96, explained why the chlorine reading meant nothing, and we drained a third of it. First clear summer in three years.' },
  { name: 'Sam H.', town: 'Arcadia', text: 'She talked me down to the chemistry-only plan because I was already brushing. That is about a hundred dollars a month she chose not to take.' },
  { name: 'Bea T.', town: 'Gilbert', text: 'The log sheet is the thing. I can see what the water did over the summer instead of trusting that someone came.' },
  { name: 'Duane P.', town: 'Fountain Hills', text: 'Green pool after a monsoon week. Quoted the recovery honestly, told me it would take three visits, and it took three visits.' },
];

export const faqs = [
  { q: 'My chlorine tests fine but the pool went green. How?', a: 'Almost always cyanuric acid. CYA stabilises chlorine against sunlight, but above roughly 70–100 ppm it also binds it so tightly that the chlorine cannot sanitise. A strip shows chlorine present and the water is effectively unprotected. It is the single most common cause of a green pool with "good" numbers, and no chemical removes CYA — you dilute it.' },
  { q: 'Do I actually need weekly service?', a: 'In an Arizona summer, most pools do. In winter, most do not. If you test and log yourself, a quarterly check is often enough — see the section above, which exists because we would rather have you at the right plan than the expensive one.' },
  { q: 'Are test strips good enough?', a: 'For chlorine and pH, roughly. For alkalinity and CYA they are poor, and CYA is the one that matters most. A drop kit is more work and enormously more accurate.' },
  { q: 'Why does my pH keep climbing?', a: 'Usually total alkalinity is too high, which makes pH stubborn and upward-drifting. Chasing pH with acid while ignoring TA is the most common mistake we see, and it burns through a lot of acid to no effect.' },
  { q: 'What is a green-pool recovery?', a: 'Filter clean, a controlled chlorine hold, brushing, and usually two or three visits over a week. Anyone promising a single visit is going to hand the pool back and let it re-bloom.' },
  { q: 'Do you handle salt systems?', a: 'Yes. A salt cell is a chlorine generator, not an alternative to chlorine — the same six numbers apply, and cells scale badly in hard water, so they get inspected on every visit.' },
];
