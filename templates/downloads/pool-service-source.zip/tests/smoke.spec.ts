import { test, expect } from '@playwright/test';

test.describe('Meridian Pool Co. — smoke tests', () => {
  test('homepage renders with the business name in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Meridian Pool Co\./);
    await expect(page.locator('h1')).toContainText('Six numbers');
  });

  // The panel is built on real <meter> elements — the correct HTML for a value
  // inside a known range. If these degrade to divs the accessibility argument
  // for this template is gone, so the element and its attributes are asserted.
  test('the panel is built from real meter elements with proper bounds', async ({ page }) => {
    await page.goto('/');
    const meters = page.locator('#panel meter.gauge-meter');
    expect(await meters.count()).toBe(6);
    for (let i = 0; i < 6; i++) {
      const m = meters.nth(i);
      for (const attr of ['min', 'max', 'low', 'high', 'optimum', 'value']) {
        await expect(m).toHaveAttribute(attr, /.+/);
      }
    }
  });

  test('each meter value sits inside its own declared min and max', async ({ page }) => {
    await page.goto('/');
    const rows = await page.$$eval('#panel meter.gauge-meter', (ms) =>
      ms.map((m) => ({
        min: Number(m.getAttribute('min')),
        max: Number(m.getAttribute('max')),
        low: Number(m.getAttribute('low')),
        high: Number(m.getAttribute('high')),
        value: Number(m.getAttribute('value')),
      })),
    );
    for (const r of rows) {
      expect(r.min).toBeLessThan(r.low);
      expect(r.low).toBeLessThan(r.high);
      expect(r.high).toBeLessThan(r.max);
      expect(r.value).toBeGreaterThanOrEqual(r.min);
      expect(r.value).toBeLessThanOrEqual(r.max);
    }
  });

  // A panel where everything is green teaches nothing.
  test('the sample panel is not all-green, and the copy quotes the real count', async ({ page }) => {
    await page.goto('/');
    const out = await page.locator('#panel .gauge--high, #panel .gauge--low').count();
    expect(out).toBeGreaterThanOrEqual(2);
    await expect(page.locator('#panel')).toContainText(`${out} of the six readings below are out of band`);
  });

  test('every gauge states its band in words, not just colour', async ({ page }) => {
    await page.goto('/');
    for (const t of await page.locator('#panel .gauge-flag').allTextContents()) {
      expect(['In band', 'Below band', 'Above band']).toContain(t.trim());
    }
  });

  // The argument of the page: CYA is the reading that makes chlorine useless.
  test('the drift table names the cyanuric acid trap', async ({ page }) => {
    await page.goto('/');
    const rows = page.locator('#drift .rate-table tbody tr');
    expect(await rows.count()).toBe(6);
    await expect(page.locator('#drift')).toContainText(/CYA too high/i);
    await expect(page.locator('#drift')).toContainText(/no chemical that removes it/i);
  });

  // The section that costs the fictional business money.
  test('the page tells some visitors not to hire it', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#skip article').count()).toBe(3);
    await expect(page.locator('#skip')).toContainText(/drop-test kit/i);
  });

  test('plans show real monthly figures', async ({ page }) => {
    await page.goto('/');
    const cards = page.locator('#plans article');
    expect(await cards.count()).toBe(3);
    for (const t of await cards.allTextContents()) expect(t).toMatch(/\$\d/);
  });

  test('FAQ accordions expand', async ({ page }) => {
    await page.goto('/');
    const first = page.locator('#faq details').first();
    await first.click();
    await expect(first).toHaveAttribute('open', '');
  });

  test('booking form marks its required fields', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#phone', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
  });

  // Scaffolded from day 82.
  test('no trace of the day-82 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['kestrel', 'asheville', 'arborist', 'roman adebayo', 'traq']) {
      expect(html).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at 375px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const r = await page.evaluate(() => {
      window.scrollTo(9999, 0);
      const x = window.scrollX;
      window.scrollTo(0, 0);
      return { x, bodySW: document.body.scrollWidth, inner: window.innerWidth };
    });
    expect(r.x).toBe(0);
    expect(r.bodySW).toBeLessThanOrEqual(r.inner + 1);
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro chemistry guide is absent from the free build', async ({ page }) => {
    const res = await page.goto('/chemistry-guide/');
    expect(res?.status()).toBeLessThan(400);
    const html = await page.content();
    expect(html).not.toContain('Dosing, per 10,000 gallons');
    expect(html.toLowerCase()).toContain('refresh');
  });
});
