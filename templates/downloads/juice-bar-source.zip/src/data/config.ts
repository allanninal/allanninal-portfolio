// ============================================================
// Juice Bar — Day 41 · Pressed & Nourished
// Wellness juice bar: cold-pressed juices, smoothies, bowls, shots
// Palette: Citrus Orange + Leafy Green + Pure White
// Fonts: Urbanist Variable (display) + Geist (body)
// ============================================================

export const bar = {
  name: 'Pressed & Nourished',
  tagline: 'Cold-pressed. Whole-ingredient. Alive.',
  shortTagline: 'Small-batch juices, smoothies, and bowls made from real produce — nothing artificial, nothing processed.',
  description:
    'Pressed & Nourished is a wellness juice bar in Portland, Oregon. We cold-press every juice to order using certified organic produce, blend nutrient-dense smoothies, and craft açaí and grain bowls for fuel that lasts. No added sugar, no artificial flavours, no shortcuts.',
  address: '1428 NW 23rd Ave, Portland, OR 97210',
  phone: '+1 (503) 555-0184',
  email: 'hello@pressedandnourished.com',
  orderUrl: '#order',
  cleanseUrl: '#cleanse',
  instagram: 'https://instagram.com/pressednourished',
  facebook: 'https://facebook.com/pressednourished',
  tiktok: 'https://tiktok.com/@pressednourished',
  estYear: '2019',
  mapsUrl: 'https://maps.google.com/?q=1428+NW+23rd+Ave+Portland+OR',
};

// ─── Hours ───────────────────────────────────────────────────────────────────

export type HoursRow = {
  day: string;
  open: string;
  note?: string;
};

export const hours: HoursRow[] = [
  { day: 'Mon–Fri',  open: '7:00 AM – 6:00 PM',  note: 'Early morning cold-press ready by 7 AM' },
  { day: 'Saturday', open: '8:00 AM – 5:00 PM',  note: 'Weekly farmers-market blend specials' },
  { day: 'Sunday',   open: '9:00 AM – 4:00 PM',  note: 'Slow start, good vibes' },
];

// ─── Menu ─────────────────────────────────────────────────────────────────────

export type MenuTag =
  | 'detox'
  | 'immunity'
  | 'energy'
  | 'anti-inflammatory'
  | 'gut-health'
  | 'hydration'
  | 'vegan'
  | 'gluten-free'
  | 'nut-free'
  | 'bestseller'
  | 'new'
  | 'raw';

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  ingredients: string[];
  price: string;
  size?: string;
  tags?: MenuTag[];
  kcal?: number;
};

export type MenuCategory = {
  id: string;
  label: string;
  icon: string;
  description: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: 'cold-pressed',
    label: 'Cold-Pressed Juices',
    icon: '🍊',
    description: 'Hydraulic cold-pressed to preserve enzymes and micronutrients. Bottled to order, never HPP.',
    items: [
      {
        id: 'green-sunrise',
        name: 'Green Sunrise',
        description: 'Our flagship: cucumber, romaine, kale, green apple, lemon, ginger. Bright, clean, grassy.',
        ingredients: ['Cucumber', 'Romaine', 'Kale', 'Green Apple', 'Lemon', 'Ginger'],
        price: '$9.50',
        size: '16 oz',
        tags: ['detox', 'vegan', 'raw', 'bestseller'],
        kcal: 110,
      },
      {
        id: 'citrus-surge',
        name: 'Citrus Surge',
        description: 'Blood orange, navel orange, pink grapefruit, Meyer lemon, turmeric. Vitamin C overload.',
        ingredients: ['Blood Orange', 'Navel Orange', 'Grapefruit', 'Meyer Lemon', 'Turmeric'],
        price: '$9.00',
        size: '16 oz',
        tags: ['immunity', 'anti-inflammatory', 'vegan', 'raw'],
        kcal: 130,
      },
      {
        id: 'beet-revival',
        name: 'Beet Revival',
        description: 'Red beet, carrot, apple, ginger, cayenne. Earthy sweetness with a slow-building heat.',
        ingredients: ['Red Beet', 'Carrot', 'Apple', 'Ginger', 'Cayenne'],
        price: '$9.50',
        size: '16 oz',
        tags: ['energy', 'anti-inflammatory', 'vegan', 'raw', 'bestseller'],
        kcal: 125,
      },
      {
        id: 'watermelon-mint',
        name: 'Watermelon Mint',
        description: 'Cold-pressed watermelon, cucumber, fresh mint, lime. Summer in a bottle.',
        ingredients: ['Watermelon', 'Cucumber', 'Fresh Mint', 'Lime'],
        price: '$8.50',
        size: '16 oz',
        tags: ['hydration', 'vegan', 'raw', 'new'],
        kcal: 95,
      },
      {
        id: 'golden-hour',
        name: 'Golden Hour',
        description: 'Pineapple, mango, fresh turmeric, black pepper, coconut water. Anti-inflammatory sunshine.',
        ingredients: ['Pineapple', 'Mango', 'Fresh Turmeric', 'Black Pepper', 'Coconut Water'],
        price: '$10.00',
        size: '16 oz',
        tags: ['anti-inflammatory', 'vegan', 'raw'],
        kcal: 145,
      },
      {
        id: 'dark-greens',
        name: 'Dark Greens',
        description: 'Spinach, celery, parsley, green apple, lemon. The no-compromise green.',
        ingredients: ['Spinach', 'Celery', 'Parsley', 'Green Apple', 'Lemon'],
        price: '$9.00',
        size: '16 oz',
        tags: ['detox', 'vegan', 'raw'],
        kcal: 90,
      },
    ],
  },
  {
    id: 'smoothies',
    label: 'Smoothies',
    icon: '🥤',
    description: 'Whole-blended for fibre and staying power. Real fruit, no syrup, no ice cream. Protein optional.',
    items: [
      {
        id: 'tropic-thunder',
        name: 'Tropic Thunder',
        description: 'Mango, pineapple, banana, coconut milk, lime, toasted coconut. A weekend in Hawaii.',
        ingredients: ['Mango', 'Pineapple', 'Banana', 'Coconut Milk', 'Lime', 'Toasted Coconut'],
        price: '$11.00',
        size: '20 oz',
        tags: ['energy', 'vegan', 'gluten-free', 'bestseller'],
        kcal: 310,
      },
      {
        id: 'berry-boost',
        name: 'Berry Boost',
        description: 'Wild blueberry, strawberry, raspberry, banana, oat milk, flaxseed, vanilla. Antioxidant bomb.',
        ingredients: ['Wild Blueberry', 'Strawberry', 'Raspberry', 'Banana', 'Oat Milk', 'Flaxseed'],
        price: '$11.50',
        size: '20 oz',
        tags: ['immunity', 'vegan', 'bestseller'],
        kcal: 295,
      },
      {
        id: 'green-goddess',
        name: 'Green Goddess',
        description: 'Spinach, banana, mango, almond milk, hemp seeds, spirulina. Earthy, tropical, protein-forward.',
        ingredients: ['Spinach', 'Banana', 'Mango', 'Almond Milk', 'Hemp Seeds', 'Spirulina'],
        price: '$12.00',
        size: '20 oz',
        tags: ['detox', 'energy', 'vegan', 'gluten-free'],
        kcal: 340,
      },
      {
        id: 'pb-banana',
        name: 'PB Power',
        description: 'Banana, natural peanut butter, oat milk, Medjool dates, cacao nibs. Fuel for a long day.',
        ingredients: ['Banana', 'Natural Peanut Butter', 'Oat Milk', 'Medjool Dates', 'Cacao Nibs'],
        price: '$12.50',
        size: '20 oz',
        tags: ['energy', 'vegan', 'bestseller'],
        kcal: 420,
      },
    ],
  },
  {
    id: 'bowls',
    label: 'Bowls',
    icon: '🥣',
    description: 'Açaí, pitaya, and grain bases loaded with house-made granola, seasonal fruit, and functional toppings.',
    items: [
      {
        id: 'acai-classic',
        name: 'Açaí Classic',
        description: 'Organic açaí, wild blueberry, banana base. Coconut flakes, house granola, sliced banana, honey drizzle.',
        ingredients: ['Organic Açaí', 'Wild Blueberry', 'Banana', 'Coconut Flakes', 'House Granola', 'Honey'],
        price: '$13.50',
        tags: ['immunity', 'vegan', 'bestseller'],
        kcal: 410,
      },
      {
        id: 'pitaya-power',
        name: 'Pitaya Power',
        description: 'Pink dragon fruit, mango, pineapple. Crunchy seed granola, kiwi, mango chunks, chia.',
        ingredients: ['Pitaya', 'Mango', 'Pineapple', 'Seed Granola', 'Kiwi', 'Chia Seeds'],
        price: '$14.00',
        tags: ['energy', 'anti-inflammatory', 'vegan', 'new'],
        kcal: 380,
      },
      {
        id: 'green-bowl',
        name: 'Green Machine Bowl',
        description: 'Spinach, pineapple, banana, coconut base. Hemp seeds, fresh berries, drizzle of almond butter.',
        ingredients: ['Spinach', 'Pineapple', 'Banana', 'Coconut Milk', 'Hemp Seeds', 'Almond Butter'],
        price: '$13.00',
        tags: ['detox', 'gut-health', 'vegan', 'gluten-free'],
        kcal: 360,
      },
      {
        id: 'quinoa-fuel',
        name: 'Quinoa Fuel Bowl',
        description: 'Warm quinoa, roasted sweet potato, avocado, edamame, radish, lemon-tahini, pumpkin seeds.',
        ingredients: ['Quinoa', 'Sweet Potato', 'Avocado', 'Edamame', 'Radish', 'Lemon-Tahini', 'Pumpkin Seeds'],
        price: '$14.50',
        tags: ['energy', 'gut-health', 'vegan', 'gluten-free'],
        kcal: 490,
      },
    ],
  },
  {
    id: 'shots',
    label: 'Wellness Shots',
    icon: '💉',
    description: '2 oz concentrated boosts. Taken solo or added to any juice or smoothie.',
    items: [
      {
        id: 'ginger-fire',
        name: 'Ginger Fire',
        description: 'Fresh ginger, lemon, cayenne. Clears sinuses, fires up metabolism.',
        ingredients: ['Fresh Ginger', 'Lemon', 'Cayenne'],
        price: '$3.50',
        size: '2 oz',
        tags: ['immunity', 'anti-inflammatory', 'vegan', 'raw', 'bestseller'],
        kcal: 15,
      },
      {
        id: 'turmeric-gold',
        name: 'Turmeric Gold',
        description: 'Fresh turmeric, ginger, black pepper, orange, coconut oil. Curcumin absorption maximised.',
        ingredients: ['Fresh Turmeric', 'Ginger', 'Black Pepper', 'Orange', 'Coconut Oil'],
        price: '$3.50',
        size: '2 oz',
        tags: ['anti-inflammatory', 'vegan', 'raw'],
        kcal: 25,
      },
      {
        id: 'wheatgrass',
        name: 'Wheatgrass Pure',
        description: 'Fresh-cut wheatgrass pressed to order. 30+ vitamins and minerals in one ounce.',
        ingredients: ['Fresh Wheatgrass'],
        price: '$4.00',
        size: '2 oz',
        tags: ['detox', 'vegan', 'raw'],
        kcal: 10,
      },
      {
        id: 'aloe-calm',
        name: 'Aloe Calm',
        description: 'Cold-pressed aloe vera, cucumber, mint. Soothes gut lining, reduces inflammation.',
        ingredients: ['Aloe Vera', 'Cucumber', 'Mint'],
        price: '$3.50',
        size: '2 oz',
        tags: ['gut-health', 'hydration', 'vegan', 'raw'],
        kcal: 8,
      },
    ],
  },
];

// ─── Cleanse Programs ─────────────────────────────────────────────────────────

export type CleanseProgram = {
  id: string;
  name: string;
  duration: string;
  description: string;
  includes: string[];
  price: string;
  popular?: boolean;
};

export const cleanseProgrammes: CleanseProgram[] = [
  {
    id: 'reset-1day',
    name: '1-Day Reset',
    duration: '1 Day · 6 juices',
    description: 'A gentle introduction. Ideal after a heavy weekend or as a monthly ritual.',
    includes: [
      '6 cold-pressed juices (morning to evening sequence)',
      'Ginger Fire wellness shot',
      'Digital cleanse guide',
    ],
    price: '$54',
  },
  {
    id: 'reboot-3day',
    name: '3-Day Reboot',
    duration: '3 Days · 18 juices',
    description: 'Our most popular cleanse. Detox, re-hydrate, and reset your relationship with food.',
    includes: [
      '18 cold-pressed juices',
      '3 Turmeric Gold shots',
      'Morning wheatgrass shot each day',
      'Digital meal guide for post-cleanse',
      'Pre-cleanse prep plan',
    ],
    price: '$149',
    popular: true,
  },
  {
    id: 'transform-5day',
    name: '5-Day Transform',
    duration: '5 Days · 30 juices + bowls',
    description: 'The full reboot. Juices, shots, and one nourishing bowl per day for sustainable energy.',
    includes: [
      '30 cold-pressed juices',
      '5 wellness shots (rotating)',
      '5 Green Machine bowls',
      'Dedicated nutritionist check-in call',
      '14-day post-cleanse eating plan',
    ],
    price: '$239',
  },
];

// ─── Ingredients / Sourcing ───────────────────────────────────────────────────

export type IngredientSource = {
  ingredient: string;
  farm: string;
  location: string;
  note: string;
  certified: string;
};

export const sourcingPartners: IngredientSource[] = [
  {
    ingredient: 'Leafy Greens & Herbs',
    farm: 'Sauvie Island Organics',
    location: 'Sauvie Island, OR',
    note: 'Kale, spinach, parsley, basil, mint — harvested same morning, delivered by 6 AM.',
    certified: 'USDA Organic',
  },
  {
    ingredient: 'Citrus',
    farm: 'Homegrown Organic Farms',
    location: 'Porterville, CA',
    note: 'Navel, blood orange, grapefruit, Meyer lemon — peak-season only, no off-season citrus.',
    certified: 'USDA Organic',
  },
  {
    ingredient: 'Tropical Fruit',
    farm: 'Pacific Produce Co-op',
    location: 'Portland, OR (distributed)',
    note: 'Mango, pineapple, banana, papaya — direct from co-op growers in Ecuador and Costa Rica.',
    certified: 'Fair Trade',
  },
  {
    ingredient: 'Root Vegetables',
    farm: 'Nash Farm',
    location: 'Canby, OR',
    note: 'Beets, carrots, turmeric, ginger — biodynamic soil, no synthetic inputs.',
    certified: 'Demeter Biodynamic',
  },
  {
    ingredient: 'Açaí',
    farm: 'Sambazon',
    location: 'Amazônia, Brazil',
    note: 'Wild-harvested, flash-frozen. Carbon-neutral supply chain, rainforest protection programme.',
    certified: 'Fair Trade · Organic',
  },
  {
    ingredient: 'Wheatgrass',
    farm: 'Indoor Sun Shoppe',
    location: 'Portland, OR',
    note: 'Grown in trays on-premises. Cut fresh daily — shortest possible farm-to-press.',
    certified: 'Spray-free',
  },
];

// ─── Our Story ────────────────────────────────────────────────────────────────

export const story = {
  headline: 'From Burnout to a Bar Counter',
  founderName: 'Maya Chen',
  founderTitle: 'Founder & Head Nutritionist',
  bio: [
    'Maya spent a decade in corporate consulting in San Francisco — 80-hour weeks, caffeine-fuelled sprints, and a body that was barely keeping up. A health scare in 2017 sent her to a functional medicine doctor who prescribed one thing: real food.',
    'The transformation was so dramatic that Maya trained as a certified nutritionist, relocated to Portland, and opened the first Pressed & Nourished counter in a converted garage in the Alphabet District in 2019. The idea was simple: make the most nutritionally dense food on earth taste like something you\'d crave.',
    'Today the bar serves over 400 people a day, has a loyal cleanse programme with hundreds of repeat customers, and sources 100% of its produce from certified organic and biodynamic farms within 300 miles.',
  ],
  stats: [
    { label: 'Opened',           value: '2019' },
    { label: 'Organic farms',    value: '6' },
    { label: 'Juices cold-pressed daily', value: '300+' },
    { label: 'Cleanse regulars', value: '800+' },
  ],
};

// ─── Gallery ──────────────────────────────────────────────────────────────────

export const gallery = [
  { alt: 'Rows of freshly cold-pressed green juice bottles lined up on a stainless steel counter, morning light streaming in', label: 'Morning press', src: 'bottles' },
  { alt: 'Hands holding a vibrant orange citrus surge juice against a white wall, glistening condensation on the glass', label: 'Citrus Surge', src: 'citrus' },
  { alt: 'An açaí bowl topped with granola, sliced banana, kiwi, and a drizzle of honey on a light wooden surface', label: 'Açaí Classic', src: 'acai' },
  { alt: 'A flat lay of fresh ginger, turmeric root, lemons, and cayenne peppers on a white marble surface', label: 'Our ingredients', src: 'ingredients' },
  { alt: 'A vibrant fresh juice being poured into a glass to order at the bar', label: 'Made to order', src: 'prep' },
  { alt: 'The exterior of Pressed & Nourished on NW 23rd Ave, glass frontage with plants, warm morning light', label: 'NW 23rd Ave', src: 'exterior' },
];

// ─── Maker ────────────────────────────────────────────────────────────────────

export const maker = {
  name: 'Allan Ninal',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  twitter: 'https://twitter.com/allanninal',
  github: 'https://github.com/allanninal',
  email: 'landix.ninal@gmail.com',
  kofi: 'https://ko-fi.com/allanninal',
};

// ─── Site Meta ────────────────────────────────────────────────────────────────

export const site = {
  title: 'Pressed & Nourished — Cold-Pressed Juice Bar, Portland OR',
  description:
    'Portland\'s favourite cold-pressed juice bar. Small-batch juices, smoothies, açaí bowls, wellness shots, and cleanse programmes — 100% organic, made fresh daily on NW 23rd Ave.',
  url: 'https://templates.allanninal.dev/juice-bar/',
  ogImage: '/og-image.png',
  language: 'en',
};
