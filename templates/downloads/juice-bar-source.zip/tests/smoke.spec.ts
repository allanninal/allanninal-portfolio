import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Pressed & Nourished/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('menu section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible();
});

test('menu has tab buttons', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(3);
});

test('menu tab switching works', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('[role="tab"]');
  // Click second tab
  await tabs.nth(1).click();
  const secondTab = tabs.nth(1);
  await expect(secondTab).toHaveAttribute('aria-selected', 'true');
});

test('cleanse section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#cleanse')).toBeVisible();
});

test('cleanse has pricing cards', async ({ page }) => {
  await page.goto('/');
  const cards = page.locator('#cleanse article');
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
});

test('sourcing section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#sourcing')).toBeVisible();
});

test('story section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#story')).toBeVisible();
});

test('location section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#location')).toBeVisible();
});

test('order CTA section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#order')).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  // Use aria-label to avoid strict mode violation (desktop + mobile nav both in DOM)
  const nav = page.getByRole('navigation', { name: 'Primary navigation' });
  await expect(nav).toBeAttached();
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const templateInfo = page.locator(
    process.env.PUBLIC_EDITION === 'pro'
      ? '[aria-label="Pro edition — live preview"]'
      : '[aria-label="Free template — download or fork"]'
  );
  await expect(templateInfo).toBeVisible();
});

test('phone link in footer is present', async ({ page }) => {
  await page.goto('/');
  const phoneLink = page.locator('a[href^="tel:"]');
  await expect(phoneLink.first()).toBeVisible();
});

test('LinkedIn contact link exists in page', async ({ page }) => {
  await page.goto('/');
  const linkedinLinks = page.locator('a[href*="linkedin.com"]');
  expect(await linkedinLinks.count()).toBeGreaterThanOrEqual(1);
});

test('mobile menu toggle works', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/');
  const toggle = page.locator('#mobile-menu-toggle');
  await toggle.click();
  const mobileMenu = page.locator('#mobile-menu');
  await expect(mobileMenu).toBeVisible();
});
