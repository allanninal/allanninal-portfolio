import { test, expect } from '@playwright/test';

const isPro = process.env.PUBLIC_EDITION === 'pro';
const BAR = isPro
  ? '[aria-label="Pro edition — live preview"]'
  : '[aria-label="Free template — download or fork"]';

test('TemplateInfo shows the right buttons when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const aside = page.locator(BAR);
  await expect(aside).toBeVisible();

  // Static download present in both editions ("Download static" / "Download free").
  const downloadStatic = aside.locator('a[download]').filter({
    hasText: isPro ? 'Download free' : 'Download static',
  });
  await expect(downloadStatic).toBeVisible();

  // "All 365" gallery link
  await expect(aside.locator('a', { hasText: 'All 365' })).toBeVisible();

  // LinkedIn link — "Build with me" (free) / "Get Pro static" (pro)
  const linkedin = aside.locator('a', { hasText: isPro ? 'Get Pro static' : 'Build with me' });
  await expect(linkedin).toBeVisible();
  expect(await linkedin.getAttribute('href')).toContain('linkedin.com');

  if (!isPro) {
    await expect(
      aside.locator('a[download]').filter({ hasText: 'Source (Astro)' })
    ).toBeVisible();
  }
});

test('TemplateInfo static zip URL contains juice-bar slug', async ({ page }) => {
  await page.goto('/');
  const aside = page.locator(BAR);
  const staticLink = aside.locator('a[download]').filter({
    hasText: isPro ? 'Download free' : 'Download static',
  });
  const href = await staticLink.getAttribute('href');
  expect(href).toContain('juice-bar-static.zip');
});

test('TemplateInfo source zip URL contains juice-bar slug (free only)', async ({ page }) => {
  test.skip(isPro, 'Pro bar does not expose the source zip');
  await page.goto('/');
  const aside = page.locator(BAR);
  const sourceLink = aside.locator('a[download]').filter({ hasText: 'Source (Astro)' });
  const href = await sourceLink.getAttribute('href');
  expect(href).toContain('juice-bar-source.zip');
});

test('No github.com/allanninal/templates links in rendered page', async ({ page }) => {
  await page.goto('/');
  const badLinks = page.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
