import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { ROUTES, setTheme } from './helpers';

for (const route of ROUTES) {
  // Light-only template — only test light mode
  for (const theme of ['light'] as const) {
    test(`a11y ${route} (${theme})`, async ({ page }) => {
      await page.goto(route);
      await setTheme(page, theme);
      const results = await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .analyze();
      expect(
        results.violations,
        `A11y violations on ${route} (${theme}):\n${JSON.stringify(results.violations, null, 2)}`
      ).toEqual([]);
    });
  }
}
