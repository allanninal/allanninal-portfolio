# Juice Bar — Day 41 of 365

**Pressed & Nourished** — a wellness juice bar template built with Astro and Tailwind CSS.

Live demo: [templates.allanninal.dev/juice-bar/](https://templates.allanninal.dev/juice-bar/)

## What's included

- **Vibrant wellness hero** — split layout with SVG juice bottle illustration, headline, stats, and CTAs
- **Scrolling benefits marquee** — 100% Organic · Cold-Pressed Daily · No Added Sugar
- **Tabbed menu** — 4 categories (Cold-Pressed Juices / Smoothies / Bowls / Shots) with prices, ingredient chips, and benefit tags (Detox / Immunity / Energy / Anti-Inflammatory / Gut Health / Hydration)
- **Cleanse programmes** — 3-tier pricing cards (1-Day Reset / 3-Day Reboot / 5-Day Transform)
- **Sourcing section** — 6 farm partners with certification badges (USDA Organic / Fair Trade / Biodynamic)
- **Gallery** — 6-image grid with accessible captions
- **Founder story** — narrative bio with SVG illustration
- **Location & hours** — address, phone, email, Google Maps link
- **Order CTA** — call / email / cleanse booking

## Design

- **Palette**: Leafy Green (#1D6B1D) + Citrus Orange (#B53500) + Pure White (#FEFFFE)
- **Fonts**: Urbanist Variable (display) + Geist (body)
- **Mode**: Light-only
- **All WCAG 2.1 AA** contrast ratios verified (min 4.5:1)

## Tech stack

- [Astro](https://astro.build) 4.x
- [Tailwind CSS](https://tailwindcss.com) 3.x
- [Urbanist Variable](https://fontsource.org/fonts/urbanist) + [Geist](https://vercel.com/font) via `@fontsource`
- Zero runtime frameworks — pure static HTML
- `schema.org` `FoodEstablishment` + `Menu` JSON-LD

## Getting started

```bash
npm install
npm run dev
```

## Environment variables

| Variable | Purpose |
|----------|---------|
| `PUBLIC_SITE_URL` | Canonical site URL (default: `https://templates.allanninal.dev`) |
| `PUBLIC_BASE_PATH` | Astro base path for sub-directory deploys (default: `/juice-bar/`) |
| `PUBLIC_TEMPLATE_HUB_URL` | Hub URL — enables download bar and analytics (leave blank for self-hosted clones) |

## Customize

Edit `src/data/config.ts` to change the business name, address, hours, menu items, cleanse programmes, sourcing partners, founder story, and gallery.

## License

MIT — see [LICENSE](./LICENSE).

Built by [Allan Niñal](https://www.linkedin.com/in/allanninal/) · Day 41 of the [365-template roadmap](https://templates.allanninal.dev).
