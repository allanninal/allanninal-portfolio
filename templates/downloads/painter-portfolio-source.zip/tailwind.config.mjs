/** @type {import('tailwindcss').Config} */
// No custom colour ramps are declared here on purpose. Every colour in this
// template lives as a CSS custom property in src/styles/global.css, so there
// is no way to write a `text-linen-200` utility for a shade the palette never
// defines (KNOWN_DEFECTS §8) — the class simply would not exist to be written.
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {},
  },
  plugins: [],
};
