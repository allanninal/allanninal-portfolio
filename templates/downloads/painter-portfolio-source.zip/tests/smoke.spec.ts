import { test, expect } from '@playwright/test';

test.describe('Teresa Ibarra — smoke tests', () => {
  test('the page leads with the size claim, not a photo', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Teresa Ibarra/);
    await expect(page.locator('h1')).toContainText(/122.*91.*cm/i);
    expect(await page.locator('img, picture').count()).toBe(0);
  });

  // ── The rooms ────────────────────────────────────────────────────────────
  test('three rooms, each a labelled, keyboard-reachable scroll region', async ({ page }) => {
    await page.goto('/');
    const rooms = page.locator('.room-scroll');
    expect(await rooms.count()).toBe(3);
    for (let i = 0; i < 3; i++) {
      const room = rooms.nth(i);
      await expect(room).toHaveAttribute('role', 'region');
      await expect(room).toHaveAttribute('tabindex', '0');
      const label = await room.getAttribute('aria-label');
      expect(label, `room ${i} has no accessible name`).toBeTruthy();
      expect(label).toMatch(/room — scroll to see every painting to true scale/i);
    }
  });

  test('every room draws a 170 cm figure and the 145 cm hang-line', async ({ page }) => {
    await page.goto('/');
    const svgs = page.locator('.room-scroll svg');
    expect(await svgs.count()).toBe(3);
    for (let i = 0; i < 3; i++) {
      const svg = svgs.nth(i);
      expect(await svg.locator('circle').count()).toBeGreaterThanOrEqual(1);
      const svgText = (await svg.evaluate((el) => el.textContent || '')).toLowerCase();
      expect(svgText).toContain('145 cm hang-line');
      expect(svgText).toContain('170 cm');
    }
  });

  // The whole point of the axis: the drawing and the table are generated from
  // the same per-painting data, so the number of rectangles drawn in a room
  // must equal the number of that room's rows in the Ready-to-ship table.
  test('the rectangles drawn per room match the rows in the ready-to-ship table', async ({ page }) => {
    await page.goto('/');
    const roomNames = await page.locator('.room-figcaption h3').allTextContents();
    expect(roomNames).toEqual(['Low Tide', 'Kitchen Table', 'Fog Studies']);

    const rectCounts: number[] = [];
    const svgs = page.locator('.room-scroll svg');
    for (let i = 0; i < 3; i++) {
      const rects = await svgs.nth(i).locator('rect.rect-available, rect.rect-preorder, rect.rect-print-only').count();
      rectCounts.push(rects);
    }

    const tableRows = await page.locator('#ready-to-ship tbody tr').count();
    expect(rectCounts.reduce((a, b) => a + b, 0)).toBe(tableRows);

    // Column 1 is the <th scope="row"> painting title; column 2 (first <td>) is the series.
    const seriesCol = await page.locator('#ready-to-ship tbody tr > td:nth-child(2)').allTextContents();
    for (let i = 0; i < 3; i++) {
      const count = seriesCol.filter((s) => s === roomNames[i]).length;
      expect(count, `${roomNames[i]} rect/row mismatch`).toBe(rectCounts[i]);
    }
  });

  test('the largest and smallest named paintings are exactly where the brief says', async ({ page }) => {
    await page.goto('/');
    const row12 = page.locator('#ready-to-ship tbody tr', { hasText: 'Low Tide No. 12' });
    await expect(row12).toContainText('122');
    await expect(row12).toContainText('91');

    const row27 = page.locator('#ready-to-ship tbody tr', { hasText: 'Fog Study 27' });
    await expect(row27).toContainText('18');
    await expect(row27).toContainText('13');
  });

  test('every finished painting appears exactly once in the ready-to-ship table', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#ready-to-ship tbody tr').count();
    // 15 Low Tide + 9 Kitchen Table + 19 Fog Studies = 43, per RESEARCH.md.
    expect(rows).toBe(43);
    await expect(page.locator('#ready-to-ship caption')).toContainText('43 finished paintings');
  });

  test('status vocabulary is exactly Available, a Ships-after date, or Print only', async ({ page }) => {
    await page.goto('/');
    const statuses = await page.locator('#ready-to-ship tbody tr td.status-available, #ready-to-ship tbody tr td.status-preorder, #ready-to-ship tbody tr td.status-print-only').allTextContents();
    expect(statuses.length).toBe(43);
    for (const s of statuses) {
      expect(s).toMatch(/^Available$|^Ships after [A-Z][a-z]{2} \d{1,2}, \d{4}$|^Print only$/);
    }
    // All three states actually occur — this is not a table that only ever says one thing.
    expect(statuses.some((s) => s === 'Available')).toBe(true);
    expect(statuses.some((s) => /^Ships after/.test(s))).toBe(true);
    expect(statuses.some((s) => s === 'Print only')).toBe(true);
  });

  // ── Pigments ─────────────────────────────────────────────────────────────
  test('five pigments, and the two fugitive ones show a fade pair', async ({ page }) => {
    await page.goto('/');
    const rows = await page.locator('#pigments table tbody tr').count();
    expect(rows).toBe(5);

    const figures = page.locator('#pigments .pigment-figure:not(.cure-clock-figure)');
    expect(await figures.count()).toBe(5);

    const rectCounts = await figures.evaluateAll((figs) => figs.map((f) => f.querySelectorAll('svg rect').length));
    // Exactly two figures show a fade pair (2 rects); the rest show one stable chip.
    expect(rectCounts.filter((n) => n === 2).length).toBe(2);
    expect(rectCounts.filter((n) => n === 1).length).toBe(3);

    const bodyText = await page.locator('#pigments').innerText();
    expect(bodyText).toContain('Alizarin Crimson (genuine)');
    expect(bodyText).toContain('Sap Green (genuine)');
    expect(bodyText).toMatch(/1994/);
  });

  test('the cure clock states real month counts, not just a curve', async ({ page }) => {
    await page.goto('/');
    const text = await page.locator('#pigments').innerText();
    expect(text).toMatch(/2 mo/);
    expect(text).toMatch(/6 mo/);
    expect(text).toMatch(/2 yrs/);
  });

  // ── Schema ──────────────────────────────────────────────────────────────
  test('every VisualArtwork withholds image, and offers are computed correctly', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const artworkBlock = blocks.find((b) => b.includes('"VisualArtwork"'))!;
    const artworks = JSON.parse(artworkBlock)['@graph'];
    expect(artworks.length).toBe(43);
    for (const a of artworks) {
      expect(a.image).toBeUndefined();
      expect(a.width.unitCode).toBe('CMT');
      expect(a.height.unitCode).toBe('CMT');
    }
    // "Print only" paintings carry no Offer at all — nothing settled to assert.
    const printOnly = artworks.filter((a: any) => !a.offers);
    expect(printOnly.length).toBe(5);

    const preorder = artworks.filter((a: any) => a.offers?.availability === 'https://schema.org/PreOrder');
    expect(preorder.length).toBeGreaterThan(0);
    for (const a of preorder) {
      expect(a.offers.availabilityStarts).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(typeof a.offers.price).toBe('number');
    }

    const inStock = artworks.filter((a: any) => a.offers?.availability === 'https://schema.org/InStock');
    expect(inStock.length).toBeGreaterThan(0);

    const all = blocks.join('');
    expect(all).not.toContain('aggregateRating');
  });

  test('every print Product is InStock at a fixed price, regardless of the original', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) => e.map((x) => x.textContent || ''));
    const productBlock = blocks.find((b) => b.includes('"Product"'))!;
    const products = JSON.parse(productBlock)['@graph'];
    expect(products.length).toBe(43);
    for (const p of products) {
      expect(p.offers.length).toBe(3);
      for (const o of p.offers) {
        expect(o.availability).toBe('https://schema.org/InStock');
        expect(typeof o.price).toBe('number');
      }
    }
  });

  // ── Prints & commission ──────────────────────────────────────────────────
  test('the prints dl states paper, ink, display life and three fixed sizes', async ({ page }) => {
    await page.goto('/');
    const terms = await page.locator('#prints dl dt').allTextContents();
    expect(terms.length).toBe(6);
    expect(terms[0]).toBe('Paper');
    expect(terms[1]).toBe('Ink');
    expect(terms[2]).toBe('Display life');
    for (const t of terms.slice(3)) expect(t).toMatch(/\$\d+/);
  });

  test('the commission form asks what kind of request this is', async ({ page }) => {
    await page.goto('/');
    for (const id of ['#name', '#email', '#request-type', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#print-size option').count()).toBe(4); // "not requesting" + 3 sizes
  });

  test('contact leads with LinkedIn, email second', async ({ page }) => {
    await page.goto('/');
    const cta = page.locator('.contact-cta');
    const linkedin = cta.getByRole('link', { name: /LinkedIn/i });
    const email = cta.getByRole('link', { name: /@/ });
    await expect(linkedin).toHaveAttribute('href', /linkedin\.com/);
    await expect(email).toHaveAttribute('href', /^mailto:/);
    // LinkedIn is visually and structurally first.
    const hrefs = await cta.locator('a').evaluateAll((as) => as.map((a) => a.getAttribute('href') || ''));
    expect(hrefs[0]).toMatch(/linkedin\.com/);
  });

  // DonateButton (src/components/DonateButton.astro) is the canonical
  // shared-ui component copied verbatim from saas-landing: it renders
  // nothing when its url prop resolves empty. The Playwright webServer env
  // in playwright.config.ts does not set PUBLIC_AUTHOR_DONATE_URL, so this
  // run exercises the "blank" branch; the "set" branch is exercised by the
  // component's own conditional (`visible = !!donateUrl`), unchanged from
  // the shared implementation used across the library.
  test('the footer donate attribution renders nothing when PUBLIC_AUTHOR_DONATE_URL is blank', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('footer .donate-attribution').count()).toBe(0);
  });

  // ── Hygiene ─────────────────────────────────────────────────────────────
  test('no trace of the day-129 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['tessa', 'wardlow', 'calligraph', 'charleston', 'envelope']) {
      expect(html, `day-129 copy survived: ${noun}`).not.toContain(noun);
    }
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    test.setTimeout(120_000);
    for (const w of [1440, 1280, 1080, 900, 700, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('the room region can be reached and scrolled from the keyboard', async ({ page }) => {
    await page.goto('/');
    const room = page.locator('.room-scroll').first();
    await room.focus();
    await expect(room).toBeFocused();
    const before = await room.evaluate((el) => el.scrollLeft);
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(150);
    const after = await room.evaluate((el) => el.scrollLeft);
    expect(after).toBeGreaterThanOrEqual(before);
  });

  test('the /design/ reference page is noindex and documents the accent decision', async ({ page }) => {
    const res = await page.goto('/design/');
    expect(res?.status()).toBe(200);
    const robots = await page.locator('meta[name="robots"]').getAttribute('content');
    expect(robots).toContain('noindex');
    await expect(page.locator('main')).toContainText(/portrait-photographer/i);
  });

  // The condition-report page is Pro-only. In the free build it must not be
  // reachable as real content — Astro.redirect() renders it as a meta-refresh
  // stub — and it must not be linked from the homepage (the isPro && (...)
  // discovery link in index.astro renders nothing when isPro is false).
  test('the Pro condition report is absent from the free build', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('a[href*="condition-report"]').count()).toBe(0);

    const res = await page.goto('/condition-report/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
