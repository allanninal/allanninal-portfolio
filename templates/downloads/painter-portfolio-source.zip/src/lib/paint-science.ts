// The oil clock and the true-size math, in one place, so the room canvas and
// the ready-to-ship table are computed from the same functions and cannot
// quietly disagree with each other. See RESEARCH.md §"The axis".

export type DryingCategoryId = 'lean' | 'standard' | 'impasto';

export type DryingCategory = {
  id: DryingCategoryId;
  months: number;
  label: string;
  note: string;
};

// Minimum cure months before an oil painting of that build can safely be
// varnished, per the standard six-month rule and its stated exceptions.
// Sources: paintingbestpractices.com, MontCarta, Will Kemp Art School — see
// RESEARCH.md for citations.
export const DRYING_CATEGORIES: Record<DryingCategoryId, DryingCategory> = {
  lean: {
    id: 'lean',
    months: 2,
    label: 'Thin, lean layers',
    note: 'A single thin, lean pass — the fastest an oil film cures.',
  },
  standard: {
    id: 'standard',
    months: 6,
    label: 'Standard alla-prima layering',
    note: 'The general rule: a painting of ordinary thickness, minimum six months before varnishing.',
  },
  impasto: {
    id: 'impasto',
    months: 24,
    label: 'Thick impasto',
    note: 'Thick, built-up passages — up to two years for the full paint film to cure through, not just the surface.',
  },
};

export function addMonthsUTC(iso: string, months: number): Date {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() + months);
  return d;
}

export function formatDate(d: Date): string {
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' });
}

export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export type ShipStatusCode = 'available' | 'preorder' | 'print-only';

export type ShipStatus = {
  code: ShipStatusCode;
  label: string;
  varnishReady: Date;
  varnishReadyIso: string;
};

/** The one function both the ready-to-ship table and the schema.org Offer
 *  read from. `forSale` false means the original itself is not for sale at
 *  any date — only a print exists — independent of cure state. */
export function computeShipStatus(
  completedIso: string,
  category: DryingCategoryId,
  forSale: boolean,
  today: Date = new Date(),
): ShipStatus {
  const varnishReady = addMonthsUTC(completedIso, DRYING_CATEGORIES[category].months);
  if (!forSale) {
    return { code: 'print-only', label: 'Print only', varnishReady, varnishReadyIso: isoDate(varnishReady) };
  }
  if (today.getTime() >= varnishReady.getTime()) {
    return { code: 'available', label: 'Available', varnishReady, varnishReadyIso: isoDate(varnishReady) };
  }
  return {
    code: 'preorder',
    label: `Ships after ${formatDate(varnishReady)}`,
    varnishReady,
    varnishReadyIso: isoDate(varnishReady),
  };
}

// ── True-to-scale geometry ──────────────────────────────────────────────
// One scale for the whole site: every rectangle, in every room and in the
// design reference page, is drawn at the same px-per-cm so a viewer can
// compare a painting in one room against a painting in another honestly.
export const PX_PER_CM = 2.4;
export const SILHOUETTE_HEIGHT_CM = 170; // average standing adult, used as the fixed reference figure
export const HANG_LINE_CM = 145; // 57 in "rule of 57" on-centre hang height
export const ROOM_HEIGHT_CM = 260; // an ordinary studio-gallery ceiling
export const WORK_GAP_CM = 28; // wall gap between adjacent paintings

export const cm = (n: number) => Math.round(n * PX_PER_CM * 100) / 100;

// ── Colour, computed rather than photographed ───────────────────────────
// Mixes a hex colour toward a target (paper/UV-bleach) hex by t (0..1), used
// to draw the "current colour next to a UV-faded simulation" pigment swatch
// pairs without a single photograph anywhere in the template.
export function mixHex(a: string, b: string, t: number): string {
  const pa = hexToRgb(a);
  const pb = hexToRgb(b);
  const mix = (x: number, y: number) => Math.round(x + (y - x) * t);
  return rgbToHex(mix(pa.r, pb.r), mix(pa.g, pb.g), mix(pa.b, pb.b));
}

function hexToRgb(hex: string) {
  const h = hex.replace('#', '');
  return {
    r: parseInt(h.slice(0, 2), 16),
    g: parseInt(h.slice(2, 4), 16),
    b: parseInt(h.slice(4, 6), 16),
  };
}

function rgbToHex(r: number, g: number, b: number): string {
  const h = (n: number) => n.toString(16).padStart(2, '0');
  return `#${h(r)}${h(g)}${h(b)}`.toUpperCase();
}

// ── Shipping window ──────────────────────────────────────────────────────
// A freshly varnished surface is touch-dry but still soft enough that
// wrapping and transit pressure can mark it. Conservators and framers widely
// advise a minimum two-week set before a varnished oil is packed — this is
// on top of the varnish-ready (minimum cure) date already computed above,
// not a substitute for it.
export const VARNISH_SET_DAYS = 14;

export function addDaysUTC(d: Date, days: number): Date {
  const out = new Date(d.getTime());
  out.setUTCDate(out.getUTCDate() + days);
  return out;
}

export function computeShippingWindow(varnishReady: Date): Date {
  return addDaysUTC(varnishReady, VARNISH_SET_DAYS);
}

// ── Framing & glazing, computed from the medium ──────────────────────────
// Oil paint film needs to breathe and is already protected by its own
// varnish layer, so — unlike a work on paper — it is conventionally framed
// WITHOUT glazing (glass or acrylic): a sealed glazed package can trap
// moisture against the paint film and glass sits close enough to touch and
// mark an oil surface that still has years of cure ahead of it. What
// changes by medium is the frame construction, not whether to glaze.
export type FramingRecommendation = { frame: string; glazing: string; note: string };

export function framingRecommendation(medium: string): FramingRecommendation {
  const glazing = 'None. Oil paint film is protected by its own varnish layer and needs to breathe — glazing traps moisture against the surface and can touch a film that is still curing.';
  if (medium.toLowerCase().includes('linen')) {
    return {
      frame: 'Floater frame, rebate depth clearing the stretcher bars by at least 6 mm so the frame never touches the paint film.',
      glazing,
      note: 'A linen canvas moves slightly with humidity; a floater frame lets it move without the frame rubbing the tacking edge.',
    };
  }
  if (medium.toLowerCase().includes('panel')) {
    return {
      frame: 'Panel or box frame seated on the cradle, not the painted face — the cradle carries the weight, the frame carries the cradle.',
      glazing,
      note: 'A cradled panel does not move the way stretched linen does, so the frame can sit closer, but the rebate still must clear the paint film itself.',
    };
  }
  return { frame: 'Simple wood frame, rebate clearing the paint film.', glazing, note: '' };
}
