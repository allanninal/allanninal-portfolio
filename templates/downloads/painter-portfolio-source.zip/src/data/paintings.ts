// Teresa Ibarra — three active series. Every number below is the fact the
// room canvas AND the ready-to-ship table are both generated from, so the
// drawing and the table cannot quietly disagree (RESEARCH.md, builder flag).
//
// "Started" paintings that were scraped back to bare ground (canvas) or
// reused (panel) do not appear below — they no longer exist as objects.
// started = finished + scraped/reused for every room, by construction.
import type { DryingCategoryId } from '~/lib/paint-science';

export type Painting = {
  id: string;
  title: string;
  widthCm: number;
  heightCm: number;
  /** ISO date the painting was finished (last mark made). */
  completed: string;
  /** false = the original is not for sale at any date; only a print exists. */
  forSale: boolean;
  priceUSD: number;
};

export type Room = {
  slug: string;
  name: string;
  medium: string;
  span: string;
  started: number;
  scrapedLabel: string;
  scrapedCount: number;
  dryingCategory: DryingCategoryId;
  paintings: Painting[];
};

function isoLerp(startIso: string, endIso: string, t: number): string {
  const start = new Date(`${startIso}T00:00:00Z`).getTime();
  const end = new Date(`${endIso}T00:00:00Z`).getTime();
  const d = new Date(start + (end - start) * t);
  return d.toISOString().slice(0, 10);
}

function price(widthCm: number, heightCm: number, ratePerCm2: number, floor: number, step = 5): number {
  const raw = widthCm * heightCm * ratePerCm2;
  return Math.max(floor, Math.round(raw / step) * step);
}

// ── Low Tide — coastal landscapes, oil on linen, 2024–2026 ────────────────
// 22 canvases started, 15 finished, 7 scraped back to bare ground.
// Thick impasto in the horizon passages → 2-year drying category.
const LOW_TIDE_SIZES: Record<number, [number, number]> = {
  1: [30, 24], 2: [41, 33], 4: [46, 38], 5: [51, 41], 7: [61, 46],
  8: [66, 51], 10: [76, 61], 11: [81, 61], 12: [122, 91], 13: [91, 71],
  15: [56, 46], 16: [36, 28], 18: [25, 20], 19: [71, 56], 21: [46, 36],
};
const LOW_TIDE_NOT_FOR_SALE = new Set([8, 18]);
const lowTideNums = Object.keys(LOW_TIDE_SIZES).map(Number).sort((a, b) => a - b);

export const lowTide: Room = {
  slug: 'low-tide',
  name: 'Low Tide',
  medium: 'Oil on linen',
  span: '2024–2026',
  started: 22,
  scrapedLabel: 'scraped back to bare ground',
  scrapedCount: 7,
  dryingCategory: 'impasto',
  paintings: lowTideNums.map((n, i) => {
    const [w, h] = LOW_TIDE_SIZES[n];
    return {
      id: `low-tide-${n}`,
      title: `Low Tide No. ${n}`,
      widthCm: w,
      heightCm: h,
      completed: isoLerp('2024-02-01', '2026-07-01', i / (lowTideNums.length - 1)),
      forSale: !LOW_TIDE_NOT_FOR_SALE.has(n),
      priceUSD: price(w, h, 0.32, 180),
    };
  }),
};

// ── Kitchen Table — still life, oil on cradled panel, 2025 ────────────────
// 11 started, 9 finished, 2 scraped. Standard alla-prima layering →
// 6-month drying category, the general rule.
const KITCHEN_TABLE_SIZES: Record<number, [number, number]> = {
  1: [20, 25], 2: [25, 20], 3: [30, 24], 5: [35, 28], 6: [41, 33],
  7: [46, 36], 8: [24, 30], 10: [28, 35], 11: [33, 41],
};
const KITCHEN_TABLE_NOT_FOR_SALE = new Set([3]);
const kitchenNums = Object.keys(KITCHEN_TABLE_SIZES).map(Number).sort((a, b) => a - b);

export const kitchenTable: Room = {
  slug: 'kitchen-table',
  name: 'Kitchen Table',
  medium: 'Oil on cradled panel',
  span: '2025',
  started: 11,
  scrapedLabel: 'scraped back to bare ground',
  scrapedCount: 2,
  dryingCategory: 'standard',
  paintings: kitchenNums.map((n, i) => {
    const [w, h] = KITCHEN_TABLE_SIZES[n];
    return {
      id: `kitchen-table-${n}`,
      title: `Kitchen Table No. ${n}`,
      widthCm: w,
      heightCm: h,
      completed: isoLerp('2025-01-15', '2025-11-20', i / (kitchenNums.length - 1)),
      forSale: !KITCHEN_TABLE_NOT_FOR_SALE.has(n),
      priceUSD: price(w, h, 0.35, 150),
    };
  }),
};

// ── Fog Studies — small studies, oil on panel, ongoing ────────────────────
// 30 started, 19 finished, 11 reused. Thin, lean layers →
// 2-month drying category.
const FOG_SIZES: Record<number, [number, number]> = {
  1: [25, 20], 3: [28, 23], 4: [30, 25], 6: [33, 28], 7: [36, 30],
  9: [38, 30], 10: [41, 33], 12: [23, 18], 13: [25, 18], 15: [28, 20],
  17: [30, 23], 18: [33, 25], 20: [20, 15], 22: [23, 15], 24: [25, 18],
  26: [28, 20], 27: [18, 13], 28: [30, 20], 30: [33, 23],
};
const FOG_NOT_FOR_SALE = new Set([9, 22]);
const fogNums = Object.keys(FOG_SIZES).map(Number).sort((a, b) => a - b);

export const fogStudies: Room = {
  slug: 'fog-studies',
  name: 'Fog Studies',
  medium: 'Oil on panel',
  span: 'Ongoing',
  started: 30,
  scrapedLabel: 'reused',
  scrapedCount: 11,
  dryingCategory: 'lean',
  paintings: fogNums.map((n, i) => {
    const [w, h] = FOG_SIZES[n];
    return {
      id: `fog-study-${n}`,
      title: `Fog Study ${n}`,
      widthCm: w,
      heightCm: h,
      completed: isoLerp('2025-05-01', '2026-08-25', i / (fogNums.length - 1)),
      forSale: !FOG_NOT_FOR_SALE.has(n),
      priceUSD: price(w, h, 0.18, 65),
    };
  }),
};

export const rooms: Room[] = [lowTide, kitchenTable, fogStudies];

export const allPaintings: (Painting & { room: Room })[] = rooms.flatMap((room) =>
  room.paintings.map((p) => ({ ...p, room })),
);

export const largestPainting = allPaintings.reduce((a, b) =>
  a.widthCm * a.heightCm > b.widthCm * b.heightCm ? a : b,
);
export const smallestPainting = allPaintings.reduce((a, b) =>
  a.widthCm * a.heightCm < b.widthCm * b.heightCm ? a : b,
);
