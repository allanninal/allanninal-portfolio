// Five pigments in Teresa's paint box, rated per ASTM D4303 — the standard
// lightfastness test for artists' colourants, rated I (excellent) through
// IV/V (poor). Sources: ASTM D4303-03, naturalpigments.com. See RESEARCH.md.
//
// Two of the five are the fugitive examples the page argues from: genuine
// Alizarin Crimson (PR83) and genuine Sap Green are both historically
// fugitive pigments that most modern "same name" tube colours have quietly
// replaced with a lightfast hue mixture — Winsor & Newton discontinued
// genuine Alizarin Crimson for Permanent Alizarin Crimson (ASTM I) in 1994.
// Teresa paints with the genuine article in both cases, which is why the
// print of a painting made with either can outlive the original.
export type Pigment = {
  id: string;
  name: string;
  colourIndex: string;
  astm: 'I' | 'II' | 'III–IV' | 'IV–V';
  fugitive: boolean;
  hex: string;
  note: string;
  usedIn: string;
};

export const pigments: Pigment[] = [
  {
    id: 'titanium-white',
    name: 'Titanium White',
    colourIndex: 'PW6',
    astm: 'I',
    fugitive: false,
    hex: '#F4F1E8',
    note: 'Excellent lightfastness. In every ground and every highlight in all three rooms.',
    usedIn: 'Low Tide, Kitchen Table, Fog Studies',
  },
  {
    id: 'yellow-ochre',
    name: 'Yellow Ochre',
    colourIndex: 'PY43',
    astm: 'I',
    fugitive: false,
    hex: '#C08A3E',
    note: 'A natural iron oxide earth — effectively permanent; some of the oldest pigment known to painting.',
    usedIn: 'Kitchen Table, Low Tide',
  },
  {
    id: 'french-ultramarine',
    name: 'French Ultramarine',
    colourIndex: 'PB29',
    astm: 'I',
    fugitive: false,
    hex: '#2A3E8C',
    note: 'Synthetic ultramarine, chemically identical in stability to the mineral it replaced. No fade to disclose.',
    usedIn: 'Low Tide skies and water',
  },
  {
    id: 'alizarin-crimson-genuine',
    name: 'Alizarin Crimson (genuine)',
    colourIndex: 'PR83',
    astm: 'III–IV',
    fugitive: true,
    hex: '#7C1A2E',
    note: '"Completely fugitive in washes." Winsor & Newton discontinued the genuine pigment for a lightfast Permanent Alizarin Crimson hue (ASTM I) in 1994 — Teresa still paints with the genuine article.',
    usedIn: 'Low Tide glazes',
  },
  {
    id: 'sap-green-genuine',
    name: 'Sap Green (genuine)',
    colourIndex: 'NG',
    astm: 'IV–V',
    fugitive: true,
    hex: '#3E8E41',
    note: 'Historically "highly fugitive" — every tube sold as Sap Green today is almost always a lightfast hue mixture, not this pigment. This is the colour on this page.',
    usedIn: 'Kitchen Table, Fog Studies foliage',
  },
];

// The UV-bleach target each fugitive pigment fades toward — computed, not
// photographed, via mixHex() in src/lib/paint-science.ts.
export const FADE_TARGET = '#DCCBA0'; // a bleached, sun-struck paper tone
export const FADE_YEARS_SIMULATED = 15;

// Which pigments are actually in a given room's paintings, derived from the
// same `usedIn` field the disclosure table already prints — not a second,
// separately-maintained list that could quietly drift from the table above.
export function pigmentsForRoom(roomName: string): Pigment[] {
  return pigments.filter((p) => p.usedIn.includes(roomName));
}
