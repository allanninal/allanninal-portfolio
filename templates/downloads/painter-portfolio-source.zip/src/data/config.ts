// Teresa Ibarra — a small coastal studio. Fictional.
export const site = {
  name: 'Teresa Ibarra',
  title: 'Teresa Ibarra — oil & cold-wax painter',
  tagline: '122 × 91 cm on the wall, not on your screen.',
  owner: 'Teresa Ibarra',
  ownerRole: 'Painter',
  city: 'Port Verren',
  state: 'ME',
  language: 'en',
  email: 'landix.ninal@gmail.com',
  linkedin: '#',
  // Held under the 160 characters Google and LinkedIn truncate at.
  description:
    'Oil and cold-wax paintings from a small coastal studio, shown true to size against a ' +
    'human figure — plus the varnish-ready date each one actually has, and the prints available today.',
  ogImage: '/og-image.png',
};

export const rooms_nav = [
  { label: 'Low Tide', href: '#room-low-tide' },
  { label: 'Kitchen Table', href: '#room-kitchen-table' },
  { label: 'Fog Studies', href: '#room-fog-studies' },
];

export const secondaryNav = [
  { label: 'Ready to ship', href: '#ready-to-ship' },
  { label: 'Pigments', href: '#pigments' },
  { label: 'Prints', href: '#prints' },
  { label: 'Commission', href: '#commission' },
];

export const howItsMade = [
  {
    step: 'Ground',
    detail: 'Linen sized and primed, or a cradled panel gessoed and sanded, so the surface is even before the first mark.',
  },
  {
    step: 'Block-in',
    detail: 'A thin, lean wash of turpentine and paint establishes composition and value — nothing here is thick yet.',
  },
  {
    step: 'Working layers',
    detail: 'Fat-over-lean passes build form over days or weeks, thickest in the passages that will read as texture from across a room.',
  },
  {
    step: 'Touch-dry',
    detail: 'The surface is dry to the finger within days to about two weeks, depending on thickness. This is not cured — only dry to the touch.',
  },
  {
    step: 'Minimum cure',
    detail: 'The oxidative cure runs through the full paint film, not just the surface: 2 months for thin, lean layers; 6 months for standard alla-prima work; up to 2 years for thick impasto.',
  },
  {
    step: 'Varnish',
    detail: 'A final protective coat is applied only after the minimum cure for that painting’s build — never before, whatever a listing might say.',
  },
];
