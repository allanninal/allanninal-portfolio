// A print is never waiting on an oil cure — a giclée reproduction on archival
// pigment ink exists the moment the file is proofed. That is the honest
// reason prints sit alongside originals here, not a generic upsell
// (RESEARCH.md, "The axis").
export type PrintSize = {
  id: string;
  label: string;
  widthIn: number;
  heightIn: number;
  priceUSD: number;
};

export const printPaper = '310gsm cotton rag, acid-free, 100% cotton fibre';
export const printInk = '11-colour archival pigment inkjet';
// Wilhelm Imaging Research testing rates correctly produced archival pigment
// prints on cotton rag at 100–200+ years of display life under glass.
export const printDisplayLife = '100–200+ years framed under glass (Wilhelm Imaging Research display-permanence rating)';

export const printSizes: PrintSize[] = [
  { id: 'sm', label: '8 × 10 in', widthIn: 8, heightIn: 10, priceUSD: 85 },
  { id: 'md', label: '12 × 16 in', widthIn: 12, heightIn: 16, priceUSD: 145 },
  { id: 'lg', label: '18 × 24 in', widthIn: 18, heightIn: 24, priceUSD: 225 },
];

export const printProcess = [
  {
    step: 'Digital capture',
    detail: 'The finished original is scanned or photographed under D65-balanced light and colour-matched by eye against the panel or canvas.',
  },
  {
    step: 'Proof',
    detail: 'One proof print is checked against the original in daylight before an edition is approved — the print is judged against the object, not a screen.',
  },
  {
    step: 'Archival pigment print',
    detail: `${printInk} on ${printPaper}.`,
  },
  {
    step: 'Ship',
    detail: 'Rolled in a rigid tube for 12 × 16 in and larger; flat-packed for 8 × 10 in. Ready to frame.',
  },
];
