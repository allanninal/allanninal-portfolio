import { test, expect } from '@playwright/test';

// Edition-aware: the Pro edition swaps the free download bar for a
// "Pro edition — live preview" strip with a locked Get-Pro link.
const isPro = process.env.PUBLIC_EDITION === 'pro';
const barLabel = isPro ? 'Pro edition — live preview' : 'Free template — download or fork';

test('TemplateInfo bar renders the canonical links', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  await expect(bar).toBeVisible();

  const allLink = bar.locator('a', { hasText: /all 365/i });
  await expect(allLink).toBeVisible();

  if (isPro) {
    const getPro = bar.locator('a', { hasText: /get pro static/i });
    await expect(getPro).toHaveAttribute('href', /linkedin\.com/);
    await expect(bar.locator('a[download][href*="-static.zip"]')).toBeVisible();
    return;
  }

  await expect(bar.locator('a[download][href*="-static.zip"]')).toBeVisible();
  await expect(bar.locator('a[download][href*="-source.zip"]')).toBeVisible();
  const hireLink = bar.locator('a', { hasText: /build with me/i });
  await expect(hireLink).toHaveAttribute('href', /linkedin\.com/);
});

test('TemplateInfo has no github.com/allanninal/templates links', async ({ page }) => {
  await page.goto('/');
  const bar = page.locator(`[aria-label="${barLabel}"]`);
  const badLinks = bar.locator('a[href*="github.com/allanninal/templates"]');
  expect(await badLinks.count()).toBe(0);
});
