import { test, expect } from '@playwright/test';

test('homepage loads with correct title', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Petal & Polish/);
});

test('hero heading is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hero-heading')).toBeVisible();
});

test('services section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#services')).toBeVisible();
});

test('gallery section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#gallery')).toBeVisible();
});

test('gallery grid has items', async ({ page }) => {
  await page.goto('/');
  const items = page.locator('#gallery-grid .gallery-item');
  const count = await items.count();
  expect(count).toBeGreaterThanOrEqual(8);
});

test('team section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#team')).toBeVisible();
});

test('testimonials section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#testimonials')).toBeVisible();
});

test('hygiene section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#hygiene')).toBeVisible();
});

test('about section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#about')).toBeVisible();
});

test('contact section is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#contact')).toBeVisible();
});

test('hours section has opening times', async ({ page }) => {
  await page.goto('/');
  const hours = page.locator('#hours');
  await expect(hours).toBeVisible();
});

test('LinkedIn contact link is present', async ({ page }) => {
  await page.goto('/');
  const contactSection = page.locator('#contact');
  const linkedinLink = contactSection.locator('a[href*="linkedin.com"]');
  await expect(linkedinLink).toBeVisible();
});

test('booking CTA link is present', async ({ page }) => {
  await page.goto('/');
  const bookingLink = page.locator('a[href*="fresha.com"]').first();
  await expect(bookingLink).toBeVisible();
});

test('service tabs switch panels', async ({ page }) => {
  await page.goto('/');
  const tabs = page.locator('.service-tab');
  const count = await tabs.count();
  expect(count).toBeGreaterThanOrEqual(3);
  // Click second tab
  await tabs.nth(1).click();
  const secondPanel = page.locator('.service-panel').nth(1);
  await expect(secondPanel).not.toHaveClass(/hidden/);
});

test('TemplateInfo bar is visible when hub URL is set', async ({ page }) => {
  await page.goto('/');
  const barLabel = process.env.PUBLIC_EDITION === 'pro'
    ? 'Pro edition — live preview'
    : 'Free template — download or fork';
  const templateInfo = page.locator(`[aria-label="${barLabel}"]`);
  await expect(templateInfo).toBeVisible();
});

test('navigation links exist', async ({ page }) => {
  await page.goto('/');
  const nav = page.getByRole('navigation', { name: 'Main navigation' });
  await expect(nav).toBeAttached();
});
