export const salon = {
  name: 'Petal & Polish',
  tagline: 'Where Nails Become Art',
  description: 'A serene nail studio in the heart of the city, dedicated to precision, artistry, and your comfort.',
  address: '182 Spring Street, New York, NY 10012',
  phone: '+1 (212) 555-0147',
  email: 'landix.ninal@gmail.com',
  instagram: 'https://www.instagram.com/',
  facebook: 'https://www.facebook.com/',
  bookingUrl: 'https://www.fresha.com/',
  linkedin: 'https://www.linkedin.com/in/allanninal/',
  kofi: 'https://ko-fi.com/allanninal',
  hours: [
    { day: 'Monday',    open: 'Closed' },
    { day: 'Tuesday',   open: '10:00 am – 7:00 pm' },
    { day: 'Wednesday', open: '10:00 am – 7:00 pm' },
    { day: 'Thursday',  open: '10:00 am – 8:00 pm' },
    { day: 'Friday',    open: '10:00 am – 8:00 pm' },
    { day: 'Saturday',  open: '9:00 am – 6:00 pm' },
    { day: 'Sunday',    open: '10:00 am – 5:00 pm' },
  ],
};

export const site = {
  title: 'Petal & Polish — Nail Salon, New York City',
  description:
    'Petal & Polish is a serene NYC nail studio offering gel manicures, acrylics, nail art, pedicures, and more. Book your appointment with our expert nail technicians.',
  language: 'en',
  ogImage: '/og-image.png',
  twitterHandle: '@allanninal',
};

export const services = [
  {
    id: 'manicures',
    category: 'Manicures',
    icon: '◇',
    items: [
      { name: 'Classic Manicure',      price: '$35',  description: 'Shape, buff, cuticle care, and polish of your choice.' },
      { name: 'Spa Manicure',          price: '$55',  description: 'Classic + warm soak, exfoliation, and hydrating mask.' },
      { name: 'Gel Manicure',          price: '$55',  description: 'Long-lasting gel polish with zero dry time.' },
      { name: 'Gel-X Extensions',      price: '$75',  description: 'Soft-gel tips for natural-looking length and strength.' },
      { name: 'Russian Manicure',      price: '$80',  description: 'Precision e-file technique for immaculate cuticles.' },
    ],
  },
  {
    id: 'pedicures',
    category: 'Pedicures',
    icon: '◯',
    items: [
      { name: 'Classic Pedicure',      price: '$50',  description: 'Soak, trim, shape, callus removal, and polish.' },
      { name: 'Luxury Spa Pedicure',   price: '$75',  description: 'Extended massage, exfoliation, and hydrating paraffin dip.' },
      { name: 'Gel Pedicure',          price: '$65',  description: 'Classic pedicure with long-wear gel polish finish.' },
      { name: 'Hot Stone Pedicure',    price: '$85',  description: 'Therapeutic hot stone massage and deep conditioning.' },
    ],
  },
  {
    id: 'enhancements',
    category: 'Acrylics & Enhancements',
    icon: '◈',
    items: [
      { name: 'Full Set Acrylic',         price: '$85',  description: 'Classic acrylic sculpted to your preferred length and shape.' },
      { name: 'Acrylic Fill',             price: '$55',  description: 'Infill to maintain your existing acrylic set.' },
      { name: 'Acrylic Removal',          price: '$25',  description: 'Safe soak-off with cuticle care included.' },
      { name: 'Dip Powder Set',           price: '$65',  description: 'Odour-free, durable dip powder for natural strength.' },
      { name: 'Dip Powder Removal',       price: '$20',  description: 'Gentle removal with minimal damage to natural nail.' },
    ],
  },
  {
    id: 'nail-art',
    category: 'Nail Art',
    icon: '✦',
    items: [
      { name: 'Simple Nail Art',        price: 'from $10', description: 'Per nail — geometric lines, dots, French variations.' },
      { name: 'Detailed Nail Art',      price: 'from $20', description: 'Per nail — florals, abstract, hand-painted designs.' },
      { name: 'Ombré / Gradient',       price: '$25+',     description: 'Seamless colour blend across all nails.' },
      { name: 'Chrome / Foil Effect',   price: '$20+',     description: 'Mirror chrome or metallic foil overlay.' },
      { name: '3D Nail Art',            price: 'from $30', description: 'Per nail — gems, texture, raised sculptural elements.' },
      { name: 'Full Set Art Design',    price: 'from $80', description: 'Cohesive nail art theme across all ten nails.' },
    ],
  },
  {
    id: 'addons',
    category: 'Add-Ons',
    icon: '◦',
    items: [
      { name: 'Paraffin Dip',           price: '$15',  description: 'Moisturising warm paraffin wrap for hands or feet.' },
      { name: 'Nail Repair (per nail)', price: '$8',   description: 'Silk wrap, gel, or acrylic repair for a broken nail.' },
      { name: 'Cuticle Oil Treatment',  price: '$10',  description: 'Nourishing cuticle oil massage and conditioning.' },
      { name: 'Gel Removal',            price: '$15',  description: 'Careful gel soak-off without damage.' },
      { name: 'Hand Massage (10 min)',  price: '$20',  description: 'Relaxing hand and forearm massage add-on.' },
    ],
  },
];

export const technicians = [
  {
    id: 'mia-chen',
    name: 'Mia Chen',
    title: 'Lead Nail Artist & Co-Founder',
    specialty: 'Nail Art · Russian Manicure',
    bio: 'Trained in nail art in Seoul and New York, Mia brings 10 years of precision artistry to every appointment. Her hand-painted floral designs and intricate nail sculptures have a devoted following across social media.',
    yearsExp: 10,
    instagram: 'https://www.instagram.com/',
  },
  {
    id: 'sofia-reyes',
    name: 'Sofia Reyes',
    title: 'Senior Nail Technician',
    specialty: 'Acrylics · Gel-X · Nail Art',
    bio: 'Sofia specialises in acrylic sculpting and Gel-X extensions that look and feel entirely natural. A perfectionist by nature, she is known for clean shapes, flawless application, and designs that turn heads.',
    yearsExp: 8,
    instagram: 'https://www.instagram.com/',
  },
  {
    id: 'luna-park',
    name: 'Luna Park',
    title: 'Nail Technician',
    specialty: 'Gel Polish · Chrome & Foil · Ombré',
    bio: 'Luna has an eye for colour and a steady hand that makes every chrome finish, ombré gradient, and foil effect look flawless. Her cheerful chairside manner keeps clients coming back.',
    yearsExp: 5,
    instagram: 'https://www.instagram.com/',
  },
  {
    id: 'grace-adeyemi',
    name: 'Grace Adeyemi',
    title: 'Nail Technician',
    specialty: 'Pedicures · Dip Powder · Classic Manicures',
    bio: "Grace is the studio's pedicure specialist — her luxury spa pedicure treatments are a seasonal ritual for many clients. She brings warmth, attentiveness, and impeccable nail care to every session.",
    yearsExp: 4,
    instagram: 'https://www.instagram.com/',
  },
];

export const testimonials = [
  {
    quote: 'Mia painted the most intricate cherry blossom design across all my nails — it looked like a painting I wanted to keep forever. I get compliments everywhere I go.',
    author: 'Chloe V.',
    service: 'Full Set Art Design',
  },
  {
    quote: 'My Gel-X set from Sofia has lasted five weeks without lifting. The shape and length are exactly what I wanted — she listened to every detail.',
    author: 'Andrée L.',
    service: 'Gel-X Extensions',
  },
  {
    quote: 'The luxury spa pedicure with Grace is a full hour of pure bliss. The hot stone massage and paraffin dip alone are worth every penny.',
    author: 'Jasmine T.',
    service: 'Hot Stone Pedicure',
  },
  {
    quote: 'Luna\'s chrome ombré is the most beautiful nail finish I have ever had. The studio is so calm and clean — exactly the kind of place I want to spend my Sunday.',
    author: 'Rebecca M.',
    service: 'Chrome & Ombré Combo',
  },
  {
    quote: 'I have been coming to Petal & Polish for two years. The Russian manicure is so precise my cuticles have never looked better. It is the only place I trust for my nails.',
    author: 'Danielle W.',
    service: 'Russian Manicure',
  },
  {
    quote: 'Clean tools, relaxing ambience, skilled technicians, and genuinely beautiful results every time. This studio sets the standard for what a nail salon should be.',
    author: 'Priya N.',
    service: 'Gel Manicure + Nail Art',
  },
];

// `src` + `proLabel` drive the Pro edition's real nail photography (free uses
// the CSS-gradient `palette` swatch). proLabel describes the actual photographed
// design; free keeps the original abstract colour name.
export const galleryItems = [
  { id: 1,  label: 'Cherry Blossom Art',    palette: ['#F5C5C8', '#D97B8A', '#A03050'],  style: 'Floral',    src: 'design-01', proLabel: 'Pink Swirl Almond' },
  { id: 2,  label: 'Coral Ombré Gel',       palette: ['#F5A88A', '#E8735A', '#C9483A'],  style: 'Ombré',     src: 'design-02', proLabel: 'Gel Polish Detail' },
  { id: 3,  label: 'Rose Gold Chrome',      palette: ['#DEB899', '#C4956A', '#9E7350'],  style: 'Chrome',    src: 'design-03', proLabel: 'Gold-Line French' },
  { id: 4,  label: 'Sage Minimalist',       palette: ['#C8D8C0', '#8AAB80', '#4E7550'],  style: 'Minimal',   src: 'design-04', proLabel: 'Pink Hearts' },
  { id: 5,  label: 'Lavender Cloud',        palette: ['#D8C8E8', '#A890C0', '#7058A0'],  style: 'Pastel',    src: 'design-05', proLabel: 'Pastel Medley' },
  { id: 6,  label: 'Pearl French Tip',      palette: ['#F8F0E8', '#D8C8B8', '#B8A090'],  style: 'French',    src: 'design-06', proLabel: 'Silver 3D Floral' },
  { id: 7,  label: '3D Floral Sculpture',   palette: ['#F5D0D8', '#E890A0', '#C05070'],  style: '3D Art',    src: 'design-07', proLabel: 'Silver Couture Art' },
  { id: 8,  label: 'Midnight Navy Foil',    palette: ['#1A1A3A', '#2A3A6A', '#4A6AAA'],  style: 'Foil',      src: 'design-08', proLabel: 'Purple Glitter French' },
  { id: 9,  label: 'Nude Almond Set',       palette: ['#F0E0D0', '#D8C0A8', '#B89880'],  style: 'Classic',   src: 'design-09', proLabel: 'Neon Lime Chrome' },
  { id: 10, label: 'Abstract Ink Swirl',    palette: ['#E8D0A8', '#C09860', '#7A6030'],  style: 'Abstract',  src: 'design-10', proLabel: 'Mirror Chrome Almond' },
  { id: 11, label: 'Hot Pink Power',        palette: ['#F560A0', '#D03080', '#A00860'],  style: 'Bold',      src: 'design-11', proLabel: 'Soft Nude Almond' },
  { id: 12, label: 'Pistachio Botanical',   palette: ['#D8E8C8', '#A8C890', '#608060'],  style: 'Botanical', src: 'design-12', proLabel: 'In the Studio' },
];

export const stats = [
  { value: '10+',   label: 'Years of Artistry' },
  { value: '4',     label: 'Expert Technicians' },
  { value: '3,200+', label: 'Happy Clients' },
  { value: '4.9★',  label: 'Average Rating' },
];

export const hygienePoints = [
  {
    icon: '◈',
    title: 'Single-Use Tools',
    description: 'Disposable files, buffers, and liners are used for each client — never reused.',
  },
  {
    icon: '◇',
    title: 'Medical-Grade Sterilisation',
    description: 'All metal implements are sterilised in a hospital-grade autoclave between every appointment.',
  },
  {
    icon: '◯',
    title: 'Non-Toxic Products',
    description: 'We use 5-free and 7-free polishes, low-odour acrylics, and dermatologist-tested gels.',
  },
  {
    icon: '✦',
    title: 'Clean Air Studio',
    description: 'HEPA filtration and individual nail desk ventilation keep the air fresh for clients and technicians alike.',
  },
];
