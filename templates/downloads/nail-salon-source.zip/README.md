# Petal & Polish — Nail Salon Template

**Day 52 of 365** · Free MIT Astro template

A polished nail salon / nail bar website with services menu, nail-art gallery/lookbook, team section, hygiene callout, booking CTA, hours, and location. Built for real nail studios ready to stand out online.

Live demo: [templates.allanninal.dev/nail-salon/](https://templates.allanninal.dev/nail-salon/)

---

## Design

- **Palette**: Pearl (#FBF8F5) background · Coral (#B03028 / #C9483A) accent · Rose-gold (#C4956A) highlights · Deep plum (#3D1A24) headings
- **Fonts**: Italiana (display/headings) + Plus Jakarta Sans Variable (body)
- **Style**: Light-only, editorial, feminine-luxe with strong WCAG AA contrast

## Sections

1. Hero — tagline, booking CTA, gallery CTA, decorative nail colour strip
2. Stats band — years, technicians, clients, rating
3. Services & Price Menu — 5 tabbed categories (Manicures / Pedicures / Acrylics / Nail Art / Add-Ons) with prices
4. Nail Art Gallery / Lookbook — 12-item colour-swatch grid with hover labels and style tags
5. Team — 4 technician profiles with specialties and bios
6. Testimonials — 6 client reviews
7. Hygiene & Quality — 4-point safety commitment callout
8. Booking CTA — full-width coral band linking to Fresha
9. About — founder story, studio values, non-toxic commitment
10. Hours & Location — 7-day schedule + address/contact card

## Schema.org

- `NailSalon` (primary) with `PostalAddress` + `OpeningHoursSpecification`
- `HealthAndBeautyBusiness` with `OfferCatalog` → `Offer` / `Service`
- `WebSite`

## Quick start

```bash
cd templates/nail-salon
npm install
npm run dev
```

## Customise

Edit `src/data/config.ts` — salon name, address, phone, hours, booking URL, services, technicians, testimonials, and gallery items are all data-driven.

## Deploy

```bash
PUBLIC_BASE_PATH=/your-path/ npm run build
```

The `dist/` folder is a self-contained static site — drop it on any host.

---

MIT License · Made by [Allan Niñal](https://www.linkedin.com/in/allanninal/)
