/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Italiana', 'Georgia', 'serif'],
        body: ['"Plus Jakarta Sans Variable"', '"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Coral/pearl/rose-gold palette
        coral:     { DEFAULT: '#C9483A', light: '#E8735A', soft: '#F5E0DB' },
        pearl:     { DEFAULT: '#FBF8F5', dark: '#F0EAE4' },
        rosegold:  { DEFAULT: '#9A6E42', light: '#C4956A', dark: '#7A5230' },
        plum:      { DEFAULT: '#3D1A24', mid: '#6B3344', light: '#9B5C6E' },
        cream:     { DEFAULT: '#FFFCF9' },
      },
    },
  },
  plugins: [],
};
