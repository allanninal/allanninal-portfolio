import { test, expect } from '@playwright/test';

test.describe('Reuben Mackaye — smoke tests', () => {
  test('homepage renders with the illustrator in the title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Reuben Mackaye/);
    await expect(page.locator('h1')).toContainText(/where it’s going before I draw it/);
  });

  // Six artworks in a series rather than one work with six medium tags — the
  // page's argument is that the medium decides what the drawing IS.
  test('each output is its own VisualArtwork, in one series', async ({ page }) => {
    await page.goto('/');
    const blocks = await page.$$eval('script[type="application/ld+json"]', (e) =>
      e.map((x) => x.textContent || ''));
    const graph = JSON.parse(blocks.find((b) => b.includes('"@graph"'))!)['@graph'];
    const plates = await page.locator('#outputs figure.plate').count();
    expect(graph.length).toBe(plates);
    const media = graph.map((w: any) => w.artMedium);
    expect(new Set(media).size).toBe(graph.length);
    for (const w of graph) {
      expect(w['@type']).toBe('VisualArtwork');
      expect(w.isPartOf['@type']).toBe('CreativeWorkSeries');
      expect(Array.isArray(w.artMedium)).toBe(false);
      expect(w.image).toBeUndefined();
    }
    const all = blocks.join('');
    expect(all).toContain('"Person"');
    expect(all).not.toContain('"offers"');
    expect(all).not.toContain('inLanguage');
    expect(all).not.toContain('ProfessionalService');
  });

  // ── The drawings ────────────────────────────────────────────────────────
  test('every output is drawn, and none of them is an image', async ({ page }) => {
    await page.goto('/');
    const plates = page.locator('#outputs figure.plate');
    const n = await plates.count();
    expect(n).toBeGreaterThan(5);
    expect(await page.locator('#outputs img, #outputs picture').count()).toBe(0);
    for (const p of await plates.all()) {
      await expect(p).toBeVisible();
      await expect(p.locator('svg')).toHaveAttribute('aria-hidden', 'true');
      expect(await p.locator('svg path, svg circle, svg rect, svg line').count()).toBeGreaterThan(0);
    }
  });

  // If the six were independent drawings the page would be claiming something
  // it cannot support. They share one body path.
  test('all seven drawings share the same body coordinates', async ({ page }) => {
    await page.goto('/');
    const bodies = await page.locator('#outputs figure.plate svg path').evaluateAll((ps) =>
      ps.map((p) => p.getAttribute('d')).filter((d) => (d || '').startsWith('M24,60')));
    const plates = await page.locator('#outputs figure.plate').count();
    expect(bodies.length).toBeGreaterThanOrEqual(plates);
    expect(new Set(bodies).size).toBe(1);
  });

  test('detail actually falls away as the constraint tightens', async ({ page }) => {
    await page.goto('/');
    const count = async (id: string) =>
      page.locator(`#outputs .plate:has(.k:text-is("${id}")) svg *`).count();
    const els = await page.locator('#outputs figure.plate').evaluateAll((figs) =>
      figs.map((f) => ({
        name: (f.querySelector('.k')!.textContent || '').trim(),
        n: f.querySelectorAll('svg *').length,
      })));
    const by = Object.fromEntries(els.map((e) => [e.name, e.n]));
    // The portfolio version is the busiest; the billboard is the simplest.
    expect(by['The portfolio version']).toBeGreaterThan(by['Newsprint, one colour']);
    expect(by['Newsprint, one colour']).toBeGreaterThan(by['Machine embroidery']);
    expect(by['Billboard, 40 metres']).toBeLessThanOrEqual(2);
  });

  test('the vinyl version bridges its counter', async ({ page }) => {
    await page.goto('/');
    const vinyl = page.locator('#outputs figure.plate').last();
    await expect(vinyl.locator('.k')).toContainText('Vinyl');
    // A filled body, a counter, and a bar joining the counter to the edge.
    expect(await vinyl.locator('svg circle').count()).toBe(1);
    expect(await vinyl.locator('svg rect').count()).toBe(1);
    await expect(vinyl.locator('figcaption')).toContainText(/bridge/i);
  });

  test('the two-colour plate really is two inks, offset', async ({ page }) => {
    await page.goto('/');
    const riso = page.locator('#outputs figure.plate').nth(2);
    await expect(riso.locator('.k')).toContainText('Risograph');
    const fills = await riso.locator('svg path').evaluateAll((ps) =>
      ps.map((p) => p.getAttribute('fill')));
    expect(fills.some((f) => (f || '').includes('ink-red'))).toBe(true);
    expect(fills.some((f) => (f || '').includes('accent'))).toBe(true);
    const shifted = await riso.locator('svg path[transform]').count();
    expect(shifted).toBeGreaterThan(0);
  });

  // ── The numbers ─────────────────────────────────────────────────────────
  test('every constraint in a caption is repeated in the table', async ({ page }) => {
    await page.goto('/');
    const capt = await page.locator('#outputs .plate .rule').allTextContents();
    const table = (await page.locator('#constraints table').textContent()) || '';
    for (const c of capt) {
      const mins = c.split('—')[0].trim();
      expect(table).toContain(mins);
    }
    expect(await page.locator('#constraints tbody tr').count()).toBe(capt.length);
  });

  test('the eyebrow counts the constrained outputs correctly', async ({ page }) => {
    await page.goto('/');
    const rules = await page.locator('#outputs .plate .rule').allTextContents();
    const constrained = rules.filter((r) => !/No floor/.test(r)).length;
    await expect(page.locator('#outputs .eyebrow')).toContainText(`${constrained} of them constrained`);
    await expect(page.locator('#outputs h2')).toContainText(`${rules.length} times`);
  });

  // ── Brief ───────────────────────────────────────────────────────────────
  test('the brief table is ordered by what a late answer costs', async ({ page }) => {
    await page.goto('/');
    const costs = await page.locator('#brief tbody td.v').allTextContents();
    expect(costs.length).toBe(6);
    expect(costs[0].trim()).toBe('Redraw');
    expect(costs[1].trim()).toBe('Redraw');
    expect(costs[costs.length - 1].trim()).toMatch(/Hours/);
  });

  test('the declined briefs name style mimicry and training data', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#terms')).toContainText(/In the style of a named living illustrator/);
    await expect(page.locator('#terms')).toContainText(/model training data/);
  });

  test('the demo says the drawings are SVG, not artwork', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.note-box')).toContainText(/SVG drawn in the page/);
    await expect(page.locator('#faq')).toContainText(/really SVG/);
  });

  test('the FAQ is an accordion and the form asks the smallest size', async ({ page }) => {
    await page.goto('/');
    expect(await page.locator('#faq details').count()).toBeGreaterThan(4);
    for (const id of ['#name', '#email', '#smallest', '#message']) {
      await expect(page.locator(id)).toHaveAttribute('required', '');
    }
    expect(await page.locator('#contact select').count()).toBe(1);
  });

  test('no trace of the day-125 source template survives', async ({ page }) => {
    await page.goto('/');
    const html = (await page.content()).toLowerCase();
    for (const noun of ['aldermann', 'providence', 'glyph', 'waterfall', 'foundry']) {
      expect(html).not.toContain(noun);
    }
    expect(await page.locator('form').count()).toBe(1);
  });

  test('the page cannot be scrolled sideways at any width', async ({ page }) => {
    for (const w of [1440, 1280, 900, 640, 375]) {
      await page.setViewportSize({ width: w, height: 900 });
      await page.goto('/');
      const r = await page.evaluate(() => ({ sw: document.body.scrollWidth, iw: window.innerWidth }));
      expect(r.sw, `overflow at ${w}px`).toBeLessThanOrEqual(r.iw + 1);
    }
  });

  test('mobile nav toggle works', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const toggle = page.locator('.mobile-toggle');
    await expect(toggle).toBeVisible();
    await toggle.click();
    await expect(page.locator('#mobile-nav')).not.toHaveAttribute('hidden', '');
  });

  test('the Pro print notes are absent from the free build', async ({ page }) => {
    const res = await page.goto('/print-notes/');
    expect(res?.status()).toBeLessThan(400);
    expect((await page.content()).toLowerCase()).toContain('refresh');
  });
});
