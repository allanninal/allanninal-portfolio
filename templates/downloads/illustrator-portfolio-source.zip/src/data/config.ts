// Reuben Mackaye — Athens, GA. Fictional.
//
// The organising idea: an illustration portfolio is a grid of pictures all
// presented identically, which hides the only thing that changes how the work
// is made. The same subject drawn for newsprint, for a two-colour risograph,
// for a 48 px icon, for 4 mm embroidery, for a billboard and for a vinyl cut is
// six different drawings.
//
// The six drawings on the page are SVG rather than raster art: nobody buying
// this template wants my drawings, they want the structure with their own work
// in it. The page says so where it matters.

export const site = {
  name:        'Reuben Mackaye',
  shortName:   'Reuben Mackaye',
  title:       'Reuben Mackaye — illustration, Athens, Georgia',
  tagline:     'Tell me where it’s going before I draw it.',
  owner:       'Reuben Mackaye',
  ownerRole:   'Illustrator',
  credential:  'Editorial, packaging and print · thirteen years',
  city:        'Athens',
  state:       'GA',
  language:    'en',
  phoneDisplay: '(706) 555-0158',
  phoneHref:   '+17065550158',
  email:       'reuben@mackaye.example',
  streetAddress: '265 W Washington St',
  postalCode:  '30601',
  hours:       'Roughs within a week of a brief · finals two weeks after approval',
  bookingWindow: 'Booked three to six weeks out · a rush is possible and it is a different price',
  description:
    'A portfolio is a grid of finished pictures, all 2000 px wide on a white background, which ' +
    'hides the only thing that actually changes the work: where it ends up. Below is one subject ' +
    'drawn six times, for newsprint, a two-colour risograph, a 48-pixel icon, machine ' +
    'embroidery, a billboard and a vinyl cut — with the physical number that forced each one.',
  formAction:  '#',
  ogImage:     '/og-image.png',
  instagram:   '#',
  facebook:    '#',
  twitterHandle: '@example',
};

export const nav = [
  { label: 'The outputs', href: '#outputs' },
  { label: 'The brief',   href: '#brief' },
  { label: 'Process',     href: '#process' },
  { label: 'Commission',  href: '#contact' },
];

export const drawingNote =
  'These six are SVG drawn in the page rather than scans of artwork, which is deliberate for a ' +
  'template: nobody buying it wants my drawings, they want the structure with their own work in ' +
  'it. Resize the window, or your browser text, and every one of them holds — which is also a ' +
  'reasonable test of an illustration site.';

// ── The six outputs ───────────────────────────────────────────────────────
// `min` is the smallest feature that survives. `drops` is what is removed and
// why. The SVGs on the page are generated per `id`.

export const outputs = [
  { id: 'full',   k: 'The portfolio version',
    where: 'A screen, 2000 px, full colour',
    min: 'No floor',
    rule: 'Nothing is a constraint',
    drops: 'Nothing. This is the drawing everybody sees and the only one of the six that has never had to survive anything.' },
  { id: 'news',   k: 'Newsprint, one colour',
    where: 'A weekly paper, 85 lpi, uncoated',
    min: '0.4 pt',
    rule: 'Dot gain closes anything finer',
    drops: 'All the hatching. On press, lines at 0.25 pt fill in and become a grey smear that looks like a printing fault and is a drawing fault. Line weights go up and the tone comes from spacing rather than from thickness.' },
  { id: 'riso',   k: 'Risograph, two colours',
    where: 'A 400-copy zine, teal and red',
    min: '1 mm overlap',
    rule: '±1 mm misregistration, every copy',
    drops: 'Any outline that has to register with a fill. The two plates are drawn to overlap on purpose, so a mis-register reads as an intentional edge rather than as a white gap. This is the drawing people think is a happy accident.' },
  { id: 'icon',   k: 'App icon, 48 px',
    where: 'A launcher, at 48 and 24 px',
    min: '2 px',
    rule: 'Below 2 px a feature simply is not there',
    drops: 'Everything but three shapes. The eye goes, the fin goes, the gill goes. What is left has to be recognisable as a silhouette, which is why this version is drawn first when an icon is in the brief.' },
  { id: 'stitch', k: 'Machine embroidery',
    where: 'Cap fronts, 4 mm satin stitch',
    min: '4 mm',
    rule: 'A stitch is the smallest mark that exists',
    drops: 'Every interior line, and the outline gets thick enough to be a filled shape. Digitising an unsuitable drawing is where an embroiderer quietly redraws your work and nobody tells you.' },
  { id: 'board',  k: 'Billboard, 40 metres',
    where: '48-sheet, read from a moving car',
    min: '120 mm',
    rule: 'Only the silhouette survives at distance',
    drops: 'All interior detail, which was decoration nobody was ever going to see. If the silhouette does not read, no amount of drawing inside it will help.' },
  { id: 'vinyl',  k: 'Vinyl cut, single path',
    where: 'Shop window, one cut, weeded by hand',
    min: 'One closed contour',
    rule: 'Floating parts fall out',
    drops: 'Anything not connected. Every counter needs a bridge to the outside, which is a drawing decision and not a production one — the cutter will happily cut a shape that falls on the floor.' },
];

export const outputNote =
  'Seven drawings, one subject, and the finished-picture version at the top is the only one with ' +
  'no constraint in it. Every over-run I have ever had came from a brief that named the picture ' +
  'and not the press.';

// ── The brief ─────────────────────────────────────────────────────────────

export const brief = [
  { k: 'Where does it print or display?',  cost: 'Redraw', n: 'The single question. Getting it in week four rather than week one means starting again, because a newsprint drawing is not a thinned billboard drawing.' },
  { k: 'How many colours, and which?',     cost: 'Redraw', n: 'Two spot colours is a completely different drawing from CMYK, not a reduced one. If it is a risograph, name the inks — they are not process colours and they do not mix like them.' },
  { k: 'What is the smallest it appears?', cost: '2–3 days', n: 'Not the largest. A drawing that works at 48 px works at 2000; the reverse fails silently and gets found by a client on a phone.' },
  { k: 'Is there an icon or a mark in it?', cost: '2–3 days', n: 'If yes it gets drawn first, because everything else can be built out from a shape that reduces and almost nothing reduces down to one.' },
  { k: 'Who else touches the file?',       cost: '1 day',   n: 'An embroiderer, a sign shop, a printer. All of them will adjust the drawing and only some of them will say so. Naming them means I can send the right file rather than the pretty one.' },
  { k: 'What is it next to?',              cost: 'Hours',   n: 'Type, a photograph, other illustrations by other people. Cheap to answer and it changes weight and crop more than any other single fact.' },
];

// ── Process ───────────────────────────────────────────────────────────────

export const process = [
  { k: 'Brief and medium, together',  n: 'One conversation, and the medium half of it is the half that gets skipped. Everything downstream is cheap if this is right and expensive if it is not.' },
  { k: 'Thumbnails, six to ten',      n: 'Postage-stamp size, deliberately, because at that size only composition exists and composition is what a change is cheap to make to.' },
  { k: 'One rough, drawn at output size', n: 'At the real dimensions, in the real number of colours. This is the approval point and it is the last cheap moment in the project.' },
  { k: 'Final, in the output medium', n: 'A change here is not a revision, it is a redraw. That is not a policy — a two-colour separation redrawn is genuinely a new drawing.' },
  { k: 'Files for whoever is next',   n: 'The layered source, the flattened version, the single-path version if there is a cutter, and the separations if there is a press.' },
  { k: 'A proof, where there is one', n: 'A press proof, a test pressing, a sample cap. I ask for one on every job that has a physical output and get one about half the time.' },
];

// ── Delivered, and declined ──────────────────────────────────────────────

export const delivered = [
  { t: 'The file the next person needs',
    d: 'Not one master file. A press gets separations, a cutter gets a single closed path, an embroiderer gets a simplified outline at stitch weight. Sending one 2000 px PNG to all three is how a drawing gets redrawn by somebody else.' },
  { t: 'The layered source',
    d: 'Yours, at the end, without asking. A studio that keeps the source is holding a future revision hostage and everybody knows it.' },
  { t: 'A licence in one paragraph',
    d: 'Where it runs, for how long, and what a second use costs. It is short because the interesting version of this argument belongs to a different trade and a different page.' },
];

export const declined = [
  { t: 'In the style of a named living illustrator',
    d: 'The commonest brief of 2026 and the easiest to turn down. If the style is the deliverable, the person who made it should be the one paid for it, and their rate is on their own site.' },
  { t: 'Artwork licensed as model training data',
    d: 'Not licensed for it, in any contract I sign, and the clause is one sentence I wrote. It costs me a job every few months.' },
  { t: 'A final in four days with no medium named',
    d: 'Not a rush problem. A rush with a known output is a price; a rush without one is a coin flip that I lose in the second week when somebody says it is going on a cap.' },
];

export const said = {
  text: 'The first question was which press it was running on, before what it was even of, which nobody had ever asked us. The line weights came back right the first time. We printed 12,000 and not one of them filled in.',
  who: 'Editor, weekly paper — 2025',
};

export const faqs = [
  {
    q: 'Why does the medium matter so much?',
    a: 'Because it is physics rather than preference. Newsprint closes anything under about 0.4 pt, a risograph misregisters by a millimetre on every copy, embroidery cannot make a mark smaller than a stitch, and a vinyl cutter will happily cut a shape that falls on the floor. None of that is a style question and all of it changes the drawing.',
  },
  {
    q: 'Can you just simplify the detailed version?',
    a: 'Sometimes, and usually not. A billboard version is not the portfolio version with detail removed — the silhouette has to carry the whole thing, which often means a different pose and a different crop. Thinning a drawing that was not built to reduce produces something that looks thinned.',
  },
  {
    q: 'What if we do not know the output yet?',
    a: 'Then we draw thumbnails and stop there until you do. Thumbnails cost an hour and survive any answer; a final costs two weeks and survives exactly one. Stopping at the cheap stage is a real option and I would rather propose it than quietly guess.',
  },
  {
    q: 'What is a revision, and what is a redraw?',
    a: 'A change at thumbnail or at rough is a revision and it is included. A change after the final has been drawn in the output medium is a redraw, because a two-colour separation reworked is genuinely a new drawing rather than an edited one. The line is at the rough approval and it is in the estimate.',
  },
  {
    q: 'Do you work in a named illustrator’s style?',
    a: 'No. It is the most common request of the last two years and the easiest to decline: if the style is what is wanted, the person who built it should be the one paid, and their rate is on their own site. The same answer covers training-data requests, which is a clause in every contract I sign.',
  },
  {
    q: 'Are those six drawings really SVG?',
    a: 'Yes, drawn in the page. Zoom to 400% and they hold. For a template that is the honest choice — nobody buying it wants my fish, they want the structure with their own work dropped into it.',
  },
];
