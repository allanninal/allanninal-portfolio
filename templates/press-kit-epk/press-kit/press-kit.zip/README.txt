Lila Marin — Official Press Kit

Contents:
- one-sheet.pdf       — One-page EPK summary (bio, stats, press, contact)
- brand-guidelines.pdf — Brand usage guidelines
- photos/             — High-resolution press photos (replace placeholders)
- logos/              — Logo and wordmark SVGs

Photo credits:
- Hero Color, B&W Portrait: Photography by Sasha Vance
- Live Performance: Photography by Tomas Rivera
- Studio Close-up: Photography by Lena Park

License: Photos for press/editorial use only. CC BY-NC-ND 4.0.
All logos copyright Lila Marin / Shallow Lake Recordings.

Contact:
Press: priya@brightnoise.pr
Booking: jay@constellationagency.com
Management: marcia@fullcurrent.co
