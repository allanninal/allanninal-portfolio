Lila Marin — Official Press Kit

Contents:
- one-sheet.pdf        — One-page EPK summary (bio, stats, press, contact)
- brand-guidelines.pdf — Brand usage guidelines
- photos/              — Press photos (see the note below)
- logos/               — Logo and wordmark SVGs

Photos:
The four images in photos/ are STAND-INS from Unsplash, used under the
Unsplash License (free for commercial use, attribution not required).
They are not photographs of Lila Marin, who is a fictional persona used
to demonstrate this template. Replace all four with the real artist's
photography before using this press kit for anything real.

Photo sources:
- hero-color-2400px.jpg   https://images.unsplash.com/photo-1459749411175-04bf5292ceea
- bw-portrait-square.jpg  https://images.unsplash.com/photo-1524650359799-842906ca1c06
- live-performance.jpg    https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f
- studio-close.jpg        https://images.unsplash.com/photo-1516280440614-37939bbacd81

Logos are part of this template and carry its MIT license.

Contact:
Press: priya@brightnoise.pr
Booking: jay@constellationagency.com
Management: marcia@fullcurrent.co
