# Background check chaser — Make workflow

Generated from the /build series **Background check chaser** (2026-07-19).
Read the series first; it is free, end to end, and explains every decision here:
https://www.allanninal.dev/build/series/background-check-chaser/

## What is in this archive

| File | What it is |
|---|---|
| `background-check-chaser.make.json` | The workflow, ready to import |
| `README.md` | This file |

## Importing it

1. In Make, **Create a new scenario**.
2. Open the **⋯** menu at the bottom of the canvas → **Import Blueprint**.
3. Choose `background-check-chaser.make.json`.
4. Every module is an HTTP call, so there are no app connections to remap — but
   you do need to add AWS SigV4 authentication to each one, or put an API
   gateway in front.
5. Set the schedule. **The free plan's minimum interval is 15 minutes**, which
   is ample: this design runs nightly or at a period close.

### Free-plan budget

This scenario is **8 modules**, so one run costs 8 of your
1,000 monthly credits. That is roughly **125 runs a month** before the
free plan stops you.

The series' own middle volume tier is 40 checks. Compare it against the
ceiling above before assuming the free plan is enough — for most of these
series it is not, and that is worth knowing on day one rather than on the day
it stops.

## What you must replace before it runs

Nothing in this file carries a credential — that is deliberate, and it is why
the import will prompt you.

- **`MODEL_ID`** in the Bedrock call. Part 7 of the series names the model the
  design assumes and explains why it is a mid-tier one rather than a frontier
  model.
- **The bucket** `background-check-chaser-inbox`, and the table names `background-check-chaser-checks`.
- **The region.** Everything is written for `eu-west-2`. Part 7 explains why,
  and what would have to move if you change it.
- **The email addresses** on the notification step.

## This is a port, not an equivalent

The series designs this system on AWS. Three things do not survive the move,
and it is better to know them now than to find out later.

1. **Per-step IAM is gone.** The AWS design gives every function its own
   execution role with a resource-scoped policy — part 7 makes a point of it.
   Make shares one credential per app across the whole scenario.
2. **The cost argument does not carry over.** Part 6 prices the system at a few
   dollars a month on Lambda, DynamoDB and SES. Make prices per operation against a 1,000-credit monthly free ceiling, so
   at the volumes the article assumes this can cost materially more, not
   less.
3. **Append-only tables with condition expressions** have no direct equivalent,
   so the concurrency story weakens from an atomic condition to sequential
   execution. Where the article relies on a conditional write, this file relies
   on running one thing at a time.

## Verification status

**Structurally checked, not import-tested.** Make's API is Core-plan and
above, so there is no way to validate a blueprint programmatically on a free
account. What has been checked: the JSON parses, module ids are unique across
nested routes, every module carries a version and designer metadata, and every
module identifier is one that appears inside a real `"module":` field in
Make's own published template corpus — `http:MakeRequest` v4 and
`builtin:BasicRouter` v1. Nothing here is guessed. The remaining test is the
one only you can run: import it.

## How this was derived

From the series' own source spec: the Lambda inventory, the branch structure
and the table schemas are read directly out of it, so the steps here line up
with the article one for one.

## Licence and provenance

Generated from the published series. The architecture, the cost breakdown and
the engineering reference are free to read at the link above. If you build on
this, the interesting part is the design, not the JSON.
