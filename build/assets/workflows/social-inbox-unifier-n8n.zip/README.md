# Social inbox unifier — n8n workflow

Generated from the /build series **Social inbox unifier** (2026-06-12).
Read the series first; it is free, end to end, and explains every decision here:
https://www.allanninal.dev/build/series/social-inbox-unifier/

## What is in this archive

| File | What it is |
|---|---|
| `social-inbox-unifier.n8n.json` | The workflow, ready to import |
| `README.md` | This file |

## Importing it

1. Open n8n.
2. **Workflows → Import from File**, and choose `social-inbox-unifier.n8n.json`.
3. n8n will flag the nodes that need credentials. Add an AWS credential and
   select it on the S3, DynamoDB and SES nodes.
4. Open the sticky note on the canvas — it repeats the substitutions below.
5. Run it once manually before you let the schedule have it.

## What you must replace before it runs

Nothing in this file carries a credential — that is deliberate, and it is why
the import will prompt you.

- **`MODEL_ID`** in the Bedrock call. Part 7 of the series names the model the
  design assumes and explains why it is a mid-tier one rather than a frontier
  model.
- **The bucket** `social-inbox-unifier-inbox`, and the table names `social-inbox-unifier-dedupe`, `social-inbox-unifier-threads`, `social-inbox-unifier-assignments`.
- **The region.** Everything is written for `eu-west-2`. Part 7 explains why,
  and what would have to move if you change it.
- **The email addresses** on the notification step.

## This is a port, not an equivalent

The series designs this system on AWS. Three things do not survive the move,
and it is better to know them now than to find out later.

1. **Per-step IAM is gone.** The AWS design gives every function its own
   execution role with a resource-scoped policy — part 7 makes a point of it.
   n8n shares one credential per app across the whole workflow.
2. **The cost argument does not carry over.** Part 6 prices the system at a few
   dollars a month on Lambda, DynamoDB and SES. Self-hosting n8n is a different shape entirely: the compute is yours and
   always on, so a quiet month is no longer nearly free.
3. **Append-only tables with condition expressions** have no direct equivalent,
   so the concurrency story weakens from an atomic condition to sequential
   execution. Where the article relies on a conditional write, this file relies
   on running one thing at a time.

## Verification status

**Validated.** This workflow passes n8n's own `validate_workflow` check —
every node type, operation and connection resolves against n8n's node
database. It has not been executed against live AWS resources.

## How this was derived

From the series' published engineering reference. That page predates the
current spec format, so the function list and the stores are recovered from it
while the branch structure is not. Treat this as the right shape with the
right pieces, rather than a step-by-step transcription -- read part 7 of the
series for the detail.

## Licence and provenance

Generated from the published series. The architecture, the cost breakdown and
the engineering reference are free to read at the link above. If you build on
this, the interesting part is the design, not the JSON.
